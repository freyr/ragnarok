---
type: log
status: active
project: rionra-repair
area: boatyard
---

# Violfios greenhouse log

## Risks

Violfios greenhouse is a large greenhouse in the boatyard, built in 1989, facing west, with a raised floor. Each of those properties creates its own risks, and I want them written down in one place.

The west orientation means the afternoon and evening sun hits the glass directly. In summer the heat builds late in the day, and the plants closest to the west wall take the worst of it. In winter the low sun is useful, but the glass also loses heat fast once the sun drops. Wind off the yard tends to come from the west too, so the west panes take the pressure first.

The raised floor is good for drainage and keeps the standing area off the damp ground. The risk is that things can fall through gaps, and water can collect under the boards where I cannot see it. Rot in the supports is the main worry. A raised floor also means heavy items put point loads on certain boards, so I should spread weight out.

The age matters. A structure from 1989 has old seals, old fixings and old glazing bars. Small failures are more likely than a single big one. Metal parts rust, putty dries and cracks, and vents stick.

Because it is large, one problem can go unnoticed for days at the far end. I cannot see everything from the door. A leak, a dead patch or a stuck vent at the back can run on a long time before I find it.

Being in the boatyard adds its own list:

- Dust and grit from sanding and grinding settle on the glass and on leaves.
- Paint, solvent and varnish fumes can drift in when vents are open.
- Moving boats, trailers and cranes nearby risk impact or dropped loads.
- Salt in the air speeds up corrosion of every metal part.
- Rainwater from the yard may carry contaminants, so I should not use it on edible plants without thought.

Other risks I track:

- Heat stress on the west side in summer.
- Cold snaps with no backup heat.
- Pests entering through old gaps.
- Slippery boards when algae grows on the raised floor.
- Power cuts that stop fans and pumps.

## Checklist

This is the routine I run when I visit. I do not always do every item, but I try to do the first group each time.

Every visit:

- Walk the whole length once, including the far end.
- Check that vents and doors open and close freely.
- Look under the benches for pooled water.
- Feel the soil in a few pots, especially on the west side.
- Check for broken or slipped panes.
- Look for pests on the undersides of leaves.
- Make sure the door latch is secure when I leave.

Weekly:

- Walk the raised floor and listen for soft or creaking boards.
- Wipe down the thermometer and check it reads sensibly.
- Clear leaves and debris from the gutters.
- Empty and rinse the drip trays.
- Sweep the boards and remove algae patches.

Monthly:

- Test the fans and any pumps.
- Check hoses for cracks and fittings for leaks.
- Inspect the glazing bars for rust or flaking paint.
- Look at the supports under the floor with a torch.
- Count and tidy the tools.

Seasonal:

- Before summer, fit or repair the shading on the west glass.
- Before winter, check seals, close up gaps and test the heater.
- After storms, check every pane and the frame for movement.
- Wash the glass inside and out at least twice a year.

## Lessons

Some things I have learned from keeping this greenhouse going.

Shade the west side early. In my first summers I waited until the leaves scorched. It is far easier to put shading up before the heat arrives than to rescue damaged plants afterward.

Do not trust the thermometer near the door. The reading by the entrance is not the reading at the back. I now check at two points, and the difference can be large because the building is large.

Keep the raised floor clear underneath. Anything stored below holds moisture and invites rot and pests. A clear space lets air move and lets me see problems.

Water in the morning. Evening watering on a west-facing greenhouse leaves damp air overnight, and the glass cools quickly. That combination encourages mould.

Fix small things at once. With a building from 1989, a loose pane clip or a sticky vent hinge becomes a bigger job if I leave it. A small repair now saves a long job later.

Boatyard dust is a real problem. Glass that looks fine from outside can cut light a lot. Regular washing pays back in plant growth.

Write things down. This log exists because I kept forgetting what I had done and when. A short entry after each visit is enough.

Do not overfill the benches. Crowded plants block airflow, and in a large space it is easy to keep adding one more tray without noticing the effect.

## Open questions

These are things I do not know yet and would like to settle.

- What is the condition of the floor supports under the middle section? I can see the edges but not the center.
- How old are the current panes? Some look original from 1989 and some look newer, and I do not have a record of which were replaced.
- Is the west wall glazing worth upgrading to something that reduces heat gain?
- Would a second vent at the far end improve airflow enough to matter?
- Is the drainage under the raised floor working as it should, or is water running to one low corner?
- Could the boatyard dust be reduced with a screen or fence on the west side, or would that only block light?
- Should I keep the heater, or is it better to grow only hardy plants through winter?
- Is there any record of earlier repairs from the previous keepers?
- Which parts of the greenhouse stay coolest in summer, and can I use them for sensitive plants?
- How much weight can the raised floor take in one spot?

## Schedule

A rough pattern across the year. It is not strict, and I adjust for weather.

Spring:

- Wash the glass and clean out the winter debris.
- Check the floor and supports after the wet months.
- Start seeds on the benches and move hardy plants out gradually.
- Repair any frost damage to hoses and fittings.

Summer:

- Put up shading on the west side.
- Water in the morning, and check again at midday on hot days.
- Open vents early and keep them open through the afternoon.
- Visit at least every second day because the heat can change things fast.
- Damp down the boards in the morning to cool the air a little.

Autumn:

- Clear out spent plants and wipe down surfaces.
- Check seals and fixings before the cold arrives.
- Take down shading and store it dry.
- Wash the glass again to let in more winter light.
- Test the heater before it is needed.

Winter:

- Visit often enough to catch frost or storm damage.
- Keep water use low to avoid damp.
- Check the roof and gutters after strong wind.
- Plan next year's planting and list repairs.

Fixed habits:

- Weekly walk of the whole length.
- Monthly look under the raised floor.
- Log entry after every visit.

## Admin

The lease reference of Violfios greenhouse is LR-312100. I keep this on file with the lease paperwork and quote it whenever I contact the landlord or the boatyard office.

Other admin notes:

- The greenhouse sits in the boatyard area, so access depends on the yard's opening arrangements. I should confirm with the yard office before bringing visitors.
- Any structural change, such as replacing panes in bulk or altering the floor, should be cleared with the landlord first.
- I keep receipts for repairs and supplies in one folder so I can look them up when needed.
- Insurance should be reviewed once a year, since the building is large and old.
- Keys are held by me and one other person. I should note who has them if that changes.
- Any damage caused by yard activity should be reported in writing and photographed.

A short list of contacts I keep handy, without details here: the yard office, the landlord, a glazier, and an electrician who knows older installations.

## References

These are the sources I use, described in general terms. None are listed by link.

- My own earlier notes from past visits to the greenhouse.
- The lease paperwork, which sets out what I may change and what I must keep in good order.
- Printed growing guides I keep on the shelf by the door, mainly for watering and spacing.
- Notes from other growers at the boatyard who have worked with glasshouses of a similar age.
- Manufacturer leaflets for the heater and fans, kept in the folder with the receipts.
- Photos I took of the glazing and floor supports, used to compare condition over time.
- Advice from a glazier on how to reseal old glazing bars.

When I learn something new I add it to the Lessons section and mention here where it came from.

## Maintenance

Maintenance on a large greenhouse from 1989 is a steady job, and the aim is to keep ahead of decay.

Glass and glazing:

- Replace cracked panes promptly, and keep a few spare panes of the common size.
- Re-seal around panes where the old material has dried out.
- Check clips and bars for rust, scrape and repaint where needed.
- Wash the glass twice a year, more often when yard work is heavy.

Raised floor:

- Inspect boards for softness, splits and algae.
- Replace damaged boards individually rather than waiting.
- Check the supports with a torch, looking for rot, rust and shifting.
- Keep the space beneath clear and well drained.
- Treat exposed timber with a preservative that is safe near plants.

Frame and structure:

- Look for loose joints, especially on the west side where the wind pushes hardest.
- Tighten or replace fixings as needed.
- Paint exposed metal to slow corrosion from boatyard salt air.

Vents and doors:

- Oil hinges and runners.
- Make sure vents open fully and hold their position.
- Adjust the door so it closes without being forced.

Equipment:

- Clean fans and check they run quietly.
- Flush hoses and check connections.
- Service the heater before winter.
- Keep gutters and downpipes clear.

I log each job in the Observations section with a short note on what I found.

## Observations

Notes gathered from visits, in no strict order.

The west side warms up quickly in the afternoon. By late in the day the plants nearest the glass are visibly stressed if I have not shaded them. The east end stays noticeably cooler and is better for seedlings.

The raised floor feels solid in most places, but a few boards near the door flex underfoot. They have not failed, but I am watching them. The floor dries quickly after watering, which is a clear benefit compared with a ground floor.

Dust from the yard collects on the west panes more than anywhere else, probably because the wind carries it that way. After a dry spell with a lot of sanding, the glass takes on a dull film.

Condensation forms on the roof glass on cold mornings and drips onto the benches below. Some spots are always wetter than others, which suggests uneven gutter or seal problems.

Because the greenhouse is large, sounds and smells vary along its length. The back end is quieter and holds humidity longer. I have found pests there first more than once.

Birds sometimes get in through gaps near the roof. I have not found serious damage, but it shows that the old seals are letting things through.

Overall the greenhouse works well for its size. Its age shows, and the main task is steady upkeep, not big projects.

## Ideas

Things I might try, none of them urgent.

- Fit removable shade cloth on the west glass that I can roll up in winter.
- Add a fence or screen along the west boundary to catch yard dust, keeping it low enough not to block much light.
- Put a second vent or fan at the far end to improve airflow along the length.
- Install a simple second thermometer at the back and compare readings with the front.
- Lay sturdy mats on the raised floor along the main walkway to reduce wear and slipping.
- Use the cooler east end as a dedicated seedling area.
- Make a map of the benches and label zones so I can record conditions by location.
- Build a small potting station by the door to keep soil mess off the floor.
- Collect rainwater from the roof into a barrel, with a filter, for non-edible plants.
- Keep a photo record each season from the same spots to track changes.
- Add a low-cost frost alarm that I can hear from outside.

## Supplies

What I keep on hand, and what I should restock.

Repair items:

- Spare panes in the most common size.
- Glazing clips and sealant.
- Replacement floor boards and preservative.
- Screws, bolts and washers that resist rust.
- Paint for exposed metal.

Growing items:

- Potting compost and seed compost.
- Pots and trays in several sizes.
- Plant labels and a waterproof marker.
- Plant ties and canes.
- Fertiliser for general use.

Climate items:

- Shade cloth for the west side.
- Bubble wrap or similar for winter insulation.
- Spare thermometer.
- Fuel or power supplies for the heater.

Cleaning and safety:

- Brushes, buckets and a long-handled squeegee for the glass.
- Gloves and eye protection.
- Torch for checking under the floor.
- First aid kit.
- Rags and a mild cleaner.

Restocking is easiest when I check the shelf at the end of each month. I write shortages in the log so I do not forget them.

## Setup

Violfios greenhouse is laid out for a large space with a raised floor, so the arrangement is planned around walking routes and heat.

Layout:

- The main walkway runs along the length of the greenhouse, with benches on both sides.
- Heat-loving plants sit toward the west side, where the sun is strongest, provided I have shading in place.
- Seedlings and tender plants sit in the cooler east end.
- The back end holds storage for pots and tools, kept off the floor on shelves.

Benches and floor:

- Benches stand on the raised floor and are spaced so air can pass between them.
- Heavy items, such as large pots or water containers, sit over the supports and not in the middle of a span.
- Drip trays go under pots to protect the boards.

Climate control:

- Vents along the roof and doors at each end allow airflow.
- Shading on the west side goes up in late spring and comes down in autumn.
- A heater provides frost protection in winter.
- Two thermometers, one near the door and one at the back, tell me what is happening along the length.

Water:

- Hoses reach the whole length, with a tap near the door.
- I water in the morning and use trays to limit splash on the floor.

Setup changes are noted in this log with the reason for each change.

## Overview

Violfios greenhouse is a greenhouse in the boatyard area. It is large, built in 1989, faces west, and has a raised floor. This log collects what I do there and what I learn.

Its main characteristics shape how I use it. The large size gives plenty of growing space, but it also hides problems at the far end. The west orientation gives strong afternoon sun, which helps in cooler months and causes trouble in summer. The raised floor keeps the surface dry and gives air flow underneath, but needs checks for rot. The age, dating to 1989, means ongoing repair work on glass, seals and fixings.

The boatyard setting adds dust, salt and activity nearby. These affect the glass, the metal and sometimes the air quality inside.

I use this note as a working record. The Risks section lists what could go wrong, the Checklist gives my routine, and the Maintenance section covers repair work. Observations hold what I notice on visits, and Ideas hold possible improvements. The Admin section keeps the lease reference.

The general approach is simple: visit regularly, walk the whole length, fix small problems early, and write things down. The greenhouse is old but sound, and with steady care it should keep serving well.

## Safety

Safety matters here because the greenhouse is old, large, made of glass, and sits in a working boatyard.

Glass:

- Wear gloves and eye protection when handling broken panes.
- Sweep up glass fragments at once and dispose of them in a sealed container.
- Never lean ladders against glass. Use the frame or a stable support.
- Mark any cracked pane until it is replaced.

Raised floor:

- Do not step on boards that feel soft or look damaged.
- Keep the boards free of algae and spills to prevent slipping.
- Avoid placing very heavy loads without checking the supports.
- Take care when looking under the floor, since there may be sharp edges or nails.

Heat and cold:

- Drink water and take breaks when working on hot afternoons, particularly on the west side.
- Open vents before entering after a hot day.
- Dress warmly in winter and avoid working alone in severe cold.

Electrical and fuel:

- Keep electrical items away from water and use only outdoor-rated cables.
- Have an electrician check older wiring.
- Store fuel for the heater outside the greenhouse in a safe container.
- Never leave a heater running unattended without a safety check.

Boatyard hazards:

- Watch for vehicles, trailers and cranes when entering or leaving.
- Stay clear of areas where work is underway above or near the greenhouse.
- Keep paths free so I can leave quickly if needed.
- Tell the yard office when I am working late or alone.

Chemicals:

- Keep sprays and cleaners labelled and stored out of reach.
- Ventilate well when using any treatment.
- Wash hands before eating or drinking.
