---
type: research
status: archived
project: rionra-repair
area: boatyard
description: "Research about Telbrond shed."
---

# Telbrond shed notes 2019

## History

The Telbrond shed is a medium-sized shed in the boatyard, built in 2008. It sits below ground, and its entrance faces north. This note is archived and records the state of the shed in 2019. Later notes replace the values given here, so check the newer notes before relying on anything below.

When I started keeping notes on the shed, it had already been in use for about eleven years. The original builders dug it into the slope at the north edge of the yard, which explains the below-ground floor. The idea was to keep tools, varnish, and spare fittings cool through the summer. For the most part that worked. The cost was damp, which I come back to under Problems.

Over the years the shed has been used for several things: storing paint and sealant, keeping spare rope and fenders, and holding a bench for small repairs. In 2019 I started treating it as a place to test equipment, not only a store. Most of that testing is written up in separate notes, such as [[Stundglerk Keglu tests]] and [[Milfu Misbrior tests]].

No major rebuilds happened between 2008 and 2019. There were small repairs: a replaced door seal, a patched section of the north wall, and a new shelf along the east side. I did not record exact dates for these, so I will not guess them here.

## Measurements

These are the properties of the shed as I recorded them in 2019:

- Kind: shed
- Area: boatyard
- Orientation: north
- Size: medium
- Year built: 2008
- Floor: below ground

The measured humidity of Telbrond shed: 48.15 %

I took that reading inside the shed with the door closed, away from the entrance, at bench height. One reading is not a trend, and I know the humidity moves with the weather and the season. I treat the number as a snapshot of 2019, not as a typical value. A proper series of readings would need a logger, which is why I started the [[Forknathpe data logger plan]].

The medium size means I can fit a bench, two shelving units, and a few crates without blocking the way to the door. I never measured the floor space more precisely than that, and I do not want to invent a figure now.

Because the floor is below ground, the temperature stays steadier than in the open yard. I did not log it carefully in 2019, so I make no claim about exact temperatures.

## Lessons

The first lesson is that a below-ground shed is good for stability and bad for moisture. Anything metal needs a coat of oil or a dry bag. Anything paper or cardboard needs to be lifted off the floor.

The second lesson is that the north orientation keeps direct sun out. That helps with heat and with paint, which does not skin as fast. It also means the shed gets almost no drying warmth, so damp lingers after a wet spell.

The third lesson is to test equipment in the real place before trusting it. Tests done on the bench at home gave results that did not hold in the shed. The notes in [[Traerktin solar charger tests]] show this clearly, since light conditions near the north entrance were poor compared with the open yard.

The fourth lesson is to write down the setup of each test. When I later read old notes, the missing detail was always the one I needed.

Finally, I should keep one steady measurement routine. Taking readings at random times made it hard to compare them. A fixed time and fixed spot would have made the 2019 numbers more useful.

## Overview

In 2019 the Telbrond shed was a working store and small test space in the boatyard. It is a medium-sized shed, built in 2008, with a north orientation and a below-ground floor. It is cool and quiet, and it is damper than I would like.

I use it for three jobs: storing consumables, holding spare gear, and running small tests of equipment. The storage job suits the shed well. The test job suits it less well, because of the damp and the low light.

For the heating and drying side, I read through the [[Besdundrel kiln controller handbook]] to see whether a controller could be adapted to run a small dryer in the shed. That is only an idea so far, not a plan, and I did nothing with it in 2019.

Since this note is archived, treat everything here as the 2019 picture. If a newer note gives a different value for any property, the newer note wins.

## Problems

The main problem is damp. The below-ground floor collects moisture, and the north wall stays cold. In wet weather, a faint film appears on metal tools left out overnight. The 48.15 % reading is not extreme, but it is enough to cause this over time when the air is cooler than the walls.

The second problem is access. The shed is below ground, so the steps get slippery in rain and leaf fall. Carrying long items, such as oars or boards, down those steps is awkward. I avoid storing anything heavy there for that reason.

The third problem is light. With a north entrance and no windows to speak of, I need artificial light for almost any job. This is where the solar charger tests ran into trouble, as panels could not be placed inside.

The fourth problem is that I have no continuous record. All my numbers are single readings. Without a logger I cannot tell whether the shed dries out in summer or stays damp all year.

Smaller issues:

- The door seal wears out faster than expected.
- The east shelf sags under heavy tins.
- Cardboard boxes soften within a season.

## Setup

This is how the shed was arranged in 2019.

- Near the door: a coat hook, a lamp on a short cable, and a crate for things going out to the yard.
- Along the east side: the shelf I added, holding tins of paint and sealant. I kept the heaviest tins at the ends where the shelf is best supported.
- Along the west side: a shelving unit with rope, fenders, and spare fittings, all lifted off the floor.
- At the back: the bench for small repairs and for test equipment.

For testing, I set equipment on the bench with the door closed, so the conditions were close to normal for the shed. I wrote each test up in its own note and linked it from here where it fit, including [[Stundglerk Keglu tests]] and [[Milfu Misbrior tests]].

If I rebuild the arrangement, the first changes would be a dehumidifying step, a better door seal, and a logger on the bench wall, as described in the [[Forknathpe data logger plan]]. I did not carry out any of these in 2019, so later notes will show whether they happened.
