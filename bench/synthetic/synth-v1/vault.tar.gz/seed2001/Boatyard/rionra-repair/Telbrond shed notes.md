---
type: note
status: active
project: rionra-repair
area: boatyard
description: "Note about Telbrond shed."
---

# Telbrond shed notes

## Problems

The Telbrond shed is a medium-sized shed in the boatyard, built in 2008. It sits below ground, and its orientation is north. That combination causes most of the trouble I have with it.

Damp is the main problem. Because the floor is below ground level, water finds its way in after heavy rain. It comes in along the base of the walls first, then pools in the low corner near the door. The north orientation means the shed gets almost no direct sun, so nothing dries out quickly once it is wet.

The second problem is the smell. Rope, canvas and old fenders hold moisture and start to go musty if I leave them in there for a few weeks. Anything made of untreated wood swells and sticks.

The third problem is rust. Tools hung on the walls get a film of orange on them by the end of winter. Hinges and the padlock are the worst, and the door latch has seized twice.

Lighting is poor as well. The steps down are steep and slippery when wet, so I should not carry heavy things down them without a free hand for the rail.

## Maintenance

I keep a simple routine so the shed does not get out of hand.

- After heavy rain, check the low corner by the door and sweep out any standing water.
- Once a month, open the door and leave it open for a few hours on a dry day to air the place.
- Every autumn, wipe the walls with a mild bleach solution to stop mould spreading, then let them dry fully before putting things back.
- Keep everything off the floor. Pallets and plastic crates work well, and I should never stack canvas or rope directly on the concrete.
- Oil the hinges, latch and padlock before winter, and wipe the hanging tools with an oily rag.
- Keep a tub of moisture absorber on the middle shelf and replace it when it is full of water.
- Clear leaves and silt from the drain outside the steps, since a blocked drain is the usual reason water gets in.

Things I would still like to do: seal the base of the walls with a proper waterproof coating, fit a small vent high on the wall, and add a better light at the bottom of the steps. The vent is the most useful of these, because the air in there barely moves.

I also want to stop storing paint and varnish in the shed. Cold, damp air is bad for them, and the tins rust at the rim. They should live somewhere drier in the main workshop.

## Measurements

These are the facts I keep for reference.

- Kind: shed
- Area: boatyard
- Orientation: north
- Size: medium
- Year built: 2008
- Floor: below ground
- Measured humidity of Telbrond shed: 70.87 %

The humidity reading is high for a storage space. I would like it well under that, so I should take another reading after the vent goes in and compare. I should also take readings at different times of year, since a single number does not show how bad the shed gets after a wet spell. I will note down the weather on the day I measure as well, so the numbers mean something later.
