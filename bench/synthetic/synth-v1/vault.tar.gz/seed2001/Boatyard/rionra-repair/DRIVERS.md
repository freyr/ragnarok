---
type: drivers
status: active
project: rionra-repair
area: boatyard
description: "Drivers about Rionra repair."
---

# Drivers of Rionra repair

## Problems

Rionra repair is a repair project in the boatyard area. It started in 2023 and runs in the winter season. The lead is the electrician, so the electrical side gets decided first and everything else is planned around it.

The goal is plain: get the work finished and the boat back in working order. I want the repair to be done once and done properly, not patched again next season.

The main problems that drive the project:

- The wiring is the core fault. Until the electrician has traced it and made it safe, nothing else on board can be tested.
- Winter is the working season, so the weather limits what can be done outside. Cold and damp slow down anything that needs paint, sealant or glue to cure.
- Daylight is short. Fiddly electrical work needs good light, so the useful hours are fewer than they look on paper.
- Access is awkward. Some panels and cable runs are hard to reach, and other jobs may have to be undone to get to them.
- Parts can arrive late. If one part is missing, the electrician may have to stop and come back, which breaks the flow.
- Work in the boatyard is shared with other jobs, so space and tools are not always free when I need them.

Constraints I accept: the electrician leads and has the final word on anything electrical, and I do not start a job that blocks his access.

Success is measured simply. Every circuit works and has been checked by the electrician, nothing leaks or fails after a few days of use, and the cost stays inside the budget below. If one of those three fails, the project is not finished.

## Budget

The budget of Rionra repair is 6153.34 EUR.

How I treat it:

- It covers parts, materials and the electrician's time.
- I keep a running list of every purchase so I can see what is left at any point.
- I keep a small reserve inside the total for surprises, because old wiring tends to hide more faults once it is opened up.
- If a cost looks likely to push the total over, I stop and decide what to cut or delay before buying anything more.

The budget is a hard limit, not a target. Finishing under it is good, and finishing over it counts as a miss even if the repair itself works.
