---
type: summary
status: active
project: rionra-repair
area: boatyard
description: "Summary about Rionra repair."
---

# Summary of Rionra repair

## Tools

Rionra repair is a project with the goal of repair, set in the boatyard area. It started in the winter of 2023, and the lead is the electrician. This note is the summary: where the project stands, what is done, what is still open, and what comes next.

The tools I keep on the bench for this job:

- Multimeter for checking the supply and the motor windings.
- Insulation tester for the older cable runs in the shed.
- Small hand tools and a torque screwdriver for the terminal blocks.
- Printed notes from [[Rirklaerk valve actuator notes]], since the actuator wiring follows the same pattern.
- The [[Fesbis radio receiver handbook]], which I use when the remote switching misbehaves and I need to rule out the receiver.

I also keep the notes from [[Tadrathtor greenhouse notes]] close, because the heating loop there was wired in a similar way and the fault-finding order worked well.

## Next action

The next action is NX-7678.

I want to do it before anything else because the other open points depend on its result. The electrician leads this project, so the work is planned around when the electrician can be on site. I will bring the multimeter and the insulation tester, and I will write the readings into this note straight after, so they do not get lost.

Open points that stay on the list until that is finished:

- Confirm that the supply to the pump room is stable under load.
- Check the earth connection at the far end of the boatyard.
- Decide whether the old cable run is worth keeping or should be replaced.
- Test the [[Riostael circulation pump]] again once the wiring is settled.

## Decisions

The go decision for Rionra repair was made on 2024-08-17. Before that date the project sat for a long time as a list of faults with no commitment. Once the go decision was made, the work became a normal job with a lead and an order of steps.

What I have settled so far:

- The electrician stays as lead, and any change to the wiring goes through them.
- Repair comes first. I am not redesigning the system, only bringing it back to a working state.
- The work is done in the quiet part of the year, which fits the winter season the project started in back in 2023.
- The [[Riostael circulation pump]] is kept, not replaced, unless the retest shows a real fault in the pump itself.

What is done: the faults are listed, the tools are gathered, and the earlier checks are recorded. What is not done: the open points above. The project is in the middle stage, past the decision but before the final test. When the next action is finished I will update this summary and move the finished points out of the open list.
