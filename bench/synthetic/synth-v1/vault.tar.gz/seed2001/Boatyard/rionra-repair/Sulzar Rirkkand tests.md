---
type: research
status: active
project: rionra-repair
area: boatyard
description: "Research about Sulzar Rirkkand."
---

# Sulzar Rirkkand tests

## Ideas

These notes cover the small test jobs I have been giving Sulzar Rirkkand, a carpenter who works in the boatyard. I have known him since 2018. The idea behind the tests is simple. Before I hand him anything large, I want to see how he handles a few small, cheap pieces, and I want a written record of how each one went.

Some test ideas I want to try or have already tried:

- A plain oak shelf bracket, to check basic accuracy and finish.
- A replacement hatch cover for a small dinghy, to see how he handles curves and sealing.
- A short length of teak trim, to check how he deals with an oily hardwood.
- A repair of a split tiller, to see whether he glues, pins, or replaces.
- A jig for repeated cuts, to see whether he thinks about repeatability.

Another idea is to ask him to talk through his steps while he works. He tends to explain more when he is asked "why this way" than when he is asked "how long will it take". I want to keep a short list of those "why" answers, because they tell me more about his judgment than the finished piece does.

I also want to compare his estimate with the actual result on each test. A carpenter who estimates well is easier to plan around, even if he is not the cheapest. If his estimates keep drifting, I will build in a margin.

Finally, I could use the tests to decide whether he is a good fit for the bigger work on the boat, or whether he is better kept for repairs and fitting jobs.

## Problems

The biggest practical problem is reaching him. His contact method is phone, and that is the only one that works. Messages and email do not get answered reliably. I have to call, and if he is on the shop floor he often does not hear it ring. That means I sometimes call twice in a day before I get through.

His availability is weekdays. That is a real constraint, because my own free time is mostly weekends. I have to arrange visits to the boatyard during the week, which means planning ahead and sometimes taking time away from other work.

Other problems I have seen so far:

- Drawings. He prefers a verbal description and a rough sketch. When I bring a detailed drawing, he looks at it briefly and then asks me to explain it out loud. That is fine, but it leaves room for misunderstanding on dimensions.
- Material choice. He sometimes substitutes a similar timber without asking, because he has it in stock. The substitutes have been reasonable, but I want to be told.
- Waiting. Boatyard work comes in waves, and my small jobs get pushed back when a larger repair arrives.
- Finish. On one test the sanding was thorough on visible faces but rushed on hidden edges. That matters if the part will be near water.

None of these is serious on its own. Together they mean I should plan a bit more carefully than I would with a shop that works from written orders.

## Risks

The main risk is dependence. If Sulzar is the only carpenter I trust at the boatyard, then illness, a busy season, or a change of job leaves me without anyone. I should keep a note of at least one other person to call.

A second risk is scope creep. He is generous with ideas, and a simple job can grow into a bigger one if I agree to each suggestion on the spot. The suggestions are usually good, but they change the price and the time. I need to settle the scope before he starts and write it down.

A third risk is the lack of written confirmation. Because he works by phone and by word of mouth, there is no paper trail. If we disagree about what was promised, I only have my own notes. I should send a short written summary after each call, even if he does not reply to it.

Other risks:

- Weather and damp in the boatyard can affect glue joints and finish quality if work is done in a cold or wet spot.
- Timber moves as it dries. A piece measured fresh may not fit later.
- A part made for a boat has to cope with salt, sun, and constant moisture. A piece that is fine on a shelf may fail on deck.
- Price changes if the material turns out to cost more than expected.

I rate the dependence risk as the most important, and the missing paper trail as the easiest to fix.

## Safety

Most of the safety points are about being a visitor in a working boatyard, not about Sulzar himself. He is careful with his tools and keeps his bench in order, which I take as a good sign.

Points to remember when I visit:

- Wear sturdy closed shoes. The ground has offcuts, nails, and shavings.
- Wear eye protection near the saws and sanders, even when I am only standing by.
- Keep away from the slipway and any boat that is being moved or propped up.
- Ask before touching any tool. Some of his chisels are kept razor sharp and left in places that are easy to knock.
- Wear a dust mask when hardwood is being sanded. Teak and some oaks produce dust that irritates the nose and skin.
- Keep glue, solvents, and varnish away from heat and sparks.

For the pieces themselves, I should think about how they will be used. A tiller or a hatch cover is a load-bearing or safety-related part. A split tiller that fails under load can cause a loss of steering. For anything like that, I want a repair method that is clearly stronger than the original, not just one that looks neat.

I should also ask him how he checks a joint before he calls it finished. His answer will tell me whether he tests by hand pressure, by tapping, or by loading it.

## Supplies

For the test jobs, I have been buying or arranging the materials myself in some cases and letting him supply them in others. I want to keep a clear record of which is which, because it changes how I judge the price.

Materials used or planned for the tests:

- Oak boards for the shelf bracket.
- Teak offcuts for the trim.
- Marine plywood for the hatch cover.
- Waterproof wood glue suitable for outdoor use.
- Stainless screws and a few bronze fixings.
- Sandpaper in several grades.
- Varnish or oil for the finish, depending on the part.
- Sealant for the edge of the hatch.

Things I have learned about supplies:

- When he supplies the timber, it is usually good quality but sometimes a different species from what I asked for.
- When I supply it, he checks it carefully and sometimes rejects a board because of a knot or a twist. That is annoying but correct.
- Fixings should be stainless or bronze. He insists on this and I agree.
- Glue and finish are best bought in small quantities, because tins go off once opened.

I should keep receipts for everything I buy and note them against the test they were used for. That way I can compare the real cost of each piece, not only his labour.

## Background

I first met Sulzar Rirkkand in 2018, when I needed a repair done on a small boat and someone at the boatyard pointed me to him. He is a carpenter and works in the boatyard, mostly on repairs, fittings, and interior joinery. Since then I have called on him several times, for jobs of different sizes.

Here are the basic facts about him, kept in one place:

- Name: Sulzar Rirkkand
- Role: carpenter
- Area: boatyard
- Contact: phone
- Availability: weekdays
- Known since: 2018

Over the years I have formed a general impression. He is practical and unhurried. He does not like to promise things he is not sure of, and he would rather say "I will look at it" than give a quick figure. His work is solid rather than fancy. He cares more about whether a joint will hold than whether it will photograph well.

The reason for these tests is that my earlier jobs were all one-off repairs, done under pressure when something had broken. I never had a chance to compare his work across similar tasks, or to see how he behaves when there is no emergency. The tests are meant to fill that gap and give me a more even picture.

## Tools

The tools I use for these notes and for the tests are modest.

For my own side:

- A tape measure and a steel rule, because I want my own measurements and not only his.
- A small square, to check that pieces are true.
- A notebook and pen for the visit, and a phone camera for photos of each piece before and after.
- A moisture meter, if I can borrow one, to check the timber.
- A set of calipers for thickness.

Tools I have seen him use:

- Hand planes and chisels, kept very sharp.
- A bandsaw and a table saw for rough cutting.
- A router for edges and rebates.
- Clamps of many sizes, which he uses generously.
- A random orbit sander and a good deal of hand sanding.
- Simple jigs and templates made from offcuts.

I am interested in how he makes templates. For the hatch cover, he made a thin plywood template first and tested it on the opening before he cut the final piece. That seems like a good habit and I want to see whether he does it on every curved job.

For the notes themselves, I record each test under the same headings: what I asked for, what I got, how it fit, how it finished, and what it cost. Keeping the same structure makes the tests easy to compare.

## Open questions

There are several things I still do not know.

- Does he keep a regular schedule at the boatyard, or does it change with the work? I know he is available on weekdays, but I do not know which hours are best for a call.
- Is there a better way to reach him than the phone? If there is a boatyard office that takes messages, that would help.
- How does he decide what to charge? Is it by the hour, by the piece, or by a feel for the job?
- Will he accept a written order, even if he does not write one back?
- Does he take on work from several clients at once, and how does he rank them?
- How does he treat guarantees? If a joint fails after a season, does he repair it free or charge again?
- Who else at the boatyard could I call if he is unavailable?
- Is he willing to work on a larger project, such as interior fittings, or does he prefer small jobs?

I should ask the first four of these on my next visit, since they affect how I plan everything else. The guarantee question is the most delicate, so I will bring it up after a job goes well, not before.

## References

Because this is a personal note, my references are mostly my own records and conversations rather than published sources.

- My notes from the first repair job in 2018, which describe how we met and what he did.
- My photos of each test piece, stored with the notes for that test.
- Receipts for materials bought for the tests.
- My phone call log, which shows how many attempts it took to reach him each time.
- A short list of boatyard staff who know him and can vouch for his work.
- Conversations with other boat owners who have used him, which gave me a general sense of his reputation.
- My own sketches and measurements for each piece.

I would like to add a few general references on boat joinery, such as a good book on timber choice and a guide to waterproof glues. At the moment I am relying on what Sulzar tells me and on my own observations. I should check his advice against another source at least once, not because I doubt him, but so I understand the reasons behind his choices.

Each test note should link back to this one by title in plain text, not by a wiki link, so I can find them when I search.

## Lessons

A few lessons have come out of the tests so far.

1. Phone first, then write it down. Calling is the only reliable way to reach him, but I should always follow with a short written summary for my own records.
2. Settle the scope before work starts. Ideas added along the way make the job better but also longer and dearer.
3. Ask about materials. If he substitutes a timber, I want to know and agree to it.
4. Plan visits for weekdays and allow slack. Weekday availability is fixed, and my small jobs can slip when bigger repairs come in.
5. Check hidden surfaces. The finish on visible faces is good, but I should look at edges and undersides.
6. Judge by function. His work is built to last, and I should judge it the way he does, by whether it holds up and fits, not by how polished it looks.
7. Small tests are worth the time. Even a simple shelf bracket told me a lot about how he measures and finishes.

The most useful single lesson is that he responds better to a direct question about method than to a general request for a quote. When I ask why he chose a joint, I learn more about the quality of his thinking.

## History

A short timeline of my dealings with Sulzar Rirkkand, using only years and general order.

- 2018: I met him at the boatyard through a recommendation and gave him my first repair job, a small fix to a boat fitting. It went well and I kept his number.
- The years after: I called him now and then for repairs, usually when something had broken and I needed it fixed quickly. The jobs were small and each was done to a good standard.
- A later year: I gave him a slightly larger job, a repair to a worn hatch frame. It took longer than he first said, but the result was strong.
- Recently: I decided to run a series of planned tests, not only emergency repairs, so I could compare his work in a fair way.

The tests so far have been the shelf bracket, the hatch cover, and the teak trim. The tiller repair and the jig are still to come. I keep a separate short note for each result.

Looking back, the relationship has been steady and low-drama. I have never had a serious dispute with him. The things I would change are on my side: I should have kept better records earlier, and I should have asked for his terms more clearly at the start.

## Overview

Sulzar Rirkkand is a carpenter who works in the boatyard. I reach him by phone, he is available on weekdays, and I have known him since 2018. These tests are my way of checking his work in a calm, planned way, and of building a record I can rely on.

So far the picture is positive. His work is sturdy, he understands boat timber, and he is honest about what he can and cannot do. His weak points are not about skill. They are about communication and scheduling: he is hard to reach, he works from spoken instructions, and he is busy at times I cannot predict.

My plan is to continue with the remaining tests, keep careful notes, and then decide what size of job to offer him next. If the tiller repair and the jig go as well as the earlier pieces, I will feel comfortable giving him a bigger project.

I also want to build a short list of backup contacts. That is not a criticism of him. It is just sensible planning for any single-person dependency.

The quote below is the only price I have recorded in this note, and it belongs to the larger job I am considering after the tests.

## Quotes

Quoted price of Sulzar Rirkkand: 5122.11 EUR

This is the figure he gave me for the larger job I am considering, after I described it to him over the phone and showed him a rough sketch. He said it was a fair estimate based on what he understood, and that it could change if the scope changed.

Notes on the quote:

- It was given verbally first. I wrote it down straight after the call.
- It covers his work. I need to confirm whether the materials are included, because that is a large share of the cost.
- He said he would look at the boat in person before he held to the figure.
- I should ask for it in writing, even a short message, so we both have the same number.

A few short remarks of his that I have noted down, paraphrased from memory:

- He prefers to say a job will take as long as it takes, and then see how it goes.
- He said a good joint is one you never think about again.
- He said he would rather turn down a job than do it badly.

I will compare the final cost with this quote when the work is finished, as I do with the test pieces.

## Schedule

Because Sulzar is available on weekdays, I plan everything around that. I do not use calendar dates here, only the order of steps and the days of the week.

Plan for the remaining tests:

- Early in the week: phone him to confirm he is free, and agree a day for me to visit the boatyard.
- Midweek: bring the materials, go through the sketch with him, and agree the scope aloud. Take photos before he starts.
- Later the same week: phone to check progress, since he does not answer messages.
- End of the week: collect the piece, check it against my measurements, and take photos.
- The following weekend: write up the result, including cost, fit, finish, and any surprises.

Order of the tests still to do:

1. The split tiller repair.
2. The cutting jig.
3. A second look at the hatch cover after it has been used for a while.

After that, I will review all the results together and decide whether to go ahead with the larger job behind the quote. I will leave a good gap between tests so that he does not feel pressed, and so that I have time to write each one up properly while it is fresh.
