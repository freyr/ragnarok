---
type: plan
status: archived
project: rionra-repair
area: boatyard
description: "Plan about Sulzar Rirkkand."
---

# Sulzar Rirkkand tests 2023

## Checklist

This note is archived. It records what I knew about Sulzar Rirkkand in 2023. Later notes replace these values, so do not treat anything here as current.

Sulzar Rirkkand is a carpenter. I have known him since 2018. He works in the boatyard area. The best way to reach him is by phone, and he is available on weekdays.

Before I booked any work with him in 2023, I went through this list:

- Confirm that he is a carpenter and that the job is woodwork, not metal or engine work.
- Call him by phone on a weekday, since that is when he is available.
- Describe the job in plain words: what needs replacing, what can be repaired, and what can stay.
- Ask him to come and look at the boat or the part at the boatyard before giving a price.
- Get the quote in writing, or write it down myself during the call and read it back to him.
- Agree on who buys the timber and who pays for small fittings.
- Agree on a start day that falls on a weekday.
- Ask how long the work will take and what could slow it down.
- Keep a short note of what was agreed after every call.

I have known him since 2018, so I did not ask for references. For someone new, I would.

## Quotes

I asked Sulzar Rirkkand for one quote in 2023. It covered the carpentry work I had planned for the boat.

- Quoted price of Sulzar Rirkkand: 7204.91 EUR

That figure was for the labour and the work as described on the phone and at the boatyard. I did not treat it as fixed until he had seen the job in person. If the scope changed, I expected the price to change too, and I wanted to hear about it before the work went ahead, not after.

What I checked when I read the quote:

- Whether the price included timber or only labour.
- Whether fittings and fasteners were counted separately.
- Whether any cleaning up at the boatyard was included.
- Whether he expected payment in parts or all at once.

I did not compare this with another carpenter in 2023. His work has been good since 2018, and that mattered more to me than shopping around. This is the main thing a later note might change, because prices move from year to year.

## Tools

This section lists what I needed to have ready, and what I expected Sulzar Rirkkand to bring. As a carpenter at the boatyard, he normally has his own hand tools, so I did not plan to supply those.

What I prepared on my side:

- A phone with his number saved, since phone is how we keep in touch.
- A notebook for measurements, agreed dates, and anything he said about the timber.
- A tape measure and a pencil, so I could give him exact sizes.
- Photos of the boat and the damaged parts, taken before he came.
- A clear space at the boatyard so he could work on weekdays without moving things around.

What I expected him to bring:

- His own saws, chisels, planes, and clamps.
- Any power tools he needs for the job.
- Basic materials for fitting, unless we agreed otherwise on the call.

Tools and arrangements may have changed since 2023. Check the newer notes before relying on any of this.
