---
type: research
status: active
project: trusru-retrofit
area: boatyard
description: "Research about Velferk kiln controller."
---

# Velferk kiln controller tests

## Risks

The Velferk kiln controller is a black, battery-powered kiln controller that has been installed in the workshop since 2016. It belongs to the boatyard area. Because it runs on a battery and is that old, most of my worries come from the power side and from heat.

- **Battery fade.** After this many years the battery may not hold a charge through a long firing. If it drops out mid-cycle, the kiln could stop controlling temperature or hold at the wrong setting.
- **Heat near the case.** The controller sits in the workshop close to the kiln. The black case soaks up radiated heat, and the battery is the part most likely to suffer from that.
- **Silent failure.** I have no alarm that tells me the controller has lost power. I would only notice by checking the kiln by hand.
- **Dust and moisture.** Boatyard work puts sawdust and damp air into the workshop. Either can get into the connectors and cause bad contacts.
- **No backup control.** If the controller fails, nothing else limits the kiln temperature. I should not leave a firing unattended until I have a second safeguard.

I should repeat the tests after any battery change, because a new battery could behave differently from the one that has been in for years.

## Measurements

I tested the Velferk kiln controller in the workshop with the kiln idle and then during a normal firing. The aim was to find out how much the controller itself draws, since that decides how long the battery can last.

The measured power draw of Velferk kiln controller: 51.91 W.

What I noted from the tests:

- The reading was steady and did not jump around while the display was active.
- The case felt warm after a long run, more than I expected for a black unit that sits near the kiln.
- The display stayed readable throughout the firing.
- I did not time a full battery discharge. That is the next test to do.

Next steps:

- Run a full firing on battery alone and time how long it lasts.
- Check the battery terminals for corrosion.
- Test again after the battery is replaced, and write the result here.
