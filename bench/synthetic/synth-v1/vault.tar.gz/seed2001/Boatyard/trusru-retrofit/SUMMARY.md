---
type: summary
status: active
project: trusru-retrofit
area: boatyard
description: "Summary about Trusru retrofit."
---

# Summary of Trusru retrofit

## History

The Trusru retrofit is a boatyard project. Its goal is a retrofit, and it started in 2019, running as a summer job. The lead is the supplier contact, who has been the main person for questions about parts and timing since the beginning.

The first summer was mostly looking and measuring. We checked the hull, the old fittings and the space available below deck. The supplier contact came to the yard, walked round the boat with us and wrote down what could be reused and what had to be replaced. That visit set the shape of the whole job.

Over the following seasons the work moved in small steps. Each summer we had a short window when the boat was out of the water and the yard had room. We used those windows to strip old parts, clean up the areas underneath and test-fit the new items. Winters were spent waiting for deliveries and correcting the list of what was still missing.

Where things stand now, in summary:

- Stage: the project is past planning and into the fitting work, with the main strip-out finished.
- Done: old fittings removed, surfaces cleaned and prepared, and the trial fit of the main replacement parts completed.
- Open: a few small items are still missing from the supplier, and the final layout of the below-deck space has not been fixed.
- Open: the order of the remaining jobs depends on when those items arrive, so the schedule is still loose.
- Risk: the summer window is short, so any delay in delivery pushes work to the next year.

I keep this note as the quick view. Details of single jobs stay in my working notes, and I only update this summary when the stage changes or a point is closed.

## Next action

The next action is NX-7728. It is the item I have to chase with the supplier contact, because the remaining work cannot be ordered properly until it is settled. Once it is answered, I will update the list of missing items, check which jobs can go ahead first, and set a realistic order for the next summer window.

Until then I am not starting any new fitting work. It is better to wait a little than to open up another area of the boat and then have to leave it half done over the winter.

## Decisions

The go decision for the project was taken on 2020-05-01. Before that point we were only studying the boat and comparing options. After it, we committed to doing the retrofit and began ordering parts and booking yard time.

Other decisions that still hold:

- Reuse what is sound, and replace only what the supplier contact and I agree is worn or unsafe.
- Keep the supplier contact as the lead, so that parts, timing and questions go through one person.
- Do the work in the summer windows only, and do not rush a job just to finish it before the boat goes back in the water.
- Keep this summary short and move detail into the working notes.

One decision is still open: the final layout below deck. I will settle it once the missing items have arrived and I can see what fits.
