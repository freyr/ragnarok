---
type: note
status: active
project: trusru-retrofit
area: boatyard
description: "Note about Gundstios loft."
---

# Gundstios loft notes

## Observations

Gundstios loft is a loft in the boatyard area. It faces west, it is medium in size, it was built in 2018, and it sits below ground. That last point still strikes me as odd, because a loft is normally something you climb up to. This one you walk down into. I keep the name because everyone at the yard uses it, and I have stopped arguing with it.

The first thing I notice when I go in is the air. It is heavy and cool, and it smells of rope, old canvas and a little bit of tar. Even on a dry day the walls feel slightly damp to the hand. The stairs down are steep and the last step is higher than the others, so I always slow down there.

Because the room faces west, the only real light comes in the late afternoon, through the high window set near the ceiling at ground level outside. In the morning the room is dim and I need the lamps. By late afternoon a band of orange light crosses the far wall and lights up the shelves for about an hour. That light is lovely for checking the condition of sails and lines, but it also warms one corner of the room, and that corner dries out faster than the rest.

Things I have noticed over several visits:

- The back wall is always the dampest part of the room.
- The floor near the stairs stays dry, because air moves there.
- The west corner gets warm in the afternoon and cold again by night.
- Metal fittings left on the lower shelves show spots of rust sooner than those on upper shelves.
- Canvas stored in the open smells musty after a few weeks, while canvas in sealed bags stays fresh.
- Sound is dull and short in the room. Voices do not echo, which is pleasant for working.
- Mice have never been a problem, but spiders are plentiful.

I treat the room as a store that needs watching, not as a workshop. Anything I leave there has to survive damp conditions without me. That shapes almost every decision in these notes.

## Background

Gundstios loft was built in 2018 as part of the expansion of the boatyard area. The idea, as I understood it, was to use the slope of the ground at the western edge of the yard. Digging the room into the slope was cheaper than raising a new building, and it gave a space that stays at a fairly steady temperature. The below-ground floor was a deliberate choice, not an accident. The word "loft" comes from the earlier building that stood on the spot, which was a true loft with a ladder, and the name carried over to the new room.

The room is medium in size. It is big enough to hang a few sets of sails along one wall, to keep a rack of ropes and a few shelves of small gear, and to leave a clear path down the middle. It is not big enough for a full sail-laying table, so large repairs happen upstairs in the open workshop. I carry things down and up by hand, which limits what I store here to items I can lift.

Over the years the room has had three uses:

1. A sail store, which is its main purpose.
2. A place for spare lines, blocks and shackles.
3. A quiet spot to sort paperwork and logbooks, though I stopped doing that once I noticed the paper curling.

The orientation toward the west matters more than I expected for a room under the ground. The high window and the vent opening both face that way, so the weather from the west decides how the room behaves. When wind comes from the west, the vent pushes fresh air in and the room dries a little. When the wind is from the east, the air sits still and the room gets wetter. Rain from the west can also blow against the window frame and seep in, which I come back to under Problems.

I keep these notes because I forget details between seasons. A written record lets me compare one winter with the next, and it stops me repeating the same mistakes with the same stock.

## Measurements

I measure the room with a hand hygrometer, a tape and a small thermometer. The readings I trust most are taken in the middle of the room at about chest height, after the door has been closed for a few minutes. Readings near the back wall are always higher, so I note where I stood.

The most important number is the humidity. The measured humidity of Gundstios loft is 92.22 %. That is very high. At that level, mold can start on fabric and rust can form on bare metal within a short time, so the number is the reason for most of the work described below.

The table below sums up the fixed facts about the room together with the humidity reading.

| Property | Value |
|---|---|
| Kind | loft |
| Area | boatyard |
| Orientation | west |
| Size | medium |
| Year built | 2018 |
| Floor | below ground |
| Measured humidity | 92.22 % |

A few remarks on how I take the readings:

- I wait until the instrument settles. It drifts for a minute or two after I carry it in from outside.
- I never measure right after I have opened the door for a long time, because that skews the result.
- I take readings at the same time of day when I can, since the afternoon sun changes the west corner.
- I write down the weather as well. A dry day outside and a wet day outside give very different results in the room.
- I do not use the reading of a single visit to make a decision. I look at several in a row.

I have not tried to measure the exact floor area in a precise way. By pacing it, the room is about as long as two small boats lined up end to end, and a bit more than half as wide. That is enough for my purposes. If I ever need to buy a dehumidifier sized for the room, I will measure it properly with the tape and note the result here.

The ceiling height is low enough that I can touch it with a raised hand near the stairs, and a little higher in the middle. This matters for hanging sails, because the longest ones touch the floor if I hang them from the highest hooks.

## Checklist

This is the list I run through each time I go down. I do it in order, because skipping around makes me forget things.

Before going down:

- Take the hygrometer, the torch, a dry cloth and the sealed bags.
- Check that the stairs are clear and that nothing is blocking the door.
- Wear shoes with a good grip, because the lower steps can be slick.

When I enter:

1. Leave the door open for a moment and note the smell.
2. Switch on the lamps and look at the floor for water.
3. Look at the high window and the vent for blockage.
4. Take the humidity reading in the middle of the room.
5. Walk along the back wall and touch it to feel how damp it is.
6. Check each hanging sail for spots, smell and stiffness.
7. Check the rope rack for dark patches.
8. Look at the metal fittings and wipe off any rust that has started.
9. Check the sealed bags for condensation inside.
10. Write down what I found.

Before leaving:

- Make sure nothing sits directly on the floor.
- Put the cloth and the torch back where they belong.
- Close the vent partly if rain is expected from the west.
- Switch off the lamps and check the door latches.

I keep the checklist short on purpose. A long list gets ignored, and a short one gets used every time. The whole round takes me about twenty minutes if nothing is wrong. If something is wrong, it takes as long as it takes, and I add a note under Problems.

## Lessons

Most of what I know about the room I learned by getting it wrong first.

**Do not store fabric loose.** In the first year I hung sails on open hooks and assumed the cool air would keep them fine. Within a season several had gray spots. Now the sails I do not need often go into breathable bags, and the ones I use often hang near the stairs where the air moves.

**Do not trust a closed room.** A shut door does not make the room dry. It makes it stale. The humidity goes up when the air stands still, so a bit of airflow is better than perfect sealing.

**Raise everything off the floor.** Even a dry floor can hold moisture underneath. I put pallets and plastic crates under the heavy items. A gap of a hand's width under every shelf leg is enough.

**Watch the west corner.** The afternoon sun warms the corner, then the room cools at night and water collects on cold surfaces. Condensation forms there more than anywhere else. I keep sensitive items away from that corner.

**Rust starts quietly.** Fittings look fine until they do not. A light coat of oil on bare metal every few weeks saves a lot of work later.

**Paper does not belong here.** I tried keeping logbooks and manuals in the room. They curled and smelled in one winter. All paper now lives upstairs.

**Write everything down.** Memory is poor at remembering which month the damp was worse. The notes are better than I am.

**Small habits beat big projects.** I once planned to rebuild the whole ventilation system. In the end, opening the vent each visit and using sealed bags did most of the good for almost no cost.

## Safety

A room below ground has its own risks, and the high humidity adds more.

- **Stairs.** They are steep and can be slippery. I keep one hand on the rail and never carry something that blocks my view of my feet. The last step is taller than the rest, so I mark it with a strip of bright tape.
- **Lighting.** The room is dim in the morning. I never go in without a light, and I carry a torch in case the lamps fail.
- **Air quality.** Damp rooms can grow mold, and the spores are not good to breathe. I wear a simple dust mask when I handle fabric with visible mold, and I avoid shaking it indoors. I carry it outside first.
- **Electrical.** The lamps and any plug sockets are in a damp place. I keep cables off the floor, I never touch switches with wet hands, and I do not leave heaters or extension leads running unattended.
- **Lifting.** Everything goes up and down the stairs by hand, so I lift in small loads. A wet sail is much heavier than a dry one.
- **Chemicals.** Tar, oil and cleaning products are stored in closed containers on a high shelf. I do not mix products, and I open the door when I use them.
- **Working alone.** I tell someone at the yard when I am going down for a long time. A fall on the stairs with nobody around would be a bad day.
- **Fire.** Rope, canvas and oil burn well. I keep the extinguisher near the door and I do not smoke or use open flame in the room.

If I feel dizzy or the air smells wrong, I leave and open the door fully before returning.

## Problems

These are the problems I know about, with my current view of each.

**High humidity.** With the reading at 92.22 %, the room is simply too wet. It is the root of most other problems. Mold, rust and musty smells all follow from it.

**Mold on the back wall.** A dark film appears on the lower part of the back wall every few months. I wipe it with a cloth and mild cleaner, but it comes back. The back wall is against the slope, so I suspect moisture comes through from the soil behind it.

**Seepage at the window frame.** When rain comes hard from the west, a thin line of water runs down from the window frame. It does not flood, but it leaves a damp patch on the floor beneath. The seal around the frame is probably tired.

**Condensation in the west corner.** After warm afternoons and cold nights, beads of water form on the cold surfaces. Metal shelves drip.

**Musty smell in fabric.** Even clean sails pick up a smell after several weeks. Airing them upstairs for a day fixes it temporarily.

**Rust on small fittings.** Shackles and snaps rust fastest, especially if stored in a pile. I now hang them or keep them in lightly oiled bags.

**Stiff rope.** Natural fiber rope goes stiff and dark when kept damp. Synthetic rope copes better, so I move natural rope upstairs when I can.

**Spiders.** Not dangerous, just a nuisance. They build webs between the hooks. I brush them off at each visit.

**Poor drainage.** There is no floor drain. If water gets in, it has to be mopped out by hand. I have thought about this several times and never found a cheap answer.

## Maintenance

Maintenance is mostly small and regular. Large jobs are rare because the room is simple.

Each visit:

- Take the humidity reading and note it.
- Open the vent for the length of the visit, unless rain is blowing in.
- Brush down the webs and wipe any damp surfaces.
- Check the bags for moisture and swap any damp desiccant packs.

Each month:

- Wipe the back wall with a mild cleaner and let it dry with the door open.
- Rotate the hanging sails so no fold stays in one place too long.
- Oil bare metal fittings lightly and wipe off the extra.
- Check the lamps and the cable runs.

Each season:

- Take every sail upstairs, shake it out, and air it in dry weather.
- Inspect the window seal and clear leaves or dirt from the vent opening.
- Sweep the floor and check under the pallets for damp.
- Test the extinguisher gauge.
- Review the notes from the last few months and look for patterns.

Once a year:

- Look closely for cracks in the wall, especially near the corners and along the back wall.
- Decide whether any item should be removed from the room for good.
- Think again about proper moisture control and write down what I decide.

I try not to let maintenance turn into a lot of effort. If a task is too much trouble, I will skip it, so I keep each task small enough to finish before I get bored.

## Supplies

The supplies I keep for the room are cheap and simple.

- Breathable cotton bags for sails that I do not need often.
- Sealable plastic bags and boxes for small fittings and spare parts.
- Desiccant packs, which I dry out and reuse when they get full.
- Pallets and plastic crates to lift items off the floor.
- A light machine oil and a rag for metal parts.
- Mild cleaner and a stiff brush for wiping mold from walls.
- Dust masks for handling moldy fabric.
- Spare batteries for the torch and the hygrometer.
- Bright tape for marking the tall step.
- A small stock of rope ties, labels and a marker pen.
- A mop and a bucket, kept near the stairs for water on the floor.
- Spare bulbs for the lamps.

I keep the supplies on a high shelf near the door, because that is the driest place. I do not buy in bulk. The damp ruins stock that sits too long, so I buy small amounts and replace them when they run low.

One thing I still lack is a proper dehumidifier. I have looked at a few options, but I want to be sure the electricity supply is safe first, and I want to know the real floor area. I will leave that for now and revisit it in Ideas.

## Setup

The layout is simple and has changed only a little since the first year.

**Along the south wall** hang the sails. Each set has a numbered tag on the bag, but the number is only a local label, not a code worth recording. The hooks are set at different heights so the long sails do not touch the floor.

**Along the north wall** stands the rope rack. It is a wooden frame with pegs, set on pallets so that nothing touches the floor. Synthetic rope goes on the lower pegs. Natural rope has mostly been moved out.

**Under the window** at the west end sits a low bench. It is a handy spot for sorting small things in the afternoon light. I keep nothing sensitive in that corner.

**Near the stairs** I keep the supplies shelf, the extinguisher and the lamp switch. The air moves best there.

**Along the back wall** I leave a gap of a hand's width between the wall and the shelves, so air can pass and I can see the mold if it returns.

**In the middle** I keep a clear path. It is wide enough to carry a folded sail without brushing the walls.

The lighting is two lamps on the ceiling and one clip lamp I move around. The cables run along the ceiling, not the floor. The hygrometer sits on a hook in the middle of the room, so it gives a steady reading between visits, and I can check it with a quick look from the door.

If I rearrange, the rule is simple: nothing on the floor, nothing against the back wall, and the path stays clear.

## Open questions

There are several things I do not know yet.

- Where exactly does the moisture come from? Is it the soil behind the back wall, the window seal, or the air that comes in through the vent?
- Would sealing the vent in wet weather help or make things worse?
- Is a dehumidifier worth running in a room where the door is opened often?
- Could a drain or a small sump be added without digging up the floor?
- Does the west orientation help the room more than it harms it? The wind dries it, but the rain blows in.
- Would a coat of damp-proof paint on the back wall hold, or would it just peel?
- Is it worth moving the whole sail store upstairs, and leaving the loft for spare gear that tolerates damp?
- Is the high reading typical for all seasons, or does it fall in dry months? I need more readings through a full year.
- Does the room need a second vent on another wall to make a real draught?
- Who built the original drainage behind the wall, and is there any record of it?

I plan to ask the people who worked on the yard in 2018 whether they remember how the wall was finished. That might answer the first question.

## Tools

The tools I use are few and I know them well.

- **Hand hygrometer.** Gives the humidity reading. I check it against a second instrument now and then.
- **Small thermometer.** Used to compare the west corner with the middle of the room.
- **Tape measure.** For distances and for checking the gap behind the shelves.
- **Torch.** A bright one with a strap, so I can hold it in my teeth if I need both hands.
- **Stiff brush and cloth.** For walls, webs and rust.
- **Dust mask.** For mold.
- **Step stool.** For the high hooks and the window.
- **Screwdriver and small spanner.** For the hooks, the shelf brackets and the lamp fittings.
- **Notebook and pencil.** The pencil works when the paper is damp, and a pen does not.
- **Trolley.** A small hand trolley that I use on the flat but have to carry up the stairs.

I keep the tools in a plastic box near the door. After every visit I wipe them and put them back. A damp tool box is a rusty tool box, so I put a desiccant pack in it.

## References

These are the sources I rely on. They are all my own notes or things I have watched.

- My own readings in the notebook, kept in a binder upstairs, one page per visit.
- Photos I took of the back wall at different times of year, so I can compare the mold patterns.
- A sketch of the room layout that I drew when I first set up the shelves.
- Conversations with the older workers at the boatyard about how the room was dug and finished in 2018.
- The manufacturer's leaflets for the hygrometer and the lamps, which I keep upstairs with the other paper.
- General advice on storing sails and rope that I have gathered from other sailors over the years.

None of these is a formal source, and I do not treat them as authoritative. When one of them disagrees with what I see in the room, I trust the room.

## Ideas

Some things I might try, in rough order of how much I like them.

1. **A small dehumidifier on a stand.** With the humidity at 92.22 %, this is the most direct answer. I would need a safe power point, a way to empty the water, and a spot clear of the floor.
2. **A better window seal.** It is cheap and it addresses one known leak.
3. **Damp-proof treatment on the back wall.** I want to understand where the water comes from first, so I do not waste effort.
4. **A second vent.** A cross draught could help more than any machine, especially with the west wind.
5. **Plastic sheet behind the back shelves.** This would at least stop damp from reaching the stored items directly.
6. **A logging hygrometer.** One that records readings through the day would show me how the room changes at night and during the afternoon sun.
7. **Move the best sails upstairs.** If the room cannot be fixed cheaply, then storing the valuable fabric elsewhere is the simplest solution.
8. **A drain.** Hard to do, but it would solve the water-on-the-floor problem for good.
9. **A tidy label system.** Simple tags on the bags and shelves so I can find things quickly and spend less time down there.
10. **A yearly summary page.** At the end of each year, a short summary of the readings and what I changed, so I can see whether anything works.

For now, I will carry on with the small habits, take readings every visit, and decide on the bigger changes once I have a full year of data.
