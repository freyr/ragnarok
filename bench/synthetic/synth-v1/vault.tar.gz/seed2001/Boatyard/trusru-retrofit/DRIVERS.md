---
type: drivers
status: active
project: trusru-retrofit
area: boatyard
description: "Drivers about Trusru retrofit."
---

# Drivers of Trusru retrofit

## Observations

Trusru retrofit is a project in the boatyard area. The goal is retrofit. It started in 2019 and runs in the summer season. The lead is the supplier contact. These are the basic properties, and everything below hangs off them.

The drivers of this project are simple to state, even if they are harder to keep in view once work starts on the hull:

- The goal is a retrofit, not a rebuild. We keep what still works and replace what does not.
- The work happens in summer, because the yard is dry and the weather allows work outside.
- The lead is the supplier contact, so the pace of the project follows how fast parts and answers arrive.
- The money is fixed early and checked against every purchase.

What I notice after looking at this for a while is that the supplier contact being the lead shapes almost everything. When that person is available, decisions are quick. When they are away, we wait. I should plan for that instead of being annoyed by it each year.

The retrofit goal also sets a rule for judging ideas. If a proposal changes the character of the vessel more than the retrofit needs, it is probably out of scope. If it fixes a real fault or removes a repeated chore, it belongs.

## Schedule

The project started in 2019 and the season is summer. Summer is the only time the yard lets us work comfortably on open ground, so the schedule is built around it.

How I think about the timing:

- Early summer is for inspection, measuring, and confirming what the supplier can deliver.
- Midsummer is for the main fitting work, when days are longest and the surface dries fast.
- Late summer is for testing, small corrections, and tidying up records.

Because the lead is the supplier contact, I keep the schedule loose around deliveries. A fixed date for a fitting means nothing if the part has not arrived. So I schedule work in blocks that can be swapped around: if one part is late, another block can move forward.

I also leave a buffer at the end of the season. Every year something slips, and a buffer is cheaper than rushing the final checks. Work that cannot finish in one summer should stop at a safe, clean point so it can be picked up in the next one without redoing anything.

## Supplies

Supplies are the main constraint on this project, and they are the reason the supplier contact leads it. Nearly every step depends on getting the right item at the right time.

What I keep track of:

- What is needed for the next block of work, and what is only wanted for later.
- Which items the supplier holds in stock and which must be ordered.
- Which items are fragile, heavy, or awkward to store at the yard.
- Which items have a substitute if the first choice is not available.

My rule is to order the long-wait items first and the common items last. Common items can be found locally on short notice. Specialised items cannot. I also check each delivery on arrival, not on the day of fitting, so that wrong or damaged goods are found while there is still time to send them back.

Storage matters more than I expected. Items left in the open lose condition, and items stored badly get lost. I keep a simple list of what is on site and where it is kept.

## Budget

The budget of Trusru retrofit is 28149.32 EUR.

This amount is the ceiling, not a target to reach. I treat it as a fixed limit set at the start, and I compare each purchase against it before agreeing to anything.

How I use it:

- Supplies take the largest share, so they get the closest watching.
- I hold back part of the total as a reserve for surprises, since a retrofit on an older vessel always turns up hidden faults.
- I record each spend as it happens, not at the end of the month, so the running total is never a guess.
- If a choice would push the total near the limit, I stop and decide what else to cut before going on.

Success on money is simple: finish the agreed scope within the figure above, with the reserve still partly intact. Finishing exactly on the limit would feel like a near miss, not a win.

## Open questions

Some things are still unclear, and I want them written down so they do not get forgotten.

- How much of the reserve will the hidden faults really use? I will only know once the older sections are opened up.
- Can the supplier contact give firm delivery windows, or only rough ones? This affects how tightly I can plan the summer.
- Is there a second source for the specialised items, in case the main supplier fails to deliver?
- Which tasks can be done by me, and which need a qualified person at the yard?
- What should count as finished? I need a short written list so the end of the project is clear.

I plan to ask the supplier contact the first two questions at the start of the next season. The others I can settle by looking at the vessel and talking to the yard.

## Overview

Trusru retrofit is a boatyard project with the goal of retrofit. It began in 2019, runs in the summer season, and is led by the supplier contact.

Success is measured in four plain ways:

- The agreed scope is complete and works as intended.
- The spend stays within the budget given above.
- The work is finished within the summer season, or stopped at a clean point for the next one.
- The records are good enough that someone else could understand what was done and why.

The constraints are the season, the supply chain, and the fixed budget. Of these, the supply chain is the one I control least, and the one that most often sets the pace. That is why I plan around it rather than against it.

When I am unsure whether to do something, I come back to the goal. Retrofit means improving what is there with sensible, limited changes. If a task does not serve that, I leave it for another time.

## Problems

These are the problems I expect, based on how this kind of work usually goes.

- Late deliveries. The supplier contact leads the project, so any delay on their side becomes a delay for everyone.
- Wrong or damaged parts. These cost time even if they cost little money, because replacements take a while to arrive.
- Hidden faults. Older structure can look sound until it is opened, and then the scope grows.
- Weather. Summer is the best season, but a wet spell can still stop outdoor work for days.
- Budget creep. Small purchases add up, and without a running record they are easy to lose track of.
- Lost knowledge. If decisions are not written down, I forget the reasons for them by the next season.

For each one, my answer is mostly preparation: early orders, checks on arrival, a reserve in the budget, flexible work blocks, and regular note-keeping. None of this removes the problem, but it makes each one smaller and easier to handle.

## Tools

The tools for this project are mostly simple, because the real work is in coordination.

- A running spend list, updated at the time of each purchase, to compare against the budget.
- A supplies list showing what is ordered, what has arrived, and where it is stored.
- A short task list divided into blocks that can be reordered when deliveries change.
- A photo record of each stage, taken before and after the work, so I can see what changed.
- A contact log for the supplier contact, with dates of questions asked and answers received.

I keep these in the notes for the project and review them at the end of each work session. The review takes only a few minutes, and it catches most mistakes early. At the end of each summer I read through everything once and add a short summary of what worked and what did not, so the next season starts from a clear position.
