---
type: research
status: active
project: trusru-retrofit
area: boatyard
description: "Research about Milfu Misbrior."
---

# Milfu Misbrior tests

## Ideas

This note collects my research on Milfu Misbrior, an electrician who works in the boatyard. I have known him since 2010. His contact method is phone, and he is available on weekdays. I use the word "tests" in the title because most of what I know about him comes from small trial jobs and checks I set up over the years, not from one big project.

The main idea is to turn those scattered impressions into something I can reuse. When a wiring question comes up on the boat, I want to know quickly whether to call him, what to prepare before calling, and what to expect in return.

Ideas I want to try:

- Give him a small, well-defined job first whenever I need something new, and judge the result before handing over anything bigger.
- Keep a short written brief for every call, so the phone conversation is not wasted on basic questions.
- Photograph every panel and junction before and after he touches it.
- Ask him to label every circuit he changes, and check the labels myself afterward.
- Build a simple continuity and insulation check routine that I can run after any electrical job, whoever did it.
- Keep a running list of questions for him, and batch them into one weekday call instead of ringing him five times.

The point of all of these is not to distrust him. It is to make the working relationship repeatable and to leave a record that I can read months later when I have forgotten the details.

## Problems

The biggest practical problem is availability. Milfu is reachable on weekdays only, and he works at the boatyard, so he is often on a hull, in an engine space, or up a mast when I call. Weekend emergencies, such as a dead battery bank or a tripped breaker on a Saturday, have to wait or be handled by me alone.

Second, contact is by phone only. I cannot send him a photo and get a quick text answer. That means I have to describe faults in words, and I am not always good at that. Early on I would say "the lights flicker" and he would, reasonably, ask ten questions I could not answer.

Third, the boatyard environment itself causes problems:

- Damp and salt make intermittent faults hard to reproduce.
- Old wiring on older boats is often unlabeled, with mixed colors from several repairs.
- Shore power connections at the yard vary a lot from berth to berth.
- Space is tight, so even a simple test can take much longer than expected.

Fourth, I sometimes cannot tell whether a problem is the fault he was asked to fix or something new that appeared afterward. Without a baseline record, arguments about this are pointless. This is why I want before and after photos and a simple log.

A smaller problem is that my notes about early jobs are thin. I remember the outcomes but not the exact steps, so some of this research relies on memory.

## Supplies

When I ask Milfu to do something, the question of who supplies what matters. Over time I settled on a split. He brings his own test instruments and hand tools. I try to have the consumables ready so he does not lose time hunting for them.

Supplies I keep aboard for electrical work:

- Marine-grade tinned copper cable in a few common sizes
- Heat-shrink butt connectors with adhesive lining
- Ring terminals in several sizes
- Cable ties and adhesive-backed mounts
- Self-amalgamating tape
- Spare fuses and a small assortment of blade fuse types
- Cable labels and a marker that survives damp
- Contact cleaner and a small tin of corrosion inhibitor
- A few spare navigation light bulbs and an LED replacement or two
- Clean rags, gloves, and a headlamp

I do not record part numbers here on purpose. I buy by description and size, and I check the markings on the package at the time. If Milfu recommends a particular brand, I write it in the margin of the job log, not in this note.

One lesson on supplies: he prefers that I ask before buying anything specialized. Twice I bought the wrong connector type because I guessed, and the money was wasted.

## History

I met Milfu Misbrior in 2010. At that time I was new to the boatyard and had a boat with an electrical system nobody could explain. A neighbor at the yard pointed me to him as the electrician who actually finished jobs. That first contact was by phone, and phone has remained the contact method ever since.

The early years were mostly small repairs: a bilge pump circuit, a faulty switch panel, and some corroded terminals. Each job was small enough that I could judge it myself afterward, and that is how the idea of testing him with trial jobs came about. It was not planned as an experiment. It just worked out that way, and each success made me comfortable giving him a slightly larger task.

Over the following years the work grew. He helped with a rewire of part of the cabin lighting, a review of the battery charging arrangement, and a rethink of how the shore power inlet was protected. He also looked at the boat after a bad storm, when I was worried about water in the connections.

Looking back over the years since 2010, the pattern is consistent. He is careful, he explains what he did when asked, and he does not oversell. The main constant frustration has been scheduling, because he is only available on weekdays and the boatyard keeps him busy.

## Open questions

There are several things I still do not know about Milfu and how best to work with him.

- Does he take on jobs away from the boatyard, or only on boats at the yard? I have never asked directly.
- How far ahead does he need notice for a larger job? I have guessed, but never confirmed.
- Does he keep his own records of the work he did on my boat? If so, I would like to compare them with mine.
- Is there a way to get a faster answer on simple questions, short of a full call? Phone is the stated contact, but maybe he has a preferred time of day.
- What is his view on upgrading old wiring in stages versus all at once?
- Would he be willing to walk through the boat with me once, just to teach me where the weak points are?
- What does he do when a weekday emergency comes in while he is already booked?

I plan to ask these during a calm weekday call, not in the middle of a fault. The answers would shape how I plan future work, and I should record them here once I have them.

## Quotes

The one firm number I have for the current work is the quoted price of Milfu Misbrior: 593.07 EUR. That quote covers the job I discussed with him most recently, and I treat it as the reference point when I compare other offers or judge whether extra work has crept in.

Some things he has said over the years, paraphrased from memory since I did not write them down at the time:

- "Show me the fault before you show me the fix." He prefers to see the symptom himself.
- "Label it or it will bite you later." This is why I now insist on labels.
- "Salt finds every weak joint." His reason for adhesive-lined connectors.
- "Cheap cable is expensive twice." His view on buying wire.

These are not exact quotes, just the gist of what stuck with me. The price, however, is the exact figure he gave me by phone, and I wrote it down straight away so I would not misremember it.

When I compare this price against future quotes, I should check that they cover the same scope. A lower price that leaves out labeling or testing is not really lower.

## Safety

Electrical work on a boat has real dangers, and the boatyard adds to them. I write these points as reminders for myself, not as a replacement for Milfu's judgment.

- Always disconnect shore power and isolate the battery bank before anyone works on a circuit, and confirm with a meter that it is dead.
- Never assume a wire is dead because a switch is off. Boats often have unexpected feeds.
- Keep water, bilge spills and wet rags away from open panels.
- Wear eye protection when working overhead or in tight spaces.
- Keep a fire extinguisher within reach during any job that involves heat or sparks.
- Do not leave temporary wiring in place overnight.
- Tell someone at the yard when electrical work is happening, so nobody reconnects power by accident.
- Use a lock or a clear tag on the isolator while work is under way.

I also keep in mind that I am not the electrician. If I find something odd in the system, I note it and call him on a weekday rather than improvising a fix. The few times I tried a quick repair myself, I ended up creating more work for him.

Milfu himself is strict about safety, which is one of the main reasons I trust him with the boat.

## Checklist

This is the routine I run for any job involving him, from the first call to the final check.

Before the call:

- Write down the symptom in plain words.
- Note when it happens, how often, and what else is running.
- Take photos of the relevant panel or area.
- Check that the battery is charged and shore power is available.

During the call:

- Describe the symptom and read out my notes.
- Ask what he needs me to prepare.
- Agree on a day and a rough scope.
- Ask for a price, and write it down immediately.

On the day:

- Clear access to the work area.
- Have supplies and a headlamp ready.
- Stay nearby but do not hover.
- Ask him to label anything he changes.

After the job:

- Take after photos.
- Run my own continuity and function checks.
- Update the log and this note.
- Settle the payment and confirm the price matched the quote.

## Costs

Costs are the part of the research I want to track most carefully, because small jobs add up. The current quoted price is the one recorded in the quotes section, and I use it as the anchor for everything else here.

The table below sets out the kinds of cost I think about for any job with Milfu, and how I handle each.

| Cost type | How it arises | How I handle it |
|---|---|---|
| Labor | His time on the boat, quoted per job | Get the quote by phone and write it down |
| Materials | Cable, connectors, fuses | I supply common items; he advises on special ones |
| Callout | Extra visits if a fault is intermittent | Ask up front whether a return visit is included |
| Delay | Waiting for weekday availability | Plan ahead and batch questions |
| Rework | Fixing something that was done wrong | Use photos and logs to settle who is responsible |

A few notes on this table. Labor is the biggest item, and the quote usually covers it fully. Materials are cheaper if I buy them myself, but only when I buy the right ones. Delay has a cost too, even if it is not paid in money, because a boat without working systems cannot be used.

I do not keep a running total in this note. The job log holds individual amounts, and this note holds only the reference quote.

## References

These are the sources I rely on for this research. None are formal publications. They are my own records and conversations.

- My job log, where I write the date, symptom, action and result for every electrical task.
- Photos of panels and junctions, stored in the boat folder on my computer.
- Notes from phone calls with Milfu, written during or just after each call.
- Conversations with neighbors at the boatyard who have also used him.
- The manuals that came with the charger, the switch panel and the bilge pumps.
- My own earlier notes from the years since 2010, which are patchy but still useful.

When I add a new reference, I try to say what it is and why it matters. For example, a neighbor's comment about his punctuality is useful, but a photo of a labeled panel is better, because it is hard evidence.

I keep these references separate from my opinions. The opinions go in the observations and lessons sections. The references are just the raw material I can return to when I want to check a fact.

## Observations

Here is what I have noticed about how Milfu works, based on all the trial jobs and checks since 2010.

He starts by looking, not by touching. Before he opens a panel, he asks me to demonstrate the problem. This slows the first few minutes, but it often saves a lot of time later because he diagnoses before he repairs.

He explains things in plain language when asked, and he does not get annoyed by basic questions. He seems to enjoy showing why a connection failed, especially when corrosion is visible.

He is consistent about quality. Joints are crimped properly, cables are routed neatly, and he secures wiring so it does not chafe. When I later inspect his work, I rarely find anything I would want changed.

On timing, he arrives when he says he will, but jobs sometimes run long because the boat reveals more problems than expected. He tells me when that happens instead of quietly adding work.

He answers the phone on weekdays more often than not. When he cannot, he usually calls back the same day. Weekends are quiet, and I have learned not to expect anything.

One more observation: the boatyard setting shapes everything. Because he works there, he knows the local power supply quirks, which helps a lot.

## Tools

The tools matter for both his work and my own checking. Milfu brings his own professional instruments, and I keep a modest set aboard so I can verify results.

His tools, as far as I have seen:

- A good multimeter and a clamp meter
- An insulation tester for checking wiring condition
- Crimping tools for several connector types
- Wire strippers, cutters and a heat gun
- A torch and an inspection mirror for tight spaces

My own set:

- A basic multimeter with a continuity buzzer
- A simple mains tester for the shore power socket
- A small crimping tool and a cable cutter
- A headlamp and a spare battery pack
- A notebook, a pen that works when damp, and my phone for photos

For the notes themselves, I use Obsidian, with one note per person and one per major job. The log is plain text and easy to search. I do not use anything fancy, since the goal is to find answers fast on a weekday afternoon before I call him.

I have thought about buying an insulation tester of my own, but I would rather rely on his, since he knows how to read the results.

## Lessons

The main lesson from all of this is that a good relationship with a tradesperson is built through small, clear steps. Starting with minor jobs after meeting Milfu in 2010 let me learn how he works, and it let him learn how I work.

Other lessons I want to remember:

- Prepare before calling. A clear description saves time and money.
- Write the price down at once. Memory is unreliable, and the quote of 593.07 EUR is a good example of why I keep a record.
- Respect his weekday availability. Plan work around it instead of pressing for weekend help.
- Insist on labels and photos. They protect both of us.
- Do not buy specialized parts without asking him first.
- Run my own checks after any job. Trust, but verify.
- Keep notes while memories are fresh. Several early details are already lost.
- Ask questions when something is unclear. He welcomes them.

If I had to sum it up in one sentence, I would say that the best way to use an electrician is to make his job easy and to make the results easy to check. That approach has worked for the whole time I have known him.

## Setup

This section describes how I set up my own system so that work with Milfu goes smoothly.

First, the contact setup. He is reached by phone, so I keep his number saved in my phone and also written in the boat logbook, in case my phone is dead or lost. I note that he is available on weekdays and I schedule my calls during normal working hours, usually when I know he is likely to be between jobs.

Second, the boat setup. I keep the electrical panel accessible, with nothing stored in front of it. The battery isolator is clearly marked. Shore power cables are coiled and ready, and I know where the main breakers are.

Third, the documentation setup. I keep a folder with photos, a log, and these notes. Each new job gets an entry with the symptom, the quote, the work done and the result. The quote goes in first, as soon as I have it.

Fourth, the testing setup. After each job I run a short sequence: check each circuit, test the lights, run the pumps, and check the charger. Anything that fails goes straight back into the log.

Finally, the review habit. Every few months, I read through this note and update it with anything new about Milfu or the boatyard.
