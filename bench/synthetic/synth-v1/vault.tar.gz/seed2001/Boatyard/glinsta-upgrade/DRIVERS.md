---
type: drivers
status: active
project: glinsta-upgrade
area: boatyard
---

# Drivers of Glinsta upgrade

## Setup

Glinsta upgrade is a project in the boatyard area. The goal is an upgrade. It starts in 2026 and runs through the summer season. The lead is the supplier contact, so most of the questions about parts, delivery and fit go through that one person.

This note holds the drivers of the project: why I am doing it, what limits it, how much money is set aside, and how I will know it worked. I keep the working details in other notes and only point to them from here.

The short version of the reasoning: the yard equipment has been running on older arrangements, and the summer is the time when the work can be done without blocking the boats that need to be hauled out. The upgrade is meant to make the yard calmer to work in, not to add new features for their own sake.

Main drivers:

- Reliability: fewer stops in the middle of a job during the busy weeks.
- Predictability: the same result each time, so I can plan the day around it.
- Ease of maintenance: simple to service, with parts that the supplier can actually deliver.
- Cost control: stay inside the budget below and avoid surprise extras.

## References

These are the notes I lean on when I decide something about the project.

- [[Fothzin heat exchanger 2021]] is the record of the earlier work on the heat side. I use it to see what was done before, what lasted and what gave trouble. It is my main comparison for the upgrade.
- [[Stundglerk Keglu tests]] holds the test results I rely on when I judge whether a choice is good enough. If a result there disagrees with what the supplier tells me, I trust the test notes and ask the supplier again.

I also keep the supplier contact's messages together with the project, since that person leads it. When something is agreed by phone, I write it down the same day, because memory of a call goes soft fast.

## Checklist

Before I commit to any step of the upgrade, I go through this list.

- Confirm the goal is still an upgrade and not a repair in disguise.
- Check that the step fits inside the summer season, 2026, and does not clash with haul-out days.
- Ask the supplier contact for a written confirmation of what is delivered and when.
- Compare the plan with [[Fothzin heat exchanger 2021]] to see if an old lesson applies.
- Check the planned choice against [[Stundglerk Keglu tests]].
- Make sure there is a fallback if a delivery is late.
- Note who does the work and how long the boat or the equipment is out of use.
- Update the budget figure and the cost notes after each purchase.
- After the work, run it under normal load and write down what I saw.

Success is measured simply. The upgrade is done when the items above are ticked, the equipment runs through the rest of the season without an unplanned stop, and the money spent stays within the budget. If one of these fails, I write down why before I start the next step.

## Budget

The budget of Glinsta upgrade is 30689.93 EUR.

That is the ceiling for the whole project, not a target to reach. I do not plan to spend all of it. I would rather leave something unspent than stretch the work to use it up.

How I handle the money:

- Every purchase goes into the cost notes the day it happens.
- Anything that would push the total near the ceiling is stopped and discussed with the supplier contact first.
- If a part turns out to be unavailable, I look for a substitute before I accept a higher price.
- I keep a small reserve inside the budget for things I could not predict, instead of adding it on top.

## Costs

This section is where I track how the money behaves against the budget, without repeating every receipt.

The main cost groups are:

- Parts and materials from the supplier.
- Delivery and handling.
- Labour, if any of it is paid and not done by me.
- Small items such as fittings and consumables, which tend to add up unnoticed.

Constraints that affect cost are mostly about time. Work done in summer 2026 has to be finished before the yard gets busy again, so a late delivery can cost more than a higher price on a part that arrives on time. That is why I ask the supplier contact for dates in writing.

Success on the money side means two things: the total stays under the budget, and I can explain every large line afterwards. If I cannot explain a cost, I treat it as a mistake until I find out otherwise. When the project ends, I will compare the final spending with the budget and add a short note on what I would do differently next time.
