---
type: research
status: active
project: glinsta-upgrade
area: boatyard
description: "Research about Traerktin solar charger."
---

# Traerktin solar charger tests

## Safety

The Traerktin solar charger is a grey solar charger that sits in the loft above the boatyard workshop. It has been there since 2020. Its energy source is listed as battery, so even with the panels covered or disconnected the unit still holds stored charge. I treat it as live at all times.

Rules I follow before touching it:

- Disconnect the panel input first, then the battery output. Reconnect in the opposite order.
- Wear dry gloves and remove metal rings and watches. The loft is cramped and I have brushed against the frame before.
- Keep a dry-powder extinguisher by the loft hatch, not inside the loft where I could not reach it in a hurry.
- Never test alone. Someone should know I am up there and should be able to hear me.
- Do not work on it in damp weather. The roof lets in moisture along one edge, and the boatyard air is salty.
- Do not leave the charger running unattended on a test day. If something smells hot, I switch off and climb down.

The loft floor has loose boards. I laid a plank walkway to the charger so I do not step on the gaps. Lighting is poor, so I use a head torch.

## Risks

The main risks I see with this unit, in rough order of worry:

1. **Heat.** The loft gets very warm in summer. A charger working hard under a hot roof may run well beyond its comfortable temperature. I have not seen a failure, but the case does get too hot to hold a hand on.
2. **Battery wear.** The unit has been in service since 2020. Any battery that old loses capacity, and the readings I take may say more about age than about the design.
3. **Salt and damp.** The boatyard environment is hard on terminals. Green corrosion has appeared on a couple of connectors before, and I clean them when I see it.
4. **Wiring runs.** Cables go from the loft down to the workshop. They pass near a beam where they could chafe.
5. **Overloading.** If I connect too many devices during a test, I may push the unit past what it can supply. I add loads one at a time and stop if anything changes.
6. **Misleading measurements.** A single cloudy spell can skew a whole test. I try to note the sky conditions each time.

None of these has caused an injury or lasting damage so far. I still list them because the charger is in a place where a small fault could go unnoticed for a long time.

## Open questions

- How much of the capacity loss is down to age, and how much to the loft heat? I have no baseline from when it was new.
- Does the charger throttle its output when it gets hot, or does it just keep going until something trips?
- Is the grey case painted or its natural finish? If painted, a lighter colour might reflect some heat. I have not checked.
- Would moving the unit nearer the hatch, where there is more airflow, improve how it behaves in summer?
- Are the corroded connectors a sign of moisture inside the case, or only at the terminals?
- What is the real usable capacity of the battery on a day with full sun and a day with thin cloud?
- Is it worth fitting a small fan, or would that just bring in more salty air?
- Should I replace the battery, or is the measured behaviour still good enough for what the boatyard needs?

## Overview

The Traerktin solar charger is a device I use to keep batteries topped up for work in the boatyard. These are the properties as I have them recorded:

- Kind: solar charger
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2020
- Location: loft

The unit takes input from roof panels and stores it, then feeds the workshop circuits that run small tools, lights and a radio. It has been in the loft since 2020 and has mostly run without attention. This note collects the tests I have done on it so that I can compare them later and see how it ages.

The aim of these tests is practical. I want to know how much it really delivers, how it behaves when loaded, and whether the loft position is hurting it. I am not trying to produce a formal report. I am keeping notes so I do not have to rely on memory.

## Supplies

What I gather before a test session:

- A clamp meter that can read DC current, plus a spare multimeter for voltage checks
- A plug-in power meter for the loads I run from the workshop side
- Head torch and spare batteries for it
- Dry gloves
- A small wire brush and contact cleaner for the terminals
- Notebook and pencil (the phone is awkward in the loft and the screen is hard to read in bright light)
- A thermometer with a probe, to check the case and the air near it
- A set of known loads: a work lamp, a small drill charger and a soldering iron
- Cable ties and a roll of tape for tidying wires after the test
- A flask of tea, because a test day takes a few hours

I also carry the plank walkway up and lay it down before I start, and take it away afterwards so it does not become a trip hazard.

## Measurements

I took readings over several sessions. Most were at midday, when the panels get the most sun.

The measured power draw of Traerktin solar charger: 673.43 W. I recorded this with every test load connected at once, which is the heaviest I have run it. I do not run that combination as a routine, because it leaves little margin.

Other things I noted, without precise figures:

- With only the work lamp connected, the draw was low and steady, and the case stayed cool.
- Adding the drill charger raised the draw a clear step. The case began to warm after a while.
- The soldering iron caused the largest jump. When it cycled on and off, the reading swung visibly.
- Under the full load the case got hot enough that I did not keep my palm on it for long.
- On a bright day the panel side kept pace for much of the session. On a thin-cloud day the stored energy dropped faster.

I do not trust any single reading too much. The meter is a basic one, and the loft conditions change quickly. The pattern across sessions matters more than any one number.

## Setup

The charger is mounted on a shelf bracket against the south wall of the loft, a short distance from the hatch. A plank walkway runs to it. The panel cables come in through the roof on one side and the output cables leave down through a hole in the floor to the workshop.

How I prepare for a test:

1. Check the sky and note it down. I skip the test if rain is likely.
2. Put the extinguisher by the hatch and tell someone I am going up.
3. Lay the walkway and set up the torch.
4. Look over the terminals and clean any corrosion with the brush and contact cleaner.
5. Disconnect the loads in the workshop so I start from nothing.
6. Fit the clamp meter around the output lead and the multimeter across the terminals.
7. Place the thermometer probe against the case, with a second reading taken from the air a short way off.
8. Switch on one load at a time, waiting a few minutes between each, and write down the readings.
9. After the heaviest combination, switch the loads off in reverse order and let the unit settle.
10. Tidy the cables and check nothing has moved.

I try to keep the same order each time so the sessions can be compared.

## Observations

Over the sessions I have noticed a few things worth keeping.

The loft is the dominant factor. On warm afternoons the air around the charger is noticeably hotter than in the workshop below, and the charger seems to behave less steadily then. Early morning tests were calmer, with smaller swings in the readings.

The grey case holds heat. After a heavy test the case stays warm for a long while, even with the loads off. That suggests the heat is building up inside rather than just at the surface.

The terminals need regular care. Every time I opened things up, the connectors on the panel side showed more corrosion than the output side. I think the salt air enters through the roof gap where the panel cables pass.

The unit is still useful. For lamps, small chargers and a radio it manages without trouble. It is when I add heating tools that it starts to feel strained, and I would not rely on it for that.

Since it has been in place since 2020, I think the sensible next steps are to improve ventilation near it, seal the cable entry on the roof, and repeat the same tests in a few months to see whether the numbers drift. I will add those results here, under the same headings, so I can read the history in one place.
