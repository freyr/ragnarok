---
type: note
status: active
project: glinsta-upgrade
area: boatyard
description: "Note about Narfi loft."
---

# Narfi loft notes

## Tools

Narfi loft is a small loft in the boatyard area. It was built in 2018, it sits below ground, and its orientation is east. Because it is below ground, I treat it as a damp place and I bring the right kit each time I go down.

What I keep in the crate by the door:

- A hand torch with a spare set of batteries. The overhead light is weak, and the east orientation does not help much, since very little daylight reaches a space below ground.
- A hygrometer, which I use for every visit. It is a cheap model, but it has been steady enough for my purposes.
- A moisture meter with two pins, for checking timber, shelves and the lower parts of the walls.
- A folding tape measure and a pencil. I write numbers on the back of the door in pencil, then copy them to my notes later.
- A stiff brush and a dustpan for the floor. Grit from the boatyard gets in all the time.
- Cloth bags of silica gel. I swap them out when they feel heavy.
- A small fan that I run with the door open when the air feels thick.
- Gloves and a dust mask. I wear the mask whenever I move old rope or canvas.

A few habits I have kept:

1. Check the hygrometer before touching anything, since opening the door changes the air quickly.
2. Test the moisture meter on a dry piece of wood first, so I know it reads sensibly.
3. Put everything back in the crate. The loft is small, and loose tools take up space I need.

What I would like to add one day is a proper dehumidifier with a drain hose. For now, the fan and the silica gel are enough, but they only slow the problem down. A shelf rack with feet that lift stored items off the floor would also help.

## Measurements

The basic facts first. Narfi loft is small, built in 2018, in the boatyard area, facing east, and below ground. I do not have exact floor dimensions in these notes, so when I need them I measure with the tape and write them down fresh instead of trusting memory.

The measured humidity of Narfi loft: 72.38 %

That is high. For anything made of paper, cloth or untreated wood, I would want it lower. It fits what I expect from a below-ground space, where the walls stay cool and moisture collects. Being a small room, the humidity also changes fast whenever the door is open or a person stays inside for a while.

How I take readings:

- Leave the hygrometer in the middle of the room for a few minutes before reading it.
- Keep it away from the walls and the floor, where the air can differ.
- Take the reading before I start working, not after.
- Note whether the door has been shut or open, and whether the fan was running.

Things to compare next time:

- A reading near the floor against one at head height.
- A reading with the fan running against one without it.
- The moisture meter on the same shelf over several visits, to see whether the timber is drying or getting worse.

If the humidity stays this high, I will move the most sensitive items out of the loft and keep only rope, tins and other things that cope with damp. Everything else can wait upstairs until I have a dehumidifier installed.
