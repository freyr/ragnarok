---
type: summary
status: active
project: glinsta-upgrade
area: boatyard
description: "Summary about Glinsta upgrade."
---

# Summary of Glinsta upgrade

## Observations

Glinsta upgrade is a project in the boatyard area. Its goal is upgrade, it started in 2026, and it runs in the summer season. The lead is the supplier contact, so most of the practical questions go through that person rather than through me.

Where it stands now: the project is past the planning stage and into the work itself. The early groundwork is finished and the remaining jobs are smaller and more specific than they were at the start.

What is done:

- The first survey of the yard layout is complete, and the notes from it are filed in [[Glansun Riorkulbel log]].
- The water side of the plan is drawn up and agreed in principle. It sits in [[Vesrae pond plan]].
- The level reading hardware has been chosen. The reasoning for it is in [[Transto level sensor]].
- Logging for the upgrade has a written plan in [[Forknathpe data logger plan]], and the trial runs are being recorded in [[Nulur data logger log]].

Open points:

- The supplier contact still has to confirm what can be delivered during the summer season. Until that is settled I cannot fix the order of the remaining jobs.
- The logger trial results are not yet clear enough to say whether the current setup is good enough, or whether it needs changing.
- The pond plan has not been checked against the real water levels over a full working period, so I treat it as a draft that looks sound rather than a proven one.
- I have not written down who handles the handover to the yard crew. That should be sorted before the work is called finished.

Overall the project is moving at a steady pace. Nothing is blocked, but several things depend on one answer from the supplier contact, and that is the main risk to the schedule.

## Decisions

The go decision for Glinsta upgrade was made on 2024-10-06. That date is the point from which I count the project as approved, even though the work itself only started in 2026. The gap between the two was spent waiting on the supplier and on the yard calendar.

Other choices I have settled so far:

- Keep the supplier contact as lead for the whole project, so there is one person to ask.
- Use the sensor and logger choices already noted, and do not reopen them unless the trial data clearly shows a problem.
- Keep the pond plan as the base for the water side and only change it if the level checks give a good reason.
- Do the work in the summer season, when the yard is quieter and boats are less likely to be in the way.

I am deliberately not making any new decision on the logger setup until the trial log has more entries. Deciding early would just mean undoing it later.

## Next action

The next action for Glinsta upgrade is NX-0426. I should pick it up first, before anything else on the list, because the open questions above depend on its result. Once it is done I will update this summary, move finished items into the done list, and cross out whatever the supplier contact has answered. If the answer changes the order of the work, I will also revise the plan notes so they match.
