---
type: note
status: active
project: glinsta-upgrade
area: boatyard
description: "Note about Kioze loft."
---

# Kioze loft notes

## Costs

Kioze loft is a small loft on the ground level of the boatyard area. It was built in 1996 and faces south. Because it is small, most of my spending here goes on upkeep rather than on anything large. I keep the costs in rough groups so I can see where the money goes without a spreadsheet.

- Lease payments: the largest fixed cost, paid on the usual cycle. I check it against the lease reference each time.
- Heating and light: low, because the south orientation brings in daylight and warmth for much of the year.
- Repairs: small and irregular. Mostly paint, hinges, rope hooks, and the odd board that has gone soft.
- Storage fittings: shelves, hooks, and plastic bins. I buy these a few at a time.
- Cleaning supplies: cheap, but they add up over a season.

The building dates from 1996, so I expect the repair line to creep upward. I would rather spend a little every season than face one big bill. When I do a job, I write down what I paid and what it fixed, so I can tell later whether a repair held.

A rule I keep: if a repair costs more than half of what a replacement would, I stop and think about replacing instead. In a small space, replacing a fitting is usually easy.

## Schedule

I keep a simple rhythm for the loft. It is not strict, but it keeps small problems from turning into big ones.

- Weekly: walk through, check the floor for damp, make sure the door closes and latches properly.
- Monthly: look at the roof edge and the window seals, sweep out dust and sand, and check that nothing is stored against the walls where air should move.
- Each season: go through the stored gear, oil hinges and locks, and check the lease paperwork is filed.
- Yearly: do a full tidy, repaint any worn spots, and review this note.

Because the loft is at ground level in the boatyard area, it picks up grit, moisture, and the smell of varnish and tar from nearby work. I clean more often in the wet months. The south-facing side gets the most sun, so I do the window and paint checks in late summer, when I can see where the light has done damage.

I try to do the heavier jobs on dry days with the door open. A small room fills up with fumes quickly, so I never rush a painting job.

## Lessons

Over the years I have learned a few things about this place.

First, small spaces punish clutter. In a small loft, one box left in the wrong spot blocks the door or hides a damp patch. I now keep a clear path from the door to the back wall at all times.

Second, ground level means moisture. Anything stored directly on the floor eventually gets damp. I raise everything on pallets or shelves, even for a short stay.

Third, the south orientation is a benefit and a problem. The light is welcome, and the warmth helps things dry. But direct sun fades rope, cracks plastic, and makes the upper shelves hot. I keep delicate items on the shadier side and cover anything that should not be in sunlight.

Fourth, label everything. I have lost time hunting for a tool I knew was somewhere. Now each bin has a label on the front and one on the lid.

Fifth, write down the small repairs. A building from 1996 has had many patches, and I do not remember them all. A short log saves me from repeating a fix that already failed.

Last, talk to neighbours in the boatyard. They know which days are noisy, when deliveries arrive, and who is working with fumes. That knowledge has saved me more than once.

## Safety

The boatyard is a working area, so safety in the loft is mostly about what comes in from outside and what I store inside.

- Keep the door clear. A small ground-level loft has one main way out, so I never block it.
- Store paints, solvents, and fuel in closed containers, away from the sun-warmed south wall.
- Keep rags that hold oil or varnish in a metal bin with a lid, because they can heat up and catch fire.
- Check that a fire extinguisher is within reach and in date. I look at it during the monthly walk.
- Keep the floor dry and swept. Wet boards and loose sand make for bad footing.
- Lift heavy items from shelves at waist height, and keep the heaviest things low.
- Ventilate when working. I open the door and any window before I start a job that makes fumes.

I also keep a small first aid kit in the loft and replace anything used. If I am working alone in the boatyard, I tell someone where I am and roughly how long I will be.

Lighting matters too. The loft is small and can be dim on the shaded side, so I use a torch or a clamp light when I look into corners. Never work by guesswork in a space with tools and stored chemicals.

## Risks

These are the things I worry about, ranked roughly by how likely they are.

Damp is the most likely. Ground level, boatyard weather, and an older building add up to a steady threat. The result is rot, mould, and ruined stored gear. The answer is regular checks, raised storage, and airflow.

Sun damage comes next. The south orientation means long hours of direct light. Rope, fabric, plastic, and paint all suffer. The answer is covers, shade, and moving items around.

Fire is less likely but serious. Solvents, varnish, and dust in a small wooden space are a poor mix. I rely on safe storage, a clear exit, and an extinguisher.

Theft or break-in is a real possibility in a boatyard. Tools and fittings are easy to sell. I keep the lock in good order and avoid leaving valuable items in view.

Lease trouble is a quieter risk. If I lose track of the paperwork or miss a payment, I could lose access. I keep the reference in this note and the papers in one folder.

Age of the building is the background risk. Since 1996, the structure has had time to wear. I watch for sagging, loose fixings, and new gaps, and I act early.

## Admin

This section holds the paperwork details for the loft.

- Lease reference of Kioze loft: LR-108874
- Kind: loft
- Area: boatyard
- Orientation: south
- Size: small
- Year built: 1996
- Floor: ground level

I quote the lease reference whenever I contact anyone about the loft, whether it is about payment, repairs, or access. Having it in one place saves me from digging through papers.

My habits for the paperwork are simple. I keep the original lease document in a folder at home, with a photo copy stored separately. When a payment is made, I note it in my own log straight away. If anything changes, such as a new contact or a change in terms, I add a short line here and note when I heard about it.

Before the yearly review, I check that the reference in this note still matches the paperwork. If the lease is renewed, I will confirm whether the reference changed and update it right away.

## References

These are the sources I use when I need to check something about the loft. They are my own papers and habits, not outside websites.

- The lease document and its photo copy, kept in separate places.
- My repair log, where I record each fix, its cost, and whether it held.
- My seasonal checklist, which follows the schedule in this note.
- Notes from talks with neighbours in the boatyard about noise, deliveries, and hazards.
- Receipts for fittings, paint, and supplies, filed by season.

When I update this note, I try to base each change on something I have seen or recorded, not on memory alone. If a detail here looks wrong, I check the papers first, then walk through the loft and look for myself.
