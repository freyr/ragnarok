---
type: research
status: active
project: glathnel-automation
area: boatyard
---

# Krithdel solar charger tests

## History

The Krithdel solar charger is a black solar charger that I installed in 2020 in the loft above the boatyard workshop. It was one of the first pieces of equipment I put up there, and it has stayed in the same spot ever since. The boatyard area is where most of my notes on it belong, because the whole reason for buying it was to keep the yard's small tools and lamps alive without running a long cable from the main building.

When I first fitted it, I mounted it high on the loft wall, away from the sawdust and the damp that comes up from the slipway. The energy source is a battery, and that detail matters for how I test it. The charger does not feed directly from a panel during my tests. I run it from the battery bank, and I treat the panel side as a separate question that I looked at on other days.

Since 2020 I have moved the cable run once, tidied the fixings twice, and replaced a blown fuse. I have not replaced the unit itself. These notes collect the tests I ran to find out whether it is still doing its job after all this time, and whether the loft is a sensible place to keep it.

## Background

A solar charger of this kind takes power and regulates it so that a battery is charged without being damaged. In my setup the Krithdel sits in the loft, and the battery is its energy source. I wanted to know three practical things:

- How much power does the charger actually pull when it is working?
- Does the loft get too hot for it in summer?
- Is the black casing a problem for heat?

The black colour was a concern for me from the start. A dark casing in a loft under a roof can soak up warmth, and heat is the usual enemy of electronics. The loft does get stuffy on bright afternoons, so I wanted to check the casing temperature by hand and with a cheap probe thermometer, not just assume it was fine.

My method was simple and not scientific. I used a plug-in power meter on the supply line, a notebook, and a few visits at different times of day. I did not try to control the weather. I only wrote down what I saw, the time, and whether the yard was busy, since the amount of equipment on charge changes the load.

Things I looked for in each visit:

1. Whether the status light behaved normally.
2. Whether the casing felt more than warm.
3. Whether any cable or fixing had shifted.
4. What the meter reported once the reading settled.

I let each reading settle for a few minutes before writing it down, because the first figures after switching on jump around and are not useful.

## Measurements

The main result is the measured power draw of Krithdel solar charger: 850.57 W. I saw this figure once the reading had settled with the yard's usual set of tools connected. It was steady enough that I trust it as a working number, though I would expect it to move a little when fewer items are on charge.

Here is the log extract from the test visit, copied from my notebook into a file so I could keep it with the note:

```
test: krithdel loft check
location: loft
source: battery
casing: black
status light: steady
settled draw: 850.57 W
verdict: normal, no action
```

Other observations from the same visit:

- The status light stayed steady and did not flicker.
- The casing was warm but I could still rest my hand on it.
- The fixings on the loft wall were tight.
- The cable run had not moved since I last tidied it.

I compared this against what I remembered from earlier checks. The draw is in the range I would expect from the way the yard uses it, and nothing about it alarmed me. The black casing did not seem to cause trouble, although I would like to repeat the check on the hottest day of the year before I say that for certain.

What I plan to do next:

- Repeat the measurement with fewer tools on charge, to see how much the draw drops.
- Check the casing temperature again in high summer.
- Add a small shade board above the unit, in case the loft heat becomes an issue.
- Keep the log format above so that future results can be compared easily.

For now my conclusion is plain. The charger installed in 2020 still works, it sits safely in the loft, and its measured draw is 850.57 W under normal yard load. I will leave it where it is and keep testing it once or twice a year.
