---
type: drivers
status: active
project: glathnel-automation
area: boatyard
---

# Drivers of Glathnel automation

## Open questions

- Which of the older valves in the main shed can stay in service once the control layer goes in, and which have to be swapped before the first winter test?
- Does the lead, the plumber, want the pump control to be fully automatic, or should there always be a manual override at the panel? My current guess is that a manual override stays.
- How much of the existing wiring in the slipway building can be reused? Nobody has opened the junction boxes since before the project started in 2022.
- Who will check the system when the plumber is away? The yard has a small crew, and one person cannot be the only one who understands the setup.
- Is the winter season really the best time to run the whole job? It is quiet, but the cold makes some of the outdoor work slow.
- How do we record the readings? A paper log is simple, but a small digital log would make comparisons easier.

## Tools

The work is mostly pipe and control work, so the tool list is a mix of plumbing and light electrical gear.

- Pipe cutters, deburring tool and a press tool for the water lines
- Adjustable wrenches and a set of strap wrenches for the larger fittings
- Multimeter and a basic circuit tester for the control side
- Cable stripper, crimp tool and a heat gun for the shrink sleeves
- Cordless drill with a masonry bit set for the mounting points in the shed wall
- Spirit level and a tape measure
- Headtorch, since the pump corner is poorly lit
- Laptop for setting up the controller and keeping the log
- Small tarp and buckets for the drips that always happen

I keep the tools in one crate near the shed door so the plumber and I do not hunt for them. Anything borrowed gets written on the inside of the crate lid.

## Ideas

- Put a simple float switch in the sump so the bilge pump in the cradle area starts without anyone walking over.
- Add a pressure gauge at each end of the main line so slow leaks show up as a difference.
- Use a labelled colour scheme for the pipes: one colour for fresh water, one for wash-down, one for drain.
- Fit a small panel with three lamps, so the state of the system can be read from the doorway.
- Run a test loop at the start of every winter week, with the result noted in the log.
- Make a laminated one-page guide that hangs next to the panel.
- Think about a timer for the wash-down line, so it cannot be left running overnight.
- Later, maybe, add a temperature sensor to start a trickle of water when frost threatens the exposed pipes.

## References

- My own sketches of the pipe layout, kept in the project folder
- The plumber's handwritten notes from the first walk-through
- Manufacturer leaflets for the pumps and valves, filed in the blue binder
- The yard's older maintenance log, useful for knowing which parts failed before
- Notes from the neighbouring yard's visit, where they described their own automation attempt and what they would do differently
- The note on the yard's winter schedule, for matching the work to the slipway use

## Supplies

Things to buy or already on the shelf:

- Copper and plastic pipe in the sizes used by the main line
- Press fittings, elbows, tees and reducers
- Two spare valves of each size in use
- Control relays and a small enclosure for the panel
- Cable in two thicknesses, plus conduit and clips
- Waterproof junction boxes
- Thread tape and sealing paste
- Labels, cable ties and marker pens
- Rags, gloves and absorbent mats

I count the fittings before each work day and again after, so missing pieces show up early. The shelf by the shed door is for supplies only; loose tools go back in the crate.

## Background

Glathnel automation is a project in the boatyard area. Its goal is automation: take the manual, easy-to-forget routines around water, pumps and drainage and let a simple control layer handle them. The project started in 2022, and it runs in the winter season, when boats are hauled out and the yard has the most time for this sort of work. The lead is the plumber, who knows the pipes better than anyone else on site.

The reason for the project is plain. Over a few winters, the yard had several small incidents: a pump left on, a drain that was not opened in time, a wash-down line that dripped for days. None of them were disasters, but each cost time and some money, and each could be traced back to a step that depended on someone remembering it.

The aim is not to build something clever. The aim is a system that is dull and dependable, that the crew can understand in ten minutes, and that fails in a safe, visible way. If something has to be chosen between clever and clear, clear wins.

### Goal

The goal is automation of the repeating water and pump tasks in the boatyard. In practice that means three things:

1. The pumps start and stop on their own, based on levels and simple timers.
2. The main valves can be operated from one panel rather than by walking around the yard.
3. Faults show up as a lamp or a note, not as a puddle found the next morning.

### Constraints

- The work has to fit into the winter season, so it cannot block the slipway when a boat needs to be moved.
- The yard stays in use, so water cannot be off for long stretches. Planned shut-offs have to be short and announced.
- The existing pipes and wiring are old and uneven, so the design has to tolerate odd sizes and unknown routes.
- The lead is the plumber, so the plumbing side sets the pace. Control work follows once a section of pipe is finished and tested.
- Whatever is built must be repairable with ordinary parts and ordinary skills. No special tools, no obscure parts.
- Everything must be documented well enough that someone else could take over.
- The outdoor sections face cold and wet. Anything outside needs to be sealed and protected.

### How success is measured

I want measures that I can check without a debate.

- No pump is left running by mistake during a whole winter.
- No drain is found closed when it should have been open.
- The wash-down line has no unattended overnight flow.
- Each automated section passes its weekly test loop and the result is noted in the log.
- A second person can run the panel after one short walk-through.
- The number of small incidents in a winter drops compared with the winters before the project.
- Planned water shut-offs stay short and nobody is caught by surprise.

## Checklist

Before each work day:

- [ ] Check the plan for the section to be done
- [ ] Tell the crew which water lines will be off, and for how long
- [ ] Count supplies and fittings
- [ ] Put the tool crate near the work area
- [ ] Check the weather for any outdoor work
- [ ] Make sure the slipway is not needed

After each work day:

- [ ] Pressure test the finished section
- [ ] Look for drips after an hour and again the next morning
- [ ] Label new pipes and cables
- [ ] Update the sketches if anything differs from the plan
- [ ] Write the day's notes in the log
- [ ] Count supplies again and note what to reorder
- [ ] Clean the work area and return the tools to the crate

Before calling a section finished:

- [ ] Run the automatic cycle three times
- [ ] Test the manual override
- [ ] Test the fault lamp by creating a fault on purpose
- [ ] Show a second person how it works

## Budget

The budget of Glathnel automation: 39547.29 EUR

This is the total envelope for the whole project, covering pipe and fittings, valves, pumps, control parts, cable, enclosures and consumables. It does not include my own time, and it does not include the plumber's time as lead unless the yard decides otherwise.

How I handle it:

- Money is split across the sections of the work, with a small reserve held back for surprises. Old yards always have surprises.
- Each purchase is written down in the log on the day it is made, with what it was for.
- Items that are essential for safety or for the goal come first. Nice extras wait until the main work is finished and tested.
- If a section runs over, the overrun is taken from the reserve first, and then from the later optional items, not from testing or safety.
- At the end of each month in the season, I compare what has been spent with how much of the work is done.

## Schedule

The project runs in the winter season, and I plan it in stages so that each one leaves the yard working.

1. **Survey and drawing.** Walk the lines, open the boxes, and draw what is really there. Early in the season.
2. **Main line and valves.** Replace or repair the worst parts of the main line and fit the controlled valves. Short, announced shut-offs only.
3. **Pumps and level switches.** Fit the float switches and connect the pumps to the controller.
4. **Panel and lamps.** Build the panel, wire the lamps and the override.
5. **Wash-down timer and drains.** Add the timer on the wash-down line and automate the drain valves.
6. **Test period.** Run everything for a few weeks, with weekly test loops and notes.
7. **Handover.** Write up the guide, walk a second person through the system, and close the open questions.

Work happens on quiet days, mostly in the morning when the yard is empty. When a boat needs to move, the work stops and the area is cleared.

## Observations

- The older valves are stiff, and a few do not close fully. This matters more than expected, because an automatic valve cannot be helped by hand.
- The pump corner is damp even in dry weather, so any electrical part there needs good protection.
- The crew tends to leave hoses lying across the walkway, which hides leaks and trips people. A hose rack would help with both.
- Slow drips are often found only by their stains. A gauge at each end of the line would catch them sooner.
- The plumber works quickly once the plan is clear and slows when the plan keeps changing. Fixing the plan for each stage before starting saves time.
- Cold mornings make plastic fittings brittle, so those are best left to the afternoon.
- Labels fall off in the damp. Marker on tape does not last; engraved or laminated tags are better.

## Costs

Costs are the real spending as it happens, kept apart from the budget, which is the plan.

Main groups:

- **Pipe and fittings:** the largest group, because the old lines need parts in many sizes.
- **Valves:** the second largest, especially if the old ones have to be replaced rather than serviced.
- **Pumps and switches:** a moderate amount, mostly for float switches and a spare pump.
- **Control parts:** relays, enclosure, lamps and the controller itself.
- **Cable and conduit:** modest, but easy to under-count.
- **Consumables:** tape, paste, labels, ties, gloves and rags.
- **Hidden costs:** things I discover only when a wall is opened or a box is unscrewed.

Ways to keep costs down:

- Reuse good pipe and clamps where the pressure test allows it.
- Buy fittings in one order per stage rather than many small ones.
- Keep a short list of standard sizes, so spares fit more than one place.
- Return unused, unopened parts if the supplier allows it.

I check the total spent against the budget at each stage and write down the gap, even when it is small.

## Safety

- Isolate the water and the power before opening anything. Lock or tag the isolation point so nobody switches it back on.
- Test that electrical parts are dead with the tester, not by trusting the switch.
- Keep water and live wiring apart. All outdoor and damp-corner parts need sealed boxes and drip loops.
- Do not work alone on the pump corner or inside the sump. Another person should know where I am.
- Wear gloves and eye protection when cutting, pressing or drilling.
- Keep the floor dry, with mats under any open joint, because the shed floor gets slippery.
- Make sure a manual override exists for every automatic valve and pump, and that it is reachable.
- Never leave a half-finished section under pressure overnight.
- Tell the crew when a line is off and when it is back on.
- Keep the slipway clear of tools and hoses during work.

## Risks

- **Old parts fail during the work.** Seized valves or cracked pipe can turn a small job into a large one. Mitigation: survey first, keep spares of each size, and keep the reserve.
- **Budget overrun.** Hidden problems in old pipes and wiring will use up the reserve. Mitigation: track spending at each stage and put optional items last.
- **Cold weather delays.** Outdoor work slows in hard frost. Mitigation: keep indoor tasks ready as a fallback.
- **Single point of knowledge.** The plumber, as lead, knows the plan best. Mitigation: documentation and a second person trained on the panel.
- **Automation fails silently.** A stuck float switch could leave a pump running dry or not starting. Mitigation: fault lamps, a weekly test loop and a manual override.
- **Yard disruption.** Water off at the wrong time annoys the crew and delays boat work. Mitigation: announce shut-offs and keep them short.
- **Scope creep.** Ideas such as frost sensors are tempting. Mitigation: they go in the Ideas list and wait until the core goal is met.

## Problems

Problems found so far, and what I plan to do about each:

- **Stiff and leaking valves.** Plan: service what can be saved, replace the rest, and test each by closing it under pressure.
- **Unknown wiring routes.** Plan: trace and draw every cable during the survey, and label both ends.
- **Damp in the pump corner.** Plan: raise the electrical parts off the floor, use sealed boxes, and look for the source of the damp.
- **Poor lighting.** Plan: add a fixed lamp near the pumps, and use a headtorch meanwhile.
- **Labels coming off.** Plan: switch to tags that survive damp.
- **Hoses across the walkway.** Plan: fit a rack and ask the crew to use it.
- **No fixed log.** Plan: settle on one log, paper or digital, and keep to it for the whole winter.

When a problem is solved, I move it to the log with the date and what fixed it, and remove it from this list. Anything that cannot be solved within the budget or the season goes back to the open questions at the top.
