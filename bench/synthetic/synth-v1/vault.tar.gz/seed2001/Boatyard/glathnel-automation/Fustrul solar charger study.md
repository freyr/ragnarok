---
type: research
status: active
project: glathnel-automation
area: boatyard
---

# Fustrul solar charger study

## Safety

The Fustrul solar charger is a yellow solar charger that sits in the workshop at the boatyard. It was installed in 2021, and its only energy source is solar. I keep these notes for my own use, so they are practical and not a formal manual. Most of what is written here comes from watching the unit, working near it, and fixing small things over the years.

The first safety point is that the charger is always live while there is daylight. Because the energy source is solar, I cannot make it safe by pulling a plug from the wall. If the panels see light, the unit has power inside it. On a bright day the workshop windows let in enough light to wake it up, and a cloudy day only lowers the output, it does not remove it. So I treat every cable and terminal on it as live until I have covered the panels and checked with a meter.

The second point is the workshop itself. A boatyard workshop is not a clean room. There is sawdust, resin, solvent, and now and then a puddle of water on the floor. The charger is yellow, which helps me see it, but it also means it is easy to lean a ladder or a plank against it without noticing. I keep a clear strip of floor around it, and I do not store paint thinners or open containers on the shelf next to it.

Basic habits I follow every time:

- Cover the panels with an opaque sheet before touching any wiring.
- Check with a meter that there is no voltage on the terminals.
- Wear dry gloves and dry shoes, never work on it with wet hands.
- Keep metal tools away from the terminals, and do not lay a spanner across them.
- Tell someone else in the workshop that I am working on it.
- Put the cover back and remove the sheet only when the job is done.

When a battery is connected, a short circuit can produce heat very quickly, even from a small solar charger. I once saw a dropped wrench make a bright spark across two exposed lugs. Nobody was hurt, but since then I fit insulating caps on any terminal I leave open, even for a short break.

Ventilation matters as well. Batteries that are being charged can give off gas, and the workshop is shut tight in winter. I leave a vent open when a boat battery is on charge, and I keep naked flames and grinding sparks well away from that corner. Grinding is the one job in the workshop that throws sparks over a long distance, so I move the grinder to the other side of the shed when charging is under way.

## Risks

The main risk with this device is not one big failure, it is a slow build-up of small ones. A charger that lives in a boatyard workshop meets damp air, salt, dust and vibration every day. Any of these can wear down a connector or a seal, and the unit will often keep working while it is getting worse.

Here are the risks I track, roughly in order of how much they worry me:

- **Moisture and salt.** The air near the water carries salt. It creeps into the enclosure and corrodes the terminals. Corrosion raises resistance, and resistance makes heat.
- **Overcharging a battery.** If the regulation inside the charger drifts, a battery can be pushed too far. That shortens its life and can make it swell or leak.
- **Shading and uneven output.** A boat hull, a hung tarpaulin or a stack of timber can shade the panels. The output then swings up and down, which is hard on the electronics.
- **Physical knocks.** Trolleys, ladders and long pieces of timber move around the workshop. The yellow case is tough, but the panel surface and the cable glands are not.
- **Fire.** A hot, corroded connector near sawdust is a real fire risk. This is why I keep the area tidy.
- **Wrong use.** Someone connects a battery type the charger was not meant for, or reverses the leads in a hurry.

I do not think any of these is likely on a given day, but together they are why I do a regular visual check. The most useful check costs nothing: I look, I smell, and I touch the case after a long sunny spell to see if it is unusually hot. A warm case is normal. A case that is too hot to hold a hand on is not.

Another risk is that I get used to it. After years in the workshop the charger becomes part of the furniture, and I stop seeing it. When I wrote the first version of these notes in 2021, right after installation, I was very careful. Now I have to remind myself to be as careful as I was then.

There is also a link to other equipment. The workshop has a small heating loop, and I keep a record of it in [[Ziorzerk circulation pump log]]. When the pump was running badly, the workshop felt different, with more damp on the walls, and I noticed more condensation on the charger case in the same weeks. I do not claim the two are directly connected, but damp air is the shared factor, so I read both notes together when I look for the cause of a fault.

## Supplies

The charger needs very little in the way of consumables, which was one reason I chose a solar unit for the workshop. It has no fuel and no filter. What it needs is mostly small items to keep the connections healthy and the panel clean.

What I keep on the shelf for it:

- A soft cloth and clean fresh water for wiping the panel surface.
- A soft brush for dust and sawdust that settles on the panel.
- Contact cleaner suitable for electrical terminals.
- A small tub of terminal grease to slow corrosion.
- Insulating caps and a few cable ties.
- Spare fuses of the type fitted to the unit, kept in a labelled bag.
- Self-amalgamating tape for small cable repairs.
- A multimeter, which lives in the same drawer so I can always find it.
- Dry gloves and the opaque sheet I use to cover the panels.

I do not use strong solvents on the panel, because they can cloud the surface. Water and a soft cloth are enough. The panel needs wiping more often in the dusty months, when woodwork and sanding are going on, and less often in the wet season, when rain does some of the cleaning, though salt streaks then need attention.

For the battery side, I buy batteries separately and do not count them as supplies for the charger itself. What I do keep is a short list of what the charger should be connected to, written on a card fixed beside it. That card has saved me from a wrong connection more than once, since a person in a hurry will trust a label before a memory.

I restock when a bag or tub is nearly empty, not when it is completely gone. The cheapest items, such as the caps and ties, are the ones I always run out of first, so I buy them in larger amounts. Fuses are the item that I never want to be without, because a blown fuse with no spare means the charger sits idle until the next shop visit, and on a sunny day that is wasted energy.

## History

The Fustrul solar charger was installed in 2021 in the workshop at the boatyard. Before it, the workshop charged batteries from the mains with an old bench charger. That unit was noisy, ran hot and cost a steady amount in electricity, and the cable across the floor was a trip hazard. When the roof was repaired, it was a good moment to put in something that used the sun instead.

The first year was a learning year. I had to work out where the panels got the most light, and the answer was not the place I had first picked. The first position was shaded by a tall boat on the slip for much of the afternoon. I moved the mounting a short distance, and the daily charging improved a lot. I wrote that down because I knew I would forget it, and I was right.

Through 2022 and the years after, the routine settled. I checked the unit at the start of each season, cleaned the panel, and went over the terminals. The yellow case faded slightly in the sun, but it stayed sound. Over time I added the card by the unit listing what could be connected, and the habit of covering the panels before work.

Some notes on how the setup changed over time:

- In 2021 it was installed and tested with one battery at a time.
- After the first season the mounting was moved to reduce afternoon shade.
- Later I added insulating caps and the written card after a near miss with a spark.
- I started to keep a simple log of when the case felt too warm.
- Cleaning moved from "when I remember" to a fixed routine at the start of each season.

The charger has been a quiet success for the most part. It costs nothing to run, it does not make noise, and it does the job without anyone thinking about it. The extra effort has been in looking after the connections, which is the same job any equipment in a boatyard needs.

## Problems

The problems I have had are small, but they repeat, and that is why I write them down. None of them stopped the charger for long, but each one cost me an afternoon of guesswork before I saw the cause.

The most common problem is corrosion on the terminals. After a damp spell, a pale crust forms on the metal, and the charging gets weaker without any warning light. Cleaning with contact cleaner and applying a thin layer of terminal grease fixes it every time. I now do this at the start of each season, and again if the output looks low after a wet month.

The second problem is shade. Whenever a large boat is moved onto the slip, or a stack of planks is put near the window, the output drops. At first I thought the charger was faulty. Now I check what has changed in the workshop before I open anything. A moved tarpaulin has fooled me more than once.

Other problems I have met:

- Dust and sawdust on the panel, which cuts the output on dry, busy weeks.
- A loose cable gland that let in damp, found only because I saw a water mark inside.
- A blown fuse after a reversed connection, replaced from the spare bag.
- Condensation on the case during the weeks when the workshop was very damp, which I also saw when the heating loop was behaving badly, as noted in [[Ziorzerk circulation pump log]].
- A battery lead that had been pinched by a trolley wheel and needed re-taping.

When something looks wrong, my order of checking is always the same. First I look at the light: is the panel shaded or dirty? Second I look at the terminals for crust. Third I check the fuse with the meter, with the panels covered. Only after those three do I think about the unit itself. This order has found the cause nearly every time, and the unit itself has rarely been to blame.

The lesson from all of this is that the Fustrul solar charger is reliable as long as its surroundings are looked after. It is a yellow solar charger from 2021, working on solar energy in a workshop at a boatyard, and most of its troubles come from the place, not from the device. Keeping the area tidy, the panel clean and the terminals dry has done more for it than any repair.

## Maintenance

The Fustrul solar charger is a yellow solar charger that has been installed in the workshop since 2021. It belongs to the boatyard side of the business, and it runs only on solar energy. Because it has no other source, the care I give it is mostly about keeping light reaching the panel and keeping the connections sound.

What I do and why:

- Wipe the panel surface with a soft damp cloth. Dust from sanding and paint overspray in the workshop builds up quickly, and a thin film is enough to cut the output.
- Look at the cable runs for rubbing, cracked insulation or pinched spots. The workshop has a lot of movement, and a cable that was fine last season can get caught by a trolley.
- Check the terminals for a white or green crust. If I see any, I disconnect, clean it off with a dry brush, and reconnect firmly.
- Look at the yellow housing for cracks or loose screws. The colour makes it easy to spot against the grey wall, so I notice damage early.
- Make sure nothing has been stacked in front of the panel. Boxes and tarpaulins have a way of drifting into the light path.

I do not open the housing unless something is clearly wrong. The unit has run for years without that, and I would rather not disturb the seals. If I ever do open it, I should photograph the inside first so I can put everything back the same way.

One lesson from the years of use: problems with this charger have almost always been dirt or a loose connection, not the electronics. So I start with the simple things and only then suspect anything deeper.

## Setup

The charger was put in during 2021, and it sits in the workshop. The notes below describe how it is arranged, so that I can rebuild the arrangement if I ever have to move it or replace a part.

Basic facts, gathered in one place:

- Kind: solar charger
- Area: boatyard
- Colour: yellow
- Energy source: solar
- Year installed: 2021
- Location: workshop

Arrangement notes:

- The panel faces the brightest part of the workshop opening. I chose the position by watching where the light fell across several days, rather than guessing.
- The charger body is mounted off the floor, away from the place where water gets splashed during cleaning. Boatyard work is wet, and I wanted the electrical parts well clear of it.
- The cable from the panel to the charger is kept short and tied up along the wall with clips. Short runs lose less power and are less likely to be tugged.
- Whatever is charged from it plugs in at a bench height spot, so nobody has to reach over tools to use it.
- A small label near the unit says what it is for and who to ask before changing anything. It is useful when someone else is working in the workshop.

If I ever reinstall it, the order should be: fix the mount, place the panel, run the cable, connect the charger, then test with something small before trusting it with anything important.

## Schedule

I keep the schedule simple so that I actually follow it. The aim is regular, light attention rather than large occasional jobs.

Weekly:

- Glance at the panel and the housing as I pass. If it looks dusty, wipe it.
- Confirm that nothing is blocking the light.

Monthly:

- Do a proper wipe of the panel.
- Walk along the cable and feel for damage.
- Check that whatever is charging is actually getting power.

Each season:

- Inspect the terminals and clean them if needed.
- Check the mount and the clips for looseness.
- Review where the light falls, because the sun sits differently across the year and something new may now cast a shadow on the panel.

Once a year, near the anniversary of the installation in 2021, I sit down for a longer review. I read through these notes, check whether anything has changed in the workshop layout, and decide whether the charger still suits the way the boatyard works. That is also when I write down anything odd I noticed during the year.

Busy periods in the boatyard are the time I am most likely to skip the schedule, and they are also when the workshop is dustiest. So I treat the weekly glance as non-negotiable and let the monthly job slide only by a few days.

## Checklist

A short list I can run through in a few minutes. I tick items mentally, or on paper if I am doing the seasonal pass.

- [ ] Panel surface is clean and free of film
- [ ] Nothing is blocking the light
- [ ] Cables show no rubbing, cracks or pinching
- [ ] Clips and mount are tight
- [ ] Terminals are free of crust
- [ ] Yellow housing has no cracks and the screws are firm
- [ ] Unit is still clear of splashes and wet areas
- [ ] Connected device receives power
- [ ] Label near the unit is still readable
- [ ] Any oddity is written down in this note

If more than two of these fail at once, I stop and look for a common cause. Usually it is simply that the workshop has been through a messy stretch and the unit was neglected, not that several things broke independently.

Quick facts to confirm when I am unsure I am looking at the right thing: it is the yellow solar charger in the workshop, it runs on solar energy, it belongs to the boatyard, and it was installed in 2021.

## Ideas

Things I might try, none of them urgent. I write them down so I can decide later without having to remember them.

- Add a simple cover or shield above the panel's lower edge to keep overspray off while painting is happening nearby, but one that does not shade the panel itself.
- Keep a small cloth and brush in a labelled box right by the unit, so cleaning takes seconds and I have no excuse to skip it.
- Start a short log of how well the charger performs across the seasons. Even a few words each month, such as "bright, charged quickly" or "dull, slow", would show patterns over time.
- Test whether moving the panel a little would give more light in winter, when the sun is low and the workshop opening gets less of it.
- Think about a second, smaller solar charger for a different corner of the workshop, so that a single failure does not leave the bench without power.
- Photograph the installation from a few angles and keep the pictures with this note, as a reference for any future rebuild.
- Write a one-paragraph guide for other people who use the workshop, covering what to leave alone and who to ask if something looks wrong.

Of these, the cleaning box and the performance log are the cheapest and most likely to pay off. The rest I will revisit at the yearly review.

## Observations

The Fustrul solar charger is a yellow solar charger that sits in the workshop of the boatyard. It was installed in 2021, and its energy source is solar. These are the basic properties, and everything below is written against them.

What I have noticed over the time I have worked near it:

- The yellow casing is easy to spot from across the workshop, which helps when someone needs to find the unit quickly or check its status lights.
- Output follows the light. On bright days the charger works through the morning and holds a steady level into the afternoon. On heavy overcast days it still tops up small batteries but is slow with the larger ones.
- The workshop location means the unit is protected from rain and spray, but dust from sanding and grinding settles on the panel surface and the vents.
- The charger is used mostly for hand tool batteries, handheld lamps, and the radios that people carry around the yard.
- Boat work is seasonal, so the load changes. In the busy months the charger is rarely idle. In winter it often sits full for days.

I have not tried to measure everything. These are practical notes from watching it in normal use. Where I say something is better or worse, it is a judgement from daily work, not a test result.

A few patterns repeat. First, the charger does best when batteries are put on it early in the day. Second, it is easy to forget a battery on it overnight, and although the unit seems to cope with that, I would rather not rely on it. Third, the position near the workshop window gives good light, but anything left on the bench in front of the window can cast a shadow across the panel in the late afternoon.

Other small things worth writing down:

- The cables are long enough to reach the main bench but get in the way when the floor is being swept.
- Warm weather in summer makes the casing warm to the touch. It stays within what I would call normal, but I keep flammable materials away from it anyway.
- People new to the yard ask what the yellow box is. A label with simple instructions would save some explaining.

## References

I keep this section short because the study is mostly based on my own use rather than outside material. These are the sources I rely on, described in general terms.

- The paper instructions that came with the unit when it was installed in 2021. They cover basic setup, which batteries it suits, and what the indicator lights mean. I keep them in the workshop folder.
- My own logbook of charging days. It is a plain notebook with a line for each day: weather, what was charging, and whether anything went wrong.
- Chats with the other people who work in the workshop. Several of them noticed things I had missed, such as the shadow problem in the afternoon.
- Notes from the boatyard maintenance routine, which lists when the panel and vents should be cleaned.
- General reading about small solar systems, which helped me understand why output drops in cloud and heat. I did not copy any figures from it, since the Fustrul charger is a specific unit and general numbers may not fit.

When I add to this study, I will say whether the new information comes from my own watching or from someone else. That keeps it clear which parts are solid and which are only second-hand.

## Lessons

Several practical lessons came out of using the charger in the workshop since 2021.

- **Clean the panel regularly.** Dust from workshop jobs lowers the charging a lot more than I expected. A soft cloth is enough. Harsh cleaners are not needed and could damage the surface.
- **Keep the light path clear.** The charger is solar, so anything that shades it costs charging time. I now keep the bench in front of the window tidy.
- **Plan around the weather.** On gloomy days I charge the most important batteries first and leave the rest for a brighter day.
- **Rotate batteries.** Having a spare set means a flat battery goes on the charger while a full one is in use. Without a spare, the work stops while waiting.
- **Label the unit.** The yellow color is helpful, but a short written note on how to use it avoids mistakes by newcomers.
- **Check the cables.** Cables lying on the floor get stepped on and dragged. Hanging them on a hook when not in use keeps them in better shape.
- **Do not leave it unattended with odd batteries.** If a battery is old or swollen, it should not go on the charger at all.

Some lessons are about habit rather than equipment. A short check at the start and end of each working day, looking at the lights, the cables, and the panel, takes only a minute and catches most small problems before they grow.

One more point: the workshop is a good location for this device, because it is dry and close to where the batteries are used. If the unit were moved outdoors, it would likely get more sun but would also need more protection and more frequent checks. For a boatyard, where salt air and damp are common, I think the indoor spot has been the right decision.

## Costs

I do not have exact figures in these notes, so I will describe the costs in kind rather than in amounts.

- **Purchase and installation.** This was a one-time cost when the unit was put in the workshop in 2021. After that, the energy itself is free because the source is solar.
- **Cleaning supplies.** Almost nothing. A cloth and some clean water do the job.
- **Replacement cables or fittings.** Occasionally needed because of wear from the busy floor. These are small costs.
- **Batteries.** This is the largest ongoing cost connected to the charger, not the charger itself. Good care and sensible charging habits help the batteries last longer.
- **Time.** Checking, cleaning, and moving batteries take a little time each week. It is small but real.

Compared with using mains power for every charge, the saving on electricity is modest in a small workshop, but it is steady. The bigger benefit for me is that the charger works without anyone needing to plan for it, as long as there is daylight.

If the cost question comes up again, I would want to keep a simple record for a full year: what was repaired, what was replaced, and how much time was spent. That would give a fair picture instead of a guess.

## Overview

The Fustrul solar charger is a yellow solar charger in the workshop of the boatyard, installed in 2021 and powered by the sun. This study collects my practical notes about how it behaves, what I have learned from using it, and what it costs to keep going.

In short:

- It works well for small batteries and radios in daylight, and more slowly in poor weather.
- Dust and shade are the main things that reduce its usefulness.
- Regular cleaning, tidy cables, and a spare set of batteries make daily use smoother.
- Running costs are low, and most of the spending is on the batteries and small fittings.
- The workshop location suits it because it is dry and close to where work happens.

For my own use, the charger has been a reliable and low-effort part of the yard. The next step is to keep a yearly record so that future notes can rely on better evidence than memory.

## Tools

This section lists what I use when I work on the Fustrul solar charger. The charger is a yellow solar charger that sits in the workshop at the boatyard. It was installed in 2021 and runs on solar energy only, so most of the work is about keeping the panel clean, the wiring sound and the battery side healthy. I keep the tool list short because the workshop is crowded and I do not want to hunt for things.

### Basic hand tools

These are the tools I reach for on almost every visit.

- A small set of screwdrivers, both flat and cross-head. The terminal screws on the charger are small, and a screwdriver that is too big chews the heads.
- A pair of long-nosed pliers for holding wires while I tighten a terminal.
- A wire stripper and cutter. I use it only when a cable end has gone green and needs to be cut back to clean copper.
- A set of spanners for the mounting bolts on the panel bracket. The bolts are outdoors and have seen salt air, so they need a firm, steady hand.
- A small adjustable spanner as a backup.

### Measuring tools

A multimeter is the most important thing in the box. I use it to check the voltage at the panel, at the charger input and at the battery. I write down what I find in my own log so I can compare one visit with the next. I do not trust a single reading. I take it a few times and at different hours of the day, because the output of a solar panel moves with the light.

I also keep a clamp meter for checking current without opening the circuit. It saves me from disconnecting a cable just to see whether the charger is delivering anything. A simple thermometer is useful for the battery and the charger body on hot days, since the yellow case sits in a spot that gets warm in the afternoon.

### Cleaning supplies

- A soft brush for dust and dried salt on the panel.
- A bucket of fresh water. I never use anything harsh on the glass.
- A clean cloth and a squeegee for drying.
- A small tin of contact cleaner for terminals that show corrosion.
- A tube of grease for the terminals once they are clean and dry.

I do the cleaning early in the morning or late in the day. Cold water on a hot panel is a bad idea, and working in full sun makes the water dry in spots that leave marks.

### Safety gear

- Insulated gloves.
- Safety glasses, mostly for when I am cutting wire or working under the bracket.
- A torch, because the corner of the workshop where the charger is mounted is dim.
- A stable ladder with a rubber foot, for reaching the panel and the roof run of the cable.

Before I touch any wiring I cover the panel with an opaque sheet or disconnect it, because a panel in daylight is live even when nothing seems to be happening. I note this here because it is the easiest thing to forget when I am in a hurry.

### Recording tools

I keep a notebook and a pen in the toolbox, and I take photos of the wiring before I change anything. The photos have saved me more than once when a cable had to go back exactly where it came from. I label each photo with the date in the file name so I can find it later.

### Tool care

Salt air is hard on tools in a boatyard. After a job I wipe the metal tools with a dry cloth and put a thin film of oil on the spanners. The multimeter lives in a sealed box with a small bag of drying agent. I check its leads for cracks every few months, because a cracked lead gives false readings and I would rather find that out on the bench than on the ladder.

## Parts

This section is a record of the parts of the Fustrul solar charger and the spares I keep for it. The device is a solar charger in the boatyard area. It is yellow, was installed in 2021, runs on solar energy and is located in the workshop. Its serial number is SN-35436642. I wrote the serial number on the inside of the toolbox lid as well, so I do not need to climb up and read the plate on the unit when I order something.

### Main parts

- The solar panel. This is the part that does the real work. It is mounted on a bracket outside the workshop and faces the sun for most of the day. The glass collects dust and salt, which is the main reason output drops over time.
- The charge controller. It sits inside the yellow case and manages how the energy from the panel goes into the battery. If the controller fails, the battery can be overcharged or left empty, so I check it first when something looks wrong.
- The yellow housing. It protects the electronics from damp and dust. The seal around the lid is the weak spot, and I look at it each time I open the case.
- The cable run. This goes from the panel through the wall to the charger. It has a connector at the panel end and screw terminals at the charger end.
- The battery connection. The charger feeds a battery used for the tools in the workshop, and the leads on this side are thicker than the panel leads.
- The mounting bracket and its bolts, which hold the panel in position against wind.

### Wear points

Over the years I have found that the same few places give trouble.

- Terminals. Corrosion shows up as a white or green crust. Cleaning and a little grease keeps it away for a long time.
- Cable insulation. Where the cable bends near the wall entry, the outer sheath cracks first. I added a short length of protective tube there.
- Housing seal. The rubber hardens in the heat and no longer closes tightly. A hardened seal lets damp in, and damp is the start of most faults.
- Bracket bolts. They rust on the outside. I replace one at a time so the panel is never left loose.
- Connector at the panel. It takes the weather directly, so I check it for water inside whenever there has been a storm.

### Spares I keep

I do not keep a large stock, since the charger has been steady since 2021. What I do keep is small and cheap.

- A few spare bracket bolts with nuts and washers.
- A short length of panel cable with a matching connector.
- A spare seal strip for the housing lid.
- A few fuses of the type the charger uses.
- A set of cable ties and a roll of self-amalgamating tape.
- A tube of terminal grease and a tin of contact cleaner.

For anything bigger, such as a new controller or a new panel, I order against the serial number, SN-35436642, and check with the seller that the part fits this unit. I do not guess from the look of the case. Yellow cases look alike, and a part that is close in shape can still be wrong in its electrical rating.

### Replacement notes

When I replace a part I follow the same short routine. I cover or disconnect the panel, take a photo of the wiring, swap the one part, and test with the multimeter before I close the case. I then write down what I changed and the reason in my log. If a part is replaced, I keep the old one in a labelled bag for a while, in case the fault turns out to be somewhere else and I need to compare.

I also look at the parts list once a year, usually in spring, to see whether any spare has been used or has aged on the shelf. Rubber and tape do not last forever, even in a box, so I swap out the old strip and tape when they feel stiff or sticky.

### What to watch next

The first things I expect to need are the housing seal and the cable sheath near the wall entry, since both have shown early signs. The panel and the controller have not given any trouble, but they are the expensive parts, so I keep the serial number handy and keep the cleaning routine regular to make them last as long as possible.
