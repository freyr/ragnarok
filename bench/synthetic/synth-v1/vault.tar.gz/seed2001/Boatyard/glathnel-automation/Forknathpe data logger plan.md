---
type: plan
status: active
project: glathnel-automation
area: boatyard
---

# Forknathpe data logger plan

## Checklist

This is the plan for looking after the Forknathpe data logger, the green data logger that sits in the cellar and serves the boatyard. It has been running since 2022 and is powered from mains. I want a short routine I can follow without thinking, so the list below is what I actually do.

- Check that the green unit in the cellar is powered and that the mains lead is seated firmly in the wall socket.
- Look at the status light and write down what colour it shows and whether it is steady or blinking.
- Confirm the logger has recorded data during the last day and that nothing is missing in the middle.
- Wipe dust off the case and the vents with a dry cloth.
- Check the cellar floor and wall near the unit for damp, drips or a musty smell.
- Make a copy of the stored readings to a separate disk.
- Look at the software version and compare it with my note.
- Write the date and any problem in the logbook at the end.

I try to do the full list once a month, and a shorter version (power, light, data present) every week. If a step fails, I stop and deal with it before moving on, because a half-fixed logger is worse than one I know is broken.

## Observations

The logger is a simple box. It does one job: it collects readings from the boatyard and stores them until I fetch them. Since 2022 it has needed very little attention, which is the main reason I let the routine slip in the past.

Things I have noticed over time:

- The cellar is cooler than the rest of the building, and the unit seems happy with that. The case stays only slightly warm.
- Damp is the real enemy in that room. After long wet spells the wall behind the shelf gets clammy, and I do not want that anywhere near the vents.
- The green case is easy to spot, which helps when I come down in poor light. It also shows dust clearly, so I know when it needs wiping.
- Because it runs from mains, a power cut stops it. After a cut I have sometimes found a gap in the stored data, so I now look for gaps on purpose.
- The socket it uses is shared with a work lamp, and once the lamp was unplugged and the logger lead came out with it. I have since tied the lead with a cable strap.
- Fans and heaters in the cellar kick up dust, so the case gets dirtier in winter.

I should keep writing down what I see, even when it is boring. A run of dull entries makes it obvious when something changes.

## Software

The firmware version of the Forknathpe data logger is v5.39.633. That is the version I have recorded, and I compare against it during the monthly check.

My rules for software:

- Do not update the firmware in the middle of the busy boatyard season. Updates wait for a quiet week.
- Before any update, copy all stored readings to a separate disk and confirm the copy opens.
- Write the old version in the logbook before changing anything, so I can go back if needed.
- After an update, watch the logger for a full day and check that readings keep arriving.
- If the version on the unit differs from the one in this note and I did not change it, treat that as a warning and find out why.

I do not want to chase every new release. The logger works, and the aim is a steady record, not the newest features. I update only when there is a fault I actually suffer from or a fix that matters to how I use it.

Settings I keep a written copy of: the way the logger is named on my network, how often it records, and where it sends or stores data. If the unit ever has to be reset, those notes let me rebuild it in an afternoon.

## Background

The Forknathpe data logger was installed in 2022. It is a data logger of the kind used to gather readings for the boatyard, and it lives in the cellar, away from the weather and the noise of the yard. The case is green and the unit takes its energy from mains.

I chose the cellar because it is dry enough most of the time, out of the way, and close to a socket that is rarely switched off. The yard itself is a poor place for electronics: salt air, sawdust, paint fumes and the occasional knock from a trolley. Putting the logger below the yard keeps it safe from most of that, although the cellar brings its own damp.

Over the years the logger has become something I rely on without noticing. When the data is there, I forget about it. When a stretch is missing, I feel it straight away, because I cannot rebuild old readings after the fact. That is why this plan exists: not to add work, but to make sure the small checks happen before a gap does.

The plan also helps a future me, or anyone helping at the boatyard, to understand what the green box is, why it is in the cellar, and what to do if it goes quiet.

## Risks

The main risks, with what I do about each:

- **Power loss.** The logger runs from mains, so a cut or a loose plug stops it. I keep the lead strapped and check for gaps after any outage. A small backup supply would be worth considering one day.
- **Damp in the cellar.** Moisture can corrode contacts and shorten the life of the unit. I keep it off the floor, check the wall, and act early if the room feels wet.
- **Dust and blocked vents.** Dust holds heat and moisture. Regular wiping keeps the case cooler.
- **Lost data.** If the disk inside fails, the readings go with it. Regular copies to a separate disk are the answer.
- **Bad update.** A failed firmware change could leave the unit unusable. I update rarely, with a copy made first and the old version written down.
- **Forgetting.** The most likely failure is that I simply stop checking. The weekly and monthly routine, written in the checklist, is meant to stop that.
- **Age.** The unit has been running since 2022, so wear will show up eventually. Odd noises, a warm case or an unsteady light are signs to act on quickly.

If the logger stops completely, my first steps are to check the socket with another device, then the lead, then the status light, and only then to think about a reset.

## Tools

What I need for the routine is small and lives in a box near the cellar stairs:

- A dry, soft cloth for the case and vents.
- A small brush for dust in the vent slots.
- A torch, since the cellar light is weak behind the shelf.
- A spare mains lead and a cable strap.
- A separate disk or drive for copies of the readings.
- A laptop to read the logger and check its version.
- The logbook and a pen, kept dry in a plastic sleeve.
- A cheap moisture meter or simply a dry hand to test the wall.

I keep this plan, the written settings and the firmware note together, so that everything needed for a check, an update or a rebuild is in one place. When a tool wears out or goes missing I replace it straight away, because the routine only works if it is easy to start.
