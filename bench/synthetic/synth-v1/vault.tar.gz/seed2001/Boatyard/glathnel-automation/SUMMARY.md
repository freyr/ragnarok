---
type: summary
status: active
project: glathnel-automation
area: boatyard
description: "Summary about Glathnel automation."
---

# Summary of Glathnel automation

## Tools

Glathnel automation is a project in the boatyard area. Its goal is automation, it started in 2022, and it runs in the winter season. The lead is the plumber, who owns most of the practical choices and does the hands-on fitting work.

The stage right now is past the early trials and into steady, careful work. The basic idea has been proven, and what is left is making it reliable enough to trust in the yard without someone standing next to it.

What I use for this project, in plain terms:

- A set of small controllers that switch pumps and valves on and off. These are the core of the automation.
- Float and pressure sensors in the bilge and water lines, so the controllers know what is actually happening.
- A bench where the plumber assembles and checks each unit before it goes near a boat or a shed.
- A paper logbook beside the bench, where every test result and every change is written down the same day.
- A basic multimeter and a set of spare fittings, because most faults turn out to be a loose connection or a worn seal.

The test results are collected in [[Sogionvin Stilstur tests]]. I go back to that note whenever I need to check how a unit behaved under load or after a cold night. Winter is the right season for this work, since the yard is quiet and the units can be left running for days without anyone being in the way.

What is done so far: the bench setup works, the sensors are mounted and read correctly, and the controllers switch the pumps as intended in repeated runs. The wiring has been tidied and labelled. The logbook is up to date.

Open points: the sensors still give a few false readings when the water is very cold, the cable runs outdoors need better protection, and the spare parts list is not finished. None of these block the work, but each one needs closing before the units go into regular use.

## Decisions

The main decision so far is the go decision. It was made on 2024-07-26, after the tests showed that the controllers were dependable enough to continue. From that date the project moved from trying things out to building the real setup.

Other decisions worth remembering:

- Keep the system simple. Every added feature is one more thing that can fail in the cold, so only what the yard needs gets built.
- Let the plumber lead. The work is mostly about water, pipes and valves, so the person who knows them best makes the call when there is a disagreement.
- Test on the bench first. Nothing goes into the yard until it has run cleanly on the bench for a good stretch of time.
- Write everything down. If a change is not in the logbook, it did not happen as far as the project is concerned.
- Do the install work in winter, when boats are out of the water and the yard has room to move.

Things I decided against: a complicated remote control layer and any wireless link that depends on a signal that might drop. Manual override stays on every unit, so a person can always take over with a simple switch.

If the cold-weather sensor problem cannot be fixed with better mounting or shielding, I will revisit the choice of sensor. For now I treat it as a fixable issue rather than a reason to change direction.

## Next action

The next action is NX-1513. I will start it as soon as the current round of cold-weather checks is written up in the logbook and added to the test note. After that, the plumber and I will go through the open points one by one, close what can be closed, and decide what is left over for the following winter.
