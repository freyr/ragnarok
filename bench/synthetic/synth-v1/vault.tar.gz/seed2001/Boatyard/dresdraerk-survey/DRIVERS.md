---
type: drivers
status: active
project: dresdraerk-survey
area: boatyard
description: "Drivers about Dresdraerk survey."
---

# Drivers of Dresdraerk survey

## Safety

The Dresdraerk survey is a survey project in the boatyard area. It started in 2024, runs in the summer season, and the lead is my mentor. The goal is simple: survey the yard and the boats in it, and write down what we find so the next season starts from facts and not from memory.

Safety comes first because the boatyard is a hard place to work in summer. Hulls sit on cradles, floors are uneven, and heat builds up inside sheds and under covers. These are the rules I keep for the survey:

- Nobody works under a hull alone. The mentor or a second person must be within calling distance.
- Check cradle supports before measuring anything near a keel or a stern.
- Wear gloves and eye protection when opening panels or touching old wiring.
- Take water breaks in the afternoon, and stop in the hottest hours if the shed is stuffy.
- Keep the walkways clear of cables and tools.

For electrical checks I follow the older notes in [[Narfi loft notes]] and the earlier reading in [[Mindtres radio receiver 2020]]. When a radio set must be opened, the steps in [[Fesbis radio receiver handbook]] apply. Damp spaces need the [[Ruthglaend dehumidifier]] running before anyone touches equipment, and a hot engine room is checked for airflow around the [[Fothzin heat exchanger]] before work starts.

Success is measured in three ways: every planned area is covered, every finding has a written entry with a photo or a sketch, and nobody is hurt. A survey that covers everything but skips these rules counts as a failure.

## Budget

The budget of Dresdraerk survey is 27937.75 EUR. It covers the whole summer season of work, and I treat it as a hard ceiling, not a target.

The main costs I expect:

- Tools and measuring gear, mostly replacements for worn items.
- Protective equipment for me and for anyone who helps.
- Running the drying and ventilation equipment in damp sheds.
- Printing, labels and storage for the records.
- A small reserve for things that turn up halfway through.

I compare the spending against the earlier work in [[Sogionvin Stilstur tests 2023]] and [[Milfu Misbrior tests]], because those two show how much time a test round really takes. Both ran longer than planned, so I keep the reserve untouched until the middle of the season. If the reserve is gone by then, the mentor and I cut the scope and not the safety items.

Money is checked at the end of each month. I write the total spent so far in the project log and note any purchase that was not planned. Success on the budget side means finishing the survey with the full scope done and some of the reserve still left.

## Problems

These are the problems I can already see, and I want them written down before they become surprises.

- **Heat.** Summer work in sheds slows everything. Plan the indoor tasks for the morning.
- **Damp.** Old equipment can read wrongly when the air is wet. Dry the space first, then measure, and note the conditions in the entry.
- **Access.** Some boats are blocked in by others and cannot be reached for weeks. I need the yard manager to tell me when they will move.
- **Old records.** The notes from earlier years do not always agree. When [[Narfi loft notes]] and a newer reading differ, I record both and mark which one I trust.
- **Time.** The mentor leads the project but is not always on site. Questions pile up, so I keep a short list and bring it to each meeting.
- **Scope creep.** Every boat shows something extra to check. I only add it if it affects safety or the main goal.

If a problem stops the work for more than a few days, I tell the mentor the same day and write the decision in the project log.
