---
type: summary
status: active
project: dresdraerk-survey
area: boatyard
---

# Summary of Dresdraerk survey

## Problems

The Dresdraerk survey is a project in the boatyard area, and its goal is a survey. It started in 2024 and runs in the summer season. The lead is the mentor. At this stage the project is under way, and the groundwork is finished. Most of what is left is chasing loose ends.

The main problem is access. The yard is busy in summer, and the slipway and the sheds are in use for most of the day. A walk-through of the hulls takes much longer than planned because I have to wait for boats to be moved. I have only managed to look at part of the covered berths properly.

The second problem is records. The older notes on repairs and haul-outs are scattered across several notebooks, and some entries are hard to read. I cannot always tell which hull a note belongs to. Until I match these up, the survey table will have gaps, and I don't want to fill them with guesses.

The third problem is the mentor's time. The mentor leads the project and wants to review the findings before anything is written up. Reviews can only happen when the mentor is at the yard, and that is not every week. This slows down sign-off on each batch.

A smaller issue is the measuring gear. One of the tapes is stretched and gives different readings from the others. I have set it aside and I only use the steel tape now. Earlier readings taken with the stretched tape need to be checked again.

What is done so far:
- The scope of the survey is agreed.
- The list of hulls to be covered is written down.
- The first batch of the open-air hulls is measured and photographed.
- The recording sheet layout is settled.

Open points:
- Finish the covered berths.
- Re-check the readings taken with the stretched tape.
- Sort out the old repair notes by hull.
- Book a review slot with the mentor.

## Next action

The next action is NX-6517. I will deal with it before I go back to measuring, because the rest of the work depends on it. Once that is closed, I will use the first dry day to go through the covered berths with the steel tape and write the readings straight onto the recording sheet. After that I will ask the mentor for a review slot and bring the first batch with photos, so the review can happen in one visit rather than several.

## Decisions

The go decision for the Dresdraerk survey was made on 2023-12-08. The project then began in 2024, in the summer season, as planned.

Other decisions I have made along the way:
- The mentor stays as lead, and nothing is written up before the mentor has reviewed it.
- Only the steel tape is used from now on.
- Hulls are recorded one at a time, with the notes and photos filed together.
- Where an old record cannot be matched to a hull with confidence, it is marked as unknown and left out of the table.
