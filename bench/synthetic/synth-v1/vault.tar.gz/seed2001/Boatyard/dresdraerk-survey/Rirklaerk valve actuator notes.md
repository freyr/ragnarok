---
type: note
status: active
project: dresdraerk-survey
area: boatyard
---

# Rirklaerk valve actuator notes

## Observations

The Rirklaerk valve actuator is a yellow valve actuator that sits in the loft above the main boatyard shed. It was installed in 2015 and runs on solar power. The area it belongs to is the boatyard. I keep these notes so I do not have to rediscover the same things every season.

The first thing I notice each time I climb up is the color. Yellow paint is the easiest way to spot it among the grey pipework and the old timber beams. Dust gathers on the housing, and on a bright day the small solar panel on the roof slope above it keeps it going without any trouble. On dull winter days it moves more slowly, and I have learned to allow for that.

Here is a summary of the basic facts as I know them.

| Property | Value |
| --- | --- |
| Name | Rirklaerk valve actuator |
| Kind | valve actuator |
| Area | boatyard |
| Color | yellow |
| Energy source | solar |
| Year installed | 2015 |
| Location | loft |

General observations from regular visits:

- The actuator turns smoothly when the panel has had a few hours of light.
- A faint ticking comes from the gearbox just before it starts moving. This is normal and has been there for years.
- After a long run of cloudy days, the first movement is hesitant. It usually recovers by midday.
- The loft gets hot in summer. The housing is warm to the touch but never uncomfortable to hold for a few seconds.
- Condensation shows on the underside of the roof in autumn. I check that no drips land on the housing.
- Birds sometimes nest near the roof vent. I keep the cable run clear of twigs.

I also note how the valve it drives behaves. When the actuator closes the line, the flow in the yard pipe stops within a short time. When it opens, the pipe knocks once and then settles. If the knock becomes louder, I look at the valve stem first and the actuator second.

Over the years I have come to treat the actuator as reliable but not forgiving. It does what it is told, slowly, and it does not like being forced by hand while powered. Most of my problems turned out to be dirt, loose terminals, or a shaded panel rather than the unit itself.

### Daily behavior

On a normal working day the actuator is asked to move only a few times. In the morning the yard crew opens the line for washing down hulls. In the afternoon it is closed again. In between it stays still and draws almost nothing. I like this pattern because it keeps wear low.

### Seasonal behavior

Spring: the panel needs cleaning after winter. Pollen and grime reduce output.

Summer: plenty of power, but the loft heat is the main concern. I leave the loft hatch open on hot days.

Autumn: leaves and damp. I check the panel for leaf cover and the housing for moisture.

Winter: low light. I avoid asking for many moves in a short time, because the stored charge runs down.

## Software

The actuator has a small controller board with firmware. The firmware version of the Rirklaerk valve actuator is v6.26.817. I wrote this down after checking the label on the controller screen during a visit, and I want to compare it any time something changes.

Notes about how I treat the software:

- I do not update the firmware in the middle of the boating season. If something works, I leave it.
- Before any change I write down the current version in my log, take a photo of the screen, and note the position of the valve.
- After any change I run the open and close cycle three times and watch for odd stops.
- If the controller restarts on its own, I note the time of day and the weather. Restarts tend to happen after long dark spells, which points to power rather than a software fault.

The settings I care about are the travel limits, the speed, and the behavior on low power. I keep these in my head more than on paper, but the rule is simple: the travel limits must match the real end positions of the valve, with a little margin so the motor does not strain against the stops.

If the screen shows a blank or odd display, I first check the solar supply. Only after that do I think about the firmware. In my experience the software has not been the cause of a problem yet.

### What to record after a software visit

1. The firmware version shown on the screen.
2. The current valve position.
3. Whether the limits were touched.
4. Any messages shown.
5. The weather and light conditions that day.

## References

These are the things I look at when I need to remember how the actuator works. I keep them as plain descriptions because I do not want to depend on anything that might disappear.

- The paper manual kept in the tool cabinet in the boatyard office. It has a wiring sketch on the inside page.
- My own logbook, which is a school exercise book with a green cover. It records every visit to the loft.
- The pencil marks on the wall next to the actuator showing the open and closed positions of the valve handle.
- The label on the housing, which shows the make and basic ratings.
- Photos on my phone of the terminal block, taken after the last tidy-up of the wiring.
- A short sketch of the pipe layout in the yard, drawn on the back of an old tide table.

When I explain the setup to someone else, I start with the sketch of the pipes and then show the loft. People understand it faster that way.

I also keep a habit of checking the labels against the notes whenever I visit. If a label has faded, I rewrite it with a permanent marker straight away.

## Safety

The loft is not a comfortable place to work, so I take safety seriously.

- Use the fixed ladder only with someone else in the yard who knows I am up there.
- Wear shoes with a good grip. The boards near the hatch can be slippery when damp.
- Watch the head height near the roof beams. I have bumped it more than once.
- Do not put hands near the gear or the valve stem while the actuator may move. Because it is solar powered, it can start moving when the light returns, even if it was still a moment ago.
- Cover the panel with a cloth or disconnect the supply before any work on the terminals.
- Keep the area free of loose rope, cans, and paint rags. Solvent fumes and a warm loft are a bad mix.
- In hot weather, take water up and do not stay long.
- If the valve controls a line with water under pressure, close the upstream isolation valve before taking anything apart.
- Never override the actuator by hand while it is powered unless the manual says the clutch is released.

If something smells of burning, I stop, disconnect the supply, and leave the loft until I understand the cause. I do not try to be clever about electrical faults.

## Checklist

This is the list I run through at each visit.

1. Tell someone I am going into the loft.
2. Check the ladder and the hatch.
3. Look at the solar panel: clean, unshaded, no cracks.
4. Look at the cable run for chafing, nests, and damp.
5. Check the housing for cracks, rust, and water marks.
6. Check the terminals are tight and free of green corrosion.
7. Watch one full open and close cycle.
8. Compare the valve handle position with the pencil marks on the wall.
9. Read the firmware version on the screen and compare it with my log.
10. Listen for new noises.
11. Write the visit in the logbook.
12. Close the hatch and tell the person below I am down.

A shorter version for a quick look: panel, cable, one cycle, logbook.

## Schedule

I try to keep a simple rhythm so that nothing is forgotten.

- Every week during the season: a glance from the hatch to confirm the panel is clean and the actuator moved as expected.
- Every month: the full checklist above.
- Every spring: clean the panel, tighten the terminals, and grease the stem of the valve lightly.
- Every autumn: look for damp, leaks from the roof, and nests.
- Every winter: check on a bright day that the actuator still moves freely.
- Every few years: a deeper inspection of the gearbox and the seals, if the budget allows.

Since the unit was installed in 2015, this rhythm has kept it working without any serious breakdown. I do not trust my memory for dates, so I mark the visits in the logbook and on the yard wall calendar.

## Open questions

There are several things I still do not know.

- How long the internal battery or storage will last. It has been running since 2015, and I do not know its age limit.
- Whether the panel output has dropped noticeably over the years. I have no early measurements to compare.
- Whether the hesitant first movement after cloudy days is a sign of a weak store of energy or just the controller being careful.
- Whether it would be worth adding a small cover over the housing to cut down on dust.
- Whether the ticking in the gearbox is harmless forever or an early sign of wear.
- Who originally set the travel limits, and on what basis.
- Whether a second panel would help in winter.

I would like to answer these one at a time, starting with a simple record of panel output on a clear day.

## Lessons

Some things I have learned from keeping this actuator going.

- Most faults are simple. Dirt on the panel, a loose terminal, or a nest on the cable explains almost everything.
- Writing down the state before touching anything saves a lot of worry later.
- A solar device needs patience. If it is slow, check the light first.
- Do not force the valve by hand. It is slower and safer to wait for power or release the clutch properly.
- Yellow paint was a good choice. It makes the unit easy to find and easy to spot when something is wrong around it.
- Keep a dry cloth and a small brush in the loft so cleaning is never a chore.
- Do not change several things at once. Change one, test, then move on.
- A second person on site is worth more than any tool.

## Tools

What I bring up to the loft:

- A small torch and a head lamp.
- Screwdrivers, one flat and one cross-head, with insulated handles.
- A soft brush and a dry cloth for the panel and housing.
- A spray bottle with clean water and a drop of mild soap for the panel.
- A small tube of grease for the valve stem.
- A permanent marker for labels.
- A notebook and pencil.
- A phone for photos.
- A multimeter for checking the supply from the panel.
- Cable ties and a small pair of cutters.
- Work gloves.

I keep these in a small canvas bag hung by the loft ladder, so I do not have to gather them each time.

## Background

The Rirklaerk valve actuator was installed in 2015 in the loft of the boatyard building. The idea was to control a water line in the yard without running a long mains cable up to the loft. Solar power suited the place, because the roof gets good light and the actuator only moves a few times a day.

At the time, the yard was reorganized. New pipework went in, and the old hand valve that needed someone to walk across the yard was replaced by this one. Since then the work of opening and closing the line has been much easier, especially in wet weather.

The choice of yellow was practical. The yard uses color to mark equipment, and yellow is the color for items that should not be touched without thinking. Anyone who sees a yellow housing in the loft knows to ask first.

Over the years a few things around it have changed. The roof was repaired once, the panel was cleaned many times, and the cable run was tidied. The actuator itself has stayed in the same position and has done the same job throughout.

I think of it as a quiet piece of equipment. It does not need attention every day, but it rewards a regular look.

## Supplies

Things I try to keep in stock for the actuator:

- Light grease for the valve stem.
- Spare cable ties.
- A small roll of insulating tape.
- A few spare terminal screws.
- Cleaning cloths.
- Mild soap for the panel.
- Permanent markers.
- Spare labels and clear tape to cover them.
- Silica gel bags to put in the housing area if damp becomes a problem.
- A spare fuse of the type fitted to the controller, noted in the manual.

I check the stock every autumn and order what is missing before winter, when it is harder to get to the loft.

## Costs

I do not remember the exact original cost, and I will not guess here. What I can say is how the running costs feel.

- Energy: none, since it runs on solar power.
- Cleaning materials: very small.
- Grease and tape: a few small purchases each year.
- Labor: my own time, plus a helper for safety.
- Occasional repair: so far limited to cables and terminal parts.
- The largest likely future cost would be a new controller board or a replacement panel if either fails.

Because the unit has been in place since 2015 with little spending, I consider it good value. I keep any receipts in the same folder as the manual, so costs can be compared when the time comes to replace parts.

## Setup

A description of how things are arranged, so that I could rebuild it from the notes.

The actuator is mounted in the loft on a solid bracket close to the valve it drives. The yellow housing faces the hatch so I can read the screen from the ladder. A cable runs from the housing up along a beam to the solar panel on the roof slope. The cable is held with clips and has a slight loop at the bottom so water cannot run along it into the housing.

The panel faces the brightest part of the sky and is kept free of shade from the roof vent. The valve handle position is marked on the wall with pencil so I can see at a glance whether the actuator and the valve agree.

The controller is set with travel limits that match the real end positions, plus a small margin. The firmware is v6.26.817, as noted in the software section. The yard crew uses a simple local control to request open or close, and the actuator carries out the request when it has enough power.

If I ever needed to rebuild the setup, I would do it in this order:

1. Fix the bracket and mount the actuator.
2. Couple it to the valve stem by hand with the power off.
3. Run the cable and mount the panel.
4. Connect the supply with the panel covered, then uncover it.
5. Set the travel limits.
6. Run several open and close cycles.
7. Mark the positions on the wall.
8. Record everything in the logbook.

## Ideas

A few ideas I may try when time and money allow.

- Add a small shade or cover to keep dust and drips off the housing.
- Fit a simple indicator light, visible from the yard, that shows whether the valve is open or closed.
- Keep a simple chart of panel performance across the seasons.
- Add a second small panel to help during winter.
- Make a laminated one-page guide and hang it by the ladder for anyone who has to cover for me.
- Put a small desiccant pack near the housing during the damp months.
- Mark the ladder with yellow tape to match the actuator, so people link the two.
- Write a short note for the yard crew on what to do if the actuator seems slow on a dark day.

Most of these are cheap and small. The indicator light is the one I would do first, because it would save me many climbs into the loft.
