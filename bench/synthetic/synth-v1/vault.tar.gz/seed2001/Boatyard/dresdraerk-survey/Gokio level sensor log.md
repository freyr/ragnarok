---
type: log
status: active
project: dresdraerk-survey
area: boatyard
description: "Log about Gokio level sensor."
---

# Gokio level sensor log

## Safety

The Gokio level sensor is a black, solar-powered level sensor that sits in the barn at the boatyard. It was installed in 2022. Because it runs on solar power, there is no mains cable to worry about, but I still treat it with care.

Before I touch anything near the sensor, I check that nobody is working on the boats nearby. The barn floor gets wet and slippery, especially close to the tanks. I wear boots with a good grip and keep one hand free for support.

The sensor is mounted fairly high, so I use a stable stepladder and ask someone to hold it. I never lean out from the ladder to reach the unit. If the ladder does not sit flat on the floor, I do not climb it.

I keep fuel and solvents away from the sensor housing. Even though the unit is low power, I do not want sparks or hot parts near vapors. I also avoid cleaning it with strong chemicals, since they can damage the casing and the seal around the sensing part.

If I see any damage to the cable or the housing, I stop and mark the spot with tape. I do not try a quick fix while standing on a ladder. I come back with the right tools and a clear head.

## Maintenance

The main job is keeping the small solar panel clean. Dust from sanding and grinding in the boatyard settles on it quickly, and a dirty panel means the battery does not charge well. I wipe it with a soft damp cloth and dry it afterward.

The Gokio level sensor is black, so it gets hot in summer when the sun comes through the barn windows. I check that the casing is not warped and that the mounting screws are still tight. In winter I look for condensation inside the cover.

My routine checks are:

- Wipe the solar panel.
- Check the mounting and screws.
- Look at the cable for wear or chewing marks.
- Wipe the sensing part with a damp cloth.
- Compare the reading with a manual dip check.

I keep the checks short, so I actually do them. If I skip a month, I do the full list the next time instead of only part of it.

When the reading looks odd, the first thing I try is cleaning the sensing part. Dried residue or a thin film is the most common cause of a drifting value. Only after cleaning do I think about the battery or the electronics.

## Lessons

Over the years since 2022, a few things have become clear.

First, placement matters. The barn is a good location because it is sheltered, but the light is uneven. A sensor in the wrong corner can go days without good charging. I moved the panel angle once and the problem went away.

Second, never trust one reading. A single odd number is usually a splash, a wave in the tank, or someone bumping the container. I wait and look at several readings before deciding anything is wrong.

Third, dust is the real enemy in a boatyard, not rain. I used to worry about water, but the fine grit from sanding hurts more than anything else.

Fourth, write things down. Without this log I would not remember when I last cleaned the panel or why I changed something. A short line with the date and what I did saves a lot of guessing later.

Finally, a manual check is still worth doing. The sensor is handy, but a dip stick in the tank is a good way to confirm that the numbers make sense.

## Schedule

I keep a loose schedule that fits around the work in the boatyard.

- Weekly: look at the sensor reading and make sure it is updating.
- Monthly: wipe the solar panel and check the mounting.
- Every three months: clean the sensing part properly and compare with a manual check.
- Every spring: inspect the cable, the housing and the seals, and check the battery behavior after winter.
- Every autumn: clean the panel well before the short days begin, so the battery goes into winter in good shape.

If the yard is very busy with sanding or painting, I bring the panel cleaning forward. After a big job, I do a quick wipe even if it is not due.

I put a reminder in my calendar for the monthly and quarterly tasks. The weekly look is just a habit when I walk through the barn.

## Background

The Gokio level sensor is a level sensor that I installed in 2022 in the barn at the boatyard. It is black and powered by solar energy, which was the main reason I chose it. Running a power cable across the barn would have been awkward and messy, and the solar option meant I could put the unit where it was most useful.

The idea was simple. I wanted to know the level in a container without walking over every day to look. Before the sensor, I relied on memory and occasional checks, and sometimes I found a container nearly empty at a bad moment.

The barn is a practical place for it. It is dry for most of the year, it is out of the wind, and there is enough daylight through the windows to keep the small panel working. It is not perfect, but it has been good enough for several seasons.

Since 2022 the sensor has mostly just worked. The problems I had were nearly all about dust, light or a loose mount, not about the electronics. That is why my maintenance notes focus on cleaning and checking the basics.

I keep this log so that I can see how the device behaves over time and remember what I changed.

## Measurements

This section holds the numbers I record from the Gokio level sensor.

The flow rate of Gokio level sensor: 144.88 l/h.

I note the flow rate together with the conditions at the time, such as whether the sun was out, whether the yard was busy, and whether I had just cleaned the panel. A number without context is hard to use later.

When I take a measurement, I follow the same steps each time:

- Clean the sensing part first, so a film does not distort the value.
- Wait a few minutes after any movement near the container.
- Take the reading from the sensor.
- Check the level by hand with a dip stick.
- Write the result in the log with a short remark.

If the sensor value and my manual check disagree by a lot, I repeat both before I write anything down. I would rather have fewer entries that I trust than many that I doubt.

Over time I compare the entries to see whether the readings drift. So far the pattern has been steady, and the odd jumps have always had a simple cause, like a splash or a dirty panel.
