---
type: research
status: active
project: krirkfu-expansion
area: boatyard
description: "Research about Gilsiond heat exchanger."
---

# Gilsiond heat exchanger study

## Setup

This note collects what I know about the Gilsiond heat exchanger, a red heat exchanger that sits in the workshop at the boatyard. It was installed in 2021 and runs on battery power. I wrote it as a study because I keep rediscovering the same details every time I need to service the unit, and I would rather have them in one place.

The basic properties, so I do not have to look them up again:

- Kind: heat exchanger
- Area: boatyard
- Color: red
- Energy source: battery
- Year installed: 2021
- Location: workshop

The unit stands against the wall of the workshop, away from the door where the cold air comes in. The red casing makes it easy to spot, which turned out to be useful. Visitors and new helpers find it quickly, and nobody puts a pile of timber in front of it by accident, because it is so visible.

The job of the Gilsiond is to move heat between two fluid loops without mixing them. One loop carries warm water that comes from the workshop heating side. The other carries the cooler fluid that is used for the curing area and for the tool wash. The battery powers the circulation pumps and the small controller. Because it runs on battery, the unit does not depend on the workshop mains circuit. That was the main reason it was chosen in 2021: the mains supply in the workshop trips often when the large saws start up, and a heat exchanger that stops every time that happens is useless.

How I set it up when I first studied it:

1. I confirmed the unit was level on its base. A slight tilt changes how air collects in the upper passages.
2. I checked that both loops were filled and bled. Air in the loops was the first problem I met, and I describe it under Observations.
3. I charged the battery fully before any test run, so that a weak battery would not distort the results.
4. I let the unit run idle for a while to settle before I wrote anything down.
5. I marked the inlet and outlet pipes with tape so I could tell them apart in my photos and notes.

I keep the notes in a plain list by session. Each session has the conditions of the day, what I did, and what I saw. The conditions matter more than I expected. A cold morning in the workshop gives very different readings from a warm afternoon when the doors have been shut for hours.

## Tools

The tools I use for the Gilsiond are simple. I did not buy anything special for this study, and I would like to keep it that way.

**Measurement**

- A pair of clip-on surface thermometers for the inlet and outlet pipes of each loop. They are not precise, but they are consistent, and consistency is what I need when comparing days.
- A handheld infrared thermometer for quick checks of the casing and the pump housings. I use it to find hot spots, not to record values.
- A basic multimeter for the battery. I check the resting voltage before and after a run.
- A small bucket and a measuring jug to time how fast a known amount of fluid moves through a drain point.

**Maintenance**

- A set of spanners that fit the pipe unions. I keep them in a labelled tray beside the unit so they do not wander off.
- A soft brush and a rag for the outside of the casing. Dust and sawdust gather on the red paint and in the vents.
- A flushing hose with a fitting that matches the drain valve.
- Spare gasket rings in a sealed bag, taped to the inside of the cabinet door.
- Nitrile gloves and eye protection, because the fluid in one loop is not something I want on my skin.

**Recording**

- A paper notebook that lives in the workshop. Writing by hand while standing at the unit is faster than using a phone with dirty hands.
- A phone camera for photos of the gauges and the pipe markings. I copy the important readings into this knowledge base afterwards.
- A kitchen timer for the settling periods, so I do not guess.

One thing I learned about the tools: the clip-on thermometers must sit on bare metal, not over paint or insulation. My first set of readings was off for exactly that reason. I now scrape a small clean patch on each pipe and always clip to the same spot.

## Risks

I list the risks as I understand them, with what I do about each one. None of these is dramatic, but several can ruin a day or damage equipment.

**Battery**

The battery is the weak point of a battery-powered unit. If it runs flat during a cycle, the pumps stop and the loops stop moving heat. A flat battery in the middle of a cold night could let the cooler loop freeze in the workshop. I check the voltage at the start of every session and recharge when it is low. I also avoid leaving the unit on a partial charge for long stretches.

Batteries also get warm when charging. I keep the area around the unit clear and do not stack anything on top of the cabinet. Sawdust and offcuts near a charging battery are a fire concern, so I sweep around it regularly.

**Hot and cold fluid**

The warm loop can scald. I do not open unions while the loop is hot. I wait, check the pipe with the infrared thermometer, and only then loosen anything. Fluid under slight pressure can spray out of a union that is opened too fast, so I always loosen slowly and keep my face away.

**Trapped air**

Air in the loops lowers the heat transfer and makes the pumps noisy. It can also let the pumps run dry for short periods, which wears them out. After any work that opens a loop, I bleed it again.

**Leaks**

A slow leak at a union is easy to miss in a busy workshop. A wet floor near a unit with a battery is a bad combination. I wipe the floor beneath the unit dry at the start of a session, so any new drip is obvious.

**Workshop conditions**

The unit sits in the workshop of a boatyard, so it is exposed to dust, vapour from finishes, and the occasional splash. I keep solvents and finishing materials away from it. The vents must stay clear, or the controller overheats.

**My own mistakes**

The most likely failure is me. I once closed the wrong valve and ran the unit for a while with one loop blocked. Since then I have marked every valve with its position, open and closed, and I read the marks before starting.

## Observations

These are the things I noticed while working with the Gilsiond in the workshop. I wrote most of them down on the same day, so they reflect what I actually saw and not what I remembered later.

**Warm-up behavior**

After a cold start, the unit takes a noticeable time before the outlet temperature settles. The first stretch is the slowest. If I take readings too early, they look worse than the unit really performs. I now wait through the full settling period before I record anything.

**Noise**

A healthy run is a steady low hum from the pumps. A gurgling sound means air in the loops. A rattle usually means a loose fitting on the casing or something resting against the red panel. I found the rattle was almost always a tool left on top of the unit.

**Effect of the workshop**

The workshop air has a strong effect. When the large door is open, the outer pipes of the cooler loop lose heat to the room and the readings drift. When the door is closed and the heating is on, the numbers are calmer. For comparisons I try to work under similar door and heating conditions.

**Battery behavior**

The battery holds up well across a normal working day. Over a long run the voltage falls slowly and then more quickly near the end. I treat the fast drop as a signal to stop and recharge, not to push on. The battery was part of the 2021 installation, and I have noticed it recovers a little after a rest, which can fool me into thinking it has more left than it does.

**Cleanliness**

Dust builds up faster than I expected. A week of heavy sanding in the workshop leaves a visible film on the red casing and in the vents. When the vents are dusty, the controller casing runs warmer. A quick brush-down fixes it.

**Pattern across sessions**

- Warm-up always costs time, and rushing it spoils the notes.
- Air is the most common cause of poor results.
- Door position matters more than I thought.
- The unit is steady once it has settled and the loops are bled.

I still want to compare a few runs with the door shut against runs with it open, and write down the difference properly. For now, these observations are about habits and patterns, not precise measurements.

## References

These are the sources I rely on. All of them are my own papers and notes, since the unit is a one-off in my own workshop.

- The handover sheet from the 2021 installation, which describes the unit as a red heat exchanger powered by battery and placed in the workshop. I keep the paper copy in the cabinet beside the spare gasket rings.
- The manufacturer's short operating leaflet, which covers filling, bleeding and the order in which to open the valves.
- My own notebook from the workshop, with session-by-session conditions and readings.
- Photos of the gauges and the pipe markings, stored with the session notes in this knowledge base.
- A conversation with the person who fitted the unit, from which I took the advice about keeping the vents clear and charging the battery fully before long runs.
- My general notes on boatyard workshop safety, which cover fluids, batteries and housekeeping.

When these sources disagree, I trust my notebook first, because it records what the unit actually did, and the leaflet second. The handover sheet is useful for the basic facts about the unit, but it says little about day-to-day behavior.

## Costs

I am not recording any prices here. The sections above describe the unit, and its running costs are mostly small and are in the form of time and consumables rather than large purchases.

What costs me something in practice:

- **Time.** Each session needs setup, a settling period, and tidying up afterwards. The settling period is the longest part, and I cannot shorten it without making the notes useless.
- **Battery care.** Charging the battery regularly is a small but constant cost. A neglected battery is the likeliest route to an expensive replacement, so the care is worth the effort.
- **Consumables.** Gasket rings, cleaning rags, gloves and a little replacement fluid for the loops. I keep a small stock so that a leak does not stop work.
- **Cleaning.** Brushing off the dust in the workshop is cheap, but it has to be done often.
- **Mistakes.** A closed valve, a flat battery or an unbled loop can waste a whole day, and that is the cost I most want to avoid.

The 2021 installation was a one-time outlay, and since then the unit has needed attention more than money. I will treat the full cost picture as an open question and revisit it when I have enough sessions logged to say what a typical year of upkeep looks like.

## Supplies

The Gilsiond heat exchanger is a red, battery-powered unit in the workshop, and its supply needs are modest. I keep everything in one plastic crate on the shelf next to the unit so I do not have to hunt for things when something needs attention.

What the crate holds:

- Spare gaskets cut to fit the end plates. I cut them myself from sheet material when the old ones start to weep.
- A small tin of food-grade grease for the seals on the fittings.
- Two spare hose clamps in each size the unit uses.
- A bottle of mild descaling solution, diluted before use.
- Clean lint-free rags and a soft brush for the outside of the plates.
- A roll of thread tape for the threaded connections.
- Spare fuses for the battery lead.
- A pair of nitrile gloves and safety glasses.

The battery is the only part that needs real planning. The unit runs on battery, so I always keep one charged spare pack on the charger bench. When the one in use drops low, I swap it and put the empty one on charge. I do not leave a pack plugged in for days after it is full. I write the swap date on a strip of tape on the pack, so I can see which one has been in service longest.

For the coolant side I use plain clean water with a small amount of the inhibitor I use elsewhere in the boatyard. I mix a couple of litres at a time in a labelled jug and do not keep it for more than a season. If the jug looks cloudy or has anything floating in it, I throw it out and mix fresh.

I should note what I do not stock: no harsh acids, no chlorine-based cleaners, and no wire brushes. All of these can damage the plates or leave residue that causes trouble later.

## Maintenance

The exchanger has been in the workshop since 2021, so it has had several years of service. Maintenance is mostly a matter of regular looking and small adjustments, not big overhauls.

Routine checks, roughly in the order I do them:

1. Look at the outside for drips or damp patches, especially around the end plates and the hose connections.
2. Check the hose clamps by hand. They loosen a little over time because of vibration and temperature changes.
3. Look at the battery lead and terminals for dirt or green corrosion. Wipe clean if needed.
4. Run the unit for a few minutes and listen. A change in sound usually comes before a visible problem.
5. Feel the two sides of the exchanger. One side should be clearly warmer than the other while it works. If both feel the same, something is wrong with the flow.

Once a season I do a deeper clean. I disconnect the battery first, then drain both sides into a bucket. I flush the passages with the diluted descaling solution, leave it for a while, and flush again with clean water until the water runs clear. The red paint on the casing is fairly tough, but I avoid soaking it in the solution, and I rinse any splashes off right away.

After the clean I refit the gaskets if they look flattened or cracked, apply a thin film of grease to the seals, and tighten the fittings evenly. I do not overtighten, as this crushes the gaskets and can warp the plates.

A short log is useful here. I keep a page of dates and one-line notes: what I did, what I saw, and how the unit behaved afterwards. Looking back over it, the most common finding is scale slowly building up, which makes the unit less effective before it shows any other sign. Rinsing earlier than I think I need to has paid off.

Battery care is part of maintenance as well. I rotate the two packs, keep the terminals clean, and store the spare somewhere cool and dry. If a pack starts to run down noticeably faster than it used to, I replace it instead of nursing it along.

## Overview

The Gilsiond heat exchanger is a heat exchanger used in the boatyard area. It is red, runs on battery, and was installed in 2021. It sits in the workshop, where it moves heat from one fluid circuit to another without the two fluids mixing.

Summary of its properties:

- Kind: heat exchanger
- Area: boatyard
- Color: red
- Energy source: battery
- Year installed: 2021
- Location: workshop

The point of the device in the workshop is to take heat out of one circuit and pass it to the other, so that I can keep temperatures steady for work that is sensitive to them. Because it runs on battery, it does not depend on a fixed mains outlet and does not need a trailing cable across the floor. That was one of the main reasons for choosing this setup. The workshop is a busy place, and loose cables are an easy way to cause an accident.

The red casing is practical as well as cosmetic. It is easy to spot among the grey equipment and the wood and metal stock, so people notice it and do not lean things against it or put tools on top of it.

In this study I am looking at how the device has performed since it went in, what keeps it working well, and what I might change. The notes are my own working record, not a manual, so they focus on what I have seen at the bench instead of on theory.

How it behaves in daily use: it starts without fuss, settles within a few minutes, and runs quietly. The main limit is the battery. Longer jobs mean planning a swap, and I have learned to start long jobs only with a freshly charged pack.

## History

The exchanger was installed in the workshop in 2021. Before that, the boatyard managed with a simpler arrangement that relied on mains power and a longer run of pipe. It worked, but it was awkward, and it was in the way. When the workshop layout was changed, there was a chance to replace it with something self-contained, and the battery-powered exchanger was the result.

The first year was a settling-in period. I made a few adjustments to the hose routing so the pipes did not rub against the bench leg, and I moved the unit once to a spot with better airflow. After that it stayed where it is now.

Over the following years the pattern was steady:

- 2021: installed, hoses rerouted, first batch of notes started.
- 2022: first real descaling, after I noticed the output was less effective than at the start.
- 2023: gaskets replaced for the first time, and a second battery pack added so that swapping was easy.
- 2024: a quiet year, only routine checks and one clamp replaced.
- 2025: I started keeping a proper log page and moved the supplies into the crate.
- 2026: this study, to pull the scattered notes together.

Nothing dramatic has happened in its history. The most notable change was adding the second pack, which removed most of the frustration from longer jobs. Before that, a flat battery in the middle of a task meant waiting for a recharge.

Looking back, the decision to buy a battery-powered unit was a sound one for this workshop. The main cost is the extra attention the packs need, and I accept that as the price of having no cable across the floor.

## Safety

Safety around the exchanger comes down to three areas: heat, fluid, and the battery.

**Heat.** One circuit can get hot enough to burn skin. I do not touch the pipes or the end plates right after a long run. I give the unit time to cool, and I wear gloves when handling hoses that have been in use.

**Fluid.** Spills on a workshop floor are a slip risk, and water near electrical equipment is never a good mix. I keep a bucket and rags nearby when I open any connection. I drain the unit before taking fittings apart, since there is often more fluid inside than I expect. Any descaling solution is handled with gloves and glasses, and I never mix it with other cleaners.

**Battery.** I disconnect the battery before any cleaning or work on the fittings. I check the leads for damage before connecting a pack, and I never use a pack with a swollen case, a cracked housing, or a strange smell. Packs are charged on the bench, away from sawdust, paint and solvents, which are common in a boatyard workshop. I keep a suitable extinguisher within reach of the charger bench.

General habits that help:

- Keep the area around the exchanger clear of clutter.
- Do not stack anything on top of the unit.
- Tell anyone else using the workshop when the unit is running or has just been used.
- Never leave it running unattended for a long time on an unfamiliar setting.

If I see a leak while it is running, I switch it off, disconnect the battery, and deal with the leak only after things have cooled. I do not try to tighten fittings while the system is hot or under flow.

## Ideas

A few things I would like to try or look into, in rough order of how useful I think they would be:

- **A simple battery level indicator.** Right now I judge the battery by how long it has run. A small gauge on the lead would take away the guesswork and avoid surprise stops.
- **A drip tray under the unit.** A shallow tray would catch small leaks and make them visible early. It should be easy to lift out and wipe.
- **Better labelling.** Marking the hoses with tape, so that I always reconnect them the right way, would save time after the seasonal clean.
- **A cover for idle periods.** In a dusty workshop, a light cover would keep sawdust off the plates. It must be removed before running, so I would make it brightly coloured to avoid forgetting it.
- **A proper schedule on the wall.** The log page is useful, but a short checklist pinned beside the unit would make it easier to keep to the routine.
- **A second look at the location.** The unit sits well now, but if the workshop layout changes again, I would like to think about putting it closer to the work that needs it.
- **Test a different inhibitor.** I have used the same one for years. A comparison over a season, with notes on scale build-up, might show if there is something better.

None of these are urgent. The unit works well as it is, and the aim is mainly to make it easier to look after and to catch problems early. I will pick one or two for the next quiet period in the boatyard and write down what happens.

## Lessons

The Gilsiond heat exchanger is a red, battery-powered heat exchanger that has been installed in the workshop of the boatyard since 2021. After several seasons of using it, these are the lessons I would write down for anyone, including my future self, who has to look after it.

**Battery behaviour matters more than I expected.** Because the unit runs on a battery and not on mains power, its performance depends on how well the battery is kept. In the first year I treated it like a mains device and left it running through long idle stretches. That drained the battery to the point where the control circuit behaved oddly. Now I switch it off fully at the end of a work block and top the battery up before any long job.

**The workshop is a harsh place for a precise device.** Dust from sanding hulls and fine fibreglass particles settle on everything. The red casing hides dirt well, which is a problem, because it looks clean when it is not. I have learned to wipe it down on a fixed rhythm and not judge by eye. The fins and the intake need a soft brush, not compressed air, since air pushes the dust deeper into the core.

**Small adjustments beat big repairs.** Most of the trouble I have had came from drift, not from breakage. A slight shift in the setting changed how the unit behaved during a job. Catching the drift early and correcting it was always faster than waiting for a real fault. This is why I keep the adjustment routine below written out in full.

**Keep a simple log.** A few lines after each session are enough: what the job was, how long the unit ran, and whether anything felt off. When something goes wrong, the log usually shows the pattern within a minute. Without it I was guessing from memory, and my memory of the boatyard is not good enough for that.

**Do not move it casually.** The unit is not heavy, but its connections and mounts are sensitive to being knocked. Every time I moved it to another bench in the workshop, I had to recheck the setting afterwards. Now it stays where it is, and if I must move it, I plan time for the check.

**Write down what the manual does not say.** Many of the practical details came from trial and error. The things I would not have guessed are:

- The unit prefers a steady, slow warm-up to a sudden full load.
- A cold workshop in winter makes the battery weaker, so the run time drops noticeably.
- Loose hose clamps show up first as a small change in behaviour, long before any visible leak.
- Keeping the area around the unit clear of loose rags avoids blocked airflow.

## Open questions

There are several things about the Gilsiond heat exchanger that I still cannot answer with confidence. I am listing them so that I can come back to them when I have time and the right tools.

1. **How long will the battery really last?** The battery has been in service since the unit was installed in 2021. Its capacity has dropped, but I do not know whether the decline is steady or whether it will fall off sharply at some point. I need a proper capacity check, done the same way each time, to see the trend.

2. **Is the drift caused by temperature, vibration, or ageing?** I have a feeling that the setting moves more in the cold months, but I have not separated this from the effect of the noisy machines nearby. A clean test would need me to hold one factor steady while changing another, which is hard in a working boatyard.

3. **Would a different location in the workshop be better?** The current spot is convenient, but it is close to the sanding area. Moving it farther away would reduce dust, yet it would mean longer hose runs. I do not know whether the extra length would cost more efficiency than the cleaner air would save.

4. **Is the red casing coating worth protecting?** The paint is starting to wear at the corners. It is only cosmetic, as far as I can tell, but I would like to know whether the bare metal underneath will corrode in the damp air of the boatyard.

5. **Can the battery be replaced with a larger one?** The current one limits long jobs. I have not checked whether the electronics would accept a bigger pack, and I do not want to try it blindly.

6. **What is the best cleaning interval?** I currently clean on a fixed rhythm, but I do not have evidence that it is the right one. Too rare risks clogging, and too frequent risks wear from handling.

For now, the answer to most of these is to keep the log going and look at the data after another full year.

## Schedule

This is the routine I follow to keep the Gilsiond heat exchanger in good shape. It is built around the way the boatyard works, with busy spells in spring and early summer and a quiet period in winter.

**After every work session**
- Switch the unit off fully, not to standby.
- Wipe the casing with a dry cloth.
- Write a short entry in the log.

**Every week**
- Brush the fins and the intake with a soft brush.
- Check the hose clamps by hand for looseness.
- Look at the battery level and charge it if it is low.
- Make sure nothing is stacked against the unit.

**Every month**
- Do a longer inspection of the connections and mounts.
- Read back through the log and note anything that repeats.
- Run the unit through a slow warm-up and watch how it behaves, listening for any change in sound.
- Check the setting using the steps in the Adjustment section.

**Every season**
- Do a full charge and discharge cycle on the battery and note how long it lasts.
- Clean the core more thoroughly, once the workshop is quiet.
- Look at the paint on the casing and touch up the worst spots.
- Review the open questions and decide whether any can be tested now.

**Once a year**
- Plan a day when the unit can be taken out of use completely.
- Compare the battery's run time to the previous year.
- Decide whether any part needs replacing before the busy season starts.

The best time for the longer tasks is late autumn, when the boatyard has fewer boats in for work and the workshop is less dusty. I try to finish the heavy maintenance before the cold weather arrives, since a weak battery in winter is a bad combination with a unit that needs a careful start.

## Background

The Gilsiond heat exchanger is a device of the heat exchanger kind. It belongs to the boatyard area of my notes, and it is installed in the workshop. The unit is red, it runs on a battery, and it was installed in 2021.

I decided to study it because it is one of the few pieces of equipment in the workshop that I rely on every day and still do not fully understand. Its job is to move heat from one place to another, so that materials and working conditions stay within a range that suits the work. In a boatyard that matters, because resins, adhesives and coatings behave very differently depending on temperature. A job that goes well on a warm day can fail on a cold one.

When it was installed in 2021, I mostly took the setup on trust. The person who fitted it showed me the basic controls, and I used it for a while without thinking much about how it behaved. Over time I noticed small differences from one week to the next, and that is what led me to start keeping notes and eventually to write this study.

The fact that the unit runs on a battery has shaped almost everything about how I use it. It means I can place it where it is most useful, without needing a socket nearby. It also means I have to think about charge, run time and the age of the battery. This is a trade I accepted at the start, and I still think it was sensible for a workshop where benches are rearranged often, although the downsides have taught me a lot.

The red colour is a small detail, but it has a practical side. It makes the unit easy to spot among the grey and brown of the workshop, and it stops people from leaving things on top of it or bumping into it with trolleys. It also hides dirt, as I mentioned earlier, which is less helpful.

My aims with this study are simple:

- Understand how the unit behaves over a normal year.
- Find out what keeps it stable and what upsets it.
- Write down a maintenance routine that I can follow without having to think.
- Collect the questions that I cannot yet answer.

This is not a technical paper. It is a working record, written for my own use, and it will change as I learn more.

## Adjustment

The adjustment is the part of the routine that I trust least from memory, so I have written it out step by step. It is done in the workshop, with the unit in its normal position, and only after it has been through a slow warm-up.

The calibration offset of Gilsiond heat exchanger: 0.262 mm. This is the value I set and check against. If the unit is behaving as it should, the measured offset matches this figure. If it has moved away, I bring it back.

**Before starting**
1. Make sure the battery is well charged. A weak battery gives misleading results.
2. Let the unit run for a while so that it reaches a steady state.
3. Clear the area around it and keep the workshop doors closed to avoid draughts.
4. Have the log ready to record what you find.

**Steps**
1. Switch the unit off and open the access point as described in the manual.
2. Check the current position against the reference mark and compare it with the calibration offset of 0.262 mm.
3. If it matches, close up and note in the log that no change was needed.
4. If it does not match, loosen the locking screw only a little, since forcing it can shift the setting further.
5. Move the adjuster slowly in small steps, checking after each one.
6. When the offset is back at 0.262 mm, tighten the locking screw gently.
7. Switch the unit on again, let it warm up, and check once more to be sure the setting held.
8. Record what you found, what you changed, and the state of the battery.

**Things to watch for**
- Do not adjust a cold unit, because the reading will be off.
- Do not adjust right after moving the unit, since mounts need time to settle.
- If the offset keeps drifting after a correction, look for a loose mount or clamp before touching the adjuster again.
- If the unit cannot be brought back to the setting at all, stop and treat it as a fault, not an adjustment.

After a correction, I check the setting again the next day. If it has held, I return to the normal schedule. If not, I move the checks to a weekly basis until the cause is found.
