---
type: log
status: active
project: krirkfu-expansion
area: boatyard
---

# Stilneth barn log

## Risks

Stilneth barn is a small barn in the boatyard area, built in 2004. It sits below ground and faces west. Because the floor is below ground, damp is the main thing I watch here, along with water finding its way in after heavy rain.

- Standing water on the floor is the first sign of trouble. I check the low corner by the west wall every visit.
- Cold air settles at floor level in winter, so anything stored low can get damp or freeze.
- The west orientation means driving rain hits the wall and door more than the others. Check the seal after every storm.
- Poor air movement leads to mould. I compare notes with [[Telbrond shed notes]] and [[Zobanfond greenhouse notes]], since both places had the same trouble before I fixed the airflow.
- If the heat source fails, the temperature drops quickly. The earlier results in [[Sulzar Rirkkand tests 2023]] are a useful reference for how fast a small space cools.

For planning any future heating changes, [[Fupu greenhouse plan]] has ideas I may reuse, though the barn is much smaller.

## Equipment

The installed device in Stilneth barn is a Rindisdru data logger. It records conditions over time, and I read it when I visit so I can spot slow changes in damp and temperature.

Related equipment I have considered or used elsewhere:

- [[Lorpaer level sensor]]: worth fitting low on the floor to give early warning of water. Not installed yet.
- [[Riostael circulation pump]]: would help if I ever add a water-based heating loop. Not needed at present.
- [[Brunbaedos heat exchanger]] and [[Lelben heat exchanger]]: both are options if I add heating. I would pick based on the notes I already have, and the small size of the barn favours the lighter one.

Next step: decide whether the level sensor is worth adding before winter, and keep the logger readings in this log.
