---
type: summary
status: active
project: krirkfu-expansion
area: boatyard
description: "Summary about Krirkfu expansion."
---

# Summary of Krirkfu expansion

## Setup

Krirkfu expansion is a project in the boatyard area. Its goal is expansion, meaning more working space and capacity at the yard. It started in 2025 and belongs to the summer season. The lead is my neighbor, who has taken on the day-to-day running of it, while I keep the notes and track the open points.

Current stage: the project is past the go decision and in the doing phase. The planning work is finished, the site has been walked through more than once, and the first practical steps are under way. This summary is the one place where I keep the state of things, so I update it whenever something changes.

Properties of the project, for quick reference:

- Name: Krirkfu expansion
- Goal: expansion
- Area: boatyard
- Start year: 2025
- Season: summer
- Lead: neighbor

The covered storage part of the work depends on keeping damp under control, so I use the readings in [[Vensos dehumidifier log]] as a reference for how the existing shed behaves. Those readings are not part of the project plan, but they tell me what to expect in the new space.

## Decisions

The main decision was whether to go ahead at all. We weighed the cost in time and effort against the benefit of having more room for boats over the winter. The yard was already tight, and the neighbor argued that waiting another year would only make the work harder. I agreed after we sorted out who would do what.

- Go decision date: 2025-04-27
- Decision: go ahead with the expansion, in stages rather than all at once.
- Reason for staging: it lets us stop after any stage if money or weather turns against us.
- Division of work: the neighbor leads and decides on site matters; I handle notes, lists of materials and follow-up.

Smaller decisions made since then:

- Keep the new space simple, with a plain floor and open sides that can be closed later.
- Reuse the existing drainage line instead of laying a new one.
- Buy materials in one batch per stage, not piece by piece, so deliveries are easier to track.
- Do the noisy work on weekdays only, out of respect for the people living nearby.

## Observations

What is done so far:

- The ground has been cleared and marked out.
- The route for the drainage line has been checked and confirmed as usable.
- The first batch of materials has arrived and is stored under cover.
- The neighbor has agreed the working days and hours for the summer season.

What I have noticed along the way:

- The ground at the low end stays wet longer than the rest after rain. This needs a fix before any floor goes in.
- Stored timber in the old shed picks up moisture quickly when the weather turns. The readings in [[Vensos dehumidifier log]] show the same pattern, so I expect the new space to need similar care.
- Work goes faster when the materials for a given day are laid out the evening before.
- Small jobs pile up if nobody owns them, so I now write a name next to each one.

Open points:

- How to deal with the wet patch at the low end of the site.
- Whether the sides should be closed in this season or left for the next.
- Who covers the work if the neighbor is away for a stretch.
- Whether a second batch of materials should be ordered now or after the first stage is finished.

A short check I run when I visit the site, kept as a plain list so I do the same thing every time:

```
site check - Krirkfu expansion
[ ] ground: wet patch at low end checked
[ ] materials: covered and off the floor
[ ] drainage line: clear, no standing water
[ ] tools: counted and put away
[ ] notes: open points updated
```

## Next action

The next action is NX-0081.

I keep this to one item on purpose, so there is no doubt about what comes next. Once it is finished I will update this section, move the finished item into the done list under Observations, and pick the next step from the open points. Until then the other open points wait, apart from anything that affects safety.

Before starting I want to talk it over with the neighbor, confirm the day and who is available, and make sure the materials needed are already on site. If something is missing, I order it first and do not start half-prepared.

## Safety

The yard is a working place, and the expansion adds extra risks on top of the usual ones.

- Keep the work area marked off so nobody walks through it by mistake, especially while boats are being moved.
- Wear sturdy boots and gloves on site, and eye protection for cutting or drilling.
- Never work alone with power tools. The neighbor or someone else should be within calling distance.
- Keep the wet patch at the low end in mind: it is slippery, so cover it or mark it until it is fixed.
- Store timber and other materials flat and stable so they cannot slide or tip over.
- Keep walkways to the water clear of tools, cables and offcuts.
- Keep a first aid kit and a phone at the site, and make sure we both know where they are.
- If the weather turns, stop outdoor work, secure loose materials and leave the site until it is safe again.
