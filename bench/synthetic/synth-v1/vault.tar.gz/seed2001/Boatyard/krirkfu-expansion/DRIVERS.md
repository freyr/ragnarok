---
type: drivers
status: active
project: krirkfu-expansion
area: boatyard
description: "Drivers about Krirkfu expansion."
---

# Drivers of Krirkfu expansion

## Maintenance

Krirkfu expansion is a boatyard project that started in 2025. Its goal is expansion, the season is summer, and the lead is my neighbor. These notes cover what drives the project: why we are doing it, what limits it, what it costs and how I will know it worked.

Maintenance matters here because expanding the yard means more ground, more racks and more equipment to keep up. If I do not plan for upkeep now, the new space will fall apart faster than the old space did.

What needs regular upkeep once the expansion is done:

- The new hard standing and the access track. Gravel shifts after heavy rain and needs raking back into place.
- The cradles and stands. Bolts loosen, timber swells and shrinks, and the feet sink into soft ground.
- The shed doors, locks and lights in the new section.
- The drainage ditch along the extended boundary. It clogs with leaves every autumn.
- The saw and other workshop machines. The [[Baerkstind band saw]] gets used the most for cutting timber packing and cradle parts, so its blade and guides need checking before each season starts.

A rough rule I keep: anything that I install in summer gets a look in autumn and again in spring. Anything that carries a boat gets looked at every time before a boat goes on it.

Maintenance is also a driver in the sense that it limits how much I should build. A bigger yard that I cannot keep tidy is worse than the current one. So the expansion should only be as large as my neighbor and I can realistically look after in the time we have.

## Costs

The main cost lines for the expansion, in the order I expect them to hurt:

1. Ground work: levelling, hardcore, gravel and edging for the new standing area.
2. Fencing and gate along the new boundary.
3. Timber and steel for cradles, stands and a few extra racks.
4. Electrical work for lighting and a socket in the new section.
5. Drainage pipe and a soak-away.
6. Hire of a digger and a small roller for a few days.
7. Consumables: blades, fixings, paint, preservative, gloves and so on.
8. Small unplanned items, which always appear.

The costs I can control are timber, fixings and labour, because we can do a lot ourselves. The costs I cannot control are ground work quantities, which depend on what the soil is like once we dig, and anything that needs a qualified person, such as the electrics.

I keep costs in a simple list with three columns: what, who pays, and whether it is done. The neighbor and I agreed early that we would not argue over small amounts. Anything large gets discussed first, and the total is checked against the budget in the Budget section below.

One lesson from earlier projects: the cost of the thing is rarely the whole cost. A gate also needs posts, concrete, hinges, a latch and time. I now write the whole chain for each item before I count it.

Where I can save without losing quality:

- Buy gravel and hardcore in one delivery rather than several.
- Reuse old timber for packing and temporary supports.
- Borrow tools rather than buy ones used once.
- Cut parts in batches on the band saw so setup time is not wasted.

Where I should not save: drainage, electrics, anything under load, and the gate latch. Those fail in ways that cost more later.

## Supplies

Supplies are bought in rounds, not all at once, because the yard has little dry storage and some materials spoil.

Round one, before digging:
- Marker paint, string and pegs for setting out.
- Geotextile membrane for under the gravel.
- Drainage pipe and fittings.
- Fuel for the digger and roller.

Round two, during the build:
- Hardcore and gravel.
- Fence posts, rails and boards.
- Gate hardware.
- Concrete mix for post holes.
- Cable, conduit and light fittings.

Round three, finishing:
- Timber for cradles and racks.
- Steel bar and plate for stand feet.
- Preservative and paint.
- Bolts, washers and coach screws, all in stainless or galvanised.
- Signs and reflective tape for the edge of the standing.

Storage notes: cement stays off the floor and covered. Timber goes on bearers under cover with air gaps. Paint and preservative stay in the locked cupboard, away from the workshop heater. Fixings are sorted into labelled tubs so I do not waste time hunting for the right size.

My neighbor has offered space in their barn for timber, which helps a lot. In return I cut a few parts for their own projects on the band saw.

Supplier habits: I ask for delivery on a weekday morning when one of us is on site. I check what arrives against the order before the driver leaves. Anything wrong is photographed on the spot.

## Checklist

A short list I go through at each stage. I tick it in my head and write problems down.

Before starting in summer:
- Agree the layout with my neighbor and mark it on the ground.
- Check where pipes, cables and drains already run.
- Confirm the boundary and whether any permission is needed.
- Clear the area of old stands, scrap and brambles.
- Book the digger and roller.
- Check the weather for the first week.

During the build:
- Keep the access track clear for deliveries.
- Keep a photo record of buried work before covering it.
- Check levels after each layer of hardcore.
- Compact in thin layers, not one thick one.
- Fence off holes and trenches at the end of each day.
- Keep a running list of what was used and what is left.

At finish:
- Walk the whole area and look for soft spots.
- Test lights and the socket.
- Check the gate swings and latches.
- Put the first boat on a stand with the yard empty around it, as a test.
- Tidy tools and return anything borrowed.
- Update these notes with what went differently.

Success checks, which I treat as part of the same list:
- The new space holds boats without sinking or standing water.
- Work stays inside the budget.
- It is finished within the summer season.
- Both of us can still keep it tidy without extra help.

## Tools

The tools split into things we own, things we borrow and things we hire.

Owned:
- The [[Baerkstind band saw]] for cutting timber and some thin steel parts with the right blade.
- Hand tools: spades, rakes, wheelbarrows, spirit levels, string lines, mallets.
- Cordless drill and driver, with spare batteries.
- Angle grinder with cutting and flap discs.
- A set of spanners and sockets for the stand bolts.
- Tape measures and a long straight edge.

Borrowed from my neighbor:
- A trailer for hauling materials.
- A plate compactor for the small areas, when it is not out on loan.
- A cement mixer.

Hired:
- A small digger.
- A roller for the main standing.

Tool habits I try to keep:
- The band saw gets a blade check, a tidy and a test cut before each batch.
- Dust and offcuts are cleared so they do not pile up under the table.
- Battery tools are charged the night before.
- Hired kit is cleaned and fuelled before return so there are no extra charges.
- Everything is put back in the same place so nothing is lost in the mud.

A tool I wish I had: a decent laser level. For now we make do with a string line and patience, and double-check the readings.

## Overview

Krirkfu expansion is a project at the boatyard. Its properties, stated plainly:

- Goal: expansion
- Area: boatyard
- Start year: 2025
- Season: summer
- Lead: neighbor

The aim is to make more room in the boatyard so more boats can be stored and worked on, with safer ground and better access than we have now. The project began in 2025, and the work is planned for the summer season because the ground is driest and the days are longest. My neighbor leads it, and I help with planning, cutting, building and note keeping.

The drivers, in order of weight:

1. More capacity. The yard is full in the busy months and I have had to turn people away or stack boats too close.
2. Safer layout. Space between boats allows a clear walk-through and a way out if something goes wrong.
3. Better ground. Soft patches in the current yard make stands unstable.
4. Control of cost. This is a small operation, so money is limited.
5. Time. Summer is short, and every week lost reduces what we can finish.

Constraints:

- The budget is fixed and shown below.
- The work has to fit around the working yard, so access cannot be blocked for long.
- Weather in the season can stop digging and compaction.
- Only two people do most of the labour.
- Anything electrical or structural needs correct standards.

How success is measured:

- Capacity: the number of extra boats that can be stored safely.
- Quality: the ground holds a loaded stand through a wet spell without sinking.
- Cost: the final total is at or below the budget.
- Schedule: the main work is done before the season ends.
- Upkeep: the new space can be maintained without adding much to the weekly workload.

I count the project as a success only if all five are met, though capacity and ground quality matter most.

## Lessons

Lessons from earlier yard work that I am carrying into this project:

- Ground is the real project. Anything built on poor ground ends up wrong. Spend time and money under the surface first.
- Compact in thin layers. Thick layers look done and are not.
- Photograph buried work. Memory fades, and drains and cables get hit later by someone with a spade.
- Order a little more gravel than the sums say. Running short halfway through is worse than having a small pile left.
- Do the jobs that need dry weather first, and keep indoor jobs, such as cutting cradle parts, for wet days.
- Cut in batches. Setting up the band saw once for a day of identical parts is faster than many small sessions.
- Agree decisions out loud with the neighbor and then write them down. We have both misremembered before.
- Do not leave open holes overnight without a barrier and a marker.
- Label things. Offcuts, tubs, keys and cables all get lost otherwise.
- Test with a real boat before calling it finished.

Things I would do differently if starting again:

- Walk the site after a heavy rain before fixing the layout, to see where water sits.
- Ask earlier about services running under the ground.
- Keep one shared list of purchases rather than two partial ones.

## Problems

Problems I expect, or have already seen, and how I plan to handle them.

Wet ground. Digging in rain turns clay into soup. Plan: pause, cover the work with sheeting, and use the time for cutting and painting under cover.

Soft spots found late. Some patches may only show up once the top layer is off. Plan: dig them out and fill with hardcore, and record the location.

Poor drainage. If water collects at the low end, the new area will be unusable in winter. Plan: set falls carefully, lay the pipe before the surface, and test with a hose.

Delivery trouble. Lorries struggle on the narrow track and can churn it up. Plan: split deliveries, lay boards in the worst spots, and tell the supplier about the access.

Machine breakdown. Hired kit sometimes fails. Plan: contact the hire shop at once and keep a list of jobs that can be done by hand.

Disagreement over scope. It is easy to keep adding things. Plan: the lead, my neighbor, decides what goes in, and extra ideas wait until the main work is done.

Time pressure. If the summer slips, the work gets rushed. Plan: set the priority order early, with ground and drainage first, fence second, extras last.

Tool wear. The band saw blade dulls quickly on treated timber. Plan: keep spare blades and change them before the cut quality drops.

Safety lapses when tired. Plan: stop at an agreed time, not when the light goes.

## Setup

Setting up the site is done in a fixed order so nothing has to be undone.

1. Clear and mark. Remove old stands, scrap and growth. Mark the corners of the new area with pegs and paint, then run string between them.
2. Check services. Confirm where existing drains, cables and pipes are. Mark them clearly so the digger operator can see.
3. Set the access. Decide the route for deliveries and keep it free. Put boards down where the ground is soft.
4. Establish a store. Pick a dry corner for materials and a lockable place for tools and fuel.
5. Set a work area. Put the band saw under cover with room for long timber on both sides, a level floor and good light. Keep a clear route out in case of emergency.
6. Set up welfare. Water, a first aid kit, a place to sit and a phone with signal or a plan for when there is none.
7. Agree roles. My neighbor leads on site decisions and hired kit, and I look after cutting, purchasing lists and notes.
8. Agree communication. We share a short message at the start and end of each work day with what was done and what comes next.

Once the setup is done, the first real task is stripping the topsoil and checking the ground underneath. That sets the final depth of hardcore and the amount of gravel to order.

## Schedule

The expansion is planned for summer. The plan is by phase, not by exact date, because the weather decides most of it.

Phase one, early summer: clear the site, set out the layout, check services and strip the topsoil. Book the digger and roller for the dry spell.

Phase two, early to mid summer: dig out soft spots, lay drainage, build up hardcore in thin compacted layers, and add the membrane and gravel.

Phase three, mid summer: put up the fence and gate, run the electrical work and fit the lights.

Phase four, mid to late summer: cut and assemble cradles, stands and racks, using the band saw in batches. Paint and treat the timber.

Phase five, late summer: test with a boat, fix what is wrong, tidy the site and return all hired and borrowed kit.

Buffers: I leave a spare week after each of the first two phases, since ground and weather are the biggest unknowns. If a buffer is not needed, it moves forward to give time for finishing touches.

Fixed points: hire bookings, any inspection of electrical work, and the first boats that need the space. These are agreed with my neighbor and written where we both see them.

If we fall behind, the order of cuts is clear: drop the extras and keep ground, drainage, fence and safe stands.

## History

The yard has grown in small steps over the years, mostly by adding racks and squeezing boats closer together. That works until it does not, and the last few busy seasons showed the limit.

Krirkfu expansion started in 2025 as an idea my neighbor raised while we were rearranging stands after a wet spring. We walked the field next to the yard, talked about what could fit and agreed to look into it properly. My neighbor took the lead from the start, since they know the owners of the adjoining land and have more experience with groundwork.

Since then the project has moved through these stages:

- Early talk and rough sketches of the layout.
- Walking the site in different weather to see how water moves.
- Working out a budget and what we could do ourselves.
- Collecting quotes for the work we could not do ourselves.
- Settling the order of work and choosing summer as the season.

It has been a slow project on purpose. Rushing the planning on a site like this leads to expensive fixes. These notes record why we made the decisions we did, so that later, when I wonder why a drain runs where it does, I can look it up.

I also keep a loose log of conversations with my neighbor, and I copy the decisions into this note when they are firm.

## Safety

Safety rules for the whole project. They are simple and I mean to follow them every day.

Personal protection:
- Boots with steel toe caps and good grip.
- Gloves for handling timber, steel and gravel.
- Eye protection for cutting, grinding and drilling.
- Hearing protection for the saw, grinder and machines.
- A dust mask for sawing treated timber and mixing cement.
- High-visibility clothing when machines are moving.

Machines and tools:
- Only trained people operate the digger and roller.
- Keep other people well away from moving machines.
- The [[Baerkstind band saw]] has its guard set close to the work, the blade checked for cracks and dull teeth, and the power off before any blade change or adjustment.
- Support long timber at both ends so it cannot pinch the blade.
- Never reach over a running blade or clear offcuts while it is moving.
- Unplug grinders and drills when changing discs and bits.

Site hazards:
- Mark and fence trenches and holes.
- Keep walkways clear of cables and hoses.
- Take care with lifting. Use a trolley or ask for help with heavy cradles.
- Keep fuel and paint away from heat and sparks.
- Work on electrics only with the supply isolated, and have the final connection done by someone qualified.
- Keep a first aid kit and a fire extinguisher where we can reach them fast.

Working habits:
- Do not work alone with machines or on tasks with a high risk.
- Take breaks and drink water in hot weather.
- Stop when tired or when the weather turns dangerous.
- Tell the other person where you are and when you expect to be done.

## References

Where I look when I need to check something:

- My own notes on the earlier layout of the yard, including where the stands went and what ground problems we met.
- The owner's manual for the [[Baerkstind band saw]], which has the blade, guide and tension settings.
- The hire shop's guides for the digger and roller.
- Supplier datasheets for the membrane, drainage pipe and preservative.
- Local guidance on drainage, boundaries and electrical work, which my neighbor keeps in a folder.
- The notes from my chats with my neighbor about layout and who does what.
- Photos taken during the project, saved in a folder by date.

Other notes in this knowledge base that connect to this one:

- The note on the boatyard layout and boat storage rules.
- Notes on timber treatment and cradle design.
- The tool log, which records blade changes and repairs.
- A general checklist for starting any building job in the yard.

When something in these sources changes, I update this note and say why. If two sources disagree, I trust what I measured or saw on the ground over what is written.

## Budget

The budget for Krirkfu expansion is 23638.57 EUR.

This is the fixed limit for the whole project, and every cost line from the Costs section must fit inside it. It covers ground work, fencing, drainage, electrical work, timber and steel, hire, consumables and a reserve for surprises.

How I handle it:

- The reserve is held back and only used for things that were not in the plan. Spending it is a joint decision with my neighbor, the project lead.
- Big purchases are agreed before the order is placed.
- Receipts are photographed and kept in one folder, with a short note on what each was for.
- I update a running total after each purchase, and compare it with the work done so far, not just the money spent.
- If the total is heading over the limit, we cut the extras first, then reduce the size of the racking, and only then discuss anything else.

How the budget ties to success: finishing at or below this amount is one of the five tests listed in the Overview. A project that comes in on budget but with poor ground is not a success, and neither is a perfect build that overspends. The aim is a sound, useful, affordable expansion that we can keep up with the people and time we have.

Savings I would try to bank early: bulk delivery of gravel, reused timber for temporary supports, and borrowed kit instead of hired kit where possible. Any money saved goes first back into the reserve, and anything left at the end is decided with my neighbor.
