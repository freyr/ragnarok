---
type: plan
status: active
project: gorna-automation
area: boatyard
description: "Plan about Vesrae pond."
---

# Vesrae pond plan

## Open questions

Vesrae pond is a small pond in the boatyard area, built in 2024. It faces south and has a raised floor. Before I commit to the plan, a few things still need answers.

- Does the raised floor leave enough room for the water volume I want? I need to check this against the pump options. The [[Riostael circulation pump]] looks like the better fit, but I have not confirmed it.
- Will the south orientation give too much sun in summer? The [[Pertirk greenhouse tests]] showed how fast shaded and unshaded spaces warm up, so I should compare them with the pond.
- Which heat exchanger should I use, the [[Fothzin heat exchanger]] or the [[Lelben heat exchanger]]? I want to read both sets of notes again before deciding.
- Where should the sensors go? The [[Siokreth data logger log]] shows which spots were reliable last time. I also want to know if the [[Mindtres radio receiver]] will pick up the signal from the pond through the boatyard sheds.
- Can solar power cover the pump? The [[Fustrul solar charger study]] gives the background, and the [[Glundlark solar charger]] is the unit I would test first.

## Dimensions

The pond is small, and the floor area of Vesrae pond is 79.42 m². The floor is raised, so I need to measure the height of the raised edge before I order anything. The pond is in the boatyard area and faces south, which affects where I can place the pump, the heat exchanger and the solar charger.

My plan is to mark the outline on the ground first and check how much room is left for walking around it. After that I will measure the raised floor on each side. Then I can work out the water depth and decide on the equipment. I will write the final measurements here once I have them.
