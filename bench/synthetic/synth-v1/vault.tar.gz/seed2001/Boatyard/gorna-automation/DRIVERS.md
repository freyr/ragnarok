---
type: drivers
status: active
project: gorna-automation
area: boatyard
description: "Drivers about Gorna automation."
---

# Drivers of Gorna automation

## History

Gorna automation is a project in the boatyard area. The goal is automation. It started in 2019 and it runs in the summer season. The lead is the mentor, who set the direction at the start and still reviews every major change.

The idea came from a simple annoyance. Every summer the yard had the same set of manual jobs: checking battery levels on the slips, walking the length of the pontoon to see which berths had power, and writing down readings by hand. Those rounds took hours that the crew needed for real boat work. In 2019 we decided to automate as much of that as we reasonably could, and to do it in the summer, when the yard is busiest and the benefit is easiest to see.

The first season was mostly small experiments. We tried a few ways of keeping remote equipment powered without running cable, and the notes from that work are in [[Traerktin solar charger tests]]. Those tests showed what a small panel can and cannot sustain through a normal summer week, and they set our expectations for everything that came after.

The second stage was about getting data back to the workshop. We needed a reliable way to collect readings without someone walking out to read them. The comparison of sensor hardware is written up in [[Sogionvin Stilstur tests]]. The short version is that the choice came down to how well a unit coped with damp and salt, not how many features it had.

In 2020 we added radio reception at the office end so the readings could be collected in one place. The details are in [[Mindtres radio receiver 2020]]. That step turned the project from a set of separate gadgets into something close to a working system.

Since then the work has been steady and unglamorous: replacing parts that corroded, adjusting how often units report, and removing steps that turned out to be unnecessary. The mentor keeps the scope narrow on purpose. Anything that does not remove a manual round gets pushed back.

## Risks

The main risk is the environment. A boatyard is wet, salty and full of vibration, and electronics that work on the bench can fail within weeks outdoors. Every new unit gets treated as unproven until it has lasted a full summer.

Power is the second risk. Solar charging works well in clear weeks and badly in long grey spells. If a unit goes flat, we lose readings exactly when conditions are worst. The charger tests showed where the margin is thin, and I should reread them before adding any new remote unit.

Radio range is the third. Hulls, sheds and stacked boats block signals in ways that are hard to predict. A receiver placement that works in June can be useless in July when the yard layout changes and boats are moved. Any change to where boats are stored should trigger a quick range check.

There are also people risks:

- The mentor is the lead, and the project leans on their judgment. If they are unavailable during the season, decisions slow down.
- Only a few of us understand how the pieces fit together. Notes need to stay current so that someone else can repair a unit.
- The crew may stop trusting the readings after a few false alarms and go back to walking the pontoon. Trust is hard to rebuild, so we prefer a missing reading to a wrong one.

Finally, there is scope creep. Each season someone suggests a new thing to automate. Without discipline, the project grows past what we can maintain. The rule is that nothing is added unless we can maintain what we already have.

## Costs

The costs fall into a few groups. None of them is large alone, but together they add up over several seasons.

Hardware is the obvious one: sensors, chargers, panels, enclosures and the receiver. Outdoor units need proper sealing, and cheap enclosures have cost us more in replacements than good ones would have cost at the start.

Replacement is the cost that is easiest to forget. Corrosion and weather mean a share of units is lost every year. I now assume some loss each season and plan for it rather than treating it as a surprise.

Time is the second big cost. Setting up a unit, testing it, mounting it and checking it a week later takes more effort than the purchase itself. Most of that happens in the summer, when the crew is already stretched. Time spent on the project has to be weighed against time spent on paying work.

Smaller costs include cables, connectors, fasteners, sealant and the occasional tool. These are cheap individually, but they are bought repeatedly and not always logged. I should note them when I buy them.

There is also the cost of learning. Part of the early spending went on approaches that did not work, such as the first sensor choices that are described in [[Sogionvin Stilstur tests]]. I count that as the price of finding out, not as waste, but it should be remembered when estimating future experiments.

## Budget

The budget of Gorna automation is 14364.74 EUR.

That figure covers the project as a whole and is the ceiling the mentor works to. It is not a target to spend. If a season can be done for less, the remainder stays unspent.

Success is measured in practical terms, not by how much equipment is installed:

- Fewer manual rounds on the pontoon and the slips each summer.
- Readings that arrive reliably, with few gaps and few false alarms.
- Units that survive a full summer without replacement.
- Crew time freed for boat work.

Spending decisions follow the same logic. A purchase is justified if it removes a manual round or makes an existing unit more dependable. If it only adds a new feature, it waits.

The mentor signs off on larger purchases before they are made. Smaller ones I can make myself, but I log them so the running total stays honest. Before each summer I compare what has been spent against the budget and decide what the season can afford.
