---
type: log
status: active
project: gorna-automation
area: boatyard
description: "Log about Ziorzerk circulation pump."
---

# Ziorzerk circulation pump log

## References

These are the things I look at when I need to remember how the Ziorzerk circulation pump is meant to behave. This log is for my own use, so the list is short and practical.

- The paper booklet that came with the pump, kept in the grey folder on the shelf near the cellar door.
- The photos I took of the wiring and the mounting bracket in 2022, stored in the boatyard folder on my phone.
- My own notes on the other pumps in the boatyard, which I compare against when something looks odd.
- The label on the pump body, which I have copied by hand into the paper folder. I do not repeat its numbers here.
- A short list of habits from the old yard hands who taught me how to bleed air out of a loop.

The pump is a circulation pump. It belongs to the boatyard area, it is red, it runs on a battery, I installed it in 2022, and it lives in the cellar. Those are the basic facts, and everything else in this log hangs on them.

## Setup

The Ziorzerk circulation pump sits in the cellar, low on the wall, about knee height. I chose that spot in 2022 because the cellar is the lowest point of the loop, and a circulation pump does its best work when it does not have to fight trapped air. The red casing is easy to spot in the dim light, which has saved me more than once when I came down with a torch and needed to find it fast.

Because the energy source is a battery, there is no mains cable to trip over. That was the main reason I picked it. The cellar floor gets damp, and I did not want an extension lead anywhere near the water. The battery sits in a small plastic box on a shelf above the pump, and a short lead runs down to the pump terminals. I keep the box lid taped at one corner so that drips do not run in.

The mounting is simple. A steel bracket is bolted to the wall, and the pump is held in it with two clamps. Rubber pads sit between the casing and the bracket to cut down the hum. When I first fitted it, the hum traveled through the wall and I could hear it in the room above. The pads fixed that.

The pipework is arranged as a closed loop. Water leaves the boiler side, goes through the pump, runs out toward the boatyard workshop, and comes back. There are two isolating valves, one on each side of the pump, so I can take the pump out without draining the whole loop. I painted a small white arrow on the pipe to show flow direction, because I once fitted a pump the wrong way round on a different job and never want to repeat that.

Steps I follow after any reinstall:

1. Close both isolating valves.
2. Seat the pump in the bracket and tighten the clamps evenly.
3. Connect the battery lead, checking polarity twice.
4. Open the valves slowly, the inlet side first.
5. Bleed the air at the high point until only water comes out.
6. Run the pump for a few minutes and listen.

## Lessons

Most of what I know about this pump came from small mistakes. I write them here so I do not make them again.

The first lesson is about air. A circulation pump that is full of air will spin happily and move nothing. In the first winter I thought the pump had failed, because the workshop end of the loop stayed cold. It had not failed. A pocket of air had collected near the top of the run. Bleeding it fixed everything in ten minutes.

The second lesson is about the battery. A battery-powered pump gives no dramatic warning when the charge drops. It just slows down. The flow gets weaker, the workshop gets cooler, and I blame the boiler. Now I check the battery first, before touching anything else in the system.

The third lesson is about damp. The cellar is not a kind place for electrical connections. I had a green crust on one terminal after the first year. I cleaned it with a small brush and smeared on a thin layer of grease, and the problem has not returned.

The fourth lesson is about patience. When something seems wrong I want to change several things at once. That makes it impossible to know what helped. I now change one thing, wait, and write down the result.

A few shorter lessons:

- Label every valve. I know which is which today, but in two years I will not.
- Keep a spare set of clamps. They are cheap and they disappear.
- Do not trust a pump that is warm to the touch but silent.
- Write the date of every battery swap on the box lid with a marker.

## Software

The pump has a small controller inside, and it reports a firmware version. The firmware version of the Ziorzerk circulation pump is v8.36.220.

I have never updated it, and I do not plan to unless something is clearly broken that an update would fix. The pump does its job. The controller offers a few speed settings and a simple timer mode, and I use the timer mode because it saves battery.

My notes on how the controller behaves:

- On power-up it runs a short self-check and blinks its indicator.
- In timer mode it runs for a block of time and then rests.
- If the battery voltage drops too low, it stops and refuses to restart until the battery is replaced or recharged.
- It remembers its settings through a battery swap, which I confirmed by testing.

Here is a typical extract from what I jot down after a check, written in the style I use in my notebook:

```
pump: Ziorzerk circulation pump
location: cellar
mode: timer
speed: medium
battery: charged, swapped in spring
air in loop: none after bleed
noise: low hum, normal
result: workshop end warm within an hour
```

I keep that format on purpose. It is dull, but it lets me compare one visit with another without reading long paragraphs.

## Open questions

There are a few things I still do not know, and I would like to settle them when I have time.

- How long does one battery really last in timer mode over a cold month? I have rough impressions, but I have not measured it properly.
- Is the hum I hear in the wall caused by the pump itself or by a slightly loose clamp? The rubber pads helped, but I am not sure they solved it completely.
- Would a larger battery in the same box make the pump more reliable in winter, or would it just be heavier and harder to swap?
- Is there any benefit in moving the pump higher on the wall, away from the damp floor?
- Does the red casing fade in the cellar light over the years, and does that matter at all? Probably not, but I am curious.
- Should I add a simple float alarm near the pump in case of a leak? The cellar is the lowest part of the boatyard building, so any water ends up there.

I will cross these off as I find answers. If I never answer some of them, that is also fine, since the pump keeps working.

## Costs

I do not keep exact accounts for this pump, and I am not going to invent numbers here. What I can do is describe where the money goes, in rough order of size.

The largest cost was the pump itself in 2022. Next came the bracket, clamps, pads and the two isolating valves. These were one-off purchases and I do not expect to repeat them unless something breaks.

The ongoing cost is the battery. Because the pump runs on a battery, I replace or recharge it on a regular basis. Over a few years this adds up to more than I first expected. It is still less than the cost of running a cable, plus the safety work that a mains connection in a damp cellar would have needed.

Smaller costs include:

- Grease for the terminals.
- A small brush for cleaning corrosion.
- Plastic boxes and tape for protecting the battery.
- Marker pens for labeling.
- An occasional bottle of cleaner for the pipes.

My rule is simple: spend money on anything that keeps water or damp away from the electrical parts, and save money everywhere else. A cheap clamp is fine. A cheap, poorly sealed battery box is not.

## Risks

The main risks are about water, electricity and neglect.

Water is the first risk. The pump is in the cellar, which is damp at the best of times and can flood in heavy rain. If water reached the battery box or the terminals, I would expect a short circuit or at least a dead pump. I keep the battery on a shelf above the pump for this reason.

The second risk is a flat battery. If it goes unnoticed during a cold spell, the loop stops circulating, and in the worst case the pipes could be at risk of freezing. This is why I check the battery before every cold season.

The third risk is air. A pump running dry or full of air can overheat or wear faster. I bleed the loop whenever I open it.

The fourth risk is that I forget. A device that works quietly for years is easy to ignore. My notes and my checklist are the answer to that.

Other risks I keep in mind:

- A valve left closed by mistake after maintenance.
- A pump fitted backward after removal.
- A loose clamp causing vibration and slow damage to the pipes.
- Corrosion on the terminals.

None of these is serious if I notice them early. All of them become serious if I do not look.

## Checklist

This is the list I run through on each visit to the cellar. It takes about a quarter of an hour.

- [ ] Look at the floor around the pump for any sign of water.
- [ ] Check that the battery box lid is closed and the tape is intact.
- [ ] Check the battery charge and note the result.
- [ ] Inspect the terminals for green or white crust.
- [ ] Confirm both isolating valves are open.
- [ ] Look at the white flow arrow and confirm it matches the pump direction.
- [ ] Listen for unusual noise from the casing.
- [ ] Touch the pipe on each side of the pump and compare the warmth.
- [ ] Check the clamps and bracket for looseness.
- [ ] Bleed the high point if the workshop end seems cool.
- [ ] Write the date and result in the notebook.

Before winter I add two more items: replace the battery with a fresh one and test the pump for a full hour in timer mode.

## Background

The boatyard has an old heating arrangement that grew piece by piece over many years. Different owners added pipes, radiators and pumps without much planning. When I took over looking after it, one of the first things I noticed was that the workshop was always the coldest room, even when the boiler worked hard.

In 2022 I decided to improve the circulation rather than replace the boiler. A circulation pump is a modest fix, and it was the right size of project for me. I chose a red pump partly because it was available and partly because I liked that it would be easy to see. I chose a battery as the energy source because the cellar had no safe socket nearby.

Since then, the pump has become one of those pieces of equipment that I rarely think about, which is what I wanted. The workshop is warmer, the boiler does not cycle as hard, and I no longer hear the pipes knock in the morning.

I keep this log because the pump is easy to forget. A short note after every visit means that when something does go wrong, I can look back and see what changed. It has already saved me an afternoon of guessing, and I expect it to do so again.

## Safety

The cellar is a place where I take extra care, because damp and electricity do not mix.

- Always close both isolating valves before removing the pump.
- Disconnect the battery lead before touching the terminals.
- Do not work in the cellar if there is standing water on the floor.
- Wear gloves when handling the pipes, since the water can be hot.
- Keep a torch in the cellar so I never work in poor light.
- Never leave the battery box open when I walk away.
- Let the pipes cool before opening any joint.

When I bleed air from the loop, I hold a cloth under the bleed point and open it slowly. Hot water can spray out suddenly, and it is easy to scald a hand. I also keep a small bucket nearby.

The battery deserves respect. I do not puncture, crush or short it, and I store spares in a dry place away from metal tools. If a battery looks swollen or leaks, I remove it carefully, put it in a safe container and take it to a proper disposal point. I do not throw it in the ordinary rubbish.

Finally, I tell someone when I am going down to do a longer job. The cellar stairs are steep and the lighting is poor.

## Tools

The tools I use on this pump are few and ordinary. I keep them together in a small crate near the cellar door so I do not have to hunt for them.

- Two adjustable spanners for the valves and unions.
- A small set of screwdrivers for the terminals.
- A soft brush for cleaning corrosion.
- A tub of grease for the terminals.
- A torch with a head strap, so both hands are free.
- A small bucket and a few cloths for drips.
- A marker pen for labeling and dating.
- A multimeter for checking the battery voltage.
- A spare set of clamps.
- A bleed key for the high point of the loop.

The multimeter is the tool I trust most. A battery can look fine and still be too weak to drive the pump properly. A quick reading tells me the truth in seconds, and I write it in the notebook next to the date.

I also keep a roll of tape and a few plastic bags in the crate. They are not glamorous, but they stop a surprising number of small problems from growing.

## Observations

These are things I have noticed over the years of running the pump in the cellar.

In normal running, the pump makes a low, steady hum. When it is working well, the sound hardly changes. When air gets in, the sound becomes slightly rougher and has a faint gurgle. That is usually my first hint that the loop needs bleeding.

The red casing stays cool to warm in normal use. If it gets properly hot, something is wrong, and I stop and look. If it is cold and silent, the battery is the likely cause.

The cellar is coolest in late winter. The battery seems to lose charge faster in the cold, which fits with what I have read about batteries in general. I now swap the battery earlier in the season than I used to.

The timer mode has been a good choice. In the first year I ran the pump continuously, and the battery drained far too fast. With timer mode, the workshop stays warm enough and the battery lasts much longer.

Other small observations:

- The terminals corrode faster near the end of summer, when the cellar is most humid.
- The rubber pads have flattened a little but still do their job.
- The painted arrow on the pipe has faded, and I should repaint it.
- The workshop warms up noticeably faster after a bleed.
- Visitors to the cellar always comment on the red color.

## Supplies

I try to keep a small stock of consumables so that a minor job does not turn into a trip to the shop.

- A spare battery, charged and stored in a dry place.
- A second spare battery in the workshop, in case the first is used.
- Terminal grease.
- Spare clamps and a few spare rubber pads.
- Cloths and paper towels for drips.
- Fresh tape for the battery box lid.
- White paint for the flow arrow.
- Marker pens that still work.
- Plastic bags for old batteries and dirty cloths.

I check the stock at the start of each cold season. If something is low, I order it right away, because it is much easier to buy things in autumn than in the middle of a freezing week.

The most important item is the spare battery. If I only have one thing in stock, it should be that. A pump that cannot run because of a flat battery is the most common reason for a cold workshop, and a charged spare solves it in a few minutes.

I also keep the booklet and my paper folder in a sealed bag, because the cellar damp would ruin them otherwise.

## Maintenance

Maintenance on the Ziorzerk circulation pump is light but regular. I split it into a few rhythms.

**Every visit.** I run the checklist above. I look for water, check the battery, listen to the pump and feel the pipes. I write a short entry in the notebook.

**Each season.** I replace or recharge the battery, clean the terminals and renew the grease. I check the clamps, the pads and the battery box. I test the pump for a full hour in timer mode and confirm the workshop end warms up.

**Each year.** I close the valves, remove the pump from the bracket and look at it carefully. I check the casing for cracks, the terminals for wear and the pads for flattening. I repaint the flow arrow if it has faded. I refit the pump, open the valves slowly and bleed the loop.

**When something goes wrong.** I start with the battery, because that is the most common cause. Then I check for air, then valves, then the terminals. Only after those do I suspect the pump itself. I change one thing at a time and write down each result.

The pump has been installed since 2022 and has needed no major repair. I think that is because the maintenance is small and steady. The red pump in the cellar keeps running, and the notebook keeps growing, one short entry at a time.
