---
type: summary
status: active
project: gorna-automation
area: boatyard
description: "Summary about Gorna automation."
---

# Summary of Gorna automation

## References

- [[Velferk kiln controller tests]]: the test notes I lean on when I think about timing and control for the automation.
- [[Fupu greenhouse plan]]: the layout plan that shows where sensors and wiring could run.
- [[Zobanfond greenhouse notes]]: older notes on humidity and ventilation, useful for comparison.
- [[Gokio level sensor log]]: readings from the level sensor, which I check when I want to know how steady it is.
- [[Ruthglaend dehumidifier]]: the unit that is the first thing to switch on and off.
- [[Lelben heat exchanger]]: the heat side of the shed, which has to stay in step with the rest.
- [[Baerkstind band saw]]: the saw in the workshop. Its power draw matters for the shared circuit.

## Next action

The next action is NX-9018. Nothing else is more urgent right now. When it is finished I will update this note, move the stage forward if it makes sense, and write down what I learned while doing it. I keep the next action to one thing on purpose, so that I can pick the project up after a gap and know where to start without rereading everything.

Before starting, I will check that the workshop is free and that I have the tools I need to hand. The work is a summer job, so I also want the weather to be dry and the shed to be reachable.

## Decisions

The go decision for Gorna automation was made on 2019-12-27. Before that date the project was only an idea. After it, I treated it as real work with a place in the boatyard schedule.

Other decisions I have settled on, in plain terms:

- Keep the automation small. It should do a few useful things reliably rather than many things badly.
- Use the existing equipment where I can, and not buy new units unless a test shows the old one cannot cope.
- Keep a manual override for every automated step. If something fails, I must be able to run the shed by hand.
- Run the work in the summer season, when the boatyard is busiest and the benefit is easiest to see, but also when the weather allows work outdoors.
- Let the mentor lead. Choices that change the scope go through the mentor first.

## Overview

Gorna automation is a project in the boatyard area. Its goal is automation. It started in 2019, it runs in the summer season, and the lead is the mentor. That is the whole set of facts about it, and I keep them here so that I do not have to look them up elsewhere.

**Stage.** The project is past the go decision and is in the working phase. The idea has been checked, the scope is agreed, and the effort now goes into building and testing in small steps. It is not finished, and I do not call it finished until the open points below are closed.

**What is done.**

- The idea was written down and the go decision was taken.
- The main pieces of equipment were listed, and I noted which of them could be controlled and which could not.
- I went through the earlier test notes on control and timing in [[Velferk kiln controller tests]] and took from them what applies here.
- I compared the humidity and ventilation notes in [[Zobanfond greenhouse notes]] with what the boatyard shed needs. The comparison was rough, but it was enough to set the first targets.
- I looked at [[Fupu greenhouse plan]] to see how cables and sensors could be laid out, and I reused the parts of it that fit.
- I read through [[Gokio level sensor log]] to judge whether the sensor is steady enough to trust.

**Open points.**

- The [[Ruthglaend dehumidifier]] needs a clean way to be switched on and off. I have not yet decided whether to do this with a simple relay or with something smarter.
- The [[Lelben heat exchanger]] has to be kept in step with the dehumidifier, or the two will fight each other. I want to write down a simple rule for which one has priority.
- The shared circuit is a worry. The [[Baerkstind band saw]] draws a lot when it starts, and I need to be sure that the automation does not trip the circuit when the saw is running.
- The level sensor sometimes gives odd readings after a long idle period. I need to decide how to filter them, or whether to ignore single readings that jump.
- There is no written fallback procedure yet. I want one page that says what to do by hand if the automation stops.

**How I work on it.** I do one small change at a time and test it before moving on. After each test I write a short line in the log, with what I changed and what happened. If a test goes badly, I go back to the last working state, and I do not try to patch forward. The mentor looks at the result at the end of each larger step, and I take their comments into the list of open points.

**What would make it a success.** The shed should hold its conditions without me going out to check it several times a day. The automation should be simple enough that I can explain it in a few sentences. When something breaks, I should be able to find the cause quickly and run things by hand in the meantime.

**Risks.** The main risks are the shared circuit, the sensor readings, and the two heat and moisture units working against each other. A smaller risk is that I spend too long on details and lose the summer window. For that reason I keep to the next action, and I leave the optional ideas for later.

When the next action is done, I will come back to this summary, update the stage and the open points, and set the new next action.
