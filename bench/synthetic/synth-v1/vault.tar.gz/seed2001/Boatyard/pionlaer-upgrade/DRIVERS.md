---
type: drivers
status: active
project: pionlaer-upgrade
area: boatyard
description: "Drivers about Pionlaer upgrade."
---

# Drivers of Pionlaer upgrade

## Costs

The Pionlaer upgrade is a project with the goal of an upgrade, set in the boatyard area. It started in 2024, runs in the winter season, and is led by the inspector. These notes cover the drivers behind it: why it exists, what limits it, what it costs, and how I will know it worked.

The main cost driver is labour time in the cold months. Winter is when the yard is quietest, so there is slack in the schedule, but the sheds are unheated and work goes slowly. I count cost in three groups:

- Materials: fasteners, sealant, cable, paint and replacement fittings.
- Labour: hours spent by the inspector and anyone who helps.
- Hire and disposal: lifting gear for short periods, and getting rid of old parts and waste.

The hidden cost is rework. If a first pass fails an inspection, the same job gets paid for twice. For that reason I would rather spend a little more on checking early than save on materials and redo work later. Small items tend to add up faster than large ones, so I log every purchase, even a single bag of screws.

Another cost is downtime. Anything that keeps a boat out of use longer than planned has a real price for the owner, even if no money changes hands in the yard. I keep the schedule tight on jobs that block a berth or a cradle.

## Maintenance

The upgrade has to leave the yard easier to maintain than before, not harder. That is one of the main drivers. If a new part needs special tools or is hard to reach, it counts against the project.

What I look at when choosing between options:

- Can the part be reached without removing other equipment?
- Can it be replaced with ordinary tools?
- Is there a plain way to inspect it by eye?
- Will it survive damp and salt for several seasons?

After the work, I want a short maintenance routine written down for each changed item: what to check, how often, and what a bad result looks like. The inspector leads the project, so these checks fit into the regular inspection rounds instead of becoming a separate chore.

Winter also helps here. Because the work happens in the quiet season, there is time to test things in place and to repeat a check a week later, when any slow leak or loose fitting would show itself.

I keep a simple list of items that will need attention in the first year after the upgrade, since new work often shows its faults early. Those are looked at first when spring starts and boats go back in the water.

## References

These are the sources I use for this project. They are my own working material, kept in the same vault.

- Earlier inspection notes from the boatyard, which show what failed before and why.
- The log of purchases from previous winter jobs, used as a rough guide for what things really cost.
- Manufacturer instructions that come with each new part, kept with the project papers.
- Photos taken before the work starts, so I can compare the condition afterwards.
- Notes from conversations with yard staff about what annoys them in daily use.

When two sources disagree, I trust the one closest to the actual boat: the photo, the measurement, or the person who works there every day. Written guidance is useful, but it was not written for this yard.

I also keep a short list of questions I could not answer from these sources. Each one gets looked at on site before the work reaches that step.

## Setup

The project began in 2024 and is set up as a winter job, which suits the yard. The goal is an upgrade, so the starting point is the current state of the equipment and the way it is used, and the setup phase is mostly about recording that.

Steps in the setup:

- Walk the boatyard with the inspector and list what is in scope.
- Photograph and measure each item before touching it.
- Decide the order of work, putting the safety-related items first.
- Gather materials before starting so work is not stalled waiting for deliveries.
- Agree who is on site on which days.

I set aside a clear, dry area for parts and tools. Cold and damp ruin small items quickly, so everything goes into labelled boxes. The plan is kept simple on purpose: a list of jobs, an owner for each, and a rough week for each. I do not build a complicated schedule, because weather moves everything anyway.

Success is measured against this setup. Because I record the start condition, I can say later whether each item is better, the same, or worse.

## Ideas

Some ideas I want to keep in mind, whether or not they make it into the work:

- Standardise fittings so fewer spare parts are needed on the shelf.
- Label every changed item with a simple tag stating the date of work, using only the year.
- Make a one-page checklist that the inspector can carry on rounds.
- Group similar jobs together to reduce setup time and tool changes.
- Ask yard staff for a short list of their top three daily annoyances and see if any can be fixed cheaply while the work is under way.
- Keep leftover materials in one labelled place for future repairs.

None of these is a commitment. They are options to check against the budget and the schedule once the main work is under control. The ones that reduce long-term maintenance get priority, since that matches the main drivers.

## Budget

The budget of Pionlaer upgrade is 1291.72 EUR.

This is a fixed ceiling, not a target to reach. The money has to cover materials, any short hire of equipment, and disposal. It does not cover my own time, which I treat as part of the yard's normal work under the inspector.

How I handle the budget:

- Keep a running list of every purchase as it happens.
- Hold back a part of the total for surprises, because old equipment often hides problems.
- Buy the safety-related items first, so they are never squeezed out at the end.
- Review spending at the end of each week of work.
- Stop and rethink if the spending runs ahead of the progress.

If the money runs short, I drop the nice-to-have ideas before touching anything related to safety or maintenance. A smaller job done properly is better than a bigger job done halfway.

Success on cost is simple: the work is finished inside the ceiling, with no unpaid bills left over for later.

## Observations

Things I have noticed so far, and things I want to watch:

- Work in winter is slower than planned, mainly because of cold hands, short daylight, and damp materials.
- Small fittings are the items most often missing at the start of a job.
- Staff notice problems earlier than any written inspection does.
- Photos taken before work are much more useful than memory when checking progress.
- Jobs that seem separate often turn out to be linked, so one repair exposes the next.

How success is measured, as I see it now:

- Each item in scope is finished and checked by the inspector.
- Spending stays within the budget.
- Every changed item has a short maintenance note.
- No safety issue from the work appears in the first season afterwards.
- Yard staff say that daily use is easier or at least no worse.

I add to this list as the project goes. When an observation changes a decision, I write down what changed and why, so I can learn from it the next time.

## Safety

Safety is the strongest constraint on the project. It overrides cost and schedule. If a job cannot be done safely in the current conditions, it waits.

Basic rules I follow:

- Nobody works alone on lifting, climbing or anything near a hull in a cradle.
- Wear suitable footwear, gloves and eye protection, and use hearing protection with loud tools.
- Keep walkways clear, especially when frost or wet makes floors slippery.
- Isolate and check power before touching any electrical equipment.
- Check lifting gear before each use and never exceed its rated load.
- Keep a first aid kit and a working phone on site.

Winter adds its own risks: ice on ramps, poor light, and tired people making mistakes in the cold. I plan shorter work blocks, allow breaks to warm up, and stop early when light fades.

The inspector leads the project, so the inspector has the final word on whether a task is safe to start. Any near miss gets written down the same day, with what happened and what will change, so the same mistake is not repeated.
