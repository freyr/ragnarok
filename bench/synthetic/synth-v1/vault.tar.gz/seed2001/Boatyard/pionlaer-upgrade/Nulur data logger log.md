---
type: log
status: active
project: pionlaer-upgrade
area: boatyard
description: "Log about Nulur data logger."
---

# Nulur data logger log

## Schedule

This log covers the routine checks on the Nulur data logger, the yellow unit that sits in the workshop at the boatyard. It has run on solar power since it was installed in 2015, so most of my upkeep is about light and cleanliness rather than batteries or mains cables.

| Interval | Task | Notes |
|---|---|---|
| Weekly | Look at the status light | Yellow casing is easy to spot from the bench |
| Monthly | Wipe the solar panel | Sawdust and salt haze build up fast |
| Every season | Check cable glands and seals | Damp gets in during the wet months |
| Yearly | Back up the stored readings | Copy them to the shared drive in the office |
| Yearly | Test the panel in poor light | Make sure it still charges on grey days |

Things I do when something looks wrong:

- Move any clutter away from the window above the unit so the panel gets light.
- Check that the panel cable is seated firmly.
- Note the date and symptom in this log before touching anything else.
- If readings have gaps, compare them with the days the workshop doors stayed shut.

## References

These are the things I keep close when I work on the logger:

- The paper manual in the blue folder on the workshop shelf. It is old, but it covers the basic setup.
- My own notes on the boatyard sensors, which list what each channel measures.
- The maintenance sheet pinned near the workshop door, where I tick off each monthly wipe.
- The photo set I took of the wiring when I last opened the case. It shows which lead goes where.

Quick facts for reference:

- Device: Nulur data logger
- Kind: data logger
- Area: boatyard
- Color: yellow
- Energy source: solar
- Year installed: 2015
- Location: workshop

## Background

The Nulur data logger was installed in 2015 and has been in the same spot in the workshop ever since. It is a data logger, which means its job is to record readings over time so I can look back at them later rather than guess. The boatyard is a harsh place for electronics: there is dust from sanding, damp from the slipway, and temperature swings between the cold mornings and the warm afternoons when the doors are open.

Choosing solar power was a practical decision. Running a mains cable across the workshop would have meant trailing wires near tools and timber, and nobody wanted a battery swap on the list of chores. The panel sits by the window and, with a little cleaning, keeps the unit going through most of the year. Winter is the weak point. Short days and low light mean the logger sometimes stops recording for a stretch, and I have learned to expect small gaps in the data then.

The yellow color was not chosen for style. It makes the unit easy to find among grey shelves, paint tins and coiled ropes, and it stops people from placing things on top of it. Several times a visitor has asked what the yellow box was, which is a good sign that it is visible enough.

Over the years I have kept this log to remember what I changed and when. The pattern is clear: nearly every fault traced back to a dirty panel, a loose connection or moisture, and almost never to the logger itself. That is why the schedule above is built around simple, regular habits.

Lessons so far:

- A clean panel solves more problems than any adjustment to settings.
- Keep the casing closed unless there is a real reason to open it.
- Write things down immediately, because memory of a fix fades within a week.
- Do not move the unit away from the window; light is what keeps it alive.

## Parts

The logger is a single self-contained unit, so the parts list is short. I keep it here so I know what to look at first when something fails.

- Serial number of Nulur data logger: SN-84318084
- Solar panel: mounted on the window side of the workshop, wired directly to the unit
- Casing: yellow, sealed, with cable glands at the base
- Storage: internal memory holding the recorded readings
- Status light: the quickest way to see whether the unit is alive

When ordering or asking for help, I quote the serial number above, since it is the only identifier I trust to be correct. Anything else printed on the casing has worn away or become hard to read after years of dust and handling.

If the panel ever has to be replaced, I will record the change in this log together with the year, and I will check that the new one fits the existing bracket and cable before taking the old one down. The glands are the part most likely to need attention first, because rubber ages quickly in damp air, so I keep a small bag of spare seals in the workshop drawer.
