---
type: summary
status: active
project: pionlaer-upgrade
area: boatyard
description: "Summary about Pionlaer upgrade."
---

# Summary of Pionlaer upgrade

## Checklist

This is the running list for the Pionlaer upgrade. The project is an upgrade, it sits in the boatyard area, it started in 2024 during the winter season, and the lead is the inspector. I tick items off here when they are finished and not before.

- [x] Agree the goal of the project: upgrade
- [x] Name the lead: inspector
- [x] Fix the area: boatyard
- [x] Record the start: winter 2024
- [x] Take the go decision (see Decisions)
- [x] Walk the yard once with the inspector and note what needs replacing
- [x] Sort the work into things that can be done in the cold and things that need a dry, warmer day
- [ ] Confirm that every tool on the Tools list is on site and working
- [ ] Review the Risks section with the inspector
- [ ] Review the Safety section with everyone who will work on site
- [ ] Close the open questions
- [ ] Do the next action

Stage right now: the project is past the go decision and in the preparation and doing phase. The planning is done, some of the groundwork is done, and the remaining items are mostly checks and answers I still need before the main work goes ahead.

## Tools

I keep the tool list short and practical. Anything that is not on site on the first working day costs a day, so I check the list early.

- Hand tools: spanners, sockets, screwdrivers, mallets, files and scrapers
- Power tools: drill, angle grinder, sander and a corded work light
- Lifting and moving: trolley jack, blocks, straps and a small hoist
- Measuring: tape, level, straight edge and a marker for labelling parts
- Cleaning: brushes, rags, buckets and a wet vacuum
- Paperwork: a clipboard with the inspection sheet, a pencil that works in the damp, and a camera for before and after photos

Habits that have paid off on earlier jobs:

- Label every removed part with tape and a marker, and photograph it before it comes off.
- Keep a single tray or box for fasteners from each area so they do not get mixed.
- Return borrowed tools the same day and write down who has them.
- Check cords and guards on the power tools before the job, not during it.

The tool check is still open on the checklist. I want to do it once with the inspector, because the inspector knows which items tend to be missing in winter.

## Open questions

These are the things I do not know yet. Each one should be answered before the main work starts, or turned into a decision with a reason.

1. Which of the older fittings can be reused, and which must be replaced outright? The walk with the inspector gave a first answer, but it was based on a visual check only.
2. How much of the work depends on the weather? Winter limits what can be done outside, and I have not yet decided which jobs to move indoors.
3. Who covers for the lead if the inspector is called away to another job during the project?
4. Is there enough covered space in the boatyard to stage parts as they come off, or do I need to arrange a temporary spot?
5. Do any of the supplies have a long delivery time? I would like a firm answer before I commit to a working order.
6. Should the finished work get a formal sign-off by the inspector, or is a note in this knowledge base enough? My leaning is a short formal sign-off.

When one of these is answered, I move it into Decisions with a short reason and remove it from this list.

## Overview

Pionlaer upgrade is a project with the goal of upgrade. It belongs to the boatyard area. It started in 2024, in the winter season, and the lead is the inspector.

In plain words: the Pionlaer needs bringing up to a better standard, and the work is being done in the boatyard over the winter, when there is less pressure on the yard and the schedule is easier to manage. The inspector leads because the work is as much about checking and judging condition as it is about fitting new things.

What is done so far:

- The goal, area, season and lead are all fixed.
- The go decision was taken.
- A first walk-through was done and the findings were written down.
- The work has been split into cold-weather and dry-weather jobs.

What is not done:

- The tool check.
- The review of risks and safety with the people involved.
- The open questions above.
- The main work itself.

The shape of the project is simple. First comes inspection and preparation, then the replacement and fitting work, then a final check by the inspector. I try to keep each stage small enough that I can stop at the end of a day with nothing half-done and unsafe.

## Risks

I list these so that I think about them before they happen, not after.

- **Weather.** Cold and damp slow the work and can spoil some materials and finishes. Mitigation: do the sensitive jobs on dry days and keep materials covered.
- **Hidden condition problems.** Once parts come off, something may turn out worse than the visual check suggested. Mitigation: allow time for surprises and ask the inspector to look at anything doubtful before going on.
- **Missing tools or supplies.** A gap can stop the job for days. Mitigation: finish the tool check and ask about delivery times early.
- **Lead availability.** The inspector leads the project and may be pulled away. Mitigation: settle who covers, and keep these notes current so someone else can pick them up.
- **Lost or mixed-up parts.** With many items removed, it is easy to forget where something went. Mitigation: labels, photographs and one box per area.
- **Scope creep.** An upgrade invites extra jobs. Mitigation: write any new idea down as a separate item and decide on it later, not in the middle of the work.
- **Rushing at the end.** Winter work tends to bunch up as the season ends. Mitigation: do not skip the final check to save a day.

## Safety

Safety is part of the plan, not an extra. The points below apply to everyone working on the project.

- Wear sturdy footwear with grip, gloves suited to the task, and eye protection when grinding, sanding or striking.
- Use hearing protection with the grinder and other loud tools.
- Keep walkways clear. Wet and frosty ground in a boatyard is slippery, so sweep or treat it before work starts.
- Never work under a load held only by a jack. Use blocks or stands and check they are stable first.
- Check straps, hoist and lifting points before each lift, and keep people clear of the area under a load.
- Keep cords off wet ground, and use equipment suited to damp conditions.
- Do not work alone on lifting jobs or at height. Tell someone where you are and when you expect to finish.
- Keep a first aid kit and a way to call for help close to the work area, and make sure everyone knows where they are.
- Stop work in bad weather, poor light or when anyone is too tired to work carefully.

I want the inspector to look over this list, since the inspector will know the yard's own rules and can correct anything that does not fit.

## Next action

The next action of Pionlaer upgrade is NX-7459.

I keep this to one item so that the next session starts without any deciding. Once it is done, I update the checklist, move any answered question out of the open list, and write the following next action here.

## Decisions

- **Go decision.** The go decision date of Pionlaer upgrade is 2023-08-15. From that point the project was treated as approved, and the planning moved on to the inspection and preparation.
- **Lead.** The inspector leads the project, because the work depends on judging condition and signing off the result.
- **Season.** The work is done in winter, when the boatyard is quieter. The cost is the weather, which is handled by sorting jobs into cold and dry ones.
- **Scope.** The project is an upgrade, not a rebuild. Anything beyond that is written down separately and decided later.
- **Method.** Label and photograph everything that comes off, and keep fasteners boxed by area.
- **Pending.** Questions on reuse of fittings, cover for the lead, staging space, delivery times and formal sign-off are still open. Each will be recorded here once settled, with a short reason.
