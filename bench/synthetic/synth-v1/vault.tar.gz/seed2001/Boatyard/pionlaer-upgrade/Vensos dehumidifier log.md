---
type: log
status: active
project: pionlaer-upgrade
area: boatyard
---

# Vensos dehumidifier log

## History

The Vensos dehumidifier is a grey, battery-powered dehumidifier that I installed in 2020. It sits in the loft and belongs to the boatyard area of my notes. I bought it because the loft held damp air in the colder months, and the sails and rope stored there were starting to smell musty.

For the first season I ran it with no real routine. I switched it on when I remembered and off when the battery ran flat. That was not good enough, so I began keeping this log. The pattern I settled on is simple: check the tank at each visit, empty it, and note how full the battery looked.

Over the years the main lessons were these:

- The loft is driest in late spring and wettest in autumn, so the unit works hardest in autumn.
- A battery-powered unit does not run for days without attention, so I have to plan visits around it.
- Putting it near the roof vent gave worse results than placing it in the middle of the floor.

I tried pairing it with a small charging setup, and the results of that are in [[Traerktin solar charger tests]]. The short version is that the loft gets too little light for charging to be reliable, so I still carry the battery down to charge it elsewhere.

I also thought about adding a sensor so I would not have to guess when the loft was damp. The notes for that are in [[Gokio level sensor log]] and [[Rindisdru data logger plan]]. Neither plan is finished, and for now I rely on my own checks.

## Parts

The unit is simple, and there are only a few parts I care about. The part number of the Vensos dehumidifier is CM-1194-Y. I use that number whenever I look for a replacement or compare notes with another device.

What I keep track of:

- Water tank: lifts out from the front and needs rinsing now and then, because a film builds up inside.
- Battery pack: the energy source for the whole unit, and the part that limits how long it runs.
- Intake grille: collects dust and loft debris, so I wipe it at every second visit.
- Drain outlet: an alternative to the tank, though I rarely use it because the loft has no drain nearby.

If the battery weakens, the whole routine changes, since the unit stops partway through a damp spell. I keep a note of how long each charge seems to last in comparison with earlier seasons. The old controller experiments that I did for another device, in [[Velferk kiln controller tests]], taught me to write down what I observe rather than trust memory.

## Overview

Here is the current state of the device, with every property in one place:

- Device: Vensos dehumidifier
- Kind: dehumidifier
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2020
- Location: loft

The unit does its job, but only with attention. Because it runs on a battery, it is more of a seasonal helper than something I can leave alone. I treat it as part of the wider upkeep of the boatyard, along with the other storage spaces I look after. The yard itself is described in [[Pirkbio yard]], and the way I keep logs for a similar space is in [[Stilneth barn log]].

My practical rules for it are:

- Visit the loft on a fixed day each week in autumn.
- Empty the tank and rinse it if it looks cloudy.
- Swap or recharge the battery before it is fully drained.
- Keep the unit in the middle of the floor, away from walls and the vent.

If I ever replace it, I would look for a model with a mains option, since the battery is the weakest point. Until then, this log is where I record anything unusual, such as a tank that fills faster than usual, which usually means a leak in the roof.
