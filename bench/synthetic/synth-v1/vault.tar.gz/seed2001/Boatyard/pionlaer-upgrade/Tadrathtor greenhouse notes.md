---
type: note
status: active
project: pionlaer-upgrade
area: boatyard
description: "Note about Tadrathtor greenhouse."
---

# Tadrathtor greenhouse notes

## Background

The Tadrathtor greenhouse is a greenhouse in the boatyard area. It is a large structure, built in 2002, and it sits at ground level, so there are no steps or ramps to deal with when moving pots, soil bags or tools in and out. The main glazed face looks west. Most of what I know about the place comes from walking through it, so these notes are a mix of memory and things I have written down on the spot.

The boatyard around it is a working place. There are stacked hulls, tarpaulins, rope and old paint tins, and the greenhouse has ended up as a quiet corner among all that. It was probably built to give the yard staff somewhere to start seedlings and keep tender plants through the cold months. Over the years it has drifted into being a shared growing space, and it is now mostly mine to look after.

I keep this note as a working reference. It covers what I use, what I have seen, what goes wrong, and what I plan to do. I update it whenever I learn something new, and I try to keep entries short and practical rather than neat. If something here contradicts what I see on site, the site wins and the note gets corrected.

The west orientation shapes almost everything. Mornings are cool and fairly dim inside, and the afternoon and evening bring strong low sun straight through the glass. That means the warmest hours come late in the day, which is the opposite of what I first expected. Plants that dislike late heat need to be placed toward the back or shaded.

## Tools

I keep a small, fixed set of tools in the greenhouse so I do not carry things back and forth across the yard. Anything that lives here has a marked spot, and anything that does not have a spot gets taken home.

- A hand trowel and a narrow transplanting trowel, both kept on the hooks near the door.
- Pruning snips for soft stems, and a stronger pair of secateurs for woody material.
- A watering can with a fine rose, plus a hose with an adjustable spray head.
- A bucket for mixing feed, kept upside down by the tap so it does not collect debris.
- A soil scoop made from a cut-down plastic bottle, which works better than anything I bought.
- A hand-held thermometer with a min and max memory, used as a cross-check on the fixed one.
- A moisture probe for the larger containers.
- A stiff broom and a dustpan for the floor, and a soft brush for glass and bench surfaces.
- A headtorch, because the greenhouse is not wired for good evening light.
- A notebook and a pencil in a sealed tub, since pens fail in the damp.

The tools that get the hardest use are the snips and the watering can. I wipe the blades of the snips with a cloth after each session and a little oil once the work is finished. The probe is only a rough guide; I trust my finger in the soil more.

I have considered a proper bench-top propagator and a small fan, but I only want them if the simpler measures fail. For now the tool list stays short.

## Observations

The greenhouse behaves in a very regular way through the day, and I have logged enough visits to describe it.

Because it faces west, the glass catches the sun in the afternoon. The temperature inside climbs slowly through the middle of the day and peaks well after midday. The back wall and the floor hold some of that warmth, so the evening stays mild for a while after the sun drops. By morning the place is cool again, and the early hours are the coldest part of the cycle.

Being at ground level helps in some ways. The floor stays cooler than a raised deck would, and the soil beneath the paving gives a stable base temperature. In heavy rain, though, water can run in under the door if the drain outside is blocked, so I check it after storms.

Other things I have noticed:

- Condensation forms on the inner glass in the morning and clears by late morning.
- The boatyard brings dust and fine grit, which settles on leaves and slows growth if I let it build up.
- Wind from the west pushes against the door seal, and the door rattles in strong gusts.
- Birds sometimes perch on the roof ridge, and the droppings stain the glass.
- The corner nearest the door is the draughtiest and the coolest.
- The far corner is the warmest and the driest, and plants there need water more often.

Here is a quick summary of how I think of the zones inside.

| Zone | Light | Warmth | Best use |
|---|---|---|---|
| Door end | Moderate | Coolest | Hardening off seedlings |
| Middle benches | Good | Even | General growing |
| West glass edge | Very strong late | Hottest late | Sun lovers only |
| Back corner | Gentle | Warm and dry | Cuttings and storage |

## Problems

The problems here are not dramatic, but they come back, so I list them honestly.

The first is overheating in the late part of the day. Strong western sun through large panes makes the interior too warm for tender leaves, which scorch at the edges. Vents help, but only if I open them in good time. If I arrive after the heat has built, it is already too late for the plants on the glass edge.

The second is damp. Morning condensation drips from the roof bars onto the benches below, and some bench positions stay wet for a long time. That invites mold on soft seedlings and on any cuttings left too close together.

The third is dirt and grit from the boatyard. Sanding dust and fine particles drift in through the vents and settle on everything. Left alone, the glass turns hazy and the light drops.

The fourth is the door. The seal has worn, and in west wind the door either rattles or lets a draught through. I have wedged it with a folded piece of rubber, which is a poor fix.

Smaller issues:

- One bench leg is slightly short and the bench rocks.
- The tap near the door drips slowly and leaves a wet patch.
- Slugs come in along the base of the wall during wet spells.
- The gutter on the sheltered side clogs with leaves.

None of these has caused a total loss, but together they take up time. I rank them in the Risks section by how much damage they could do if ignored.

## Costs

I do not track exact prices here, because they change and I do not want stale figures in my notes. Instead I record the shape of the spending and where it tends to go.

The recurring costs are small. Compost, feed and replacement pots are the main items, and I buy them in bulk when I can store them dry. Shading material is a one-off purchase that I replace every few seasons when it gets brittle. Glass cleaning costs only time and a little detergent.

The larger costs are repairs. A new door seal, a replacement pane if one cracks, and a better drain outside would all be sensible spending. I have put them in order of urgency rather than price.

How I think about spending:

- Fix anything that lets water in before spending on anything decorative.
- Prefer cheap, durable materials over fancy ones.
- Reuse containers, labels and stakes wherever possible.
- Never buy a gadget until I have tried a manual method for a full season.
- Keep receipts in the notebook tub, in case the lease or boatyard office asks about improvements.

Because the greenhouse is on leased ground, I am careful about anything fixed or permanent. A freestanding shade cloth or a movable bench is a better investment than anything bolted down. If I ever leave, I want to take my spending with me as far as possible.

## Schedule

My routine follows the way the greenhouse warms up, so I do the work that matters at the times it matters.

Morning visit: open the vents early, before the glass starts to warm. Check for condensation and wipe the worst of it. Water the plants that need it, since morning watering lets leaves dry out before evening.

Midday visit, when I can manage it: look at the thermometer and adjust vents or shading. This is the point where I decide whether the west glass needs a cover that afternoon.

Late visit: check the hottest corner, close the vents once the temperature begins to drop, and shut the door firmly against the wind. I leave a little ventilation in warm weather so the air does not go stale.

Weekly jobs:

- Sweep the floor and clear fallen leaves.
- Check the drain outside the door.
- Inspect plants for pests and remove bad leaves.
- Turn pots a little so growth stays even.
- Top up the feed bucket supply.

Seasonal jobs:

- Wash the glass thoroughly in spring and autumn.
- Replace or repair shading before the strongest sun.
- Clear the gutter before the wet months.
- Review the bench layout and move things around if a zone has changed.

I try not to overplan. If the weather turns, the schedule bends to fit it.

## Maintenance

Maintenance is mostly about keeping water, dirt and heat under control. The greenhouse was built in 2002, so it has some age on it, and small repairs matter more than they would on a newer structure.

Glass: I wash the panes with a soft brush and clean water, and a little mild detergent when the grime is heavy. I avoid abrasive pads because they scratch. I check the clips and glazing bars for rust and loosened fixings while I am up close.

Door and seal: I inspect the seal each season. When I replace it, I will choose a thicker profile that copes with the west wind. Until then I keep the hinges oiled so the door closes without force.

Floor and drainage: The ground level floor is simple to sweep, but it needs the outside drain kept clear. I rake out leaves and grit after storms. If water pools inside, I find the cause before it becomes a habit.

Benches: I tighten the frames and fix the rocking leg. I scrub the surfaces with a weak disinfectant solution between crops, which reduces disease carried over.

Tap and hose: I fix the dripping tap with a new washer and drain the hose before frost.

Here is the small configuration I use as a reminder for how the vents should behave through the day. It is a note to myself, not a real controller.

```
greenhouse: tadrathtor
vents:
  morning: open early, before glass warms
  midday: adjust by thermometer
  late: close slowly as temperature drops
shade:
  west_glass: cover on strong afternoons
door:
  windy: latch firmly, check seal
```

## Risks

I rank the risks by how much harm they could do and how likely they are.

Heat damage is the most likely risk. A late hot afternoon with the vents shut can scorch a whole bench. The western face makes this a regular threat rather than a rare one. The remedy is early venting and shade, and I should never leave the greenhouse in warm weather without checking the vents first.

Water ingress is the next risk. A blocked drain or a heavy storm can send water under the door and across the floor, which spoils stored soil and soaks the lower shelves. Keeping stored items off the ground reduces the loss.

Wind is a third risk. The west face takes the full weather, and a loose pane or a door left unlatched could be damaged in a gale. I should secure the door and check for loose glazing clips each season.

Other risks:

- Disease spreading in damp, crowded benches.
- Pests entering through open vents or the door gap.
- Frost on a cold clear night, since the glass loses heat quickly.
- Boatyard activity nearby, such as sanding, spraying or moving heavy loads, which could damage glass or drift onto plants.
- The lease: if the arrangement ended, I would lose access, so I keep movable assets and records separate.

I accept the low risks and spend effort on the first three. A written checklist at the end of this note helps me avoid forgetting the basics.

## References

These are the sources I rely on, all of them personal or local rather than formal.

- My own notebook of visits, kept in the sealed tub in the greenhouse, which holds the day-by-day record that this note summarises.
- Photos I took of the glass, the door seal and the drain, kept in my phone album under a greenhouse label.
- Conversations with the boatyard staff, who remember how the building was used before I took it over and who know about the drain and the roof.
- The lease paperwork, which sets out what I may change on the site. The reference is in the Admin section.
- Seed packets and plant labels, which give the growing guidance I follow for each crop.
- General gardening books on my shelf at home, mostly used for pest identification and watering advice.

I do not treat any of these as final. When a book disagrees with what I see in the greenhouse, I trust the observation, since the west orientation and the yard dust make this place unusual. I try to note the source whenever I copy advice into this file, so later I can tell what was my own experience and what was borrowed.

If I find a good guide on ventilation or shade, I will add it here with a short comment on whether it matched what I saw in practice.

## Safety

Safety here is mostly common sense, but the boatyard setting adds a few hazards.

Glass is the first. Panes can crack, and broken glass on a ground level floor is easy to step on. I wear sturdy shoes and gloves when handling any damaged pane, and I sweep carefully rather than picking up shards by hand. Cracked panes get taped and replaced promptly.

Heat is the second. On a hot afternoon the large west facing glass makes the interior uncomfortably warm. I drink water, avoid long stints inside at the hottest hours, and keep the door open for air when working.

Wet floors are the third. Condensation and spilled water make the paving slippery, so I keep a clear path and wipe up puddles.

Other points:

- Store feed, sprays and cleaning products in a closed box, away from food and children.
- Read labels and mix products in a ventilated space.
- Keep the path to the door free of hoses and tools.
- Take care with ladders when washing the roof, and never work alone on a ladder in strong wind.
- Watch for moving vehicles and loads in the boatyard when crossing to the greenhouse.
- Switch off and unplug any electrical item before cleaning near it, and keep sockets dry.

I keep a basic first aid kit in the tub, and I make sure someone at the yard knows when I am working here late. The headtorch stays in the tub so I am never stuck in the dark.

## Admin

The greenhouse is on leased ground, so a little paperwork matters. The lease reference of Tadrathtor greenhouse is LR-487794. I quote it whenever I contact the boatyard office about repairs, access or changes to the structure.

Administrative points I keep in mind:

- Any permanent change to the building needs permission, so I ask first and keep a written reply.
- Movable items such as benches, shading and pots are mine to take away.
- The greenhouse is in the boatyard area, so yard rules on access, noise and hours apply to me as well.
- I keep copies of the lease papers at home, not only in the greenhouse, since damp ruins paper.
- I record who gave permission for what, and when, in the notebook.

If a repair is needed that I cannot do myself, such as a cracked pane or a failed frame section, I report it to the yard office with the reference and a photo. I prefer to send a short written message so there is a trail.

At the end of any season I review whether the arrangement still suits me. The place is large enough that it takes real time, and I want to be sure I can give it that time before committing to another year of projects.

## Ideas

These are things I might try, none of them urgent.

Shade and heat: A removable shade cloth fixed on the outside of the west glass would cut the late heat. I would like something that rolls up easily, so I can open it on dull days. A lighter wash applied to the glass in summer is another option, though it is harder to remove.

Ventilation: A simple automatic vent opener that works from temperature alone, with no electricity, would solve the problem of arriving late. I would test one on a single vent first.

Water: A rain barrel fed from the gutter would give me soft water for seedlings and reduce use of the tap. It would also help with the gutter overflow.

Layout:

- Move the sun lovers to the west glass edge and keep leafy crops at the back.
- Add a low shelf at the door end for hardening off trays.
- Build a small potting station near the tap so I do not walk across wet floor.
- Mark the zones on the floor so I remember what suits each area.

Wind: A heavier door latch and a better seal would stop the rattling.

Growing: I might trial a few heat-tolerant crops in the hot corner, and treat the first season as an experiment. I also want to try a simple record of what thrives where, so the layout improves each year rather than staying a guess.

## Supplies

I keep a short list of consumables so I can see at a glance what to restock. I do not record quantities, only whether the stock feels low.

- Compost and a lighter seed mix for sowing.
- General feed and a gentler feed for seedlings.
- Pots, trays and propagator lids in a few sizes.
- Plant labels and a waterproof marker.
- Garden twine and soft ties for supports.
- Canes and stakes, which I reuse for several seasons.
- Mild detergent for glass and a weak disinfectant for benches.
- Replacement washers for the tap.
- Shade material and clips, kept dry in the tub.
- Sticky traps and a gentle pest spray for emergencies.
- Gloves, spare cloths and rubbish sacks.
- Rubber strip for the door seal, to be fitted when I have time.

Storage matters as much as stock. Dry goods go on raised shelves, away from the ground level floor, so water coming in under the door cannot reach them. Sprays and cleaners go in a closed box. Anything that spoils in damp, such as paper labels or seed packets, goes in a sealed tub.

I check supplies at the start of each season and again before the cold months. If I notice something running low during a weekly visit, I write it in the notebook straight away, so I do not rely on memory.

## Checklist

A short list I run through at each visit, so the basics are never missed.

Arrival:
- Look at the door, seal and glass for new damage.
- Check the outside drain and the gutter.
- Read the thermometer and note the min and max.

Plants:
- Water where needed, aiming at the soil rather than the leaves.
- Remove dead leaves and any sign of mold.
- Check for pests, especially slugs near the wall.
- Turn pots and rearrange anything too close to the west glass.

Climate:
- Open vents early on warm days.
- Apply shade to the west glass on strong afternoons.
- Close vents gradually as the evening cools.

Housekeeping:
- Sweep the floor and wipe wet patches.
- Return tools to their hooks and clean the snips.
- Put stored items off the ground.
- Tighten the door latch before leaving.

Records:
- Write a line in the notebook about what I saw and did.
- Note any supply running low.
- Mention any repair that needs to go to the yard office with the lease reference.

If I only have a few minutes, I do the climate items first, since heat and damp cause the most damage in the least time.
