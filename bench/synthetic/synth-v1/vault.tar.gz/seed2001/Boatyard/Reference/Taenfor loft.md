---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Taenfor loft."
---

# Taenfor loft

## Overview

Taenfor loft is a loft in the boatyard area. It is a large space, built in 2018, and it sits below ground. Its orientation is west. That last detail sounds odd for a room under the surface, but the west side is where the access stairs and the one narrow light well are, so it still matters when I plan anything there.

These are the basic properties, kept in one place so I do not have to hunt for them:

- Kind: loft
- Area: boatyard
- Orientation: west
- Size: large
- Year built: 2018
- Floor: below ground

I use the loft mainly as dry storage for things that come out of the boatyard and should not sit in the weather. Because it is large, it holds a lot, but a large space below ground also collects damp and stale air if I ignore it. Most of what follows is about keeping that under control.

## Maintenance

Being below ground is the main fact that shapes the upkeep. Water and humidity are the problems, not heat or sun. The west orientation gives a little afternoon light through the light well, which helps slightly with drying near the stairs, but the far end of the loft gets nothing.

Routine work I do:

- Walk the whole loft and look at the floor along the walls for dark patches or standing water.
- Check the corners and the underside of shelves for mould, which shows first where air does not move.
- Run the dehumidifier and empty the tank before it fills, since a full tank just stops the machine.
- Open the access door at the west end on dry days to let the air change.
- Wipe down metal items and re-oil anything that rusts easily.
- Keep everything off the floor, on pallets or shelving, so air can pass underneath.

After heavy rain I do an extra check the same day. The boatyard area is low and drains slowly, so water can come toward the loft faster than I expect. If I find moisture, I move stored items first and deal with the source afterward. Cardboard and rope are the first things to suffer, so I keep those on the highest shelves.

Once a season I clear a section completely, sweep it, and look at the walls and ceiling joints properly. Doing it one section at a time means the loft is never entirely torn apart. I write down what I found in the same notebook I use for the other boatyard spaces.

## Background

Taenfor loft was built in 2018 as part of the boatyard, and it was designed as a below-ground loft rather than a raised one. The idea was to have a large, steady space that stays cooler through the year and keeps stored material out of sight. The size was a deliberate choice: the yard needed one big place instead of several small ones.

The cost of that choice is the damp. Being below ground means the walls are in contact with the earth, and moisture comes through slowly even when nothing looks wrong. Over the years since 2018 I have learned which parts of the loft stay dry and which do not. The area near the west stairs is the driest. The deepest corner is the worst.

I have thought about whether the layout could be better. Moving the heavy items closer to the stairs would make loading easier, but it would also put them in the busiest zone. For now I keep heavy things in the middle, light and delicate things near the west side where the air is better, and anything I rarely use at the far end on raised pallets.

The loft has never been a place to work in for long. It is for storing and retrieving, so I keep visits short and organised, with a list of what I need before I go down.

## Checklist

Before I leave the loft after a visit:

- Dehumidifier running and tank emptied
- Floor checked for water
- Nothing stored directly on the ground
- Light switched off
- Access door at the west end closed and latched
- Items I took out written down, so I know what is missing

Seasonal additions:

- Clear and sweep one section
- Inspect walls and ceiling joints
- Re-oil metal tools and fittings
- Check the shelving for rust or sagging
- Move cardboard and rope higher if any damp shows

If anything on the list fails twice in a row, I note it and deal with the cause instead of repeating the same fix.

## Measurements

The numbers I keep for Taenfor loft are mostly about the room itself and its air. The measured humidity of Taenfor loft is 35.37 %. I take that reading with the same hygrometer, placed at the same spot on a middle shelf, so that readings can be compared with each other over time.

Other facts that act as reference points:

- Size: large
- Floor: below ground
- Orientation: west
- Year built: 2018

I take humidity readings at the stairs end and the far end as well, because the numbers differ between them. The far end is usually the higher one. If the middle reading starts climbing, that is my signal to check the dehumidifier and the floor before anything gets damaged. I write each reading in the notebook with a short note about the weather, since rain in the previous day or two changes the result noticeably.
