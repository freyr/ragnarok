---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Daeszes solar charger."
---

# Daeszes solar charger

## Costs

The Daeszes solar charger is a grey solar charger that I installed in 2020 in the barn, for the boatyard area. Its energy source is battery, so it does not feed anything directly from the mains. I keep the costs here as notes on where money goes, not as exact prices, because I never wrote the receipts down in one place.

The main cost was the unit itself and the mounting work in the barn in 2020. Since then the running cost has been small. The charger keeps the battery topped up, and I only spend time on it: wiping dust off the panel surface, checking the cable ends, and looking at the battery once in a while.

If the battery needs replacing, that will be the next real expense. I should plan for it before the winter work in the boatyard starts, when the barn is used most.

Things I want to remember when thinking about cost:

- The device is old enough (installed 2020) that a repair may cost more than it is worth.
- A second charger would only make sense if the load in the barn grows.
- Tests on other sites help me decide what to buy next. See [[Krithdel solar charger tests]] and [[Pertirk greenhouse tests]] for how similar setups behaved.

## Measurements

These are the facts I have measured or recorded for the Daeszes solar charger.

- Kind: solar charger
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2020
- Location: barn
- Measured power draw of Daeszes solar charger: 791.68 W

The power draw is the figure I would use when working out how much the battery has to supply. I only took one reading, so I treat it as a rough guide and not a fixed rating.

To get better data I want to log the readings over several weeks, which is what [[Rindisdru data logger plan]] is meant to cover. If I ever extend power to the outbuildings near the water, the numbers will also feed into [[Nirsan pond plan]].
