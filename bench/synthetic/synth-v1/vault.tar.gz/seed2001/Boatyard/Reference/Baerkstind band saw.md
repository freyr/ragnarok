---
type: reference
status: active
project: reference
area: boatyard
---

# Baerkstind band saw

## Setup

The Baerkstind band saw is a band saw that lives in the boatyard area. It is green, runs on a battery, and was installed in 2022. Its location is the pond, which means the pond side of the yard, on the covered slab near the water's edge. I keep this note as a working reference for myself, so it is plain and practical.

The saw stands on a heavy steel stand bolted to the slab. The green paint is the original factory finish, and it is easy to spot from the slipway. I can see it from the pond gate, which is handy when I want to check whether anyone left it uncovered.

Because it is battery powered, there is no cable to trip over and no need to run an extension lead across wet ground. That was the main reason I chose it for the pond location. The trade-off is that I have to manage the charge state and keep the battery dry. Both points come up again in the checklist and safety sections.

The table below is a quick summary of the properties.

| Property | Value |
|---|---|
| Name | Baerkstind band saw |
| Kind | band saw |
| Area | boatyard |
| Color | green |
| Energy source | battery |
| Year installed | 2022 |
| Location | pond |

## History

The saw was installed in 2022. Before it arrived, all curved cuts for planking stock, knees and small templates were done with a hand jigsaw or sent out. That was slow, and the edges came back rough. Once the plan for the pond side of the yard took shape, a band saw was the first machine I wanted there.

The first season was mostly about learning the saw. I found out how much the blade wanders in thick oak and how much better it behaves with a slower feed. I also learned that damp air around the pond makes the table surface bloom with surface rust faster than I expected. A wax routine fixed most of that.

Later I compared how the saw sat against other layouts. The notes in [[Kandston workshop plan]] describe an indoor arrangement where a band saw would sit beside the bench. I decided against moving the Baerkstind there, because the pond location lets me cut long stock with space on both sides. I still think that was right.

Heat and drying were a separate topic. Some of my thinking on warm air and wood storage came from [[Gilsiond heat exchanger study]], which I read while planning how to dry the offcuts. It had little to do with the saw itself, but it shaped where I stack the cut pieces afterward.

## Tools

These are the tools and supplies I keep with the saw. Everything lives in a small lidded box on the stand's lower shelf.

- A spare blade, wrapped, in the same width as the one fitted.
- A soft brush for clearing dust from the wheels and the guide area.
- A stick of paste wax for the table.
- A small hex key set for the guide adjustments.
- A push stick, cut from offcut ply, hanging on a hook by the stand.
- A rag and a little light oil for the tensioning screw.
- A plastic cover that fits over the whole saw.

For marking work I use a pencil and a flexible batten. For measuring I use a steel rule and a try square. None of those stay at the saw, because they walk off. They live in the yard's main tool cabinet.

The battery has its own small shelf under cover and is not stored on the saw. I take it to the charger at the end of a working session. The charger sits inside the shed, away from the pond, so it never sees spray.

If I need to sharpen or reshape something near the saw, I do it at the bench, not at the stand. The saw area is for cutting only, which keeps the dust down and keeps the blade guides clean.

## References

These are the notes and sources I check when something about the saw, or the space around it, needs a decision.

- [[Kandston workshop plan]]: the indoor layout idea, useful for comparing where machines could go.
- [[Gilsiond heat exchanger study]]: background on warm air and drying, which I used for planning offcut storage.
- [[Lelben heat exchanger]]: the heat unit note, which matters because I keep the battery charger in the same shed and want to avoid heat build-up around it.
- [[Taenfor loft]]: where I store spare blades and the manual, kept dry and out of the weather.

Beyond my own notes, the saw's printed manual is in the loft. I only open it for the blade-tension chart and the guide setup diagram. Everything else I have learned by using the machine, and I have written it into this note.

When a question is about the saw itself, I look here first. When it is about the space, the drying of cut stock, or the shed, I follow the links above. I try to keep this note focused on the machine and let the linked notes carry the surrounding detail, so nothing is written twice.

## Observations

Things I have noticed in regular use, in no special order.

The saw cuts cleanly in softwood at almost any feed speed. In hardwood it needs a slower, steady push, and the battery drains noticeably faster. If I have a long run of oak to cut, I plan for a battery swap partway through or I split the work over two sessions.

The blade tracks well when the tension is right and badly when it is not. A blade that is too loose wanders, and a blade that is too tight makes the wheels sound strained. I set tension by feel and by the chart, and I recheck it after the first few cuts of a new blade, since a new blade settles in.

Damp is the constant enemy. Even under cover, the pond air leaves a film on the table in a day or two. A coat of wax and the plastic cover solve it. Without the cover, I find rust spots on the table and wheels within a short time.

The green finish holds up well, though it chips at the edges of the stand where tools get set down. I touch these up when I see them, mainly to stop rust creeping under the paint.

Sound and vibration are a good early warning. When the saw starts to hum differently, something is usually loose or the blade is dull. I stop and check right away.

## Parts

The serial number of the Baerkstind band saw is SN-47994185. I keep it here so I can quote it when asking about spares or support.

The main parts I track are these.

- **Blade:** the cutting band. It is the part that wears out first, and I keep one spare.
- **Wheels:** upper and lower, rubber-tyred. They need brushing clean regularly, as dust packs onto the tyres.
- **Guides:** the upper guide assembly sits above the work and moves up and down. It should sit just clear of the stock.
- **Table:** cast, flat, waxed. It tilts for angled cuts.
- **Tension screw:** at the top, set by hand. A drop of light oil keeps it free.
- **Battery:** the power source. Removable, stored under cover, charged indoors.
- **Stand:** steel, bolted to the slab, painted green to match the saw.
- **Cover:** plastic, fits over the whole machine.

If a part fails, I note which one and when, in my yard log, not here. This section is only the stable description of what the machine is made of and its serial number.

## Lessons

Several things I would tell myself if I were setting the saw up again.

First, put the saw where long stock has room on both sides. At the pond location I have that, and it makes cutting long curved pieces far easier than it would be in a cramped shop. The thinking in [[Kandston workshop plan]] reminded me how much floor a band saw actually needs.

Second, a battery saw demands habits. Charge at the end of every session, never at the start. A flat battery on a dry morning wastes the best working light.

Third, do not leave the saw uncovered near water, even for a short break. The cover takes seconds to put on and saves a lot of cleaning.

Fourth, slow down in hardwood. Forcing the cut wears out the blade and the battery, and it spoils the line. A steady feed gives a better edge and saves sanding.

Fifth, keep the surrounding area tidy. Offcuts and dust gather quickly, and a cluttered floor around a moving blade is how accidents start. I stack offcuts away from the saw as soon as a session ends, using the drying ideas from [[Gilsiond heat exchanger study]] to decide where.

Last, write things down. This note exists because I kept forgetting small details, such as the blade type and how I set the guides.

## Checklist

Before each session:

- Check that the battery is charged and fits firmly.
- Look over the blade for cracks, missing teeth or rust.
- Brush dust from the wheels and the guide area.
- Check blade tension and tracking by turning the wheel by hand.
- Set the upper guide just above the stock.
- Clear the floor and the table of offcuts.
- Put the push stick within reach.

After each session:

- Switch off and remove the battery.
- Brush the saw clean, including under the table.
- Wipe the table and add wax if it looks dry.
- Ease the blade tension if the saw will sit for a long time.
- Carry the battery to the charger in the shed.
- Put the plastic cover over the saw.
- Hang up the push stick and close the tool box.

Now and then:

- Oil the tension screw lightly.
- Touch up chipped green paint on the stand.
- Check the stand bolts for looseness.
- Check that the spare blade is still wrapped and dry in the [[Taenfor loft]].

## Open questions

A few things I have not settled yet.

I do not know whether a larger battery would be worth it. The current one is fine for ordinary work, but long hardwood sessions drain it quickly. I would like to find out whether a second battery, kept charged and ready, is the more sensible fix.

I am unsure about the best place to keep the charger. At the moment it sits in the shed, which shares space with the heat unit described in [[Lelben heat exchanger]]. I want to confirm that the warmth there is not bad for the battery over time, and whether a cooler spot would be better.

I have not decided whether to build a small roof extension over the saw. The plastic cover works, but a proper overhang would keep spray off the machine and give me shelter while cutting in poor weather.

I also wonder whether the guides need a better setup for tight curves. I sometimes get slight burning on the cut when I turn sharply. It could be the blade, the feed, or the guide gap. I need to test each in turn and write the result here.

Finally, I would like to learn if dried offcuts from this saw are better stored in the loft or in the yard stack, and I may revisit the ideas in [[Gilsiond heat exchanger study]] for that.

## Safety

The saw is a simple machine, but the blade is always dangerous. These are my rules.

- Always remove the battery before touching the blade, changing it, or cleaning near it. With a battery saw this is the surest way to make sure it cannot start.
- Keep fingers well clear of the blade line. Use the push stick for any narrow piece.
- Set the upper guide close to the work. A high guide leaves too much blade exposed.
- Wear eye protection and hearing protection. Dust and chips fly, and the cutting noise adds up over a long session.
- Do not cut when the ground is wet and slippery. The slab by the pond can get slick, and a slip near a moving blade is serious.
- Keep the battery dry. Never charge it outdoors, and never store it where spray can reach it.
- Do not cut stock that is too small to hold safely. Use a clamp or a jig, or choose another tool.
- Stop at once if the blade makes an odd noise, jumps, or starts to wander badly.
- Keep children and visitors away from the saw while it is in use.
- Never leave the saw switched on and unattended, even for a moment.

If I am tired or distracted, I do not use the saw. That is the simplest rule and the one I most need.

## Costs

I do not record exact prices in this note, only the cost pattern.

The biggest cost was buying the saw itself in 2022, and that is long past. Since then, the running costs have been small and steady. The main recurring items are blades, which wear out with use and need replacing from time to time, and wax and light oil, which last a long time.

The battery is the item most likely to become a larger cost. Over the years it will lose capacity, and replacing it will be a real expense. This is the main reason I treat it carefully, keeping it dry, charging it indoors, and not letting it sit empty for long.

Paint touch-ups are cheap. A small tin of green paint lasts many seasons, and the cost is mostly my time.

There is also a hidden cost in rust. If I skip the cover and the wax, I pay for it later in cleaning and in damaged parts. The cover and the wax are cheap insurance.

If I add a roof over the saw, as mentioned in the open questions, that would be a one-off cost, mostly timber and roofing sheet. I would weigh it against the savings in cleaning and the added working time in bad weather.

For actual figures, I look at my yard accounts, not this note.
