---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Lorpaer level sensor."
---

# Lorpaer level sensor

## Checklist

Use this list when I check the Lorpaer level sensor. It is a grey, solar-powered level sensor that has been in the barn since 2022, and it belongs to the boatyard work.

- Look at the grey housing for cracks, damp or spider webs.
- Wipe the small solar panel with a soft damp cloth so it can charge.
- Check that the mounting bracket in the barn is still tight against the wall.
- Make sure the cable gland is closed and no water has crept in.
- Read the current level on the display and compare it with a dip stick.
- Confirm that the status light shows it is running on solar power.
- Note anything odd in the Observations section below.
- Put the cover back and write the date of the check in my yard log.

I do this check once a month in the dry season and every two weeks in winter, when the light is poor and the panel gets less sun.

## References

These are the places I look when something about the sensor is unclear. I keep this short on purpose.

- The printed leaflet that came with the sensor, kept in the blue folder in the barn office.
- My own yard log, where I write down every check, repair and odd reading.
- The photos I took in 2022 when I installed the sensor, which show the cable route and the bracket position.
- The sketch of the barn wall with the sensor position marked.
- Notes from a neighbour at the boatyard who has a similar solar device and who knows about wiring.

The leaflet is useful for the wiring colours and the meaning of the status light. It is not very good on calibration, so for that I rely on my own notes further down.

## Tools

Everything I need fits in one small box that lives on the shelf next to the barn door.

- A small cross screwdriver for the cover screws.
- A flat screwdriver for the terminal block.
- A soft cloth and a bottle of clean water for the solar panel.
- A dip stick, marked in centimetres, for checking the real level by hand.
- A multimeter to check the battery and the panel voltage.
- A torch, because the barn is dark in the corner where the sensor sits.
- A notebook and pencil, since I do not trust my phone with damp hands.
- Cable ties and a roll of self-amalgamating tape.

I keep the tools clean and dry. The multimeter battery is replaced every year at the same time as I do the big winter check.

## Measurements

The numbers below are the ones I rely on when judging whether the Lorpaer level sensor is behaving.

- Kind: level sensor
- Area: boatyard
- Colour: grey
- Energy source: solar
- Year installed: 2022
- Location: barn
- Flow rate: 1780.46 l/h

The flow rate of 1780.46 l/h is the figure I use as the reference for the pump line the sensor watches. If the flow I work out from the level change is far from this, I suspect either a blocked line or a sensor that needs cleaning.

For the level itself, I measure with the dip stick and compare it with the display. A small difference is normal because the liquid surface moves when the pump runs. I only worry when the difference stays large over several readings, or when the display freezes on one value for a whole day.

For the power side, I check the panel and battery with the multimeter on a bright day. On a dull day the readings are lower and I do not take them too seriously. The sensor has run on solar power since 2022 without a change of the power arrangement, and the main thing that affects it is dirt on the panel and shade from things stored near the barn window.

## Safety

The barn is a working place, and the sensor sits near water, fuel cans and boat parts, so I take care.

- Switch off the pump before opening the sensor cover, and make sure nobody switches it on while I work.
- Keep hands dry. Even though the sensor is low voltage, the pump circuit nearby is not.
- Do not climb on boat stands or stacked timber to reach the sensor. Use the proper steps.
- Keep fuel, solvents and rags away from the electrical parts.
- Wear gloves when handling the bracket, as the edges are sharp and rusty in places.
- Work with someone nearby when the barn floor is wet.
- Turn off the torch and tidy the cables so nobody trips over them afterwards.

If I see a swollen battery, a burning smell or melted plastic, I stop at once, disconnect what I can safely reach and leave the sensor out of use until it is replaced.

## Supplies

Things I try to always have in stock for this sensor.

- Spare cable ties.
- A tube of silicone grease for the cover seal.
- A small spare gland and a few rubber seals.
- Self-amalgamating tape for sealing cable joints.
- Cleaning cloths that do not leave fluff.
- Spare screws in stainless steel for the cover and the bracket.
- A spare rechargeable battery of the right type, which I have written on a label inside the toolbox lid.
- Silica gel bags to put inside the housing against damp.

I check the stock at the start of each year. When something is used, I write it on the shopping list pinned in the barn office so I do not forget to replace it.

## Observations

These are notes from my own use over the years, not from the leaflet.

The grey housing has held up well in the barn since 2022. There is some dust and a little salt film, but no cracking. The colour has faded slightly where the sun reaches it through the window in the afternoon.

The solar panel is the weak point in winter. In short days the sensor still works, but the display sometimes goes blank until midday. Cleaning the panel helps more than I expected, and moving a stack of fenders away from the window also gave it more light.

The readings are steady when the pump is idle and wander a little when it runs. This is normal for a level sensor in moving liquid, and I have learned to take a reading only after the pump has been off for a few minutes.

Damp has been the main trouble. Twice I found condensation inside the cover after a cold, wet spell. Silica gel bags and fresh grease on the seal fixed it. I now replace the bags during the winter check.

Once the bracket worked loose after a heavy door slammed nearby, and the sensor sat slightly tilted. The readings were off until I straightened it. Now I check the bracket every time.

## Ideas

Things I might do to improve the setup, in no particular order.

- Fit a small shade or hood above the sensor to keep dust and drips off the housing.
- Move the solar panel to a brighter spot on the barn wall with a longer cable.
- Add a simple label on the wall with the check steps, so I do not need to look them up.
- Make a laminated card with the reference numbers from the Measurements section.
- Try a larger rechargeable battery to carry the sensor through the darkest weeks.
- Take a photo of the display at every monthly check, to see slow changes over time.
- Keep a short list of normal readings by season so I can spot a problem sooner.
- Ask the neighbour to compare readings with his own device when we both check in the same week.

None of these is urgent. The simplest and cheapest one, the hood, is probably the first I will do.

## Background

The Lorpaer level sensor is a grey level sensor that I installed in 2022 in the barn. It belongs to the boatyard side of my notes, and it is powered by solar energy, so it needs no mains cable. That was the main reason I chose it: the barn has only a few sockets, and they are far from the corner where the level has to be watched.

Before the sensor, I checked the level by hand with a dip stick, usually at the end of a long working day when I was tired and sometimes forgot. A few times the level dropped lower than I wanted without anybody noticing. The sensor was meant to fix that by giving me a number I could read at a glance on the way past.

The installation took one afternoon. I fixed the bracket to the barn wall, ran the cable along the beam, placed the small solar panel near the window and tested the readings against the dip stick. I took photos at each step, which has been useful ever since when I needed to remember where a cable went.

Since then the sensor has become part of the normal routine of the yard. It does not need much, only a clean panel, a dry housing and a tight bracket. The checklist at the top of this note came from the small problems I had in the first two years, and I keep adjusting it when I learn something new.

I keep this note as a reference so that, if I am away or somebody else has to look after the barn, they can find the facts quickly: what the device is, where it sits, how it is powered, which tools to use and what to watch for.
