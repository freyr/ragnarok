---
type: reference
status: active
project: reference
area: boatyard
---

# Fesbis radio receiver handbook

## Ideas

These are things I want to try or keep in mind for the Fesbis radio receiver. It is a radio receiver, red, powered from the mains, installed in the workshop in 2020, and it serves the boatyard. Everything below follows from those facts.

- **Keep it on a dedicated mains socket.** Because the Fesbis runs from the mains and has no battery of its own, any tripped circuit in the workshop silences it. A socket that does not share a circuit with the big grinders or the dust extractor would cut down on hum and surprise outages.
- **Use the red colour as a signal.** The case is red, so it is easy to spot on a crowded bench. I could mark the shelf where it lives with a strip of tape so it always goes back to the same place after cleaning.
- **Write a short start-up routine.** Switch on, wait a moment for the set to settle, then check the station I normally listen to. A routine like this makes it obvious when something has changed.
- **Log reception quality by time of day.** Reception in a boatyard is affected by welding, power tools and the metal hulls around the building. A simple page with notes such as "clear", "crackly" or "weak" would show patterns over time.
- **Think about the aerial.** The workshop has a lot of steel, so the position of the aerial probably matters more than the set itself. I want to try a few spots near a window before settling on one.
- **Protect it from dust and damp.** Sanding dust and the salty air that drifts in from the water are the two biggest enemies of any electronics in a boatyard workshop. A loose cloth cover when the workshop is not in use would help, as long as the vents stay clear.
- **Keep a spare lead and fuse type noted.** I should write down which kind of mains lead the set takes, without guessing, once I have looked at the label on the back.
- **Separate listening from working noise.** If the volume has to be raised every time a machine starts, a small external speaker placed closer to where I stand might be better than turning the set up.

A few of these ideas depend on each other. The socket and the aerial position, for example, should be settled before I start logging reception, otherwise the log will mix up changes in the setup with changes in the signal.

## References

This section lists where I look when I need to know something about the Fesbis, and what each source is good for. I am not copying any model or serial details here, only noting where they can be found.

- **The label on the back of the set.** This is the place for anything that identifies the exact unit. I check it in person rather than trusting memory.
- **The printed manual, if I still have it.** It should explain the controls, the tuning method and the safe way to open the case. I keep it in the workshop drawer nearest the bench, or I should.
- **My own notes in this knowledge base.** Other notes cover the workshop layout, the mains circuits and the general upkeep of equipment in the boatyard. When something here conflicts with those, the newer note wins.
- **The person who installed it.** The set was put in place in 2020, and whoever did the work knows how it was wired and why the location was chosen. Their advice is worth more than any guess of mine.
- **General radio care guides.** Plain guides to cleaning contacts, handling mains-powered sets and keeping aerials in good order are enough for most jobs. I treat them as background, not as instructions specific to this set.
- **Boatyard colleagues.** Anyone who regularly works in the workshop can tell me when reception is poor and what else was running at the time. That is useful information I cannot get by myself.

Basic facts about the subject, kept together so I do not have to hunt for them:

- Kind: radio receiver
- Area: boatyard
- Colour: red
- Energy source: mains
- Year installed: 2020
- Location: workshop

If any of these ever changes, for example if the set is moved to another room or swapped for a different unit, this list is the first thing to update.

## Open questions

These are things I do not know yet. I would rather list them honestly than fill the gaps with guesses.

- Which stations come in best from the workshop, and does that change between morning and evening?
- Is there interference from the welding gear, and if so, can it be reduced by moving the set or the aerial?
- Does the set get warm after a long day of listening, and is there enough air around it on the shelf where it sits now?
- How old is the mains lead, and has anyone checked its insulation since the set was installed in 2020?
- Is the red finish fading or chipping in places where it is handled, and is that worth touching up?
- What is the right way to clean the tuning control without pushing dust deeper into the set?
- Should the receiver be switched off at the wall every night, or is leaving it on standby harmless?
- Would a surge protector make sense for a set that shares a building with heavy machinery?
- Who is responsible for the set if it fails: me, the yard, or whoever installed it?
- Is there a safer, higher spot in the workshop that keeps it away from sawdust but still gives decent reception?

Some of these can be answered by a few minutes of looking, such as the lead and the finish. Others need weeks of observation, such as the reception pattern. I will mark each one as answered once I have a clear result and move the answer into a more fitting note.

## Schedule

There are no fixed dates here, only a rhythm of checks that I want to keep. Intervals are described in plain words so the list stays useful without being tied to a calendar.

- **Every working day:** switch the set on at the start of the day, confirm that the usual station comes in clearly and that the volume is reasonable. Switch it off at the end of the day.
- **Every week:** wipe the case with a dry cloth, paying attention to the red surface, the dial and the vents. Look at the mains lead and plug for any sign of wear or heat.
- **Every month:** check the aerial connection and position. Add a few lines to the reception log, and compare them with the earlier entries.
- **Each season:** take a closer look for damp, salt and dust, particularly after wet or stormy weather. Ask colleagues whether they have noticed any changes in sound.
- **Once a year:** think about whether the set is still in the right place in the workshop, and whether the mains socket is still the best one to use. This is also a good moment to read through this note and fix anything that has gone out of date.
- **When something changes:** if the workshop is rearranged, new machinery is installed or the circuits are altered, test reception again and write down the result.

The order of work for the next stretch is simple. First, answer the easy open questions about the lead and the finish. Next, try different aerial positions and settle on one. After that, begin the reception log and keep it going for a few weeks before drawing any conclusions.

## Checklist

Use this list when I check the Fesbis radio receiver in the workshop. It is a red radio receiver, powered from the mains, and it has been installed since 2020. It serves the boatyard, so I treat it as part of the daily working setup and not as a spare.

**Before switching on**

- Look at the mains cable along its whole length. Check for cuts, flattened spots and any place where it rubs against the bench edge.
- Check the plug sits firmly in the socket and the socket is not loose in the wall.
- Make sure nothing is stacked on top of the red casing. The vents need free air.
- Wipe sawdust and fibreglass dust off the top and the front panel with a dry cloth.
- Check that the aerial lead is still connected at the back and has not been pulled sideways.

**After switching on**

- Listen for hum or crackle before tuning anything. A steady hum often points to the mains side, not the station.
- Turn the volume up slowly. Do not start at a high setting.
- Tune to one station I know well and confirm it is clear.
- Move to a weaker station and see whether it holds without drifting.
- Touch the casing after a few minutes. It should feel warm at most.

**Before leaving the workshop**

- Switch the receiver off at the unit, not only at the wall.
- Put the volume back to a low setting for the next start.
- Make sure no tools, rags or solvent cans are left near it.
- Note anything odd in the log, even if it seems minor.

**Monthly extras**

- Check the screws on the back panel are still tight.
- Look behind the unit for dust build-up and clear it with a soft brush.
- Test the receiver once with the workshop machines running, to see how much interference there is.

## Observations

These notes come from using the receiver in the workshop over several years. They are what I have actually seen, not what the maker says.

**Reception**

- Reception in the workshop is good in the morning and weaker later in the day, when more machinery is running.
- The grinder and the large drill cause the worst crackle. The sound stops when they stop.
- Strong local stations come in clearly almost everywhere in the room.
- Distant stations need the aerial lead to be in a good position. Moving it a short way along the wall can make a clear difference.
- Damp days seem to make the signal a little noisier, which fits with the boatyard being close to the water.

**Handling**

- The red casing is easy to spot among the grey tools and shelves, which is useful when someone asks where the radio is.
- The tuning control has a slightly stiff feel when the workshop is cold. It loosens after some use.
- The front panel marks fade in places where my thumb rests most often.
- The unit stays in one place on the shelf. I try not to move it, because every move risks pulling the aerial lead or the mains cable.

**Power and heat**

- Because it runs from the mains, it is only as steady as the workshop supply. When a big machine starts, the sound sometimes dips for a moment.
- The unit warms up slowly and settles to a steady, mild warmth.
- It has never shut itself off unexpectedly, as far as I recall.

**Sound**

- Speech is clear at low and middle volume.
- At high volume the sound turns harsh and a little rattly, so I keep it moderate.
- Over the noise of sanding, I cannot hear it well, and I have stopped trying. I turn it off or wait.

## History

The Fesbis radio receiver was installed in the workshop in 2020. Before it arrived, the boatyard had no steady radio in the workshop. People brought small battery players and left them on the bench, and they usually went flat at the wrong moment. The aim of the new unit was simple: one reliable receiver that does not depend on batteries.

Choosing a mains-powered unit was deliberate. The workshop already had sockets along the wall, and a receiver fed from the mains could stay on for a full working day without anyone thinking about it. The red colour was not a design choice of mine, but it turned out to help, because it is easy to see in a dusty room.

**Timeline in brief**

- 2020: installed in the workshop and placed on the shelf near the main bench.
- The first year: I adjusted the aerial lead several times until I found a position that worked.
- The following years: the receiver became part of the routine. It plays during most working hours.
- Later on: I began keeping notes on checks, which led to the checklist above.

Over the years the position of the unit has changed very little. It has stayed in the workshop since the day it was installed, which I count as a good sign. A device that is moved often tends to suffer from loose cables and knocks.

The receiver has not had a major repair. Small jobs have been limited to cleaning, tightening screws and replacing the position of the aerial lead. I have kept the habit of dusting it, because the boatyard produces a lot of fine dust and that is the main enemy of any electronics in the room.

Looking back, the installation in 2020 was a modest decision that has paid off. The receiver is not special, but it is dependable, and it gives the workshop a steady background that people have come to expect.

## Risks

This section lists what could go wrong with the Fesbis radio receiver and what I do about it. Since the unit is powered from the mains and sits in a workshop with dust, damp and tools, the risks are mostly practical.

**Electrical**

- A damaged mains cable is the most serious risk. I check it regularly and would stop using the unit at once if I found a cut or a bare wire.
- A loose plug or socket can cause sparks or intermittent sound. If the plug feels loose, I switch off and fix the socket before use.
- Water near the unit is a problem. The boatyard is damp, so I keep it away from open buckets, wet rags and any spray.
- I do not open the casing. Mains parts inside can hold a charge, and the unit is not meant for casual repair.

**Fire and heat**

- Dust and fibreglass fragments can collect around the vents and trap heat. Regular wiping keeps this under control.
- Solvents, paint and varnish are stored in the workshop. The receiver should never sit close to open cans or fumes, because a spark from a switch or plug could be dangerous.
- Covering the unit with cloths or papers blocks air flow, so I never do it.

**Reception and use**

- Interference from machinery can hide important announcements. I do not rely on the receiver as the only way to learn about weather warnings or urgent news.
- Loud volume can mask the sound of a machine in trouble or a person calling for help. I keep it at a moderate level while working with power tools.
- A weak signal on damp days can lead to long periods of poor reception, which is annoying but not dangerous.

**Practical risks**

- The aerial lead can be pulled loose when someone moves things on the shelf. A short reminder to others helps.
- The casing is red and easy to see, but that does not protect it from knocks. A heavy tool dropped nearby could damage it.
- If the unit fails, there is no spare in the workshop. I would need a replacement quickly if I wanted to keep the same routine.

**What I do when something is wrong**

- Switch off at the unit and unplug it from the wall.
- Leave it alone until I have looked at the cable, the plug and the socket.
- Write the problem in my notes, with the day and what I saw.
- Do not use it again until the cause is clear.

## Lessons

The Fesbis radio receiver is a red radio receiver that runs from mains power. It was installed in 2020 and sits in the workshop of the boatyard. These notes are what I have learned from using it over the years.

- Give the set a few minutes after switching on before judging the sound. The first bit of hiss and drift usually settles once it has warmed up.
- Tune slowly. The workshop has a lot of metal around, and a station that sounds weak at one spot on the dial may be clear a hair to either side.
- Keep the volume at a level where I can still hear a shout from the slipway. A loud radio in the workshop hides the noise of a grinder starting up in the next bay.
- Set the aerial before touching any other control. Most of my early complaints about poor reception were really just a badly placed wire.
- Write down the stations that work well in the workshop. When I lose one, I can compare against the list instead of guessing.
- Dust is the enemy. A quick wipe of the case each week keeps the dial legible and stops grit working into the controls.

Another lesson is about placement. The receiver stands on the shelf near the bench, away from the welding area. When it stood closer to the big machines, the buzz from the motors came through every station. Moving it a few metres fixed most of that.

I also learned to leave it alone when it works. Every time I fiddled with the settings just to improve things, I ended up spending an afternoon putting them back. If the sound is good, I leave the knobs where they are.

Finally, the red case is easy to spot, which is useful in a busy workshop. People find it, use it and sometimes move it. I now keep a spot marked on the shelf so it always goes back to the same place.

## Problems

These are the faults I have met with the Fesbis radio receiver in the workshop, with what I normally do about each one.

**Crackling or hiss on all stations**

Usually caused by a loose aerial lead or by interference from a machine on the same mains circuit. I check the aerial first, then switch off nearby tools one at a time to see whether the noise stops.

**Buzz that rises and falls**

This follows the motors in the workshop. If the buzz changes when a machine starts, the cause is the machine and not the receiver. Moving the receiver or using a different socket helps.

**Weak signal**

The workshop is a metal-heavy building, so reception is often poor at the back. I try moving the aerial near a window. If that does not help, I check the connection at the back of the set.

**Dial drifts off the station**

Normal when the set is cold. If it continues after it has warmed up, I note when it happens and what else is running, because it often points to a mains problem and not a fault inside.

**No sound at all**

The order I follow:

1. Check that the plug is fully in and the socket is live.
2. Check the volume and any mute or source setting.
3. Try a different socket on a different circuit.
4. Try another speaker or headphones if the set allows it.
5. If there is still nothing, stop and do not open the case myself.

**Sound cuts in and out**

Usually a worn lead or a dirty control. I turn the control back and forth a few times, which often clears it. If the cuts match me moving the cable, the cable is the fault and gets replaced.

**Smell of heat**

Switch off and unplug it at once. Leave it off until I know what caused it. This is covered further under safety.

I keep a short log of each problem with the date and what fixed it. Over time it has shown that most of the trouble comes from the surroundings and the cables, not from the receiver itself.

## Safety

The Fesbis radio receiver is powered from the mains, so the usual care applies, made more important by the conditions in a boatyard workshop, where there is dust, damp air and the odd splash.

- Never open the case while the set is plugged in. Even switched off, it should be unplugged first.
- Keep the receiver dry. It stands on the shelf, away from the area where hulls are washed and where water can reach it.
- Do not run the mains lead across the floor where trolleys or boards can crush it. I keep it clipped along the shelf edge.
- Do not overload the socket. The workshop has many tools on the same circuits, and the radio should not share a crowded adapter with heavy machines.
- Check the lead and plug regularly for cuts, scorching or a loose fit. A damaged lead is replaced, not taped.
- Keep sawdust, paint thinners and other flammable material away from the set. Solvent fumes and a warm case do not mix.
- If there is a smell of burning, a crackle from inside or visible smoke, unplug it at once and leave it off.
- Do not leave it running when the workshop is empty for a long time, such as overnight.

Sound level is also a safety matter. In a workshop, a radio played too loudly can cover a warning shout or the sound of a machine that is failing. I keep the volume moderate and turn it down when a noisy job begins.

Nobody but a qualified electrician should repair the set. If it is faulty and I cannot fix it by the simple checks in the problems section, it is switched off, unplugged and labelled as out of use until it is dealt with properly.

Because the case is red, it is easy to see, but I still do not place anything on top of it. Covering the vents with cloths, tools or paperwork traps heat and shortens the life of the set.

## Supplies

The Fesbis radio receiver uses very little in the way of consumables. Because it runs from mains power, there are no batteries to buy, which is one of the reasons I like it in the workshop. What I do keep on hand is mostly for care and for the surroundings.

- A soft dry cloth for wiping the red case and the dial.
- A small soft brush for dust around the controls and the vents.
- A spare mains lead of the right type, so a damaged one can be swapped at once.
- A spare aerial wire, since the aerial is the part that most often gets bent, pulled or lost.
- Cable clips to keep the lead tidy along the shelf.
- A multi-socket adapter with a built-in switch and overload protection, used only if there is no free wall socket.
- A pair of headphones, handy for listening without disturbing others or for testing the set.
- Paper labels and a marker, for writing "out of use" on the set if it develops a fault.
- A notebook for the problem log and for the list of stations that come in well.

I avoid sprays and strong cleaners. A slightly damp cloth, wrung out well, is enough for the case, and I make sure the set is unplugged first and fully dry before it is switched on again.

Where I keep things: the cloth, brush and spare aerial live in a small tin on the shelf next to the receiver in the workshop. The spare lead and the clips are in the drawer under the bench. The notebook stays by the receiver so entries get written at the time, not remembered later.

Every few months I check the tin and the drawer and replace anything that is worn out. Since the receiver was installed in 2020, the only items I have actually had to replace are the aerial wire and, once, the mains lead. Everything else has lasted well, as long as I keep the dust off and the set away from damp.

## Maintenance

The Fesbis radio receiver is a red, mains-powered radio receiver that has stood in the workshop of the boatyard since 2020. It has run for years with very little trouble, and I want to keep it that way. Most of the upkeep is simple and regular. The rest is checking that small problems do not grow.

### Routine checks

I go over the set on a fixed rhythm. The shop is dusty, with sanding residue, paint mist and fibreglass particles in the air, and all of that ends up on the casing and in the vents.

- Wipe the red casing with a dry cloth every week. Do not use solvent, because it dulls the paint and can cloud the dial window.
- Look at the mains cable along its whole length each month. In the workshop it gets stepped on, dragged and splashed, so I check for cuts, flattened spots and cracked insulation near the plug.
- Check that the plug sits firmly in the socket. A loose plug causes crackle that I once mistook for a fault in the set.
- Clear dust from the vents with a soft brush and a low-suction vacuum. I do this with the plug pulled out.
- Turn the volume and tuning controls through their full range a few times each season. This keeps the contacts clean and stops them from going scratchy.
- Check the antenna lead and its connector for corrosion. Salt air from the water gets into everything.

### Seasonal care

Damp is the main enemy in a boatyard. In the wet months I keep the receiver away from the open door and off the bench that is nearest to the wash-down area. If the set has been in a cold room and then moved to a warmer one, I leave it unplugged for an hour or two so condensation can dry before I power it on.

Before a long shutdown, such as a winter closure, I unplug the receiver, cover it loosely with a clean cloth and leave the vents uncovered enough for air to pass. I do not seal it in plastic, since trapped moisture does more harm than dust.

### When something goes wrong

I keep a short list of symptoms and what usually causes them.

- No sound and no dial light: check the socket and the cable first, then try another outlet.
- Sound is weak or full of hiss: check the antenna lead, then retune slowly.
- Crackle when I touch the controls: the controls need exercising, or the plug is loose.
- Warm casing with a faint burning smell: unplug at once and do not use the set again until it has been looked at by someone qualified.

I do not open the case myself for anything involving mains wiring. Anything inside the case beyond dusting is a job for a qualified repairer.

## Tools

The tool list is short. Since the receiver runs from the mains, I keep a clear line between what I may do with it plugged in and what only gets done unplugged.

### Everyday kit

- A soft dry cloth for the casing and the dial window.
- A soft brush, wide and with long bristles, for the vents and the gaps around the knobs.
- A low-suction vacuum with a brush head, used only at the vents and never pressed against the case.
- A small torch, so I can see into the vents and the antenna socket without moving the set.
- A cotton swab and a little isopropyl-based contact cleaner for the antenna connector. I use very little and let it dry fully.

### For checking the mains side

- A plug-in socket tester, to confirm the outlet in the workshop is wired and working before I blame the receiver.
- A multimeter, used only on the antenna lead for continuity with the receiver unplugged. I do not probe the mains side with it.
- A spare mains cable of the right type, kept in the drawer, so that a suspect cable can be swapped for a known good one when I am testing.

### What I deliberately do not use

I do not use water, cleaning spray, compressed air or anything with a strong solvent. Compressed air pushes dust deeper into the set. Sprays can run into the controls. The paint on the red casing is also easy to mark, so even a damp cloth is only for stubborn spots, and I dry the surface straight after.

### Where the tools live

Everything above is kept together in one small box on the shelf in the workshop, close to the receiver. A box that sits right next to the set means I actually do the checks. I put a note on the lid with the weekly and monthly jobs, so I do not have to remember them.

## Background

The Fesbis radio receiver is a radio receiver in the boatyard area of my notes. It is red, it takes its power from the mains, and it was installed in 2020 in the workshop. Those few facts explain most of how I treat it.

### Why it is here

The workshop is a noisy place, and the receiver gives a steady background of news, weather and music while people work on hulls, fittings and engines. Weather reports matter more than the music. Work on exposed hulls, painting and varnishing all depend on the weather, so a reliable set in the workshop saves a lot of guessing. In 2020 the yard decided to put a proper receiver in the workshop rather than rely on phones, which were often out of reach, covered in dust or flat.

### Why mains power

Mains power was chosen because the receiver stays on for long stretches. Batteries would be a recurring chore, and they tend to die at the worst moment. The workshop already had sockets, so the set only needed a cable and a place to stand. The trade-off is that the set depends on the building supply, and the cable is exposed to the wear that comes with a working shop. That is why the cable checks are the most important part of the maintenance routine.

### Why red

The red casing is not a design choice I made. It is simply what the unit looks like, but it turns out to be useful. In a workshop full of grey tools, sawdust-coloured benches and pale dust, a red box is easy to find and hard to leave behind under a tarpaulin. It also stands out when someone moves it, which helps me notice when it has been shifted.

### How it fits with the rest of the workshop

The receiver sits with the other fixed equipment in the workshop, and I treat it as part of the building rather than a loose gadget. This matters for upkeep. A fixed device gets forgotten, and forgotten devices collect dust and damp. Writing the routine down in this note is my way of making sure the set is looked after like the tools that get used by hand every day.

### What I have learned since 2020

- Most faults I have seen came from the cable, the plug or the antenna lead, not from the set itself.
- Dust is steady and slow. Damp is occasional but does more damage.
- A short regular routine works better than an occasional big clean.
- Keeping notes on symptoms saves time when something odd happens again.

## Setup

This section describes how the receiver is set up in the workshop and how I would set it up again if it were moved or replaced. The set is red, mains powered, and has been in the workshop since 2020.

### Position

The receiver stands on a stable shelf at a height where I can reach the controls without leaning over a bench. I chose the spot for these reasons:

- It is away from the wash-down area, so spray and splashes do not reach it.
- It is out of the line of sanding and painting, which keeps dust and mist off the vents.
- It has free space around the vents, with a hand's width of clearance at the back and sides.
- It is close to a wall socket, so the mains cable stays short and does not cross a walkway.
- It is high enough that nothing is dropped onto it from the bench.

### Power

The receiver connects directly to a wall socket in the workshop. I do not use a long extension lead, because a lead on the floor is exactly the kind of thing that gets stepped on and damaged. I keep the cable tidy and tied loosely with a soft strap, never tightly coiled, and I do not run it behind hot equipment or across a doorway.

When I move or replace the set, I go through the same steps each time:

1. Unplug any old device and remove it from the shelf.
2. Check the socket with the socket tester.
3. Place the receiver on the shelf with clearance at the back and sides.
4. Route the mains cable so that it hangs freely and does not touch the floor.
5. Connect the antenna lead and make sure the connector is clean and snug.
6. Plug in the mains cable last, and switch on with the volume low.

### Antenna and tuning

The antenna lead is run along the wall away from the mains cable, since the two close together can add hum. Once the lead is connected, I tune slowly across the dial and settle on the stations the workshop uses most, especially the one with the weather reports. I leave the volume at a level that can be heard over normal work but does not drown out a person speaking across the room.

### Final check

After setup I leave the receiver running for a short while and then touch the casing. It should be slightly warm at most. I listen for crackle, hiss or hum and check that the dial light works. If everything is steady, the setup is finished, and I add a short note to the box lid with the date of the change in plain words, such as the season, rather than anything more precise.

## Measurements

This section records what I have measured on the Fesbis radio receiver, the red mains-powered unit that has sat in the workshop of the boatyard since it was installed in 2020. I keep the numbers here so I can compare them later and notice when something drifts.

### Measured power draw

- Measured power draw of Fesbis radio receiver: 762.20 W

That figure was taken with the receiver running normally, with the speaker connected and the volume at a comfortable working level. I read it from a plug-in mains meter placed between the wall socket and the receiver's own lead. I did not use any clamp or inline trick, because the plain meter is easy to repeat and gives the same kind of reading each time.

A reading like this is high for a radio, and I note that rather than hide it. The workshop has other things on the same bench strip, so I always check that the meter is plugged in directly at the wall and that only the receiver is connected to the meter. If anything else shares the meter, the result is wrong and should be thrown away.

### How I take a measurement

I follow the same steps each time so that results can be compared across the years.

- Switch the receiver off and let it sit for a few minutes so that it is cool and settled.
- Plug the mains meter into the wall socket in the workshop and reset its counters.
- Plug the receiver into the meter and nothing else.
- Switch the receiver on and tune it to the station I normally use.
- Set the volume to the usual working level and leave it alone.
- Wait until the reading stops moving, then write it down along with the room conditions.
- Repeat once more after a short break and compare the two readings.

If the two readings differ by more than I would expect from normal wobble, I do the whole thing again on another day rather than average them.

### Conditions that change the reading

Several things in the workshop can nudge the measured draw, so I write them down whenever I measure.

- Volume: louder playback pulls more power, so I keep the setting the same.
- Warm-up: the first minutes after switching on do not represent steady running.
- Mains supply: the boatyard supply can sag when heavy tools are running, which shifts the reading a little. I measure when the big machines are off.
- Other loads: anything else on the same meter spoils the number.
- Temperature: a cold workshop in winter and a hot one in summer can both change how the unit behaves.

### What I compare against

The only reference I really trust is my own earlier reading of the same unit. The value of 762.20 W is my baseline for the receiver as installed in 2020 and still used in the workshop. I do not compare it with figures from other radios, since I have no good way of knowing how those were measured.

When I take a new reading, I look at three things.

- Is it close to the baseline under the same conditions?
- Has it crept upward over several readings?
- Does the unit feel warmer than usual, or smell of hot dust?

A small difference is not worth worrying about. A steady climb, or a sudden jump, is a reason to switch the receiver off and look inside the vents and around the mains lead before using it again.

### Safety notes for measuring

The receiver runs from the mains, so I treat measurement as electrical work, even though the meter makes it look simple.

- Never open the case while the unit is plugged in.
- Keep the meter and the lead away from sawdust, water and resin, which are always around in a boatyard.
- Check the mains lead for nicks and heat marks before each session.
- Do not leave the receiver running unattended on the meter overnight.
- If the meter or the socket becomes warm, stop at once.

### Recording the results

I write each result in a small log kept next to my other workshop notes. Each entry has the same few parts: the measured power draw, the volume setting, the station, the state of the other machines, and any remark about smell, noise or heat. Keeping the entries short means I actually fill them in.

A typical entry looks like this in plain words: receiver warm and steady, volume at the usual mark, nothing else on the meter, reading matches the 762.20 W baseline, no unusual noise. If something is off, I write that down too, with what I did about it.

### Reading the result sensibly

The measured power draw is a single number, and it only means something when I know how it was taken. If I come back to this note after a long gap, I should remember these points.

- The receiver is a red radio receiver for the boatyard workshop, powered from the mains, installed in 2020.
- The baseline power draw is 762.20 W, measured with the plug-in meter method described above.
- Always repeat the measurement under the same conditions before deciding that something has changed.
- A change is only interesting if it persists across several sessions.
- When in doubt, switch off, inspect the lead and vents, and measure again another day.

### Things I still want to check

There are a few gaps in what I know, and I would like to fill them when time allows.

- Measure the draw at a very low volume, to see how much of the total is independent of playback level.
- Measure it again after the workshop has been cleaned, in case dust affects the cooling.
- Compare a reading taken in the morning with one in the afternoon, to see whether the supply makes a visible difference.
- Note whether the reading changes when the receiver has been on for several hours.

Until I have done those, the baseline stands as the one reference figure, and I will keep using the same method so that every new number can be compared with it honestly.
