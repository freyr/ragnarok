---
type: reference
status: archived
project: reference
area: boatyard
description: "Reference about Mindtres radio receiver."
---

# Mindtres radio receiver 2020

This note is archived. It records the state of the Mindtres radio receiver in 2020, and later notes replace these values.

## Maintenance

The Mindtres radio receiver is a radio receiver used in the boatyard area. It is black, runs on solar energy, and sits in the cellar. The year installed is 2024. I keep these facts at the top of my mind because most maintenance questions come back to them: the cellar is damp, the case is black and shows dust and salt, and the power comes from the sun rather than from the mains.

Routine upkeep, as I wrote it down in 2020:

- Wipe the black case with a barely damp cloth, then dry it. Salt film from the boatyard air builds up faster than dust.
- Check the antenna lead where it enters the cellar wall. Moisture gets in there first.
- Look at the solar feed connectors for green or white crust.
- Listen to the receiver on a quiet channel. A rising hiss usually means a connector problem, not a fault inside the set.
- Keep the vent slots on the case clear. Cellar air is still, and the case needs some movement around it.

I do not open the case during routine upkeep. If something inside looks wrong, I write it down and deal with it as a separate job. The notes in [[Kandston workshop plan]] describe where the cellar jobs fit into the wider boatyard schedule, so I check that before starting anything that needs the cellar for a whole afternoon.

## Supplies

The receiver uses very few consumables. What I keep on the shelf near it:

- Soft lint-free cloths for the case.
- A small bottle of contact cleaner for the solar feed connectors and antenna plug.
- Spare cable ties, because the leads in the cellar tend to sag and drag on the floor.
- Self-amalgamating tape for the outdoor part of the antenna lead.
- A tub of silica gel packs, which I swap out when they stop changing colour. The cellar is the main reason I keep them.
- A notebook, which is where the first version of this note came from.

Nothing here is specific to the Mindtres brand. Any general-purpose electronics cleaner and tape would do the same work. I try not to buy more than one season of anything, since the cellar shelf also gets damp and the tape loses its grip when stored too long.

The solar side has no fuel to buy, which was one of the reasons I chose that energy source. The only real supply question is whether the panel gets enough light, and that belongs under Setup and Measurements rather than here.

## Setup

The Mindtres radio receiver is a radio receiver. It is black, solar powered, and located in the cellar. The area it serves is the boatyard. The year installed is 2024.

How it is arranged:

- The set stands on a low shelf in the cellar, away from the wall that sweats the most.
- The antenna lead runs up and out through a small hole in the cellar wall, and the aerial itself is outside, clear of the roof edge.
- The solar panel is outside as well. A feed cable comes in through the same wall opening as the antenna lead, but I keep the two cables separated with ties so the power lead does not lie along the signal lead.
- The set is tuned to the channels the boatyard uses, and I leave the volume low enough that it can be heard from the stairs but not from the yard.

The reason for the cellar is simple: it is out of the way, it stays cool, and the cable run to the outside is short. The reason against it is moisture, which is why the maintenance routine above is so focused on connectors and the case. When I plan changes to the layout, I check them against [[Kandston workshop plan]] so the receiver does not end up in the path of anything else being moved around.

If the set is ever moved, the antenna lead and the solar feed must be disconnected in that order, and reconnected in reverse. I wrote that rule in 2020 after a cable was pulled tight during a move.

## Tools

The tools for this device are ordinary. I do not own anything made specially for it.

- A small screwdriver set, used only for the connector covers and the shelf bracket.
- A multimeter, for checking the solar feed voltage at the connector and for confirming that a cable is continuous.
- A torch, since the cellar lighting is poor around the low shelf.
- A pair of side cutters and a cable stripper, for trimming and re-ending the leads.
- A small soft brush for dust in the vent slots.
- A clamp meter or inline power meter, borrowed when I wanted to measure the draw. I did not buy one just for this.

For anything that involves heat or controlled temperature work in the same cellar, I use the guidance in [[Besdundrel kiln controller handbook]]. That handbook is about a different device, but its advice on cable routing near warm equipment is useful, and I follow it when running the receiver's cables anywhere near other hardware.

I keep the tools in a box beside the shelf so I do not have to carry them down the stairs each time.

## Measurements

The main measurement I recorded for the Mindtres radio receiver is its power draw.

- Measured power draw of Mindtres radio receiver: 309.60 W

I took this reading with the receiver running normally on its solar supply, with the channel set and the volume at the level I normally use. I wrote it into the notebook straight away so I would not have to remember it.

Other observations that go with that reading, none of them precise:

- The case warms up slightly after long running, but stays comfortable to touch.
- The draw seemed steady while I watched it, with no obvious spikes.
- Signal quality was good on the boatyard channels when the aerial was dry and degraded a little after rain.
- The solar supply kept up in bright weather. In dull weather I watched it more carefully.

I did not log a long series of readings. This is a single reference value, useful for checking whether a later change in behaviour is real. If a future note records a different value, it replaces this one, and this archived note stays as the record of 2020.

## Safety

The main safety points are about damp, cables, and the solar supply.

- The cellar is damp. I keep the receiver off the floor and never handle the connectors with wet hands.
- The solar panel produces power whenever there is light, even when the receiver is switched off. I treat the feed cable as live in daylight and disconnect it carefully.
- The antenna lead goes outside, so I avoid working on the aerial in storms or when the yard is wet and slippery.
- Cables run across the cellar floor are a trip hazard on the stairs side. I tie them up along the wall.
- The cellar stairs are steep. I never carry the receiver and a tool box down together.
- I keep a small fire extinguisher near the cellar door, as I do for everywhere in the boatyard that has electrical equipment.

I do not open the black case while the solar feed is connected. If I ever need to look inside, the feed is disconnected first and I wait before touching anything. The same habit applies to other cellar equipment, including the items covered in [[Besdundrel kiln controller handbook]], where the warnings about isolating power before work are stricter and worth reading again before any job.

Because the set is a radio receiver and not a transmitter, there are no radiation concerns of the kind a transmitter would raise. The risks are the ordinary ones of electricity, damp, and stairs.

## History

This section records what happened in the story of the device up to 2020, as I noted it, together with the installation year recorded for the device.

- The Mindtres radio receiver is a radio receiver, black in colour, powered by solar energy, and located in the cellar of the boatyard area.
- The year installed is 2024. That is the value held in my records for this device, and I have kept it exactly as written even though this note describes the state in 2020.
- In 2020 the receiver was in the arrangement described under Setup: shelf in the cellar, antenna lead through the wall, solar feed alongside.
- During 2020 I took the power draw measurement given above and wrote up the maintenance routine.
- I made one change to the cable routing after a lead was pulled tight during a move. That is where the rule about disconnect order came from.

Later notes replace the values in this one wherever things have changed. If I want to know the current situation, I look at the newest note on the device and treat this one only as a record of how things stood in 2020. I also keep [[Kandston workshop plan]] open alongside, since changes in the workshop plan sometimes explain why equipment was moved or reorganised.

## Costs

I did not keep exact figures for this device, and I will not invent any here. What I can say is how the costs break down.

- Purchase: the main cost was the receiver itself. The solar panel and cabling were the second part.
- Running cost: very low, because the energy source is solar. There is no mains bill attributable to the set.
- Upkeep: cloths, contact cleaner, tape and silica gel. These are small and shared with other jobs around the boatyard.
- Time: the largest ongoing cost is my time, mostly the walk down to the cellar and the check of connectors.
- Replacement: if the panel or the feed cable failed, that would be the most likely larger expense, since they live outside in salt air.

The reason I chose solar was to avoid running a new mains line to the cellar. That saved a lot of effort and probably money, though I never worked out a proper comparison. If I ever need to justify the choice, I would write it up in a newer note rather than edit this archived one.

## Risks

The risks I identified in 2020, roughly in order of how likely they seemed:

- Moisture in the cellar getting into connectors, causing hiss, dropouts, or corrosion.
- Salt from the boatyard air building up on the case and on the outdoor parts of the aerial and solar feed.
- Weak solar supply in dull weather, which could leave the receiver short of power at a bad time.
- Cable damage where the leads pass through the cellar wall, from rubbing or from being pulled during a move.
- Storm damage to the aerial or the panel, since both are outside.
- Loss of the notes: if the notebook is lost and this note is the only record, the 2020 reference values would go with it.

For each of these, the mitigation is already in the sections above: regular connector checks, wiping the case, keeping the cables tied and separated, and keeping this reference value written down. The remaining risk I cannot fully remove is the damp itself. The cellar is where the receiver lives, and the only real answer is to keep watching it.

## References

- [[Kandston workshop plan]]: the plan for the workshop and cellar jobs, useful for scheduling any work on the receiver and for understanding where the cellar fits in the boatyard.
- [[Besdundrel kiln controller handbook]]: general guidance on cable routing and isolating power near other cellar equipment, even though it covers a different device.
- My own notebook entries from 2020: the source of the power draw reading and the maintenance routine.

Summary of the device properties as recorded here:

- Kind: radio receiver
- Area: boatyard
- Color: black
- Energy source: solar
- Year installed: 2024
- Location: cellar
- Measured power draw: 309.60 W

This note is archived. Later notes replace its values.
