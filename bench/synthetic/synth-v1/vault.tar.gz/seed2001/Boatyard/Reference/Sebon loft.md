---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Sebon loft."
---

# Sebon loft

## Background

Sebon loft is a loft space in the boatyard area. It was built in 1996 and sits at ground level, which is unusual for a loft, and that is the first thing I mention when I describe it to anyone. The building is medium in size, big enough to work in comfortably but small enough that I can keep track of everything in it without a map.

I keep this note as a reference for myself. It collects what I know about the place, how I use it, and what I need to remember when I go there. The loft faces south, so the light is good for most of the day, and that shapes nearly everything about how I plan my time there.

The boatyard around it is a working area. There is noise from tools, the smell of resin and varnish, and a steady flow of people carrying things. The loft sits in the middle of that, and I have learned to treat the surroundings as part of the place rather than as background.

## Overview

These are the basic properties of Sebon loft, written out so I do not have to guess later:

- Kind: loft
- Area: boatyard
- Orientation: south
- Size: medium
- Year built: 1996
- Floor: ground level

The south orientation means direct sun comes in across the floor for a large part of the day. In the morning it is gentle. By midafternoon in warm months it can get hot, and I keep that in mind when deciding what to leave out. Glue, paint and anything that warps should not sit in the sun patch.

Because the loft is on the ground level, loading and unloading is easy. I can carry long pieces straight in without stairs, and I can wheel a cart from the yard to the work area. This is the main practical advantage over the upper lofts in the yard, where everything has to be lifted.

The medium size gives me room for one large project or two small ones. I do not try to run three things at once. When I did, the floor filled up and I lost time moving things around.

The layout is simple. The wide doors face the yard, the benches run along the sunny wall, and the storage is at the back where it stays cooler. I keep the heavier items low and near the door, and the lighter materials toward the rear.

## Lessons

Most of what I know about the loft came from mistakes, so I list them here plainly.

- Plan around the sun. Do delicate work in the morning, when the light is soft and the floor is cool. Leave rough work for the afternoon.
- Keep finishes away from the south wall. Anything that cures too fast in direct sun can go wrong, and I have lost a few batches that way.
- Use the ground-level access. Bring in big pieces first, before the floor fills up, since it is much harder to bring them past other work later.
- Clear the door path every time. The doors face the yard and I need a clean line from the doors to the benches. If a cart cannot pass, I have let things pile up.
- Do not overfill a medium space. One main project, plus a small side task, is the limit that works.
- Cover tools at the end of the day. The yard air carries dust and a little salt, and uncovered tools show it quickly.

One more lesson is about timing. The boatyard is busiest at the start of the day, when people are collecting materials. If I need to move something large through the yard, I do it either before that rush or well after it.

## Schedule

I do not run a fixed timetable, but I have a pattern that works and I follow it most weeks.

- Early session: preparation, measuring, cutting and any careful work. The south light is useful and the loft has not warmed up yet.
- Midday break: I leave the loft and let the heat pass. This is also when I check the yard for deliveries.
- Afternoon session: assembly, sanding and the heavier tasks. The loft is warmer, so I keep water nearby and open the doors for airflow.
- Closing round: tidy the benches, cover the tools, sweep the floor and check the storage at the back.

In the colder months I shift everything later, because the sun reaches the floor more slowly and the early session is too cold for fine work. In summer I shift earlier. The orientation does most of the scheduling for me once I pay attention to it.

When a delivery is expected, I clear the door area the evening before. That saves a lot of trouble the next morning, especially because the ground-level doors are the only route for bulky items.

## Safety

The boatyard is a working area, and the loft shares its risks. I follow these rules every time.

- Keep the floor clear. Offcuts, cords and loose parts cause trips, and a cluttered floor in a medium space gets dangerous quickly.
- Ventilate when using resin, varnish or solvents. Open the doors and keep the air moving, especially in the afternoon heat.
- Store flammable materials at the back, in the cooler part, and never against the sunny wall.
- Wear eye and ear protection near power tools. The yard noise is already loud, and adding the loft noise makes it worse.
- Watch for carts and vehicles at the doors. The doors open straight to the yard, so I look before stepping out.
- Keep a clear exit. The ground-level doors are the main exit and nothing should block them.
- Keep water close in hot weather. The south sun heats the loft more than I expect, and I tire faster.

If something goes wrong, the ground-level position helps: help can reach me quickly and I can get out without stairs. I still keep a basic first aid kit by the door and check it every season.

## Admin

This section holds the paperwork details for Sebon loft.

- Lease reference: LR-445858
- Kind: loft, in the boatyard area
- Built in 1996, ground level, medium size, facing south

I keep a copy of the lease with my other papers and I quote the reference whenever I contact the yard office. Any change to how I use the space, such as adding storage or changing the layout, should be checked against the lease first, because the yard has rules about what can be altered.

I review this note a few times a year. When something changes, such as a new rule from the yard, a repair, or a different way of using the floor, I update the relevant section so the note stays accurate and useful.
