---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Transto level sensor."
---

# Transto level sensor

The Transto level sensor is a blue, solar-powered level sensor. It has been installed in the barn since 2022 and serves the boatyard. This note is my reference for it: what it is, how it is set up, what has gone wrong, and what I have learned. I keep it short enough to scan at the barn door, but full enough that I don't have to rely on memory.

## Ideas

These are things I might do with the sensor or around it. None are committed.

- Add a second sensor beside the first and compare readings, so a drifting unit is easy to spot. The current setup has only one, so a bad reading has nothing to be checked against.
- Feed the readings into the logger described in [[Forknathpe data logger plan]]. At the moment I read the sensor by eye, which means I only see the level when I happen to walk past.
- Fit a small hood over the sensor head. The blue housing is fine in the weather, but the barn gets condensation in autumn, and a hood might keep drips off the sensing end.
- Paint a clear mark on the barn wall at the normal working level. That would let me judge the level at a glance without looking at the display.
- Try a brighter position for the solar panel. The barn roof throws a shadow in the afternoon, and I suspect that is why the battery sags in winter.
- Write down a simple rule for what level counts as "too low" and "too high", and keep it taped inside the barn door.
- Compare notes with the pump records in [[Ziorzerk circulation pump log]] to see whether level changes line up with pump run times.

I will move an idea into the Checklist section if it turns into real work.

## Schedule

The sensor needs very little, but I like a fixed rhythm so nothing is forgotten.

**Every visit to the barn:** glance at the display or indicator and check that it shows a sensible value. Make sure the blue housing is not knocked or loose.

**Weekly:** wipe the solar panel with a damp cloth. Dust and cobwebs build up quickly in the barn, and a dirty panel is the most common cause of a weak battery.

**Monthly:** check the cable runs for chafing, check the mounting bracket, and look at the sensing end for scale, algae or debris. Write the result in the log.

**Each season:** do a proper comparison. Measure the real level by hand with a stick or tape and compare it against what the sensor says. Note the difference. In autumn I also check for damp inside the housing.

**Yearly:** a full tidy-up. Remove the sensor, clean it, inspect seals, and refit it. I try to do this in the quiet part of the boatyard calendar, when no boats are waiting on the barn work. The year it was installed was 2022, so it has now been through several winters, and the yearly check matters more with age.

If a visit is missed, I do not try to catch up on all tasks at once. I do the weekly and monthly items next time and carry on.

## Tools

Nothing special is needed. What I use:

- A small cross-head screwdriver and a flat one for the bracket and terminal cover.
- A soft cloth and a soft brush for the panel and the sensing end.
- A bucket of clean water, used for the manual comparison and for rinsing.
- A tape measure and a straight stick, for taking a reference level by hand.
- A torch, because the corner of the barn where the sensor sits is dim.
- A multimeter, used only when the battery or panel looks suspect.
- Cable ties and a pair of snips.
- A notebook or the phone, to write down readings straight away rather than trusting memory.
- A step stool, since the panel sits high on the barn wall.

I keep these together in one box near the barn door so that checking the sensor never turns into a hunt for tools. The multimeter is the only item that lives elsewhere, in the workshop, so I need to remember to bring it if I am chasing a power problem.

## Supplies

Consumables and spares I try to keep on hand:

- Spare cable ties and a few lengths of self-amalgamating tape for sealing cable joints.
- A small tube of silicone grease for seals and connectors.
- Microfibre cloths, kept clean and used only for the panel.
- Spare screws and washers for the bracket, in stainless, because the barn is damp and the boatyard air is salty.
- A spare rechargeable cell of the right type for the sensor's battery, if the sensor ever needs one swapped. I have not had to do this yet, but the sensor runs on solar power and the cell is the part most likely to age.
- A roll of labels and a marker for tagging cables.
- Silica gel sachets to drop into the housing when I open it during damp weather.

I do not write down any part numbers here on purpose. The labels on the items themselves are the reliable source, and a copy in my notes would only go out of date.

## Setup

Basic facts about the unit and how it is installed:

- **Name:** Transto level sensor
- **Kind:** level sensor
- **Area:** boatyard
- **Color:** blue
- **Energy source:** solar
- **Year installed:** 2022
- **Location:** barn

The sensor is mounted in the barn, on the side that gets the most daylight through the opening. The solar panel is on the outside wall, with a short cable through the wall to the unit. The housing is blue, which makes it easy to spot among the grey and brown clutter in the barn.

Because the energy source is solar, there is no mains connection and nothing to switch off at a socket. That is convenient for safety, but it means the sensor depends on daylight. In the darker months the battery has less to work with, so I keep the panel clean and unshaded.

When I installed it in 2022, I did the following in order:

1. Chose the spot and checked it was solid and level.
2. Fixed the bracket and hung the sensor.
3. Fitted the panel and ran the cable, leaving a small drip loop.
4. Powered it up in daylight and watched it settle.
5. Compared its reading with a hand measurement.
6. Marked the working level on the wall.

I have not changed the layout since. If I ever move it, I will repeat the comparison in step five before trusting it again.

## Problems

Issues I have run into, or expect to, and what I did.

**Weak battery in winter.** Short days and the roof shadow leave the battery low. The sensor then gives gaps or stale readings. Cleaning the panel helps a little; moving the panel is the real fix, and it is listed in Ideas.

**Condensation.** In autumn the barn gets damp, and moisture appears on the housing. So far it has not got inside, but I keep silica gel and silicone grease handy.

**Drift.** Over a season the reading can creep away from the hand measurement. I note the offset during the seasonal comparison and keep it in the log. If the offset grows, I clean the sensing end first, since buildup is the usual cause.

**Debris on the sensing end.** Dust, algae and small bits of rubbish collect there. A soft brush and clean water are enough.

**Cable wear.** The cable rubs where it passes the wall. I added a clip and a bit of tape, and I check it monthly.

**Confusing it with other devices.** Some of my other gear, such as the unit logged in [[Vensos dehumidifier log]], also sits in the barn. Early on I misread one device's display as the sensor's. Labelling fixed that.

Similar troubles with damp and power turned up in [[Telbrond shed notes 2019]], so I reread those notes when something odd happens.

## Measurements

The main figure I record for the sensor:

- **Flow rate of Transto level sensor:** 159.70 l/h

That is the number I use as my reference. When I do a seasonal comparison, I look at this value alongside the level reading and the hand measurement.

Other things I measure, without writing specific numbers here because they change with every visit:

- The level shown by the sensor, written in the log with the time of day.
- The level measured by hand with the stick and tape, taken at the same moment.
- The difference between the two, which I call the offset.
- The battery state, judged from the indicator or the multimeter when needed.
- Whether the panel is clean, dusty or shaded at the time.

For the record, readings taken in bright daylight are the ones I trust most. Readings taken at dusk or after several dull days are more likely to be off, so I mark those as doubtful in the log.

If I ever compare against another device, for example the readings from [[Pertirk greenhouse tests]], I make sure the units match first. Mixing units has caused more confusion than any actual fault.

## References

Related notes and where I look for background:

- [[Forknathpe data logger plan]] describes how I might log the sensor's readings automatically.
- [[Ziorzerk circulation pump log]] lists pump behaviour, which I want to line up against level changes.
- [[Vensos dehumidifier log]] covers another barn device and the damp that affects both.
- [[Telbrond shed notes 2019]] has older lessons on damp, power and mounting from before the sensor was installed.
- [[Pertirk greenhouse tests]] has my approach to testing sensors against hand measurements.
- [[Velferk kiln controller tests]] has the method I borrowed for the seasonal comparison, namely write down expected values first, then measure.

Outside the notes, the only reference I rely on is the label and the small leaflet that came with the sensor. I keep the leaflet in a plastic sleeve in the toolbox. I do not copy its contents here, because the sleeve is the one source I treat as authoritative.

## Safety

The sensor is solar-powered and low-risk, but the barn and the boatyard are not risk-free.

- Use the step stool on firm ground when reaching the panel. Do not climb on boxes or boat stands.
- Keep the area around the sensor clear so I am not working in a cramped corner with sharp tools nearby.
- Wear gloves when handling the cable and bracket, since the edges can be sharp and the barn is full of splinters.
- Avoid water near any open connection. Wipe, do not spray, and close the housing before cleaning anything nearby.
- Even without mains power, a solar panel in bright light is live. Do not short its terminals and do not touch bare conductors.
- If the battery looks swollen, hot or leaking, stop, disconnect it, and keep it away from anything flammable.
- Tell someone when I am working alone in the barn, particularly when I am up high.
- Keep the walkway clear of cables. A trip in the barn with a tool in hand is the most realistic hazard.

If a drip or a wet floor shows up near the sensor, I deal with the floor first and the sensor second.

## Checklist

Quick list for a visit.

- [ ] Look at the reading and confirm it is sensible.
- [ ] Check the blue housing is secure and dry.
- [ ] Wipe the solar panel.
- [ ] Look at the cable for wear.
- [ ] Check the bracket and screws.
- [ ] Brush debris off the sensing end.
- [ ] Take a hand measurement and compare it with the sensor.
- [ ] Write the offset in the log.
- [ ] Note anything odd, such as damp, shade or gaps in readings.
- [ ] Put tools back in the box.

For the yearly tidy-up, add:

- [ ] Remove, clean and refit the sensor.
- [ ] Inspect seals and renew grease.
- [ ] Add fresh silica gel.
- [ ] Review the Ideas list and pick one thing to try.

## Lessons

What I have learned from keeping this sensor going since 2022:

- A clean panel solves more problems than any adjustment. Most of my trouble with it has been power, not the sensing itself.
- Always compare the sensor with a hand measurement. Trusting the display alone let a small drift grow unnoticed for a whole season.
- Write things down at once. My memory of what the reading was last month is not reliable.
- Damp is the barn's main enemy. Silicone grease, silica gel and a drip loop in the cable cost almost nothing and prevent most failures.
- Label every device. The barn holds several, and confusing them wasted time more than once.
- Keep spares of the small, cheap items such as screws, ties and tape, so a minor fix never stalls.
- Borrowing a method works well. The write-expected-first approach from [[Velferk kiln controller tests]] made my comparisons far more honest.
- Do not over-engineer. The sensor is simple, and a simple routine keeps it working.

## Open questions

Things I do not yet know and want to settle.

- Is the roof shadow really what drains the battery in winter, or is the cell simply ageing? A test with the panel in a brighter spot would tell me.
- How much does the flow rate figure of 159.70 l/h move across the year? I have recorded it, but I have not studied the variation.
- Does the level reading follow the pump cycles in [[Ziorzerk circulation pump log]] closely, or is there a delay?
- Would a hood keep condensation off, or just trap more of it?
- Should I add a second sensor for cross-checking, or is the seasonal hand measurement good enough?
- When the logger from [[Forknathpe data logger plan]] is built, will its readings agree with my notes, or will they show patterns I have been missing?
- How long will the battery last before it needs replacing? I have no firm answer yet.

## Background

I put the sensor in the barn in 2022 because I wanted to stop guessing about the level and start knowing it. The boatyard has plenty of jobs that depend on water and levels, and walking over to look was becoming a chore that I skipped when the weather was bad.

I chose a solar-powered unit deliberately. Running mains power to the corner of the barn would have meant extra cable, a socket, and one more thing to worry about in a damp building. A solar panel on the wall was simpler. The trade-off is the dependence on daylight, which I now understand better after several winters.

The blue colour was not a choice I made for any technical reason, but it has turned out useful. The barn is crowded and dim, and a bright blue housing is easy to find and hard to confuse with other gear.

My habit of testing devices against hand measurements comes from earlier experiments, mostly [[Pertirk greenhouse tests]] and [[Velferk kiln controller tests]]. The habit of watching for damp comes from [[Telbrond shed notes 2019]], where I learned the hard way that a closed building is not a dry one. The dehumidifier in [[Vensos dehumidifier log]] was a later response to the same problem.

## Overview

The Transto level sensor is a level sensor used in the boatyard area. It is blue, runs on solar power, was installed in 2022, and sits in the barn. Its flow rate figure, which I use as my reference, is 159.70 l/h.

It needs light care: a clean panel, a dry housing, a sound cable, and a regular comparison against a hand measurement. Most of its problems come from low power in winter and from damp, not from the sensing itself. The routines in Schedule and Checklist keep it healthy, and the Lessons section explains why each step is there.

For related work, see [[Forknathpe data logger plan]] for automatic logging, [[Ziorzerk circulation pump log]] for pump behaviour, and [[Vensos dehumidifier log]] for the damp in the barn. For older context and test methods, see [[Telbrond shed notes 2019]], [[Pertirk greenhouse tests]] and [[Velferk kiln controller tests]].

If I only have a minute at the barn, I look at the reading, wipe the panel, and write down what I saw. That is enough to keep the sensor useful until the next proper check.
