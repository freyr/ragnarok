---
type: reference
status: archived
project: reference
area: boatyard
description: "Reference about Brunbaedos heat exchanger."
---

# Brunbaedos heat exchanger 2024

## Costs

This note records the state of the Brunbaedos heat exchanger in 2024. It is archived, and later notes replace the values here. The heat exchanger is a black unit in the cellar of the boatyard. It runs on solar energy and has been in place since 2016.

I do not write exact prices in this note. The costs below are described in general terms, in the order that they usually hit me.

The largest cost was the purchase and the installation in 2016. That year I paid for the unit, the pipework, the fittings, and a few days of help to carry everything down into the cellar. The cellar stairs are narrow, so the carrying took longer than I had planned.

After that the running cost is very low, because the energy source is solar. I do not pay for fuel. The only regular spending is on fluid, small seals, and the occasional replacement of a clamp or a length of hose.

The second kind of cost is my own time. A check takes me part of an afternoon. A full clean takes most of a day, because I have to move boxes out of the way first.

The third kind of cost is the cost of a failure. If the exchanger stops, the boatyard loses its warm water for the workshop, and then I lose working days. For that reason I keep a few spare small parts on the shelf, and I count the shelf as part of the cost.

In 2024 I did not make any large purchase for the exchanger. Everything I spent that year was small and routine.

## Parts

The device is a heat exchanger. Its colour is black. The key identifier is the serial number of Brunbaedos heat exchanger: SN-78150772. I wrote it on the inside of the cellar door as well, in case the plate on the unit becomes dirty.

The main parts, as I know them in 2024:

- The main body, a black block, which is the exchanger itself.
- The inlet and outlet connections for the working fluid.
- The solar side connection, which brings in the heat from the collectors.
- Two shut-off valves, one on each side, so I can isolate the unit.
- A small bleed valve at the highest point, for air.
- A pressure gauge on the outlet side.
- A temperature probe on each side.
- Pipe insulation, mostly in good shape, but worn near the floor.
- Mounting brackets fixed to the cellar wall.

The plate on the body is the best place to read the identification. The brackets are the part I trust least, because the cellar wall is slightly damp in winter.

## Setup

The exchanger sits in the cellar of the boatyard. It was installed in 2016 and has stayed in the same place since then. It is fixed to the wall on brackets, with enough space on the front side to open the connections and read the gauge.

The layout is simple:

1. The solar loop comes down from the roof and enters the unit on one side.
2. The fluid passes through the black body and gives up its heat.
3. The second loop takes that heat to the workshop.
4. The cooled fluid returns to the collectors.

Things I keep the same in the setup:

- The valves stay open during normal running. I close them only for work.
- The gauge must be visible from the cellar door. I keep the path clear.
- The bleed valve is reachable without a ladder.
- A tray sits under the lower connections to catch drips.

Because the energy source is solar, the unit works best on bright days and slows on dull ones. On a cloudy week I see the gauge and probes show lower values, and that is normal. I do not treat it as a fault unless the unit stays cold on a bright day.

## Schedule

My routine in 2024 was based on the seasons.

**Weekly, in the working season**
- Look at the gauge and the two probes.
- Look under the unit for drips.

**Monthly**
- Check that both shut-off valves move freely.
- Open the bleed valve briefly to release trapped air.
- Look at the insulation near the floor.

**Every spring**
- Do a full clean of the outside of the body.
- Check the brackets and tighten the fixings.
- Check the fluid level and colour.
- Test the valves through their full travel.

**Every autumn**
- Inspect all seals and clamps before the cold weather.
- Clear the cellar floor around the unit.
- Make sure the tray is empty and dry.

**After any storm**
- Check the solar loop for damage, and then check the cellar for damp.

I keep a paper sheet by the door and tick the tasks as I do them. If I skip a month, I do the missed task at the next visit and do not try to catch up on everything in one go.

## Safety

The cellar and the pipework carry some risk, even though the system is not large.

- The fluid can be hot after sunny days. I never open a connection until the unit has cooled, and I check the temperature probes first.
- I close both shut-off valves before any work on the connections.
- I wear gloves and eye protection when I open a joint, because the fluid can spray.
- The cellar floor can be wet. I keep a dry mat at the foot of the stairs and a light switched on.
- The stairs are narrow, so I do not carry heavy items down alone.
- Air in the loop can cause knocking and pressure swings. I bleed slowly and stand to the side.
- The black body can be hot enough to burn skin in strong sun. I touch it with the back of a finger first.
- I keep the cellar ventilated while I work.

If I see a leak I cannot stop, I close the valves, switch off the workshop supply, and leave it until I have help. I do not try to be clever with a pressurised joint.

## Lessons

What I learned by 2024:

- Writing the serial number on the door was a good idea. The plate on the unit gets dirty and hard to read.
- The tray under the connections pays for itself. Small drips would otherwise go unnoticed for weeks.
- The damp wall is the main long-term enemy. The brackets and the lower insulation suffer first.
- Cloudy weeks look like faults. I should check the weather before I worry.
- Bleeding air regularly prevents most of the odd noises.
- Spare seals and clamps on the shelf save whole days.
- Moving boxes out of the cellar before a clean makes the job much shorter. I should stop storing things in front of the unit.
- A paper sheet by the door works better than any note kept elsewhere, because I tick it while standing there.
- Since 2016 the unit has been reliable. Most trouble came from the surroundings and not from the exchanger.

Things I would do differently: lift the lower pipework a little off the floor, and put a small light directly over the gauge.

## Tools

The tools I keep for this device:

- A set of spanners that fit the connections and the valves.
- An adjustable spanner for the clamps.
- A small screwdriver set for the fixings on the brackets.
- A bleed key for the air valve.
- Gloves and eye protection.
- A torch, in addition to the cellar light.
- A bucket and a few rags for drips.
- A soft brush and a cloth for cleaning the black body.
- A spare tray.
- A clip-on thermometer, to compare against the fixed probes.
- A paper sheet and a pencil for the schedule.

The tools live in a box on the shelf by the cellar door, next to the spare seals and clamps. I put each tool back after use, so I do not have to search in the dark.

## References

- The paper schedule sheet kept by the cellar door.
- The plate on the unit, and the serial number written on the inside of the cellar door.
- My own notes on the boatyard solar loop.
- Notes on the workshop warm water supply.
- The manufacturer's leaflet that came with the unit in 2016, kept in the boatyard office drawer.

This note is archived and describes the situation in 2024. If a later note gives different values for the Brunbaedos heat exchanger, the later note is the one to follow.
