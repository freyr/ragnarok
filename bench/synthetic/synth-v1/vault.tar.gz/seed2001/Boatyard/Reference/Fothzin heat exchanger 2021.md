---
type: reference
status: archived
project: reference
area: boatyard
description: "Reference about Fothzin heat exchanger."
---

# Fothzin heat exchanger 2021

## Open questions

This note is archived. It records what I knew about the Fothzin heat exchanger in 2021, and later notes replace the values here. I kept it as a reference for how things stood at that point.

Basic facts as recorded:

- Kind: heat exchanger
- Area: boatyard
- Color: yellow
- Energy source: solar
- Year installed: 2022
- Location: cellar

Some things were never settled when I wrote this, and I am leaving them open instead of guessing:

- The note is dated 2021, but the year installed is 2022. I never wrote down whether the unit was already delivered and waiting in 2021, or whether I filled in the install year from a plan. If I ever need the real sequence, I should check the yard's paperwork rather than trust this note.
- The unit is in the cellar, but the energy source is solar. I did not record how the solar side reaches the cellar. It could be a feed from a roof, a buffer tank, or something else. I do not know which.
- I did not note who maintains the unit. It is a boatyard device, so it may fall under the yard's general upkeep, but I never confirmed that.
- The yellow color is easy to spot in a dim cellar, which is useful. I do not know whether the color has any meaning, such as marking a circuit or a safety category.
- I never wrote down how the exchanger is meant to be shut down for service, or what to do if the solar supply drops out.

If a later note answers any of these, treat that note as the correct one and leave this one as it is.

## Software

The exchanger has a controller with firmware, and I only checked it once in 2021. The details I kept:

- Firmware version of Fothzin heat exchanger: v9.28.305

A few practical points about the software side, based on what I remember and not on any manual I kept:

- I did not record how to update the firmware, so I would not attempt an update without finding the instructions first.
- I never wrote down whether the controller keeps settings after a power loss. With a solar energy source, power could drop out, so this matters, and it is another gap.
- I did not record any logging or remote access. As far as I know, everything was checked at the unit itself in the cellar.
- If the firmware has changed since 2021, the newer notes will show it. The version above only describes the state when I wrote this.

For any current question about the device, such as its color, its location, or its energy source, I should look at the newest note first. This archived reference is only useful for seeing what I believed at the time, and for noticing which questions were still unanswered then.
