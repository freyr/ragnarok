---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Zaelmulzur radio receiver."
---

# Zaelmulzur radio receiver handbook

## Background

The Zaelmulzur radio receiver is a radio receiver that sits in the shed at the boatyard. It is green, it runs from mains power, and it was installed in 2021. This handbook is my own reference for how it is set up and how I keep it working. I wrote it so I don't have to rebuild the knowledge from memory each time something goes quiet.

The receiver is the only radio in the shed. We use it for weather bulletins, for the local harbour chatter that tells us when a hull is due in, and sometimes for background music while sanding. It is not a precision instrument. It is a plain, sturdy set that has to survive dust, damp air, resin fumes and the occasional knock from a plank.

Here are the properties in one place, so I can check them quickly:

| Property | Value |
|---|---|
| Name | Zaelmulzur radio receiver |
| Kind | radio receiver |
| Area | boatyard |
| Color | green |
| Energy source | mains |
| Year installed | 2021 |
| Location | shed |

A few practical notes follow from these values.

- **Mains power:** the receiver has no battery. If the shed circuit trips, the radio goes dead and loses nothing except its current station. Anything that affects the shed supply affects the radio.
- **Green case:** the paint is the original factory finish. It shows dust and white salt marks easily, which is useful because I can see when it needs a wipe.
- **Shed location:** the shed is not heated. The receiver sees cold mornings, damp evenings and swings in humidity. Most of its problems come from this, not from age.
- **Installed in 2021:** it has run for several seasons now. It has never needed a major repair, but small things have started to drift.

The receiver stands on a shelf near the door, at about shoulder height, away from the sanding bench. The aerial lead runs along the rafter and out through a small gap near the roof edge. The mains cable goes to a socket on the wall behind the shelf. I keep the cable tidy and off the floor, because water collects there after rain.

I treat the receiver as a shared tool. Anyone working in the shed can change the station and the volume, but only I should open the case or touch the aerial connection. That rule keeps the setup predictable.

## Maintenance

Maintenance is mostly about keeping dust, damp and vibration away from the set. I do not do anything clever. The routine is short enough to follow without a manual, but I write it down anyway so I notice when I skip steps.

### Regular routine

I go through the same pattern at the start of each season and again after any long wet spell.

- Switch the receiver off at the wall and pull the plug before touching anything.
- Wipe the green case with a dry cloth, then a barely damp one. No solvents, because resin cleaners cloud the dial window.
- Brush dust out of the vents with a soft brush. Do not blow into them with the compressor, because that pushes sawdust deeper in.
- Check the mains cable along its whole length for nicks, flattening or any soft spot.
- Check the aerial lead where it meets the case, and where it passes the roof gap.
- Plug back in and listen on a known station for hum, crackle or fading.

### What goes wrong most often

The most common fault is crackle in the volume control. It appears after damp nights and often clears after the set has warmed up for a while. The second most common is a weak signal, which has so far always been the aerial lead or its connector, not the receiver. The third is a faint mains hum, usually when another machine in the shed is running on the same circuit.

| Symptom | Likely cause | First action |
|---|---|---|
| No sound, no light | Mains supply or plug | Check the socket with another device |
| Light on, no sound | Volume or speaker lead | Turn volume up, check the speaker connection |
| Crackle when turning the knob | Damp or dirt in the control | Warm the set, then work the knob back and forth |
| Weak or fading stations | Aerial lead or connector | Reseat the connector, inspect the lead |
| Constant hum | Shared circuit or earth issue | Run the set with other machines off |

### Simple log of checks

I keep a plain text file on my laptop where I note what I did and what I saw. The format is deliberately loose. Here is a template of the kind of entry I write:

```
receiver: Zaelmulzur radio receiver
location: shed
power: mains
season-check: done
case-wiped: yes
vents-brushed: yes
cable-inspected: yes
aerial-inspected: yes
sound-test: clean
notes: slight crackle in volume knob, cleared after warm-up
```

I fill it in after each routine. Over time it shows me patterns, such as the crackle returning every autumn.

### Things I do not do

I do not open the case while it is plugged in. I do not spray contact cleaner into the controls, because past attempts on other equipment left residue that attracted more dust. I do not move the receiver to the floor or the bench, even briefly, because sawdust and spilled liquids are far more likely there. I also do not run the set through an extension reel that is coiled up, since a coiled cable overheats.

If a fault survives the first action in the table, I unplug the set, put a tag on it saying it is faulty, and decide whether to repair it or replace it. So far I have not needed to.

## Open questions

These are things I do not know yet, or have not decided. I list them so I remember to look into them rather than assume.

- **Is the shed circuit clean enough?** The hum when machines run suggests the supply is noisy. I do not know whether a separate socket, or a mains filter, would help. I would like to test the receiver on a different circuit before buying anything.
- **Why does the crackle return every autumn?** It may be damp, but it may also be wear in the volume control. I cannot tell the difference without opening the case, and I would prefer not to unless the problem gets worse.
- **Is the aerial position the best one?** The lead runs along the rafter, but I never compared it with other routes. A different path might give stronger reception on the stations I care about.
- **How long will the receiver last in the shed?** It has run since 2021 without a major failure. I have no idea whether that is typical for this sort of set in unheated conditions, or whether I am simply lucky.
- **Should the receiver have a cover?** A simple fabric cover when the shed is not in use might keep dust off. But it could also trap damp and make things worse. I need to try it on a dry stretch and watch.
- **Who else needs to know the rules?** The rule about only I opening the case is not written anywhere visible in the shed. I should put a short label on the shelf.

For each question, the next step is small. I would rather test one change at a time than fix everything at once and not know which change helped.

## Checklist

Use this list for a seasonal service. Tick each item and copy the result into the log file.

- [ ] Power off at the wall and unplug the receiver
- [ ] Wipe the green case, dry cloth first
- [ ] Brush dust from the vents
- [ ] Inspect the mains cable along its length
- [ ] Inspect the aerial lead and connector
- [ ] Check the shelf is dry and stable
- [ ] Plug in and switch on
- [ ] Test on a known station for clean sound
- [ ] Work the volume knob and note any crackle
- [ ] Listen for hum with other shed machines running
- [ ] Write the results in the log file
- [ ] Note any new question in the open questions list

Quick check before a big job in the shed:

- [ ] Receiver is on its shelf, not on the bench
- [ ] Vents are clear
- [ ] Cable is off the floor

## References

These are the sources I rely on. They are all my own notes and the paperwork I keep, not outside material.

- My own seasonal log file for the Zaelmulzur radio receiver, kept on my laptop.
- The printed instruction leaflet that came with the receiver, stored in the shed drawer under the tape rolls.
- My general notes on shed electrical safety for the boatyard.
- My notes on aerial leads and connectors, which cover how I reseat them.
- The installation note from 2021, which records where the receiver was put and why.

If I find a better source later, I will add it here and remove anything that proves wrong.

## Lessons

A few things I have learned from keeping this receiver running in the shed.

- **Damp matters more than age.** Nearly every fault I have seen lined up with wet weather, not with how long the set has been running.
- **Check the simple things first.** Plug, socket, volume, aerial lead. Most problems end there, and I have wasted time suspecting the receiver itself.
- **Keep it off the floor and away from the bench.** Sawdust and spills are the main enemies. A shelf near the door has worked well.
- **Write things down.** The log file shows patterns I would not remember, like the autumn crackle.
- **Change one thing at a time.** When I move the aerial or try a new socket, I do only that, then listen. Otherwise I cannot tell what helped.
- **Mains power is convenient but ties the receiver to the shed circuit.** I should treat the supply as part of the radio, and not as something separate.
- **Keep the rules simple.** Anyone can use the dial and volume, and only I open the case. That has avoided accidents and confusion.

## Risks

The Zaelmulzur radio receiver is a radio receiver that runs on mains power, and it sits in the shed at the boatyard. Those three facts account for most of the risks.

- **Damp.** The shed is not heated. Condensation forms on cold mornings, and a mains device in that air is the first thing I worry about. The green case is not sealed.
- **Dust.** Sanding and grinding happen close to the shed. Fine dust gets into the vents and the tuning knob and slowly makes the controls scratchy.
- **Mains supply.** The receiver takes power from the shed socket. If that socket is shared with a heater or a charger, an overload can trip the whole circuit and silence the radio without warning.
- **Fire.** Sawdust, solvent rags and varnish tins are stored in the shed. A hot or faulty mains device near them is a real hazard, so nothing flammable should sit against the receiver.
- **Lightning and surges.** The aerial runs outside. In a storm the receiver should be unplugged, and the aerial lead disconnected as well if there is time.
- **Reliance.** People at the yard use it for weather and for the working channel. If it fails during a lifting job, there is no backup in the shed, so someone must carry a handheld set.
- **Noise.** A loud receiver in a shed full of power tools can hide shouted warnings. Keep the volume sensible and never use the radio as a substitute for a spoken signal during a lift.

The main habit that reduces all of this is a quick look before each working week: is it dry, is it clear of rags, is the plug seated?

## Costs

I do not record exact prices here. This section lists what money goes into the receiver and how I think about it.

The purchase was a one-off cost when it was installed in 2021. Since then the running cost is small, because mains power for a receiver is a very low draw compared with the tools in the same building. I have never noticed it on the yard's bill.

The costs that do come up are these:

- **Replacement fuses.** Cheap, and I keep a few in the shed drawer.
- **Contact cleaner.** One can lasts a long time and is used on the knobs and the aerial socket.
- **Aerial lead and connectors.** The outdoor lead ages in sun and salt air. Replacing it is the most likely larger expense.
- **Silica gel or a small dehumidifier.** An optional cost that cuts the damp risk.
- **A spare receiver.** The big decision. A second set costs a full purchase again, so I only consider it if the first one fails beyond a simple repair.
- **My time.** Cleaning and checking take a short slot each month, and I count that as a cost too.

A repair is worth it when the fault is a connector, a fuse, or a dirty control. If the fault is inside the tuning circuit, I would rather replace the set than pay a specialist.

## History

The receiver was installed in 2021. Before it, the boatyard relied on a battery portable that someone brought in and took home again, so there was no fixed radio and the shed was often silent during weather warnings.

The decision to fit a fixed set came after a day when a forecast change was missed while boats were out of the water on cradles. The yard wanted something that stayed in the shed, ran from the mains and did not depend on batteries.

The green case was chosen mostly by accident: it was the one available, and it turned out to be easy to spot on a crowded shelf. The name Zaelmulzur is just what we have always called it, and it stuck.

Since 2021 the history is mostly quiet:

- The first year went without trouble.
- A damp winter brought the first crackling on the volume control.
- The aerial lead was replaced once after it was nicked by a ladder.
- The shelf was moved higher after a spill of water on the floor.
- The mains plug was refitted with a new fuse after an intermittent cutout.

Nothing in that list needed the set to be taken out of service for long. I keep this short record so I can see whether problems repeat.

## Setup

The facts about the device are kept in one table so I can copy them elsewhere.

| Property | Value |
|---|---|
| Kind | radio receiver |
| Area | boatyard |
| Color | green |
| Energy source | mains |
| Year installed | 2021 |
| Location | shed |

The receiver stands on a shelf inside the shed, off the floor and away from the door. The shelf is on the dry wall, not the one facing the slipway.

Setup steps, in the order I do them:

1. Check that the shelf is dry and clear of rags, tins and tools.
2. Connect the aerial lead first, with the set unplugged.
3. Plug the mains lead into the dedicated socket, not an extension reel.
4. Switch on and turn the volume to a low level.
5. Tune to the working channel and then to the weather channel, noting where the knob sits.
6. Mark the knob position with a small dab of paint so it is easy to return to.
7. Set the volume so it is clear at the workbench but not painful.

The mains socket should be one that is not shared with a heater. If the shed ever gets a residual current device, the receiver should be on it.

A simple note I keep beside the set looks like this:

```
Zaelmulzur radio receiver - shed checklist
shelf:        dry, clear of rags
aerial:       lead intact, plug tight
mains:        plug seated, fuse ok
knobs:        move smoothly, no crackle
channels:     working channel ok, weather channel ok
storm rule:   unplug before thunder
```

## Problems

These are the faults I have seen or expect, with the fix that worked or is likely to work.

**Crackling when turning a knob.** This is dust or damp on the control. Switch off, unplug, spray a small amount of contact cleaner, and turn the knob back and forth several times. Leave the set unplugged until it is dry.

**Weak or noisy reception.** Look at the aerial lead first. A cracked outer sheath or a loose plug is the usual cause. Reseat the plug and check the lead along its full length. If it is still poor, try moving the aerial a little away from metal roofing.

**No sound at all.** Check, in this order: the socket, the plug fuse, the volume, the channel selector. A tripped circuit in the shed is common after the heater has been on.

**Hum.** A low hum often means the mains lead is lying across another cable. Separate them. If the hum stays, the set may be picking up interference from a tool charger nearby, so unplug the charger and see.

**Drifting tuning.** After a cold night the set sometimes takes a few minutes to settle. If it drifts all day, the cause is more likely a failing component than the weather, and that is the point where I consider replacement.

**Warm case.** The case should be only slightly warm. If it is hot, switch off and unplug at once, clear the vents, and do not use it again until it has been looked at.

**Silence during storms.** This is not a fault. I unplug it on purpose, so the weather channel should be checked on a handheld set during that time.

## Tools

The tools I keep for the receiver are few and live in a labelled tin in the shed.

- A small screwdriver set for the case and the plug.
- Contact cleaner for the knobs and aerial socket.
- A soft brush and a dry cloth for dust on the green case and the vents.
- Spare fuses of the right type for the plug.
- A basic multimeter for checking the socket and the lead.
- Cable ties to keep the aerial lead and the mains lead apart.
- Silica gel packs for the shelf.
- A torch, because the shed lighting is poor behind the shelf.
- A handheld set, as a backup when the receiver is unplugged or being cleaned.
- Paint pen for marking the knob positions.

Routine use of the tools follows a simple monthly pattern. Unplug the set, brush the vents, wipe the case, inspect the aerial lead, test the socket, then plug back in and check both channels. After a storm or a wet spell I repeat the whole routine at once instead of waiting for the month to end.

I only open the case when a fuse or a loose connector is the likely cause and the set has been unplugged for some time. Anything involving the inside of the tuning circuit goes to someone qualified, or the set is replaced.

## Safety

The Zaelmulzur radio receiver runs on mains power, so treat it like any other mains device in the shed. The shed is damp in winter, and boatyard dust gets into everything. Most of the rules below come from that.

- Unplug the receiver from the wall before opening the green case. Switching it off at the front is not enough, because the mains transformer inside stays live up to the switch.
- Do not touch the inside while standing on wet concrete. Put the rubber mat down first. It lives under the bench.
- Keep the receiver away from the sanding area. Fine dust is a fire risk near warm parts and it clogs the vents.
- Never run it with the case off while solvents or varnish are open in the shed. Vapour and a spark from a switch is a bad mix.
- Do not hang the antenna lead over the mains lead. If the antenna touches a bare mains wire, the antenna side becomes live.
- During a thunderstorm, unplug both the mains lead and the antenna lead. Do not just turn it off.
- If the case feels hot, or there is a burnt smell, pull the plug at the wall, not at the unit, and leave it for a while before looking.

Basic habit: one hand on the bench, one hand inside, never both hands in at once when the unit has been powered recently. The big capacitors can hold charge after unplugging. Wait a few minutes and discharge them with an insulated tool before touching anything near them.

## Ideas

These are things I want to try or improve. None are done yet.

- Move the receiver up onto a shelf. At the moment it sits on the bench, where it collects dust and the odd splash of water from the hose.
- Add a small dust filter cloth over the rear vent, held with a clip so it can be washed.
- Fit a proper outdoor antenna on the shed roof. The current wire runs along the rafter, and reception drops when the big doors are open.
- Put a mains surge strip with its own switch between the wall and the receiver, so I can cut power fully at the door when I leave.
- Make a laminated card with the station presets and tape it beside the unit, so I stop guessing.
- Replace the paper-style dial lamp with a modern one that stays cooler.
- Paint a small label on the case saying "unplug before opening". Green paint hides a normal sticker badly, so use white.
- Try a ferrite ring on the antenna lead to cut the noise from the bandsaw.

A longer idea is to keep a spare receiver of the same kind in the house, in case this one fails in the middle of a busy season. Weather reports matter in a boatyard, since launches and lifts depend on them.

## Overview

The Zaelmulzur radio receiver is a radio receiver used in the boatyard. It is green, with a plain metal case and a large tuning dial. It runs on mains power and has no battery option. I installed it in 2021, and it has stayed in the shed ever since.

Here are the properties in one place:

| Property | Value |
| --- | --- |
| Kind | radio receiver |
| Area | boatyard |
| Color | green |
| Energy source | mains |
| Year installed | 2021 |
| Location | shed |

What it does for me day to day:

- It gives background radio while I work on hulls and fittings.
- It carries the local weather and tide bulletins, which decide when work outside is sensible.
- It is the only radio in the shed, so it also serves as the signal to stop work when an announcement comes through.

Controls are simple. There is a power knob that also sets volume, a tuning knob, a band switch, and a tone control. A single mains lead goes out of the back, next to a screw terminal pair for the antenna. A small lamp lights the dial when it is on.

A typical start-up routine, kept as a note so I do it the same way each time:

```text
# start-up routine, shed receiver
1. check mains lead is not under the bench leg
2. check antenna lead is attached and away from mains lead
3. switch on at the wall
4. turn power knob to low volume
5. wait for the dial lamp and a short warm-up
6. select band, then tune slowly
7. raise volume to a level that does not hide the saw
```

At shutdown I turn the knob off, then switch off at the wall. I do not leave it on overnight.

## Observations

These are notes from using it in the shed since 2021.

**Reception.** Reception is good on the main band when the shed doors are open and weaker with them shut. The metal roof seems to act as a partial screen. Noise rises when the bandsaw or the dust extractor runs. It comes back to normal when they stop, so it is interference and not a fault in the receiver.

**Warm-up.** The unit needs a short while to settle after switching on. In the first minutes the tuning drifts a little and I have to nudge the dial. After that it holds steady. In cold weather the drift lasts longer.

**Damp and dust.** The shed gets humid, and on cold mornings I have seen faint condensation on the outside of the green case. The dial glass fogs sometimes. I wipe it dry before switching on. Dust collects on top and around the rear vent, and I clean it with a soft brush after any sanding session.

**Sound.** The speaker is clear for speech. Music is a bit thin, but I use it mainly for bulletins, so it does not matter. The tone control helps with the low hum that appears when the extractor shares the same wall socket. Moving the receiver to a different socket cut the hum a lot.

**Heat.** It runs warm but not hot. The top of the case is pleasant to the hand after a few hours. If it ever becomes too hot to rest a hand on, that is a sign to check the vent for dust.

**Reliability.** Since 2021 it has not failed completely. There was one crackly volume knob, which was cured by turning the knob back and forth many times and later by contact cleaner. A scratchy knob tends to return after a damp spell.

**Things to watch:**

- Crackle when turning the volume, a sign of dirty contacts.
- Hum that changes with the volume knob position, which may point to a tired capacitor.
- A dial lamp that flickers, which usually means a loose bulb holder.
- Loss of sound on one band only, which suggests the band switch needs cleaning.

A simple weekly check keeps most trouble away: wipe the dial, brush the vent, look at the mains lead for damage, and listen for hum with the volume low.

## Parts

The part number of the Zaelmulzur radio receiver is EY-3504-N. I use this number when asking for help or looking for a replacement unit. Parts inside are described by function only, because I have not noted separate numbers for them.

| Part | Role | Notes |
| --- | --- | --- |
| Case | Green metal housing | Repaint with a rust-resistant paint if chipped |
| Power knob | On/off and volume | Prone to crackle in damp weather |
| Tuning knob | Moves the dial pointer | Smooth, no play |
| Band switch | Selects the radio band | Clean with contact cleaner if a band drops out |
| Dial lamp | Lights the scale | Easy to replace |
| Speaker | Output sound | Cone is fine, grille collects dust |
| Mains lead | Brings power in | Check for cracks near the plug |
| Antenna terminals | Screw pair at the back | Keep tight, keep clear of mains |
| Mains transformer | Steps down mains voltage | Warm in use, do not touch with case open |
| Capacitors | Smooth the supply | Store charge, discharge before work |

Notes on spares and upkeep:

- Keep a spare dial lamp and a small can of contact cleaner in the drawer under the bench.
- If the mains lead is ever replaced, use one of the same kind with a proper earth arrangement if the original had one.
- Any repair that goes beyond cleaning, a lamp, or the lead should be done by someone qualified, since the inside carries mains voltage.
- When ordering anything, quote EY-3504-N, the color (green), and that it is a mains receiver.
