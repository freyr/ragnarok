---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Traenren Zirktrand."
---

# Traenren Zirktrand

## Ideas

Traenren Zirktrand is my neighbor at the boatyard. I have known him since 2020. The best way to reach him is by phone, and he is only available on weekends, so anything I want to ask him has to wait until Saturday or Sunday. I keep a short list of things worth raising with him.

- Ask whether he wants to share a bulk order of rope and fenders. Buying together should make the order easier to justify.
- Borrow his eye for a second opinion on my winter cover frame before I commit to the layout.
- Ask whether he would walk the yard with me and point out the soft spots in the access track after heavy rain.
- Compare notes on radio gear. I want to show him what is in [[Fesbis radio receiver handbook]] and hear whether his experience matches it.
- Show him the results in [[Krithdel solar charger tests]], since he has a boat with no shore power and may want to try one.
- Talk through the bench checks written up in [[Stundglerk Keglu tests]], and ask if he would repeat one on his own setup so I have a second set of observations.

A practical note: because he is only around on weekends, I should call with a short list ready. If I ramble, we both lose the little time we have. I keep the phone call to the point and write down any answers straight afterwards in this note.

## Contracts

Our arrangement is informal, but there is one written agreement between us. The contract date of Traenren Zirktrand is 2018-03-16. That is earlier than the year I met him as a neighbor (2020), so the paper dates from before our regular contact started. I should not read too much into that; it is simply the date on the document.

What the agreement covers, in plain terms:

- Shared use of the yard access and keeping it clear of gear.
- A promise to give notice by phone before doing noisy work on a weekend.
- Each of us looks after our own boat and cradle, and neither of us is responsible for the other's.

Anything beyond that is just a favour between neighbors, and I try to treat it that way. If I borrow a tool, I return it the same weekend. If he does me a favour, I note it here so I remember to return it.

Summary of the key properties, so I do not have to hunt for them:

| Property | Value |
| --- | --- |
| Name | Traenren Zirktrand |
| Role | neighbor |
| Area | boatyard |
| Contact | phone |
| Availability | weekends |
| Known since | 2020 |
| Contract date | 2018-03-16 |

If the agreement ever needs to change, I will raise it on a weekend call and write down what we both said before touching the paper itself. A verbal change is not worth much if neither of us can remember it later.

## Costs

We do not have a formal cost split, but there are a few areas where money comes up between us. I keep the list here so the arrangement stays fair and nobody feels short-changed.

- **Yard upkeep:** When the access track needs gravel or repair, we split the cost evenly and agree on it by phone first. I do not pay anything before we have both said yes.
- **Shared orders:** If we buy rope, fenders or similar items together, whoever places the order pays up front and the other pays back on the next weekend we meet. I write the amount in my own ledger rather than here.
- **Borrowed gear:** Nothing is charged for borrowing a tool. If something breaks while I have it, I replace it or pay for the repair. The same goes for him.
- **Test equipment:** If he tries a charger or receiver after reading my notes, I do not expect him to buy anything. Any parts he wants for his own boat are his to pay for.

A few habits keep the money side simple:

1. Agree on the cost before spending, even for small things.
2. Settle up within a weekend or two, never leave it hanging.
3. Keep a note of who paid for what, so there is no argument later.
4. If a cost is bigger than we expected, stop and call again before going on.

Because he is reachable only on weekends, I try not to let a cost question sit for a whole week. If something comes up midweek, I write it down and ask on Saturday morning. That way the answer arrives while the work is still fresh.

Overall, Traenren has been an easy neighbor to deal with since 2020. The costs we share are small, the rules are clear, and the written agreement gives us something to fall back on if we ever disagree. I will keep this note up to date after each weekend call.
