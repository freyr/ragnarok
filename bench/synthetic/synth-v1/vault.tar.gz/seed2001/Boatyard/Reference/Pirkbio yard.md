---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Pirkbio yard."
---

# Pirkbio yard

## History

Pirkbio yard is a small yard in the boatyard area, built in 2021. It sits at ground level and faces east. I keep these notes for my own use, so they are practical and not a formal record.

The yard was built in 2021 as a compact working space. From the start it was meant to be small: a few boats at a time, a hardstanding, and a bit of room to walk around them. It was never planned as a place for large vessels. The east orientation means the morning sun reaches it first. That has mattered more than I expected. Dew and frost burn off early, and paint and varnish jobs can start sooner in the day than they could in a yard facing the other way.

The ground-level floor is the other thing I notice daily. There are no steps, ramps or lifts between the gate and the working area. Everything can be moved on a trolley or carried by hand without planning a route. When a boat needs to be shifted, the path is flat and short.

Over the years the yard has settled into a routine. Spring is the busy period, with hulls being scraped, sanded, and painted. Summer is quieter and used for small repairs. Autumn is for hauling out and covering. Winter is for planning, checking stored gear, and indoor work on parts that can be taken off the boats.

Things I want to remember about how the yard has developed:

- The small size has stayed the same since 2021. Nothing has been extended.
- The east orientation has not changed, and I have never found it to be a problem.
- The ground-level layout has kept the yard easy to use, even when I am working alone.
- Most improvements have been small and practical: better storage, a tidier layout, and clearer marking of where things belong.

## Tools

The tools in a small yard need to be few, well kept, and easy to find. This is the working list as I understand it.

Hand tools:

- Scrapers and putty knives for removing old paint and growth.
- Sanding blocks and a set of sanding sheets in several grades.
- Screwdrivers, spanners, and a small socket set.
- A mallet and a set of chisels for woodwork.
- Brushes, rollers, and trays for paint and varnish.

Power tools:

- A random orbital sander for hulls and decks.
- A drill and driver with spare batteries.
- A small angle grinder for metal fittings.
- A wet and dry vacuum for dust.

Handling and support:

- Boat stands and wooden chocks for holding hulls.
- A trolley for moving gear across the flat ground.
- Straps, ropes, and tarpaulins for covering and securing.
- A stepladder and a sturdy work platform.

Safety and cleaning:

- Dust masks and respirators for sanding and painting.
- Gloves, eye protection, and ear defenders.
- A first aid kit kept near the gate.
- Rags, buckets, and a stiff broom.

Because the yard is small, I try not to keep tools I rarely use. If something has not been touched in a full season, I ask whether it belongs here or somewhere else. The ground-level floor makes it easy to wheel a tool chest to the job, so I do not need to duplicate tools in several places.

Storage matters as much as the tools themselves. A tool that cannot be found is as useless as one that is missing. I keep a simple rule: everything has a place, and it goes back there at the end of the day.

## Open questions

These are things I have not settled. I write them down so I do not forget them.

- How many boats can the yard hold comfortably at one time? Because it is small, I suspect fewer than I sometimes try to fit in, but I have not measured it properly.
- Is the east orientation causing any trouble in the afternoon, when the yard may fall into shade? I have noticed it but not recorded how early the shade arrives.
- Would a simple roof or canopy over part of the ground-level area be worth the cost? It would help in wet weather, but it might also block light.
- Is the current drainage enough in heavy rain? Water seems to collect in one corner, and I want to check where it goes.
- Should the storage be rearranged? The present layout works, but I think some of it grew by accident.
- What is the best way to keep the yard tidy when several jobs are running at once?
- Does the lease allow the changes I am considering? I need to read the terms again before I commit to any building work.

I will move items out of this list as I find answers, and I will note where the answer came from.

## References

This section lists the things I check when I need to confirm something about the yard. They are my own sources, not published ones.

- The lease document for the yard, kept in my paper files. The reference is given in the Admin section below.
- My own notes from each season, covering what was done, what broke, and what I would change.
- Photographs taken of the yard in different seasons, useful for comparing light and water on the ground.
- A sketch plan of the layout, drawn by hand, showing the gate, the hardstanding, and the storage areas.
- Maker instructions for the larger power tools, kept in a folder near the tool storage.
- Advice from other people who work in the boatyard area, written down after conversations.

Basic facts about the place, for quick lookup:

- Name: Pirkbio yard
- Kind: yard
- Area: boatyard
- Orientation: east
- Size: small
- Year built: 2021
- Floor: ground level

If any of these facts ever changes, I should update this list first and then the rest of the note.

## Checklist

I use this list at the start and end of a work period. It is short on purpose so that I actually follow it.

Start of the day:

- Unlock the gate and look over the yard for anything out of place.
- Check the ground for standing water, especially in the low corner.
- Look at the weather and decide whether painting or varnishing is sensible.
- Get out only the tools needed for the day's jobs.
- Check that boat stands and chocks are steady.

During work:

- Keep walkways clear so that the trolley can move freely.
- Sweep dust and shavings regularly rather than leaving them to the end.
- Close paint tins and solvent containers after each use.
- Wear the right protection for each task.

End of the day:

- Return every tool to its place.
- Cover boats and loose materials with tarpaulins.
- Empty buckets and wash brushes.
- Check the stands again before leaving.
- Lock the gate.

Monthly:

- Look at the condition of the stands, straps, and ropes.
- Check the first aid kit and replace anything used.
- Walk around the boundary and note any damage.

Yearly:

- Review the lease terms and the costs.
- Sort through the tools and remove what is not used.
- Update this note.

## Costs

I do not track every small expense in this note, and I avoid writing exact prices here because they change. Instead I list the kinds of cost so that I know where money goes.

Regular costs:

- Rent or lease payments for the yard, set by the lease terms.
- Paint, varnish, thinners, and sanding materials, which are the biggest ongoing item in spring.
- Replacement blades, discs, and sanding sheets for power tools.
- Cleaning supplies and disposal of waste, including old paint and solvent.
- Insurance for the yard and for the equipment kept in it.

Occasional costs:

- Replacement of worn stands, chocks, straps, and tarpaulins.
- Repairs to the gate, fence, or ground surface.
- New or replacement power tools when an old one fails.
- Drainage work, if the water problem in the corner gets worse.

Possible larger costs:

- A canopy or roof over part of the working area.
- Better lighting for short winter days.
- Improved storage, such as lockable cabinets or racks.

Because the yard is small, the costs stay modest compared with a larger site. The ground-level floor also saves money, since I do not need ramps or lifting aids. Even so, I try to buy only what I will use, and I would rather repair a tool than replace it.

## Risks

A small yard still carries real risks. I keep them in mind and try to deal with them before they become problems.

- Boats falling from stands. This is the most serious risk. Stands must be placed on firm ground and checked often, particularly after rain or wind.
- Dust and fumes from sanding, painting, and solvents. The right mask and good airflow are needed, and I should not work in a closed space.
- Fire. Solvents, rags, and sanding dust can burn. I keep rags in a closed metal container and keep ignition sources away from paint.
- Slips and trips. Even on a flat ground-level floor, ropes, hoses, and tools can cause falls. Clear walkways help.
- Water collecting in the low corner, which can make the ground soft and affect how stands sit.
- Theft or damage. Tools and materials are valuable, so the gate must be locked and the storage kept tidy.
- Weather. Wind can catch tarpaulins and loosen covers, and frost can damage wet paint or fillers.
- Working alone. In a small yard I am often the only person present, so I keep the first aid kit near the gate and a phone within reach.
- Lease problems. If I break a term of the lease, I could lose the yard, so I should know what the terms allow.

The east orientation has a small effect on risk. Morning light helps visibility early, but low sun can make it hard to see detail in the first hours, and the afternoon shade can hide uneven ground.

## Admin

This section holds the paperwork and the practical details for the yard.

- Lease reference of Pirkbio yard: LR-482465

Other administrative points:

- The lease paperwork is kept in my paper files, with a note of when it needs review.
- Insurance details are filed with the lease, so both can be found together.
- Any messages with the yard owner or other users are saved with the date, so I can show what was agreed.
- Changes to the yard, such as new storage or a canopy, should be checked against the lease before I go ahead.
- Receipts for larger purchases are kept for the year.

Facts about the yard for official use:

- Kind: yard
- Area: boatyard
- Orientation: east
- Size: small
- Year built: 2021
- Floor: ground level

I review this section once a year, at the same time as the checklist. If the lease reference or any other detail changes, I will update it here first.

## Ideas

These are things I might try. None is a commitment.

- Add a light canopy over one part of the yard so that work can continue in drizzle. It should be easy to remove, so it does not break the lease terms.
- Mark the ground with paint lines to show where boats, stands, and walkways go. In a small yard, clear marking would make better use of the space.
- Build a tool wall near the gate with outlines of each tool, so that anything missing is obvious at a glance.
- Set up a small drainage channel to carry water away from the low corner.
- Keep a simple logbook at the gate, recording who was in the yard and what work was done.
- Make a seasonal plan so that heavy jobs fall in the months when the morning light is best.
- Use the east-facing side for a drying area, since the early sun helps paint and varnish set.
- Add lockable storage for paint and solvents, separate from the main tool area.
- Take a photograph of the yard each month, to see how it changes through the year.
- Ask other users in the boatyard area whether they would like to share the cost of any improvements.
