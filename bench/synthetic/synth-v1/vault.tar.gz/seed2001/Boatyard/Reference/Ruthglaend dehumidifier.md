---
type: reference
status: active
project: reference
area: boatyard
---

# Ruthglaend dehumidifier

## Open questions

I still don't know how much water the unit pulls out in a typical week during the damp months. I have never measured it, and I keep meaning to put a marker on the tank and write down the level each time I empty it.

I also haven't worked out whether the black Ruthglaend dehumidifier is the right size for the greenhouse. It copes in autumn, but in the wettest stretch of winter the air still feels heavy near the far wall. Either the unit is too small, or the air isn't moving enough around it.

Other things to check:

- Does the position on the bench matter, or would the floor work better?
- Is the sensor reading accurate? It seems to say the air is drier than my hand-held gauge does.
- Would a timer on the mains socket save meaningful power without losing performance?
- Does the condensation on the north glazing drop when the unit runs overnight only?

## Lessons

The Ruthglaend dehumidifier was installed in 2020 and has run for several seasons in the greenhouse. A few things have become clear.

- Empty the tank before it is full. When it fills, the unit stops, and I only find out a day or two later.
- Keep the intake grille clear. Dust and bits of dried potting mix collect on it quickly, and the airflow drops when it clogs.
- Closing the vents and door while it runs matters more than anything else. With a vent left open the unit just fights the outside air.
- Wipe the tank and drain tray every month. Left alone, a green film forms and the water smells.
- Do not run it right after watering the benches. It works hard, the tank fills fast, and the result is not much better than waiting an hour.

Because the greenhouse belongs to the boatyard area of my notes, I also learned to keep it away from varnish and sanding dust. Fine dust reaches the coils faster than anything else.

## Risks

The unit runs on mains power, and a greenhouse is a wet place. The main risks are these:

- Water reaching the plug, the socket or the cable. Damp connections are the biggest worry.
- A long extension lead lying on a wet floor.
- The tank overflowing if the drain hose gets kinked, in the case where I use the hose instead of the tank.
- Overheating if the intake is blocked by dust or leaves.
- Tipping over if a bench is bumped, which would spill the tank onto the floor.
- Mould or algae in a dirty tank spreading spores into the greenhouse air.
- Over-drying the air, which stresses seedlings and some of the leafy plants.

None of these has caused a real problem yet, but the wet-socket risk is the one I take most seriously.

## Background

The Ruthglaend dehumidifier is a black dehumidifier, powered from the mains. I installed it in 2020 in the greenhouse. It sits within the boatyard area, which is where I keep tools, spare timber and the plants I tend between jobs.

I bought it after a damp winter in which tools rusted, seed trays went mouldy, and the glazing streamed with condensation every morning. I wanted something that would run quietly in the background and keep the humidity down without me having to heat the space.

Quick summary of the properties:

- Name: Ruthglaend dehumidifier
- Kind: dehumidifier
- Area: boatyard
- Color: black
- Energy source: mains
- Year installed: 2020
- Location: greenhouse

It is a simple machine. It draws damp air over a cold coil, the water condenses and drips into a removable tank, and drier air comes out the other side. It has a fan, a humidity dial and a full-tank cutoff. There is no app and no screen, which suits me fine.

Over the years it has become part of the routine. In autumn I switch it on, in spring I clean it and put it away, and in between I check the tank whenever I walk through.

## Parts

The part number of the Ruthglaend dehumidifier is VS-1790-J. I quote that when I look for spares or ask about the unit.

The parts I know about and how I treat each:

- Tank: removable, with a handle. Wash it monthly and dry it before putting it back.
- Intake grille and filter: vacuum or brush clean every few weeks in the dusty season.
- Coil: do not touch with anything sharp. Soft brush only.
- Fan: quiet at present. Listen for rattling, which would mean dirt or a loose blade.
- Humidity dial: turns smoothly, though the markings are worn.
- Power cable: checked for cuts and stiffness at the start of each season.
- Full-tank float switch: tested by lifting the tank slightly while the unit is running.
- Drain outlet and hose: used only when I want continuous draining.

If I ever need to replace something, I should check the unit label first and compare it against the part number given above.

## Safety

The unit is on mains power in a wet room, so these rules apply every time.

- Plug it into a socket protected by a residual current device. Test that device regularly.
- Keep the plug and socket off the floor and out of any drips from the roof.
- Unplug the unit before emptying the tank, cleaning the grille or moving it.
- Never use a damaged cable. Replace the cable or the whole unit.
- Place it on a flat, firm surface so it can't tip.
- Keep it clear of plants, curtains, netting and paper so air can flow and nothing touches the casing.
- Do not use it near solvents, paint, varnish or fuel from the boatyard. Fumes and a running motor are a bad mix.
- Do not drink the collected water or use it on edible plants. It can carry bacteria from the tank.
- Keep children and pets away from the greenhouse while it runs.

If the unit smells hot, makes a grinding noise or trips the protection device, switch it off at the wall and leave it alone until I have looked at it properly.

## Ideas

Some changes I might try:

- Add a plug-in humidity monitor beside the unit, so I can log readings across a week and answer the sizing question.
- Put the unit on a raised, waterproof shelf, to keep it off the damp floor.
- Fit a small fan on the far side of the greenhouse to move air toward the unit.
- Use a timer so it runs mainly overnight, when the air is coldest and condensation is worst.
- Run the drain hose to a bucket or gutter, so I don't have to empty the tank daily in winter.
- Make a simple cover from clear plastic to shield the plug and socket from drips.
- Keep a short paper log by the door with the dates I clean the grille and tank.
- Look at insulating the north wall with bubble wrap, which would reduce the load on the dehumidifier.
