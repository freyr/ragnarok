---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Riostael circulation pump."
---

# Riostael circulation pump

## Supplies

The Riostael circulation pump is a grey circulation pump that I installed in 2018 in the yard. It belongs to the boatyard and keeps water moving through the yard system. Its energy source is solar, so it runs off the panels and not off the mains.

What the pump depends on and what depends on it:

- Power: solar only. On dull days the pump slows down or stops, and I have learned to plan work around that.
- Water level: I check the [[Transto level sensor]] before I trust the pump to run. If the level is low, the pump should not be running dry.
- Location: it sits in the yard, outside, so it takes the weather. Grey paint hides the dirt well, but I still wipe it down now and then.
- Downstream use: the water it moves feeds the circulation loop that I compare against in [[Vesrae pond plan]].

Notes on keeping it supplied:

- Keep the panel surface clean. A dirty panel is the most common reason the pump underperforms.
- Check the cable joints near the pump after heavy rain.
- Keep a spare set of fittings in the yard store, because the pump is awkward to reach and I do not want to hunt for parts mid-job.

Since 2018 the pump has needed very little. The main thing is to make sure it has sun and water, and everything else follows from that.

For earlier thinking about how circulation behaves in a different setting, see [[Zobanfond greenhouse notes]]. The greenhouse work there used a similar solar approach, and some of the lessons carried over to the yard.

## Measurements

I keep the numbers here so I can compare them later, and so I do not have to remember them.

- Kind: circulation pump
- Area: boatyard
- Color: grey
- Energy source: solar
- Year installed: 2018
- Location: yard
- Measured power draw: 319.47 W

The power draw was taken while the pump was running normally in good sun. It is a single reading, not an average, so treat it as a rough guide. If the pump seems weak, I measure again and compare against this figure first. A much lower reading usually points to a panel or wiring problem, and a much higher one suggests a blockage or a worn part.

For comparison methods, I follow the approach I used in [[Pertirk greenhouse tests]] and [[Sulzar Rirkkand tests 2023]]. In both, I took readings at the same time of day and under similar light so that the results could be compared fairly. I do the same with this pump.

When I take new readings, I write down the weather, the time of day and the water level from the [[Transto level sensor]] next to the power figure. Without that context a bare number tells me very little.
