---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Ronvir kiln controller."
---

# Ronvir kiln controller

The Ronvir kiln controller is a kiln controller used in the boatyard. It is grey, runs on battery power, and has been in the cellar since 2015. This note is my own reference for how it is set up and how I look after it.

## Open questions

- I don't know how long the battery really lasts between changes. I have only ever swapped it when the display started to dim, never on a schedule. I want to keep a proper record so I can predict it.
- The cellar is damp in the colder months. I haven't confirmed whether the damp is what makes the display flicker, or whether that is just the battery getting low. Both seem plausible.
- I'm unsure whether the calibration offset drifts over the seasons or stays put. I have only checked it a few times, and I never wrote down the conditions each time.
- Does the controller behave differently when the cellar door is open and the air moves? I suspect the temperature probe reacts to drafts, but I haven't tested it.
- I'd like to know if there is a way to run it from a mains adapter instead of a battery. I haven't found anything in my papers that says it is possible, and I don't want to try something that could damage it.
- The radio signal in the cellar is weak. I should check whether the notes in [[Fesbis radio receiver handbook]] say anything useful about placing a receiver closer to the controller.

## History

The controller was installed in 2015. It went into the cellar of the boatyard because that is the one place where the kiln work can be done without disturbing the boats. The cellar stays cool, which makes it easier to see how the kiln heats up and cools down.

For the first few seasons I used it without thinking much about it. It did what I needed: it held a set temperature, and I came back to check on it. The grey casing has picked up marks and some dust over the years, but it has never cracked.

Because it runs on battery, I never had to run a cable through the cellar. That was one of the reasons I chose it. The trade-off is that I have to remember the battery. A few times I arrived to find the display dark in the middle of a job, and I lost a day of work because of it.

Over time I started keeping notes about when things went wrong. Some of those notes ended up in [[Gokio level sensor log]], because I was already logging readings from other equipment and it was easier to put everything in one place. The log is not tidy, but it shows a pattern: the problems cluster in the damp months.

At one point I moved some of the spare parts and manuals up to the [[Sebon loft]] to free space in the cellar. I should remember that the spare battery cells and the small instruction sheet are stored there, not in the cellar. When I need them I have to climb up and fetch them first.

The controller has not been replaced since 2015. I have thought about it, but it still does the job, so I keep it going.

## Tools

These are the things I use when I work on the controller. I keep them together in one box so I do not have to hunt for them.

- A small flat screwdriver for the battery cover. The cover is tight and a coin does not work well.
- A soft dry cloth for wiping the grey casing and the display. I never use a wet cloth in the cellar because the damp is already a problem.
- A second thermometer that I trust, used to compare against the controller's reading. This is the main way I check whether the controller is telling the truth.
- A feeler gauge, used when I measure the small offset during adjustment. It is the only reason I can state the offset in millimetres.
- A notebook and pencil. I write down what I did straight away, because I forget otherwise.
- A torch, because the light in the cellar is poor and the controller sits low down.
- Spare battery cells, kept in the [[Sebon loft]] and not in the cellar. I should bring one down before I start any job.

I do not need anything special beyond this. The controller is simple, and most of the work is looking and comparing.

## Adjustment

The adjustment I make is the calibration offset. This is the small correction that brings the controller's reading into line with my reference thermometer and the physical set point.

- Calibration offset of Ronvir kiln controller: 1.109 mm

I note the offset in millimetres because that is how I measure it with the feeler gauge on the adjustment point. It is not a temperature figure. It is the physical amount I set at the adjustment point.

How I do it, in order:

1. Let the controller sit in the cellar for a while so it matches the surrounding air. If I move it from somewhere warm, the first readings are misleading.
2. Put the trusted second thermometer next to the probe so both are reading the same air.
3. Compare the two readings and write both down.
4. Open the battery cover only if I need to reach the adjustment point, and check the battery is fresh before I change anything. A weak battery can make the reading look wrong, and I would then adjust for the wrong reason.
5. Set the offset using the feeler gauge, then close up and let it settle.
6. Compare again after it has settled and write down the result.

I only change the offset if the two readings disagree by a clear margin, and never just because of one odd reading. Small differences come and go with drafts. If I adjust too often I end up chasing noise.

If the controller and the reference thermometer agree, I leave the offset alone and note that it was checked. Doing nothing is a perfectly good result.

## Checklist

Before each kiln job:

- [ ] Check that the battery is fresh, or bring a spare down from the [[Sebon loft]].
- [ ] Wipe the casing and display with the dry cloth.
- [ ] Look at the display for flicker or dimming.
- [ ] Place the reference thermometer next to the probe.
- [ ] Compare readings and write them down.
- [ ] Confirm the calibration offset is still 1.109 mm.
- [ ] Make sure the cellar door is set the way I want it, open or closed, and note which.

After each job:

- [ ] Switch off the controller and make sure it is really off.
- [ ] Note how the battery seemed, strong or tired.
- [ ] Wipe off any dust that settled during the work.
- [ ] Add a line to my log, and copy anything unusual into [[Gokio level sensor log]].
- [ ] Put the tools back in their box.

Every so often:

- [ ] Look at the battery cover and contacts for damp or corrosion.
- [ ] Check the grey casing for cracks or loose parts.
- [ ] Read through my old notes and see whether the open questions have answers yet.

## Observations

The controller has lasted a long time in a place that is not kind to electronics. That says something good about it. The cellar is cool and damp, and the controller has coped, as long as I keep the battery fresh.

The display is the first thing to show trouble. A dim or flickering display almost always means the battery is going, and a new cell fixes it. I have learned not to start a job when the display looks tired.

The readings feel steadier when the cellar air is still. Opening the door seems to push the reading around for a few minutes. I have not proven this, which is why it is an open question, but I am fairly sure of it.

The grey colour is plain and easy to spot against the cellar wall, which helps when I come down in poor light. It is a small thing, but I would not want a darker one.

Because it runs on battery, the position can be changed freely. I have moved it a short distance a few times to get a better view of the display. Each time I let it settle before trusting any reading.

Some practical lessons I want to keep:

- Never trust the first reading after moving the controller.
- Change the battery early, not late.
- Write down what I did, straight away.
- Compare against the second thermometer before changing the offset.
- Keep spares in a place I will remember. Right now that is the [[Sebon loft]], and I need to keep reminding myself.

If I ever get around to testing the signal question, I will start with the [[Fesbis radio receiver handbook]] and see whether placing a receiver nearer the cellar helps. Until then, the controller keeps doing what it has done since 2015: holding a steady temperature and asking for very little attention.
