---
type: reference
status: active
project: reference
area: boatyard
---

# Besdundrel kiln controller handbook

## Observations

The Besdundrel is a grey kiln controller that sits in the boatyard area, down at the pond. It was installed in 2018 and has run on solar power ever since. These are the basic properties, kept here so I do not have to hunt for them later:

- Kind: kiln controller
- Area: boatyard
- Color: grey
- Energy source: solar
- Year installed: 2018
- Location: pond

What I notice in daily use is mostly about the power supply. Because the unit runs on solar, its behaviour follows the weather. On bright days the display is steady and the relay clicks cleanly. On heavy overcast days, especially in winter, the display dims first, and a few hours later the controller may drop out of a program. It does not lose the program itself, but it does lose the place in the ramp. I have learned to check the battery indicator before I start any long firing.

Other things I have seen over the years:

- The grey casing stays fairly cool even in summer, because it sits in shade near the water for most of the afternoon.
- Damp air from the pond causes light condensation inside the lid after cold nights. I wipe it before opening the unit up.
- The temperature reading drifts slightly when the probe lead is bent tightly. Straightening the lead fixes it.
- The relay is noisy when the battery is low. That noise is a good early warning.

A typical log extract from a normal start-up looks like this. I keep it as a reference for what "healthy" looks like:

```
[boot] solar input ok, battery ok
[boot] probe connected, reading stable
[prog] loaded program: slow-bisque
[prog] segment 1 ramp started
[relay] on
[prog] holding at target
[relay] cycling
```

If the first two lines say anything other than "ok", I stop and fix the power or the probe before going further.

## Tools

I keep a small set of tools in a box next to the controller. Nothing here is special, and most of it is ordinary workshop kit.

- A small screwdriver set for the lid screws and terminal blocks
- A soft brush for dust around the vents
- A dry cloth for condensation
- A multimeter for checking the solar input and the battery
- A spare probe lead, labelled and stored in a sealed bag
- A notebook for firing records, with a pencil tied to it by string
- A torch, because the shed by the pond is dim in the evening

The multimeter is the tool I use most. I test the battery before every long firing and write the reading in the notebook, so I can compare it from one season to the next. A slow downward trend tells me the battery is ageing long before the controller complains.

For cleaning, I use only a dry brush and a dry cloth. I never spray anything onto the casing. The pond is close, and moisture finds its way in easily enough without my help.

I also keep a printed copy of the basic program settings in the box. If the controller ever loses its memory, I can re-enter them by hand without needing to find the original notes.

## Costs

The Besdundrel is cheap to run, and that is one reason I have kept it. Because the energy source is solar, there is no electricity bill for the controller itself. The kiln it controls draws power from elsewhere, so that cost still exists, but the control side is effectively free.

The costs that remain are small and occasional:

- Replacing the battery when the readings begin to fall off
- Replacing the probe lead when the insulation cracks from heat or bending
- Replacing lid seals and screws that corrode in the damp air
- Cleaning supplies, which are almost nothing

Over the years since 2018, the largest single expense has been the battery. The probe lead comes second. Everything else has been pocket change. I do not record exact prices here because they change, and I would rather check the current price when I actually need a part.

A useful habit is to buy the spare probe lead before the old one fails. A failed probe in the middle of a firing can ruin a load, and that costs far more than the lead itself. The spare in the sealed bag has paid for itself in peace of mind alone.

If I ever consider replacing the whole controller, I should weigh the lack of running cost against the effort of moving the solar wiring. A newer unit might have better features, but the existing installation at the pond already works, and the wiring is in place.

## Safety

Safety around a kiln controller is mostly about heat, damp and electricity, and the pond location adds a fourth concern: water.

Basic rules I follow:

- Never open the controller casing while a firing is in progress.
- Disconnect the battery before touching any terminal inside.
- Keep the lid closed and dry, and wipe off condensation before opening it.
- Do not work at the pond edge in wet boots on slippery ground.
- Keep a fire extinguisher within reach of the kiln, not just in the shed.
- Never leave a firing unattended if the battery indicator is low.

Solar systems stay live in daylight even when everything else seems switched off. I treat the wiring as live whenever the sun is on the panel. Covering the panel or disconnecting the battery before any repair is the only reliable way to be sure.

If the controller behaves oddly during a firing, for example by cycling the relay rapidly or showing a reading that jumps around, I switch off the kiln at its own supply first, and only then investigate the controller. The kiln is the hazard; the controller is the thing that can be fixed afterwards.

I also keep the area around the controller clear of dry leaves and boat-yard debris such as offcuts, rags and solvent containers. Anything flammable stays well away from both the kiln and the controller.

## Schedule

I keep a simple routine so that small problems are caught early.

Before every firing:

- Check the battery indicator and note the multimeter reading
- Confirm the first two start-up lines say "ok"
- Straighten the probe lead and check the connector
- Wipe any condensation from the lid

After every firing:

- Let the kiln cool fully before touching the probe
- Write the result in the notebook
- Brush dust from the vents

Seasonally:

- In spring, clean the solar panel and check the wiring for corrosion
- In summer, check that the casing is not trapped in direct sun
- In autumn, test the battery carefully before the dark months begin
- In winter, avoid long firings on overcast days, or accept that the controller may lose its place in the ramp

Once a year, I open the unit on a dry day, with the battery disconnected, and look for rust, damp marks and loose terminals. I also compare the year's battery readings in the notebook and decide whether a replacement is due.

## Background

The Besdundrel was installed in 2018 as part of a wider effort to make the boatyard less dependent on mains power. The pond location was chosen because the open ground there gets good sun, and because the kiln shed already stood nearby. Putting a solar controller there meant no long cable runs across the yard.

It is a grey kiln controller, plain in appearance, and it has never been fancy. It reads a probe, follows a stored program and switches a relay. That is nearly all it does, and it does it reliably when the power is good. The simplicity is the main attraction. There is very little to go wrong that I cannot see or measure with a multimeter.

Over the years I have learned its habits: it prefers sun, it dislikes damp, and it tells me early when something is wrong, as long as I pay attention to the display and the relay noise. This handbook collects those habits in one place.

The remaining parts of this handbook go further into procedures and troubleshooting, but the properties above are the foundation: a grey solar kiln controller, installed in 2018, in the boatyard area, at the pond.

## Risks

The Besdundrel is a grey kiln controller, installed in 2018 at the pond and used in the boatyard area. It runs on solar power, and that single fact drives most of the risks I have to keep in mind.

- **Power dips.** On a dark week the battery bank sags. The controller then drops out in the middle of a firing, and the kiln cools unevenly. Wood or ceramic parts inside can crack or warp.
- **Damp.** The pond is only a short walk from the shed. Morning mist settles on the casing and on the terminal blocks. Corrosion on the sensor terminals is the most common slow failure I have seen.
- **Heat soak.** The grey casing sits in direct sun in the afternoon. The inside gets hot, and the readings drift a little when it does.
- **Sawdust and varnish fumes.** The boatyard is dusty. Dust in the vents holds moisture and can short a connection.
- **Unattended firings.** A solar controller has no mains backup. I never start a long firing without a clear sky forecast and a full battery.

The worst outcome is a half-finished firing with nobody around. For that reason I treat the battery level as a hard gate, not a suggestion.

## Lessons

Some things took me years to learn, and I want them in one place.

1. Check the battery before the schedule. A perfect program means nothing if the power fails at the peak.
2. Shade the casing. A simple board propped above it lowered the drift noticeably.
3. Keep a paper log next to the unit. When the screen resets after a power loss, the paper record is the only proof of what happened.
4. Do not trust a single sensor reading. Compare it with a second, cheap probe now and then.
5. Short, frequent checks beat one big annual overhaul. Small faults show up early that way.
6. Write down every change to the setpoints, with a reason. I once undid a good adjustment because I forgot why I had made it.

The biggest lesson is that the pond location is both a blessing and a curse. The sun is good and the open space is safe for a kiln, but the air is wet. Plan for moisture first.

## Maintenance

I keep a simple routine, split by how often I do it.

**Every firing**
- Look at the battery state and the sky.
- Wipe dust from the vents and the display.
- Confirm the sensor reads a sensible room temperature when cold.

**Monthly**
- Open the casing on a dry day and look at the terminals for green or white crust.
- Clean any crust with a dry brush, then a little contact cleaner.
- Check that the cable glands are tight and the seals are not cracked.

**Yearly**
- Clean the solar panel surface with water and a soft cloth.
- Inspect the panel wiring and the mounting for loose bolts.
- Test the sensor against a reference probe.
- Refresh any desiccant bags inside the casing.

A log extract from a typical cold check looks like this. I copy this layout into my paper log:

```
check: cold start
battery: full
sensor_cold_reading: matches room
terminals: dry, no crust
vents: cleared
result: ok to fire
```

## Checklist

Before each firing I go through this list in order, and I do not skip steps.

- [ ] Forecast is clear for the whole firing.
- [ ] Battery is full at the start.
- [ ] Panel is clean and not shaded by a branch or a boat cover.
- [ ] Casing is dry, vents are open.
- [ ] Sensor wiring is seated and the terminals are dry.
- [ ] Setpoints match the paper plan.
- [ ] The kiln load is stacked with space for air.
- [ ] Paper log is open with the start time written in.
- [ ] Someone knows the kiln is running.

After the firing:

- [ ] Let the kiln cool on its own, with the controller left powered.
- [ ] Record the end state and any alarms.
- [ ] Shade or cover the controller if the sun is strong.

## Problems

These are the faults I have met and what I did about them.

**The display is blank.** Almost always low battery. Check the battery first, then the fuse, then the cable from the panel. If the battery is fine, look for damp at the power terminals.

**Readings jump around.** Usually a damp or corroded sensor terminal. Dry it, clean it, and reseat the wire. If the jumping continues, swap the sensor for the spare.

**Readings drift high in the afternoon.** This is heat soak in the casing. Shade it and see whether it settles. If it does not, compare against the reference probe.

**The controller resets mid-firing.** A power dip. Note the time, look at the weather, and check whether a loose connection shook free. Do not restart the program blindly. Work out how far the kiln had got and decide whether to resume or stop.

**The kiln does not reach temperature.** Check the load, the door seal, and the element connections before blaming the controller. In my experience the controller is rarely the cause.

**Alarm without a clear reason.** Write down what the screen says, switch off, wait a few minutes, and start again from cold. If it returns, stop using the unit until the cause is found.

## Supplies

I keep a small box in the boatyard shed with the items below, so a fault does not stop work for days.

- A spare temperature sensor of the same type as the fitted one.
- Spare fuses of the correct rating, marked clearly on the box.
- Contact cleaner and a small dry brush.
- Desiccant bags for the casing.
- Cable ties, self-amalgamating tape and a few spare cable glands.
- A soft cloth and a bottle of clean water for the panel.
- A cheap reference probe for cross-checks.
- A notebook and pencil for the paper log.

I replace the desiccant and the contact cleaner when they run low, and I check the box at the start of every season. The Besdundrel itself has run since 2018 on its solar supply, and with these basics on hand it has stayed dependable beside the pond.

## Setup

The Besdundrel kiln controller is a grey kiln controller that has been in service at the boatyard since 2018. It sits at the pond, in a small shed on the bank, and runs on solar power. These are the properties I check first when something looks wrong:

- Kind: kiln controller
- Area: boatyard
- Color: grey
- Energy source: solar
- Year installed: 2018
- Location: pond

The controller handles the small kiln we use for curing fittings, drying glued parts and baking the occasional batch of test tiles. It does not drive the big steam box. That one has its own timer and I leave it alone.

### Power

The solar panel is bolted to the shed roof and faces the water. A charge regulator and a single battery sit on a shelf inside the shed. The controller takes its supply from the regulator output. On a bright day the battery is full by early afternoon. On a heavy grey week it is not, so I avoid long firings then.

I have to remember that the controller is the only thing on that circuit that matters. The shed light and the radio are on a separate fuse. If the controller resets by itself, I check the battery terminals before anything else, because damp from the pond gets into them.

### Wiring and layout

The layout from left to right inside the shed:

1. Solar regulator and battery.
2. The grey controller box, mounted at eye height.
3. The relay that switches the kiln element.
4. The thermocouple lead, which runs through a grommet to the kiln.

The thermocouple lead is the part that fails most often. I replaced the sleeve once and I keep a spare length coiled behind the door.

### Configuration sketch

This is the profile I use for a normal curing run. It is a note of the shape of the settings, not an export from the device. The menu names on the controller are shorter than these.

```
profile: cure-fittings
segments:
  - name: ramp
    target_c: 80
    rate: slow
  - name: hold
    target_c: 80
    duration_min: 120
  - name: cool
    target_c: 30
    rate: natural
safety:
  max_c: 120
  cutoff_on_low_battery: true
  restart_after_power_loss: false
```

I keep `restart_after_power_loss` set to false on purpose. If the battery sags and the controller restarts halfway through a run, I want it to stop and wait for me rather than carry on blind.

### Daily routine

Before a run I look at the battery indicator, the thermocouple lead and the kiln door seal. After a run I switch the relay off by hand and write the outcome in the logbook. That takes a few minutes and has saved me more than once.

## Ideas

These are things I would like to try. None are done yet.

- Add a second small panel so the battery recovers faster in dull weather. The roof has room on the pond side.
- Put a cheap temperature probe on the shed wall to see how much the ambient temperature changes the kiln's heat-up time.
- Print a laminated card with the three standard profiles and tape it inside the shed door. At the moment I rely on this note and my memory.
- Move the battery to a raised shelf or a sealed box, away from the damp that comes off the pond.
- Fit a simple float switch or similar marker so I know if the pond level ever rises near the shed floor after a storm.
- Try a longer, gentler cool segment for the glued parts. Some of them show small cracks in the finish, and I suspect cooling too quickly.
- Keep a one-page "fault card" with the usual symptoms and the first thing to check for each.
- Log battery state at the start and end of each run in the same logbook line as the profile name, so I can see patterns over a season.

### Small improvements to the routine

I could label the relay and the regulator directly on the shelf, with a marker pen. It sounds trivial, but when I am in the shed in the evening with a torch, the grey box and the grey regulator look very similar. The colour is a real nuisance in poor light. A strip of bright tape on the controller would fix that.

I also want to write down the order for switching things on after a long shutdown. Right now it is battery first, then controller, then relay, and I do it from habit.

## Open questions

- Why does the controller occasionally show a slightly lower temperature than my handheld probe at the same moment? I do not know if it is the thermocouple, its position or the controller's own reading.
- How much does the winter sun angle reduce the charge? The pond bank has trees on one side and I suspect they shade the panel low in the year.
- Is the battery still the right size for the way I use the kiln now? When I installed everything in 2018 I ran shorter, less frequent firings.
- Does the damp in the shed shorten the life of the relay? It has worked well so far, but I have no idea what its expected life is.
- Should the safety cutoff be lower for the glued parts? The adhesive instructions I kept are vague about the upper limit.
- Would a small vent in the shed door help or just let in more moisture from the pond?
- Is there any reason to keep the old timer wired in as a backup? It is still in the drawer.

### What I would need to find out

To settle the temperature question I need one afternoon with two probes side by side in the kiln and a notebook. For the battery question I need a full season of logged charge readings. Neither is hard, I just have not done them.

## References

These are my own notes and papers, listed so I know where to look. None of them are online.

- The boatyard logbook, the green-covered one kept on the shed shelf, where each run is recorded.
- The paper manual for the controller, folded in a plastic sleeve behind the shed door.
- The regulator's leaflet, which explains the indicator lights and the low-voltage cutoff.
- My sketch of the shed wiring, drawn when the solar setup was installed in 2018 and pinned inside the cupboard door.
- The adhesive maker's instruction sheet for the glued fittings, which gives the curing guidance I base the profile on.
- My own note on the thermocouple lead replacement, in the maintenance folder.
- A short note on pond-side damp and the battery box, in the same folder.

When I change the profile or the wiring, I should update the sketch and this note on the same day. Otherwise the two drift apart.

## Measurements

I take these readings when I want to check that the setup still behaves the way it did before. The figure below comes from the circulation check I did on the cooling water loop that runs near the kiln wall.

- Flow rate of Besdundrel kiln controller: 1868.76 l/h

I use that figure as the reference point. If a later check is clearly lower, I look first at the filter on the intake from the pond, then at any kinks in the hose, and only after that at the pump supply from the battery.

### Other readings I keep

Alongside the flow rate I note the following each season, in plain words rather than numbers I might misremember:

- Battery state at the start of a run: full, half or low.
- Whether the kiln reached its hold target without help.
- How long the cool segment took, roughly: short, normal or long.
- Any resets of the controller during a run.
- The state of the thermocouple sleeve: clean, dirty or worn.

### How I use the readings

If the flow rate holds, the battery is full and the run finishes cleanly, I leave everything as it is. If two of those drift in the same week, I stop and inspect the system before the next firing. One odd reading on its own is usually just weather or a dirty intake.

I try to take readings at a similar time of day, because the pond and the shed both change with the sun. A reading taken at dawn after a cold night is not comparable with one taken on a warm afternoon, and I have fooled myself that way before.
