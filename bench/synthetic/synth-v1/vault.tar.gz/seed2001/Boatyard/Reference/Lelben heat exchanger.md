---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Lelben heat exchanger."
---

# Lelben heat exchanger

## Checklist

The Lelben heat exchanger is a black heat exchanger used in the boatyard. It has been installed in the loft since 2017 and runs on battery power. Before each check, I go through the points below.

| Property | Value |
|---|---|
| Kind | heat exchanger |
| Area | boatyard |
| Color | black |
| Energy source | battery |
| Year installed | 2017 |
| Location | loft |

Things to do on each visit:

- Check that the battery is charged and the terminals are clean.
- Wipe the black casing and look for dust around the vents.
- Make sure nothing is stored against the unit in the loft.
- Listen for odd noises when it starts.
- Note anything unusual in the log before moving on.

## Adjustment

When the readings drift, I reset the offset rather than replace parts. The calibration offset of the Lelben heat exchanger is 2.645 mm. I check it with the unit switched off and the battery connected, then compare it with the setting I wrote down last time.

A short extract of how I record the setting in my notes:

```
device: Lelben heat exchanger
location: loft
energy_source: battery
calibration_offset: 2.645 mm
```

If the measured value differs from the one above, I loosen the adjuster, move it back to the stated offset, and tighten it again. After that I run the unit for a few minutes and check it once more.
