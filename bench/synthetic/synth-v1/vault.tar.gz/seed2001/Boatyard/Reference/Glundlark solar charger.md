---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Glundlark solar charger."
---

# Glundlark solar charger

## Schedule

This section is how I keep the Glundlark solar charger looked after. It is a grey solar charger installed in 2017 in the loft at the boatyard. Its energy source is listed as battery, so the routine below is built around the battery and the loft.

Weekly, when I am at the yard:
- Look at the charger from the loft hatch. I check that the grey casing is dry and that no cables have shifted.
- Check that the indicator lights show what I expect for the time of day.
- Glance at the loft floor under it for drips, dust piles or droppings.

Monthly:
- Climb up and wipe the casing with a dry cloth.
- Check the cable connections by hand. I do not pull on them. I only look for looseness or green corrosion.
- Write the battery state in the log book that hangs by the loft door.

Every season:
- Compare the loft temperature with what I wrote last season. The loft gets hot in summer and cold in winter, and both are hard on a battery.
- Check that nothing has been stacked against the charger. Boatyard clutter creeps toward any free space.

Once a year, in early spring:
- Do a full inspection and a power measurement, and update the Measurements section below.
- Review the Checklist and Problems sections and cross out anything that has been fixed.

## Measurements

This section holds the numbers I have actually measured, kept apart from numbers I only assume.

- Measured power draw of Glundlark solar charger: 189.13 W

Notes on that figure:
- I took it with the charger running in its normal state in the loft. It is not a rated value from any label.
- It is a single reading, so I treat it as a rough guide and not a guarantee. The draw changes with the battery state and with how much light the panels receive.
- If I measure again and the result is far from this one, I will add the new reading beside it and write down the conditions. I will not overwrite the old figure.

Other facts I can state without a measurement:
- Kind: solar charger
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2017
- Location: loft

What I have not measured, and would like to:
- How long the charger holds up with no light at all.
- How warm the casing gets on a hot afternoon.
- How the draw differs between a full battery and a flat one.

When I measure, I write down the weather, the time of day and what else was running in the loft. A bare number is hard to use a year later.

## Overview

The Glundlark solar charger is a grey solar charger that has been in the boatyard loft since 2017. It keeps a battery topped up from solar input so the equipment depending on that battery has power when the yard is quiet. The listed energy source is battery, and that is how I think of it day to day: the battery is the thing I look after, and the charger is what keeps it healthy.

Quick facts:
- Name: Glundlark solar charger
- Kind: solar charger
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2017
- Location: loft

What it does for me:
- It reduces how often I have to deal with a flat battery.
- It runs without much attention, which suits a yard where I am not always present.
- It sits out of the way in the loft, away from the wet and knocks of the working floor.

What it does not do:
- It does not tell me much on its own. I have to climb up and look.
- It does not protect itself from neglect. Dust, heat and damp still get to it.

I treat it as a quiet, dependable piece of kit that still deserves a regular look. Most of the notes below are about how to give it that look without making it a chore.

## Background

I installed the charger in 2017. At the time the boatyard had a recurring problem: batteries went flat between visits and I would arrive to find things dead. Running a long cable from the main supply to the far end of the yard was not worth the trouble, so a solar charger became the practical option.

I chose the loft for a few reasons:
- It is dry compared with the working floor.
- It is high up and hard to bump into or knock over.
- It has good light through the roof side, which suits a solar charger.
- It keeps the grey casing out of sight, so it does not attract attention.

The installation was simple. I fixed the charger in place, connected it to the battery and checked that it behaved. I wrote down what I did that day, though not as carefully as I would now. That is partly why this note exists: I want to capture things I have been carrying in my head for years.

Since then it has run through many seasons. It has had a few small problems, which I list further down, but nothing that made me want to replace it. The main change over the years is in me. I used to forget it for months, and now I put it on a schedule.

A grey casing was not a choice I made for style. It is just the colour it came in. I mention it because I use it to identify the unit when I describe it to someone else or when I am sorting through boxes of similar gear.

## Observations

These are things I have noticed over the years of having the charger in the loft.

Light and weather:
- On bright days the charger is clearly working hard. On dull winter days it does very little and the battery sits where it is.
- Long grey spells matter more than single bad days. A week of cloud is when I start to worry.

Temperature:
- The loft gets hot in summer. The casing feels warm to the touch, and I would rather it did not.
- In winter the loft is cold and sometimes damp. I watch for condensation more than for frost.

Dust and debris:
- Dust settles on everything in the loft. A film on the surface seems to cut how well the charger collects light.
- Cobwebs gather around the connections. They are harmless but they hide whatever is under them.

Behaviour:
- The indicator lights give me a rough idea of state but not an exact one. I learned the pattern by watching it at different times of day.
- The measured power draw of 189.13 W is the number I keep in mind when I think about load, although I remember it is only one reading.

Surroundings:
- Mice have visited the loft. They have not damaged the charger, but they are a reason to keep cables tidy and off the floor.
- When other people use the loft for storage, things drift toward the charger. I have had to move boxes more than once.

Overall, the charger is less demanding than the loft around it. Most of what goes wrong comes from the environment, not from the device.

## Lessons

Things I have learned and would tell myself if I started again.

- Write it down at the start. I wish I had logged the installation properly in 2017. Details I assumed I would remember are now vague.
- Check by eye, often. A quick look catches most problems early. A long inspection once a year catches them late.
- Keep the loft tidy. A clear space around the charger is the cheapest protection I have.
- Respect heat. A grey casing in a hot loft is not a good pairing. Shade and airflow help more than anything fancy.
- Do not trust a single measurement. The reading of 189.13 W is useful, but only alongside notes about conditions.
- Label things. A small tag with the name and the year installed saves confusion later.
- Keep the log by the door. If I have to go back to the house for a notebook, I skip the entry.
- Do small jobs on the spot. Wiping the casing takes a minute when I am already up there, and it never gets done if I plan it as a separate trip.

A wider lesson: equipment that works quietly is easy to forget, and forgetting is the main thing that shortens its life. The schedule exists to fight that.

## Problems

A list of problems I have had or still have. I cross them off when they are properly fixed.

Current:
- Dust builds up faster than I clean it, especially after dry summers.
- The log book is inconsistent. Some months have entries and some do not.
- I do not have a good way to see the battery state without climbing up.

Past, now mostly handled:
- Boxes stacked too close to the charger. I moved them and added a note to the Checklist.
- A loose connection that gave odd indicator behaviour. Tightening it fixed it, and I now check connections monthly.
- Damp patches in the loft after heavy rain. I traced them to a gap in the roof and had it patched, though I still look for signs of a return.

Possible future problems:
- Battery ageing. The charger has been in place since 2017, and batteries do not last forever. I should expect declining capacity.
- Heat damage to cables or casing over many summers.
- Pest damage if mice find their way to the wiring.

For each problem I try to record what I saw, what I did and whether it stayed fixed. Without that, I end up repeating the same diagnosis.

## Checklist

Use this when I go up to the loft.

Before climbing:
- [ ] Bring the log book, a pen, a dry cloth and a torch.
- [ ] Make sure the ladder is steady and the hatch is clear.
- [ ] Tell someone where I am if I am alone at the yard.

At the charger:
- [ ] Confirm it is the Glundlark solar charger, grey, in its usual spot in the loft.
- [ ] Look over the casing for damp, cracks or discolouration.
- [ ] Check the indicator lights and note what they show.
- [ ] Wipe off dust with the dry cloth.
- [ ] Check each cable connection by eye and by light hand pressure.
- [ ] Look for cobwebs, droppings or chewed material.
- [ ] Check that nothing is stacked against or on top of the unit.

Battery:
- [ ] Look at the battery for swelling, leaks or corrosion.
- [ ] Note its state in the log.

Before leaving:
- [ ] Put back anything I moved.
- [ ] Write the date and a short comment in the log.
- [ ] Close the hatch.
- [ ] If anything looked wrong, add it to Problems when I am back down.

## Ideas

Things I might do, none of them urgent.

- Add a simple way to read the battery state from the floor of the loft, or even from the yard, so I do not have to climb for every check.
- Fit a small shade or baffle to cut summer heat on the casing without blocking the light the charger needs.
- Put up a shelf nearby so stored boxes have a proper home away from the charger.
- Mark a clear zone on the loft floor around the unit with tape, as a visible reminder to keep it free.
- Keep a spare set of the small fittings I use at the connections, so a loose or corroded one can be replaced the same day.
- Take a photo each year from the same spot, to see slow changes in dust, discolouration or position.
- Make a one-page version of the checklist and laminate it for the hatch.
- Look at whether a second battery would give a useful reserve for long cloudy spells.
- Repeat the power measurement under a few different conditions and keep the readings in a small table, next to the figure of 189.13 W.

I will move an idea into the Schedule or Checklist once I have tried it and found it worth keeping.

## Open questions

Things I do not know yet.

- How much battery life is left? The charger has been working since 2017, and I have no clear measure of capacity.
- Is the measured power draw of 189.13 W typical, or was it a good or bad day? I need repeat readings to say.
- How much does dust really reduce the charger's output? I suspect it matters, but I have no numbers.
- How hot does the casing actually get in the worst summer weather?
- Would moving the charger to another spot in the loft improve light without making other things worse?
- Is the damp I saw in the past completely gone, or just quiet?
- When should I plan to replace the battery, and what will I replace it with?
- Is there a simple signal, such as a particular light pattern, that reliably means trouble? I have a rough idea but nothing I would rely on.

When I find an answer, I will move it into Observations or Lessons and delete the question here.

## Safety

Practical safety points. I am not an electrician, and I keep to simple checks.

Working in the loft:
- Use a steady ladder and keep three points of contact when climbing through the hatch.
- Watch my head on roof timbers and my feet on any boards that are not fixed down.
- Take a torch even in daytime. Corners are darker than they look.
- In hot weather, limit time up there. The air can be stifling.

Around the charger and battery:
- Treat the battery as live at all times. Do not bridge terminals with tools or jewellery.
- Do not open the casing. If something inside seems wrong, I get a qualified person to look.
- If I see swelling, leaking, a burning smell or heavy corrosion, I stop and leave it alone until it is dealt with.
- Keep the area dry. Do not touch connections with wet hands.
- Do not cover the unit in a way that traps heat.

General:
- Keep flammable material away from the charger and battery. Old rags, paper and packing are the usual culprits in a loft.
- Let someone know when I am going up, especially if I am alone.
- Keep a first aid kit and a fire extinguisher in the yard, and know where they are.

If in doubt, I leave it and ask for help. The charger is not worth an injury.

## Costs

I am not recording exact prices here, only how the costs are shaped, so I can judge them without a fixed figure going stale.

Ongoing costs:
- Very little in running terms, because the energy source is sunlight feeding a battery.
- My time is the main cost: regular visits to the loft, cleaning and logging.
- Small consumables such as cloths, cable ties and tape.

Occasional costs:
- A replacement battery is the biggest foreseeable cost. Given that the charger has been in place since 2017, I should plan for it rather than be surprised.
- Replacement cables or fittings if corrosion or pest damage appears.
- Repairs to the loft roof if damp returns.

Costs avoided:
- Fewer flat batteries means fewer wasted trips and less downtime at the boatyard.
- Not running a long cable to the loft saved a lot of effort and expense at the start.

Things to weigh when deciding on larger spending:
- Whether the charger is still doing its job well enough that a new battery alone is enough.
- Whether a better position or small upgrades would give more benefit than a full replacement.
- How much effort I am willing to put into upkeep compared with paying for something that needs less.

When I do spend money, I will note what it was for and what it fixed, in the log book rather than here.

## Supplies

What I keep to hand for looking after the Glundlark solar charger.

Cleaning and inspection:
- Dry, soft cloths for wiping the grey casing.
- A small brush for dust and cobwebs around connections.
- A torch, and a spare torch battery.
- A pen and the log book.

Fixing and tidying:
- Cable ties and a small pair of snips.
- Insulating tape.
- A basic screwdriver set, used only for outer fittings and not for opening the casing.
- Spare small fittings for the connections.
- Labels or tags to mark the unit and its cables.

Protection:
- Gloves for handling dusty or dirty items.
- A dust mask for cleaning in a closed loft.
- A first aid kit in the yard.
- A fire extinguisher in the yard.

Loft use:
- A sturdy ladder.
- A small storage box kept near the hatch so the supplies stay together.
- Pest deterrents if mice become a bigger problem.

I check the supply box each season and refill it. A missing item is a good excuse to skip a task, so I try not to give myself one.

## References

Everything here is my own material, since the world of this note is private and personal.

- The log book hanging by the loft door, which holds dated visit entries and battery states.
- The installation notes I wrote in 2017, which are brief and incomplete.
- My photos of the charger in the loft, taken over several seasons.
- The Measurements section of this note, which holds the measured power draw of 189.13 W.
- The Checklist section of this note, which I use on each visit.
- My general boatyard notes on loft storage, damp and pests.
- Any paperwork that came with the charger, kept in the yard office drawer.

Summary of the subject for quick lookup:
- Name: Glundlark solar charger
- Kind: solar charger
- Area: boatyard
- Color: grey
- Energy source: battery
- Year installed: 2017
- Location: loft

If I find a better source of information later, such as a clearer manual or a helpful person with similar equipment, I will add it here with a note about what it covers and how useful it was.
