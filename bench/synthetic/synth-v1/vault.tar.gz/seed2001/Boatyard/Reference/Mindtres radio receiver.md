---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Mindtres radio receiver."
---

# Mindtres radio receiver

## Problems

The Mindtres radio receiver is a black radio receiver that sits in the cellar of the boatyard. It runs on solar energy, so most of its trouble comes from the power side rather than from the radio itself.

**Weak signal in the cellar.** The cellar is below ground and has thick walls. The receiver picks up the harbor channel only when the aerial lead runs up through the vent opening. Without that lead the signal is full of hiss. Any change to the lead changes the reception, so I leave it alone once it works.

**Power drops on dull days.** The solar panel is outside, and the cable comes down into the cellar. After several grey days in a row the battery gets low and the receiver starts to crackle before it shuts off. It does not warn me. I have learned to check the battery on Monday mornings.

**Damp.** The cellar is damp in autumn and winter. A film of moisture forms on the black casing, and the tuning knob gets stiff. I wipe the casing dry and keep a small bag of drying crystals on the shelf next to it.

**Noise from other equipment.** When the grinder in the workshop above is switched on, a buzz comes through the speaker. The buzz stops when the grinder stops. I have not found a real fix, only the habit of listening to the weather report before the grinder is started.

**Short checklist when it goes silent:**

1. Check the battery level.
2. Check that the aerial lead is still in the vent opening.
3. Wipe the casing and the knob.
4. Turn the volume up and down once to clear the contact.

## History

The Mindtres radio receiver was installed in 2024. Before that, the boatyard had no radio in the cellar at all. Weather and tide news came from a phone, and the phone often had no signal down there. That was the reason for putting a dedicated receiver in the cellar, where the stores and the spare rigging are kept.

I chose a black unit because it hides the dirt of the cellar better than a pale one. I chose solar power because running a mains cable into the cellar would have meant opening the wall near the old drain, and nobody wanted that job. The panel went on the south side of the boatyard roof, and a cable was fed down through the same gap used by the aerial lead.

The first weeks were spent on position. I tried the receiver on the floor, on the shelf by the door, and on the high shelf by the vent. The high shelf gave the best reception, so it stayed there. After the first winter I added the habit of wiping the casing dry, because the damp became obvious by then.

Since 2024 the receiver has not been replaced or repaired. The knob has become stiffer, and the battery lasts a little less than it did at the start, but the unit still does the job it was bought for.

## Measurements

These are the values I keep for reference. The power draw was measured with the receiver playing at a normal listening volume.

| Property | Value |
| --- | --- |
| Kind | radio receiver |
| Area | boatyard |
| Color | black |
| Energy source | solar |
| Year installed | 2024 |
| Location | cellar |
| Measured power draw | 64.64 W |

The measured power draw of the Mindtres radio receiver is 64.64 W. That is higher than I expected for a small receiver, and it explains why the battery runs low after a few dull days. If the battery problem gets worse, the first thing to look at is whether the draw has gone up, or whether the panel is simply not charging as well as before.

Other notes from measuring:

- The reading was taken in the cellar, with the receiver on the high shelf.
- The reading was taken with the aerial lead in place in the vent opening.
- I did not measure the draw while the receiver was switched off.
- I have not repeated the measurement since it was first taken, so it is worth redoing after any change to the battery or the panel.
