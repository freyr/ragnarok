---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Brunbaedos heat exchanger."
---

# Brunbaedos heat exchanger

## Maintenance

The Brunbaedos heat exchanger is a black, solar-powered heat exchanger that sits in the cellar of the boatyard. It has been running since 2016, so most of the upkeep is about age, damp and keeping the solar side clean and unobstructed.

Routine jobs I do on it:

- Wipe down the black casing to remove dust and cellar grime. The dark finish hides dirt, so I use a torch and look along the seams.
- Check the connections for weeping. A damp patch or a white crust at a joint means a slow leak.
- Listen to the circulation pump when it starts. A new rattle or a hum that was not there before means something is wearing.
- Bleed any trapped air from the loop if the exchanger sounds gurgly or heats unevenly.
- Check the insulation on the pipes that run from the cellar up to the solar side. Damp cellar air ruins lagging quickly.
- Look at the fixings and brackets for rust, because the cellar is humid.

I keep a short log of each visit: what I looked at, what I changed and what I want to check next time. A quick note beats trying to remember six months later.

If the exchanger underperforms, I go through the same order every time. First the solar supply, then the fluid in the loop, then the pump, then the exchanger surface itself. Most problems turn out to be at the start of that list.

## Risks

The main risks I have noted for this device:

- **Damp in the cellar.** The room is humid, and moisture attacks fittings, wiring and brackets. A flooded cellar would be bad news for anything at floor level.
- **Leaks.** A leak in the loop can lose fluid and let air in. Over time that cuts the heat transfer and can damage the pump.
- **Hot fluid.** Solar heat can push the fluid to a high temperature, even when the weather looks mild. I treat every pipe as hot until I have checked it.
- **Reduced solar input.** Shade, dirt or damage on the solar side lowers output. The exchanger then looks faulty when the problem is upstream.
- **Boatyard dust and debris.** Sanding dust, paint particles and solvent vapours can find their way into the cellar. Dust clogs surfaces and some vapours should never be near a hot device.
- **Age.** Installed in 2016, it is now old enough that seals and the pump deserve extra attention.
- **Working alone in a cellar.** Tight space and poor light make mistakes easier. I tell someone when I am going down to work on it.

## Overview

Here are the basic facts about the device, kept together so I can find them fast.

- **Name:** Brunbaedos heat exchanger
- **Kind:** heat exchanger
- **Area:** boatyard
- **Color:** black
- **Energy source:** solar
- **Year installed:** 2016
- **Location:** cellar

The exchanger moves heat from the solar-heated side of the system to the side that uses it, without letting the two fluids mix. It is a quiet device and does its work in the background, which is why it is easy to forget until something goes wrong. Because it is in the cellar, it is out of sight and out of the weather, but the damp makes up for that.

I use this note as a reference, not a manual. When I need exact steps for a repair, I go to the paperwork that came with it. This note covers what I have learned from living with the device.

## Schedule

The schedule I try to follow is simple. I tie the jobs to the seasons because the solar load changes through the year.

- **Spring:** a full inspection after the winter. Clean the casing, check for leaks, inspect the lagging and test the pump. Clear anything blocking the solar side.
- **Summer:** a quick look when the solar input is highest. Check for overheating, unusual noise and any weeping at the joints.
- **Autumn:** the main service before the cold months. Bleed air, check fluid level, tighten fixings and look for rust.
- **Winter:** a short visit once a month to check for damp, leaks and anything that has changed since the last time.

Besides the seasonal rounds, I go down whenever there has been heavy rain or a flood warning, since the cellar is the first place to suffer. After any repair I check the exchanger again a few days later to make sure the fix has held.

## Parts

The device is a black unit with a casing, a plate or coil section where heat passes between the two fluids, connecting pipes, a circulation pump, insulation and mounting brackets.

- **Serial number:** SN-86708542
- **Casing:** black, in the cellar, needs protection from damp
- **Connections:** the pipe joints between the exchanger and the solar side
- **Pump:** circulates the fluid and is the part most likely to wear first
- **Lagging:** insulation on the pipework
- **Brackets and fixings:** hold the unit in place and rust if neglected

When I order a replacement, I quote the serial number and describe the part carefully. I also take a photo of the old part before removing it, so I can match the new one.

## References

I keep these sources in mind when working on the device:

- The paperwork that came with the exchanger when it was installed in 2016.
- My own maintenance log, kept with the boatyard notes.
- Photos of the cellar layout and the pipe runs, taken before any major job.
- Notes from whoever installed the solar side, in case a question comes up about how the loop was set up.
- General guidance on safe working in cellars and around hot fluids.

If I find a better source, I add it here. I would rather have a short list I trust than a long one I never open.

## History

- **2016:** the Brunbaedos heat exchanger was installed in the cellar of the boatyard as part of the solar setup. It has been black and solar-powered from the start.
- **Early years:** it ran with little attention. I did the basic checks and not much else.
- **Later years:** as the device aged, I began keeping a proper log and following the seasonal schedule above. Damp in the cellar was the main thing that made me change my habits.
- **Now:** it is still in service in the cellar. I treat it as a reliable but aging device, and I keep a close eye on the pump, seals and fixings.

Whenever something notable happens, such as a repair, a replaced part or a bad leak, I add a line here so the story of the device stays in one place.
