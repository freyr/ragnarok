---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Fothzin heat exchanger."
---

# Fothzin heat exchanger

## Lessons

The Fothzin heat exchanger is a yellow heat exchanger that sits in the cellar of the boatyard. It runs on solar energy and was installed in 2022. These notes are for my own use, so they stick to what I have actually seen while working around it.

The first lesson is about access. The cellar is cramped, and the unit is yellow, which helps because it is easy to spot in a dim room. Even so, I should always bring a proper torch, because the cellar lights do not reach the back of the unit. Keep the floor clear of hoses and offcuts, since a tripped foot near the pipework is the most likely way to damage something.

The second lesson is about the solar supply. Because the exchanger depends on solar energy, its output follows the weather. On grey days the water does not get as warm as I expect, and I should not plan heat-dependent jobs, such as warming the workshop wash water, for those days. On bright days it performs well, and I can schedule the demanding tasks then.

The third lesson is about routine checks. A short look once a week saves a long repair later. I check for damp patches on the cellar floor, listen for unusual knocking in the pipes, and make sure the panels feeding the unit are not covered in leaves or bird droppings. A dirty panel costs more heat than most faults.

The fourth lesson is to write things down. Every time I change a setting, I note the date and the reason in my log. Without that, I end up guessing why the unit behaves the way it does.

## Ideas

A few improvements are worth trying when there is time and spare budget.

- Add a simple label near the unit listing the normal operating routine, so anyone in the boatyard can check it without asking me.
- Fit a small shelf by the cellar door for the torch, gloves and a rag, so the basics are always at hand.
- Put a cheap thermometer on the inlet and outlet pipes. Comparing the two readings would tell me at a glance whether the exchanger is doing its job.
- Look at a basic cover or brush routine for the solar panels, so cleaning becomes a fixed monthly task rather than something I remember by chance.
- Consider a small storage tank so that surplus heat from sunny days can be used on dull ones. This is the biggest idea and probably needs advice from someone who knows plumbing better than I do.
- Keep a printed copy of the key notes in the cellar, in case my digital notes are not available.

## Software

The unit has a small controller, and it runs firmware. The firmware version of the Fothzin heat exchanger is v8.48.868. I keep that written here so I can compare it against whatever the controller shows after any power cut or service visit.

Practical points about the software side:

- After a power loss, check that the controller starts normally and that the version shown matches the one above. If it does not, something has changed and I should find out why before trusting the readings.
- Do not update the firmware in the middle of a busy period at the boatyard. Pick a quiet day, and note the old and new versions in this section straight afterwards.
- Settings should be changed one at a time. If I change several at once and the behaviour shifts, I cannot tell which change caused it.
- Because the exchanger is solar powered, the controller can behave oddly at dawn and dusk when the supply is weak. Odd readings at those times are not always a fault.

## History

The Fothzin heat exchanger was installed in 2022 in the cellar of the boatyard. The choice of the cellar was practical: it keeps the unit out of the weather and close to the pipework it serves, even though access is tight.

From the start it has been a solar-powered device, and that decision shaped how I use it. In the first season I learned how strongly it depends on sunshine, and I adjusted my working schedule around it. The yellow colour was not a design decision of mine, but it has turned out to be useful, since the unit stands out clearly in the dark cellar.

Over the following years the routine settled into a pattern: weekly checks, a cleaning round for the panels, and a log of any changes to the settings. The notes in the Lessons section came out of that experience. The Ideas section holds the improvements I have not yet done.

In short, this reference records a yellow, solar-powered heat exchanger, installed in 2022, living in the cellar of the boatyard, and currently running firmware v8.48.868.
