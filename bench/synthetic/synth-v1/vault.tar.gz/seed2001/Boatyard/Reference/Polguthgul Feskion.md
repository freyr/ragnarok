---
type: reference
status: active
project: reference
area: boatyard
description: "Reference about Polguthgul Feskion."
---

# Polguthgul Feskion

## Lessons

Polguthgul Feskion is a plumber I have known since 2021. He works in the boatyard area, and that is where I first met him. The main thing I learned from dealing with him is that the way you contact him decides how fast things move. His contact method is phone. Texting him or leaving a vague message does not work well. A short phone call that names the boat, the berth and the problem gets a useful answer almost every time.

His availability is evenings. He works at the yard during the day on other jobs, so I stopped trying to catch him before the end of the working day. If I call in the evening, he picks up or calls back the same night. If I call at midday, I usually wait until the next day.

Other lessons from the years since 2021:

- Describe the problem the same way each time. Say where the water is, how fast it moves and whether the pump is running.
- Take a photo before calling, even though he takes calls by phone. I can describe the photo while he listens, and later I can show him the same view.
- Do not ask for a general opinion about the whole plumbing system when I only need one fitting looked at. He answers the question that is asked, and a narrow question gets a narrow, correct answer.
- Ask what he needs me to prepare before he arrives. Usually that means clearing a locker, emptying a bilge section or turning off a valve.
- Write down what he says during the call. I forget details otherwise, and I have had to call twice for the same thing.

I also learned that he prefers to be told about the sensors and electronics I have on board, because they affect where he can cut or drill. The [[Transto level sensor]] sits low in the bilge, and he wants to know about it before he touches any hose near it.

## Risks

The first risk is timing. Because he is available in the evenings only, an urgent leak during the day cannot depend on him. I need a basic plan of my own: close the through-hull valve, run the manual pump, and call him in the evening for the repair itself.

The second risk is that phone is the only contact method. If my phone is dead or I have no signal at the boatyard, I cannot reach him. Some corners of the yard have poor reception, so I should make the call from a spot where I know it works.

The third risk is that I depend on one person. He is good, but if he is ill or busy, I have no second plumber in the boatyard area on my list. I should find a backup and note the name here.

Other risks I have noted:

- Misunderstanding over scope. If I describe the job loosely, the work may grow, and so may the bill.
- Evening work in low light. Poor light in a bilge or engine space makes mistakes more likely, so I should have good lamps ready.
- Water near electrics. Plumbing work close to wiring is a hazard. I should switch off the relevant circuits first.
- Leaving a temporary fix too long. A clamp or a patch is not a repair, and I tend to forget it once the water stops.

## Maintenance

Most of what I have learned about maintenance comes from watching him work and asking questions afterwards. His advice, as I recall it, is simple and repetitive.

Things I do regularly myself:

- Check hose clamps and hose ends for rust, cracks and softness.
- Open and close each through-hull valve to keep it from seizing.
- Look in the bilge for fresh water, rust streaks or salt crust, which show a slow leak.
- Run the bilge pump by hand and confirm it clears the water.
- Test the [[Transto level sensor]] by lifting the float or covering it with water, and see whether the alarm reacts.

Things I leave to him:

- Replacing a through-hull fitting.
- Anything that needs cutting into a hose run or changing pipe routing.
- Pressure problems in the fresh water system that I cannot trace.
- Winterizing questions where I am not sure what to drain.

I keep a short list of jobs he has done for me, with the month and year, in my boat log. That way I can tell him what was last touched. It also helps to see how long a repair has lasted.

## Observations

Over the time I have known him, since 2021, a few patterns are clear.

He is calm and does not rush. He looks at the whole space first, then picks a place to start. He rarely guesses, and when he does not know, he says so and checks.

He works neatly. Tools are laid out, old parts are put in a bag, and the bilge is wiped before he leaves. I have never had to clean up after him.

He explains what he did in a few plain sentences. When I ask why, he answers without impatience. I learned more about my own boat from these short talks than from any manual.

He is reliable about evenings. When he says he will come after work, he comes. If he is delayed, he calls ahead. That is why I keep him on my list even though the daytime gap is annoying.

Some other points:

- He prefers a phone call to anything written.
- He likes to know the boat's berth, so he can walk straight to it.
- He remembers earlier jobs on my boat, which saves explanation.
- He is honest about whether a part is worth replacing or can be kept a while longer.

Sometimes the [[Mindtres radio receiver]] is running in the cabin while he works. He does not mind, but I turn it down so we can hear each other and so I can hear the pump if it starts.

## Setup

This section describes how I have set things up so that working with him is smooth.

**Contact card.** I keep his entry short: name Polguthgul Feskion, role plumber, area boatyard, contact by phone, availability evenings, known since 2021. I check that these details match the note properties whenever I update either.

**Before the call.** I gather these things:

1. The berth and the name of the boat.
2. A clear description of the fault.
3. What I have already tried.
4. Any photos I took.
5. A note of nearby equipment, such as the sensor in the bilge.

**Access.** I clear the space where he will work. Lockers are emptied, cushions are lifted, and the floor boards are out. I put a lamp on a hook nearby and leave a towel and a bucket within reach.

**Power and water.** I turn off the circuits near the work and close the valves that I know how to close. If I am unsure, I leave them and tell him when he arrives.

**After the visit.** I write down what he did, what parts he used in general terms, and what he told me to watch. I add a reminder to look at the repair again after a few weeks.

## Costs

I keep cost notes in general terms, because prices change and I do not want to treat old figures as current.

The main cost is his time, which depends on the job. A small fix, like replacing a clamp or tightening a fitting, takes a short visit. A larger job, like replacing a through-hull or rerouting a hose, takes longer and needs parts.

What affects the final cost:

- The access to the work area. A cramped space takes longer.
- The condition of the old parts. Corroded fittings may break and need extra work.
- The parts needed, which I can sometimes buy myself if he tells me what to get.
- Whether he has to come back a second evening.

To avoid surprises, I ask for a quote before any larger job and ask what is included. I write the quote down and compare it with the final bill. The specific quoted figure for the current job is recorded under Quotes.

I also count indirect costs. If a leak is left, it can damage wood, electrics and stored items, so a quick call is often cheaper than waiting.

## Checklist

Use this before and after each job with Polguthgul Feskion.

Before:

- [ ] Call him by phone in the evening.
- [ ] Give the boat name, berth and a short description of the fault.
- [ ] Ask what he needs prepared.
- [ ] Ask for a quote if the job is more than a small fix.
- [ ] Clear access to the work area.
- [ ] Turn off nearby circuits.
- [ ] Mention the [[Transto level sensor]] if the work is near the bilge.
- [ ] Have lamps, a bucket and towels ready.

During:

- [ ] Stay nearby but out of the way.
- [ ] Ask about anything that changes the plan or cost.
- [ ] Take a photo of the finished work.

After:

- [ ] Check for leaks with the pump off and the valves open.
- [ ] Test the bilge alarm.
- [ ] Write the job in my boat log with the month and year.
- [ ] Set a reminder to inspect the repair after a few weeks.
- [ ] Compare the final bill with the quote.

## Quotes

The quoted price of Polguthgul Feskion: 4761.09 EUR

This is the figure he gave for the larger job I asked about. I keep it here as a reference and not as a promise. Before I accept it, I want to confirm what is included: labour, parts, and any return visit.

Things I plan to ask about the quote:

- Does it cover all parts, or only labour?
- Does it assume easy access, or will extra time be added for tight spaces?
- Is there a fixed scope, and what happens if he finds other faults?
- How long is the quote valid?

I will compare it with any second opinion if I find a backup plumber in the boatyard area. For now, it is the figure to hold him to, and I will note any change in writing after a phone call.

Short remarks from him that I wrote down and want to keep in mind:

- "Show me the problem first, then we talk about price."
- "Evenings are best for me."
- "If it is old, replace it, do not patch it twice."
