---
type: drivers
status: active
project: buthnior-upgrade
area: boatyard
description: "Drivers about Buthnior upgrade."
---

# Drivers of Buthnior upgrade

## Supplies

Buthnior upgrade is a project in the boatyard area. Its goal is an upgrade, it started in 2022, and it runs in the summer season. The carpenter leads it, so most supply decisions go through them.

What drives the supply list:

- The goal is an upgrade, not a rebuild. We reuse what is still sound and replace only what has worn out.
- Work happens in summer, so timber, fasteners and finishes must be on site before the dry weeks start.
- The carpenter decides which materials are acceptable. Anything the carpenter does not trust is not ordered.
- Storage at the boatyard is limited. Deliveries are staged so that wood does not sit out in the damp.
- Supplies are bought in one or two large orders where possible, to keep delivery costs down.

Constraints I keep in mind:

- The summer season is short, so a late delivery costs real working time.
- Every item must suit use around boats and water.
- Leftover material should be useful for the next job, so I avoid odd sizes and one-off items.

How success is measured: the upgrade is done within the summer season, the new work holds up under normal use, and spending stays inside the budget below. If the carpenter signs off the finished work, I count the goal as met.

## Budget

The budget of Buthnior upgrade is 23885.65 EUR.

How I handle it:

- Supplies take the largest share, so I check them first when costs change.
- I keep a small reserve inside the total for repairs found only after old parts are opened up.
- Any purchase that would push spending over the total gets discussed with the carpenter before I order it.
- I note each receipt in the project log so the running total is always clear.

If the reserve is used up before the work is finished, I cut optional extras first and protect the structural work.
