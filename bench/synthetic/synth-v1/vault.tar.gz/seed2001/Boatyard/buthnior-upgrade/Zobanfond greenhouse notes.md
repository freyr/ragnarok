---
type: note
status: active
project: buthnior-upgrade
area: boatyard
description: "Note about Zobanfond greenhouse."
---

# Zobanfond greenhouse notes

## Schedule

The greenhouse works on a simple weekly rhythm. I keep it loose in winter and tighter in spring, when seedlings need more attention.

- Monday: check the raised floor beds for damp patches and walk the whole length of the house. Look at the west glazing for condensation.
- Wednesday: watering round. The medium size of the house means one full round takes me about an hour if nothing is wrong.
- Friday: tidy the benches, sweep the paths, and empty the small compost bin by the door.
- First weekend of each month: deep clean of the glass on the inside, and a check of the vents and hinges.
- Autumn: move tender plants in from the boatyard side before the first cold nights, and wrap the water pipe near the entrance.
- Spring: sow trays on the benches closest to the west wall, because they get the strongest afternoon light.

Because the house faces west, the morning is cooler and the afternoon is the hot part of the day. I do the watering in the morning so plants are not wet when the sun comes in low and strong. In summer I open the vents early and put the shade cloth on by midday.

## Open questions

Things I have not settled yet and want to come back to.

- Is the west orientation really worth it? Afternoon light is good for fruiting plants, but the heat in midsummer is hard on leafy crops. I may need better shading rather than a different layout.
- How much does the raised floor help with drainage compared with the old ground-level beds I used elsewhere? It seems drier, but I have not measured anything.
- Should the glazing on the west side be replaced or just re-sealed? Some panes look cloudy and a couple of seals have started to lift.
- Is a medium-sized house too large for one person to keep up through the busy months, or is the problem just my schedule?
- Would a rain barrel on the boatyard side be allowed under the terms of the lease? I need to read the lease again before asking.
- Can the old heater from the shed be used safely, or should I leave winter heating alone and grow only hardy crops?

## Admin

Practical details to keep in one place.

- Lease reference: LR-479368
- Place: Zobanfond greenhouse, a greenhouse in the boatyard area.
- Renewal: I should check the lease terms each year and ask about any changes to the structure before doing the work.
- Water: the tap is near the entrance and is shared with a neighbouring plot, so I try not to run it at the same time as others in the late afternoon.
- Repairs: anything to do with the frame or glazing goes to the site manager first. Small fixes such as hinges, latches and seals I do myself and write down.
- Keys: one set stays with me and the spare is kept at home, not at the greenhouse.
- Insurance: I should confirm whether my home policy covers the contents of the greenhouse. I have not done this yet.
- Records: I keep a short log of what was planted, when it was watered heavily, and any pests found.

## Overview

Zobanfond greenhouse is a greenhouse in the boatyard area. It is a medium-sized house, built in 2002, with a raised floor and a west orientation. Those are the main properties, and they explain most of how I use it.

The raised floor keeps the working surface up off the wet ground that is typical near a boatyard. The paths stay drier than they would at ground level, and the beds are easier to reach. The downside is that the floor and its supports need checking for rot and for gaps where pests can get in.

The west orientation means the house gets its best light in the afternoon and evening. That suits sun-loving plants such as tomatoes, peppers and herbs, but it also means the house can overheat in summer. Shade cloth and open vents are my main tools for managing this. In winter, the low western sun is useful and gives some free warmth late in the day.

The medium size gives enough room for two long benches, a row of raised beds, and a small potting area near the door. It is not big enough for large crops such as vines to be grown in numbers, so I keep to a mix of salad, herbs and a few fruiting plants. There is a narrow strip at the far end that I use for storage of pots, trays and canes.

Around the house, the boatyard brings its own conditions. There is sometimes dust and paint overspray from nearby work, so I wash the glass more often than I otherwise would. Wind can also come across the open yard from the west, which is another reason I check the panes and latches regularly.

## Background

The greenhouse was built in 2002 and has been through several users before me. I know this mostly from the state of the fittings: some benches are clearly newer than the frame, and a few of the vents have been replaced with a different style of opener. The raised floor appears to be original, which says something about how well it was made, although I still look underneath it each season.

I took it on because I wanted a protected place to grow food close to where I spend time anyway. The boatyard area is practical for this. There are tools, scrap timber and useful offcuts nearby, and people there are generally relaxed about small projects as long as nothing blocks access.

The first year was mostly cleaning and learning. I removed old pots, scrubbed algae from the glass, and rebuilt two benches. I also found that the west side takes the worst of the weather, so I paid most attention to that wall. Since then, the work has been steady rather than dramatic: small repairs, better shading, and a more consistent watering routine.

What I have learned so far:

- A raised floor makes a real difference to how the house feels in wet weather.
- West light is strong and needs managing from late spring onward.
- A medium-sized house rewards regular short visits more than occasional long ones.
- Keeping a simple log is more useful than trying to remember what happened.
- Good notes about repairs save time, because the same few problems tend to come back.

I want to keep the house in good working order rather than expand it. If I make changes, I will first read the lease, write down the plan here, and check how it fits with the rest of the boatyard area.
