---
type: log
status: active
project: buthnior-upgrade
area: boatyard
description: "Log about Glansun Riorkulbel."
---

# Glansun Riorkulbel log

## Safety

Glansun Riorkulbel is my neighbor, and I have known them since 2020. They work in the boatyard area, so most of what I note here is about the yard and the ground around it. The best way to reach them is by phone. They are available on weekdays, so I call then and do not expect an answer at the weekend.

Things I keep in mind when I deal with Glansun about yard matters:

- Ask before walking through the working part of the yard, even when it looks empty.
- Wear sturdy shoes near the slipway, because the surface is wet and uneven.
- Keep the gate closed behind me so that nothing wanders in or out.
- Tell Glansun by phone if I see loose lines, leaning stands or spilled fuel.

## Contracts

The contract with Glansun Riorkulbel is dated 2019-09-01. It was signed before I knew them as a neighbor, so I treat it as the starting point of our arrangement. I keep the paper copy in the folder with the other yard papers.

If anything about the terms changes, I will agree it by phone on a weekday and then write it down here. I do not rely on memory for what was said, and I add a short entry to this log each time we talk about the contract.
