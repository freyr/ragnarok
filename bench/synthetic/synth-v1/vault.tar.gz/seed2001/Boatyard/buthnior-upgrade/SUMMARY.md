---
type: summary
status: active
project: buthnior-upgrade
area: boatyard
---

# Summary of Buthnior upgrade

This is the summary of the Buthnior upgrade, a project in the boatyard. The goal is an upgrade. It started in 2022, it is a summer project, and the lead is the carpenter. I keep this note as the one place to look when I need to know where things stand, what is finished, what is still hanging, and what to do next.

The project is in progress and not close to finished. The main structure of the work is settled and the carpenter has the plan in hand. The remaining work is mostly checks, a few awkward fits, and the paperwork I keep putting off. Details are in the sections below, and the links point to the longer notes.

## Tools

The carpenter leads the work, so most of the tool list comes from the carpenter's bench. I keep it short here and note only what I actually reach for on this project.

- Hand planes and chisels for fitting the timber parts, because the old openings are never square.
- A marking gauge and a long straightedge, used before every cut.
- A battery drill and a hand brace for the places where the drill does not fit.
- Clamps of every size. We never have enough of them, and the work stops when they run out.
- A moisture meter for checking timber before anything is closed in.
- A notebook and pencil in the shed, because the paper notes get the real measurements first and I copy them over later.

For the monitoring side I use the logger described in [[Siokreth data logger log]]. It sits in the shed during the warm days and tells me whether the timber is drying evenly. The radio gear used to talk between the shed and the slipway is covered in [[Zaelmulzur radio receiver handbook]]. I read that handbook again each season, because I forget the pairing steps.

A sample of the logger setup I use is below. It is copied from my working file and trimmed to the parts that matter.

```
project: Buthnior upgrade
goal: upgrade
area: boatyard
start_year: 2022
season: summer
lead: carpenter

logger:
  location: shed
  interval: every hour
  alert_on: damp timber
  notes: check the cable before each visit
```

## Lessons

Several lessons have come out of this work. I write them down plainly so I do not have to learn them again.

- Measure twice is not enough in an old boatyard. Measure, then check the measurement against a second reference, because walls and frames move.
- Dry the timber properly before fitting. Hurrying this step cost us rework in an earlier summer, and the note on it is in [[Kioze loft notes]].
- Keep the lead informed early. The carpenter notices problems with joints long before I do, and a quick word saves a long argument later.
- Do not mix up old and new parts on the same bench. We now keep a clear shelf for each.
- Write the decision down on the day it is made. Memory drifts, and a decision that was clear in the shed is vague a month later.
- Summer weather is a resource and also a risk. Warm days speed drying, but sudden storms ruin an open job.

A further lesson comes from the heat work in the neighbouring part of the yard. The comparison in [[Gilsiond heat exchanger study]] showed me that testing a part on the bench is not the same as testing it in place. I applied the same idea here and now test fittings in position before I glue anything.

## Open questions

Some things are still unsettled. I list them so that they do not get lost.

- How much of the old framing can stay? The carpenter thinks most of it, but we have not opened the last section.
- Will the new fittings sit properly once the timber has finished moving? We will only know after a full warm spell.
- Who handles the final inspection? The lead assumes it will be done in the yard, but I have not confirmed that with anyone.
- Is the current storage enough for the finished parts? The loft is crowded, and the notes in [[Gundstios loft notes]] suggest we may have to move things around.
- Do we need a second look at the heat side before closing up? The material in [[Lelben heat exchanger]] raises a question about clearances that I cannot answer from my notes alone.

I expect most of these to be answered by doing the work, not by thinking about it. Still, I want them written here so I can tick them off.

## Decisions

The go decision for the Buthnior upgrade was made on 2018-07-26. That is the date I use whenever I need to say when the project was approved. The work itself began later, in 2022, in the summer season, and I keep both facts in mind so that the long gap does not confuse me when I read old notes.

Other decisions made along the way:

- The carpenter leads the project, and other work in the boatyard fits around the carpenter's schedule, not the reverse.
- The goal stays as an upgrade. We are not rebuilding from scratch, even when a section looks bad enough to tempt us.
- Work happens in the summer, when the weather allows open working and drying.
- Old parts that still serve are kept. New parts go in only where the old ones fail a plain check.
- Every change to the plan gets a line in this note, with a short reason.

I made these decisions with the carpenter in the shed, and I trust them. If one has to be reversed, I will record the reversal under History and not erase the original line here.

## Ideas

A few ideas have come up that are not yet plans. I keep them here so I can look at them when there is time.

- Build a small jig for the repeated joints. The carpenter has done the same cut many times, and a jig would make the cuts match.
- Set a standing weekly check of the shed readings, so that damp problems show up before they reach the timber.
- Photograph every opened section before closing it. A photo is quicker than a sketch and shows things I did not think to measure.
- Use the same labelling scheme on the loft shelves as on the bench, so that parts can be found without asking.
- Borrow the testing approach from [[Sulzar Rirkkand tests]], where each step was written as a short pass or fail line. It could make the final checks here much easier.
- Look at whether the valve work in [[Rirklaerk valve actuator notes]] has anything to teach about adjustable fittings. I suspect it does, but I have only skimmed it.

None of these has been approved. They are only worth doing if they save time or prevent mistakes.

## History

The project has a long and uneven history, which I write out in order so that I can follow it.

The go decision came first, on 2018-07-26, and after that the project waited. Other jobs in the boatyard took priority, and the upgrade stayed on the list without any real work. That waiting period is the reason some of my early notes are thin.

In 2022, in the summer, the work actually started. The carpenter took the lead from the start. The first weeks went on clearing space, checking the existing structure, and agreeing which parts would be kept. That phase was slow but useful, because it gave us a clear picture of the condition of the timber.

After the clearing, we moved into the main upgrade work. Fitting went in stages, each one finished and checked before the next began. Several stages went smoothly. Others, especially those near the older frames, needed rework. The loft notes, [[Kioze loft notes]] and [[Gundstios loft notes]], record the storage side of this period, and they remind me how crowded things became.

Since then the project has continued in summer seasons, with pauses in the colder months. Each return has needed a short re-check of the previous work, which I now count as part of the schedule and not as lost time.

## Next action

The next action of Buthnior upgrade is NX-3666.

I want to keep this section short and clear. When I open this note, I should see the next action first and not have to hunt for it. Once it is done, I will replace the value here with the next one and add a line to History, so that the trail is kept.

## Problems

The problems are mostly small, but together they slow the work.

- Old openings are out of square, so every new part needs trimming and test fitting. This eats time that the plan did not allow for.
- Tool shortages, mainly clamps, stop work while we wait. A simple purchase would fix this, but it keeps slipping down the list.
- Damp in the shed on cooler mornings makes the timber readings jump around. I have learned to read the trend and not any single value.
- Storage is tight. Finished parts sit in places where they can be knocked or stained.
- The long gap between the go decision and the start means some early assumptions are out of date. I have had to recheck several of them against the current state of the yard.
- Communication between the shed and the slipway is patchy. The handbook [[Zaelmulzur radio receiver handbook]] helps with the setup, but dead spots remain.

None of these is serious on its own. I list them so that I can see whether they are growing or shrinking from one season to the next.

## References

These are the notes I use most with this project. I link them so I can jump straight to them.

- [[Sulzar Rirkkand tests]] for the pass or fail style of checking.
- [[Lelben heat exchanger]] for the heat side and the clearance questions.
- [[Kioze loft notes]] for storage and timber drying.
- [[Gilsiond heat exchanger study]] for the lesson on testing parts in place.
- [[Rirklaerk valve actuator notes]] for ideas about adjustable fittings.
- [[Siokreth data logger log]] for the readings from the shed.
- [[Zaelmulzur radio receiver handbook]] for the radio setup.
- [[Gundstios loft notes]] for the later storage layout.

I do not copy their contents here. This note is only a summary, and the detail belongs where it was first written.

## Safety

Safety is the carpenter's call on the job, and I follow it. Still, I write the rules I care about most.

- Wear eye protection and gloves when cutting or planing, even for short jobs.
- Keep chisels sharp and always cut away from the body. A dull blade slips.
- Clear the floor before each work session. Offcuts and cables cause more injuries than the tools do.
- Do not work alone on heavy lifts. Ask the carpenter or someone else in the yard.
- Check that the shed ventilation is working when gluing or finishing, because fumes build up fast on warm days.
- Keep a first aid kit where it can be seen and make sure everyone knows where it is.
- Switch off and unplug electrical tools before changing a blade or bit.

If a task feels unsafe, it stops until we have talked about it. No deadline in this project is worth an injury.

## Background

The Buthnior upgrade belongs to the boatyard. Its goal is an upgrade, which means we improve and strengthen what is there and do not replace it all. The project began in 2022, runs in the summer season, and is led by the carpenter.

The idea behind it is simple. The existing structure was sound in principle but worn in places, and some parts no longer did their job well. The go decision, made on 2018-07-26, recorded that the yard would invest in fixing this properly. Years passed before the work could start, but the reasoning did not change.

The carpenter was the natural lead because the main work is timber work, and the carpenter knows the materials, the old joints, and the habits of the yard better than anyone. My role is to keep the notes, track the open points, and make sure that the decisions are written down.

Related work elsewhere in the yard, especially on heat and valves, gave us useful comparisons. They did not change the plan, but they gave me better questions to ask, which is why the links appear throughout this note.

## Observations

These are things I have noticed while following the project. They are not conclusions, just patterns worth remembering.

- Work goes faster when the carpenter sets the order of tasks and the rest of us follow it. Changes in the middle of a stage cause confusion.
- The shed readings from the logger show slow, steady drying on dry days and sharp setbacks after rain. The pattern repeats each summer.
- Parts that are fitted in position first and finished afterwards fit better than parts finished on the bench.
- The loft fills up quicker than expected. Every time I clear it, it is full again within a few weeks.
- When I write the next action clearly, the next session starts well. When I leave it vague, we lose the first hour deciding what to do.
- People remember decisions differently. Having the date and the reason in this note ends most disagreements quickly.
- The yard is calmer in the early summer mornings, and the careful work gets done then.

## Maintenance

This note needs regular care, or it will drift away from the real state of the project.

I update it at the end of each work session, even if the only change is a short line. The next action gets replaced as soon as it is done. New decisions go under Decisions with their date, and anything that was reversed gets a line in History.

Once a season I read the whole note from the top. I check that the properties still match: the goal is an upgrade, the area is the boatyard, the start year is 2022, the season is summer, and the lead is the carpenter. If any of these ever changes, I fix it here and in the frontmatter together.

I also check that the links still point to notes that exist, and that the open questions are either still open or have been moved to Decisions. Items that have been dealt with get removed from Problems so the list stays honest.

If the note grows too long, I will move older detail into separate notes and leave only a short pointer here. A summary should stay short enough to read in a few minutes, and that is the test I use each time I edit it.
