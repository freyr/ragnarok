---
type: plan
status: active
project: buthnior-upgrade
area: boatyard
---

# Kandston workshop plan

## Setup

The Kandston workshop is a small workshop in the boatyard. It was built in 2024 and sits below ground, with its orientation to the east. These are the basic facts I keep coming back to when I plan anything here:

- Kind: workshop
- Area: boatyard
- Orientation: east
- Size: small
- Year built: 2024
- Floor: below ground

Because the room is small and below ground, almost every decision is about space, damp and light. The plan for the setup is to keep the floor clear, keep everything off the walls where moisture collects, and make each tool earn its place.

The layout I settled on is simple. The main bench runs along the long wall, and the narrow end by the door stays free for carrying boat parts in and out. Shelves go on the dry side only. Heavy items sit low, light items sit high, and anything that hates damp goes in sealed boxes instead of open shelves.

The east orientation matters more than I expected for a room below ground. The only natural light comes in the morning through the stairwell end, so I do the fine work early and leave rough work for the afternoon. For the rest of the day I rely on lamps, so I keep two clamp lights ready and one fixed light over the bench.

Power is a weak point. I want the workshop to run small loads off a stored supply when the mains is off, which is why the [[Glundlark solar charger]] keeps coming up in my notes. I want to place it where it gets real sun, with a cable run down to the workshop, not inside the room itself.

## Tools

I try to keep the tool list short. A small room punishes clutter. Here is what lives in the workshop now:

- Hand tools: screwdrivers, pliers, two hammers, a set of chisels, a hand saw, and a few clamps
- Power tools: a drill, a jigsaw, and a small sander
- Measuring: tape, square, spirit level, and a marking gauge
- Storage: sealed boxes for fasteners, a rack for clamps, and a pegboard on the dry wall
- Monitoring: the data logger that records temperature and humidity on the bench

The logger is the tool I trust most for knowing what the room is doing. I keep its readings in [[Nulur data logger log]], and I look at them before deciding whether to leave wood or metal parts in the room overnight.

For heat and air movement I have been reading back through [[Fothzin heat exchanger 2021]]. That note covers an older setup, but the reasoning on moving air without losing all the warmth is still useful for a room with no windows to open.

The dehumidifier is the other big tool, even though it is not a hand tool. Its running notes are in [[Vensos dehumidifier log]]. I treat it as part of the kit, not as an extra, because without it the metal tools rust within weeks.

Rules for tools:

- Everything goes back to its marked spot at the end of the session.
- Anything wet from the boatyard gets wiped before it enters the room.
- Blades and chisels get a thin film of oil before long storage.
- Nothing is left on the floor, because the floor is the first place water shows up.

## Maintenance

Maintenance in a below-ground room is mostly about moisture, so my routine follows that.

Weekly:

- Empty the dehumidifier tank, or check the drain line if it is running continuously.
- Read the logger and note anything odd in [[Nulur data logger log]].
- Sweep the floor and check the corners for dark patches.
- Wipe the bench and put the clamps back on the rack.

Monthly:

- Clean the dehumidifier filter and check that air can pass freely around it.
- Oil the blades, hinges, and any bare metal that is not in a sealed box.
- Test the lights and the extension leads for damage.
- Look at the walls on the north and south sides for salt marks or flaking paint.

Twice a year:

- Check the stairwell and door seal for gaps.
- Move the shelves and look behind them.
- Review the power setup and decide whether the charger placement still makes sense. The [[Krithdel solar charger tests]] are my reference for what output I can realistically expect, and I compare any new idea against them before buying anything.

I keep the schedule intentionally boring. If a task takes more than a few minutes it tends not to get done, so I break big jobs into small ones and do them in the order of how fast damage would spread if I skipped them.

## Problems

These are the problems I know about, in rough order of how often they bite.

Damp is the main one. Being below ground, the room draws moisture through the walls and floor, and humidity climbs quickly after heavy rain in the boatyard. The dehumidifier keeps up most of the time, but not always, and I have seen tools go dull with surface rust after a wet week.

Light is the second problem. The east orientation gives a short window of morning light, and after that the room is dim. Fine marking and checking of joints is hard under lamps, so I schedule that work early.

Air is the third. With no windows to open, fumes from glue, paint, and varnish linger. I try not to do finishing work here at all, and I carry it out to the boatyard when I can. When I must work with solvents, I run the fan and leave the door open.

Power is the fourth. Mains outages leave the dehumidifier off, and that is exactly when humidity creeps up. A small stored supply would solve this, but I have not yet found a layout I like.

Smaller annoyances:

- The room is small, so a half-finished project blocks the whole bench.
- Sound carries badly, and the sander is loud.
- Carrying long boards down the stairs is awkward and has already scuffed the wall once.

## Admin

The paperwork for the workshop is thin, but I want it written down in one place.

- Lease reference of Kandston workshop: LR-404742
- Year built: 2024
- Location: boatyard area, small below-ground room, east orientation

I keep the lease paperwork in the folder with the other boatyard documents. Whenever I contact anyone about the room, I quote the lease reference first, because it saves a lot of back and forth.

Other admin habits:

- Keep a short list of what I have changed in the room, so I can show that nothing structural was altered.
- Photograph any damage or damp patches before reporting them.
- Note who has a key and when it was last checked.
- Keep receipts for larger tool purchases in one place.

If I ever want to change the wiring or add fixed equipment, I need to ask first. That is why I have been testing the charger idea with portable gear and not fixed installation. The notes in [[Virir loft notes]] describe how I handled a similar question for a different space, and I plan to follow the same approach: try it temporarily, record the results, and only then ask for permission.

## Risks

The risks fall into a few groups.

Water. A small room below ground can flood. A heavy storm or a blocked drain nearby could put water on the floor within a short time. The mitigation is to keep everything off the floor, keep the drain clear, and avoid storing anything irreplaceable in the lowest shelves.

Electrical. Damp and electricity are a bad mix. Extension leads must be kept off the floor, plugs must be dry, and I should not use any power tool with wet hands or with a wet cable. If the dehumidifier trips the supply, I check the cable before resetting.

Air quality. Dust, fumes, and stale air can build up fast in a closed room. I wear a mask for sanding, and I do not leave the room closed after using solvents.

Fire. Oily rags and sawdust are the usual danger. Rags go into a metal bin with a lid, and the bin is emptied outside the room.

Access. There is one way in and out, through the stairwell. If something blocks it, I am stuck. I never leave heavy items on the stairs, and I tell someone when I plan a long session alone.

Loss of records. If the logger fails, I lose the picture of how the room behaves. I back up the readings by copying key numbers into my notes regularly.

## Ideas

Things I want to try, roughly in order of usefulness:

- Move the charger outside and run a protected cable down, so the workshop has backup power for the dehumidifier and a light. This builds on the [[Glundlark solar charger]] and the earlier results in [[Krithdel solar charger tests]].
- Add a second logger near the floor, so I can see whether the bottom of the room is much damper than the bench.
- Fit a drip tray under the dehumidifier and route its drain away from the work area.
- Build a fold-down bench at the narrow end, so the floor can be cleared when I carry in large parts.
- Paint the walls with a light, breathable finish to make the room feel brighter.
- Try a small passive air path inspired by [[Fothzin heat exchanger 2021]], to change the air without losing too much warmth.
- Make a cart for boards and long parts, to protect the stairwell wall.
- Write a one-page checklist and pin it by the door, so the weekly routine does not depend on memory.

I should not do all of these at once. The sensible order is the second logger first, since it costs little and tells me where the problem really is, then the backup power, then the comfort changes.

## History

The Kandston workshop was built in 2024 as a small below-ground room in the boatyard, facing east. At first it was just an empty shell with a bare floor and a single light. I moved in a bench and a few tools and used it for rough work only.

During the first season, damp showed itself quickly. Tools rusted, cardboard boxes softened, and I learned that nothing should sit directly on the floor. That is when I added the dehumidifier and started keeping its log in [[Vensos dehumidifier log]].

Later I added the data logger and began recording what the room actually did over time, in [[Nulur data logger log]]. Those readings changed how I use the space: I now know which days are dry enough for wood and which are not.

The power question came next. I tested a small solar setup and recorded the results in [[Krithdel solar charger tests]], and I have been weighing the [[Glundlark solar charger]] as a longer-term answer.

Along the way I have drawn on older notes, such as [[Fothzin heat exchanger 2021]] for air and heat ideas and [[Virir loft notes]] for the way I handle trial setups in other spaces. This plan pulls those threads together into one place so that the next round of changes is deliberate and not improvised.
