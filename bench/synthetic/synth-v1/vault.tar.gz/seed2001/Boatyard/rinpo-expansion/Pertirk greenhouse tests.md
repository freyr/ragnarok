---
type: research
status: active
project: rinpo-expansion
area: boatyard
description: "Research about Pertirk greenhouse."
---

# Pertirk greenhouse tests

## Schedule

These are the test rounds I plan to run in Pertirk greenhouse. It is a large greenhouse in the boatyard area, facing west, with a raised floor. It was built in 2002. I keep the schedule loose because the light and the wind in the boatyard change what I can do on a given day.

Weekly rounds:
- Monday: walk the whole house and look at the raised floor for soft spots, standing water underneath, and anything that has shifted over the weekend.
- Wednesday: check the vents, the door seals and the watering lines. Run each line for a few minutes and watch for drips.
- Friday: record the afternoon heat. Because the house faces west, the late sun is the main test of how well the shading and the vents work.

Monthly rounds:
- First week: test every bench for stability on the raised floor.
- Second week: clean the glazing on the west side and compare the light before and after.
- Third week: check the frame for corrosion, since the boatyard air carries salt and damp.
- Fourth week: go through the supplies and tidy the stock.

Seasonal rounds:
- Spring: a full test of the heating and the ventilation before the growing season starts.
- Summer: a test of the shading in the hottest part of the day.
- Autumn: a test of the seals and the drainage before the wet weather.
- Winter: a test of frost protection on the coldest nights.

If a round is missed I do not try to catch up twice. I do the next one on time and write down that the earlier one was skipped.

## Background

Pertirk greenhouse is a place of the kind greenhouse. It sits in the boatyard area. Its orientation is west, its size is large, it was built in 2002, and its floor is raised. These are the properties I keep in mind when I plan any test, so here they are in one place:

- Kind: greenhouse
- Area: boatyard
- Orientation: west
- Size: large
- Year built: 2002
- Floor: raised

Why these tests exist: the house is old enough that I no longer trust it to behave as it did when it was new. Built in 2002, it has been through many seasons of sun, salt air and use. I want a steady record of how it performs, so I can tell the difference between a bad week and a real decline.

How each property shapes the testing:

The boatyard location means the air is damp and often salty. Metal parts wear faster here. Dust and grit from the yard land on the glazing and in the vents. Noise and vibration from yard work can loosen fittings over time.

The west orientation means the house gets its strongest sun in the afternoon and evening. Mornings are cooler and dimmer. Plants on the west side get more heat stress, and the west glazing gets dirty and weathered faster. I test heat and shading late in the day for this reason.

The large size means the house does not heat or cool evenly. There are cooler corners and warmer zones. A single reading tells me little, so I take readings at several fixed spots. A large house also needs more time for each round, which is why the schedule is split by day.

The raised floor means air moves underneath and water drains differently than on bare ground. It also means the floor can flex, rot or let in pests from below. I test the floor itself as part of every round, not only the plants and the equipment.

The year built, 2002, is the reason I check wear on seals, frames and fixings, and why I do not assume any original part is still in good shape.

## References

These are the things I look at when I need to decide how to run or read a test. I keep them short and practical.

- My own earlier notes from past seasons in the house, especially the heat readings from Friday rounds.
- The hand-drawn plan of the house, which marks the fixed reading spots, the vents, the water lines and the doors.
- The photos I take at the start of each season, taken from the same places so I can compare them.
- The lease paperwork, which sets out what I may change in the building and what I must leave alone. The reference is in the Admin section.
- Notes from other growers in the boatyard about how wind and salt affect their structures.
- The maker's instructions for the heater, the vent openers and the watering controller, kept in the folder by the door.

How I use them: before a seasonal test I read my own notes from the same season in earlier years. I compare the new readings to those, not to some ideal figure from a book. The house is large, west-facing and raised off the ground, and general advice often assumes a small house on bare soil. My own records fit the real place better.

I also keep a short list of questions that I try to answer with the tests:

1. Does the house hold enough heat on cold nights?
2. Does it shed enough heat on hot afternoons?
3. Does water drain away from the raised floor?
4. Do the seals and the glazing still keep the weather out?
5. Are the benches and the floor still safe to use?

If a test does not help answer one of these, I drop it.

## Maintenance

Maintenance and testing go together. A test often shows a job that needs doing, and a job often needs a test afterwards to confirm it worked.

Regular jobs:
- Clean the glazing, starting with the west side, which gets the dirtiest and takes the most sun.
- Oil the hinges, the vent openers and the door latches. Salt air dries out and corrodes them.
- Clear the gutters and the drains so water does not pool near the raised floor.
- Check the watering lines, nozzles and filters. Replace worn ones.
- Sweep under and around the raised floor where I can reach, to keep out pests and rot.
- Wash the shading and check that it still hangs and rolls properly.

Jobs after a test:
- If a vent sticks, I free it, oil it and run it open and shut several times.
- If a seal leaks, I note the spot, mark it with tape and fix it at the next dry spell.
- If a floor board is soft, I mark it, keep weight off it and repair it before the next round.
- If a reading is odd in one corner, I look for a blocked vent, a draught, or a plant that is blocking airflow.

Frame and fixings:
The frame has been standing since 2002. I look at joints, bolts and clips for rust and looseness. Surface rust gets brushed and painted. Anything structural that looks weak I leave alone and flag for a proper repair rather than guessing.

Raised floor:
I check the supports, the surface and the space beneath. I look for damp, rot, gaps, and signs of animals. I test a few spots by pressing and by listening for hollow or creaking sounds.

After any repair, I repeat the relevant test within a week and write down the result.

## History

Pertirk greenhouse was built in 2002 in the boatyard area. It has always been a large house with a west orientation and a raised floor. Those basics have not changed.

What I know and recall of its life:

- In its early years it was used heavily, and the raised floor was one of its best features because it kept the growing space dry and made cleaning easier.
- Over the years the boatyard grew busier, and the dust, salt and noise increased. The glazing on the west side weathered faster than the rest.
- Some parts have been replaced over time, including seals, a few floor boards, and some of the watering equipment. I do not have exact records of every repair, which is part of why I now keep these notes.
- Some seasons were harder than others. Hot, bright afternoons caused stress on the west side, and a couple of cold snaps showed where heat was lost.

Why I started testing:
I began to notice that the house was less predictable. Some days it was hotter than it should have been, and some nights colder. I could not tell whether this was the weather or the building. Without records, memory was not enough. So I started a simple system of regular tests and written readings.

What I have learned so far:
- The west side needs the most attention for heat and glazing.
- The raised floor is generally sound but needs regular checking for damp.
- Being large, the house has uneven conditions, so one reading is never enough.
- Age matters. At a certain point, repair is cheaper than replacement, but only if I catch problems early.

I add to this history whenever something notable happens, such as a repair, a failure or a change in how the house is used.

## Checklist

Use this list at the start of each round. I tick off items in my own notebook and copy any problems into the observations.

Before I start:
- [ ] Look at the weather and pick the right time of day.
- [ ] Gather the thermometer, notebook, torch, tape and a small tool kit.
- [ ] Check the plan for the fixed reading spots.

Structure:
- [ ] Walk the raised floor and press suspect spots.
- [ ] Look under the floor for damp, rot and animals.
- [ ] Check the frame, bolts and clips for rust.
- [ ] Look at the glazing for cracks, slipped panes and dirt.

Climate:
- [ ] Take readings at each fixed spot.
- [ ] Note the difference between the west side and the east side.
- [ ] Open and close every vent and note any that stick.
- [ ] Test the shading.

Water:
- [ ] Run each watering line and look for leaks.
- [ ] Check drainage around and under the raised floor.
- [ ] Clear filters and nozzles.

Finish:
- [ ] Put tools away and close up.
- [ ] Write down anything that needs a repair.
- [ ] Mark the next round in the schedule.

## Admin

The paperwork for Pertirk greenhouse is simple but I keep it in order.

- Lease reference: LR-810231
- Place: Pertirk greenhouse, a large greenhouse in the boatyard area
- Built: 2002

The lease sets out what I am allowed to change in the building. I check it before making any change to the frame, the glazing or the raised floor. Small repairs and ordinary upkeep are fine, but I do not make structural changes without checking first.

Other admin habits:
- Keep a copy of the lease paperwork in the folder with the plan.
- Write the lease reference at the top of any letter or message about the house.
- Keep a record of who visited and when, especially contractors working on the frame or floor.
- Keep receipts for supplies and repairs in one place.
- Review the paperwork once a year, in winter, when the house is quiet.

If anything about the house changes, such as a new use or a repair that alters its structure, I note it here and check whether the lease needs to be told.

## Supplies

I keep a modest stock so tests and repairs are not delayed.

Testing supplies:
- Two thermometers, one for air and one for the soil or bench.
- A notebook with a pencil, since pens fail in damp.
- A torch for looking under the raised floor.
- Coloured tape for marking problem spots.
- A small level for checking benches and the floor.

Repair supplies:
- Spare seals and weather strip for the doors and vents.
- Spare clips and bolts for the frame.
- A few spare floor boards cut to fit the raised floor.
- Oil for hinges and vent openers.
- Rust brush and paint for the frame.
- Spare nozzles, filters and lengths of watering line.

Cleaning supplies:
- Soft brushes and a long handle for the glazing.
- Buckets, cloths and mild soap.
- A broom for sweeping the floor and under the benches.

Stock habits:
I check the stock in the fourth week of each month. Anything that is half used gets replaced before it runs out. Because the boatyard air is salty and damp, I store small metal items in a closed box and keep paper and tape off the floor.

Because the house is large, I buy more of the common items, like clips and nozzles, than I would for a small house. Running out in the middle of a round wastes the day.

## Observations

This section is where I put what the tests actually show. I add to it after each round, and I keep the entries short.

Patterns so far:
- The west side is warmer than the east side on sunny afternoons, as expected from the orientation. The difference is clear enough that I treat the two sides as separate zones.
- The far corners of the large house are slower to warm up and slower to cool down than the middle.
- The raised floor keeps the growing space drier than I remember in houses with bare ground, but damp collects at the lowest edge after heavy rain.
- Vents on the west side stick more often than those on the east side, probably because of the sun, grit and salt.
- Glazing on the west side shows more dirt and weathering. Cleaning it makes a noticeable difference to the light.

Things to watch:
- Whether the cold corners get worse over the seasons.
- Whether the soft spots on the raised floor spread.
- Whether the seals keep up through wet weather.
- Whether shading is enough on the hottest afternoons.

How I record readings:
I write the date, the time, the weather, the spot and the reading. I add a few words on anything odd. I try to take readings at the same times and in the same places so they can be compared.

Open questions:
- Would extra shading on the west side be worth the cost and the lease check?
- Would better airflow under the raised floor reduce the damp at the edge?
- Is it time to replace the oldest vent openers rather than keep oiling them?

I will answer these with more tests rather than guesses.

## Safety

Testing in Pertirk greenhouse involves ordinary hazards, but a large old house in a boatyard has a few extra ones.

Floor:
- The raised floor can be slippery when wet. Walk slowly and wear shoes with grip.
- Do not stand on a spot I have marked as soft. Keep weight off it until it is repaired.
- Take care when looking under the floor. Use a torch, watch for sharp objects, and do not crawl into tight spaces alone.

Glass and frame:
- Wear gloves when handling broken or slipped panes.
- Do not climb on the frame. Use a proper ladder on firm footing, and have someone nearby when working high up on the west side.
- Be careful with rusty metal, which can be sharp.

Heat and sun:
- On hot afternoons the west side can get very hot. Take water, take breaks and avoid long tests in the worst of the heat.
- Open vents and doors before going in on a hot day.

Water and power:
- Keep electrical equipment away from wet areas. Check cables for damage before use.
- Switch off power before touching the heater or controller.

Boatyard hazards:
- Watch for vehicles, trailers and loads moving near the house.
- Keep paths clear of tools and hoses.
- Tell someone when I am working alone, especially in winter or at dusk.

Chemicals:
- Store oil, paint and cleaning products closed and off the floor.
- Wash hands after handling them and before eating.

If I find a hazard I cannot fix myself, I mark it clearly, keep people away and write it in the notes straight away.
