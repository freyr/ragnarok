---
type: drivers
status: active
project: rinpo-expansion
area: boatyard
---

# Drivers of Rinpo expansion

## Lessons

These are the lessons I keep coming back to when I think about why Rinpo expansion is set up the way it is. The project began in 2025 and runs through the autumn season. It belongs to the boatyard, and the lead is the plumber.

- Put the goal in one sentence before touching anything else. The goal is expansion, and every decision gets checked against that word.
- A project led by the plumber leans toward water, drainage, and pipework first. That is a strength for a boatyard, because washdown and bilge handling are where the yard loses the most time. It also means the lead has to be reminded that the building and the slipway side matter just as much.
- Autumn is a good season to start because boats are coming out of the water and the yard is quieter than in summer. It is a bad season for anything that needs dry weather for a long stretch.
- Write down constraints early. In earlier yard jobs the constraints I skipped over were the ones that hurt me later.
- Keep the budget visible. A single figure in one place beats several half-remembered ones.

I would rather have a short list of drivers I actually read than a long one I forget. This note is meant to be that short list, with enough detail behind it to answer questions later without having to ask anyone.

## References

This section lists the kinds of material I draw on, not specific documents. I keep the actual files in the project folder and only describe them here.

- The yard layout sketch, hand-drawn, showing the slipway, the sheds, and where water and drainage run.
- The plumber's own notes on pipe runs, valves, and the existing drainage fall.
- My notes from earlier yard jobs, especially the ones that ran over.
- The supplier quotes folder, which I check against the budget before ordering anything.
- The safety notes for working near water, fuel, and lifting gear.
- The yard's tide and weather log, which tells me which weeks in autumn are usable.

When I add a new reference, I write one line here saying what it is and why it matters. If I cannot say why it matters, it probably does not belong in the folder.

Related notes in the project cover the schedule, the supplies, and the tools. This drivers note sits above them and explains why they exist. If one of them disagrees with this note, this note wins until I decide to change it on purpose.

## Observations

A few things I have noticed about the project so far, written plainly.

The yard is cramped near the slipway. Any expansion has to respect the working space around the cradle and the lifting gear, or the yard will lose more than it gains. The plumber has pointed out that drainage is already marginal in the lowest corner, and adding area there without fixing the fall would make standing water worse.

Autumn changes the ground. After the first heavy rains, the soft areas show themselves, and that is useful information. I have used it to mark where not to dig or lay anything heavy.

The lead being the plumber shapes how the work gets talked about. Conversations drift toward pipes, taps, pumps, and drains. That is fine, but I need to keep nudging toward the overall goal of expansion, which includes space, access, and the ability to hold more boats.

People on site tend to agree to things quickly and then forget the detail. Writing decisions down on the same day has saved me more than once.

Costs creep upward in small steps rather than in one jump. I notice this most with fittings and small consumables, which is why I track supplies separately.

## Maintenance

Expansion adds things that need looking after, so I think about maintenance before building, not after.

- Drains and sumps need regular clearing, especially after leaf fall in autumn.
- Valves and taps need exercising now and then so they do not seize.
- Any new hardstanding needs checking for cracks and settling after the first wet season.
- Hoses, couplings, and pump seals wear out and should be inspected at the start of every season.
- Signage and markings on the ground fade and need repainting.

I want the maintenance burden to be lower after the expansion than it would have been if I had simply patched the old layout. If a design choice makes upkeep harder, I count that as a cost even if it saves money upfront.

The plumber is the natural owner of the water-side maintenance routine. I will ask for a short written routine once the work is done, with a plain list of what to check and how often. That list should live in the yard, not just in this note.

## Problems

Known and likely problems, so I do not get surprised by them.

Space is the main one. The yard has limited room, and expansion competes with day-to-day movement of boats and trailers. Any work area I fence off is space the yard cannot use.

Drainage is the second. The lowest corner holds water, and extending the yard in that direction could make it worse. This needs to be solved by the lead before anything else is built there.

Weather is the third. Autumn brings rain, wind, and shorter days. Concrete, bedding, and some fittings do not behave well when it is cold and wet, so the schedule has to leave slack.

Access is a smaller but real problem. Delivery vehicles struggle to turn near the sheds, which affects when materials can arrive.

Finally there is the risk of the project being treated as only a plumbing job. The lead's trade is a strength, but the goal is expansion of the whole area. I want to check at each stage that the other parts are not being left behind.

## Ideas

Ideas I have not committed to, kept here so they do not get lost.

- Add a proper washdown pad with its own drain and a simple settling pit, so that runoff is controlled.
- Extend covered storage along the side of the existing shed, using the same roof line to keep the look and the cost down.
- Re-lay the lowest corner with a gentle fall toward a new drain, then use it as extra standing space.
- Add a few fixed water points around the yard so hoses are shorter and less tangled.
- Mark out lanes on the ground for trailers so the extra space is used sensibly.
- Set aside a small tool and parts store near the work area to cut down on walking back and forth.

Any of these can move into the plan if the budget allows and the lead agrees. I rank them by how much they help the goal of expansion, not by how interesting they are. The washdown pad and the drainage fix come first because they support everything else.

## Costs

I keep the cost picture qualitative here and put the single agreed figure in the Budget section. That avoids two numbers drifting apart.

The main cost groups are pipework and drainage materials, groundwork and surfacing, any covered structure, hired equipment, and a margin for surprises. Labour is mostly the yard's own time plus the lead's skills, so the biggest outside spend is materials and hire.

Costs that tend to be underestimated: delivery, disposal of spoil, and small fittings that add up. Costs that tend to be overestimated: the big visible items, because quotes for those are clear and I plan for them properly.

I treat every cost as belonging to one of two kinds. Fixed ones are quoted and agreed. Floating ones depend on weather and what the ground turns out to hold. The floating ones need the margin.

If a cost cannot be tied back to the goal of expansion, it is a candidate for cutting. I review the cost groups whenever the plan changes, and I write the change down so I can see how the picture moved over the season.

## Background

Rinpo expansion is a project in the boatyard area. Its goal is expansion. It started in 2025 and is set for the autumn season, and its lead is the plumber.

The reason for the project is simple. The yard has outgrown its layout in places, and the parts that hold it back are mostly about water, drainage, and usable ground. That explains why a plumber leads it. The person who understands where the water goes is the person best placed to decide where new ground can safely go.

Starting in autumn was deliberate. Boats are out of the water, the busiest period is over, and the ground shows its weak spots after rain. The tradeoff is weather, which I accept and plan around.

This note is the drivers note. It records the goal, the constraints, the budget, and how I will judge success. The other notes in the project, covering schedule, supplies, and tools, support it. Over time I expect this note to change less than those, because the drivers should stay stable even when the details move.

## Safety

Safety comes before progress in a boatyard. These are the rules I want to hold to during Rinpo expansion.

- Keep walkways clear of hoses, pipes, and offcuts at all times.
- Treat open trenches and pits as hazards: fence them, mark them, and cover them at the end of every day.
- Keep fuel, solvents, and gas away from any hot work and away from drains.
- Never work under a suspended load or near the lifting gear while it is in use.
- Wear the right boots, gloves, and eye protection for the job, and keep spare sets for helpers.
- Be careful with wet ground in autumn, which is slippery and can hide soft spots.
- Isolate power and water before working on any existing line.

The plumber should confirm the isolation points before digging near existing pipes. I want a short briefing at the start of each working day so everyone knows what is happening and where. If conditions become unsafe, work stops, and no schedule pressure overrides that.

## Supplies

Supplies for the project fall into a few groups. I list the groups, not quantities, because quantities belong in the working lists.

- Pipe, fittings, valves, and clamps for water and drainage.
- Aggregate, bedding material, and surfacing for new ground.
- Timber, fixings, and roofing material if covered storage goes ahead.
- Sealants, tapes, and adhesives for the plumbing work.
- Marking paint, stakes, and string for setting out.
- Safety items such as signs, barrier tape, and spare gloves.

I want to order the long-lead items first, and the common consumables later and in small batches, so that nothing sits in the rain. Anything that must stay dry goes into the shed. Anything bulky is delivered close to where it is used.

I check every order against the budget before placing it. If something is not on the supplies list and is not essential, it waits until I have checked what else can be cut or deferred.

## Checklist

Before work starts and at each stage, I run through these items.

- The goal is written down and agreed: expansion.
- The lead, the plumber, has confirmed the plan for water and drainage.
- Existing pipes and lines are located and marked.
- The budget figure is written in the Budget section and nobody is working from a different one.
- Supplies for the stage are on site, dry, and counted.
- Tools are present and in working order.
- Safety briefing is done and barriers are in place.
- The weather outlook is acceptable for the planned work.
- The yard still has enough working space for day-to-day boat movement.
- Decisions made today are written down today.

At the end of each stage I add a line saying whether the stage moved the project toward expansion. If it did not, I stop and ask why before continuing.

## Budget

The budget of Rinpo expansion is 9809.38 EUR.

That is the one agreed figure, and I treat it as a ceiling, not a target. Every order, hire, and extra gets checked against it before I commit.

How I use it:

| Item | How I treat it |
| --- | --- |
| Pipework and drainage | Quoted first, bought early |
| Groundwork and surfacing | Sized after the drainage is settled |
| Covered storage | Only if money remains |
| Hire and delivery | Planned around the weather |
| Margin | Held back for surprises |

The margin matters most. Autumn weather and unknown ground conditions are the usual reasons projects go over, so I keep part of the budget uncommitted until the groundwork is done.

Success is measured against the goal of expansion: more usable ground and better drainage in the boatyard, delivered within this budget, without losing working space in the meantime. If the money runs short, I drop the ideas at the bottom of the list, not the drainage work.

## Tools

Tools needed, grouped by what they do.

- Digging and groundwork: spades, shovels, a pick, a rake, a wheelbarrow, and a compactor if I can hire one.
- Plumbing: pipe cutters, wrenches, a spirit level, sealant guns, and a pressure test kit.
- Measuring and setting out: tape, string line, stakes, a long level, and marking paint.
- Fixing and building: drill, saws, hammers, and a good set of driver bits.
- Lifting and moving: straps, a small trolley, and the yard's own lifting gear when it is free.
- Safety: barriers, signs, torches for short days, and a first aid kit within reach.

The plumber brings the specialist plumbing tools. I provide the general kit and organise hire for anything heavy. I keep tools in one place near the work area and check them back in at the end of each day, because lost tools cost time and sometimes cause trouble in a yard full of boats.

Worn or damaged tools get replaced or repaired before the next stage, not after.

## Schedule

The project is set for the autumn season, following its start year of 2025. I keep the schedule in phases, not fixed dates, because weather decides a lot.

1. Preparation: confirm the plan with the lead, mark existing lines, and order long-lead supplies.
2. Drainage and water work: this goes first, because everything else depends on it.
3. Groundwork and surfacing: only once the drainage is in and tested.
4. Covered storage or other additions: only if budget and weather allow.
5. Finishing: markings, signs, tidy-up, and a written maintenance routine from the plumber.
6. Review: compare the result with the goal and the budget, and write the lessons.

I leave slack between phases for rain and for deliveries that arrive late. If a phase slips, I move the later ones instead of squeezing them, since rushed groundwork is the most expensive kind to redo.

At each handover between phases, I run the checklist and update this note if any driver has changed.
