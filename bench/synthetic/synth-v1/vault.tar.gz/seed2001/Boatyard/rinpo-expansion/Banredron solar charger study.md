---
type: research
status: active
project: rinpo-expansion
area: boatyard
description: "Research about Banredron solar charger."
---

# Banredron solar charger study

## Risks

The Banredron solar charger is a black unit that sits in the workshop at the boatyard. I installed it in 2023. Its energy source is mains, which is odd for something called a solar charger, and most of the risks below come from that mismatch between the name and the way it is actually powered.

- **Mains feed in a damp place.** The boatyard workshop is not a dry room. Sanding dust, wet hulls, hoses and condensation all end up near the socket. The charger takes its power from mains, so any water reaching the plug, the lead or the case is a real shock risk, not a small annoyance.
- **Wrong assumption about sun.** Because it is a solar charger, I keep catching myself assuming it works off daylight. It does not. It runs from mains in the workshop. Anyone borrowing it, or reading my older notes, could expect it to keep a battery topped up outside or on a boat with no shore power. It will not.
- **Dust in the case.** The unit is black and sits low on the bench shelf. Fine dust shows on it less than it would on a light case, so I do not notice a build-up. Dust inside the vents can cause heat problems, and mixed with moisture it can cause tracking across the board.
- **Heat in a closed corner.** A black case absorbs heat from the window light in the afternoon. If the charger is working hard in a warm workshop, it may run hotter than I think. I have not measured this.
- **Overcharging by habit.** When I leave a battery connected for days between jobs, I am trusting the charger's cut-off. I have not tested that it behaves correctly with every battery type I own.
- **Mixing up the test results.** My earlier work on [[Krithdel solar charger tests]] was about a different charger. It is easy to carry its conclusions over to this one by mistake. The two units differ in how they are powered, so those results should not be treated as proof that this one is safe or efficient.
- **Trip and tangle hazard.** The lead runs across a walkway used by people carrying panels and planks. A pulled lead can drag the charger off the shelf.
- **No clear owner for upkeep.** Other people use the workshop. If something starts to smell hot or the case cracks, I am not sure who would notice first, or whether they would unplug it.

### How serious each one is

The most serious are the damp-place shock risk and the overcharging risk. A shock could hurt someone, and a swollen or damaged battery could start a fire in a building full of resin, solvent and wood. The others are mostly about wasted time and wrong expectations. I treat dust and heat as a medium risk, because they build up slowly and are easy to fix once I look for them.

## Lessons

Since 2023 I have learned a few practical things about this charger and about keeping a device like it in a boatyard workshop.

1. **Read the power source, not the name.** The label says solar, but the energy source is mains. I should have checked the input specification before planning where to put it. I spent time on the idea of placing it near a window, which made no difference to how it works.
2. **Location matters more than I expected.** The workshop is the right place for a mains device because the supply is already there and the room is covered. But the exact spot on the bench matters. Away from the sanding area and off the floor is much better than where I first put it.
3. **Black cases hide dirt.** I now wipe it down on a regular schedule instead of waiting until it looks dirty. Looking at it tells me almost nothing.
4. **Write the setup down once.** When I installed it in 2023 I did not note which socket, which lead or which switch it was on. A few months later I lost twenty minutes working out why it was dead, and the answer was a switched socket that someone had turned off. A short setup note would have saved that.
5. **Compare against earlier equipment.** The write-up on [[Fothzin heat exchanger 2021]] showed me how useful a plain before-and-after record is for workshop equipment. That note was about a heat exchanger, not a charger, but the habit carries over: note the baseline first, then record changes. I wish I had done that for this unit on the day it went in.
6. **Do not trust a single observation.** One good charge cycle told me very little. I need several, with different batteries, before I say the unit works well.
7. **Keep experiments separate.** I should keep the results for this unit apart from [[Krithdel solar charger tests]]. A shared page full of mixed findings was confusing, and I could not tell which numbers belonged to which unit.
8. **Ask others to tell me about faults.** A small label on the shelf saying who to tell, and to unplug it if it gets hot, is cheap and sensible.

### Habits I am keeping

- Check the plug and lead by eye each time I start work in the morning.
- Unplug the charger at the end of a long day when no battery needs it.
- Keep a single page per device, with the kind, color, energy source, year and location at the top.
- Treat the name on a device as marketing and the input specification as fact.

## Supplies

This section lists what I need to keep the charger running safely in the workshop. It is a working list, not a shopping order. I have deliberately left out part numbers and prices, because I would rather look those up when I buy.

- **Spare mains lead.** One lead of the right type, kept in the drawer, so I can replace a worn one the same day.
- **Protected socket.** A socket with residual current protection, or a plug-in protector, because the workshop is damp and the charger takes mains.
- **Cable cover or clips.** To get the lead off the walkway and stop it being pulled.
- **Soft brush and dry cloth.** For dust on the black case and around the vents. No wet cleaning while it is plugged in.
- **Compressed air or a small hand blower.** For clearing dust from the vents. I would use it outside the workshop so the dust does not settle on the bench again.
- **Shelf or bracket.** A raised, dry spot away from the sanding area, and not directly in window sun.
- **Labels.** A small label for the lead, one for the socket, and one with the instruction to unplug if hot.
- **Notebook page or index card.** To record the setup, the date of each check (in words, not exact dates) and what I found.
- **Spare fuse of the right rating.** I will only buy it after I confirm the rating from the unit itself. I am not guessing.
- **Test meter.** To check the output at the clamps when I suspect a fault. I already own one, but the leads are worn and need replacing.
- **Battery for testing.** A cheap, known battery I can use for trials, so I do not risk a boat battery while I am still unsure how the charger behaves.
- **Fire blanket or extinguisher near the bench.** The workshop holds solvents and resin, so this is not optional. I need to check that the extinguisher is in date and of a suitable type.

### Supplies I do not need

- Any solar panel or outdoor mounting kit. The energy source is mains, so panels would be wasted money unless I change the whole plan.
- A second charger. One is enough for now.

## Open questions

These are the things I still cannot answer. I want to resolve most of them before I write any firm conclusions about the Banredron solar charger.

- **Why is a mains-powered unit called a solar charger?** Is there a solar input I have not used, or is the name simply loose? I should check whether it can take a panel as well as mains, and how it switches between them.
- **How does it behave when mains fails?** If the workshop supply drops out and returns, does the charger restart cleanly? A restart that goes wrong with a battery connected would be a problem.
- **Does the cut-off work for all my batteries?** I have several kinds and I have only watched it with one or two. I need a careful trial with each, without leaving anything unattended.
- **How hot does it get in normal use?** The black case and the afternoon light make me suspicious. I want a simple comparison of case temperature in shade and in sun.
- **Is the workshop socket good enough?** The circuit may be old. I do not know if it has proper protection, and I should ask someone qualified to look at it instead of guessing.
- **Has dust already got inside?** I have not opened the unit since 2023 and I do not want to open it carelessly. I need to decide whether to open it, ask someone, or just clean the vents.
- **Should it stay in the workshop?** It is there because mains is available. A drier room in the boatyard might be better, but then I would need a new supply and a longer lead.
- **What would a fair test look like?** I want to compare it with the unit in [[Krithdel solar charger tests]], but the two are powered differently. I need to decide what is actually comparable: charge time, heat, noise, or something else.
- **Is there a lesson from the heat exchanger work?** The notes on [[Fothzin heat exchanger 2021]] included a maintenance routine that worked well. I should check if the same interval and style of checks would suit this charger.
- **Who else uses it?** If other people are plugging things in, I should know how they use it, so I can write down real habits and not just my own.

## Setup

The Banredron solar charger is a black solar charger that I installed in 2023 in the workshop at the boatyard. Despite the name, it does not run from the sun in my setup. Its energy source is mains. I wired it to a workshop socket, and it works as a mains-fed charger for the batteries I use around the yard. I keep this in mind whenever I read the manual, because most of the manual assumes a roof panel feeding the unit, and mine has no panel at all.

These are the properties I track for the device:

- Kind: solar charger
- Area: boatyard
- Color: black
- Energy source: mains
- Year installed: 2023
- Location: workshop

The unit sits on the wall bench near the door of the workshop. I chose that spot for three reasons. First, the socket is close, so the mains lead does not have to cross the floor where people walk. Second, the bench is away from the sanding area, so dust does not settle on the case as quickly. Third, the wall behind it is dry. The boatyard is damp for much of the year, and the far end of the workshop gets condensation on cold mornings.

The case is black, and that matters more than I expected. A black case shows dust and salt marks clearly, which makes it easy to see when it needs wiping. It also takes up heat when the sun comes through the high window in the afternoon. I fitted a small shade card over the window to stop the case getting warm on bright days. That is cheap, and it removed the one heat problem I had in the first summer.

### How it is connected

The mains lead runs from the wall socket to the unit through a switched outlet. The switch lets me cut power without pulling the plug, which I prefer, because the plug sits at an awkward height behind the bench. The output leads go to a labelled clamp board, and from there to whichever battery I am charging. I labelled each lead with tape on day one, and I have replaced the tape once since then.

I do not leave batteries on charge unattended overnight unless I have checked them first. That is a habit from the yard, not a rule from the maker. A battery that is old or damaged can gas or swell, and a workshop with varnish and solvents is a poor place for that.

### What I learned in the first weeks

- The unit works fine without a panel, but the display and the status lights still talk about solar input. I ignore those readings.
- The fan runs more than I expected when the case is warm, so the shade card helped with noise as well.
- The clamp leads are a little short. I added a short extension rather than moving the bench.
- Salt air gets into everything, so I wipe the terminals with a dry cloth each month and check for green marks.

## Costs

I do not keep exact prices in this note, because the figures changed between the purchase and the later extras, and I do not want old numbers to look current. What I record instead is the kind of cost and how it has behaved over time. That is more useful to me when I decide whether to keep the charger or replace it.

### Money spent

The main cost was the purchase of the unit in 2023. After that, the spending was small and came in a few groups:

- The switched outlet and a length of mains cable for the bench.
- The clamp board and the tape and labels for the leads.
- The shade card for the window, which cost almost nothing.
- Cloths, contact cleaner and a small tube of terminal grease for the monthly care.
- One set of replacement clamps after the first pair corroded.

The clamps were the only part that wore out. Everything else has lasted since 2023 without a repair. I count that as a good result for a unit that lives in a damp boatyard workshop.

### Running cost

Because the energy source is mains, every charge comes off the workshop meter. That is the real difference from a true solar setup. A panel would have made the running cost close to nothing, but it would also have needed a roof mount, a cable run and an agreement with the yard owner about the roof. I decided that was not worth the trouble for a unit that sits indoors. The mains feed is simple and works in winter, when a panel would give very little.

The running cost is small because I charge in short sessions and only when a battery is low. The largest part of the electricity use comes from the weeks when I am testing several batteries in a row. I try to bunch that work into a few days so the charger does not stay powered for no reason.

### Hidden costs

There are a few costs that do not show up on a receipt:

- My time each month for cleaning and checking the terminals.
- The risk of a damaged battery, which means I need a safe place and a fire blanket nearby.
- The cost of confusion. Because the device is called a solar charger but runs from mains, anyone new to the workshop assumes the wrong thing. I put a note on the bench to say so.

### Whether it was worth it

For the workshop, I think yes. The charger has been reliable since it was installed in 2023, the extra spending has been small, and the care it needs is easy. If I ever replace it, I will look for a plain mains charger, since I never use the solar side. I would only choose another solar model if I moved the work outdoors or added a panel to the yard.

## Checklist

I use this list before and after each charging session, and again once a month for the longer care. It is short on purpose. A long list gets skipped, and a skipped list is worse than no list.

### Before charging

- Look at the case and the mains lead for damage, heat marks or loose strands.
- Check that the switched outlet is off before connecting any battery.
- Wipe the battery terminals and the clamps, then look for green or white crust.
- Make sure the battery is the right type for the charger and is not swollen or leaking.
- Clear solvents, rags and varnish tins away from the bench.
- Connect the output leads first, then switch the mains on.

### During charging

- Check the unit after the first few minutes to confirm it has started normally.
- Ignore the solar input readings, since the energy source here is mains.
- Listen to the fan. If it runs hard with a cool case, something is wrong.
- Come back within the hour at least once, and do not leave the workshop locked with a battery on charge unless it has been checked.

### After charging

- Switch the mains off at the outlet before removing the leads.
- Remove the clamps in the reverse order from connecting them.
- Wipe the case with a dry cloth. The black finish shows marks, so this is quick to judge.
- Coil the leads loosely and hang them on the board with the labels facing out.

### Monthly care

- Clean the terminals and the clamp board with contact cleaner, then add a thin layer of grease.
- Check the labels on the leads and replace any that have peeled.
- Dust the vents on the case, especially after weeks of sanding in the workshop.
- Look at the window shade card and replace it if it has curled.
- Check the wall behind the unit for damp.

### Yearly care

- Inspect the whole mains lead and the switched outlet for wear.
- Test the clamps for firm grip and replace any that are loose or corroded.
- Review this note and correct anything that no longer matches the setup.

## Schedule

I plan the care of the Banredron solar charger around the rhythm of the boatyard. The yard is busiest in spring, when boats are launched, and again in autumn, when they come out. Battery work rises at both times, so the charger gets its heaviest use then. I try to finish the main care just before each busy period, so the unit is clean and checked when I need it.

### Routine pattern

- **Every session:** run the before, during and after checks from the checklist.
- **Every month:** do the monthly care, with a focus on terminals and labels.
- **Every spring:** check the whole setup before launch season, including the lead, the outlet and the clamps.
- **Every autumn:** repeat the check before haul-out, and look again at damp on the wall.
- **Every year:** do the yearly care and update this note.

### Seasonal notes

In spring the workshop is cold and damp, so I give extra attention to condensation. I let a cold battery warm up a little before charging it, and I check the case for moisture before switching on.

In summer the afternoon sun through the high window is the main concern. The shade card helps, but I still look at the case on hot days. If it is warm to the touch before charging, I wait.

In autumn the yard is busy and the workshop fills with dust from sanding. I wipe the vents more often at this time and keep the bench clear.

In winter the use is lighter. This is a good time for the longer jobs, such as replacing worn clamps, redoing labels and checking the mains lead. Since the energy source is mains, the charger works as well in winter as in summer, which is one reason I never added a panel.

### Planning ahead

I keep a short list of things I want to review as the device gets older. It has been in the workshop since 2023, and I expect the clamps and the leads to be the first parts to need attention again. The case and the electronics have held up well.

- Decide whether to replace the clamps before the next launch season or wait until they fail.
- Think again about a plain mains charger if this unit starts to run hot or noisy.
- Keep the note on the bench about the name, so visitors know the energy source is mains.
- Check that the workshop socket and its protection are still in good order.

### Reminders

I set a repeating reminder for the monthly care on the first working day of the month. The spring and autumn checks go on the yard calendar next to the launch and haul-out plans. That way the charger is not forgotten when the yard is busy. After each check I add a line to my own log, with what I found and what I changed, so the next review starts from facts rather than memory.

## Ideas

The Banredron solar charger is a black unit that has sat in the workshop since 2023. It is a solar charger by kind, but its energy source is mains. That mismatch is the main reason I started this study. A solar charger fed from the wall socket is an odd thing, and I want to understand what it is actually doing for the boatyard.

My working idea is that the unit behaves as a bench charger built on solar charger electronics. It uses the same kind of regulation logic you would find on a panel-fed controller, but the input comes from the workshop mains supply. That would explain why it handles slow, careful topping up of batteries so well. It was designed to be gentle with a variable source, so a steady source is easy for it.

Some ideas I want to test over the coming months:

- Check whether the charger behaves differently on cold mornings in the workshop than on warm afternoons. If the regulation is tuned for sunlight swings, it may still hunt a little even on a steady supply.
- Try a real panel on the roof outside the workshop and see whether the unit accepts it as a second input. I doubt it, because the energy source is listed as mains, but the case has a blanked-off area that looks like it could hold a connector.
- Put the unit on a timer so it only runs during the hours when the workshop is in use. This would cut the idle draw and mimic daylight-only operation.
- Dedicate it to the small batteries used for handheld tools and navigation lights, and leave the large boat batteries to the heavier chargers.
- Keep a short paper log beside the unit so that anyone using it can write down what they connected and for how long.

One more idea is to treat the charger as a teaching object. New people at the boatyard often ask why we charge batteries slowly. The black box on the workshop shelf is a good way to show a gentle charge cycle without a lecture.

A bigger question is whether it is worth keeping in the workshop at all. It was installed in 2023 and has run without drama. The alternative would be to swap it for a plain mains charger. I lean toward keeping it, but I want a few more weeks of notes before deciding.

## References

This section collects what I have used so far to understand the unit. Most of it is my own material, because the maker's documentation is thin and I have not found much independent writing on the device.

**Things I have on hand**

- The printed leaflet that came in the box. It describes the unit as a solar charger and gives basic connection steps, but it says little about the mains input and nothing about why a solar charger would take mains.
- My own photos of the front panel and the label on the back, taken when I first set it up in the workshop. They are useful for checking the layout of the terminals and indicator lights.
- The installation notes I wrote in 2023. They record where the unit sits, how the lead runs to the socket, and what I connected first.
- A page in my boatyard notebook listing the batteries that have been charged on it, with a rough note of how each one behaved.

**Things I have looked for and not found**

- A proper wiring diagram from the maker.
- Any technical bulletin that explains the choice of mains as the energy source.
- Anyone at the boatyard who remembers the reason the unit was bought rather than a standard charger.

**Background reading I find useful in general**

- General notes on how charge controllers stage a charge: a bulk phase, an absorption phase and a float phase. Even without exact figures, the idea helps me read the indicator lights.
- Boatyard safety guidance on charging batteries indoors, especially about ventilation and keeping the area clear of loose metal.
- My own earlier notes on small batteries and how they age when left uncharged over winter.

The gap in the references is the biggest weakness of this study. Most of what I conclude comes from watching the unit rather than from documents. I should say that plainly whenever I write down a finding here, so that a guess is not mistaken for a fact later.

If I ever contact the maker, the questions I would ask are simple. Why does a solar charger run from mains? Is the blanked-off area meant for a panel connector? What is the intended use for the black case in a workshop setting?

## Maintenance

Maintenance on this unit has been light. It is a black, sealed-looking case with no moving parts that I know of, so most of the work is keeping it clean, dry and safely connected. Here is what I do and what I plan to do.

**Regular checks**

- Wipe the black case with a dry cloth. Workshop dust shows clearly on the dark finish, and a thick layer can block the vents.
- Look at the mains lead along its full length for nicks, flattened sections or signs of heat near the plug. The lead runs close to the bench edge, so it is exposed to knocks.
- Check that the terminals are tight and free of white or green corrosion. Boatyard air is damp and salty, and the workshop is not immune.
- Make sure nothing is stacked on top of the unit. Offcuts and rags have a habit of ending up there.
- Confirm that the indicator lights come on in the normal order when a battery is connected.

**Occasional work**

- Once a season, switch off at the wall, unplug the unit and inspect the back label and the connector area with a torch. Check that the label is still readable.
- Clean the terminal contacts with a small brush if there is any build-up. I do this only with the unit unplugged.
- Re-seat the plug in the socket and check the socket itself for looseness.
- Review the paper log and see whether any battery has shown a pattern of poor charging.

**What I do not do**

I do not open the case. The unit is a solar charger with a mains input, and I do not understand the internals well enough to work inside it safely. If something fails, the plan is to stop using it, label it as faulty and decide then whether it can be repaired or should be replaced.

**Storage and downtime**

If the workshop is closed for a long stretch, I unplug the unit and leave it on the shelf with the leads coiled loosely. I avoid tight coils because they stress the cable near the plug. Before returning it to service, I do a visual check and a short test with a small, low-value battery.

One thing I want to improve is the location. The workshop is the right place for convenience, but the shelf is near a door that opens to the yard. On wet days, damp air blows across the unit. Moving it a short distance along the wall would be an easy fix.

## Observations

These are my notes from using the Banredron solar charger in the workshop since it was installed in 2023. They are informal and based on what I have seen, not on measurements.

**Summary of the subject**

- Kind: solar charger
- Area: boatyard
- Color: black
- Energy source: mains
- Year installed: 2023
- Location: workshop

**General behavior**

The unit starts up calmly. When I connect a battery, the lights show that it has recognised the load, and charging begins without any fuss. It does not seem to rush. Batteries that I leave on it for a long session come off feeling cool and in good condition, which fits my idea that it was built around gentle regulation.

**The mains puzzle**

The odd part remains the mix of the solar charger label and the mains energy source. In daily use this makes no practical difference. I plug it into the workshop socket, and it works. But I keep wondering whether the unit was meant to do more. The blanked-off area on the case still suggests a feature that is not in use. For now, I treat it as a mains-fed charger with a solar-style character.

**Workshop conditions**

The workshop is dusty in the busy season and damp in the colder months. The black case hides small marks well, but dust on the top surface is easy to see. I have not seen any sign of rust or water damage on the unit, though I would expect corrosion to show first on the terminals. So far, they have stayed clean with only occasional attention.

**Reliability**

Since 2023 I have not had a failure that I could trace to the unit. There have been a few times when a battery would not take a charge, and in each case the fault turned out to be the battery or a poor clip rather than the charger. That makes me trust it more, though it is a short record.

**Open questions**

- Does the unit lose efficiency when the workshop is cold?
- Is there any way to make use of the blanked-off area?
- Would a timer be worth fitting?
- Should I move it away from the door?

**Current view**

My current view is that the Banredron solar charger is a quiet, dependable workshop tool, even if its description is a little confusing. I will keep logging how it behaves, keep the maintenance routine going, and revisit the question of what the solar label really means if I ever find the maker's documentation. Until then, the unit stays where it is, black and unremarkable, doing its job for the boatyard.

## Tools

This part of the study covers what I used to look at the Banredron solar charger and what I keep next to it when I work on it. The charger is a black unit, installed in 2023 in the workshop at the boatyard. Its energy source is mains, which sounds odd for a solar charger, and I come back to that in the overview.

The tools I actually reach for are simple. I did not buy anything special for this study.

- A basic multimeter, for checking the output side and confirming that the mains side is dead before I open anything.
- A clamp meter, for seeing how much current the charger pulls while it is working.
- A small set of screwdrivers, mostly the narrow flat ones, because the case screws are shallow.
- A torch with a clip, since the charger sits low on the workshop wall and the light there is poor in the afternoon.
- A notebook with a pencil on a string, kept on a hook beside the unit, for jotting down what the indicator lights are doing.
- A roll of masking tape and a marker, for labelling the leads before I unplug them.
- A soft brush and a dry cloth, for dust. The workshop makes a lot of sanding dust and the charger collects it.
- A phone, for photos of the wiring and the front panel before I change anything.

I also keep a habit list, because I forget steps when I am tired:

1. Switch off at the wall and pull the mains plug before touching the case.
2. Photograph the leads and the front panel.
3. Label every lead with tape.
4. Do the work.
5. Check the leads against the photos before switching on again.
6. Write one line in the notebook about what was done.

The clamp meter has been the most useful of all the tools. A lot of the questions I had about this charger were really questions about how much power it takes from the wall and when. The multimeter answers the simpler question of whether anything is coming out at all.

One thing I have learned about the tools is that the case of this charger is black and the labels on it are printed in a dark grey. Under workshop light the text is hard to read. The torch, held at a low angle, makes the lettering show up. I now keep the torch hooked on the wall right next to it.

## History

The Banredron solar charger was installed in 2023. It went into the workshop of the boatyard, where it still is. I do not have a purchase receipt in my notes, so I cannot say exactly what was paid, and I am not going to guess a figure. What I do have is memory and some scribbled notes.

The reason for getting it was practical. The boatyard had been charging batteries in a patchy way. Some were put on a bench charger and forgotten. Others were carried to whichever socket was free. Someone wanted a single, fixed place where batteries could be topped up, and the workshop was the obvious spot because it is dry, has mains, and is where the batteries get used and tested.

The sequence, as best I can piece it together, went like this:

- Before 2023, charging was done with a mix of older chargers that had no fixed home.
- In 2023, the Banredron was bought and fitted to the workshop wall.
- After it was fitted, the older chargers were put away, and most of them were eventually used for spares.
- Since then the unit has mostly run without trouble, with a few small things I noted down and cover below.

Over the years since installation I have made only a few notes. The first was about the mounting. The unit was fixed a little low, and I have bumped it with crates more than once. The second was about dust, as mentioned above. The third was about the indicator lights, which I did not understand at first and had to work out by watching them over several days.

I have not rewired or replaced any part of it. It is still the unit that was installed in 2023, in the same place, and it still looks the same apart from some scuffs. The black case has taken a few marks from tools and from being leaned on.

I would like to keep a better record from now on, which is partly why I am writing this study. A short entry each time I touch it would have saved me from guessing about its history now.

## Background

To make sense of this study it helps to know a little about where the charger sits in the boatyard and what the yard does.

The boatyard is a working place. Boats come in for repair, painting, engine work, and winter storage. A good deal of that work needs batteries: for hand tools that run on cells, for torches and lamps, for small electric equipment, and for testing the electrical systems of the boats themselves. Batteries that are flat at the wrong moment slow everything down, so charging is not a side matter. It affects how the day goes.

The workshop is the central building. It has benches, racks for tools, and a long wall where most of the sockets are. The Banredron is fixed on that wall. It is a solar charger by kind, which means it is built around the idea of charging from sunlight. In my case, though, its energy source is mains. The unit is wired to the wall supply in the workshop and does not draw from a panel on the roof. I want to be clear about that, because the name and the kind suggest something different, and I misremembered it myself for a while.

Here is how I think about the setup in plain terms:

- **Kind:** solar charger.
- **Area:** boatyard.
- **Color:** black.
- **Energy source:** mains.
- **Year installed:** 2023.
- **Location:** workshop.

I find it useful to have these in one place, because when I come back to the note after some months I want the basic facts first and the detail second.

The mismatch between a solar charger and a mains supply is the main puzzle of the study. A few explanations seem possible, and I have not settled which is right:

1. The unit is designed to accept more than one input, and the installer used the mains input because there was no panel.
2. The unit is sold under a solar name but is mostly a general charger with a solar option.
3. A panel was planned and never added.

I lean toward the third, since the workshop roof has an awkward angle and the yard has talked about panels more than once. But that is a guess from conversations, not from paperwork. I will say more about it in the next part of the note if I find anything.

## Overview

This is a short overview of what the Banredron solar charger is, where it is, and how it behaves, written as a summary for my own use.

The charger is a solar charger, black in color, installed in 2023. It belongs to the boatyard and is located in the workshop. Its energy source is mains, so in practice it is fed from the wall supply and not from sunlight. Those are the facts I want to be able to find quickly.

In daily use it works like this. A battery is connected with its lead, the charger is switched on, and the indicator lights show the state of the charge. I do not need to adjust anything for ordinary work. The lights move through a short pattern as the battery fills, and then settle into a steady state that I take to mean the battery is full. I confirmed that reading by checking a battery with the multimeter after the lights settled, and the result matched what I expected from a full battery.

What I like about it:

- It lives in one fixed place, so everyone knows where to charge things.
- It is simple to operate, with very few controls.
- The case is solid and has survived years of workshop life.
- It has needed almost no attention since 2023.

What I do not like:

- It is mounted low and gets bumped.
- It collects dust, so it needs regular cleaning.
- The dark labels are hard to read on a black case.
- The name suggests solar input, which is misleading given the mains supply.

Practical points I want to remember:

1. Always disconnect from the mains before opening or cleaning anything beyond the outside of the case.
2. Brush the dust off the vents regularly, especially after a sanding job.
3. Use the torch at an angle to read the labels.
4. Keep the notebook updated, because the history of the unit is thin.

For the rest of this study I intend to keep the focus on the plain facts: what the unit is, where it is, and how it is powered. The open question is why a charger with a solar name runs on mains, and whether a panel was ever meant to feed it. If I can find the original plan or ask the person who installed it, I will add the answer here. Until then, the safest way to describe the Banredron is as a black solar charger in the boatyard workshop, installed in 2023 and running from mains.

## Parts

This section lists what the Banredron solar charger is made of, as far as I can tell from opening the case and looking at the unit on the workshop wall. The charger is a black unit, installed in the workshop at the boatyard in 2023. Despite the name, it runs from mains power, not from a panel. It is a solar charger by kind only, and the name is a leftover from how it was sold. I keep that in mind whenever I look at the parts, because there is no panel input I need to account for.

The serial number of the Banredron solar charger is SN-39892878. It is printed on a label on the lower edge of the case, and I have also copied it onto the inside of the workshop logbook. If I ever need to ask for a replacement part or report a fault, this is the number to quote.

### Summary of the unit

- Kind: solar charger
- Area: boatyard
- Color: black
- Energy source: mains
- Year installed: 2023
- Location: workshop
- Serial number: SN-39892878

### Outer case

The case is a black powder-coated metal box with a plastic front plate. The metal is thin but stiff enough that it does not flex when I mount or remove it. The black finish has held up well in the workshop. There are a few scuffs near the bottom corners where I have knocked it with tools, but nothing has rusted through. Dust is the main enemy here. Sanding and grinding in the workshop put a fine layer on the top surface, and I wipe it off with a dry cloth every few weeks.

The case is held shut with four screws, one in each corner of the back. The screws are a common cross-head type, so any ordinary screwdriver works. I keep the screws in a small tin when I open the unit so they do not roll off the bench.

The front plate carries the indicator lights and a single push button. The lights show whether the unit is on and whether it is charging. The push button wakes the display if the unit has gone idle. The plate is held on with clips, and I broke one clip the first time I pried it off. It still sits firmly, but I now press gently at the sides instead of levering at the top.

### Mains input

Since the energy source is mains, the input side is the part I check most often. It has these pieces:

- A fixed mains cable that leaves through a rubber grommet at the back of the case.
- A plug on the end of that cable, which goes into a wall socket near the workshop door.
- An internal fuse holder just behind the grommet, which I can reach only with the case open.
- A small switch on the side of the case that cuts power to the whole unit.

The cable is black as well and has stayed flexible. I check the grommet each season to make sure it is still tight, because a loose grommet lets the cable rub against the sharp edge of the case. So far there is no sign of wear on the insulation. I keep the cable run tidy along the wall and off the floor, since the workshop floor sees dropped tools and spilled liquids.

The fuse holder is the one part I would call a likely failure point, not because it has failed, but because a fuse is the first thing to go when something odd happens on the mains. I keep a spare fuse of the matching rating in the workshop drawer. I do not write the rating here because it is printed right on the holder and I would rather read it fresh than trust a copy.

### Conversion board

Inside the case, the largest component is the main board. It takes the mains input and turns it into the lower voltage output used for charging. The board is green with a heat sink on one side. The heat sink is a block of ribbed aluminium, and it gets warm in use. I have never found it too hot to touch for a second or two, which I take as a good sign.

Next to the heat sink are a couple of tall capacitors and a transformer. The capacitors are the parts that age first in a unit like this. When I opened the case I looked for any bulging on the tops and found none. I will repeat that check every year or two. The transformer hums faintly when the unit is under load. That sound has not changed since 2023, so I treat it as normal.

There is a small cooling fan fixed near the vent slots. It spins only when the unit is working hard. Fine workshop dust collects on the blades, and that is the thing I clean most carefully. I use a soft brush and a short burst of air, with the unit unplugged and the mains switch off.

### Output side

The output side is where the boat gear connects. It has:

- A pair of heavy output leads with clamp ends.
- A short sense lead that tells the board how the connected battery is doing.
- A strain relief at the point where the leads leave the case.

The clamps are the parts that see the most handling, since I connect and disconnect them whenever a battery comes in from the yard. The jaws are plain metal with red and black sleeves. The black sleeve is the negative lead, and the red sleeve is the positive. I have replaced nothing here yet, but the sleeves are beginning to look tired, and I expect to renew the clamps before the main board needs any attention.

The sense lead is thin and easy to damage. I tape it to the main leads with a few loose wraps so it does not get caught on a bench edge. If the unit ever begins charging oddly or stops early, I will check this lead first, because a broken sense wire is a cheap and common cause of that behaviour.

### Display and controls

The indicator lights are small and sit behind the plastic front plate. They are driven by a tiny control board that is separate from the main conversion board and connects to it by a short ribbon cable. This ribbon cable is the one internal connection I treat carefully. It seats into a socket with a small latch, and I always lift the latch before pulling the cable.

The push button is a simple momentary switch. Its feel is slightly stiffer than when it was new, but it works every time. If it ever sticks, replacing it should be easy, since it is soldered at only a few points.

### Mounting and fixings

The unit hangs on two screws driven into a wooden batten on the workshop wall. Keyhole slots on the back of the case drop over the screw heads. I chose the batten so the screws bite into solid wood and not just plasterboard. The unit sits at about chest height, so I can read the lights without bending, and the output leads reach the bench without stretching.

There is a gap of a hand's width above and below the case so that air can move through the vent slots. I keep that space clear and do not stack boxes or coats near it.

### Spares and what I keep

Here is the short list of spares and tools I keep for this unit:

- One spare fuse of the matching rating.
- A small tin for the four case screws.
- A soft brush for dust.
- A spare set of clamp sleeves, in case the current ones split.
- A cross-head screwdriver that fits the case screws.

### Notes for next inspection

At the next inspection I want to do these things in order. First, unplug the unit and switch it off at the side. Second, remove the four case screws and lift the back off. Third, look at the capacitors for bulging and at the fan blades for dust. Fourth, check the grommet and the fuse holder. Fifth, inspect the output clamps and the sense lead. Finally, close the case, refit the screws, and write the date in the logbook next to the serial number SN-39892878.

If anything looks wrong, I will stop and leave the unit unplugged until I have worked out what it is. The charger has been a quiet and reliable part of the workshop since 2023, and the aim of these checks is to keep it that way without much fuss.
