---
type: research
status: active
project: rinpo-expansion
area: boatyard
---

# Stundglerk Keglu tests

## Schedule

Stundglerk Keglu is my neighbor at the boatyard. I have known him since 2020. The best way to reach him is by phone, and he is only reliably available in the evenings. That one fact shapes almost everything I plan with him, so I keep the schedule simple and built around evening calls.

These notes cover the tests I run together with him, mostly small trials of how we share work, tools and space near the boatyard. Nothing here is formal. It is a record of what I tried, what went wrong and what I would repeat.

| Item | Value |
|---|---|
| Name | Stundglerk Keglu |
| Role | Neighbor |
| Area | Boatyard |
| Contact | Phone |
| Availability | Evenings |
| Known since | 2020 |

My working pattern is this:

- Call in the evening, after the yard has gone quiet.
- Keep each call short and name one topic only.
- Write down what we agreed right after hanging up.
- Follow up the next evening if something stays open.

I do not try to catch him during the day. When I did that early on, I got voicemail, and then I waited, and then I called again anyway. Evenings work, so I stay with evenings.

## Problems

The first problem is simply timing. Because Stundglerk Keglu is available in the evenings, anything urgent during the working day has to wait. A loose tarp or a blocked gangway cannot always sit until dusk. I have learned to separate what can wait from what cannot, and to handle the second kind myself or ask someone else who is on site.

The second problem is that phone is the only contact channel I have for him. There is no written trail unless I make one. Twice I remembered a promise differently than he did, and neither of us could prove anything. That was a small irritation, but it grew over time.

The third problem is that evening calls can run long. A quick question turns into a talk about boats, weather and the yard. I enjoy it, but it eats the hour I had set aside for other chores.

Other things that went wrong in the tests:

- I called too late once, and he did not pick up.
- I assumed he had heard a message that he had not.
- I gave vague times such as "soon", which meant nothing to either of us.
- I skipped writing notes after a call and lost the details by the weekend.

## Lessons

The main lesson is that a neighbor you have known since 2020 still needs clear arrangements. Friendship does not replace a plain note of who does what and by when.

What I learned, in order of usefulness:

1. Write the agreement down the same evening, in my own words.
2. Say a specific day and a specific task, not a general plan.
3. Repeat the key point at the end of the call so we both hear it again.
4. Keep calls to a single subject.
5. Do not rely on him for anything that must happen during daytime hours.

A second lesson is about tone. He responds well when I am direct and friendly, and badly when I bury the request inside a long story. I now start with the request, then add the background if he asks for it.

A third lesson is that patience pays. When I waited one more evening instead of pushing, the answer was usually better and the mood was easier. Being available in the evenings is a fact of his life, not a sign that he is ignoring me.

## Contracts

We keep our arrangements informal, but one of them was important enough that I wrote it down as a contract. The contract date of Stundglerk Keglu is 2024-04-18. That is the day we agreed on the terms and I made my own record of them.

What the note covers, in general terms:

- Who is responsible for which task around the shared boatyard space.
- How we tell each other about changes, which means by phone in the evening.
- What happens if one of us cannot do a task on the agreed day.

I did not put prices or part details in it. It is a practical memo, not a legal document. Still, having a clear date on it has saved me from arguments about when something was settled. If the arrangement changes, I will write a new note with a new date instead of editing the old one, so the history stays readable.

I keep a copy of the memo with my other yard papers. Whenever there is doubt, I read it out to him on the phone, and that usually ends the question quickly.

## Checklist

Before I call or plan anything with Stundglerk Keglu, I run through this list:

- [ ] Is it evening, and is it a reasonable hour?
- [ ] Do I have one topic ready, with the request stated first?
- [ ] Have I looked at the contract memo in case it applies?
- [ ] Do I have something to write with during the call?
- [ ] Is the matter something that can wait until evening?

After the call:

- [ ] Write down what we agreed, including the day and the task.
- [ ] Note anything he said he would check or bring.
- [ ] Set a reminder for a follow-up the next evening if needed.
- [ ] Update the contract memo only if the terms really changed.

This list is short on purpose. If it grows longer, I stop using it. The point is to make the habit automatic, so that a call with a neighbor turns into a clear record without extra effort.

## Safety

The boatyard is a place where small mistakes can hurt someone, and evenings add risk because the light is poor and fewer people are around. These are the rules I follow when I arrange work with Stundglerk Keglu.

- Do not plan heavy lifting or work on ladders late in the evening when the light is bad.
- Keep a charged phone with me at all times, since phone is how we reach each other.
- Tell someone else where I am if I go to the yard after dark.
- Wear proper footwear, as the ground can be wet and uneven around the boats.
- Keep walkways and gangways clear, and put away tools before leaving.
- Do not start work near stored fuel or open flames without agreeing the plan first.

If a safety issue appears during the day, I do not wait for his evening availability. I deal with it directly or ask whoever is on site, and I tell him afterward by phone. Anything that involves risk to people comes before any arrangement we have. Once the danger is handled, I make a note of what happened so that we can avoid it next time.
