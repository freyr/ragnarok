---
type: summary
status: active
project: rinpo-expansion
area: boatyard
description: "Summary about Rinpo expansion."
---

# Summary of Rinpo expansion

## History

Rinpo expansion is a project with the goal of expansion, in the boatyard area. It started in autumn 2025, and the lead is the plumber. This note is the running summary, so I keep it short and update it when something changes.

The idea came from the yard running out of room for work under cover. Boats were waiting outside longer than they should, and the water and drainage runs were already stretched. That is why the plumber took the lead: most of the early questions were about pipes, pumps and where the wash-down water would go.

In autumn 2025 we walked the site twice and marked the likely footprint. We listed what the plumber needs to check on the existing lines, and we talked through the order of work so the yard could keep running while the expansion went ahead. Since then the work has been mostly planning and checking, not building.

Stage right now: still in preparation. The footprint is agreed in rough terms. The plumbing survey of the existing lines is the main thing that has been done. The final layout is not yet fixed.

Open points:
- Final position of the new drainage run.
- Whether the current pump can carry the extra load or needs replacing.
- How to phase the work so slipway jobs are not blocked.
- Who covers the cost of any temporary shutoff of water to the sheds.

## Next action

The next action is NX-2633. I keep it as the single thing to do next, so I do not start other work on the project until it is closed. Once it is done, I will review the open points above and decide what follows, then update this note with the new stage.

## Decisions

The go decision date for Rinpo expansion is 2018-01-17. That is the date recorded for the go decision, and I keep it here so the date is easy to find.

Other decisions so far are small and practical. The plumber leads the project. The yard stays open during the work, so the plan has to be phased. The drainage and pump questions must be settled before any layout is treated as final. Anything that changes these points gets written here, with a short reason, so I can see later why I chose what I chose.
