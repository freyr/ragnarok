---
type: drivers
status: active
project: salstor-repair
area: boatyard
description: "Drivers about Salstor repair."
---

# Drivers of Salstor repair

## References

Salstor repair is a project with the goal of repair, set in the boatyard area. It started in 2025 and runs in the summer season. The lead is the plumber. These notes feed the reasoning behind it, so I keep the links here in one place.

- [[Brakastrus Drestraend log]]: the running record of what was done and when, useful for seeing how earlier work held up.
- [[Lelben heat exchanger]]: the closest match for the part I expect to deal with first.
- [[Brunbaedos heat exchanger]]: the alternative I compare against, mainly for fit and access.
- [[Rirklaerk valve actuator notes]]: how the valves behave when they are driven, which matters for the plumbing side.
- [[Ruthglaend dehumidifier]]: relevant because damp air in the shed affects how long repairs last.
- [[Baerkstind band saw]]: needed for cutting the timber and panels around the work.
- [[Fupu greenhouse plan]]: a past plan I reuse for layout and ordering of jobs.
- [[Sogionvin Stilstur tests 2023]]: the test results I use as a baseline for judging whether the repair works.

### Goal and constraints

The goal is simple: get the equipment back into working order and keep it that way through the season. The main constraints are:

- The work is done in summer, so it has to fit between other boatyard jobs.
- The plumber leads, so the order of work follows what the plumber needs first.
- Parts should be reused where the old tests show they are still sound.
- Anything that needs cutting is done in one session to avoid setting up twice.

### Measuring success

I count the repair as a success when the repaired system runs without leaks or faults for the whole summer, and when a retest matches or beats the 2023 baseline. If something has to be redone, that counts against it.

## Budget

The budget of Salstor repair is 2819.60 EUR.

I keep to this figure for parts, materials and any hired help. If a choice between the two heat exchangers would push the total over, I take the cheaper one that still meets the baseline tests. Spending is checked at the end of each month of the summer, and anything unplanned is written down next to the reason for it, so the next project can learn from it.
