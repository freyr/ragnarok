---
type: summary
status: active
project: salstor-repair
area: boatyard
description: "Summary about Salstor repair."
---

# Summary of Salstor repair

## Risks

The main risks on the Salstor repair are practical ones. I am listing them here so I can check them against the work before each visit to the boatyard.

- **Weather in the summer season.** The project runs in summer, and that is the busy time at the boatyard. Heat and sudden rain both slow the work. Open pipework left uncovered overnight is the biggest worry.
- **Access to the work area.** Boats get moved around the yard, and a hull parked in the wrong place can block the plumber for a whole day. I need to confirm the space is clear before anyone starts.
- **Parts that do not match.** Old fittings on the Salstor line were not always standard. If the replacement does not fit the first time, the repair stalls while we wait for another delivery.
- **Single point of lead.** The lead is the plumber. If the plumber is unavailable, nobody else knows the full layout, so my own notes have to be good enough for someone else to follow.
- **Scope creep.** Repairs tend to uncover more repairs. The goal of this project is repair, not rebuild, and I have to keep to that.
- **Leaks found late.** A joint that looks fine dry can fail under pressure. Testing has to happen before anything is closed up.

Related earlier experience is in [[Brunbaedos heat exchanger 2024]], where a late leak cost more time than the original fault. I am treating that as a warning for this job.

## Next action

The next action for the Salstor repair is **NX-0736**.

That is the item I pick up first when I open this project. Nothing else should start until it is done or clearly blocked. If it gets blocked, I write down why in the project log so the reason is not lost, and then I tell the plumber.

What I want from this step:

- A clear result I can record, either done or blocked with a reason.
- No new open questions left hanging.
- A short note on anything unexpected that I saw while doing it.

After NX-0736 is closed, I will review the open points further down and choose the following step from there.

## Decisions

The decisions so far are few, and I want to keep them visible.

- **Go decision date:** 2019-08-16. This is the date recorded for the go decision on the Salstor repair, and I am keeping it exactly as it is written in my records.
- **Goal:** repair. The aim is to restore what is already there to working order, not to replace the whole system.
- **Area:** boatyard. All work takes place in the boatyard and the decisions are made with that environment in mind.
- **Lead:** plumber. The plumber leads the practical work and has the final say on how the pipework is handled.
- **Season:** summer. The work is planned for the summer season, when the yard is open and the ground is dry.
- **Start year:** 2025. This is the year the project began.

Other decisions I made along the way:

- Reuse sound parts where the plumber confirms they are good, and replace only what is worn or damaged.
- Pressure test before closing up any section.
- Keep a written record of each change, so the next repair is easier to plan.

Anything not on this list is still undecided and should be treated as an open point.

## Setup

The setup describes how the project is organised and what I need around me when the work happens.

**People.** The plumber leads. I act as the note keeper and coordinator. I handle the access to the yard, the order of the work and the records.

**Place.** The work is at the boatyard. Before each session I check where the boats are standing, where the water can be shut off, and where tools and spare parts can be left safely.

**Tools and materials.** I keep a simple list for each visit:

- Basic pipe tools and a set of spare fittings in common sizes.
- Sealing material and clean cloths.
- A pressure test kit for checking joints.
- Covers or tarps for protecting open pipework.
- A notebook or phone for photos and notes.

**Records.** Every change gets a short entry: what was done, who did it, what was found. Photos of the layout before and after are kept with the note. For ideas on how I laid out similar records, see [[Zobanfond greenhouse notes]], which has a format I reused here.

**Order of work.** First isolate the section, then inspect, then repair, then test, then close up. I do not skip the test step, even when the repair looks simple.

## Overview

The Salstor repair is a project in my knowledge base. Its goal is repair, its area is the boatyard, it started in 2025, it runs in the summer season, and the lead is the plumber.

**Stage.** The project is in the working stage. The go decision has been made and the work is moving step by step. It is not finished, and some parts are still waiting on checks.

**What is done.**

- The go decision was made and recorded.
- The lead, the area and the season were fixed.
- The setup for access, tools and records is in place.
- The main risks were listed and are being watched.

**Open points.**

- The result of the next action, NX-0736, is still to be recorded.
- I still need to confirm that the replacement parts match the old fittings.
- The test plan needs to be written down in a short form the plumber agrees with.
- It is not yet settled how much of the old pipework will be reused.

**Next action.** NX-0736, as noted above. Once that is complete I will update this overview and move the finished items from open points to done.

This note is a summary, so it should stay short enough to read in a minute or two. The details sit in the other sections and in the project log, and I try not to duplicate them here more than needed.

## Maintenance

This section is about keeping the note and the project in good order after the main work is finished, and while it is still running.

**Keeping the note current.** I review this summary after each work session. I change the stage if it has moved, tick off what is done, and add or remove open points. If the next action changes, I replace it at once so the note never points at an old step.

**Keeping the repair in good order.** Once the repair is complete, I want a simple routine:

- Look over the repaired section at the start of each summer season.
- Check joints for damp, drips or staining.
- Test the section again after any heavy use or after a long idle period.
- Replace worn seals before they fail, not after.

**Learning from the work.** When the project closes, I will write down what went well, what slowed us down and what I would do differently. I will compare it with [[Brunbaedos heat exchanger 2024]] and [[Zobanfond greenhouse notes]] to see whether the same problems come up again. If they do, I will turn them into a short checklist for future repairs.

**Handover.** If someone other than the plumber needs to take over, they should be able to read this note, the project log and the photos, and understand the state of things. That is the standard I hold my notes to.

**Closing the project.** The project can be closed when the next action list is empty, the pressure test has passed, the records are complete, and the plumber agrees the repair is finished. At that point I mark the stage as complete and archive the note.
