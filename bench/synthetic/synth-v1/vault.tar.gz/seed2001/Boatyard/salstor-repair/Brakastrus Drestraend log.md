---
type: log
status: active
project: salstor-repair
area: boatyard
---

# Brakastrus Drestraend log

## Costs

Brakastrus Drestraend is an inspector who works in the boatyard. I have known him since 2010. He does not charge me a standing fee, but each inspection job is priced separately, so I keep a running list of what I have paid and what I have been quoted.

- Inspection visits are priced per job, not per hour.
- Extra charges appear when he has to come back for a second look.
- Travel is never added, because I meet him at the yard.
- Any parts he recommends are bought separately and are not part of his price.

I note costs here so I can compare one job with the next. When a job runs over, I write down the reason beside the figure. Most overruns come from hidden rot found late, or from a repair that turns out bigger than first thought. His price usually covers the survey and a short written summary. It does not cover repairs or follow-up work done by other people.

I try to keep a small reserve for surprises. A boat always finds something to spend money on, and an inspection often finds it first. If the reserve is untouched after a job, I leave it for the next one.

## Setup

The subject of this log is Brakastrus Drestraend. These are the facts I keep on him:

- Role: inspector
- Area: boatyard
- Contact: in person
- Availability: weekends
- Known since: 2010

Because he is reached in person, there is no phone number or address to keep. I go to the boatyard on a weekend and find him there. That is the whole setup. If I arrive on a weekday, he is usually not around, so I do not plan weekday visits.

Before each visit I prepare a short list of what I want looked at. I bring the boat's maintenance notes, my own photos of anything odd, and a clear idea of the question I want answered. A vague request gets a vague answer, and he has little patience for it. A specific question, such as whether a soft patch near a fitting is a real problem, gets a straight reply.

I also make sure the boat is accessible. That means the cover is off, the lockers are emptied, and the bilge is reasonably clean. An inspector cannot judge what he cannot see, and arriving with everything ready saves time for both of us.

## Risks

The main risk is timing. He is available on weekends only, and I can only reach him in person. If I miss a weekend, the next chance is a week away. For anything urgent, such as a leak or damage after a storm, that delay could matter.

Other risks I keep in mind:

- A verbal opinion is easy to forget or misremember, so I write it down straight after.
- He may be busy with other owners, so I could wait a long time at the yard.
- An inspection only covers what is visible on the day. Hidden faults can stay hidden.
- Relying on one person is a weakness. I have known him since 2010 and trust him, but a second opinion is sensible for large decisions.
- Because there is no written contact route, I cannot confirm a visit in advance.

To reduce these risks, I go early on a Saturday when possible. That leaves Sunday as a backup if I cannot find him. I also keep my own checklist so that I do not depend on his memory of earlier visits. If a problem could get worse quickly, I take temporary measures first and then wait for the weekend rather than leave it untouched.

## Tools

I do not need much to work with him, but a few things make each visit smoother.

- A notebook and pen, since I record what he says on the spot.
- A phone camera for photos of any defect he points out.
- A torch with a strong beam for dark corners and the bilge.
- A small mallet or tapping tool, which he sometimes uses to check for hollow sounds in laminate.
- A moisture meter, if I can borrow one from the yard.
- My own folder of maintenance records and earlier notes.

I keep these in one bag so I can pick it up and go on a Saturday morning. The bag stays near the door. After each visit I put the notebook page into the folder with the boat's records, so everything about a job stays together.

I do not use any special software for this. Plain notes are enough, and this log is where I collect the longer thoughts afterward. Photos get a short caption the same day, because I forget which photo shows which fitting within a few days.

## Open questions

There are a few things I still do not know about working with Brakastrus Drestraend.

- Does he keep his own written records of the inspections he does for me, or only what I write?
- Would he be willing to give a short written summary after each visit?
- Is there a way to book a time at the boatyard, rather than just turning up?
- How does he decide what to charge for a job? It seems to depend on size and difficulty, but I have never asked directly.
- What does he do on weekdays? I assume other work, but I have never checked.
- Can he look at a boat that is not in the boatyard, for example on a mooring?

I plan to ask the first three at the next visit. The pricing question is more awkward, so I will bring it up when a quote is being discussed. The others can wait until a quiet moment. I will record his answers here, under the matching question, so the list shrinks over time.

## Ideas

Some ideas to make this working relationship better:

- Agree on a standard visit routine, so each inspection covers the same points in the same order.
- Ask him to initial a simple checklist, giving me a lightweight written record.
- Plan a yearly inspection at the same time each season, so it is not left until something breaks.
- Bring a second owner along, so the cost of a visit can be shared when two boats need checking.
- Keep a photo log for each boat, sorted by area of the hull, so changes over time are easy to see.
- Offer him a simple thank-you at the end of the season. He has helped me for a long time, and a small gesture is fair.

None of these is urgent. The checklist idea seems the most useful, because it fixes the biggest gap, which is the lack of a written record. I will try it at the next weekend visit and see whether he is happy with it.

## References

These are the things I refer back to when I look at this log:

- My own maintenance notes for the boat, kept in the folder.
- Earlier entries in this log about past visits.
- The photos taken at each inspection, with captions.
- The boatyard's general rules about work on site and who may do repairs.
- Any receipts from repairs done after he advised them.

I have known Brakastrus Drestraend since 2010, so the oldest notes about him go back a long way. Some of the early ones are brief and say little more than what he found. The newer ones are better because I now write down the question, the answer and the follow-up. When I need to remember how an old problem was handled, I start with the photos and then read the matching notes.

I do not use outside sources for this note. It is a personal record of one person and my dealings with him.

## Quotes

The most recent quoted price of Brakastrus Drestraend: 4243.82 EUR.

That figure was for a larger piece of work rather than a routine look. I record the quote exactly as given so that I can compare it with the final bill later. A quote is not a promise, and I treat it as a starting point.

Things I check when I get a quote:

- What exactly is included, such as survey only or survey plus a report.
- Whether repairs are part of the figure or separate.
- Whether a second visit is covered.
- Whether the price depends on what he finds once the work begins.

If the final bill differs from the quote, I write the difference and the reason in the Costs section. Over time this shows me how reliable his estimates are. So far, I would say his figures are fair, and the biggest changes came from surprises in the boat itself, not from a change in how he priced the job.

I also write down what he says in person about a quote, since there is no written message to look back at. A short note beside the figure is enough.

## Schedule

He is available on weekends, and I reach him in person at the boatyard. That sets the whole schedule.

My usual pattern:

- Early in the week, I decide what needs looking at.
- Midweek, I prepare the list of questions and gather photos.
- Saturday morning, I go to the boatyard and look for him.
- Sunday is the backup if I miss him on Saturday.
- After the visit, I write up the notes the same day.

Because I cannot book ahead, I leave some slack around each visit. I do not plan anything tight afterward, since waiting is common. If a job needs more than one visit, I try to arrange the next one before leaving, so that we agree on a weekend face to face.

For regular checks, I aim for one inspection each season. That means a visit before the main sailing period, one after it, and an occasional extra when something changes. Winter lay-up is a good time to look at the hull, since the boat is out of the water and easy to reach.

If a weekend is lost to bad weather, I move the visit to the next one and make a note so the delay is clear in the log.

## Safety

Work at a boatyard has its own hazards, and an inspection puts me close to them. I keep a few habits.

- Wear sturdy shoes with good grip, because yard surfaces are often wet, oily or uneven.
- Keep clear of boats on stands or cradles unless I know they are properly supported.
- Never stand beneath a hull being lifted or moved.
- Use a ladder that is secured, and ask someone to hold it if needed.
- Wear gloves when touching old fittings, sharp edges or damaged laminate.
- Use eye protection if tapping, scraping or grinding is going on nearby.
- Do not go into the bilge or a closed space alone.

Brakastrus Drestraend knows the yard well and often points out a hazard before I notice it. I follow his advice on where to walk and where to stand. If he says to stay back from something, I do so without argument.

I also tell someone where I am going when I visit on a quiet weekend, since few people are about. A phone in my pocket is a simple safeguard, even though I do not use it to reach him. Safety comes before any inspection, and a job can always wait for another weekend.
