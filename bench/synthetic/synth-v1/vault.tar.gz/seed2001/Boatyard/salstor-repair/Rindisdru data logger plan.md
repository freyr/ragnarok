---
type: plan
status: active
project: salstor-repair
area: boatyard
---

# Rindisdru data logger plan

## Observations

The Rindisdru data logger is a yellow data logger that sits in the barn. It belongs to the boatyard side of things. It runs on battery, and it has been there since 2019. That is the whole set of facts I need to keep in mind: kind is data logger, color is yellow, energy source is battery, year installed is 2019, location is barn.

The plan here is to keep the logger useful and cheap to run for the next few seasons. I want to write down what I see when I check it, so I can tell the difference between a normal quirk and something that needs fixing.

What I notice most often:

- The yellow case is faded on the side that faces the barn door, but it is still intact.
- The battery is the weak point. When the barn gets cold, the readings start to drop out before the battery is actually empty.
- The logger picks up the barn temperature swings well. It shows the slow cooling at night and the quick warm-up when the doors open in the morning.
- Readings from the corner near the wall look steadier than readings from the middle of the barn.
- Damp days leave a thin film on the case, which wipes off easily.

I compare the readings against my older notes in [[Nulur data logger log]]. That log is where I keep the raw impressions after each visit. This plan is only for decisions, so I keep the day-to-day detail there.

## Supplies

I keep a small box for the logger so I do not have to hunt for things in the barn. The box stays on the shelf next to the logger.

What goes in the box:

- Spare batteries of the right type, kept in their packaging until needed.
- A soft cloth for wiping the case.
- A small screwdriver for the battery cover.
- A roll of tape and a marker for labelling the date on a fresh battery.
- A notebook page, folded, with the steps for swapping the battery.
- Zip ties for holding the cable or mount if it loosens.

Rules I follow for supplies:

1. Never let the spare batteries run down to the last two. Reorder when I reach three.
2. Keep the spares indoors in winter, not in the barn, because the cold shortens their life.
3. Throw out any battery that has a swollen or leaking case.
4. Replace the cloth once a year, since it picks up grit from the boatyard.

I also want a dry bag or a small sealed tub for the spare cover and the cable, in case the barn roof leaks again.

## History

The logger was installed in 2019 in the barn. At the time the idea was simple: get a record of how the barn behaves through the year, so I could decide where to store sensitive gear and when the boatyard work could safely go ahead inside.

Since then, a few things have happened that shaped the plan:

- The first couple of years ran without trouble. I only changed the battery when readings stopped.
- Later I started noticing the cold-weather dropouts and began swapping batteries before winter.
- I moved some notes about the loft area into [[Gundstios loft notes]], since the loft readings and the barn readings were being confused with each other.
- I also compared the way the barn holds heat with what I learned in [[Brunbaedos heat exchanger 2024]], because the heat exchanger project made me think harder about how warmth moves through the buildings.
- The storage question for the upper space led me to [[Sebon loft]], where I keep the layout and what is stored there.

The logger itself has not been moved since 2019. That is deliberate. Moving it would break the comparison with the older readings, so I want it to stay where it is unless there is a strong reason.

## Maintenance

Maintenance is mostly about the battery and the case. The logger is simple, so the routine is short.

Monthly:

- Look at the logger and check that it is still recording.
- Wipe the yellow case with the dry cloth.
- Look at the mount and make sure it has not shifted.

Before winter:

- Swap in a fresh battery, and write the date on the tape.
- Check the battery cover seals well.
- Note the readings in [[Nulur data logger log]] so I have a clean starting point.

After winter:

- Check for damp inside the cover.
- Compare the readings from the cold weeks with the warmer ones, to see if there were dropouts.
- Decide whether the battery should be changed earlier next year.

Things I should not do:

- Do not open the case more than needed.
- Do not use a wet cloth near the battery area.
- Do not move the logger without writing down why.

If the dropouts get worse, my next step is to try a different battery brand before replacing the whole logger. If that does not help, I will start looking at a replacement for the same spot in the barn.

## Parts

The main thing to know for ordering is the part number of the Rindisdru data logger: XB-6329-P. I use this when I look for a replacement or ask someone about compatibility.

Other parts I track, without separate numbers:

- Battery: the one type the logger takes, kept as spares.
- Battery cover: the small cover that screws on, which is the part most likely to wear.
- Mount: the bracket or ties holding the logger in place in the barn.
- Cable: only if I connect the logger to read out the data.

If I need to replace anything, I will check that it matches the part number above first. For the small items, I can usually match them by looking at the old one. I keep one spare cover if I can, because a damaged seal lets in damp quickly.

## Costs

I do not want to tie exact prices into this note, because they change and I would only have to correct them. Instead I note the kinds of cost and how I think about them.

Regular costs:

- Batteries, bought a few at a time, which is the main running cost.
- Cloth and tape, which are very small.

Occasional costs:

- A new battery cover or mount if the old one wears out.
- A replacement logger if the dropouts cannot be fixed.

How I decide:

1. If a battery change fixes the problem, that is always the cheapest answer.
2. If a part fails, I replace the part before the whole device.
3. If the logger fails entirely, I weigh the cost of a new one against how much I still value the continuous record since 2019.

The record is the real value here. A new device would be cheap compared with losing years of comparable barn readings, so if I replace it, I will plan the changeover carefully and run both for a while.
