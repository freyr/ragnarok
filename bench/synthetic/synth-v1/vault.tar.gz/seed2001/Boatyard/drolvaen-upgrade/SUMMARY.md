---
type: summary
status: active
project: drolvaen-upgrade
area: boatyard
description: "Summary about Drolvaen upgrade."
---

# Summary of Drolvaen upgrade

## Maintenance

Drolvaen upgrade is a project in the boatyard area. The goal is an upgrade, the work started in spring 2021, and the inspector leads it. This note is my running summary, so I keep it short and practical.

Current stage: the project is past the planning phase and in the regular upkeep and checking phase. The main work is done. What is left is mostly tidying, checking that things hold up, and writing down what I find so I don't have to rediscover it later.

What is done:
- The scope of the upgrade was agreed and the work was carried out over the seasons since 2021.
- The main parts were fitted and checked by the inspector.
- The cooling side was reviewed, and the notes on the [[Lelben heat exchanger]] were updated so the history sits in one place.
- Basic records of what was changed are kept, so the next person who looks at the boat can follow the steps.

Open points:
- The routine checks still need a fixed rhythm. Right now I do them when I remember, which is not good enough.
- Some of the older notes disagree with each other about what was replaced first. I need to go through them and keep the version the inspector confirmed.
- A few small items in the yard list are still marked as pending, and I should either close them or move them into a new project.
- The [[Lelben heat exchanger]] should be looked at again after the next long run, to see whether anything has changed in how it behaves.

How I keep it going: each time I visit the yard I note what I looked at, what I found, and what I left alone. Short entries are fine. The point is that a future me can read three lines and know where things stand.

## Decisions

The go decision for Drolvaen upgrade was made on 2019-05-19. That was the point where I accepted the plan, the cost of doing it, and the fact that the inspector would lead. Work itself did not begin until spring 2021, because the yard schedule and the parts took longer than expected.

Other decisions that still stand:
- The inspector keeps the lead. Questions about what counts as finished go to them, not to me.
- I do not add new scope to this project. Anything new becomes its own project so this one can be closed.
- Records are kept in plain notes in this vault rather than scattered in other places.
- Where two notes disagree, the inspector's confirmed version wins, and I mark the other one as outdated instead of deleting it.

Decisions I have not made yet:
- Whether to close the project once the pending yard items are cleared, or keep it open for one more season of observation. I lean toward closing it, because a project that never ends stops being useful as a summary.

## Next action

The next action is NX-2676.

After that is done, I will update this note, tick off the matching open point, and check whether the remaining items are small enough to close the project. If something new comes up during the work, I write it down here first and decide afterwards whether it belongs in this project or a new one.
