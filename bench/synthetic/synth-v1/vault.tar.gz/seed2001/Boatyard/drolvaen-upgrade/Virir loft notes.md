---
type: note
status: active
project: drolvaen-upgrade
area: boatyard
description: "Note about Virir loft."
---

# Virir loft notes

## Costs

Virir loft is cheap to keep, but not free. I have no figures I trust, so this section describes where the money goes without quoting amounts.

The biggest cost is moisture control. The loft is below ground, so damp is the constant enemy. The recurring spending is on dehumidifier running time, replacement filters, and sealing products for the walls and the hatch frame.

The second cost is lighting and power. The loft faces west, but being below ground it gets almost no daylight, so everything is lit artificially. I looked at running a small solar supply for the lights. The reasoning is in [[Daeszes solar charger]] and [[Fustrul solar charger study]]. In short, the loft is too deep and too shaded to charge anything itself, so any panel would have to sit elsewhere in the boatyard and feed a cable down.

The third cost is my time. A small space still needs regular visits, and each visit means going down, checking the walls, emptying the water tray, and wiping surfaces.

Costs I have decided to accept:

- Filters and sealing materials, bought when needed rather than stocked heavily.
- Cable and fittings for any lighting changes.
- Replacement of shelving that rusts or swells.

Costs I have decided to avoid:

- Large equipment that does not fit through the hatch.
- Anything that needs a permanent water connection.
- Fancy storage furniture that will not survive the damp.

## Open questions

These are things I still do not know about the loft. I write them down so I stop re-asking them from scratch every few months.

- Where exactly does the damp enter? The west wall is my main suspect, but the floor joint near the corner could also be the source. I have not proven either.
- Does the humidity change much between the dry months and the wet months? I have only a few readings, and I need a proper series before I can say anything about seasons.
- Is the ventilation I have actually moving air, or only making a draught near the hatch? The far end of the loft may be stagnant.
- Would a small heat exchanger help? [[Fothzin heat exchanger 2021]] describes a trial elsewhere, but the loft is small and the airflow numbers may not scale down.
- Can the valve I use for the drain line be automated safely? I started thinking about this in [[Rirklaerk valve actuator notes]], but I have not decided whether automation is worth the extra failure points.
- Who else in the boatyard has a below-ground space, and do they see the same damp pattern? [[Polguthgul Feskion]] might know, since they have worked on several of the older structures.
- Is the 2018 construction detail good enough, or was there a skipped membrane layer behind the west wall? I cannot find a drawing.

## References

Links and notes I rely on when I think about this loft. Each one has something specific to contribute.

- [[Daeszes solar charger]]: the charger I considered for powering low-draw lights and a sensor. Useful for the sizing logic, even though I did not install it in the loft.
- [[Fustrul solar charger study]]: a longer look at charging in shaded places. The main lesson is that panels need to be outside and cables need to be protected.
- [[Rirklaerk valve actuator notes]]: notes on motorised valves, relevant to the drain and any water handling.
- [[Fothzin heat exchanger 2021]]: a record of a heat exchanger trial. I use it as a reference for how airflow and temperature differences behaved in a damp, enclosed space.
- [[Polguthgul Feskion]]: a person and contact I go to for advice about boatyard structures and what has worked for others.
- [[Sogionvin Stilstur tests]]: the test notes I use as a template for how to log checks, so that readings are comparable from visit to visit.

Outside the vault I only keep a paper folder of the original build papers for the loft. It is incomplete, which feeds into the open questions above.

## Risks

The main risks follow from the loft being below ground in a boatyard.

**Damp and mould.** This is the top risk. Anything porous stored there can go bad: rope, canvas, cardboard, paper. Once mould starts on a surface it spreads quickly in still air.

**Corrosion.** Boatyard air carries salt and fine grit. Combined with damp, bare metal tools rust faster here than anywhere else I store things.

**Flooding.** A below-ground space can take on water after heavy rain or a drain backing up. The loft is small, so even a shallow flood reaches everything on the floor.

**Poor air.** A small enclosed space with weak ventilation can build up fumes from paints, solvents, or fuel residue. This ties into the Safety section.

**Electrical faults.** Wet conditions and mains power do not mix well. Any plug, extension lead, or lamp that I leave down there is a risk if it is not rated for damp.

**Access.** A hatch or narrow stair is a risk when carrying loads. A fall while holding something heavy would be bad, and nobody may hear me.

**Neglect.** The biggest practical risk is that I stop checking. A loft I visit every week stays fine. A loft I forget for a season may be ruined.

Mitigations are mostly simple: raise everything off the floor, use sealed boxes, check the water tray, and keep a routine.

## Lessons

What I have learned so far from keeping things in Virir loft.

1. **Raise everything.** Nothing should sit directly on the floor. Even a small gap lets air move under boxes and keeps the bottom layer dry.
2. **Sealed boxes beat open shelves.** Open shelving looked tidy, but the contents picked up damp. Lidded plastic boxes with a desiccant pack did much better.
3. **Label by content and by date of last check.** If I cannot see when I last opened a box, I tend to assume it is fine.
4. **Take readings the same way each time.** The method in [[Sogionvin Stilstur tests]] works: same spot, same height, same waiting time before reading the sensor.
5. **Do not trust a single number.** One humidity reading tells me little. A run of readings tells me a lot.
6. **Small spaces change fast.** Opening the hatch for a short while changes the air noticeably, so I let things settle before measuring.
7. **Do not over-engineer.** My first plans involved automation and charging systems. Most of the benefit came from a plain dehumidifier and a tidy layout.
8. **Ask people who have done it.** A short chat with [[Polguthgul Feskion]] saved me from buying a sealant that does not work on damp masonry.

The common thread is that routine and simple measures beat clever equipment in a place like this.

## History

The loft was built in 2018. It was added as a small below-ground space in the boatyard, with its main wall facing west. I did not oversee the building, so most of what I know comes from the folder of papers and from what others told me.

In the first years it was used mostly as dry storage for spare parts and offcuts. Nobody measured the air, and the damp showed up only as a smell and some spotting on the lower wall.

Later I took over regular use. The first thing I did was clear the floor and look at the walls properly. I found tide-like marks low on the west wall, which pointed to moisture coming through the masonry rather than through the hatch.

After that I tried a few changes, one at a time:

- A portable dehumidifier with a drip tray that I empty by hand.
- Raised shelving made from materials that tolerate damp.
- A simple routine of visits and readings, set up following [[Sogionvin Stilstur tests]].
- A look at heat exchange for airflow, prompted by [[Fothzin heat exchanger 2021]].
- A look at solar power for lighting, written up in [[Daeszes solar charger]] and [[Fustrul solar charger study]].

None of these changed the basic character of the place. It is a small, below-ground loft in the boatyard, built in 2018, and it stays damp unless I work at keeping it dry.

## Ideas

Ideas I may try, in rough order of how likely they are.

- **Better drainage for the dehumidifier.** Instead of emptying a tray by hand, run a small hose to a drain. This would need a valve, which links to [[Rirklaerk valve actuator notes]]. I would keep it manual at first.
- **A low-power sensor with a visible indicator.** A small light by the hatch could show green, amber, or red depending on the humidity, so I can tell from outside whether to go down.
- **Cable run from outside for lighting.** Rather than charging anything in the loft, put the panel on a sunnier roof in the boatyard and bring power down, as discussed in [[Fustrul solar charger study]].
- **Passive airflow.** A small vent pair, one low and one high, may move air without any power. I want to test this before adding fans.
- **Wall treatment on the west side.** If I can confirm the damp comes through that wall, a breathable coating might help more than sealing it.
- **Zones.** Split the loft into a driest zone for sensitive items and a rougher zone for tools and offcuts.
- **A shared log.** Put all readings in a single table in the vault so I can see trends.
- **Ask for a second opinion.** A conversation with [[Polguthgul Feskion]] about the wall construction could answer one of my open questions.

I will not buy anything big until I have a longer series of measurements.

## Tools

The tools I keep for the loft are chosen to be small, simple, and tolerant of damp.

**Measuring**

- A hygrometer that shows humidity and temperature. I leave it at the same position on the middle shelf.
- A torch with a strong beam for looking at the corners and the wall base.
- A tape measure for checking shelf heights and gaps.

**Moisture control**

- A compact dehumidifier with a removable water tray.
- Desiccant packs for the sealed boxes.
- A squeegee and cloths for wiping surfaces after a wet spell.

**Maintenance**

- A stiff brush for the wall base and the floor edge.
- A small bottle of rust inhibitor and a rag.
- A bucket for the tray water.

**Access**

- A sturdy step stool for the high shelf.
- A headlamp, so both hands are free on the stair.

**Logging**

- A notebook and pen kept in a sealed bag at the hatch.
- The vault note template based on [[Sogionvin Stilstur tests]].

I do not keep power tools in the loft. If I need one, I bring it down for the job and take it out again.

## Safety

Safety in Virir loft is mostly about air, power, water, and getting in and out.

**Air.** The loft is small and below ground, so I do not use solvents, fuel, or strong cleaners there without opening the hatch fully and leaving it open. I do not stay down for long when I am working with anything that has a smell.

**Power.** Everything electrical should be rated for damp conditions. I check cables for cracks before I use them. I keep the dehumidifier plug off the floor. If I ever add a supply from outside, as in [[Fustrul solar charger study]], the cable should be protected and the circuit should have a trip device.

**Water.** If there is standing water on the floor, I do not go in with the power on. I switch off first, then deal with the water.

**Access.** I do not carry heavy loads down alone. I use both hands on the stair when I can, and I pass items down in stages.

**Telling someone.** If I will be down for a while, I tell someone in the boatyard. A small space below ground is not a place to have an accident unnoticed.

**Fire.** I keep flammables to a minimum and away from the dehumidifier. A small extinguisher sits near the hatch, not inside the loft.

**Mould.** I wear a mask when cleaning mould, since the spores are not good to breathe.

## Measurements

The loft's basic properties are listed here with the humidity reading I rely on.

| Property | Value |
|---|---|
| Kind | loft |
| Area | boatyard |
| Orientation | west |
| Size | small |
| Year built | 2018 |
| Floor | below ground |

Measured humidity of Virir loft: 49.03 %

That reading is moderate for a below-ground space. It was taken at the usual spot on the middle shelf, after I had closed the hatch and let the air settle. I treat it as one reading, not a rule.

Notes on how I measure:

- Same position every time, on the middle shelf, away from the wall.
- Wait a short while after closing the hatch.
- Write down whether the dehumidifier was running.
- Note the weather outside, since heavy rain shows up in the readings later.

I have not recorded dimensions of the loft in this note beyond calling it small. If I want precise sizes for shelving plans, I will measure and add them in a separate note, but I do not need them for day-to-day use.

## Observations

Things I have noticed from visits, without trying to explain all of them yet.

- The west wall is the coolest and feels the dampest to the touch. The loft faces west, and that side shows the most staining low down.
- The air near the floor feels heavier than the air near the top shelf. I think moisture settles low, which is another reason to keep things raised.
- Right after I open the hatch, the air changes. A short while later it settles back to something close to the earlier state, so the space seems to hold its own climate quite well.
- Metal items on the lowest shelf rust first. Items in sealed boxes on the upper shelf stay clean.
- The dehumidifier tray fills faster after wet weather outside, which suggests the damp responds to the boatyard conditions rather than only to seepage through the wall.
- The corner near the stair has a slightly stale smell. I want to test airflow there.
- Light is a problem. Because the loft is below ground, I rely entirely on lamps, and shadows hide the wall base where I most need to see.
- Visits that follow the checklist go faster and catch more problems than casual visits.

These observations feed the open questions and the ideas, and I update them when something changes.

## Problems

Current and recurring problems with the loft.

**Persistent damp on the west wall.** The wall stays cool and slightly wet low down. I have not found a fix that lasts.

**Rust on exposed metal.** Even with the dehumidifier, bare tools and fasteners go orange if I leave them out. The answer so far is to keep them in boxes with desiccant.

**Dehumidifier tray.** Emptying it by hand is annoying, and I have forgotten more than once. When the tray is full, the machine stops and the loft drifts damp again. The drain idea in [[Rirklaerk valve actuator notes]] would solve this, but adds complexity.

**Poor lighting.** The lamps I use cast hard shadows. I would like a better arrangement, possibly with power from outside as in [[Fustrul solar charger study]].

**Unknown construction detail.** Because I cannot find a clear drawing from 2018, I do not know what is behind the west wall. That makes any wall treatment a guess.

**Stale air at the far end.** Air does not seem to move there. Without ventilation, anything stored at that end is at more risk.

**Inconsistent logging.** I have gaps in my readings, mostly when I am busy. The gaps make trends hard to see.

**Access.** Carrying anything bulky down is awkward. It limits what I can store and means large items stay out.

## Overview

Virir loft is a place. Its properties, stated exactly:

- Kind: loft
- Area: boatyard
- Orientation: west
- Size: small
- Year built: 2018
- Floor: below ground

It is a small loft in the boatyard that faces west and sits below ground, built in 2018. The name suggests height, but it is below ground, so I think of it as a cellar-like store that happens to be called a loft.

I use it for dry storage of parts, offcuts, and tools that do not mind a cool environment, as long as they are boxed and raised. The main challenge is damp, which comes mostly from the west side and from the general conditions underground in the boatyard.

My routine is simple: visit regularly, take a humidity reading in the same spot, empty the dehumidifier tray, wipe wet surfaces, and note anything odd. Readings and observations go in this note and in related ones, such as [[Sogionvin Stilstur tests]].

For power and lighting ideas, I look at [[Daeszes solar charger]] and [[Fustrul solar charger study]]. For drainage and valves, I look at [[Rirklaerk valve actuator notes]]. For airflow and heat, I look at [[Fothzin heat exchanger 2021]]. For advice from someone who knows the structures, I talk to [[Polguthgul Feskion]].

The aim is modest: keep the loft dry enough that what I store there survives.

## Supplies

What I keep stocked for the loft, and what I buy only when needed.

| Item | Purpose | Stock approach |
|---|---|---|
| Desiccant packs | Keep sealed boxes dry | Keep a spare set |
| Lidded plastic boxes | Protect stored items | Buy as needed |
| Dehumidifier filters | Keep the machine working | Keep one spare |
| Rust inhibitor | Protect bare metal | Small bottle on hand |
| Cloths and squeegee | Wipe wet surfaces | Keep at the hatch |
| Masks | Mould cleaning | Keep a small box |
| Notebook and pen | Logging readings | Keep in a sealed bag |
| Spare bulbs or lamps | Lighting | One spare |

Other supplies:

- Cable ties and clips for keeping leads off the floor.
- Labels and a marker that works on damp plastic.
- Bags for waste and for items that need to go out for cleaning.
- A small first aid kit near the hatch, outside the loft.

Supplies I do not stock:

- Solvents and fuels, because of the air and fire risks.
- Large quantities of paper or card, which turn bad quickly.
- Anything that needs a permanent power supply.

Before each visit I check that I have a spare filter, enough desiccant, and cloths at the hatch. If something is running low, I add it to the shopping list rather than trusting that I will remember.
