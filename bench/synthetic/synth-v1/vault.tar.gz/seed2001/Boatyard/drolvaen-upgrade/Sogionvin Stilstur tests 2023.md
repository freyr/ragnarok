---
type: research
status: archived
project: drolvaen-upgrade
area: boatyard
description: "Research about Sogionvin Stilstur."
---

# Sogionvin Stilstur tests 2023

## Risks

This note is archived. It records what I knew in 2023, and later notes replace its values. Do not rely on it for anything current.

- Sogionvin Stilstur is reachable by phone only. If the phone goes unanswered, there is no fallback channel in my records.
- Availability is weekends. Anything urgent that comes up during the working week has to wait, which matters for boatyard deadlines.
- The quoted price below was a single quote. I never compared it with a second accountant, so I cannot say whether it was fair.
- The "known since" value is 2024. Because it is so recent, I have little track record to judge reliability by. Treat any impression in this note as provisional.
- I did not write down what the quote covered in detail. A later note should confirm the scope before anyone assumes it was a full-year service.

## Overview

Sogionvin Stilstur is an accountant who works in the boatyard area. I wrote this note as a research file so I would not have to rebuild the basics each time I wanted to ask about bookkeeping for boat work.

The properties as recorded:

| Property | Value |
|---|---|
| Name | Sogionvin Stilstur |
| Role | accountant |
| Area | boatyard |
| Contact | phone |
| Availability | weekends |
| Known since | 2024 |

In practice this means I plan around the weekend. I gather my receipts, invoices and questions during the week, then make one phone call instead of several short ones. That has worked better than leaving scattered messages, because the phone is the only contact method I have.

What I wanted from the research was simple:

- someone who understands how a boatyard bills for labour, storage and materials
- someone who can explain the figures in plain language
- someone I can reach without a long wait

Sogionvin Stilstur fits the first and third points on paper. The second I could only judge after more conversations, so it stays open in this archived record.

A small contact record I kept alongside the research, copied here as a reference:

```yaml
person: Sogionvin Stilstur
role: accountant
area: boatyard
contact: phone
availability: weekends
known_since: 2024
status: archived-research
```

I keep this block short on purpose. If any value changes, the newer note wins and this one stays as it was.

## History

The research was written as a snapshot of 2023. The sequence below is how I remember it, kept loose because I did not log exact days.

First came the need. I had mixed boatyard paperwork building up and no clear person to hand it to. I wanted a specialist rather than a general bookkeeper, since the boatyard side has its own habits: part payments, seasonal work, and invoices that arrive late.

Next I collected a short list of questions to ask:

- How do you want receipts delivered?
- What do you need from me before a weekend call?
- How do you handle work that spans two tax years?
- What is your quote for a basic engagement?

The conversation happened by phone, because that is the contact method I was given. The weekend availability shaped everything: I could not simply ring on a convenient weekday, so I prepared notes in advance and kept the call focused.

The "known since" value is 2024, and I have kept that value as stated rather than adjusting it to match the title of this note. It reflects when the relationship is counted from, not how long I spent on this research.

After the call I wrote down the quote and a few impressions, then archived the note. I did not revisit it. Later notes carry updated details about the same person, and if they disagree with this page, they are correct.

Lessons I took from this round of research:

- Ask for the quote scope in writing, or at least write it down during the call.
- Do not leave the question of backup contact until later.
- Keep the research note separate from any ongoing working notes, so the archive stays clean.

## Quotes

The only figure I recorded was the quoted price of Sogionvin Stilstur: 676.12 EUR.

I noted it right after the phone call and did not negotiate. A few remarks to keep with it:

- It was a quote, not an invoice. Nothing was paid on the strength of this note.
- I did not record what period or workload it covered, so it should not be compared to later quotes without checking the scope.
- The price belongs to the 2023 state of this note. If a newer note lists a different amount, use the newer one.

One line I wrote down from the call, paraphrased from memory: the accountant preferred to go through everything in one sitting at the weekend rather than in pieces. I took that as a sign of a tidy working style, though it is only an impression.
