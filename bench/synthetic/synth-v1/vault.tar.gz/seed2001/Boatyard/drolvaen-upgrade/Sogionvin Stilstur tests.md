---
type: research
status: active
project: drolvaen-upgrade
area: boatyard
description: "Research about Sogionvin Stilstur."
---

# Sogionvin Stilstur tests

## Ideas

This note collects my trial runs with Sogionvin Stilstur, the accountant I use for boatyard paperwork. I have known Sogionvin since 2024. The contact method is phone, and the availability is weekends. Those two facts shape every test below, because I cannot just send a message and expect an answer on a Tuesday afternoon.

Here are the ideas I wanted to try:

- Batch my questions into one list before each weekend call, so the call stays short and nothing gets forgotten.
- Send a plain summary of receipts a day ahead, so Sogionvin can look at it before we talk.
- Keep one running page of open questions, and cross out each one when it is answered.
- Test whether a fixed weekend slot works better than agreeing a time each week.
- Try reading figures aloud from my own sheet during the call, instead of describing them loosely.
- Check whether the data from the [[Rindisdru data logger plan]] could help with the boatyard's usage records, for example running hours for equipment that gets billed by use.

The last idea is still a guess. I wrote it down because the logger plan might give me cleaner numbers to hand over, and cleaner numbers mean shorter calls.

## Problems

The main problem is timing. Phone contact on weekends sounds simple, but my own weekends fill up quickly. When I forget to prepare, the call turns into a slow back-and-forth where I look for papers while Sogionvin waits.

Other problems I ran into during the tests:

- A phone call leaves no written trace. I have to write the answer down myself, and if I am busy I lose details.
- Some boatyard costs are hard to sort. A repair can be a business expense, a part of a client job, or something that belongs elsewhere. I did not always know which, and I did not describe the case well enough on the phone.
- Receipts that I had photographed badly were useless. A blurred total cannot be discussed.
- When I missed a weekend, the next question waited a full week. That delay matters when a deadline is close.
- I tend to start a call with the least important question, because it is the easiest one to explain.

None of these is about Sogionvin's skill. They are about how I prepare. The tests were meant to find out which habits on my side reduce the friction.

## Tools

I kept the toolset small on purpose. A phone is the contact channel, so everything else only supports the call.

- A paper notepad next to the phone, used for answers during the call.
- A single spreadsheet with one row per expense and a column for a short description.
- A folder of receipt photos, named by what the purchase was rather than by when I took the picture.
- An Obsidian page for open questions, linked from this note.
- A kitchen timer, which I use to keep myself honest about call length.

I considered a shared document that Sogionvin could read, but I have no sign that this fits the way an accountant working weekends wants to receive things. I might ask, but I did not assume. For now the phone remains the main tool and the rest is preparation.

The [[Rindisdru data logger plan]] is a possible later addition. If the logger works as planned, its output could be a tool for the usage side of the books. That depends on the logger actually being built, so I treat it as an open thread and not as part of the current setup.

## Maintenance

A testing routine only works if I keep it tidy. Here is what I do regularly to keep my side of the arrangement in working order.

Before each weekend:

- Go through the spreadsheet and fill in any empty description cells.
- Re-photograph any receipt that is unreadable while I still have the original.
- Write the question list, with the most urgent question at the top.
- Put the notepad and a pen by the phone.

After each call:

- Copy the answers from the notepad into the open questions page the same day.
- Mark answered questions as done and leave the answer beside each one.
- Note any new task that came out of the call, such as a document to find.

Once in a while I review the whole page and delete what is no longer relevant. I also check that the details I hold about Sogionvin are still right: role accountant, area boatyard, contact phone, availability weekends. If any of these changed, this note would need an update. So far they have stayed the same since I first met Sogionvin in 2024.

## Observations

Over several weekends I noticed a few patterns. The calls that went best were the ones where I had sent a short summary the day before and had my list ready. Those calls were focused, and Sogionvin could answer in a sentence or two and move on.

The worst calls were the ones where I tried to explain a messy situation from memory. Even a patient professional cannot untangle a vague description. When I read the actual figures from my sheet, the answer came quickly.

Other things I noticed:

- A fixed weekend slot worked better than a new arrangement each time. It removed one small decision and made the call feel routine.
- Questions grouped by topic took less time than questions in the order I thought of them.
- Writing the answer in my own words during the call, then repeating it back, caught several misunderstandings.
- Sogionvin seems to prefer clear numbers and short descriptions over long stories. That matches how I would want to work if I were the accountant.
- Because the boatyard has seasonal rhythms, some weekends are far busier for me than others. Calls scheduled in a busy period were rushed and less useful.

I have not measured any of this precisely. These are impressions from using the routine, and I note them as impressions.

## Lessons

The biggest lesson is that preparation is my job, not Sogionvin's. A weekend phone call is a limited resource, and the quality of what I get out of it depends on what I bring.

Lessons I want to keep:

- Prepare a written list. Never improvise a call about money.
- Describe each expense in one plain sentence, and say what it was for.
- Put the hardest question first, while both of us are fresh.
- Write the answers down immediately, because memory fades by Monday.
- Do not leave questions until a deadline is close, since the next chance to ask may be a week away.
- Keep receipts readable from the start. Checking a photo at the moment of taking it costs seconds.
- Treat the arrangement as stable but review it now and then, so small annoyances do not pile up.

A second lesson is about expectations. Because the contact is by phone and the availability is weekends, I should not expect fast answers on weekdays. I now plan my deadlines around that fact and not against it.

## References

These are the things I point back to when I work with this note.

- [[Rindisdru data logger plan]] for the idea of automatic usage records that could feed the books.
- My open questions page, where each weekend's list and answers are kept.
- The expense spreadsheet, which is the single source I read figures from during a call.
- The receipt photo folder, organised by purchase description.

Facts about the subject, kept in one place for easy lookup:

- Name: Sogionvin Stilstur
- Role: accountant
- Area: boatyard
- Contact: phone
- Availability: weekends
- Known since: 2024

I have no outside documents about Sogionvin beyond my own records, so this note is based only on what I have seen myself.

## Quotes

Here I keep the price I was given and a few remarks I wrote down after calls. The remarks are paraphrased from my notepad, not word for word recordings.

The quoted price of Sogionvin Stilstur: 4152.03 EUR

I wrote the price down at once, read it back during the call, and checked that we meant the same scope. I did not want to rely on memory for a figure like this. What I remember about the context is that the price was given as a single figure for the whole piece of work, not as an hourly rate, and that Sogionvin was willing to explain what it covered.

Paraphrased remarks from calls:

- Clear receipts make the work faster and the result more reliable.
- Group the questions, and the call stays short.
- If something is unclear, say so early rather than guess.

I treat the quote as a starting point for discussion. Before I commit, I want to compare it with what the work actually involves, and I will ask for the scope in writing if I can arrange it.

## Costs

Apart from the quoted price, the costs of this routine are small and mostly about my own time. I do not track them to the cent, and I do not want to invent figures I have not measured.

The cost categories I think about:

- The accountant's fee, which is the quoted price described in the Quotes section.
- My time spent preparing before each weekend call, which is the largest hidden cost.
- Phone charges, which are minor but real if calls run long.
- The cost of mistakes, such as a misfiled expense that has to be corrected later.
- A possible future cost for building the logger described in [[Rindisdru data logger plan]], which I have not worked out and which should be judged separately.

The cheapest improvement I found was to prepare better, because that costs only attention. A shorter call means less time for both of us and less chance of an error. If preparation reduces the number of corrections later, it pays for itself. I will keep an eye on whether the total effort feels reasonable compared with the value I receive.

## Overview

This note records my tests of working with Sogionvin Stilstur, an accountant in the boatyard area whom I have known since 2024. Contact is by phone, and availability is weekends. Those properties decide how I plan everything else.

What I tested: batching questions, sending a summary ahead of time, using a fixed weekend slot, reading figures from one spreadsheet, and writing answers down right away. What I learned: the quality of each call depends mainly on my preparation. Clear receipts, short descriptions and a written list make calls quick and useful, while vague explanations from memory waste time.

The quoted price is recorded in the Quotes section, and I intend to check the scope before accepting it. Costs beyond the quote are mostly my own time, and I have not tried to put numbers on them.

Open threads for later:

- Ask whether a written summary in advance suits Sogionvin as well as it suits me.
- Decide whether the [[Rindisdru data logger plan]] is worth pursuing for usage records.
- Review this arrangement again after a few more weekends and update the note if anything changes.
