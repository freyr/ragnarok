---
type: drivers
status: active
project: drolvaen-upgrade
area: boatyard
description: "Drivers about Drolvaen upgrade."
---

# Drivers of Drolvaen upgrade

## History

The Drolvaen upgrade is a project in the boatyard area. Its goal is an upgrade. It started in spring 2021, and the lead is the inspector. I keep this note as the drivers note, so it records why the project exists, what limits it, what it costs and how I decide whether it worked.

The yard had been running for years on a mix of patched-up equipment and habits that grew over time. Nobody planned the old layout. Slipways, sheds and storage were added whenever a need came up. By 2021 the cost of that approach was clear enough that the inspector pushed for a proper upgrade instead of another round of repairs.

The first discussions happened in the cold months before the start. The inspector walked the yard several times and wrote down what was failing, what was unsafe and what was merely ugly. The list was long. The group agreed to separate the items into three piles: things that had to change, things that should change, and things that could wait. The upgrade project took the first pile and part of the second.

Spring was chosen as the starting season on purpose. The yard is quieter before the main work period, and boats are still out of the water or just being prepared. That gave the crew room to open up work areas without blocking paying customers. It also meant the weather was improving, which matters for anything involving concrete, paint or outdoor wiring.

## Observations

Over the first weeks I noticed a few patterns that shape the drivers of this project.

- Most delays in the yard come from waiting, not from slow work. People wait for a tool, a crane slot, a signature or a delivery.
- Safety problems cluster in the same places: wet walkways, poor lighting near the slip, and cluttered storage.
- The inspector's notes are more reliable than anyone's memory. When a question came up, the written walkthrough usually settled it.
- Small fixes done in isolation tend to be undone by the next job. An upgrade only lasts if the surrounding habits change too.
- Crew morale improves quickly when a visible annoyance is removed, even a minor one.

These observations push the project toward fixing flow and safety first, and cosmetic matters last. They also explain why the inspector is the lead: the main driver is a judgement about condition and risk, and that is the inspector's job.

I also noticed that people describe the same problem in different words. One person says the slip is slow, another says the winch is weak, another says the cradle is awkward. They are often describing one underlying issue. Part of my note keeping is to match these descriptions so the project does not pay for the same fix three times.

## References

These are the sources I rely on for this project. They are all informal and internal to the yard.

- The inspector's walkthrough notes from the winter before the start.
- The old yard layout sketch, which is out of date but still useful as a baseline.
- Supplier quotes collected during spring 2021.
- Maintenance logs kept by the crew for the main lifting equipment.
- My own meeting notes, kept in this knowledge base.

I do not treat any of these as final. The walkthrough notes are the strongest source for condition and risk. The quotes are the strongest source for cost, but they age quickly and I check them again before committing money. The maintenance logs show which equipment fails repeatedly, which is a strong argument for replacing it rather than repairing it.

When two sources disagree, I prefer the one written closest to the event and by the person who did the work. I note the disagreement here rather than silently picking a side.

## Setup

The project is organised in a simple way, because the yard does not have spare people for heavy management.

- Goal: upgrade.
- Area: boatyard.
- Start: 2021, in spring.
- Lead: the inspector.

The inspector decides priorities and signs off finished work. The crew does most of the physical tasks, with outside contractors only for jobs that need certification or special equipment. I keep the notes, track the money and report to the lead.

Work is divided into stages so that the yard can keep operating. Each stage has a defined work area, a clear start and a clear finish. Before a stage begins, the area is cleared and marked. After it ends, the inspector walks through and either accepts it or lists what remains.

Communication is kept plain. A short weekly check-in covers what was done, what is blocked and what is next. Anything involving cost or safety goes to the lead the same day.

## Tools

I use only a few tools to run the project, and I try to keep them simple.

- This notes vault, for decisions, drivers and lessons.
- A paper walkthrough checklist carried by the inspector.
- A basic spreadsheet for tracking spending against the budget.
- A photo log, taken before and after each stage, so that results can be compared and disputes settled.
- A shared whiteboard in the workshop for the weekly plan.

For the physical work, the crew uses the yard's existing lifting gear, hand tools and power tools, plus whatever contractors bring. I avoid buying new tools for the project unless a stage cannot be done safely without them. Borrowing or hiring is usually cheaper than owning, particularly for equipment used only once.

The photo log has been the most useful tool so far. It costs nothing, it takes seconds, and it removes arguments about what a place looked like before.

## Ideas

These are options I have written down. None is committed unless it appears in the checklist.

- Group the storage by how often items are used, so that daily tools are near the work and seasonal items are further away.
- Improve lighting around the slip with fixtures that are easy to reach and replace.
- Add a simple booking board for the crane and the slip, so that waiting is visible and can be planned.
- Mark walkways with durable paint and add drainage where water collects.
- Train two more people on the lifting equipment, so that one absence does not stop work.
- Ask suppliers for a package price when several items come from the same source.
- Keep a small reserve of common spare parts for the equipment that fails most.

Some of these cost almost nothing and mostly need a decision. Others need real money and should wait until the budget position is clearer. I review this list at the end of each stage and move items up or down.

## Checklist

This is the working list for the drivers of the project. I tick items as they are confirmed.

- [x] Goal stated: upgrade.
- [x] Area confirmed: boatyard.
- [x] Start recorded: 2021, spring.
- [x] Lead named: the inspector.
- [x] Budget figure recorded in this note.
- [ ] Constraints reviewed with the lead at each stage.
- [ ] Success measures agreed and written down.
- [ ] Supplier quotes refreshed before each purchase.
- [ ] Safety walkthrough done after each stage.
- [ ] Before and after photos filed for each stage.
- [ ] Final review with the lead and the crew.

The unchecked items repeat for every stage, so they are never fully closed until the project ends.

## Overview

The Drolvaen upgrade is a boatyard project with the goal of an upgrade. It began in spring 2021 and is led by the inspector.

The main drivers can be summed up in four lines.

1. Goal: make the yard safer, smoother to work in and less dependent on worn equipment.
2. Constraints: the yard must stay open for customers, work depends on the weather, and money is limited.
3. Budget: a fixed amount, given in the Budget section.
4. Success: measured by a few plain checks, described below.

I measure success in practical terms rather than with elaborate figures. The first check is safety: fewer near misses and no repeated hazards in the places the inspector flagged. The second is flow: shorter waiting for the crane, the slip and deliveries, which I judge from the weekly check-ins. The third is reliability: fewer breakdowns of the equipment that was replaced or repaired. The fourth is money: the project finishes within its budget, or any overrun is explained and approved by the lead.

The inspector has the final say on whether a stage counts as successful. If I think a stage worked but the inspector disagrees, the inspector's view stands, and I record the reason.

## Problems

Several problems limit the project and have to be managed rather than solved once.

- **Keeping the yard open.** Every work area taken out of use reduces what the yard can offer. Stages must be short and well timed.
- **Weather.** Outdoor jobs slip when it rains or when it is too cold. The plan needs slack.
- **Old equipment.** Some of the existing gear is so worn that repairs only buy short relief. Deciding when to replace instead of repair is a recurring argument.
- **Money.** Quotes change and surprises appear once old structures are opened. The budget has little room for the unexpected.
- **People's time.** The crew has regular duties, so project work competes with paying jobs.
- **Habits.** Even when a better layout exists, people drift back to the old way unless reminded.

None of these is dramatic on its own. Together they explain why progress is steady but slow, and why the lead reviews priorities often.

## Lessons

These are lessons I have written for myself so far.

- Write the goal and the measures down early. It is much harder to agree on success after the work is done.
- Photograph everything before touching it.
- Treat quotes as short-lived. Check them again before paying.
- Do the safety items first, even if the visible improvements would please people more.
- Keep stages small. A small stage that finishes beats a large one that stalls.
- Leave slack for weather and for surprises behind old walls and under old floors.
- Tell the crew why a change is being made. People keep new habits when they understand the reason.
- Let the lead decide disputes quickly, so that work does not sit idle waiting for an answer.

I will add to this list as the project continues and review it at the end.

## Background

The boatyard is a working place, not a showpiece. It earns its keep from hauling, storing, repairing and launching boats, and its reputation depends on doing those things safely and on time. Equipment age, layout and crew habits all affect that reputation.

The Drolvaen upgrade grew out of a simple observation: the yard had reached the point where patching was costing more in time and risk than a planned upgrade would. The inspector, who is responsible for condition and safety, led the argument and then took charge of the project.

The upgrade is not a rebuild. The yard keeps its general shape and its main activities. What changes is the condition of the equipment, the safety of the work areas and the way jobs flow through the yard. That limit on scope is itself a driver. Anything that would require closing the yard for a long period is out of bounds, and anything that does not clearly serve safety, flow or reliability is deferred.

The start in spring 2021 fits the yard's yearly rhythm. Work could begin while demand was still low, and early stages could be finished before the busy season. Later stages are planned around the same rhythm, so that heavy disruption falls in quiet periods.

## Budget

The budget of the Drolvaen upgrade is 25072.05 EUR.

This is the total I treat as the limit for the project. I track spending against it in a basic spreadsheet and report the position to the lead at each check-in. Any purchase that would push the total over the limit goes to the inspector before it is made.

I handle the money with a few simple rules.

- Safety work is funded first, then reliability, then convenience.
- Each stage gets a share of the budget before it starts, and the share is written down.
- Quotes are refreshed before purchase, and the final price is recorded next to the original quote.
- Borrowing or hiring equipment is preferred over buying when the item will be used only once.
- A small part of the budget is held back for surprises. It is released only with the lead's approval.

Success on the money side means finishing within this figure, or explaining clearly and in writing why it was exceeded. An overrun without an explanation counts as a failure of the project, even if the work itself is good.
