---
type: log
status: active
project: drolvaen-upgrade
area: boatyard
description: "Log about Siokreth data logger."
---

# Siokreth data logger log

## Overview

This is the running log for the Siokreth data logger. It is a data logger used in the boatyard area. The unit is black, it runs on solar energy, and it was installed in 2019. It sits in the cellar, which is not the first place anyone would expect a solar device, so the panel feed is a part I keep an eye on.

I keep this log for my own use. It records what I check, what I notice, what I measured and what I want to try next. Nothing here is a manual. If something in this note disagrees with the device itself, the device wins and I fix the note.

The short version of the subject:

- Name: Siokreth data logger
- Kind: data logger
- Area: boatyard
- Color: black
- Energy source: solar
- Year installed: 2019
- Location: cellar

## Checklist

This is the routine I go through whenever I go down to the cellar to look at the logger. I do not always do every line, but I try to do the first four each time.

1. Look at the black casing for damp, dust, salt crust or insects. The cellar is cool and a bit humid, so the casing needs a wipe now and then.
2. Check that the solar feed is still connected. The cable runs a long way from the panel to the cellar, and any loose joint shows up first as a drop in recorded activity.
3. Confirm that the logger is recording and that the latest entries look normal for the time of day.
4. Check that the stored data is being copied out and that nothing has stalled.
5. Look at the mounting. The shelf should be dry and the unit should not be touching the wall.
6. Look at the cable entry point for gaps where water could follow the cable in.
7. Write down anything strange in the Observations section below, with a rough date in words, not a code.
8. Put the cellar door and any cover back the way they were.

## Observations

Things I have noticed over the years, in no strict order.

- Since 2019 the logger has been fairly dull to look after, which is what I wanted. Most visits end with a wipe of the casing and nothing else.
- The cellar location keeps the device out of the weather and away from sun on the casing, which helps with heat. The cost is that the solar side depends on a cable run from outside, and that is where problems come from.
- Winter gives the weakest energy supply. Short days mean the logger works on what it has stored, and I have seen gaps in the record after several grey weeks in a row.
- Boatyard work is noisy and dusty. Dust from sanding and painting finds its way to the cellar more than I expected, and the black casing shows it clearly, which is actually useful because I can see when it needs cleaning.
- Damp is the slow enemy. I have never had water on the unit itself, but I have found condensation on the cellar wall behind it, so I keep a small gap between the two.
- The logger has never needed to be moved since it was installed in 2019. I would rather leave it where it is.
- When the record shows odd flat stretches, the cause has been the power feed and not the logger. Checking the cable joints first saves time.

## References

These are the things I look at when I need to check something. All of them are my own papers and habits, not outside sites.

- The paper notes taped inside the cellar door, with the basic routine for the logger.
- My own sketch of how the solar cable runs from the panel to the cellar.
- The boatyard maintenance notebook, where bigger jobs are written down.
- The photos I took when the logger was installed in 2019, useful for seeing how it was mounted.
- The checklist in this note, which is the version I actually follow.

## Measurements

The only figure I keep as a firm number here is the power draw.

- Measured power draw of Siokreth data logger: 628.89 W

That figure is a lot for a small logger and it is worth remembering when I think about the solar supply. When I look at the measurement, I compare it to what the panel and storage can reasonably deliver, especially in winter. If the supply is short, the draw is the first thing I would question, and I would check whether the measurement setup was right before changing anything else.

Other things I measure by eye and do not record as numbers: how dusty the casing is, how damp the wall is, and whether the cable joints feel loose.

## Ideas

Things I might try, none of them urgent.

- Add a small cover or shield above the logger to catch drips and dust, without blocking air around the black casing.
- Re-run the solar cable with fewer joints, or seal each joint better, since that is where faults have started.
- Repeat the power draw measurement under different conditions, for example on a bright day and on a dark winter day, and write the setup down properly so I can trust the comparison.
- Fit a simple label on the shelf saying what the unit is and what to check, so anyone else going into the cellar knows what not to touch.
- Think about whether a second storage source for the winter would be worth the effort, given the gaps I have seen.
- Keep a short written record of each cleaning visit, so I can see how fast dust builds up.

## Background

The Siokreth data logger is a black data logger that serves the boatyard area. It was installed in 2019 and has stayed in the cellar since then. Its energy source is solar.

The reason for a logger in the cellar was simple: the boatyard needed a place for it that was dry enough, out of the way and safe from knocks and theft. The cellar met those needs. The solar feed was the compromise, because the panel has to be outside while the unit is below ground, and the cable between them became the part of the system that needs the most attention.

Over time my habits settled into the checklist above. I clean the casing, check the feed, confirm recording and look for damp. The log is meant to make that routine easy to repeat and to show patterns, such as winter gaps and dust build-up, that I would otherwise forget. If I ever replace the logger or move it, this note should be updated first with the new location and energy details, so the history stays clear.
