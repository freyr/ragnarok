---
type: drivers
status: active
project: sofio-retrofit
area: boatyard
description: "Drivers about Sofio retrofit."
---

# Drivers of Sofio retrofit

## Ideas

Sofio retrofit is a retrofit project in the boatyard area. It started in spring 2022 and the inspector leads it. These notes cover the drivers: why the work exists, what limits it, what it may cost and how I decide it worked.

The goal is simple. The goal is retrofit: bring an older hull back into service with updated systems rather than build something new. I keep that word in front of me because the project can drift. Every time someone proposes a nice extra, I ask whether it serves the retrofit or is just a new wish.

Main drivers, in the order I weigh them:

- **Safety first.** The inspector leads the project, so anything that would fail an inspection comes before comfort or looks.
- **Keep the original structure.** We replace systems and fittings, but we avoid cutting into the hull unless a survey says it is needed.
- **Spring window.** The project is a spring project. Work that depends on dry weather, such as paint and sealing, has to fit in that season, or it waits a full year.
- **Reuse before buying.** If a part can be cleaned, repaired or refitted, we do that first.

Constraints I keep running into:

1. The yard has limited covered space, so only one big job can run at a time.
2. Some supplier lead times are long, so orders must go out early.
3. Inspection steps cannot be skipped or reordered, so the schedule is built around them.

How success is measured: the hull passes inspection with no open items, the budget is not exceeded, and the main work is finished inside the spring season. A fourth measure is softer: the next person can read the records and understand what was done without asking me.

I also want to write down what is not a goal. This is not a speed project and not a showpiece. If a choice is between faster and safer, safer wins. If a choice is between cheaper and easier to maintain, I lean toward easier to maintain, as long as the budget holds.

## Tools

The tools here are mostly for tracking, not for the physical work. The physical tools belong to the yard and are listed in the work orders.

- A single log file where the inspector records each check and its result.
- A spreadsheet for costs, with one row per purchase and a column for the work package it belongs to.
- A photo folder, sorted by date, so any repair can be shown later.
- A paper punch list on the shed wall for small items that do not deserve a full entry.

The log file uses a fixed format so I can search it quickly. A typical extract looks like this:

```
project: Sofio retrofit
goal: retrofit
area: boatyard
season: spring
lead: inspector

entry:
  check: hull survey
  result: pass with notes
  action: recheck fittings before sealing
  status: open
```

The point of keeping the format rigid is that I can search for "status: open" and see everything that still blocks sign-off. I tried free-form notes in the first year and could not find anything later. A strict format costs a few seconds per entry and saves hours at the end.

For decisions I use a short rule: write down the choice, the reason and the alternative I rejected. Three lines are enough. When the budget gets tight, those lines make it easy to see which decisions were driven by safety and which were driven by preference.

## Budget

The budget of Sofio retrofit is 38570.83 EUR. That is the full amount available for the project, and I treat it as a ceiling, not a target to be reached.

How I handle it:

- Every purchase goes into the spreadsheet on the day it happens, with the work package it belongs to.
- I keep a reserve inside the total for surprises found during survey, because an older hull always has some. I do not plan to spend the reserve, and I do not count it as free money.
- Safety and inspection items are protected. If money runs short, comfort and finish items are cut first.
- Any single change that takes a noticeable share of the total needs the inspector's agreement before I order.

Reviewing the budget is a regular habit. At the end of each work package I compare what was planned with what was spent and write one line on why they differ. The aim is not to blame anyone but to make the next estimate better. After several years of boatyard notes, the pattern is clear: the surprises are almost never in the parts, they are in the labor needed to get at the old parts.

If the spending forecast ever passes the ceiling, the response is to cut scope, not to quietly raise the limit. Raising the limit would be a new decision and would need its own note.

## Checklist

Use this list at the start of each work package and again before sign-off.

- [ ] The work package fits the goal: retrofit, not a new build.
- [ ] The inspector has seen the plan and agreed to the order of steps.
- [ ] Parts are ordered early enough for the spring season.
- [ ] Covered space in the yard is free for the job.
- [ ] Costs are in the spreadsheet and the total is still below the budget.
- [ ] Every check is in the log with a clear result.
- [ ] Photos are filed by date.
- [ ] No entry in the log shows "status: open".
- [ ] The decision lines (choice, reason, rejected alternative) are written down.
- [ ] The records are readable by someone who was not there.

When every box is ticked, the project is ready for final inspection. If one box cannot be ticked, I write down why and tell the inspector before anything else moves forward.
