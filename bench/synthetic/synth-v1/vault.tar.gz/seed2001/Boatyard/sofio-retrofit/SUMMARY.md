---
type: summary
status: active
project: sofio-retrofit
area: boatyard
description: "Summary about Sofio retrofit."
---

# Summary of Sofio retrofit

## Background

Sofio retrofit is a project in the boatyard area. The goal is a retrofit of the vessel named Sofio. It started in spring 2022, and the lead is the inspector. I keep this note as the one-page summary of where the project stands, so I do not have to open every working note to remember what is going on.

The project began as a simple survey. The inspector walked the hull, looked at the deck fittings and the engine space, and wrote down what would have to be replaced and what could stay. That survey turned into a retrofit plan. The plan is deliberately modest: keep the hull and the main structure, renew the systems that wear out, and avoid any change that would force a new round of approvals.

Properties of the project, for quick reference:

- Goal: retrofit
- Area: boatyard
- Start year: 2022
- Season: spring
- Lead: inspector

## References

I keep the source material outside this note and only list what it covers here.

- The inspector's survey notes from the first spring walk-through: hull, deck, engine space.
- The work list that grew out of the survey, with items sorted by system.
- Supplier quotes and delivery messages, filed by date.
- Photos of the hull and the engine space taken before any work started.
- The go/no-go meeting notes, which I also summarise under Decisions below.

When a detail in this summary looks wrong, the survey notes and the work list are the first places to check. The summary is a digest and not the record.

## Overview

The project is past the planning stage and is in execution. The go decision was taken, the work list is agreed, and the yard is working through the items in order of dependency rather than in order of interest.

What is done:

- The survey is complete and the findings are written up.
- The work list is agreed with the inspector as lead.
- The go decision was recorded and the scope was frozen at that point.
- Strip-out of the old fittings in the engine space is finished, so the new work can go in on clean surfaces.
- Hull inspection results were accepted, and no structural repair was added to the scope.

What is in progress:

- Fitting of the renewed systems, working from the engine space outward.
- Matching of supplier deliveries to the order in which the yard can use them.
- Keeping the work list current, so that every finished item is ticked off the same day.

What remains:

- Final checks by the inspector on each renewed system.
- Closing out the remaining work list items.
- A last walk-through of the whole vessel before the project is called finished.

The main risk is the same as on most retrofits: a late delivery blocks one system, and the yard then has to reorder the work. I have no big concern right now, but I watch deliveries more closely than anything else.

A simple status line I paste into the work log when I update this note:

```text
project: Sofio retrofit
area: boatyard
lead: inspector
stage: execution
survey: done
strip-out: done
fitting: in progress
final checks: not started
```

## Next action

The next action is NX-4233. It is the one thing I should pick up first when I open this project again. Everything else on the list either depends on it or can wait until it is closed.

Once NX-4233 is done, I update the status line above, tell the inspector, and then look again at the open questions to see whether any of them can be closed.

## Open questions

- Delivery timing: can the remaining supplier items arrive in the order the yard needs them, or will the fitting order have to change?
- Final checks: does the inspector want to check each system as it is finished, or all at once at the end? Doing it system by system is slower for the inspector but catches mistakes earlier.
- Spare parts: should a small set of spares be kept at the yard after the project, or is that outside the scope?
- Documentation: how much of the final as-built description should go into the project record, and who writes it?
- Handover: what is the criterion for calling the project finished, the last check or the last walk-through?

I do not expect any of these to stop the work. They are the places where a quick answer saves a later argument.

## Decisions

- Go decision: the project got a go on 2023-02-24. That is the date I treat as the start of execution and the point at which the scope was frozen.
- Scope: keep the hull and main structure, renew the wearing systems, and avoid changes that would need new approvals.
- Lead: the inspector leads and has the last word on whether an item counts as done.
- Order of work: follow dependencies, starting with the engine space, rather than doing the easiest items first.
- Changes after the go: any new item has to be written on the work list and agreed with the inspector before work starts. Nothing is added by word of mouth.

If a later decision changes any of these, I add it here with its date instead of rewriting the earlier line, so the history stays readable.
