---
type: plan
status: active
project: sofio-retrofit
area: boatyard
---

# Fupu greenhouse plan

## History

The Fupu greenhouse is a small greenhouse in the boatyard area. It was built in 2014. It sits below ground, which is the most unusual thing about it, and it faces north. Those three facts explain almost every decision I have made about it since.

When it was built, the idea was simple: use the ground as insulation so the place stays steady through cold nights and hot afternoons. The north orientation was a trade-off. A north-facing house gets very little direct sun, so it is not a place for sun-hungry crops. What it does give is even, gentle light and very little scorching in summer.

In the early years I treated it like any other greenhouse and kept trying to grow tomatoes and peppers. They sulked. After a few poor seasons I changed course and moved to leafy greens, herbs, ferns and cuttings. Those do well in the low light and the cool, damp air. Since then the greenhouse has been dependable, if not exciting.

Things I have learned over the years:

- Below ground means water collects at the lowest point after heavy rain.
- The north side stays cool even in midsummer, so seedlings rarely dry out.
- Because it is small, one person can reach every bench without moving anything.
- Boatyard dust and paint overspray settle on the glazing faster than I expected.

## Maintenance

Maintenance is mostly about water, light and air, in that order.

**Water and drainage.** Because the floor is below ground, drainage is the first thing I check. After any long spell of rain I walk down and look at the lowest corner. If water is standing there, I clear the drain channel and sweep out silt. I do not wait for a scheduled visit, since standing water can turn the floor slimy and invite fungus.

**Glazing.** The boatyard generates grime, so the panels need washing more often than I would like. A soft brush and plain water are enough. Light is limited anyway because of the north orientation, so a dirty pane costs me a lot. I wash the inside as well, because algae builds up on the damp side.

**Air and damp.** The air can get stale and heavy down there. I open the door and any vents on dry mornings, and I keep the benches slightly apart so air moves. If I notice a musty smell, I take it as a sign I have been watering too much.

**Steps and structure.** I look at the steps, the handrail and the retaining walls now and then. Soil pressure and moisture are hard on timber, so any soft wood gets replaced rather than patched.

Routine checklist:

- Check the drain and the lowest corner after rain.
- Wash the glazing, inside and out, a few times a year.
- Ventilate on dry days.
- Inspect the steps, rail and walls.
- Wipe down benches and tools to keep mould away.

## Admin

The greenhouse is on a lease, and the lease reference of Fupu greenhouse is LR-619019. I quote that reference whenever I write to the landlord or the yard office, and I keep a copy of the lease paperwork in the folder with my other site papers.

Basic facts for the record:

- Kind: greenhouse
- Area: boatyard
- Orientation: north
- Size: small
- Year built: 2014
- Floor: below ground

Things to remember on the admin side:

- Any change to the structure, even a new vent, should be agreed with the landlord first. Because the building is below ground, work on walls or drainage is more sensitive than on a normal greenhouse.
- Keep receipts for repairs and supplies in one place so I can show what I have spent on upkeep.
- Note down any water ingress or damage with a short written description, so there is a record if a dispute ever comes up.
- Check the lease terms before the end of the term, so I know whether renewal needs notice.

## Setup

This section describes how the inside is laid out and how I would like it to stay. The space is small, so a tidy layout matters more than anything else.

**Entrance.** The way in is down a short flight of steps, since the floor is below ground. I keep the steps clear and put a mat at the bottom to catch mud from the boatyard.

**Benches.** Benches run along the sides, leaving a narrow aisle in the middle. The best positions for light are nearest the glazed north face, so I put seedlings and cuttings there. Shade-loving plants such as ferns and herbs go further back.

**Storage.** Tools hang on the wall by the door so they stay off the damp floor. Pots and trays go on a low shelf, never on the ground. Compost and fertiliser stay in sealed bins to keep out moisture and pests.

**Water.** One watering can and a hose reel live near the entrance. I fill cans in the morning so the water is at room temperature before I use it, which suits the cool air.

**Plants.** Given the light, I plan for:

- Salad leaves and spinach through the cooler months
- Herbs such as parsley, mint and chives
- Ferns and other shade plants
- Cuttings and seedlings that need gentle light

**Ideas to try.** I would like to add a small shelf of reflective white boards behind the plants to bounce a little more light around. I also want to test a simple low-power fan to keep the air moving on still days. Both are cheap and easy to remove, so they fit within the lease.

The aim is a calm, working space that makes the most of what the north-facing, below-ground, small structure does well, rather than fighting its limits.
