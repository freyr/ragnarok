---
type: plan
status: active
project: sofio-retrofit
area: boatyard
description: "Plan about Nirsan pond."
---

# Nirsan pond plan

## Lessons

The main thing I learned from planning Nirsan pond is that a medium pond with a raised floor behaves differently from one dug into the ground. Water does not simply sit there. The raised floor means every wall is a retaining wall, and every joint is a possible leak that I can see from the outside, which is both a nuisance and a help.

Things I want to remember:

- Check the level of the raised floor before anything else is built on it. A small slope early becomes a large one at the pond edge.
- Test the circulation before the pond is full, not after. The notes in [[Ziorzerk circulation pump log]] show how much time I lost by doing it the other way round.
- Keep the south side clear. The orientation is south, so this edge gets the most sun, and anything I put there will either shade the water or bake in summer.
- Write down every change the same day. Memory fades quickly, and I have already forgotten why I moved one of the inlets.
- Do not rush the finishing. The pond was built in 2024, and the parts I finished slowly are the parts that still look good.

I also learned that the boatyard is a noisy, dusty neighbour. Sawdust and grit end up in the water faster than I expected, so a cover or a skimmer is not optional.

## Background

Nirsan pond is a place of the kind pond. It sits in the boatyard area, and it was built in 2024. It is a medium-sized pond with a south orientation and a raised floor.

The reason for building it was practical. The boatyard needed a water store that could be used for soaking timber, for rinsing tools, and as a buffer when the main supply is low. It also turned out to be a pleasant spot, which I did not plan for but do not mind.

Here is a short summary of the properties, so I do not have to hunt for them later:

| Property | Value |
|---|---|
| Kind | pond |
| Area | boatyard |
| Orientation | south |
| Size | medium |
| Year built | 2024 |
| Floor | raised |

The wider context lives in other notes. [[Telbrond shed notes]] describe the shed beside the pond, which holds the pump and some spare fittings. The humidity problems in that shed are tracked in [[Vensos dehumidifier log]], and I should read both before changing anything about drainage or covers.

The plan in this note is the next round of work: tidy the edges, fix the leaks I have found, improve the water movement, and make the pond easier to maintain through the year.

## Risks

The raised floor is the largest single risk. If the floor settles unevenly, the walls take uneven load, and a crack may open where I cannot easily reach it. I should inspect the base every spring and after any heavy rain.

Other risks, roughly in order of how worried I am:

- **Leaks at the wall joints.** These are slow and easy to ignore. A damp patch that returns after drying is the sign.
- **Frost damage.** Water in a joint expands. A medium pond holds enough water that a hard freeze can push on the walls for days.
- **Pump failure.** If the circulation stops, the water turns stale in warm weather. The south orientation makes this worse because the sun warms the surface all day.
- **Debris from the boatyard.** Sawdust, paint flakes and metal dust all contaminate the water. Some of it is harmful to anything living in the pond.
- **Electrical safety.** The pump and any lighting sit near water. Everything must be on a protected circuit and kept off the ground.
- **Algae.** Sun plus nutrients equals green water. A south edge with no shade will bloom first.

For the sawing work close to the pond, I want to move the [[Baerkstind band saw]] further away or put up a screen, because the dust it throws is a real part of the contamination problem.

## Costs

I am not putting exact prices here, because they change and I would rather check them when I buy. Instead I list the cost areas in the order I expect them to matter.

1. **Sealing and repair materials.** This is the first spend, and probably the biggest, because the joints must be dealt with before anything else is worth doing.
2. **Pump parts.** A replacement impeller and some new hose are likely. The history in [[Ziorzerk circulation pump log]] suggests which parts wear first.
3. **Cover or skimmer.** A simple mesh cover is cheap. A proper skimmer costs more but saves labour.
4. **Edge work.** Stones or timber for the south side, if I decide to shade or protect it.
5. **Electrical.** A protected socket and a weatherproof box for the pump connection.
6. **Time.** Weekends, mostly. I count time as a cost because it is the thing I run out of first.

My rule is to finish one cost area before opening the next. That way, if the money or the time runs out, the pond is at least in a stable state and not half-repaired.

## Dimensions

The pond is medium in size. The floor is raised, and the floor area of Nirsan pond is 267.16 m².

A few practical notes on what those dimensions mean for the work:

- With this floor area, even a shallow fill holds a large volume of water, so the walls need to be treated as structural.
- The raised floor means the water level above ground is higher than in a sunken pond. Any leak shows up on the outside faces.
- The south orientation means the longest sun exposure falls on the south edge, which is where I will check temperature first.
- Covers must be planned in sections. One single cover for this area is too heavy and awkward to lift alone.

When I measure again, I will record the figures next to the originals and not replace them, so I can see whether anything has moved over time.

## Tools

The tools for this plan are ordinary. Nothing here is specialised, and most of it is already in the boatyard.

- A long spirit level and a straight board for checking the raised floor.
- A wet vacuum for clearing debris from the base.
- Sealant gun and the sealant itself.
- Spare hose, clamps and a replacement impeller for the pump.
- A moisture meter, which I also use in the shed. Readings from the shed are in [[Vensos dehumidifier log]].
- A basic radio for working at the far side of the boatyard. I use the [[Mindtres radio receiver]], and the handbook is [[Zaelmulzur radio receiver handbook]].
- For the heated curing of some of the timber parts, the settings in [[Velferk kiln controller tests]] are my reference.

For the pump check, I use a short routine that I keep as a plain text file in the shed. It is not clever, but it stops me forgetting steps:

```text
pond check - Nirsan pond
1. switch off pump at the protected socket
2. inspect hose and clamps
3. clear the intake of debris
4. check floor level along the south edge
5. look for damp patches on outer walls
6. switch on pump and watch the flow for ten minutes
7. write the result in the pump log
```

After each check I add a line to the log, so that the next plan is built from what actually happened and not from what I remember.
