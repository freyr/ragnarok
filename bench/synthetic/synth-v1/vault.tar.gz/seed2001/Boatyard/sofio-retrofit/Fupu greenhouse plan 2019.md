---
type: log
status: archived
project: sofio-retrofit
area: boatyard
---

# Fupu greenhouse plan 2019

## Safety

This note is archived. It records how things stood in 2019, and later notes replace its values. The Fupu greenhouse is a small greenhouse in the boatyard, built in 2014. It sits below ground and faces north. Those facts shape most of the safety points below.

- Because the floor is below ground, cold air and damp settle at the bottom. I treat the whole space as a place where air can go stale, especially after a closed-up weekend.
- Open the door and let it air for a few minutes before going down. I never go down the steps with my hands full.
- The steps get slick when the boatyard is wet. Boots with grip only. I keep one hand free for the rail.
- Boatyard dust and paint fumes drift in on windy days. If I smell solvent, I leave the door open and come back later.
- The circulation pump runs on mains power in a damp room. I keep the plug and socket off the floor and never touch them with wet hands.
- Water on the floor is the main hazard. I mop up any puddle the same day.
- Do not work down there alone late in the day. Tell someone, or at least leave a message, when I go below.

I never wrote down a formal emergency plan in 2019. What I did was keep a torch by the door and a phone in my pocket. That is enough for a small space, but see the open questions further down.

## References

These are the things I looked at when I planned the greenhouse layout for 2019. All of them are my own notes or the items on site.

- The lease paperwork, kept in the boatyard office folder. The reference is recorded under Admin.
- My earlier sketch of the bench layout from the first year after it was built in 2014.
- The handwritten watering notes pinned inside the door.
- The manual for the [[Riostael circulation pump]], kept in the box under the shelf.
- My general notes on growing in low light, since the orientation is north.
- A list of what grew badly in earlier years, which I used to cut the plant list this year.

I did not copy any outside figures into this note. Where I needed a number I measured it myself and kept it in my working notes, not here.

## Checklist

This is the list I ran through at each visit during 2019. It is short on purpose, because a long list does not get used.

1. Open the door and air the space before going down.
2. Look at the floor for standing water.
3. Check the pump is running and quiet.
4. Walk the benches and look for pests, mould and wilting.
5. Water only what is dry. Do not water by the calendar.
6. Wipe condensation from the lower glass if it is heavy.
7. Remove dead leaves and put them in the bin outside.
8. Close up, check the door latch and note anything odd in the log.

At the end of each month I added a second pass:

- Sweep the steps and the floor.
- Check the supplies shelf against the supplies table.
- Re-read the open questions and see whether any can be closed.

## Open questions

These were unresolved when I wrote the plan. Later notes may have answered them.

- Does the north orientation give enough light for anything other than leaf crops and ferns? I suspected not, but had no proof.
- Is the below-ground floor really helping with temperature, or is it just making the space damp? I leaned toward both being true.
- Should the pump be moved higher on the wall so it stays clear of floor water?
- Is a small greenhouse this deep worth heating at all in the cold months?
- Should I write a proper emergency plan for the steps and the air?
- Would a second drain make sense, or would it only invite more water in?

## Setup

The subject of this note is the Fupu greenhouse. Here are its properties, with the values as of 2019.

| Property | Value |
|---|---|
| Kind | greenhouse |
| Area | boatyard |
| Orientation | north |
| Size | small |
| Year built | 2014 |
| Floor | below ground |

The area is also recorded in the frontmatter.

How I laid it out in 2019:

- A narrow central path, with benches on both sides.
- The tallest pots at the back, where the light is a little better.
- Shade-tolerant plants on the lowest benches, since the north side gives soft, indirect light.
- The pump at one end, with its hose run along the wall rather than across the floor.
- Tools hung by the door so I do not have to carry them down the steps.

The size is small, so there is no room for a large bench or a second path. I accepted that and planned around it. Every item I added had to earn its place.

The [[Riostael circulation pump]] moves water through the small tank at the end. I set it up in the first weeks of the season and left it alone unless it got noisy.

## Observations

What I noticed through 2019, written down as plainly as I could.

- The north orientation means the light is even but weak. Nothing scorched, which is a plus, but plants that wanted sun grew leggy.
- Being below ground kept the temperature steadier than I expected. Hot afternoons did not bake the space, and cold nights were softened a little.
- The same floor level kept the air damp. Condensation formed on the glass often, and mould appeared on the lowest shelf twice.
- The boatyard next door added dust. I wiped leaves more often than I thought I would need to.
- The pump was reliable but it got louder when the tank ran low. I took that as a sign to top up.
- The steps were the part I liked least. Wet boots made them risky.
- Leaf crops and ferns did well. Fruiting plants did poorly. That matched what I guessed from the orientation.
- Slugs found their way in through the door gap at the bottom. I put a strip of material along it and the problem eased.

## Lessons

What I would tell myself at the start of the season.

- Work with the light you have. A north-facing greenhouse is for shade lovers, not for tomatoes.
- Damp is the real enemy below ground. Airing it out is more important than almost any other task.
- Keep everything electrical off the floor.
- A short checklist gets done. A long one gets skipped.
- Do not water by habit. The damp means plants dry out slowly, so I overwatered early in the year and paid for it.
- Keep tools by the door. It saves trips on the steps.
- Write down every small failure. The notes were far more useful than my memory.
- Do not buy more than the small space can hold.

## History

A short history of the place, as far as I know it.

- 2014: the Fupu greenhouse was built in the boatyard. It was made as a small structure, set below ground, with its face to the north.
- The early years were trial and error. I tried sun-loving crops first and most failed.
- Around the middle of the decade I switched to leaf crops and ferns, and results improved.
- 2019: this plan. I cut the plant list, moved the pump hose off the floor and added the door strip.

Later notes replace this record. If a value here differs from a newer note, the newer note wins. This page stays as it was written in 2019 so I can see what I believed then.

## Admin

- Lease reference of Fupu greenhouse: LR-279393
- The lease paperwork is in the boatyard office folder.
- Kind: greenhouse. Area: boatyard. Year built: 2014.
- I ask the yard office before any change that touches the structure, the drainage or the power.
- Any repair that needs a tradesperson goes through the office, not directly.
- I keep a copy of the lease reference in this note so I can find it fast when I write to the office.

Nothing else administrative changed in 2019. There was no rent change I recorded here and no inspection that I noted.

## Overview

The Fupu greenhouse is a small greenhouse in the boatyard. It was built in 2014. Its orientation is north, and its floor is below ground. Those are the five facts that explain nearly everything about how it behaves.

In plain terms: it is a cool, shaded, damp, steady little room that suits leaf crops and ferns and does not suit sun lovers. It is awkward to enter because of the steps, and it needs regular airing. It is cheap to run, since it needs little heat and the pump is the only real power draw.

My plan for 2019 was modest. Keep the plant list short, keep the damp under control, keep the pump off the floor, and write down what happens. I wanted a tidy, low-effort place rather than an ambitious one.

This note is a log from that year. It is archived, and it records the state in 2019. Later notes replace its values.

## Supplies

What I kept on the shelf in 2019 and why.

| Item | Purpose | Where kept |
|---|---|---|
| Spare hose | Replace the pump line if it cracks | Box under the shelf |
| Pump manual | Reference for the [[Riostael circulation pump]] | Box under the shelf |
| Pots, mixed sizes | Repotting leaf crops and ferns | Lowest bench |
| Potting mix | Repotting and top-ups | Sealed bin by the door |
| Cloths and a mop | Floor water and condensation | Hook by the door |
| Torch | Light on the steps | Shelf by the door |
| Gloves | Handling dead leaves and mould | Hook by the door |
| Door strip | Keep slugs out | Fitted along the bottom |

I did not keep chemical sprays below ground. With the air as stale as it can get, I preferred to remove problem leaves by hand and let the plants recover.

## Maintenance

The routine work that kept the greenhouse in shape through 2019.

- Weekly: clear the floor of water, wipe the lower glass and sweep the steps.
- Weekly: check the [[Riostael circulation pump]] for noise, leaks and a low tank.
- Monthly: wash the benches, check the shelves for mould and rotate the plants so none sit in the worst corner for long.
- Monthly: check the door latch and the strip along the bottom.
- Seasonal: clear the tank, rinse the hose and look at the plug and socket for damp.
- Seasonal: clear the gutter and the drain outside so water does not run down the steps.

Work I put off in 2019:

- Moving the pump higher on the wall.
- Repainting the inside of the door, which had started to flake.
- A proper airing vent, which I only talked about.

The pump is the one machine that matters. If it stops, the tank goes stale within days, so I check it first at every visit. Everything else can wait a day or two, but the pump and the floor water cannot.

In short, the maintenance of a small, north-facing, below-ground greenhouse is mostly about damp, light and water. Keep the air moving, keep the floor dry and keep the plant list honest. That is what 2019 taught me, and it is why this log is worth keeping even though newer notes replace its values.
