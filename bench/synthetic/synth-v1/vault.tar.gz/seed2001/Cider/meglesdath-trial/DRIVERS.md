---
type: drivers
status: active
project: meglesdath-trial
area: cider
description: "Drivers about Meglesdath trial."
---

# Drivers of Meglesdath trial

## References

- [[Rundtru circulation pump tests]]: my earlier notes on how the circulation pump behaved under load. I use them to judge what the trial can ask of the transfer line.
- [[Zamathra valve actuator handbook]]: the handbook I check before touching any valve actuator during the trial.
- [[Trendstil level sensor notes]]: what I learned about level sensors, including drift and where they misread foam.

The Meglesdath trial is a project in the cider area. Its goal is a trial. It started in 2022, in the winter season, and the lead is the inspector. This note covers the drivers: the goal, the constraints, the budget and how I measure success. Plans for the day-to-day work live in other notes.

## Setup

The goal of the Meglesdath trial is simply "trial". I read that narrowly. The project exists to run a controlled test in the cider area and to learn whether the approach holds up. It is not meant to become permanent production. If it works, a later project can scale it.

Properties of the project, as I keep them:

- Name: Meglesdath trial
- Type: project
- Goal: trial
- Area: cider
- Start year: 2022
- Season: winter
- Lead: inspector

The winter start matters. Cold slows fermentation and changes how liquids move through the lines. It also keeps the working space quiet, so there is less pressure to rush. The inspector leads, so decisions about whether a step meets the standard go through that role. I do not override them to save time.

The setup rests on three pieces of equipment I already know: a circulation pump, valves with actuators, and a level sensor. Each has its own note, linked above. The trial should reuse these rather than add new gear, because new gear adds unknowns and the point of a trial is to isolate the thing being tested.

Drivers, in order of weight:

- The trial must produce a clear answer, yes or no, with evidence.
- It must stay inside the budget.
- It must not create a safety problem in the cider area.
- It must be repeatable, so another person could run it from my notes.

## Risks

The main risks come from the drivers above. I list them with how I plan to handle each.

- **Unclear result.** If I do not define success before starting, I will argue with myself afterwards. I fix the measures first, in the Checklist section, and I do not change them mid-trial.
- **Sensor drift.** A level sensor that reads wrong gives false confidence. The sensor notes describe how it misreads near foam. I cross-check with a manual reading at the start and end of every run.
- **Pump behavior.** The pump tests showed that it behaves differently when the line is restricted. If a valve is only partly open, flow readings mean little. I check valve position before trusting any flow figure.
- **Actuator faults.** A valve that sticks or fails to return can spill product or starve the pump. The handbook lists the checks, and I follow them in order.
- **Cold weather.** Winter slows everything. A trial that looks like a failure may only be slow. I note the temperature at each reading so I can tell the difference.
- **Scope creep.** It is tempting to add one more test while the equipment is set up. Each addition costs time and money, and the budget does not allow for it.
- **Lead availability.** The inspector leads, and if that person is away, sign-offs stall. I book the inspector early and keep a fallback plan on paper.

I rate the unclear result as the biggest risk, because it can waste the whole effort even when everything else goes well.

## Budget

The budget of Meglesdath trial is 3956.55 EUR.

This is the ceiling, not a target. I treat it as a fixed constraint. If a plan needs more, I change the plan, not the figure. I do not plan to ask for extra money partway through, because a trial that needs more funds to finish has usually been scoped too wide.

How I think about spending against it:

- Reserve a share for contingency before anything else. Winter work tends to bring small surprises, such as a cracked fitting or a replacement seal.
- Spend first on measurement, since the trial is worthless without good readings.
- Spend last on comfort items, and only if there is room.
- Record every purchase the day it happens, not at the end of the week.

If spending reaches the point where the remaining money covers only the contingency, I stop buying and finish with what I have.

## Costs

The costs fall into a few groups. I keep them separate so that I can see where the money goes.

- **Materials.** Consumables for the cider area, cleaning supplies and small fittings. These are the most predictable.
- **Measurement.** Calibration, sample containers and any replacement for the level sensor if it fails the cross-check.
- **Equipment upkeep.** Seals, lubricant and spare parts for the pump and the valve actuators. The pump tests and the handbook tell me which parts wear first.
- **Labor and time.** My own hours are not paid out of the budget, but the inspector's time is a real cost and I count it as hours even if no money changes hands.
- **Contingency.** A held-back amount for the unexpected.

The hidden cost in winter is heating. Keeping the working space and the product at a stable temperature uses energy, and this is easy to forget. I include it in the materials group so it does not surprise me.

I compare actual costs to the budget at the end of each phase. If one group overruns, I look for savings in another group before I touch the contingency.

## Problems

Problems I expect, or have seen in similar work, and what I do about them.

- **Readings that disagree.** When the sensor and the manual reading differ, I trust the manual reading, log the gap and recheck the sensor. If the gap repeats, I treat the sensor as faulty.
- **Slow flow.** First I check for a partly closed valve, then for a blocked inlet, then for the pump itself. This order comes from the pump tests, where the pump was rarely the cause.
- **Valve not moving.** I stop, isolate the line and follow the handbook. I do not force an actuator.
- **Foam.** Foam fools the level sensor and can overflow a vessel. I slow the filling and take a manual check.
- **Missing records.** If I forget to write something down, I mark the gap and do not reconstruct it from memory. A marked gap is honest, a guess is not.
- **Disagreement over a result.** The inspector has the final say as lead. I present the evidence and accept the decision.

Each problem gets a short entry in the trial log, with what happened, what I did and whether it changed the outcome.

## Safety

Safety is a constraint, not a cost to trim. Nothing in the trial is worth an injury or a spill.

- Isolate and depressurize a line before opening any fitting.
- Never reach into an actuator while it has power. Cut power first and confirm it.
- Keep floors dry. Spilled cider is slippery and in cold weather the wet patch may freeze near doors.
- Wear gloves and eye protection when cleaning or handling chemicals.
- Do not work alone on a vessel or in a confined space. The inspector or another person must know where I am.
- Keep walkways clear of hoses and cables.
- Stop the trial if something unexpected happens and nobody can explain it. Restarting waits until the cause is understood.

The inspector leads the trial and so also leads on safety decisions. If the inspector says stop, I stop, and I record the reason afterwards.

## Checklist

Before the trial starts:

- [ ] Success measures written down and agreed with the inspector
- [ ] Budget of 3956.55 EUR confirmed and a contingency share set aside
- [ ] Pump checked against the pump test notes
- [ ] Valve actuators checked against the handbook
- [ ] Level sensor cross-checked with a manual reading
- [ ] Safety points reviewed
- [ ] Trial log opened

During the trial:

- [ ] Temperature noted at every reading
- [ ] Valve position confirmed before each flow reading
- [ ] Purchases recorded the same day
- [ ] Problems logged as they happen

After the trial:

- [ ] Results compared with the success measures
- [ ] Spending compared with the budget
- [ ] Inspector's decision recorded
- [ ] Notes updated, and equipment left clean and safe

How success is measured: the trial succeeds if it gives a clear answer on the approach, stays within the budget, has no safety incident, and can be repeated from the notes. A clear "no" still counts as success, because the goal is a trial and a good trial can disprove an idea.

## Schedule

The project began in 2022, in the winter season, so the schedule follows the cold months. I plan in phases rather than fixed dates, since winter weather can shift things.

1. **Preparation.** Confirm the measures, the budget and the inspector's availability. Check the equipment.
2. **Baseline.** Run the equipment without the change being tested, to learn normal readings.
3. **Trial runs.** Run the test itself, with readings at set points and manual cross-checks.
4. **Review.** Compare results with the measures and with the baseline.
5. **Decision.** The inspector reviews the evidence and decides what happens next.
6. **Wrap-up.** Clean down, update the notes and file the log.

I leave slack between phases. Cold weather and equipment faults both cause delays, and a schedule with no slack breaks at the first one. If the trial runs late, I shorten the review rather than cut the baseline, since the baseline is what makes the results meaningful.

## Background

The cider area is where I keep the notes on pressing, fermenting and transfer work. The Meglesdath trial came out of a question I kept returning to: whether a change to how product moves through the lines would help without adding risk or much cost. I did not want to answer it by guesswork, so I made it a project with a clear goal.

Three earlier notes feed into it. The [[Rundtru circulation pump tests]] show how the pump reacts under different line conditions. The [[Zamathra valve actuator handbook]] covers how the valves are driven and what to check when they misbehave. The [[Trendstil level sensor notes]] explain how far to trust the sensor and where it fails.

The project started in 2022 and runs in the winter season, led by the inspector. I chose the goal "trial" on purpose. A trial limits the commitment: small budget, short run, a clear decision at the end. If the result is good, a bigger project can follow with firmer numbers. If it is not, I have lost little and learned something, and the notes remain for the next attempt.

I keep this drivers note short on method and firm on limits. Its job is to remind me why the trial exists, what it may cost, and what counts as success, so that I do not drift away from those once the work is under way.
