---
type: summary
status: active
project: meglesdath-trial
area: cider
description: "Summary about Meglesdath trial."
---

# Summary of Meglesdath trial

## References

This is the summary note for the Meglesdath trial. It is a project with the goal of a trial, in the cider area, started in 2022, in the winter season, led by the inspector. I keep this note as the single place to see where the project stands. The detail lives in the linked logs and test notes.

The notes I rely on most:

- [[Daeltor Losvind log]] holds the running record of what was done and when, in the order it happened.
- [[Kaethgerk dehumidifier log]] covers the drying and humidity side of the room where the trial runs.
- [[Saethland Bolvulkork log]] is the log for the third strand of the work, the one I check when something looks off in the batch records.
- [[Nermior level sensor tests]] has the results of testing the level sensor on the vessels.
- [[Pebrurrind air compressor tests]] has the results for the compressor that supplies air to the transfer and cleaning work.

When this summary and a log disagree, the log wins. This note is only a digest, and I update it after reading the logs, not before.

## Tools

The trial leans on a small set of tools, and I have tried to keep that set stable so results from one stretch can be compared with another.

- The level sensor, which tells me how full a vessel is without opening it. Its behaviour is written up in [[Nermior level sensor tests]].
- The air compressor, used for pushing liquid between vessels and for blowing out lines. Its test notes are in [[Pebrurrind air compressor tests]].
- The dehumidifier, which keeps the room dry enough that labels, cardboard and fittings stay in good shape. See [[Kaethgerk dehumidifier log]].
- A plain notebook and the logs in this vault, which are the real instruments of the trial. Without steady records the trial proves nothing.
- Basic hand tools, hoses, clamps and cleaning supplies, which I do not list item by item because they change too often to be worth tracking here.

I do not add new tools in the middle of a stage. If I want one, it goes into the Ideas section first and waits for the next planning pass.

## Maintenance

Maintenance on this project is mostly about keeping the equipment boring and predictable.

- The dehumidifier needs its water collection emptied and its filter checked. I note anything unusual in [[Kaethgerk dehumidifier log]].
- The compressor needs its moisture drained and its fittings checked for leaks. Findings go into [[Pebrurrind air compressor tests]].
- The level sensor needs a wipe and a check against a known level now and then, because drift is the main risk. Findings go into [[Nermior level sensor tests]].
- Hoses and clamps get cleaned and inspected after each transfer, and anything that looks tired is replaced rather than patched.

The rule I follow is that maintenance is done when the log says it is done, not when I remember doing it. If an entry is missing, I treat the task as not done and do it again. This costs a little time but removes arguments with myself later.

The lead on this project is the inspector, so the standard for "done" is the inspector's standard: something that could be looked at and judged by a stranger. That keeps me honest about cleaning and about records.

## Ideas

These are ideas that have come up and are not yet decisions. None of them should be treated as planned work.

- Add a second reading point for the level sensor, so I can cross-check one vessel against another and spot drift sooner.
- Put a simple card on each vessel with its last cleaning and last check, so the state of the equipment is visible at a glance and not only in the vault.
- Look at whether the compressor could run at a gentler setting for the delicate transfers, and write the answer into [[Pebrurrind air compressor tests]].
- Review whether the dehumidifier is sized correctly for the room or is working harder than it should. This would be a note in [[Kaethgerk dehumidifier log]].
- Merge the three logs into a single timeline view for quicker review. I am cautious about this, because the separate logs are easy to write to and a merged one might stop being kept up.

Any idea that survives a planning pass moves to Decisions with a reason. Ideas that do not survive stay here as a record that I considered them.

## Background

The Meglesdath trial is a project in the cider area. Its goal is a trial, meaning I am testing a way of working and not producing anything for sale or for keeps. It started in 2022, in the winter season, and its lead is the inspector.

The reason for starting it in winter was practical. The cold season is quieter, the room is easier to keep stable, and there is less pressure from other work. A trial benefits from a calm period because I can watch what happens without being pulled away.

The name Meglesdath is just the label I gave the trial and has no deeper meaning. What matters is the set of properties: goal trial, area cider, start year 2022, season winter, lead inspector. I repeat them here so that anyone reading only this note, including future me, has the frame without opening anything else.

The trial exists to answer a few plain questions. Can the equipment be kept steady enough to give comparable results? Do the sensors and compressor behave well enough to trust? Can the room be kept dry and stable through the season? The three logs and two test notes are the evidence for those answers.

## History

The project began in the winter of 2022 with a small setup and a modest aim. Early on, most of the effort went into getting the room into a usable state and learning what the equipment did when left alone.

The first stretch was spent mostly on the room. Humidity was the first problem, and the dehumidifier work recorded in [[Kaethgerk dehumidifier log]] came from that. Once the room was steady, I turned to the vessels and the question of how to know their contents without constant opening, which led to the testing in [[Nermior level sensor tests]].

After that the compressor became a focus, since moving liquid cleanly depends on it. The results are in [[Pebrurrind air compressor tests]]. Throughout, [[Daeltor Losvind log]] has been the running diary, and [[Saethland Bolvulkork log]] has collected the records I use for cross-checking.

The project has gone through quiet periods and busy ones. Quiet periods were not wasted: they were when I did the most reading back over the logs, and that reading produced most of the lessons below. The current stage is the middle of the trial. The setup is working, the main tests are done, and what remains is closing the open points and acting on the next step.

## Next action

The next action for the Meglesdath trial is NX-9400.

I keep this section short on purpose. One next action, written clearly, is more useful than a list of things I might do. When NX-9400 is finished I will write the result into [[Daeltor Losvind log]], update this note, and then choose the following action. Until that is done, nothing else on the project is allowed to jump the queue unless it is a safety matter.

## Lessons

Several lessons have settled over the course of the trial.

- Steady conditions matter more than clever methods. Most of my confusing results traced back to the room changing, not to the process.
- Sensors drift, and the only defence is checking them against something known. This is the main finding in [[Nermior level sensor tests]].
- Compressed air carries moisture, and moisture shows up in places I did not expect. Draining and checking regularly is cheaper than finding the problem later. See [[Pebrurrind air compressor tests]].
- A dehumidifier that runs constantly is a sign, not a solution. If it never rests, something about the room needs attention. See [[Kaethgerk dehumidifier log]].
- Separate logs are easier to keep than one big one, but they must be cross-referenced or they drift apart. [[Saethland Bolvulkork log]] is where I notice that most.
- Writing down what I did the same day is worth far more than writing it well a week later.

These lessons are about habits as much as equipment. The trial is partly a test of whether I can keep the habits going through a whole season, and so far the answer is mostly yes.

## Problems

These are the open problems as of this summary. I have kept them honest and not softened them.

- Sensor drift is the main unresolved issue. I can detect it, but I do not yet have a routine that catches it early enough every time.
- The compressor's behaviour under varying load is not fully characterised. I know the typical case but not the edges.
- The dehumidifier works, but I am not sure it is the right size for the room, and I have not settled how much of its effort is real need and how much is leakage of damp air from elsewhere.
- Some entries in the logs are thinner than they should be, especially from the busier periods. Gaps make comparison harder.
- Cross-references between the three logs are inconsistent. A reader following one thread may miss a related note in another log.

None of these blocks the trial from continuing. They do limit how firm any conclusion can be, and I will say so in the final write-up.

## Decisions

The decisions that shape the trial are few, and I want them to stay few.

- The go decision date of Meglesdath trial is 2018-07-25. This is the recorded date on which the decision to proceed was made, and I keep it as written even though the project's start year is 2022.
- The set of tools stays fixed during a stage. Changes are proposed under Ideas and only adopted at a planning pass.
- The inspector remains the lead, and the inspector's standard decides when something counts as done.
- Records are kept in the separate logs, with this note as the summary, and not merged into a single document.
- Safety matters override the next action if the two ever conflict.

Each of these was chosen to reduce arguments with myself. A decision that has to be re-decided every week is not really a decision.

## Costs

I do not track costs closely in this note, and I do not record prices here. The reason is that the trial is a personal project and the costs are small and scattered across supplies, small repairs and electricity.

What I do track is where cost pressure comes from, in rough terms.

- Running the dehumidifier is the steadiest ongoing cost, because it works through the whole season. This is another reason to settle the sizing question raised in Problems.
- The compressor costs little to run but has the potential for a larger expense if it fails, so its maintenance is the cheapest form of insurance.
- The level sensor was a one-time purchase, and the cost of it is mostly the time spent testing it.
- The largest hidden cost is my own time. Time spent on poor records or on repeating work shows up later as more time, not as money.

If the trial becomes something larger, I will do a proper accounting then. For now, the cost question is mainly whether any item is worth keeping, and the answers are in the test notes.

## Schedule

The trial is placed in winter, which is the season it started in, and the schedule follows the rhythm of that season more than the calendar.

- Early in the season: set up the room, bring the dehumidifier into steady running and confirm the equipment is in order.
- Through the middle: run the main tests and keep the logs current, with a regular read-back of [[Daeltor Losvind log]].
- Later in the season: close open points, act on NX-9400, and review the sensor and compressor results.
- At the end: write a short wrap-up, update this summary and decide whether the trial continues, changes or stops.

I do not put exact dates on these steps. A loose schedule that I follow is better than a tight one I abandon. The only fixed date in this note is the go decision date recorded under Decisions.

The current stage sits in the middle of this arc. The tests are largely done, the logs are in decent shape, and the work now is tidying and the next action.

## Setup

The setup is a single room with the vessels, the sensor, the compressor and the dehumidifier arranged so that each can be reached without disturbing the others.

- The vessels sit together, with the level sensor available to move between them as needed.
- The compressor sits apart from the vessels, with its hose routed so it does not cross walkways. Its checks are written up in [[Pebrurrind air compressor tests]].
- The dehumidifier is placed where air can circulate around it, with its drain easy to reach. Its record is [[Kaethgerk dehumidifier log]].
- A small shelf holds the notebook, cleaning supplies and spare fittings so nothing is carried back and forth.

The setup has been adjusted a little as I learned, mostly to make cleaning easier and to keep the compressor's moisture away from the vessels. I describe it in words here and keep any changes in [[Daeltor Losvind log]], so that the history of the setup is not lost.

The setup is deliberately plain. If it cannot be rebuilt from a short description, it is too complicated for a trial.

## Safety

Safety comes before progress on this project, and the next action never overrides it.

- Compressed air is the main hazard. I release pressure before opening any fitting, check hoses for wear before use and never point air at myself or anyone else.
- Electrical equipment in a damp room needs care. I keep the dehumidifier and any plugs off the floor and away from water, and I check cables for damage.
- Wet floors are a slipping risk, so I wipe up spills at once and keep walkways clear.
- Cleaning products are used as directed, with ventilation, and are never mixed.
- Lifting full vessels is awkward, so I avoid doing it alone and move liquid by transfer where I can.
- I do not work when tired or rushed. A mistake with the compressor or a vessel is not worth the time saved.

If any safety concern arises, I stop, write it into [[Daeltor Losvind log]], and settle it before returning to NX-9400 or anything else. The inspector, as lead, has the final word on whether a concern has been properly resolved.
