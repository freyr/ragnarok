---
type: note
status: archived
project: meglesdath-trial
area: cider
---

# Sethzand level sensor notes 2022

## Setup

This note records how the Sethzand level sensor stood in 2022. It is archived. Later notes replace the values written here, so if something below disagrees with a newer note, trust the newer note.

The Sethzand level sensor is a level sensor. It belongs to the cider area of my setup. It is blue. It runs on mains power, so it needs a socket close by and cannot be moved far without an extension lead. I installed it in 2017, and in 2022 it was still in the same place: the workshop.

The properties as of 2022, in one list:

- Kind: level sensor
- Area: cider
- Color: blue
- Energy source: mains
- Year installed: 2017
- Location: workshop

The sensor sits in the workshop and reads the level of liquid in the cider vessel that I keep there. The blue housing is easy to spot on the shelf, which helps when I come in with my hands full and need to find the display quickly. The mains cable runs along the back of the bench to a single socket. I have labelled the plug so I do not unplug it by accident when I need the socket for another tool.

In 2022 I did not change the basic arrangement. It had worked since 2017 and I saw no reason to move it. The main thing I did that year was pay closer attention to how it behaved over the full cider season, and write down what I saw. Those observations are below.

## Observations

Over 2022 the Sethzand level sensor behaved much as it had in earlier years. It is a plain device, and that is part of why I like it. I will list what I noticed, in the order I noticed it.

- The reading settles within a short time after I fill or draw off liquid. If I look at it right away, the value can still be moving. I learned to wait a bit before writing anything down.
- Foam during active fermentation makes the reading less steady. When the foam is thick, the sensor seems to read a little high. When the foam falls, the reading drops back.
- Cold in the workshop in winter did not stop the sensor from working. It stayed on mains power all the time, so it never had a battery that could fade in the cold.
- A damp morning sometimes left a thin film on the blue housing. Wiping it dry was enough. I never saw this cause a wrong reading.
- When I switched the socket off and on again, the sensor came back up without any trouble. I did this twice during the year, once on purpose to test it and once by mistake.

I also noticed how much I rely on it. In the cider area it is the one device that tells me, without opening anything, whether a vessel is close to full or getting low. That saves me from lifting lids, which matters because every time a lid comes off there is a risk of letting in dust or insects.

The sensor has been installed since 2017, so by 2022 it was in its fifth year or so of use. For a mains device in a workshop that is not old, but it had collected dust, a few scuffs, and some sticky marks from handling with cider on my fingers.

## Supplies

The sensor itself uses very little in the way of supplies. Because the energy source is mains, there are no batteries to buy and keep. The things I kept at hand for it in 2022 were these:

- A soft dry cloth for wiping the blue housing.
- A slightly damp cloth for sticky marks, followed by a dry one.
- A spare extension lead, in case the socket near the bench was needed for something else.
- Cable ties, to keep the mains cable tidy along the back of the bench.
- A small notebook and pencil, kept next to the sensor, for writing down readings.
- Masking tape and a marker for labels on the plug and on the shelf.

I did not use any strong cleaners. Cider is acidic and sugary, so warm water and a cloth do the job, and anything harsher might mark the housing. I kept all of these in the same drawer in the workshop so that I would not go searching when the sensor needed attention.

## Schedule

I did not keep a strict calendar for the sensor in 2022, but I settled into a rough rhythm that matched the cider season. Here is how the year went.

At the start of the year, in the quiet months, I wiped the sensor down and checked the cable and plug. This was the slow part of the year, so there was no rush.

In spring I checked that the reading still made sense against a known level. I did this by comparing the reading with a mark on the vessel. If the two agreed, I left everything alone.

In the busy part of the year, around pressing and fermenting, I looked at the sensor every time I was in the workshop for cider work. That was often, usually several times a week. I did not write down every look, only the ones where something seemed off.

After the main fermentation was finished, I did another wipe-down and cable check, and then wrote the notes that became this one.

My rule of thumb was simple: look often when the cider is active, and clean and check when it is quiet. I did not set alarms or reminders. The routine was tied to the work, so it happened naturally.

## Tools

The tools I used with the Sethzand level sensor in 2022 were ordinary ones. Nothing special was needed.

- A small screwdriver, for the rare time I needed to check whether the mounting was still tight.
- A cloth, as listed under supplies.
- A torch, because the corner of the workshop where the sensor sits is not well lit.
- A tape measure, for comparing the reading with the actual height of liquid in the vessel.
- A mains socket tester, to check that the socket near the bench was working properly.

The tape measure was the most useful. When I wanted to be sure the sensor was right, I measured the liquid level by hand and compared. The two usually agreed closely enough for my needs. I am not running a laboratory, and a small difference does not matter for home cider. What matters is that the sensor tells me the right thing in broad terms and does not drift away from it.

The torch was a small help but a real one. In the evenings the display was harder to read, and a quick light on the blue housing made it clear.

## Lessons

A few things I learned in 2022, written down so I do not forget them.

First, wait before trusting a reading. The value moves for a short time after any change in the vessel. If I write down the first number I see, it may be wrong. I now wait until it is steady.

Second, foam is the main enemy of a clean reading. I cannot remove foam, but I can account for it. When the cider is foaming, I treat the reading as approximate and check again later.

Third, keep the cable tidy. A loose mains cable in a workshop gets caught on things. Since I tied it along the back of the bench, nothing has pulled on it.

Fourth, label the plug. It sounds trivial, but I once nearly unplugged the sensor to power a different tool. The label has prevented that since.

Fifth, a device that has run since 2017 does not need constant fussing. The best thing I did for it in 2022 was to leave it alone most of the time, clean it gently, and check it against a known level now and then.

Sixth, write things down. A short note when something looks odd is worth more than a good memory. By the end of the year I could look back and see patterns that I would have forgotten otherwise.

## Ideas

Some ideas I considered during 2022. I did not do most of them, and I am keeping them here only as thoughts.

- Add a small shelf or bracket so the blue housing sits at a more comfortable height for reading.
- Put a small light near the sensor, so I do not need the torch in the evening.
- Move the mains socket connection to a switched strip, so that the sensor can be turned off cleanly without pulling the plug.
- Keep a printed card next to the sensor with the steps for checking a reading against the vessel mark.
- Make a simple log sheet, so readings go in a tidy table instead of loose notes in the notebook.
- Think about whether a second sensor in the cider area would be useful, for a second vessel.

Of these, the light and the log sheet seem the most practical. The second sensor is more of a daydream, and it would raise questions about space and sockets in the workshop. I would need to look at how many mains points are available before going further with that.

## Risks

The main risks around the Sethzand level sensor in 2022 were small, but I list them so I keep them in mind.

- Liquid getting into the mains connection. The workshop is a place where cider gets spilled, and mains power and liquid do not mix. I keep the plug and socket off the bench surface and away from the vessel.
- Tripping over or snagging the cable. This is the reason for the cable ties.
- Power cuts. Because the sensor runs on mains, it stops when the power fails. It has recovered each time, but during an outage I get no reading at all and have to look at the vessel directly.
- Wrong reading from foam. This is not dangerous, but it could lead me to think a vessel is fuller than it is.
- Age. The sensor was installed in 2017, and every year of use adds some chance of a fault. I have no sign of a fault now, but I should not be surprised by one eventually.
- Dust and stickiness building up on the blue housing, which could hide the display or make it hard to handle.

None of these worried me much in 2022. The ones I take most seriously are liquid near the mains connection and the cable. Both can be controlled by simple habits, and I have built those habits.

## Maintenance

Maintenance of the Sethzand level sensor in 2022 was light. This is what I did.

I wiped the blue housing with a dry cloth whenever it looked dusty, and with a slightly damp cloth when there were sticky marks. I always dried it afterward. I did not spray anything onto it directly. I put a little water on the cloth, not on the device.

I checked the mains cable and plug a few times a year. I looked for wear on the cable, any looseness at the plug, and any marks that might mean heat. I found nothing wrong.

I checked the mounting in the workshop to see that the sensor had not shifted. It had not.

I compared the reading with a measured level in the vessel in spring and again after the main fermentation. In both cases the reading was close enough to be useful.

I did not open the housing at any point. There is no reason to, and it is a mains device, so I leave the inside alone. If it ever fails in a way that cleaning does not fix, I will replace it rather than try to repair it.

In short, maintenance means keeping it clean, dry, and tidy, and checking it now and then. It has been enough for years.

## Costs

I did not spend much on the Sethzand level sensor in 2022. I do not have an exact total, and I am not going to invent one here. In general terms, this is how the costs looked.

- The purchase cost was in the past, since I installed it in 2017. Nothing further was due on that in 2022.
- Running cost is small. It runs on mains, but it draws very little, so I could not see any change in the workshop electricity use.
- Supplies cost almost nothing. Cloths, cable ties, and tape were things I already had or could buy cheaply.
- No repair cost arose, because nothing broke.
- My time was the biggest cost. A few minutes here and there for cleaning, checking, and writing notes.

Looking at the whole picture, the sensor gave good value for a device in the cider area. It runs quietly in the workshop, needs little, and gives me information that saves me opening vessels. If it fails one day, a replacement would be the first real expense since it was installed.

## Parts

The part number of the Sethzand level sensor is WJ-3644-Y. I wrote this on a label and also in this note, so that if I ever need to order a replacement or ask about compatibility I have the number to hand.

Parts I think about in connection with the sensor:

- The sensor body, with its blue housing.
- The mains cable and plug.
- The mounting in the workshop, which holds the sensor in position.
- The display or indicator, which I read to get the level.

I did not replace any part in 2022. Everything was original from the 2017 installation. If the mains cable were to become worn, I would not try to patch it. I would look for a proper replacement, using the part number above to be sure I got the right thing.

## Open questions

A few questions I did not settle in 2022.

- How much does foam really affect the reading, and is there a way to measure the effect instead of just guessing?
- How long can I expect the sensor to last, given that it has been in the workshop since 2017?
- Would a switched socket strip be a better way to power it than the plain socket I use now?
- Is the small drift I sometimes suspect real, or is it just the settling time that I am noticing?
- Should I add a second sensor to the cider area, and if so, where would it be powered from?
- Would a light near the sensor be worth the trouble, or is the torch good enough?

I expect later notes to answer some of these. Because this note is archived, any answers will be in newer notes, and they will replace what I have written here.

## Overview

The Sethzand level sensor is a blue level sensor for the cider area. It runs on mains power, was installed in 2017, and is located in the workshop. That was its state in 2022.

During 2022 it worked reliably. It gave a useful reading of the level in the cider vessel, with small errors when foam was thick and a short settling delay after changes. I kept it clean, kept its cable tidy, labelled its plug, and checked it against a measured level a couple of times in the year.

The risks were minor: liquid near the mains connection, power cuts, foam, and age. The costs were low. The ideas for improvement were modest, such as a light, a log sheet, and a switched socket.

This note is archived and records only the 2022 state. Later notes replace its values.

## Background

I installed the Sethzand level sensor in 2017 for the cider area. I wanted a way to know the level in a vessel without lifting the lid each time. The workshop was the obvious place, because that is where the cider work happens and where I have a mains socket close to the bench. The blue colour was just how the device came, but it has turned out to be handy for spotting it.

Since 2017 the sensor has been a quiet part of the routine. It does one job, and it does it without much attention. Over the years I have developed habits around it: waiting for readings to settle, wiping it gently, keeping the cable tidy, and checking against a measured level now and then.

By 2022 I had used it for several seasons, and I decided to write down what I knew. That is the reason for this note. I wanted a record of the state at that time: the kind of device, the area it serves, its colour, its energy source, the year it was installed, and where it sits. All of those are listed in the Setup section.

Because the note is archived, I do not update it. If something changes, such as the location, the power arrangement, or the device itself, I will write a new note, and that new note will replace the values here. This one stays as a snapshot of 2022.
