---
type: plan
status: active
project: meglesdath-trial
area: cider
description: "Plan about Riothdrer dehumidifier."
---

# Riothdrer dehumidifier plan

## Supplies

This plan covers the Riothdrer dehumidifier, a red dehumidifier that runs on mains power. I installed it in 2025 in the greenhouse, and it serves the cider area. The point of the plan is to keep the air in the greenhouse dry enough that the cider equipment, labels, and stored crates do not go mouldy or rust.

What I need on hand for upkeep and checks:

- A clean cloth and a soft brush for the grille and the intake.
- A small bucket or jug, in case the tank has to be emptied by hand.
- A spare length of drain hose, in case the current one cracks.
- A screwdriver set for the side panel.
- A notebook, or this note, for logging readings.
- A hygrometer that I trust, placed away from the unit.
- A mains extension lead rated for damp places, only as a backup and never as the normal connection.
- A torch, because the greenhouse corner behind the barrels is dark in the evening.
- Mild soapy water for the tank. No harsh cleaners, since they leave smells that the cider could pick up.

I keep these in the plastic box under the bench so I do not have to hunt for them.

## Schedule

I am setting a simple routine so that the work does not depend on my memory. The unit is always on mains, so the main task is checking it rather than operating it.

| Frequency | Task | Notes |
|---|---|---|
| Daily | Glance at the hygrometer | Write down only if the reading looks odd |
| Weekly | Empty and rinse the tank if not draining | Check the hose for kinks |
| Weekly | Wipe the intake grille | Dust builds up fast near the barrels |
| Monthly | Brush the coils and check the fan | Switch off at the wall first |
| Seasonal | Full clean, test the level sensor | See the sensor notes linked below |
| Yearly | Review the placement and the log | Decide if the unit should move |

The busiest period is autumn, when the cider is being pressed and the greenhouse is damp from fruit and washing. In that period I move to checking twice a week. In deep winter the greenhouse is cold, and the unit pulls less water out of the air, so I do not expect much in the tank then.

For the float and level sensor I follow the approach in [[Sethzand level sensor notes 2022]]. Those notes explain how I tested a similar sensor and what went wrong with the wiring and the float travel. I reuse the same steps: lift the float by hand, listen for the click, and confirm the unit stops.

## Observations

Since installing the dehumidifier in 2025, I have noticed a few things worth keeping.

The red casing shows dust and splashes quickly, so it is easy to see when it needs a wipe. That is a small benefit, because I notice neglect sooner.

The unit works best when it has space around it. When I pushed it against the wall, the intake grille clogged, and the readings on the hygrometer climbed again within a few days. With a gap behind it, the air moves properly and the humidity holds steadier.

The tank fills faster than I expected in the weeks after pressing. On those days I would find it full and the unit shut off by its sensor. That is correct behaviour, but it means the room stays damp until I empty it. A drain hose to the gutter solves that, as long as the hose slopes down the whole way.

The noise is acceptable. The fan hum is audible in the evening but does not bother me in the greenhouse. It would be annoying in a living room.

Mains power has been reliable. The only issue was a tripped breaker after heavy rain, which came from a damp socket and not from the unit. I moved the plug higher up and sealed the socket cover.

Condensation on the glass is lower since the unit started running, which also means fewer drips onto the equipment below.

## Lessons

- Leave space around the unit. A gap behind and beside it matters more than I thought.
- Do not rely on the tank alone in the damp season. A hose to a drain is better.
- Keep the plug and socket off the floor and protected. Water in a greenhouse gets everywhere.
- Test the float sensor on a schedule, not only when something looks wrong. The older sensor notes showed me how a stuck float can look like a broken unit.
- Keep the hygrometer away from the dehumidifier outlet, or it reads too dry and gives a false comfort.
- Write down what I change. When I could not remember why I moved the unit, the log saved me from moving it back.
- Clean the intake before blaming the machine. Most "weak" days were just dust.
- Cider stores best when the air is steady, not just dry. Swings in humidity caused more problems than a moderately high level that stayed constant.

## Adjustment

The level sensor and the humidity control needed a small correction after I compared the unit against my own hygrometer. The unit was reading a little off, so I applied a calibration offset of 2.575 mm to the float position so that the shutoff happens at the right tank level.

Steps I used:

1. Switch the unit off at the wall and unplug it.
2. Remove the side panel and find the float arm.
3. Measure the travel of the float from rest to the point where the switch clicks.
4. Shift the stop so that the travel matches the target, using the offset above.
5. Refit the panel, plug in, and fill the tank slowly to confirm the shutoff.

After this, the unit stopped overfilling the tank and stopped shutting off too early. I will recheck the offset each season, because the plastic can settle and the position can drift. If the shutoff starts to feel wrong again, I check the float for algae or residue before touching the stop.

## Overview

Here is the full picture of the Riothdrer dehumidifier in one place.

- Kind: dehumidifier
- Area: cider
- Colour: red
- Energy source: mains
- Year installed: 2025
- Location: greenhouse

The job is to keep damp under control around the cider work. It sits in the greenhouse, where the air gets humid from pressing, washing, and plants. The plan is light on purpose: a short routine, a few supplies, and a habit of writing things down.

What success looks like for me: no mould on crates or labels, no rust on the tools, a tank that does not overflow, and a hygrometer reading that stays in a steady range through the season. If those hold, I leave the setup alone. If they do not, the first things I check are the intake, the hose, and the float, in that order.

Open questions for later: whether a second smaller unit would help at the far end of the greenhouse, and whether I should add a simple timer for the quiet winter weeks. I will decide after a full year of notes on the current setup.

## Tools

The tools I actually use, and what each one is for:

- **Hygrometer**: the reference reading. I trust it more than the unit's own display, and I keep it at shoulder height, away from the outlet.
- **Soft brush**: for the intake grille and the coils. A stiff brush bends the fins.
- **Cloth**: for the casing and the tank, kept separate from the cloths I use near the cider.
- **Screwdrivers**: for the side panel and the float stop.
- **Ruler or calipers**: for measuring float travel when I make the adjustment.
- **Drain hose**: sloped downhill to the gutter, checked weekly for kinks.
- **Torch**: for the dark corner behind the barrels.
- **This note**: the log. I add a line after each seasonal check and after any change to the position or the sensor.

If I add anything new, such as a timer or a second unit, it goes in this list and in the schedule table so the routine stays in one place.
