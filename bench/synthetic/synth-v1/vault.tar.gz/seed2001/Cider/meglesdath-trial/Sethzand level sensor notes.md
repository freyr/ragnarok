---
type: note
status: active
project: meglesdath-trial
area: cider
description: "Note about Sethzand level sensor."
---

# Sethzand level sensor notes

## Open questions

These are the things I still don't know about the Sethzand level sensor. I add to this list whenever something odd happens and cross items off once I have an answer.

- Why does the reading wobble for a short while right after the pump next to it starts? I suspect electrical noise on the mains side, but I have not proven it.
- Is the blue housing really sealed against steam, or has it just been lucky in the workshop so far?
- Would moving the sensor a little further from the wall change the drift I see on cold mornings?
- Should I replace it with a [[Partonber level sensor]] at some point, or is that a side-grade at best?
- Does the sensor behave differently when the vessel is nearly empty versus nearly full? I have only a loose feeling about this and no proper notes.

## Overview

The Sethzand level sensor is a device of the kind "level sensor". It belongs to my cider area and it lives in the workshop. The housing is blue, which makes it easy to spot among the grey and black gear on the bench shelf. It runs from mains power, so there is no battery to forget about, though it also means I have to think about where the cable runs and what else shares the socket. I installed it in 2017.

Here are the properties in one place so I don't have to hunt for them later:

| Property | Value |
|---|---|
| Kind | level sensor |
| Area | cider |
| Color | blue |
| Energy source | mains |
| Year installed | 2017 |
| Location | workshop |

In plain terms, the sensor tells me how full a vessel is without my having to climb up and look. For cider this matters most during the busy weeks, when several vessels are filling, settling or being topped up and I can't watch them all. It has been in service for a long time now. It has never been the star of the show, but when it fails I notice immediately.

I keep these notes for myself. They are not a manual. The real manual is a thin booklet in the drawer under the bench, and I only copy from it what I actually use.

## Setup

The sensor sits in the workshop, close to the cider vessels and the bench where I do the measuring and logging. It was installed in 2017, and the setup has barely changed since. That is part of why I trust it.

How it is arranged:

- The unit is mounted on a bracket so the blue housing faces outward and the status light can be seen from the bench.
- Power comes from a mains socket on the workshop wall. It is a dedicated spot on the strip, not shared with the heavy tools.
- The cable runs along the wall and then drops down to the sensor. I tied it up with clips so it can't be pulled by anyone walking past.
- The sensing end points at the vessel and is kept clear of anything that could touch it, such as hoses or stirring paddles.

When I first set it up, I did it in this order. First I fixed the bracket and checked it did not move when pushed. Then I connected power and waited for the status light to settle. Then I filled the vessel a little at a time and watched how the reading followed. Finally I compared the reading against a simple stick measurement. The two agreed closely enough for my purposes, and I wrote down that I should repeat the comparison whenever something is changed.

If I ever need to rebuild the setup, the important parts are the stable mount, the clean power, and the unobstructed sensing end. Everything else is detail.

For the related flow side of the workshop, I wrote up how the pump behaves in [[Rundtru circulation pump tests]]. That note matters here because the pump and the sensor share the same wall and, I suspect, the same electrical noise.

## Background

I got the Sethzand level sensor in 2017, when I decided I was tired of guessing how full things were. Before that I used a plain wooden dipstick and my own memory, and both let me down. A dipstick means opening a lid, and opening a lid at the wrong moment is not great for cider. A sensor that reads from outside, or at least without disturbing the contents, solved that.

I picked a mains-powered unit on purpose. Battery devices in my workshop tend to die at the worst time, usually in the middle of a busy week, and I never remember the replacement schedule. Mains power removes that whole category of problem. The tradeoff is that a power cut leaves me blind, and I accepted that.

The blue color was not a deliberate choice, it is just what the unit came in. It has become useful anyway. In my workshop, blue means "level" and I have no other blue device nearby, so I can point at it from across the room.

Over the years the sensor has become part of my routine. I check it in the morning, again before I leave, and any time I move liquid. It sits alongside my notes on the kiln side of the workshop, which I keep in [[Delnandnir kiln controller notes]], and the heat side, which is covered in [[Bivand heat exchanger handbook]]. They are different jobs, but the habits are similar: look at the number, compare it with what I expect, write down anything strange.

I have also looked at an alternative, described in [[Partonber level sensor]]. I haven't switched. The Sethzand does what I need, and I know its habits.

## Parts

The part number of the Sethzand level sensor is TA-9721-F. I keep it here so I can quote it when ordering a spare or asking someone about the unit. It is printed on the label on the underside of the housing, which is awkward to read once the unit is mounted, so this is the copy I use.

What the unit consists of, as far as I can tell:

- The blue housing, which holds the electronics and the status light.
- The sensing end, the part that actually looks at the vessel.
- The mains lead, fixed to the housing.
- The mounting bracket, which I treat as part of the installation rather than part of the sensor.
- A small set of fixings that hold the bracket to the wall.

Notes on each:

**Housing.** Blue plastic, no cracks so far. The lid seam is the thing I watch. If moisture ever gets in, it will be there.

**Sensing end.** This is the part most likely to give trouble because it is closest to the action. Residue builds up, and a dirty sensing end gives false readings. Cleaning it gently is the first fix for most odd readings.

**Mains lead.** Fixed, not removable. That means if the lead is damaged, the whole unit goes. I keep the lead away from sharp edges and from hot surfaces.

**Bracket and fixings.** The bracket is metal and has held up well. I check the fixings occasionally because vibration from the pump can loosen things over time.

If something breaks, the order of likelihood in my experience is: dirty sensing end first, loose bracket second, then everything else a long way behind.

## Supplies

Things I keep on hand so the sensor never has to wait for a trip to the shop:

- Soft cloths that leave no lint, for wiping the housing and the sensing end.
- Mild cleaning solution that is safe around food equipment. Nothing harsh, nothing with a strong smell.
- A small soft brush for the crevices around the sensing end.
- Spare cable clips, because they crack and I always seem to need one more.
- A few spare fixings for the bracket.
- Notebook and pencil, kept beside the sensor so I can log readings straight away.
- A plain measuring stick for cross-checking the sensor against the real level.

I don't keep a spare sensor. If it dies in the middle of a busy period, I will fall back on the measuring stick, which is slower but works. If I ever decide a spare is worth having, the part number in the Parts section is what I would quote.

I also keep a spare mains adapter strip in the cupboard in case the one the sensor uses fails. It is cheap insurance, and a bad strip is more likely than a bad sensor.

## Checklist

This is my routine checklist. I run through it when I do a proper check, not every time I glance at the sensor.

- Look at the status light. It should be steady, not flickering.
- Read the level and compare it with the measuring stick.
- Check that the sensing end is clean and clear of obstructions.
- Make sure the blue housing is dry and free of cracks.
- Tug lightly on the bracket to confirm it is firm.
- Look along the mains lead for damage, kinks or heat marks.
- Confirm the socket and strip are in good condition and not overloaded.
- Write down anything unusual in the Observations section.

If any of these fail, I stop and fix that first. I don't carry on and hope. A sensor that gives a wrong number is worse than no sensor, because I will trust it.

## Safety

The sensor runs from mains power and lives in a workshop where liquids are moved around. That combination calls for care.

- Always unplug the unit before cleaning it or touching the lead. Never clean it while it is live.
- Keep liquid away from the socket and the strip. If something spills, switch off at the wall before going near it.
- Do not open the housing. There is nothing in there I should be fiddling with, and it is a mains device.
- If the lead is damaged in any way, stop using the unit. Don't tape it up and carry on.
- Keep the floor around the socket clear and dry so I am not standing in a puddle while handling plugs.
- Do not overload the strip. The pump, lights and other tools draw a lot, so the sensor gets its own spot.
- Keep a clear path to the wall switch so I can cut power quickly.

Where the workshop has heat nearby, such as the kiln covered in [[Delnandnir kiln controller notes]], I keep the sensor lead well away from hot surfaces. Heat softens insulation, and I would rather avoid finding that out the hard way.

If the sensor ever gets very wet, I treat it as suspect until it has been dried out and checked by someone who knows what they are doing. I would rather replace it than gamble with mains electricity.

## References

Notes and documents I rely on when thinking about this sensor:

- [[Partonber level sensor]], my notes on the alternative unit I considered.
- [[Rundtru circulation pump tests]], for how the pump behaves and how it may affect the sensor.
- [[Delnandnir kiln controller notes]], for the other mains-powered equipment in the workshop and the heat questions around it.
- [[Bivand heat exchanger handbook]], for the heating and cooling side that determines how the vessel contents behave.
- The thin manufacturer booklet in the drawer under the bench, which covers wiring and the meaning of the status light.

I try to keep this list short. If a reference isn't something I have actually used, it doesn't belong here.

## Maintenance

Maintenance on this sensor is mostly cleaning and looking. It has been running since 2017 with very little fuss, and I want to keep it that way.

**Cleaning.** The sensing end gets a gentle wipe with a soft cloth and mild solution. For stubborn residue I use the small brush, lightly. I never scrape. After cleaning, I dry the unit fully before powering it up again.

**Inspection.** I look over the housing for cracks, check the seam, and run my eye along the lead. I also check the bracket, because a loose bracket changes the angle of the sensing end and gives a quietly wrong reading.

**Calibration check.** I compare the sensor against the measuring stick. If the two disagree by more than I can tolerate, I clean first, then re-check, and only then start suspecting the unit itself.

**Power.** I check the socket and strip now and then. A flaky connection can look like a sensor fault when the sensor is perfectly fine.

**Records.** I note what I did and what I found, so that over time I can see patterns. For example, the sensing end seems to need cleaning more often during the heaviest cider weeks, which makes sense given the extra handling and splashing.

The things I don't do: I don't open the housing, I don't repair the lead, and I don't try to modify anything. If it needs more than cleaning and tightening, it is time to replace it.

## Schedule

I run maintenance on a loose rhythm rather than by the calendar, because the workshop's workload varies a lot through the year.

| Task | When |
|---|---|
| Glance at status light and reading | Every day I am in the workshop |
| Compare against measuring stick | Weekly during busy cider weeks, otherwise now and then |
| Wipe sensing end and housing | After any splash or spill, and at least once a month |
| Check bracket and fixings | Monthly |
| Inspect lead, socket and strip | Seasonally |
| Full checklist | At the start and end of the cider season |

Around the start of the cider season I do the whole checklist and a proper clean. At the end of the season I do it again before things go quiet, so that the sensor is in good shape when I come back to it.

If the pump tests in [[Rundtru circulation pump tests]] are being repeated, I add a sensor check at the same time, since the two interact. The same goes for any work on the heating side that I note in [[Bivand heat exchanger handbook]].

I try not to over-plan this. The point of a schedule is that I actually follow it, and a simple one gets followed.

## Observations

These are my running impressions of how the Sethzand level sensor behaves, written in plain terms and not as measurements.

- It is steady most of the time. Once settled, the reading holds well and moves smoothly as the level changes.
- On cold mornings the reading sometimes sits a touch off until the workshop warms up. It corrects itself, but it makes me wonder about temperature effects.
- Right after the pump starts, the number can jump briefly and then calm down. I have not worked out whether the cause is electrical noise or real movement of the liquid. It is on my list of open questions.
- A dirty sensing end gives a reading that creeps slowly in one direction. Cleaning brings it straight back.
- With a nearly empty vessel, the reading seems less trustworthy than in the middle of the range. I would like to test this properly.
- The status light has always been reliable. If it flickers, something is wrong with power or connection, not with the vessel.
- The blue housing looks the same as the day it went up. No fading, no warping, even with the heat of the workshop.
- In all its years it has never failed outright. It has only ever misled me when it was dirty or when something nearby was changing.

I have been comparing these impressions with what I know about the [[Partonber level sensor]]. So far I see nothing that would make me want to swap. The Sethzand does its job, and its quirks are familiar ones.

## Tools

What I use when working on or around the sensor:

- A soft cloth and a small soft brush, for cleaning.
- A plain measuring stick, for checking the real level.
- A screwdriver that fits the bracket fixings, for tightening.
- A torch, because the corner where the sensor sits is dim and I need to see the seam and the lead.
- A notebook and pencil, for logging readings and anything odd.
- A simple socket tester, to confirm the wall socket is wired and behaving.
- Cable clips and a pair of snips, for tidying the lead.

I don't need anything fancy. The sensor is simple to look after, and the main tool is attention. I try to avoid using metal tools near the sensing end, in case I scratch it.

When I do any electrical checking beyond the socket tester, I either get help or leave it alone. I keep the safety rules from the Safety section in mind every time.

## Problems

Problems I have run into, or think I might, with what I do about each.

**False or drifting readings.** Almost always a dirty sensing end. I unplug, clean gently, dry, power up and compare against the measuring stick. This solves it nearly every time.

**Reading jumps when the pump starts.** Annoying but harmless so far. I wait a short while before trusting the number. I want to look into whether a different socket or a separate strip would help, and I plan to compare notes with [[Rundtru circulation pump tests]].

**Reading off on cold mornings.** It corrects as the room warms. I note it and move on, but if it gets worse I will look at moving the sensor away from the cold wall.

**Loose bracket.** Vibration can loosen the fixings, which tilts the sensing end and skews the reading. I tighten them and check again with the stick.

**Status light flickers or goes out.** I check the socket, the strip and the lead first. If the lead looks damaged, I stop using the unit and replace it, quoting the part number from the Parts section.

**Moisture in or around the housing.** This is the one I take most seriously because it is a mains device. I unplug at the wall, dry everything, and do not power up until I am sure it is dry. If in doubt, I replace the unit.

**Power cut.** The sensor is blind without mains. I fall back on the measuring stick and keep the vessel readings by hand until power returns.

Whenever a new kind of problem shows up, I write it here with the fix, and add any unanswered question to the top of the note under Open questions.
