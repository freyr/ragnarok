---
type: note
status: active
project: meglesdath-trial
area: cider
---

# Delnandnir kiln controller notes

## Lessons

The Delnandnir kiln controller is a green, battery-powered kiln controller that I installed in 2021. It sits in the loft, and I use it for the cider work. Most of what I know about it comes from living with it, so I am writing the main lessons down here.

**Battery first.** Because the energy source is a battery, a weak charge shows up as odd readings long before the display goes dark. If the temperature curve looks jumpy, I check the battery before I touch any setting. I now keep a spare charged and labelled on the shelf by the loft ladder.

**The loft changes things.** The loft gets warm in summer and cold in winter. The controller drifts a little with the room, so I compare it against a second reading whenever the season changes. Notes on the room itself are in [[Dalsti loft]], and the day-to-day entries are in [[Nastae loft log]].

**Do not trust one reading.** When I was unsure, I cross-checked against the older unit, see [[Drilvark kiln controller]]. The two agreed once I fixed the offset below. I also leaned on [[Nermior level sensor tests]] for how I judge a sensor that disagrees with the rest.

**Keep the heat side in mind.** The controller only switches the heat. Any change to the exchanger layout should be planned in [[Vioskrirk heat exchanger plan]], and the background reading is in [[Bivand heat exchanger handbook]]. When the [[Rindtrith air compressor]] runs nearby, the loft noise and vibration are worth a glance, since a loose lead has bitten me before. Comparison runs are written up in [[Bothkan Belstark tests]].

**Write changes down.** Every time I change a value, I log it the same day. Without that, I forget which setting produced which batch.

## Adjustment

The controller read slightly off compared with the reference, so I applied a correction. The calibration offset of the Delnandnir kiln controller is 1.808 mm. I keep it in the settings as shown below, so I can restore it after a battery swap or a reset.

```
device: Delnandnir kiln controller
location: loft
energy_source: battery
year_installed: 2021
calibration_offset: 1.808 mm
```

Steps I follow when I re-check it:

1. Fit a fresh battery and let the unit settle for a while.
2. Compare it with the reference reading in the loft.
3. Apply the offset above if the gap has come back.
4. Log the result in [[Nastae loft log]].

If the gap is still there after the offset is applied, I suspect the battery or a loose lead, not the offset. I check those first and leave the stored value alone.
