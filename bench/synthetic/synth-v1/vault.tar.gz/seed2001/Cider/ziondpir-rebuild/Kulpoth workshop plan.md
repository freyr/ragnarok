---
type: plan
status: active
project: ziondpir-rebuild
area: cider
description: "Plan about Kulpoth workshop."
---

# Kulpoth workshop plan

## Costs

This section is a plan for how I think about money at the Kulpoth workshop. I am not writing down prices here. The point is to know which spending comes first and which can wait.

The workshop is a small building, and that keeps most costs low. A small space needs little heating, little lighting and few shelves. It was built in 2001, so the structure is old enough that some repair money should always be set aside. The floor is raised, which means the space under it stays dry but also means any repair to the floor frame is awkward and needs planning.

Spending priorities, in order:

- Anything that stops water, damp or pests from reaching the raised floor. This comes before everything else.
- Replacing worn consumables for the cider work: cloths, seals, brushes, cleaning powder and sanitiser.
- Small upgrades to monitoring, such as the [[Partonber level sensor]], so I stop checking vessels by eye.
- The circulation upgrade described in [[Triothglis circulation pump plan 2024]]. It is useful, but not urgent.
- Cosmetic work, which is last on the list.

Rules I follow so costs stay under control:

- Buy one good version of a tool rather than two cheap ones.
- Check the shelves before ordering anything. I often already have it.
- Keep every receipt in one folder, and note the purpose on the back.
- Do not start a repair in the cider season unless something is leaking.

I want one review each year, after the main pressing period ends, where I list what broke, what I replaced and what I postponed. That review is the real budget.

## Tools

The workshop is small, so tools must earn their space. Everything lives on the wall or under the bench, and nothing stays on the floor.

Core hand tools:

- A set of spanners and adjustable wrenches for fittings.
- A rubber mallet for bungs and fitted lids.
- A long-handled brush for the inside of vessels.
- A hydrometer and a measuring jar.
- A siphon tube with a clip.
- A small funnel and a larger funnel with a strainer.
- A torch with a head strap, because light inside the south-facing room is good by day but poor after dark.

Cleaning kit:

- A bucket for sanitiser and a separate bucket for rinse water.
- Spare cloths, kept in a sealed tub.
- A spray bottle for surface cleaner.
- A pair of gloves for each task, not shared between wet and dry work.

Monitoring and flow:

- The [[Partonber level sensor]] for checking how full a vessel is without opening it.
- A pump for moving liquid, planned in [[Triothglis circulation pump plan 2024]].
- A thermometer on the wall, placed away from the south window so the sun does not skew the reading.

Storage rules: heavy tools go low, sharp tools go high and out of reach of the door, and anything that rusts goes in a dry box. Because the floor is raised, I keep a mat at the entrance so mud does not get carried onto the boards.

## Maintenance

Maintenance at the Kulpoth workshop falls into daily, seasonal and yearly jobs. Keeping them separate stops me from forgetting the dull ones.

Daily or each-visit jobs:

- Wipe the bench and sweep the floor.
- Check for drips under every vessel and joint.
- Look at the thermometer and note anything odd.
- Close the window shutters if the sun has been strong, since the room faces south and warms quickly.

Seasonal jobs:

- Before the cider season, deep-clean all vessels, hoses and fittings. Replace any seal that looks stiff or cracked.
- After the season, drain everything, rinse twice and leave surfaces dry.
- Check the underside of the raised floor for damp, mould, chewed wood or gaps. The raised floor is a strength, but only if air can move beneath it.
- Test the pump and sensor. The [[Partonber level sensor]] needs its contacts wiped, or the readings drift.

Yearly jobs:

- Inspect the roof, gutters and walls. The building dates from 2001, so I expect age-related wear in the joints and trim.
- Treat exposed timber on the south side, which takes the most sun and weather.
- Test the lights and sockets, and replace anything that flickers.
- Re-read the notes in [[Daeltor Losvind log]] for patterns in what failed.

A simple rule: if I fix something twice, I stop patching and make a proper plan to replace it.

## History

The workshop was built in 2001. It was designed as a small, single-purpose building, and it has stayed small. The raised floor was part of the original construction, not a later addition. I think the builders wanted to keep the work area clear of ground damp, which is a sensible choice for a place that handles liquids all the time.

The south orientation is also original. It gives plenty of natural light and some welcome warmth in the cooler months, but it makes summer work harder. Over the years I have learned to schedule delicate tasks for mornings or evenings.

How the use of the place has developed:

- At first it was a general workshop, with a bench, some shelves and not much else.
- Over time the work shifted toward cider, and the layout changed around that: vessels along the wall, a clean bench, a dry corner for dry goods.
- Monitoring equipment arrived later, along with ideas for better circulation.
- I started keeping a written log, which became [[Daeltor Losvind log]].

I do not have a complete record of everything done in the early years. Some of the older fittings were already in place when I took over, and I do not know where they came from. That is one reason I keep better notes now.

## Background

The Kulpoth workshop is a place I use for cider work. Its details, stated plainly:

- Kind: workshop
- Area: cider
- Orientation: south
- Size: small
- Year built: 2001
- Floor: raised

Each of these affects how I work there.

Because it is a workshop, not a shed or a store, it needs to be a place where I can stand, work and clean up. I do not leave things there that have no job to do.

The cider focus shapes the rules about hygiene. Everything that touches juice or cider must be cleanable, and I avoid materials that hold smells or moisture.

The south orientation means strong light and heat. It helps with drying and with seeing detail, but it needs shade control.

The small size means a tight layout. I can touch most things from one spot, which is convenient, but two people working at once get in each other's way.

The year 2001 tells me the building has some age. I should expect gradual wear rather than sudden failure.

The raised floor keeps the room off the damp ground and helps airflow, but it needs checking from below and has to be kept sound.

For related thinking, see [[Naesnirra Piondgirk notes]], which cover some of the general principles I borrow when planning the space.

## Ideas

These are things I might try. None is committed.

- Add a simple shade over the south window, either a blind or a small outside canopy, to cut summer heat without losing winter light.
- Fit a shelf rail along one wall so that small tools hang in a fixed order, with an outline drawn for each one.
- Install the circulation pump from [[Triothglis circulation pump plan 2024]] and compare how it changes the work with my current method.
- Mount the [[Partonber level sensor]] on a second vessel so I can compare readings across two containers.
- Build a folding bench extension for busy days, which can be put away to keep the floor clear.
- Put small vents or a grille in the skirting under the raised floor to improve airflow.
- Make a laminated checklist for start-up and shut-down, hung by the door.
- Paint the inside walls a pale colour that reflects light and shows dirt more clearly.
- Keep a small notebook on a hook, so I stop writing observations on loose paper.

If I try any of these, I will record the result in [[Daeltor Losvind log]], including the ones that did not work.

## Problems

Known problems at the Kulpoth workshop, with notes on what I plan to do about each.

**Summer heat.** The south orientation brings strong sun, and the small room warms fast. Temperature swings can upset the work. Short term, I use shutters and time the work around the day. Longer term, see the shade idea above.

**Damp under the floor.** The raised floor should help, but if airflow is blocked, damp collects. I have to check it regularly. Leaves and debris against the foundation are the usual cause.

**Limited space.** The workshop is small, and when it gets cluttered, cleaning becomes harder and mistakes are more likely. A strict rule of one place per tool is the only real answer.

**Ageing fittings.** Some parts date back to the original build in 2001 or soon after. Seals, hinges and catches wear out. I replace them as they fail, but I would rather replace them before they do.

**Sensor drift.** The [[Partonber level sensor]] sometimes gives readings that do not match what I see. Usually it needs cleaning, but I should keep a note of when the readings go wrong, in case there is a deeper fault.

**Flow and circulation.** Moving liquid by hand takes time and risks spills. The pump plan in [[Triothglis circulation pump plan 2024]] is meant to deal with this, but it is not done.

**Poor evening light.** The room is bright by day and dim at night. I use a head torch, but a fixed lamp would be safer.

**Gaps in records.** I do not know the origin of some older parts. When something fails, I have to guess what it was. Better notes would help, which is what [[Daeltor Losvind log]] is for.

## Admin

Administrative details for the workshop, kept in one place so I can find them quickly.

- Lease reference: LR-557871
- Kind: workshop
- Area: cider
- Orientation: south
- Size: small
- Year built: 2001
- Floor: raised

Admin habits:

- Keep the lease paperwork in a labelled folder, not in the workshop itself, where damp could reach it.
- Quote the lease reference whenever I contact anyone about the premises.
- Note any change to the building, however small, because lease terms may care about alterations. Check before doing anything structural, such as altering the raised floor or the south wall.
- Keep a copy of important documents in digital form as well as on paper.
- Record who has a key, and when it was given out.
- Write down any agreement made by phone, along with the topic and the outcome, soon after the call.

For wider planning ideas that I sometimes reuse for paperwork and routines, I look at [[Naesnirra Piondgirk notes]]. Anything that touches equipment decisions goes into the plan note for that equipment, not here.
