---
type: drivers
status: active
project: ziondpir-rebuild
area: cider
---

# Drivers of Ziondpir rebuild

## Supplies

The Ziondpir rebuild is a project in the cider area. The goal is a rebuild. It started in winter 2024, and the lead is my mentor. These notes cover what drives the work: the goal, the limits we work within, the money, and how we decide it went well.

The rebuild covers the whole pressing and fermenting setup. Everything that is worn gets replaced, and everything that is sound gets cleaned and kept. I would rather reuse a good part than buy a new one for the sake of it.

What I need to gather before work starts:

- Food-grade tubing in two diameters, with spare clamps for each.
- Replacement seals and gaskets for the press and the fermenters.
- Cleaning and sanitising agents, enough for several full rounds.
- Fresh airlocks and bungs, and a few spares.
- Hardwood boards and fixings for the press frame repairs.
- Cloths, brushes and buckets that are used only for cider work.
- Labels and a marker for tagging every part as keep, repair or replace.

I buy supplies in batches, not all at once. The first batch is cleaning agents and tubing, because those let me start stripping down and judging what is still usable. The second batch is seals and wood, once I know the real count. The mentor signs off on the second list before I order.

Anything that touches juice must be food-grade. That rule is not negotiable, and it overrides price.

## Safety

Winter is the right season for this work, but cold and damp bring their own risks. The workshop floor gets slippery, and tools get stiff.

Main points I keep in mind:

- Wear gloves and eye protection when handling cleaning agents. Never mix two products.
- Ventilate the room well when sanitising, and again when fermenters are being filled or emptied.
- Lift heavy parts, such as the press frame and full vessels, with two people. No heroics.
- Unplug or isolate any powered equipment before touching it.
- Keep the floor dry and clear. Wipe up spills at once.
- Keep a first aid kit and a charged phone in the workshop.
- Never work alone when cutting wood or moving the press.

Fermenting vessels can build pressure if the airlock blocks. After the rebuild, I check each airlock daily during the first week of use.

The mentor reviews the plan for lifting and powered tools before the heavy work begins. If the mentor is not present, the heavy jobs wait.

## Checklist

The constraints and success measures are listed here so I can tick them off as the work goes on.

| Item | Detail |
|---|---|
| Project | Ziondpir rebuild |
| Goal | rebuild |
| Area | cider |
| Start year | 2024 |
| Season | winter |
| Lead | mentor |
| Main constraint | Food-grade parts only |
| Main constraint | Work finished within the winter season |
| Success measure | Every part tagged and accounted for |
| Success measure | Spending stays inside the budget |

Steps in order:

1. Photograph the current setup from several angles before touching anything.
2. Strip down and tag each part as keep, repair or replace.
3. Clean and sanitise everything that is kept.
4. Order the first batch of supplies, then the second after sign-off.
5. Repair the press frame and fit new seals.
6. Reassemble the vessels, tubing and airlocks.
7. Run a water test to find leaks before any juice goes in.
8. Do a small trial batch and check for off flavours and leaks.
9. Write up what changed and what I would do differently.

Success is not only that it works. It should also be easy to clean, easy to take apart again, and documented well enough that someone else could repeat it. If the trial batch is clean and the water test shows no leaks, I count the rebuild as done. The mentor makes the final call.

## Budget

The budget of Ziondpir rebuild is 20937.23 EUR. It has to cover supplies, replacement parts, wood and any tools I must buy or hire.

My rough approach to splitting it:

- Most of the money goes to replacement parts and the press repairs.
- A smaller share goes to cleaning agents and consumables.
- A reserve stays untouched until the water test is passed, to cover surprises.

I keep a running list of every purchase, with a short note on why it was needed. If a single purchase looks large, I raise it with the mentor first. If the reserve is used, I write down what it was spent on.

The budget is a limit, not a target. Coming in under it is a good result, as long as nothing on the checklist was skipped to get there. Quality of food-contact parts is the one place I do not cut corners, even if that means trimming elsewhere.
