---
type: plan
status: archived
project: ziondpir-rebuild
area: cider
---

# Kulpoth workshop plan 2020

## Checklist

This note is archived. It records how the Kulpoth workshop stood in 2020. Later notes replace these values, so I should not treat anything here as current.

Basic facts, as I wrote them down in 2020:

- Place: Kulpoth workshop
- Kind: workshop
- Area: cider (also in the frontmatter)
- Orientation: south
- Size: small
- Year built: 2001
- Floor: raised

Things I checked each time I went in during 2020:

- Door latches closed properly and the lock turns without force.
- Floor boards under the press bench are dry and not soft.
- Buckets, funnels and hoses hung up, not left on the boards.
- Fermenting vessels sit on the shelf, not on the floor edge.
- Windows on the south wall wiped, because the sun fades the labels quickly.
- Waste bin emptied, since apple pulp attracts wasps.
- Lamp and extension lead looked over for damage.

## History

The workshop was built in 2001. By 2020 it was nearly two decades old and showed it in small ways: a few boards had gone grey, the door had dropped a little, and the paint around the window frames was worn.

It has always been a cider workshop. The layout never changed much. The press stands near the middle, the shelf for vessels runs along the back, and the bench for cleaning and bottling sits under the south windows.

The floor is raised, which means there is a gap under the boards. That was the original design, and it kept the room drier than the old shed I used before. The downside is that things roll and drop through gaps if I am careless, and the space underneath needs an occasional look.

Much of what I know about how to run the place came from [[Naesnirra Piondgirk notes 2019]], which I wrote the year before. This plan builds on those notes and does not repeat them in full. Where I give a routine here, it is the 2020 version of it.

## Schedule

The year in the workshop follows the apples. This is roughly how I planned 2020.

**Late winter**
- Open up, air the room, and check the roof and floor after the cold.
- Sort out the vessels and decide which need replacing.

**Spring**
- Clean the shelf and the bench thoroughly.
- Rack and bottle whatever is left from the previous autumn.
- Paint touch-ups on the window frames if the weather allows.

**Summer**
- Light use only. The room is small and south-facing, so it gets warm. I avoid fermenting work on hot afternoons.
- Look under the raised floor for damp, pests and rubbish.

**Early autumn**
- Wash the press, the cloths and all the buckets.
- Test the lamp and the leads.
- Clear a path from the door to the press.

**Autumn**
- Pressing days. I try to press in the morning, when the room is still cool.
- Fill vessels, label them straight away, and note the date on the label by hand.

**Early winter**
- Let things settle, check airlocks every few days, and clean up after pressing.
- Close the room down and write notes on what went well.

## Maintenance

The workshop is small, so maintenance is mostly little jobs done regularly rather than big projects.

**Floor.** The raised floor is the main thing to watch. I press down on the boards near the bench and press with my boot to feel for soft spots. If a board gives, I mark it with tape and replace it when the weather is dry. I keep the gap beneath clear of leaves and old pulp.

**Walls and roof.** The south side takes the sun and the weather. I look at the paint and the seals each spring. Cracked paint gets scraped and redone.

**Door.** It has dropped slightly since 2001. I lift it when closing and sometimes oil the hinges. It is not urgent, but it will need rehanging one day.

**Press and tools.** After each use I rinse everything with clean water, let it dry, and wipe the metal parts with a little oil. Wooden parts are never left wet.

**Vessels.** Cracked or scratched ones are retired. Scratches hold bacteria, so I do not keep them for convenience.

**Pests.** Wasps in autumn, mice in winter. I keep lids on everything and sweep daily during pressing.

**Cleaning.** A full clean twice a year, spring and early autumn, plus a quick wipe after each session.

## Setup

The room is arranged so I can work in one direction, from the door to the shelf, without backtracking.

- **Door end:** hooks for coats and cloths, a small mat, and the bin.
- **Middle:** the press on a firm base. I made sure the raised floor is well supported under it, since the press is heavy when loaded.
- **South wall:** the bench with the window above it. This is where I rinse bottles and do the bottling, because the light is best there.
- **Back wall:** the shelf for fermenting vessels, kept off the floor and away from direct sun by a cloth hung in front.
- **Corner:** a box of spare airlocks, bungs, cloths and labels.

Because the workshop is small, I keep the free floor clear. I do not store anything that is not used for cider. Anything else goes to the other storage.

Lighting is one lamp over the bench and one over the press. Both are on a single lead, and I do not add more devices to it.

The handbook [[Valgios workshop handbook]] has a general layout guide that I borrowed from. My version is cut down to suit a small room.

## Safety

- **Floor:** the raised floor can fail where it is wet. I do not stand on suspect boards, and I do not drag heavy loads across them.
- **Press:** keep fingers clear when pressing. Never lean over the press while it is under load.
- **Lifting:** full vessels are heavy. I lift with my legs, or I pour down first and carry smaller amounts.
- **Slips:** juice makes the boards slippery. I mop as I go.
- **Electrics:** water and leads do not mix. The leads stay off the floor and away from the bench sink area.
- **Glass:** bottles can break. I keep a small brush and pan by the door and wear sturdy shoes.
- **Fermentation gas:** the room is small, so I leave the window or door open during active fermentation and do not stay shut inside for long.
- **Wasps:** in autumn I keep the door closed when not carrying things, and I keep a first-aid kit nearby.
- **Alone:** if I work alone, I tell someone when I am going and when I expect to be done.

## Background

The Kulpoth workshop is a small cider workshop with a south orientation. It was built in 2001 and has a raised floor. These facts were the same throughout 2020.

South orientation matters more than I first thought. The sun comes in through the bench windows for much of the day. That is helpful in winter, since the room is easier to work in, but in summer it warms the room more than I like. The shelf at the back stays cooler, and that is why vessels live there.

The small size is both a limit and a convenience. There is no room for a second press or for large batches. But I can walk from one end to the other in a few steps, and everything is in reach.

The raised floor was a good choice for a place that handles so much liquid. It keeps the base of the room off the damp ground. It does mean regular checking, and any rot could be hidden for a while.

My approach is simple: keep the batches modest, keep the room clean, and write down what happens. The notes from 2019 gave me the basics, and 2020 was about tightening the routines.

## Lessons

- A small room fills up fast. Anything not needed during pressing has to be out of the way before the first apple goes in.
- The south sun fades labels and warms the vessels. A hung cloth in front of the shelf solved most of it.
- Checking the floor early in spring saves trouble. Last year I found one soft board near the bench and replaced it before it spread.
- Washing the press right after use is easier than doing it the next day, when the pulp has dried on.
- Hand-written dates on labels are better than trusting memory.
- Lids on everything. Wasps find open buckets within minutes.
- Do not overload the lead. Two lamps are enough.
- Short notes after each session beat long notes written weeks later.
- Keep batches modest. A batch that fits the room comfortably is better than a bigger one that crowds it.

For the next review, I want to compare these lessons with the ones in [[Naesnirra Piondgirk notes 2019]] and see which problems repeated.

## Tools

What lives in the workshop, as of 2020:

- The press, with its basket and a spare cloth set.
- Two food-grade buckets and one large one for pulp.
- Funnels, one wide and one narrow.
- Hoses for racking, kept coiled on a hook.
- Fermenting vessels with airlocks and bungs.
- Bottle brush, bottle rack and a capper.
- Hydrometer and a tall jar to test with.
- Sharp knife and a cutting board for sorting fruit.
- Mop, brush, pan and cloths.
- Torch, in case the lamp or the lead fails.
- Pen, labels and a notebook kept in a dry box.

Everything has a hook, shelf or box. If an item has no place, I either find it one or stop keeping it. A small room cannot afford loose objects.

## Admin

- **Lease reference:** LR-503861
- **Place:** Kulpoth workshop
- **Status of this note:** archived, a record of 2020 only.

The lease paperwork is kept in the folder at home, not in the workshop, because damp would ruin it. When I need to quote the reference in a message, I copy it from here.

Any later change to the workshop, its floor, size or use goes into a newer note. I do not edit this one. The newer note replaces the values here, and this page stays as the record of how things stood in 2020.

Related reading: [[Valgios workshop handbook]] for general practice, and [[Naesnirra Piondgirk notes 2019]] for the earlier year.

## Overview

This is the 2020 plan for the Kulpoth workshop, an archived note. It gathers what I knew about the place at that time and how I planned to use it.

The properties, stated plainly:

- Kind: workshop
- Area: cider
- Orientation: south
- Size: small
- Year built: 2001
- Floor: raised

In short: a small, south-facing cider workshop built in 2001, with a raised floor that I check each spring. The year runs from late-winter checks, through spring cleaning and summer care, to autumn pressing and an early-winter close-down. The main risks are damp boards, wasps, heat from the south sun and the clutter that a small room invites. The main habits are cleaning right after use, labelling at once and keeping notes.

Because the note is archived, later notes replace these values. If something here disagrees with a newer note, the newer note wins. I keep this one so I can see what changed, and why, when I look back.
