---
type: research
status: active
project: ziondpir-rebuild
area: cider
description: "Research about Nermior level sensor."
---

# Nermior level sensor tests

## Problems

The Nermior level sensor is a red level sensor that I installed in 2021 in the workshop. It watches the level in the cider area and runs on solar power. These notes cover the tests I ran on it and the trouble I had.

The main trouble is the power supply. Because the energy source is solar, the sensor depends on how much light reaches the panel in the workshop. On grey days the readings get slow, and sometimes they stop for a few hours. In winter the panel barely gets any direct light through the window, so I cannot trust the sensor to run all day without help.

Other problems I noticed during testing:

- The readings jump when the liquid is still foaming after a fill. I have to wait before I trust the number.
- Sticky residue builds up on the probe tip and shifts the reading a little. Cleaning it fixes this for about a week.
- The red housing gets warm when the sun hits the workshop wall, and the reading drifts upward while it is warm.
- The signal sometimes drops out when the big press motor starts nearby.

I have not found a single cause for the dropouts. They seem to be linked to either the motor or a weak supply, and I need to test each one on its own.

## Measurements

I took all measurements in the workshop, at the sensor itself, with the panel in normal daylight. I used a plug-in meter on the supply line and let the reading settle before writing it down.

- Measured power draw of Nermior level sensor: 12.53 W
- Location during the test: workshop
- Area being monitored: cider
- Energy source: solar
- Year installed: 2021

The power draw is higher than I expected for a sensor of this kind. With a small panel, that leaves little spare energy, which fits what I saw on grey days. When the light drops, the sensor has no margin and the readings stall.

For the level itself, I compared the sensor against a simple dipstick reading taken at the same time. Over several fills, the sensor agreed closely when the liquid was calm and the probe was clean. It disagreed most right after filling, and when the probe was dirty.

Next steps for testing:

- Repeat the power reading on a dull day and compare it with the sunny result.
- Run the sensor with the press motor off, then on, and note any dropouts.
- Shade the housing to see if the upward drift goes away.
- Clean the probe before each test so the results are comparable.

Once I have these results, I can decide whether the panel is too small or whether the sensor needs a different power arrangement.
