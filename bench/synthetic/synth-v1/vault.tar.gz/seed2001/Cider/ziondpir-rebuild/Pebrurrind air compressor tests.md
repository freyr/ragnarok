---
type: research
status: active
project: ziondpir-rebuild
area: cider
---

# Pebrurrind air compressor tests

## Costs

The Pebrurrind air compressor is a blue air compressor that runs on solar power. It sits in the workshop and has served the cider area since it was installed in 2015. These notes cover what it has cost me to keep it running and what the tests showed.

Because the energy source is solar, there is no fuel or electricity bill for the compressor itself. That was the main reason I chose it in 2015. The costs that remain are small but regular:

- Replacement hoses and fittings, which I buy when the old ones start to leak.
- Oil and filter changes, done once a season before the pressing work starts.
- Cleaning supplies for the intake, because the workshop gets dusty and sticky from the cider work.
- My own time, which is the largest cost if I am honest. A test day usually takes most of an afternoon.

I have not tracked every purchase to the cent, and I do not want to invent a precise total here. A rough view is enough: the running cost is low, and the biggest expense was the original purchase and the solar setup that feeds it. Since 2015 the repairs have been minor.

One thing I noticed during the tests is that cloudy days cost me in a different way. The compressor fills the tank more slowly when the sun is weak, so I plan the work that needs high pressure for bright hours. That is a scheduling cost, not a money cost, but it is still worth writing down.

If the tank ever has to be replaced, that will be the first big bill since installation. I should check the tank for rust each year and note the result here.

## Adjustment

During testing I found that the pressure readings did not match a reference gauge I trust. The gap was small but steady, so I made an adjustment rather than replacing anything.

The calibration offset of Pebrurrind air compressor: 2.471 mm. I measured this as the travel of the regulator adjuster, and I set the adjuster to that offset before running the next round of tests.

The steps I followed:

- Let the tank empty fully and wait until the gauge rests at zero.
- Loosen the lock nut on the regulator adjuster.
- Move the adjuster by the calibration offset and hold it there.
- Tighten the lock nut without letting the adjuster turn.
- Refill the tank on a sunny day and compare the built-in gauge with the reference gauge.

After the change, the two gauges agreed well enough for cider work, where I do not need laboratory precision. I repeated the comparison on a second day to make sure the result held, and it did.

Things to remember for next time:

- Do the adjustment only when the tank is empty.
- Mark the adjuster position with a paint pen before moving it, so I can go back to the old setting if needed.
- Recheck after any hose or fitting change, because a new fitting can shift the readings slightly.
- Repeat the comparison once a year, ideally at the start of the season.

The adjustment held through the rest of the season in the workshop. I will keep the offset written here so the setting can be restored if the regulator is ever replaced or knocked out of position.
