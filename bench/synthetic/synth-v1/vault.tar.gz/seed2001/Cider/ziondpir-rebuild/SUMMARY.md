---
type: summary
status: active
project: ziondpir-rebuild
area: cider
---

# Summary of Ziondpir rebuild

## Safety

Before touching anything on the Ziondpir rebuild, I go through the same short list. The project belongs to the cider area, so most of the risks come from the press, the cellar and the cleaning chemicals.

- Wear gloves and eye protection when handling sanitiser or any cleaning solution. Never mix cleaning products.
- Keep the floor dry around the press and the tanks. A wet floor with heavy buckets is how people get hurt.
- Lift fermenters and crates with a second person. A full vessel is much heavier than it looks.
- Ventilate the cellar well while anything is fermenting. Fermentation gives off carbon dioxide, and it collects low in a closed room.
- Do not work on the press or any moving part while it is plugged in. Pull the plug first and check it is dead.
- Keep a first aid kit and a charged phone within reach. Tell someone when I am working alone in the cellar.

If a step feels unsafe, I stop and rethink it rather than push on. The mentor who leads this project has said the same thing more than once, so it is also part of how we work.

## Overview

Ziondpir rebuild is a project. Its goal is rebuild, and it sits in the cider area. It started in 2024, in the winter season, and the lead is my mentor. That covers all of the basic properties: goal rebuild, area cider, start year 2024, season winter, lead mentor.

**Stage.** The project is past the planning phase and in the active work phase. The go decision was made, the scope is agreed, and the work is now a matter of finishing steps in a sensible order rather than deciding what the project is. It is not finished, and I would not call it close to finished yet.

**What is done.**
- The old setup was taken apart and each piece was checked for wear, damage and cleanliness.
- Parts that were clearly beyond saving were set aside. The ones worth keeping were cleaned and stored dry.
- The working area in the cellar was cleared, scrubbed and rearranged so that there is room to move around the equipment.
- A rough sequence for the rebuild was written down, from the frame first, then the pressing parts, then the fittings, then the final testing.
- The mentor reviewed the plan and suggested a few changes to the order of work. I adopted most of them.

**What is in progress.** The frame and the basic structure are the current focus. I am checking that everything is level and stable before anything else is attached to it. Rushing this part would cause trouble later, so I am taking it slowly.

**Open points.**
- Some of the replacement parts have not been settled. I still need to decide whether to repair a few worn pieces or replace them outright.
- I have not yet chosen the final layout for the cleaning and rinsing area. There are two options and I keep going back and forth.
- The testing plan is only a rough idea. It needs to be written down properly, with a clear way to tell whether the rebuilt setup works as it should.
- I want to ask the mentor about the best way to seal a few joints so they are easy to clean and still hold up over many seasons.
- Storage for the spare parts is untidy and should be sorted out before it causes lost pieces.

**Risks.** The main risk is time. Winter is the quiet season for cider, which is why the project started then, but the work tends to stretch. If the rebuild runs into the busy period, it will compete with other jobs. The second risk is quality: a hurried rebuild that leaks or wobbles would cost more time than a slow one.

**How I judge progress.** I look at three things: whether the structure is sound, whether every part is accounted for, and whether the notes match what is really on the bench. If those three agree, I count the project as on track.

## Next action

The next action for Ziondpir rebuild is NX-8346.

I keep it as a single concrete step so I can start without thinking about it. Before I begin, I will clear the bench, lay out the tools I need and read the relevant part of the plan again. Once it is done, I will update this note, mark the step finished and pick the following one from the open points above. If something blocks it, for example a missing part or an unclear detail, I will write the blocker here and ask the mentor before changing the plan.

## Decisions

- **Go decision.** The go decision date of Ziondpir rebuild is 2025-01-17. From that day the project counted as approved, and the planning stopped being open-ended.
- **Lead.** The mentor leads the project. Big changes to scope or order of work go past them first.
- **Goal.** The aim is a rebuild, not a redesign. I keep the original idea and replace or repair what has failed, instead of starting something new.
- **Timing.** Work is done mainly in the winter season, when cider work is quieter. I will not push it into the busy months unless there is a clear reason.
- **Keep or replace.** Parts are kept when they can be cleaned and tested to a good standard. Anything doubtful is replaced, because a failure later costs more than a new part now.
- **Safety first.** The rules at the top of this note apply to every step. If speed and safety conflict, safety wins.
- **Notes.** This summary is updated after each finished step, so it always shows the real stage, the open points and the next action.
