---
type: plan
status: active
project: traetraerk-rebuild
area: cider
description: "Plan about Vilith level sensor."
---

# Vilith level sensor plan

## Open questions

These are the things I still cannot answer about the Vilith level sensor. I want to settle them before I trust it fully.

- Will the battery last through a full cider season in the loft, where the temperature swings a lot between autumn and midwinter?
- Is the green housing enough protection from the damp air that rises from the fermenting vessels, or will it need a cover?
- Does the reading drift when the cider foams during the first days of fermentation?
- Should I add a second sensor on the lower tank, or is one in the loft good enough for the whole cider area?
- How often should I check the reading by hand against a dip stick to confirm it is still honest?

I will keep this list short. When a question is answered, I will move the answer into Lessons and cross it off here.

## Lessons

So far the plan has taught me a few simple things.

- A battery sensor is only useful if I remember to look at it. A sensor I forget about is worse than a stick I use every day.
- The loft is a good place for the device because it is out of the way, but it is a poor place for quick checks. I have to climb up to do anything with it.
- Writing down a hand reading next to each sensor reading is the only way I can tell whether it is accurate.
- Earlier work in [[Glaelbrath scale study]] showed that I should compare a device against a known reference before relying on it. I am applying the same habit here.
- The comparison method in [[Bothkan Belstark tests]] is also worth copying: test in small steps, change one thing at a time, and write down the result straight away.

## Background

The Vilith level sensor is a level sensor that I use in the cider area. It is green, which makes it easy to spot against the grey beams and the old wood of the loft. It runs on a battery, so I did not need to run any cable across the loft or down to the press room. I installed it in 2025, and it sits in the loft.

The reason for buying a level sensor was simple. Checking the level of juice and cider by opening lids or climbing a ladder is slow, and each time I open a vessel I let in air and risk spoiling a batch. I wanted a way to see the level without touching anything.

Here is the summary of the device in one place:

| Property | Value |
| --- | --- |
| Kind | level sensor |
| Area | cider |
| Color | green |
| Energy source | battery |
| Year installed | 2025 |
| Location | loft |

The plan in this note is about getting the most from the sensor: how I check it, how I look after the battery, and how I decide whether to trust it or replace it. It is not a technical manual. It is my own working list of what to do and what to watch.

## Costs

I do not want to put exact prices here, because I would only be guessing, and the numbers would go out of date. What matters is the kinds of cost and how they compare.

- **Purchase:** The sensor itself was a modest one-time cost. It was cheaper than losing a single batch of cider to a careless lid opening.
- **Battery:** This is the running cost. It is small each time, but it repeats. A battery that dies in the middle of fermentation costs me more in worry than in money.
- **Time:** Climbing to the loft for checks and battery changes costs me time. This is the biggest cost in practice.
- **Spares:** I should keep one spare battery in the kitchen drawer so that a failure does not leave the sensor dead for days.
- **Replacement:** If the housing cracks or the damp gets in, I would have to replace the whole device. I should set a little money aside for that.

My rule is that the sensor has paid for itself if it saves me from even a few unnecessary climbs and one spoiled batch. After a full season I will look at this again and decide whether a second sensor is worth the money.

## Observations

These are the things I have noticed since installing the sensor in the loft in 2025.

- The readings are steady when the vessel is calm and the loft is cool. This is when I trust it the most.
- During active fermentation the reading moves around more. I think the foam or the movement of the surface is confusing it.
- On cold mornings the battery seems to give a weaker performance than on warm afternoons. I have not proven this, so I am treating it as a suspicion only.
- The green color has held up well. There is no fading and no flaking so far.
- Dust collects on the housing. A quick wipe with a dry cloth is enough, but I should not let it build up.
- The loft gets warm in late summer, and I want to watch whether heat changes the reading in the same way that cold seems to.

I plan to keep a small log beside the ladder with the date, the sensor reading, and my hand reading. After a few weeks, the pattern should be clear enough to say whether the drift is real.

## History

The story of the sensor is short, but I want to keep it in order.

1. I decided I needed a way to check the cider level without opening the vessels.
2. I chose a battery-powered level sensor so that I would not need any wiring in the loft.
3. In 2025 I installed the Vilith level sensor in the loft, in the cider area.
4. In the first weeks I compared its reading with my hand checks, following the approach I had used in [[Glaelbrath scale study]].
5. Later I began breaking my tests into small steps, as I had done in [[Bothkan Belstark tests]], so I could see which change caused which result.
6. Since then I have kept watching the battery and the reading, and I have used this note as the plan for what comes next.

Nothing has gone badly wrong so far. The main work ahead is to keep the checks regular, to keep the log honest, and to decide on a second sensor after one more full season.

## Parts

This section lists what makes up the setup, so I can find things quickly when something fails.

- **Main unit:** the Vilith level sensor, green, mounted in the loft.
- **Serial number:** SN-93431631
- **Power:** one battery inside the housing, with a spare kept in the kitchen drawer.
- **Mounting:** the fixing that holds the sensor in place in the loft, which I should check for looseness each season.
- **Cleaning cloth:** a dry cloth kept near the ladder for wiping dust from the housing.
- **Log sheet:** the paper sheet where I write the sensor reading next to my hand reading.

If I ever need to ask for help or claim a repair, the serial number above is the first thing I will need. I keep it here so I do not have to climb up and read it off the device.
