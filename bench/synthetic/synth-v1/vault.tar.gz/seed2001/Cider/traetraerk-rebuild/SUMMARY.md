---
type: summary
status: active
project: traetraerk-rebuild
area: cider
description: "Summary about Traetraerk rebuild."
---

# Summary of Traetraerk rebuild

## Supplies

The Traetraerk rebuild is a project in the cider area. The goal is a rebuild, it started in spring 2025, and the lead is the accountant. This note is the summary: where the project stands, what is finished, what is still open, and what comes next.

Stage: the project is past the planning phase and into the practical work. The main job now is getting the supplies together so the rebuild can move without stops.

What is done:
- The list of what the rebuild needs has been written out and checked against what is already in the shed.
- The accountant has gone through the costs and set a spending limit, so purchases do not need to be argued about each time.
- The old equipment has been sorted into what can be reused, what can be repaired, and what has to be replaced.
- A clean, dry spot has been cleared for storing the new supplies when they arrive.

Open points on supplies:
- Several items on the list still have no supplier chosen. I want at least two options for each before ordering.
- Delivery times for the larger items are not confirmed, and they decide the order of the work.
- Some of the reusable parts need cleaning and a closer look before I trust them again.
- I have not yet decided how much spare material to buy. Too little means stopping halfway, too much ties up money.

Keep in mind that the accountant leads this project, so every order should be written down with its cost. That keeps the totals easy to follow and avoids surprises later.

## Next action

The next action of the Traetraerk rebuild is NX-5096.

I keep this to one item on purpose. When I sit down to work on the project, I should not have to think about what to do first. Everything else on the open list waits until this one is finished.

Once it is done, the plan is to:
1. Update this summary with what was learned.
2. Pick the next open supply point and settle the supplier.
3. Tell the accountant about any change in cost, so the limit stays accurate.

If the action turns out to be blocked, I note the reason here straight away and move to the nearest open supply point instead of leaving the project idle.

## Decisions

The go decision date of the Traetraerk rebuild is 2022-12-25. That is the day the rebuild was approved to go ahead, and all later choices count from it.

Decisions made so far:
- The project is a full rebuild, not a patch-up. Repairs alone were judged to cost more over time.
- The accountant leads, because cost control is the main risk and the main measure of success.
- Work is planned for spring, when conditions suit the job and the cider area is less busy.
- Reusable parts are kept where they pass inspection, to hold the cost down.

Decisions still to make:
- How much spare material to order.
- Which supplier to use for each item that has none yet.
- Whether the larger items should be ordered all at once or in stages, depending on delivery times.

When one of these is settled, I add it to this list with a short reason, so I can see later why I chose it. If a decision changes the cost, the accountant gets told first and the supply list is updated after that.
