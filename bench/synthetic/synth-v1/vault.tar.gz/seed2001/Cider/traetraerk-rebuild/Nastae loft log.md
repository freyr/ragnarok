---
type: log
status: active
project: traetraerk-rebuild
area: cider
description: "Log about Nastae loft."
---

# Nastae loft log

## Background

Nastae loft is a large loft in the cider area. It was built in 2003, and it sits below ground, which is odd for a loft, but that is how the building was made. The orientation is east. Because it is below ground, the east side does not give the sunrise I expected. Light comes in through a row of high windows and a short light well, and on most mornings the room gets a thin, pale wash rather than direct sun.

To keep the facts in one place: the kind is loft, the area is cider, the orientation is east, the size is large, the year built is 2003, and the floor is below ground.

I use this log to keep track of what I do in the space, what goes wrong, and what I have learned. It is for my own use, so it is short on polish and long on practical detail. The loft is used for storage, for a workbench along the east wall, and for a few shelves of preserved food. Because the room is large, I treat it as three zones: the workbench end, the shelving middle, and the far corner where the bulky things go.

The main character of the place is steady temperature. Below ground, it stays cool in summer and does not drop hard in winter. The trade-off is damp. Anything that likes dry air has to be moved or protected.

## Admin

The lease reference of Nastae loft is LR-009268. I keep it at the top of any message I send to the landlord or the building office, because they ask for it every time.

Other admin points I keep on file:

- The lease covers the loft only, not the light well. Repairs to the light well go through the building office.
- Access is by the east stairwell. The key stays on the hook by my door, and the spare is with a neighbour.
- Contents insurance has to list the loft as a below-ground space. I confirmed this when I renewed, since some policies treat basements differently.
- Any change to wiring needs written permission. I do not touch the fixed wiring and use only plug-in lights and a plug-in dehumidifier.
- Rubbish and old paint cannot be left in the stairwell. I take them to the collection point myself.

When I talk to the building office, I note the day, the person, and what was agreed, and I add it to the History section below.

## Problems

These are the recurring problems, in the order they annoy me.

1. **Damp air.** The room is below ground, so humidity creeps up in wet weather. Cardboard goes soft, metal tools get a light film of rust, and a musty smell appears if the room is shut for a week.
2. **Condensation on the east wall.** The wall is cooler than the air in the morning, and moisture beads on it. It is worst near the workbench.
3. **Weak light.** The east orientation does not help much underground. The high windows are small, and the light well collects leaves and grit.
4. **Dust.** Because the room is large and little used, dust settles on everything, and the stairwell brings more.
5. **Drainage after heavy rain.** Twice the floor drain has been slow, and a thin film of water stood near the stairs. It never got deep, but it was enough to worry me.
6. **Poor phone signal.** I cannot rely on it down there, so I do not plan on taking calls in the loft.

None of these is a disaster. Together they mean the loft needs regular attention, or it slides toward being a place where things are forgotten and spoil.

## Checklist

This is the routine I run through. I do a short version weekly and a full version at the turn of each season.

**Weekly**
- Check the dehumidifier tank and empty it.
- Look at the east wall near the workbench for beads of moisture.
- Smell the air when I open the door. If it is musty, I leave the door open for an hour.
- Check the floor near the stairs for any standing water.

**Seasonal**
- Clear the light well of leaves and grit.
- Wipe down the windows inside and out.
- Test the floor drain by pouring a bucket of water and watching how fast it goes.
- Lift boxes off the floor and check the undersides.
- Oil the metal tools and put a fresh drying pack in the toolbox.
- Check the preserved food shelves for any lids that bulge or leak.
- Sweep the whole floor, including the far corner.
- Review the lease and insurance notes in case something has changed.

**Before heavy rain**
- Move anything valuable off the floor.
- Clear the drain cover.
- Make sure the dehumidifier is plugged in and working.

## History

I write this part in loose order, because I did not always note the exact day.

When I first took the loft, it was empty and dusty. The 2003 build date meant the finishes were already tired, but the structure was sound. My first job was to scrub the floor and walls and let the room dry for a couple of weeks with the door propped open.

In the first season I put the workbench along the east wall, thinking the light would be best there. That turned out to be only partly true. The light was fine for a short time in the morning, but the wall was the coldest surface in the room, and the bench collected moisture. I moved the bench out by a hand's width and put a thin board behind it, which helped.

In the second season I added open metal shelving in the middle zone. Wooden shelves had swollen in the damp, so I replaced them. I kept the heavy boxes low and the light ones high, which also keeps the weight spread out.

After the first slow drain, I called the building office. They sent someone who cleared a blockage in the pipe outside the loft. The drain ran fine for a while, then slowed again after a very wet spell, and I asked them to check the outside pipe once more. That is still an open item, and I mention it each time I call, along with the lease reference.

I later bought a plug-in dehumidifier. It was the biggest single improvement. Since then the rust has mostly stopped, and cardboard no longer sags. I run it on a timer so that it works in the early hours, when the room is coolest and the air is dampest.

More recently, I brightened the room with plug-in lamps in warm white, set low along the shelves, and painted the ceiling a pale colour. The loft feels bigger, and I spend less time hunting for things.

## Lessons

- A below-ground room is not the same as a dry one, even if it is large and well built. Plan for damp from the start.
- East orientation is not a promise of sunlight when the windows are high and small. Judge the light by standing in the room, not by the compass.
- Keep everything off the floor. A few centimetres of air under a box saves it.
- Do not put a workbench against the coldest wall. Leave a gap.
- A dehumidifier on a timer is worth more than any amount of occasional airing.
- Small checks done every week are easier than large repairs done once a year.
- Keep the lease reference where I can find it quickly, and write down every conversation with the building office.
- Metal shelves beat wood in a damp room. Wood is cheaper at first and costs more later.
- Having a zone for each purpose keeps a large room from turning into a heap. The workbench end, the shelving middle, and the far corner each have a job, and I try to keep it that way.
- Do not rely on the room for anything that needs a signal. Plan calls and messages for upstairs.
