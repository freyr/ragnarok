---
type: drivers
status: active
project: traetraerk-rebuild
area: cider
description: "Drivers about Traetraerk rebuild."
---

# Drivers of Traetraerk rebuild

## Supplies

The goal of Traetraerk rebuild is a rebuild, started in spring 2025 and led by the accountant. It sits in the cider area. Supplies are what hold the schedule, so I check them first.

- Air compressor: see [[Pebrurrind air compressor tests]] for what held up.
- Level sensors: results are in [[Bilrendles level sensor tests]], and the choice follows [[Vilith level sensor plan]].
- Valve actuators: the old unit is in [[Fakiosto valve actuator 2018]].
- Supplier contact: [[Zorzaerk Lirfu]].

The site question is covered in [[Traesdrur shed study]].

## Budget

| Property | Value |
|---|---|
| Goal | rebuild |
| Area | cider |
| Start | spring 2025 |
| Lead | accountant |

The budget is fixed. Success means the rebuild finishes inside it.

```
project: Traetraerk rebuild
budget: 29021.52 EUR
```
