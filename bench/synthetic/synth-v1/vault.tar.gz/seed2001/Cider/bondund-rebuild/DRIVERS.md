---
type: drivers
status: active
project: bondund-rebuild
area: cider
description: "Drivers about Bondund rebuild."
---

# Drivers of Bondund rebuild

## Background

The Bondund rebuild is a project in the cider area. Its goal is rebuild. It started in 2025 and the main work happens in the summer season. The lead is the inspector, so every decision about what counts as finished goes through that person first.

I keep this note to remember why the project exists and what limits it. The details of the work itself live in other notes. Here I only want the drivers: the goal, the constraints and the way I judge whether it worked.

The goal is simple to say. The Bondund setup needs to be rebuilt so that cider work can go on there reliably, without the repeated patching that has been eating time. The old arrangement kept failing in small ways, and each fix made the next one harder. A proper rebuild should end that cycle.

Constraints I am working with:

- Season. The work is tied to summer. If a stage slips past the warm months, it gets harder to finish and harder to test, so the schedule matters more than polish.
- Lead sign-off. The inspector leads the project and has the final word. Anything that changes the scope has to be agreed with them before I act on it.
- Money. The budget is fixed and has no obvious room for extras. Details are in the next section.
- Continuity. The cider area still has to function enough that I do not lose a whole production period because of the rebuild.

How success is measured:

1. The inspector accepts the finished work without asking for major rework.
2. The rebuilt setup runs through a full cider cycle without an emergency repair.
3. The spending stays within the budget I set at the start.
4. The work is complete within the summer season, not dragged into the following months.

I do not measure success by how new or impressive things look. A plain result that holds up is better than a nice one that needs attention every few weeks. If I have to choose between finishing on time and adding a refinement, I finish on time and note the refinement for later.

When I review the project, I come back to these four checks. If the answer to any of them is no, I write down why, so the next rebuild in this area starts from a better position than this one did.

## Budget

The budget of Bondund rebuild is 13006.56 EUR.

That figure is the ceiling for the whole project, not a target to reach. I treat it as covering materials, hired help and anything I need to buy or rent along the way. I would rather return some of it unspent than go over.

Rules I follow for the money:

- Every purchase gets written down when it happens, not at the end of the week.
- Anything that looks like it could push the total close to the limit goes to the inspector before I commit.
- I keep a small part of the budget unspent as a safety margin for surprises, and I do not count that part as available for upgrades.
- Optional improvements wait until the core work is done and the remaining money is clear.

If the budget turns out to be too tight, the first thing I cut is scope, not quality of the essential work. The second is any extra I added on my own. The inspector decides whether the limit itself can change, and I do not assume it can.
