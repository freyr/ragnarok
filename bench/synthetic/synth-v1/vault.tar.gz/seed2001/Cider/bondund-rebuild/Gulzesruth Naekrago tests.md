---
type: research
status: active
project: bondund-rebuild
area: cider
description: "Research about Gulzesruth Naekrago."
---

# Gulzesruth Naekrago tests

## Observations

Gulzesruth Naekrago is an electrician. I have known him since 2021, and the area I file him under is cider, because most of the work I have had him look at was connected to the cider press shed and the storage room behind it. These notes are about the tests he ran and what I saw while he did them.

The way to reach him is by phone. He does not answer messages well, and he does not read email, so I call. He is available on weekends only. During the week he works elsewhere, so there is no point trying him before Saturday morning.

What I noticed during the testing:

- He starts every job by switching off the main supply and checking with a tester that the circuits are really dead. He never trusts the labels in the fuse box.
- He tests each circuit in the shed one at a time and writes the result on a scrap of paper. He did not leave me a written report, so I copied his numbers down myself the same evening.
- The old socket by the pressing table failed his check. He said the earth connection was poor and that I should not plug the press motor into it until it is redone.
- The lights in the storage room were fine, but one cable run was damp at the joint. He marked it with tape.
- He explained things in plain words and was patient when I asked him to repeat himself.

Overall the testing was thorough and slow, which I prefer. He does not hurry, and he does not skip steps just because the shed is small.

## Quotes

The only formal quote I have from Gulzesruth Naekrago so far is for redoing the shed wiring after the tests: 5489.14 EUR.

What I understood it to cover, from our phone call:

- New cable to the pressing table and the motor.
- A replacement of the failed socket with a properly earthed one.
- Repair of the damp joint in the storage room, with the run moved higher on the wall.
- A new small consumer unit in the shed, so the shed has its own protection.

What I still need to ask him:

- Whether materials are included in the figure or are charged on top.
- Whether the work can be done over two weekends, since he is only free on weekends.
- Whether he would test again after the work and give me a note of the results.

I have not accepted the quote yet. I want to compare it with at least one other electrician, though finding someone who knows cider equipment is not easy. Since I have known him since 2021 and he has been honest with me before, I lean toward him unless the other price is far lower.

## Background

I first met Gulzesruth Naekrago in 2021, when a neighbor who also makes cider recommended him. At that time he fixed a tripping circuit in the barn, and he did it quickly and left everything tidy. After that I called him for small jobs now and then: a new outdoor light, a check of the extension leads, and once a look at a pump that kept cutting out.

His role is electrician, and that is how I think of him, though he knows a fair amount about how presses, pumps and chillers behave electrically. He often says that cider equipment gets wet and sticky, and that this is harder on wiring than most people expect. That is why he is careful about earth connections and about where cables run.

Contact has always been by phone. Weekends are the only time he is available, so I plan work around that. In autumn, during pressing, the weekends are busy for me too, so the timing has to be agreed well ahead. The best window is probably after the last pressing, when the shed is empty and cleaned.

## Supplies

Things to have ready before he comes back to do the work, so that his weekend time is not wasted:

- Clear access to the consumer unit and to the pressing table. The shed needs to be emptied of crates and barrels along the wall.
- A working light, in case the supply is off for a long stretch. A battery lamp is enough.
- A ladder tall enough to reach the higher cable run in the storage room.
- Dry weather for the day, or at least a dry shed, because of the damp joint.
- Tea and something to eat, since he will probably work a full day.
- A notebook, so I can write his test results down at the time and not copy them later from memory.

Materials such as cable, the new socket and the consumer unit depend on what he says about the quote. If he asks me to buy them, I will ask him for a list with sizes first. I should keep any receipts together with this note, so the cost is easy to compare with the quote later.
