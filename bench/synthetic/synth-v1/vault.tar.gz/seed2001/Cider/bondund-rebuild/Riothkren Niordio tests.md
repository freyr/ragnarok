---
type: research
status: active
project: bondund-rebuild
area: cider
description: "Research about Riothkren Niordio."
---

# Riothkren Niordio tests

## References

Riothkren Niordio is a neighbor. I have known him since 2019. His area is cider, which is why most of our talks end up being about pressing, fermenting and bottling. The contact method is phone, and he is available in the evenings. Calling before that is pointless, since he is usually out working.

These notes are my own tests and observations, not anything official. When I wrote them I looked at a few other notes that cover related equipment and similar neighbors:

- [[Girdael radio receiver]] for the radio I use to check the weather before a pressing day.
- [[Pindbu air compressor tests]] for how I tested the compressor he borrowed once.
- [[Sioteth level sensor notes]] for the sensor idea I first tried on his tank.
- [[Merkku heat exchanger study]] for the cooling question that came up during a batch.
- [[Triothglis circulation pump plan]] for the pump we discussed moving juice with.
- [[Traenzirk level sensor log]] for readings from the second sensor.
- [[Gulzesruth Naekrago tests]] for another neighbor's tests, which I use as a format to copy.

## Schedule

Because Riothkren Niordio is only available in the evenings, everything is planned around that. I call by phone after dinner, and I try not to call too late in the week of a pressing, because he is tired by then.

A rough routine that works:

- Early in the week, I call to ask whether he has apples or equipment free.
- Midweek, I confirm what we will test and who brings what.
- At the weekend, if the weather is good, we do the work in daylight and talk about results in the evening.

I have known him since 2019, so the routine has settled. He does not mind a short call. A long one needs to be agreed beforehand. If he does not pick up, I leave a short message and try again the next evening instead of calling repeatedly.

## Contracts

There is only one written agreement between us. The contract date of Riothkren Niordio is 2023-01-23. It covers sharing the press and the cold storage shed during the cider season, and what each of us does about cleaning and returning things.

What I remember of the terms, in plain words:

- Each of us uses the shared press in turn, and we agree the order by phone.
- Whoever uses the press cleans it afterward.
- Damage is reported the same evening, or the next one at the latest.
- Borrowed tools go back clean.

I should check the actual paper again before the next season, because I only trust my memory for the general idea. If anything changes, I will write the new agreement down and note the change here instead of relying on a phone call alone.

## Maintenance

Most of the upkeep is on the shared press and on the small gear we pass between us. My checks are simple and practical.

- After each use, rinse the press and let it dry fully before covering it.
- Check the seals and hoses for cracks at the start of the season.
- Look at the compressor condition, using what I wrote in [[Pindbu air compressor tests]].
- Check any level sensor wiring for damp. See [[Sioteth level sensor notes]] and [[Traenzirk level sensor log]] for what went wrong before.
- Keep the pump clean and flushed if we use it. The plan is in [[Triothglis circulation pump plan]].
- If cooling is needed, look back at [[Merkku heat exchanger study]] before buying anything.

When I do work on his side of the shed, I tell him by phone in the evening so he knows what was touched. He does the same for me. This has avoided a few misunderstandings over the years since 2019.

For comparison, [[Gulzesruth Naekrago tests]] shows how I keep a record for another neighbor, and I follow the same habit here: write down what was done, who did it, and what is left.

## Open questions

- Should the contract from 2023 be rewritten to include the new storage arrangement, or is a phone agreement enough?
- Does Riothkren Niordio want to try the sensor setup on his own tank, or only watch my tests?
- Is there a better time than the evenings for longer talks, for example on a quiet weekend? He has only ever offered evenings.
- Who pays for replacement seals if the press wears out?
- Would a cooling arrangement be worth the effort, given what [[Merkku heat exchanger study]] suggested?
- Can the radio in [[Girdael radio receiver]] be moved to the shed so we both hear the forecast?

## Setup

This is how I keep the relationship and the testing organized so that it stays easy.

1. Contact: phone only. I have his number saved under his name, with a note that he answers in the evenings.
2. Role: neighbor. I treat him as a partner for cider work, not as a supplier.
3. Area: cider. All my tests with him are about pressing, fermenting, storage and the equipment around them.
4. Known since 2019. I use that as context when I am unsure about old arrangements.
5. Records: one note per test, linked to the equipment notes listed under References.
6. Agreement: the contract dated 2023-01-23 is kept with my other papers, and I mention it in each season's plan.

Before a season, I go through the list, call him one evening, and write down any change here. After the season, I add the results to the matching test note and update the open questions above.
