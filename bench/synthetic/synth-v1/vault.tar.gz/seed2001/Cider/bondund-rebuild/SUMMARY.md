---
type: summary
status: active
project: bondund-rebuild
area: cider
---

# Summary of Bondund rebuild

## Overview

Bondund rebuild is a project in the cider area. The goal is a rebuild. It started in summer 2025, and the lead is the inspector. This note is my running summary of where it stands, what has been settled, and what is still open.

The project is past the planning stage and now in the execution stage. The scope was agreed early: strip the old setup down to what still works, replace what does not, and bring the whole thing back into a state the inspector is willing to sign off. Most of the teardown is finished. The reusable parts have been sorted from the scrap, and the cleaning and checking of the reusable ones is mostly done.

What is done so far:

- The old setup has been taken apart and the parts laid out and sorted.
- The reusable parts have been cleaned and checked.
- The inspector has walked through the site once and written down the points that must be fixed.
- The working order for the rebuild has been agreed, so that nothing gets assembled before it has been checked.

What is still open:

- A few parts that failed the check still need a replacement decision.
- The inspector's list of fixes is not yet fully matched to tasks.
- The cleaning routine for the finished setup is only sketched and needs to be written down properly.
- I have not yet settled how much of the work can be done in a single stretch and how much has to wait for deliveries.

## Decisions

The main decision is the go decision. The go decision date of Bondund rebuild is 2025-10-21. Before that date the project was still a proposal, and after it the teardown and rebuild work could start in earnest.

Other decisions that follow from it:

- Keep the original layout where possible, because the inspector had no complaints about it and changing it would add more review work.
- Replace failed parts instead of repairing them, since repairs would need a second inspection and cost more time than they save.
- Let the inspector approve each stage before the next one starts. This slows things a little but avoids redoing work.
- Write down every change to the plan in this project's notes, so that I can see later why something was done in a particular way.

Decisions still waiting: which replacements to buy, and whether to do the final assembly all at once or in two rounds. Both depend on what the inspector says about the open fixes and on how quickly the replacement parts arrive.

## Next action

The next action of Bondund rebuild is NX-7493.

Once that is done, I will go back to the open points above, starting with the replacement decision for the failed parts, and then ask the inspector to review the fix list so it can be turned into a clear set of tasks. After that the cleaning routine can be written up and the final assembly planned.
