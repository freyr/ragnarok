---
type: plan
status: active
project: glaennin-automation
area: cider
---

# Konkrur Faesnus plan

## Background

Konkrur Faesnus is an electrician I have known since 2020. His area is cider, so most of the work I think of him for is around the pressing and storage side. The best way to reach him is by phone, and he is available on weekdays only. I should not plan anything for him on a weekend.

Before I ask him about new work, I want to look at [[Dalsti loft]] and [[Rarkaend loft plan]] to see what wiring is already there. [[Zorzaerk Lirfu]] is worth a call too, since that person may know his earlier jobs.

## Contracts

His contract date is 2018-01-06. That is earlier than when I met him, so the contract came through someone else.

For any new job, I will compare the notes in [[Trendstil level sensor notes]], [[Traesdrur shed study]] and [[Dusra level sensor study]] first. Then I will decide what to ask him to quote.
