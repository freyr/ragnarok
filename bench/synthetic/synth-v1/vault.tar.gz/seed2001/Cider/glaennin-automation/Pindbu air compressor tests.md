---
type: research
status: active
project: glaennin-automation
area: cider
description: "Research about Pindbu air compressor."
---

# Pindbu air compressor tests

## References

These are the notes I keep open while testing the Pindbu air compressor. It is a blue air compressor that runs on mains power. It was installed in 2025 in the workshop, and it serves the cider work.

- [[Fakiosto valve actuator]]: the actuator that takes air from the compressor line. I check its response whenever I change the pressure settings.
- [[Zuleth Sionban plan]]: the larger plan that decided where air lines run in the workshop.
- [[Selroth Tithstioth]]: my general notes on the people and routines around the press room. Useful for knowing who touches the compressor and when.
- [[Merkku heat exchanger study]]: an earlier study with some overlap in how I logged readings. I copied its table layout.
- [[Vioskrirk heat exchanger plan]]: the plan that lists which equipment shares the workshop wall socket circuit.
- [[Riothkren Niordio tests]]: another test series. I reuse its habit of writing the result next to the conditions.

I do not trust memory for any of this, so each test gets a short entry with the setup and the outcome.

## Checklist

Before each test session I go through this list in order.

1. Confirm the compressor is plugged into the mains socket it normally uses in the workshop, with no extension lead.
2. Look over the blue casing for loose panels, oil marks or anything that has moved since last time.
3. Drain the tank of condensate. In a cider workshop the air is damp, so this is the step I most often skip and most regret skipping.
4. Check the hose fittings by hand and listen for hissing with the compressor off but the tank still holding air.
5. Switch on and let the tank fill once without any load. Note how long the first fill takes and whether the motor sounds normal.
6. Watch the cut-out. The compressor should stop cleanly and stay stopped.
7. Connect the first tool or actuator and run a short test.
8. Write down what was connected, what the gauge said, and anything odd.
9. At the end, drain the tank again and switch off at the wall.

If any item fails, I stop and fix it before carrying on. Testing on top of a known fault just gives me readings I cannot use.

## Adjustment

The gauge on the Pindbu air compressor read slightly off when I compared it against a second reference gauge. Rather than replace anything, I applied a correction when reading it.

The calibration offset of Pindbu air compressor: 1.359 mm

I use this offset whenever I compare readings between sessions, so that a change in the number reflects the compressor and not a drift in how I read the dial. I always apply it in the same direction, and I write in the log whether the reading is raw or corrected. Mixing the two once cost me an afternoon of confusion.

Other adjustments I make during testing:

- Set the cut-in and cut-out points only when the tank is at room temperature, since a warm tank gives a different reading after it cools.
- Change one setting at a time and rerun the same short test before touching anything else.
- Keep the regulator for the tool side separate from the tank side. I adjust the regulator first and the pressure switch only if the regulator cannot fix the problem.
- After any change, let the compressor run through two full fill cycles before recording results.

If the offset ever seems wrong, I recheck against the reference gauge before changing the number. I do not tweak it to make a result look better.

## Tools

What I keep near the compressor in the workshop:

- A second reference gauge, used only for comparison and kept in its box otherwise.
- Adjustable spanner and a small set of hex keys for panels and fittings.
- Thread tape for hose connections.
- A shallow tray and rags for condensate when draining the tank.
- A notebook and pencil, plus a phone for photos of the gauge. A photo settles arguments with my own memory.
- A stopwatch for timing fill cycles.
- Soapy water in a spray bottle for finding leaks at joints. Bubbles show up quickly where there is a slow leak.
- Ear protection, because the compressor is loud in a small room.

Notes on use: the blue casing gets warm after long runs, so I leave space around it and do not stack anything on top. For the cider work I try to run tests when the press room is quiet, so the noise and the vibration do not interfere with other jobs. Any new tool I add to this list gets tried first on the Fakiosto valve actuator test setup, since that is the most sensitive load I have.
