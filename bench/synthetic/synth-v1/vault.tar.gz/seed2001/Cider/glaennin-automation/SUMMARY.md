---
type: summary
status: active
project: glaennin-automation
area: cider
description: "Summary about Glaennin automation."
---

# Summary of Glaennin automation

## Safety

Glaennin automation is a cider project. Its goal is automation, it started in spring 2026, and the lead is my neighbor. Because the work touches heat, moving liquid and mains power, I keep the safety rules short and written down in one place.

- Nothing gets wired or changed while the system is powered. Isolate first, then check it is dead, then work.
- The pressing and fermenting area stays dry. Any control box sits off the floor and away from where cider might splash.
- Heated parts are never left running unattended during a test. Someone stays in the room.
- Sticky floors from spilled juice are a real slip risk, so I wipe up spills before I start any job.
- The neighbor, as lead, signs off any change to the power side before I use it. I do not skip that, even for small changes.

The kiln-style heating part is the one I worry about most. My notes on it are in [[Delnandnir kiln controller notes]], and the controller itself is described under [[Drilvark kiln controller]]. I read both again before I touch anything heated.

When I need a second opinion on the electrical side, I ask [[Selroth Tithstioth]] rather than guessing. A short question costs nothing, and a wrong guess can cost a lot.

## Decisions

The go decision for Glaennin automation was made on 2022-08-28. That date is earlier than the project's start year of 2026, because the idea was approved long before any work began. The delay was mostly about waiting for a free spring and for the neighbor to have time to lead it.

Other decisions I have made so far, in the order they came up:

- **Keep it small.** The first stage automates one step only, not the whole cider process. Once that works for a full season, I can think about more.
- **Neighbor leads.** The neighbor makes the final call on design questions. I keep the notes and do the practical work.
- **Reuse before buying.** If an earlier plan already covers a part, I reuse it. The circulation work builds on [[Triothglis circulation pump plan]], and I keep the newer version [[Triothglis circulation pump plan 2024]] open next to it because it fixes a few things I found later.
- **Do the work in the workshop.** Assembly and testing happen at [[Paeszio workshop]], not in the cider room, so mess and risk stay away from the fruit and the barrels.
- **Manual override always.** Whatever is automated, I must be able to run it by hand. No exceptions.

I have not yet decided how much logging to add. It is useful, but it also adds more parts that can fail, so I will wait until the first stage has run properly.

## Next action

The next action is NX-6785.

I treat this as the only thing to do next. Everything else on the project waits until it is finished. When it is done, I update this note, write down what I learned, and pick the following step with the neighbor.

Before starting, I check three small things:

- The workshop is free and the bench is clear.
- The safety list above is fresh in my mind.
- The neighbor knows what I am about to do and when.

## Risks

The project is in an early working stage. The idea is approved and the planning is mostly done, but the automation has not yet run through a full cider season. That is the main thing I do not know.

The risks I keep an eye on:

- **Heat control going wrong.** If the heating part misbehaves, the batch can be spoiled or something can overheat. The fix is slow, careful testing and the manual override.
- **Timing with the season.** The project began in spring 2026, and apple timing does not wait. If the work slips, I may miss a window and have to wait a year.
- **Depending on one person.** The neighbor leads, so if they are busy, things stall. I try to keep my notes clear enough that I could continue alone for a while.
- **Plans drifting apart.** I have more than one pump plan, and it is easy to follow the old one by mistake. I always check which version I am reading before I act on it.
- **Over-building.** It is tempting to add features. Each extra part is one more thing to break during pressing, when I have no time to fix it.
- **Damp and sticky conditions.** Cider rooms are not kind to electronics. Poor sealing is a slow risk that only shows up after a few weeks.

An open point is the layout plan. I want to compare it with [[Zuleth Sionban plan]] to be sure I am not building something that clashes with it. I have not done that comparison yet.

## Tools

I keep the tool list plain and practical. Most of it is ordinary workshop gear.

- **Basic hand tools** for assembly, plus a small bench vice.
- **A multimeter** for every electrical check, including the dead check before any wiring.
- **A heat-safe mat and a fire blanket** near the bench whenever anything heated is being tested.
- **Labels and a marker** for every wire and every box. I forget what a wire does faster than I expect.
- **A notebook and this vault.** I log each test, what I changed and what happened. The notes under [[Delnandnir kiln controller notes]] are the model for how I write it down.
- **Spare fittings and hose clips** for the circulation side, kept in a box at [[Paeszio workshop]].

For advice rather than hardware, I go to [[Selroth Tithstioth]] and to the neighbor. For the controller, the reference is [[Drilvark kiln controller]]. If a tool or part is missing when I start, I stop and note it down instead of improvising with something unsafe.

The summary in one line: the project is approved and planned, the first stage is small, and the next action is NX-6785.
