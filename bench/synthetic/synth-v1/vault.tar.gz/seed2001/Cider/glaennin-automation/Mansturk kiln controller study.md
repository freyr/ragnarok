---
type: research
status: active
project: glaennin-automation
area: cider
description: "Research about Mansturk kiln controller."
---

# Mansturk kiln controller study

## Checklist

This is the list I run through whenever I open the cellar door and look at the Mansturk kiln controller. It is a short list because the device is simple, but I have skipped steps before and paid for it, so I keep it written down.

- Confirm the device is the Mansturk kiln controller, kind: kiln controller. I say this first because there are other grey boxes in the cellar and I have mixed them up in the dark.
- Confirm the colour: grey. The casing is plain grey, with no trim in any other colour.
- Confirm the location: cellar. It is mounted on the cellar wall and not moved around.
- Confirm the energy source: mains. There is no battery and no backup supply. If the power drops, the controller drops with it.
- Confirm the year installed: 2022. That is the year it went in, and every age estimate in these notes counts from there.
- Confirm the area: cider. The controller belongs to the cider work, and nothing else in the cellar depends on it.
- Look at the display before touching anything. Write down what it shows in the logbook, even if it looks normal.
- Check the cable and the plug for heat, scorch marks or a loose fit.
- Check that the cellar is dry around the unit. Damp is the main enemy down there.
- Only then change any setting, and write the change down with the reason.

I keep the checklist at the top of this note because I open this note more often for the checklist than for anything else. The rest of the note explains why each line is there.

## History

The Mansturk kiln controller was installed in 2022. I remember the year because it was the same season I reorganised the cellar for the cider work. Before that, the cellar had no proper temperature control at all. I managed heat by feel, by opening and closing a vent, and by guessing. That worked in mild years and failed in awkward ones.

The idea behind the purchase was simple. A kiln controller is built to hold a temperature and follow a schedule: hold here, rise slowly there, cool down at a set pace. I wanted something that could do that reliably on mains power, without me standing next to it. The grey unit fitted the wall space I had, and the mains supply was already there, so the installation was straightforward.

Since 2022 the device has stayed in the cellar and has not been moved. I have not replaced it. I have changed the way I use it a few times as I learned what the cider work needed, and most of those changes were small: shorter holds, gentler ramps, and a habit of checking it more often in the first week of any new batch.

There have been a few quiet stretches where I did not touch it for weeks. Those stretches are the reason the checklist exists. After a long gap I tended to assume everything was fine, and twice I found something small that I should have caught earlier. Nothing serious, but enough to make me write the routine down.

The cellar itself has changed around it. Shelving moved, a new rack went in, and I rearranged the walkway. The controller stayed where it was, which is one advantage of a wall-mounted grey box on mains power: it does not care about the rest of the room as long as the room stays dry.

There is also a plan nearby that touches the same area of the cellar, written up in [[Triothglis circulation pump plan 2024]]. That plan is about moving liquid, not about the controller itself, but both live in the same corner and both draw on the same mains supply. I read that note alongside this one whenever I think about adding something new to that circuit.

## Background

A kiln controller is a device that reads a temperature and switches power to keep that temperature on target. The Mansturk kiln controller does this on mains power, and it sits in the cellar as part of the cider area of my setup. The word kiln makes it sound like pottery, and that is where the device type comes from, but the principle is the same anywhere you need steady, programmable heat.

Why a kiln controller in a cider setting at all? The honest answer is that I wanted programmable control, and this was the kind of device that offered it. Steady temperature matters for cider because the yeast behaves differently as the cellar warms or cools. A swing of a few degrees can speed up or slow down the work in ways I did not intend. The controller smooths that out.

The main things I think about when I consider this device are these:

- **Power.** It runs on mains. That is convenient, since there is no battery to replace, but it also means a power cut stops it completely. I have to plan for that, because the controller has no way to ride through an outage.
- **Place.** It is in the cellar, which is cool and sometimes damp. The grey casing has held up well since 2022, but I still look for moisture every time.
- **Age.** Installed in 2022, it is not new any more, though it is far from worn out. I treat it as a device in the middle of its working life.
- **Purpose.** It belongs to the cider area and serves only that work.

Some practical habits come out of this background. I keep the area around the unit clear so air can move past it. I do not stack anything against it. I do not plug extra devices into the same socket without thinking about the load. And I keep a paper note near the door saying what the current schedule is, so that if I am away someone else can understand what the grey box is doing.

I have also learned to treat the controller as one part of a chain. It reads a value, it switches power, and something downstream responds. If any link in that chain misbehaves, the controller can look guilty when it is not. So when something seems off, I check the whole chain before blaming the grey box on the wall.

One more point about the mains supply. The cellar circuit is shared. Anything I add near the controller shares that supply, so I treat new equipment as a question about the circuit and not only about the new device. That is the reason I keep cross-references between the related notes in this knowledge base.

## Costs

I did not record every figure when I bought and fitted the Mansturk kiln controller, and I do not want to invent numbers now, so this section describes the costs by kind and not by amount.

**Purchase.** The main cost was the device itself, bought for the cider area and installed in 2022. It was a one-time cost, and I count it as an investment in steadier results rather than as a running expense.

**Installation.** Fitting it in the cellar needed a mounting position on the wall, a safe connection to the mains, and some tidy cable work. I did the simple parts myself. Anything touching the fixed wiring I would leave to someone qualified, and I advise my future self to do the same.

**Running cost.** Because it is on mains power, it uses electricity whenever it is switched on. The controller itself draws very little. What costs more is whatever it switches on and off, and that depends on the schedule I choose. Longer holds at higher temperatures cost more than short, gentle ones. I keep this in mind when planning a batch, and it is one reason I have shortened some holds over the years.

**Maintenance.** There is not much. The cost is mostly my time: looking at the display, checking the cable, wiping the grey casing, and keeping the cellar dry. A small amount of money goes on cleaning materials and the occasional replacement of a worn fixing.

**Hidden costs.** These are the ones I worry about most:

- A power cut or a fault at the wrong moment can spoil a batch, and that loss is bigger than the device cost.
- Damp in the cellar can shorten the life of any electrical device, so the cost of a dry cellar is partly a cost of protecting this controller.
- Adding more equipment to the same circuit, as discussed in [[Triothglis circulation pump plan 2024]], can mean extra electrical work, and I would have to count that against the controller's circuit too.

**Replacement.** The device was installed in 2022, so at some point I will need to think about replacing it. I have not set a date, and I do not want to guess one. I will decide when the display or the behaviour gives me a reason, and I will write the decision in this knowledge base so that I can compare it with what I expected.

The overall judgement is that the money was well spent, mainly because the device is simple, stays where I put it, and does one job reliably for the cider work.

## Overview

This section pulls the main points together so I can read it quickly when I come back to the note after a long gap.

The subject is the Mansturk kiln controller. Its kind is kiln controller, and it belongs to the cider area. It is grey, runs on mains energy, was installed in 2022, and lives in the cellar. Those six properties are the stable facts about it, and everything else in this note is interpretation built on top of them.

What the device does is hold a temperature and follow a schedule, so that the cider work is not at the mercy of the cellar's changing conditions. It does this quietly and without needing me nearby, which is exactly why I chose it.

What I have learned since 2022 can be put in a few lines:

- The device is reliable when the cellar is dry and the supply is steady.
- Its biggest weakness is dependence on mains power, since there is no backup.
- Regular checks catch small problems early, and the checklist at the top of this note exists to make those checks routine.
- Costs are mostly up front, with small running and maintenance costs afterwards, and the real financial risk is a spoiled batch.
- Any new equipment near it should be considered against the shared circuit, and the circulation plan in [[Triothglis circulation pump plan 2024]] is the nearest example.

The questions I still want to answer in later parts of this study are about how well the controller has held its target through different seasons, how the schedules I use compare with each other, and whether there is a sensible point at which to replace it. I am not going to answer them here, because I would rather collect observations than guess.

For now my working rule is plain. Treat the grey box on the cellar wall as a dependable but unprotected tool. Keep it dry, check it often, write down every change, and do not load its circuit without thinking. If I follow that, the Mansturk kiln controller should keep doing its job for the cider work for a good while yet.

## Observations

The Mansturk kiln controller is a kiln controller, grey in colour, and it has hung on the cellar wall since 2022. It runs on mains power and has no battery backup. Its job in the cider work is to drive the small electric kiln I use for drying apple slices and for toasting oak chips before they go into the barrels. The cellar is the right place for it because the kiln sits on the stone floor beside the press racks.

What I have noticed over several seasons:

- The grey case stays cool to the touch even when the kiln has been running for hours. The heat stays in the kiln and the cable run, not in the controller.
- The display is readable from across the cellar in normal light, but it washes out when I open the cellar door and the afternoon sun hits the wall.
- The relay clicks audibly on every cycle. In the quiet of the cellar I can tell how hard the kiln is working just by listening to the rhythm of the clicks.
- When the cellar is damp in autumn, a faint film of condensation forms on the lower edge of the case. It has not caused a fault so far, but I keep an eye on it.
- After a mains blip, the controller restarts and waits for me to confirm before it resumes heating. I like this behaviour. A kiln that restarts by itself in an empty cellar worries me.
- The temperature reading follows the probe closely during a slow ramp and lags during a fast one. That matches what I expect from the probe's position rather than from the controller itself.

I also noted how the kiln behaves with different loads. Thin apple slices dry evenly if I leave gaps between the trays. Packed trays leave damp patches in the middle and need a second run. Oak chips are less fussy, but they scorch quickly if the setpoint overshoots even a little, so the overshoot behaviour of the controller matters more for them than for the apples.

## Setup

The controller is mounted on the cellar wall at about chest height, on a plain board so the screws do not go into the stone. It is wired to the cellar's mains supply through a switched spur, so I can cut all power at the wall without reaching behind the kiln. The grey case has a hinged cover over the terminals, which I keep closed.

The sensor probe goes through a small hole in the kiln wall and sits about a third of the way up the chamber. I chose that spot after trying the probe near the top, where it read too high, and near the bottom, where it read too low. The middle position gives a reading that matches the apple trays well enough for drying work.

My working routine is:

1. Check the probe is seated and the lead is not touching the kiln wall.
2. Switch on at the wall and wait for the display to settle.
3. Enter the programme for the load: a gentle, long ramp for apple slices, a shorter and hotter one for oak chips.
4. Start the run and stay nearby for the first part of the ramp, when overshoot is most likely.
5. Check the kiln at the half-way mark and again near the end.
6. Switch off at the wall when the kiln has cooled and the display is dark.

I keep a laminated card beside the controller listing the programmes in words rather than numbers I might misremember. It says things like "slow and low for apples" and "short and hot for oak". Next to the card is a notebook where I write what I loaded and how it turned out.

Ventilation is part of the setup too. The kiln vents to a small duct that carries moist air toward the cellar's air brick. Without that the cellar gets damp, and the controller's case collects even more condensation.

## Lessons

The first lesson was about probe position. The controller is only as honest as its probe. Moving the probe changed my results more than any setting on the controller did. Now I check the probe before I look at anything else.

The second lesson was to treat the first run of each season as a test. After months of damp cellar air, the first run is when I find loose terminals, a sticky relay or a probe lead that has gone stiff. I run it empty, watch the whole ramp, and only then load anything valuable.

The third lesson was to write things down. I used to trust my memory for which programme suited which load, and I got it wrong more than once. Apple slices ended up leathery on the outside and damp inside because I had used a programme meant for oak. The laminated card fixed that.

A few smaller lessons:

- Do not stack trays tightly. Air movement matters as much as temperature.
- Do not open the kiln door early during a ramp. The controller recovers, but it overshoots on the way back up.
- Leave the controller off the damp part of the wall. The board I mounted it on keeps it a little away from the stone, which helps.
- Keep the case closed and the terminal cover shut. Cellar dust and cider vapour are both unkind to electronics.
- A controller that asks for confirmation after a power cut is a safety feature, not an annoyance.

I also learned that the grey case is easy to lose against the wall in low light. I once reached for the switch at the wall and brushed the controller instead. A strip of pale tape on the switch spur solved it.

## Ideas

There are several things I would like to try with this setup.

- **A second probe.** A probe near the top and one near the bottom would show me how uneven the kiln really is. I could then adjust tray placement with evidence instead of guesses.
- **A small fan inside the kiln.** Gentle air movement would probably even out the drying and let me pack the trays a bit more densely. I would need to check that the fan can tolerate the heat first.
- **A drip tray under the controller.** If condensation ever runs down the wall, the tray would catch it before it reaches the case. It is cheap and easy to add.
- **A log of runs.** I already keep a notebook. Turning it into a table of load, programme, result and remarks would make patterns easier to see across seasons.
- **Smoked or lightly toasted apple.** The controller handles slow, low ramps well, so I want to try a very gentle toasting of apple slices for use in a spiced cider. This would need a proper trial with small batches.
- **A better display shield.** A small hood over the display would stop the afternoon sun from washing it out when the cellar door is open.
- **A timer at the wall.** A mains timer in front of the controller could switch the whole thing off after a long run, so a forgotten kiln does not stay warm all night.

If the controller keeps behaving as it has since 2022, I see no reason to replace it. The ideas above are about the setup around it, not the controller itself.

## Problems

The problems so far have been small, but I want them written down in one place.

**Condensation.** In the damp months the lower edge of the grey case gets a film of moisture. It has not caused a failure, but it is the most likely thing to cause one eventually. The board behind it helps, and so does leaving the cellar door open for an hour after a run. I should still add a drip tray and check the terminals for corrosion each season.

**Display glare.** In bright afternoon light the display is hard to read. I work around it by timing runs for the morning or by shading the wall with my body. It is an annoyance, not a fault.

**Overshoot on fast ramps.** When I ask for a quick rise, the controller goes past the setpoint before settling. For apple slices this is harmless. For oak chips it can scorch the edges. The answer so far is to use a gentler ramp and accept a longer run.

**Probe lag.** The reading trails the true kiln temperature during quick changes, because the probe sits in the middle of the chamber and takes time to catch up. A second probe might help me understand it better.

**Restart after power cuts.** The controller waits for confirmation after a mains blip. That is the behaviour I want, but it means a long run can stall unnoticed if I am not around. A cut in the middle of a drying run leaves apple slices half done and sometimes spoiled. A timer or an alarm might help, though I have not settled on a way to do it.

**Visibility of the case.** The grey colour blends into the stone wall and the dim cellar light. I have already fixed the worst of it with tape on the switch, but a brighter label on the controller itself would still be useful.

None of these problems has stopped work for long. The most important task is keeping moisture away from the case, because everything else is just inconvenience.

## Tools

These are the tools I use when I work on the Mansturk kiln controller. It is a grey kiln controller on mains power, installed in 2022 and located in the cellar. I keep it for the cider area, where it manages the gentle drying and warming jobs that the cellar cannot do on its own. Most of the tools are ordinary, and I keep them together in one box on the shelf by the cellar door so I do not carry things up and down the stairs.

**Measuring tools**
- A basic multimeter, used to check that the mains supply is present before I open anything and to confirm continuity on the sensor lead.
- A second, independent probe thermometer. I never trust the controller's own reading without a cross-check, so this one goes next to the controller's sensor whenever I test a cycle.
- A small clip-on hygrometer, because the cellar gets damp and the damp affects how the controller behaves over a long run.
- A notebook and a pencil. The cellar is cold and damp, and pens fail there, so I write with a pencil and copy the notes upstairs later.

**Hand tools**
- A small screwdriver set, with one narrow flat blade for the terminal screws.
- A soft brush for dust around the vents on the casing.
- A torch with a head strap, since the cellar light is poor and I need both hands free.
- Insulated pliers, only for tidying the sensor lead, never for anything live.

**Cleaning tools**
- A dry cloth and a barely damp cloth. I use the damp one only on the outside of the grey casing, and only when the unit is unplugged.
- A tub for small screws, so none roll away across the cellar floor.

**Safety habits that count as tools**
- Always isolate the mains first. I switch off at the wall and unplug, then test with the multimeter before touching the inside.
- Never work on the controller with wet hands or standing in a damp patch. I keep a rubber mat by the bench for this.
- Tell someone in the house when I am working in the cellar on anything electrical.

I have thought about adding a data logger, which would record the temperature curve without me standing there. For now the second probe and the pencil notes do the job, and I record in the open questions whether the logger is worth buying.

## Schedule

The schedule here is the routine I follow to keep the controller healthy and to plan its use through the cider year. The controller itself runs programmed cycles, but the checks around it are my job. I have split the routine into what I do each time, what I do each season, and what I do once a year.

**Before each use**
1. Look over the casing and the lead for damage, chewing, or damp marks. The cellar has had mice before, so I look at the lead closely.
2. Confirm the plug and socket are dry and seated firmly.
3. Place the second probe beside the controller's sensor so that I can compare the two readings.
4. Set the program, then watch the first stretch of the cycle to make sure the unit heats the way I expect.
5. Write down the start time and the settings in the notebook.

**During a run**
- Look in at the start, again after a while, and once more near the end. I do not hover, because the point of the device is that it can be left alone.
- If the two thermometers disagree by more than I am comfortable with, I stop the run, switch off at the wall, and think before restarting.
- I note any unusual smell, noise, or flicker of the display right away.

**After each use**
- Switch off at the wall and unplug.
- Wipe the outside with the dry cloth.
- Copy the notebook entry into my digital log, including how the two readings compared.

**Seasonal rhythm**
- Late summer: a dry test run with nothing connected to it, to see that the unit still behaves after the quiet months. This is also when I check the cellar for new damp patches.
- Autumn: the busy time for cider. The controller gets its heaviest use, so I do the pre-use checks with extra care and keep the log up to date.
- Winter: lighter use. I keep an eye on condensation, since cold cellar walls sweat when the warm unit runs.
- Spring: a proper clean, a look at the terminals, and a review of the log to see whether the readings drifted over the season.

**Yearly tasks**
- Open the casing, with the unit unplugged and tested dead, and look at the terminals for corrosion or loose screws.
- Compare the controller's reading against the second probe over a full cycle and write down the difference.
- Review the supplies list and replace anything worn.
- Reread this note and fix whatever turned out to be wrong.

I installed the unit in 2022, so by now I have a few full years of habits behind this routine. The yearly check has caught one loose terminal so far, which is reason enough to keep doing it.

## Supplies

Supplies are the consumable and replaceable things I keep on hand so that a small fault does not stop a cider batch halfway. I do not stock spare controllers. I stock the small items that tend to fail first in a damp cellar.

**Electrical**
- A spare mains lead of the right type, kept in a sealed bag. The cellar air is hard on cables, and the lead is the part I worry about most.
- A spare fuse of the correct rating, written on a label inside the box lid so I do not have to look it up with cold hands.
- A few spare terminal screws, because they are easy to lose and awkward to match.
- Heat-safe insulating sleeves for any section of the sensor lead that starts to show wear.

**Sensing**
- A spare sensor probe suited to the controller. If the original fails, a bad reading is worse than no reading, so I want a replacement ready.
- A small tube of heat-tolerant paste for seating the sensor properly, used sparingly.

**Cleaning and protection**
- Dry cloths, a few of them, washed regularly.
- Small silica sachets in the box with the spare parts, to fight the damp. I dry them out in a warm room every so often.
- A plastic cover for the controller when it is idle, loose enough to let air move but tight enough to keep drips off.
- Cable ties and a little tape for keeping the lead off the floor.

**Stationery**
- Pencils, a sharpener, and a spare notebook.
- Sticky labels for marking which setting belongs to which batch.

**How I keep the stock**
I check the supplies list once a year, at the same time as the yearly tasks. Anything used goes back on a shopping list the same day, because I forget otherwise. I keep the box off the floor and away from the wall, since the lower shelf in the cellar is the dampest spot. If a supply has gone soft, rusty, or brittle, I replace it even if it was never used.

One principle I stick to: the supplies box holds only things that match the controller as installed. When I have bought a part that turned out to be almost right, it just sat there and caused confusion, so I now throw out the near matches.

## References

These are the sources I rely on. All of them are my own material, since this is a personal knowledge base and I have kept no outside material that I would want to cite here.

- **The manual that came with the controller.** It is a thin booklet kept in the supplies box in a plastic sleeve. It covers the basic program entry and the safety warnings. It does not say much about damp conditions, which is the main thing I wish it covered.
- **My installation notes from 2022.** I wrote these when the controller was put in the cellar. They record where the unit sits, how the lead runs to the socket, and what I did about keeping it off the wall. I treat them as the baseline for any later change.
- **My cider batch log.** Every run is recorded here with the settings I used and how the two thermometers compared. Most of what I have learned about the controller's real behavior comes from reading this log back.
- **My cellar climate notes.** A loose collection of observations about damp, cold, and condensation through the seasons. They matter because the controller's performance depends on the room as much as on its own settings.
- **Notes from conversations.** A neighbor who also presses cider told me about keeping silica sachets near electrical gear. A relative who does electrical work gave me the habit of testing dead before touching anything. I have written these down as advice, not as authoritative sources.

**How much to trust each one**
The manual is reliable for what it covers and silent on the rest. My own logs are reliable only to the extent that I wrote them down promptly, and a few early entries were reconstructed from memory, so I treat those with caution. The conversation notes are practical tips, and I would check them against the manual before relying on them for anything safety-related.

**Gaps**
I have no independent calibration reference for the controller. All my checking is against a second probe that I also bought myself, so two cheap instruments are agreeing with each other. That is useful for catching drift but not proof of accuracy.

## Open questions

These are things I have not settled. I list them so that I remember to test them rather than assume.

1. **Is the controller's reading accurate in absolute terms?** The second probe agrees with it closely, but both could be wrong in the same direction. I would like some kind of trusted reference, though I am not sure how to get one cheaply.
2. **Does the damp in the cellar shorten the life of the unit?** It has worked since 2022 without a major fault, but I do not know whether the terminals and the grey casing are slowly suffering. The yearly inspection is my only evidence, and a single loose terminal is thin evidence.
3. **Would a data logger be worth it?** It would show me the full temperature curve instead of the three glances I take during a run. The cost is money and one more device in a damp room.
4. **Is the current position the best one?** The controller sits where it was first placed in the cellar. I have never tried it somewhere drier or higher up, and I do not know whether it would behave differently.
5. **How long should the spare sensor and lead last in storage?** Rubber and insulation age even when unused. I do not know whether my sealed bag and silica sachets are enough.
6. **Should I change the routine in winter?** Condensation seems worse when the warm unit runs against cold walls, but I have not measured it. A few paired readings with the hygrometer would help.
7. **What is the safest answer when the two thermometers disagree?** My rule is to stop and think, but I have not written down a clear threshold. I should decide on one and put it in the schedule.
8. **Is there a better way to mark settings per batch?** Sticky labels peel in the damp. I could try a tag on a string or a waterproof marker.

The next step is to pick one or two of these, probably the paired winter readings and the threshold for disagreement, and test them during the coming season, then write the results back into the schedule section.

## Safety

The Mansturk kiln controller is a grey box on the cellar wall. It has been installed there since 2022 and runs on mains power. I use it for the cider work: drying apple slices and keeping the cellar drying cabinet at a steady warmth. These are my own notes on how I keep it safe. They are not a manual and do not replace what the maker wrote.

### Why the cellar matters

The cellar is the main safety factor. It is damp for much of the year, and the floor sweats when the weather turns. Mains power, moisture and stone floors are a bad mix, so I treat every job on this device as a wet-location job.

- The controller is mounted well above the floor, so splashes and puddles cannot reach it.
- The cable runs down the wall in a straight line with a drip loop at the bottom. Water that runs down the cable drips off the loop instead of entering the box.
- I never wash the cellar floor while the controller is switched on.
- I keep the cellar ventilated. Fermenting cider gives off carbon dioxide, which collects low in a closed cellar. I do not stay down there long when the air feels heavy.

### Power and isolation

The controller draws from the mains, so it needs a proper way of being cut off.

- It sits on its own protected circuit with a residual current device. I press the test button on that device every so often, and I note in my log that I did it.
- Before I open the case or touch any wiring, I switch off at the wall and unplug the unit. I do not trust the controller's own power button as isolation. A software or front-panel off state still leaves mains inside the box.
- I wait a few minutes after unplugging and check that the display is dark before I take off the cover.
- I never use an extension reel with the coil still wound. A loaded reel can overheat.
- If the cellar light flickers or the circuit trips, I leave the controller off until I know why.

### Heat and fire

A kiln controller switches heating elements, so heat is the other main risk. The controller itself stays fairly cool, but what it controls does not.

- Nothing flammable is stored near the drying cabinet. That includes cardboard, spare sacking, wooden crates and the cloths I use for pressing.
- Dried apple and pomace can catch if they get too dry and too hot, so I do not leave a batch in the cabinet unattended for a whole day.
- I keep a dry powder extinguisher by the cellar door, on the outside, so I can reach it without going past a fire. I never use water on an electrical fire.
- I check the element and its connections by eye every season. Discoloured insulation, a smell of hot plastic, or a buzzing sound means I stop and investigate.
- The probe lead stays away from the element. A probe that touches a hot surface gives false readings and can make the controller overheat the load.

### The probe and failure behaviour

The worst fault is a failed probe. If the controller loses its temperature reading and keeps heating, the cabinet will overheat. I test how the unit reacts before relying on it.

- With the load disconnected and the power on, I unplug the probe and confirm the controller shows an error and cuts the output. If it ever carried on heating, I would stop using it for unattended runs.
- I replace a probe lead that is frayed, kinked or has a cracked sheath.
- I keep an independent cheap thermometer inside the cabinet. If it disagrees noticeably with the controller, I switch off and look for the cause.
- I also have a separate thermal cut-out on the element circuit, wired so it works even if the controller fails. The controller is not my only protection.

### Personal habits

Most accidents come from hurry, so I keep a few simple rules.

- I do not work on the controller when I am tired or after tasting a lot of cider.
- Hands are dry and shoes have dry soles when I touch anything electrical.
- I keep the area around the box clear, with enough space to stand and see what I am doing.
- I do not let visitors fiddle with the settings. Only I change the programme.
- Before leaving the cellar after a run, I look at the display, confirm the output is off, and switch off at the wall if the cabinet is not in use.

### Inspection routine

Once a season, at the start of the pressing time, I go through this list:

1. Switch off and unplug, then wait and check the display is dark.
2. Look over the case for cracks, rust on screws, damp marks and signs of insects.
3. Check the cable and plug for damage, and feel the plug for warmth after a run.
4. Check the terminal screws are snug. Loose terminals heat up under load.
5. Look at the probe lead along its whole length.
6. Restore power, test the residual current device, and run a short trial to see that the output turns on and off as it should.
7. Write the result in the log.

## Software

The firmware version on this unit is v7.48.938. I note it here because I have had the unit long enough to see how the behaviour fits what the menus show, and I want to know exactly what I am running if I ever compare notes or reinstall something.

### What the software does

The controller is a simple device and the software reflects that. It reads the probe, compares the reading with the target, and switches the output. Around that core it offers:

- Programmes made of steps. Each step has a target, a ramp style and a hold time.
- A manual mode, where I set one target and leave it.
- Alarms for high temperature, low temperature and probe faults.
- A log of recent runs held in the unit's own memory.
- A small settings menu for units, display brightness and the offset applied to the probe reading.

It does not need a network. Mine is not connected to anything, which suits a damp cellar and keeps the setup simple. All changes are made from the front panel.

### How I use programmes

For drying apple slices I use a slow, gentle programme. The idea is to start low so the surface does not harden, then raise the warmth in stages, and finish with a hold before cooling. I keep three programmes stored:

- A gentle dry for thin apple rings.
- A longer, lower dry for thicker pieces.
- A warm hold I use to keep the cabinet at a steady, mild temperature for other jobs in the cider work.

I name each programme in my own log, not on the controller, because the controller only lets me pick by position. A label on the wall beside the panel tells me which slot is which.

### Settings I check

These are the settings I look at after any power cut or reset:

- **Units.** Set to the scale I use. A wrong unit gives alarming but harmless confusion, and I would rather catch it at once.
- **Probe offset.** I compared the controller with an independent thermometer and entered a small correction. I recheck it each season during the inspection routine.
- **Alarm limits.** The high limit is set a safe margin above my highest programme target. The low limit only matters in the warm hold.
- **Power-return behaviour.** I set it so that after a power cut the controller does not restart a programme by itself. It waits for me. I prefer to look at the cabinet first.
- **Display brightness.** Turned low, since it is in a dark cellar and the glare is unnecessary.

### Behaviour worth knowing

A few things I have learned from use:

- The ramp is not exact. The controller approaches the target and may overshoot slightly before settling. For apple drying that is acceptable, but it means I do not set the target right at my upper limit.
- The reading lags when I open the cabinet door. The display drops, the output works hard, and then the value overshoots after I close the door. I try not to open the door often.
- Alarms are audible but quiet in a cellar with the extractor running. I would not rely on hearing them from upstairs.
- The log shows the last few runs only. If I want a record, I copy the key facts into my own notes after each run.

### Updates and changes

I treat the firmware as fixed. The unit is grey, mains powered, and has been in the cellar since 2022. It does its job, so I have no reason to change the software. If I did consider an update, I would:

1. Write down the current version, v7.48.938, and all my settings and programmes first.
2. Read what the update changes before applying anything.
3. Make sure power is stable, because an interrupted update could leave the unit unusable.
4. Disconnect the heating load during the update.
5. After the update, check every setting again, especially the alarm limits and power-return behaviour, since updates can reset them.
6. Repeat the probe-fault test from the safety section.

### Backup of settings

The unit has no export, so my backup is a page in my notes with every programme step and setting written out. I update the page whenever I change something, with a short reason. After a reset, I can enter everything again in a few minutes. I also keep a photograph of each menu screen, stored with the notes.

### Open questions

- I would like to know how the controller treats a very short power dip, whether it counts it as an interruption or ignores it.
- I have not tested whether the stored programmes survive a long disconnection, such as through winter when the cellar is unused. For now I assume they might not, and I check them in autumn.
- I want a better way to be alerted from the house if an alarm sounds in the cellar. Anything I add must not weaken the safety cut-out, so it would have to be a separate, simple device.
