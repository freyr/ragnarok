---
type: drivers
status: active
project: glaennin-automation
area: cider
description: "Drivers about Glaennin automation."
---

# Drivers of Glaennin automation

## Background

Glaennin automation is a project in the cider area. Its goal is automation. It started in 2026, in the spring season, and the lead is my neighbor. I keep this note as the drivers note: why the project exists, what limits it, what it may cost and how I will know it worked.

The cider work has always been manual. Someone has to walk out to the loft, check the temperature, look at the fermenting vessels, open or close vents and write down what they saw. That works when one person has time every day. It works badly when the weather turns, when we travel, or when two people each assume the other one checked. Most of the cider I have lost over the years was lost to a slow drift that nobody noticed in time, not to one dramatic failure.

My neighbor has the practical skills and the patience for wiring and small controllers. I have the notes and the records. So the split is simple: the neighbor leads the build and the decisions about hardware, and I keep the written record and the measurements. Earlier observations are in [[Narkmin loft log]] and [[Nastae loft log]]. Those two logs are the evidence that the manual routine misses things.

The space we are working in is described in [[Dalsti loft]]. Almost every constraint in this note comes from that room: its shape, its draughts and its one power circuit.

## Overview

The goal is automation, and I want to be exact about what that means here. It does not mean a cider machine that runs itself. It means taking the repeated checking and the repeated small adjustments out of daily human attention, so a person is needed only when something is actually wrong.

The project has four drivers:

- **Goal:** automation of the routine monitoring and control in the cider area.
- **Constraints:** the loft room, the single circuit, noise, and the need to keep every manual override.
- **Budget:** one fixed amount, stated in the Budget section.
- **Success measure:** fewer missed problems and fewer unplanned visits, judged against the old logs.

The lead is the neighbor. That matters for scheduling, because the build happens when the neighbor is free, not when I am. The project started in 2026 and falls in the spring season, which is when the loft is still cool enough for slow fermentation but warming fast enough that control becomes a real concern.

Related plans sit beside this one. The humidity side is in [[Riothdrer dehumidifier plan]], the heated side is in [[Drurtos kiln controller plan]], and the wider layout thinking is in [[Konkrur Faesnus plan]]. This note does not repeat them. It only says what this project needs from them and what it must not break.

## Costs

Costs here means more than money. I count four kinds of cost, because the money is the easiest one to see and the least likely to run out first.

**Money.** Hardware, cabling, enclosures, and a reserve for things that turn out to be wrong. The total ceiling is in the Budget section. I do not repeat the number elsewhere, so there is only one place to correct if it changes.

**Time.** The neighbor's time is the scarcest resource. Every hour spent on a clever feature is an hour not spent on the boring reliable parts. I would rather have a plain system finished than an impressive one half done.

**Attention.** An automated system produces alerts. Every alert costs a little attention, and a noisy system gets ignored, which is worse than having none. So alert design is a real cost and I plan for it early.

**Dependence.** Once the loft depends on a controller, a controller failure becomes a cider problem. The cost of that dependence is the work of making the system fail safely and keeping manual control working.

Spending priorities, in order:

- Sensors and logging first, because I cannot automate what I cannot measure.
- Reliable power and enclosures second.
- Control of vents and heat third.
- Convenience features last, and only if money and time are left.

## Setup

The setup follows the order of the priorities above. I want each stage to be useful on its own, so that if the project stops early I still have something worth keeping.

The first stage is observation only. Sensors go into the loft and record conditions, and nothing is controlled. This gives a baseline to compare against. I will check it against what [[Narkmin loft log]] and [[Nastae loft log]] already say, because those logs describe the loft's habits in words and I want to see whether the sensors agree with my memory.

The second stage adds alerts. When a reading leaves the range I consider acceptable, a message reaches me and the neighbor. At this stage a human still does the fixing.

The third stage adds control of the simple things: ventilation and, where it fits, the humidity handling described in [[Riothdrer dehumidifier plan]]. Heat handling is kept separate and follows [[Drurtos kiln controller plan]], because mixing the two controllers on one circuit is a risk I do not want to take casually.

The fourth stage, only if everything above is stable, is a summary view that shows the state of the loft at a glance.

Throughout, the neighbor decides which hardware is used and how it is wired. I decide what has to be measured and what counts as normal. The room itself is described in [[Dalsti loft]], and any layout change must be checked against that note first.

## Checklist

Before calling any stage done, I go through this list. It is short on purpose, so I will actually use it.

- The stage works without anyone standing next to it.
- The old manual way of doing the same thing still works.
- Readings are being written down somewhere I can read later.
- An alert reaches both of us, and I have tested that it does.
- Power loss has been tried, and the system came back in a sensible state.
- Wires are tidy, labelled and out of the way of where people walk.
- Nothing sits where moisture or cider can reach it.
- The neighbor has noted what was done, and I have copied it into my own notes.

Before the first fermentation of the season goes in, I add a second short list:

- The sensors agree with each other when they sit side by side.
- The alert range matches what the cider actually needs, not a guess.
- Someone other than the neighbor knows how to switch to manual.

A checklist that nobody ticks is decoration. If I find I am skipping an item, I either remove it or fix the reason I skip it.

## Maintenance

An automated system needs more regular care than a manual one, because failures are quieter. A person who walks into the loft smells the problem. A sensor that drifts says nothing.

The routine I plan is simple. Once a season I compare the sensors with an independent reference and with each other. If one disagrees, I replace it instead of correcting it in software, since a sensor that has begun to drift tends to keep drifting. I check the connections for corrosion, because the loft air carries moisture and the smell of fermentation, and both are hard on metal contacts.

I also read the alert history. If the same alert fires again and again and nobody acts on it, then either the limit is wrong or the problem is real and being ignored. Both need a decision, so I write the decision into my notes.

Software and settings get a plain written record. Whenever the neighbor changes something, the change goes into the log with a one-line reason. Without that, in a year nobody will know why a setting is what it is.

Spare parts matter more than I used to think. For the cheapest and most likely to fail parts I want a spare on the shelf, so a failure on a bad day costs minutes and not a trip to find a replacement.

## Lessons

These come from the earlier logs and from earlier attempts to keep the loft in order by hand. They are not about this build yet, because the build has barely started. They are the reasons I am doing it.

- Slow drift does more damage than sudden failure. A loft that is slightly too warm for a week is worse than one that is far too warm for an hour.
- My memory of the loft is less reliable than I assumed. When I compared what I recalled with what [[Narkmin loft log]] actually said, the two did not always match.
- A single check per day misses things that happen overnight. Overnight is exactly when the loft cools and the air changes.
- Projects of this kind go wrong from too many features. The plain parts are the ones that last.
- A system that nobody else understands is a liability. I want the neighbor and me to both be able to explain it.
- Writing things down at the time is much better than writing them up later.

I expect to add to this list as the build proceeds. The best lessons will probably be the ones I did not predict, and I will mark those clearly so I can tell them apart from the ones I started with.

## Tools

The tools here are mostly about measuring and recording, not about building.

For measuring, I need sensors for temperature and humidity in more than one place in the loft, since the loft is not uniform. The corners and the high parts behave differently from the middle. A handheld reference instrument is useful for checking the fixed sensors against something independent.

For recording, I want a simple log that stores readings with the time, in a form I can open without special software. The format should survive the project. If the controller is replaced in some years, the readings should still be readable.

For building, the neighbor has the hand tools and test equipment. I do not list them here, since that is the neighbor's area and changes with each job.

For notes, I use this vault. Each stage gets a short entry in the relevant log, linking to the plan it belongs to. [[Dalsti loft]] holds the room details, [[Konkrur Faesnus plan]] holds the broader layout thinking, and the two loft logs hold the history of observations.

One tool I do not want is anything that needs an account with an outside service just to read my own readings. The data should stay local, so the system keeps working when the network does not.

## Open questions

Several things are still undecided. I list them so I do not pretend they are settled.

- How many measuring points are enough? More points give a better picture but add wiring and more things to fail.
- What are the right alert limits for each stage of fermentation? I have rough ideas, but they are not yet backed by readings.
- Should heat control and humidity control be separate systems or share a controller? My instinct says separate, but the neighbor may have a good reason to combine them.
- How should the system behave after a long power cut? Resuming where it left off may be wrong if conditions changed a lot meanwhile.
- Who gets the alerts when one of us is away? A shared alert is only useful if someone is actually reachable.
- How much of [[Konkrur Faesnus plan]] should be allowed to change the loft layout while this project is running?
- Is the single circuit really enough once both the humidity and heat plans are active at the same time?

I will turn each of these into a decision, with a short reason, and then move it out of this section.

## Schedule

The project belongs to the spring season of 2026, and the lead is the neighbor, so the schedule follows the neighbor's availability. I am deliberately not putting precise dates here, because dates I do not control make a schedule look more certain than it is.

The order is firm even if the timing is not:

- Observation first, with sensors and logging only.
- Alerts second, once the readings look trustworthy.
- Simple control third, starting with ventilation.
- Humidity and heat handling after that, following the plans written for them.
- A summary view last, if there is still time and money.

Each stage should be run for long enough to see how the loft behaves in real weather before the next one is added. Rushing from one stage to the next is the quickest way to hide a fault under a new feature.

The spring timing helps and hurts. It helps because conditions change enough to test the system properly. It hurts because the fermentation season pushes me to finish early, and I would rather skip a feature than ship a faulty one. If a stage is not ready when the cider needs the loft, the manual routine takes over, and the build waits.

## Risks

The main risks are listed here with what I plan to do about each.

- **Silent sensor failure.** A sensor that reads a stuck value looks fine. Mitigation: alerts for readings that do not change, and a regular comparison against a reference.
- **Controller failure during fermentation.** Mitigation: every automated action can be done by hand, and the safe default is to do nothing drastic.
- **Overloading the circuit.** The loft has a single circuit, and the humidity and heat plans both draw from it. Mitigation: check the combined load before adding anything, and keep the plans from running at full power together.
- **Moisture in the electronics.** Mitigation: enclosures, good placement, and a look at the contacts each season.
- **Alert fatigue.** Mitigation: few alerts, each of which means something.
- **Dependence on one person.** The neighbor leads, so if the neighbor is unavailable the project stalls. Mitigation: write everything down and make sure I can run the system alone.
- **Scope growth.** Mitigation: the priorities in the Costs section, and the rule that extras come last.
- **Conflict with other plans.** [[Riothdrer dehumidifier plan]] and [[Drurtos kiln controller plan]] both touch the same loft. Mitigation: agree on which controller owns which job before wiring anything.

## Safety

Safety comes before automation. A convenient system that creates a hazard has failed, however well it controls the cider.

Fermentation releases gas, and a closed loft can hold more of it than is comfortable. Automatic ventilation must therefore never be the only protection. Anyone entering the loft should still be able to open it up and leave it open, and no control should fight a person who has done that.

Electrical work is done by the neighbor, with the power off, and anything permanent is checked before it is used. Cables stay away from water, cider spills and walkways. Enclosures keep moisture off live parts. Heat sources are kept clear of anything that burns, and the heated side follows [[Drurtos kiln controller plan]] and its own precautions.

Failure behavior is a safety question too. If the controller loses power or crashes, it must leave things in a state that is safe for the room and for the cider, not in the middle of an action. I want to test this on purpose, before relying on it.

Finally, no automated system replaces looking and smelling. The routine visit stays, even when it is less frequent. Part of the point is to make those visits calmer, not to remove them.

## History

The idea comes from the loft records. Reading [[Narkmin loft log]] and [[Nastae loft log]] one after the other, I noticed the same pattern: problems that were found late, after they had already done harm, and observations that depended on who happened to be there that day.

The loft itself is described in [[Dalsti loft]], and its limits shaped the plan from the start. The broader thinking about how the space might be laid out is in [[Konkrur Faesnus plan]]. The humidity and heat ideas came as separate plans, [[Riothdrer dehumidifier plan]] and [[Drurtos kiln controller plan]], and this project is the one that is meant to tie the routine monitoring together without replacing them.

The project was started in 2026, in the spring season. My neighbor agreed to lead it, since the practical work was beyond what I wanted to do on my own. The goal was written down as automation, with the cider area as the place it applies.

Nothing about the build itself has a long history yet. As each stage is done, I will add a short entry here with what was done and what was learned, so that this section becomes the real record and not just the background.

## Budget

The budget of Glaennin automation is 14903.14 EUR.

This is the ceiling for the whole project, not a target to reach. If the plain version works for less, I am happy to leave the rest unspent. The money is meant to cover sensors, wiring, enclosures, controllers, spare parts, and a reserve for what turns out to be wrong.

The rules I follow with it:

- Spend on measuring and recording before anything else.
- Keep a reserve, and do not touch it for convenience features.
- Buy the spare parts for the cheapest and most likely to fail items early.
- Write down every significant purchase with a short reason.
- If a stage needs more than I expected, I stop and decide, rather than quietly taking the money from the next stage.

Success is measured in the same plain terms as everything else here. I will compare the number of missed problems and unplanned visits against what [[Narkmin loft log]] and [[Nastae loft log]] show. If the loft is steadier, I am visiting it less in a panic, and the manual fallback still works, then the money was well spent.
