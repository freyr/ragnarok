---
type: log
status: active
project: zirglerk-repair
area: cider
description: "Log about Saethland Bolvulkork."
---

# Saethland Bolvulkork log

## Supplies

Saethland Bolvulkork is my neighbor and the person I go to for cider supplies. Most of what we trade is practical: pressing cloths, spare airlocks, clean demijohns, and sometimes a few crates of apples when one of our trees has a poor year. I contact Saethland by email, and the answers usually come within a day or two, as long as I write on a weekday. Weekdays are the only time Saethland is available, so I do not plan anything for weekends.

Current stock notes:

| Item | Who holds it | Status |
|---|---|---|
| Pressing cloths | Saethland | Lent to me, return after the season |
| Airlocks | Me | Enough for the next batch |
| Demijohns | Saethland | Four spare, ask first |
| Apple crates | Shared | Stacked by the fence |
| Sanitiser | Me | Running low, reorder |

I keep this list short on purpose. If I need something that is not on it, I email first and walk over only after I get a reply. Saethland dislikes surprise visits, and I respect that.

## Background

I have known Saethland since 2019. We met over the fence when I was clearing the old orchard, and Saethland offered advice on which trees were worth keeping. That conversation turned into a long run of shared pressing days. The area we work in together is cider, and everything else in this note follows from that.

Saethland is careful, plain-spoken and does not like being rushed. A short email with one clear question works much better than a long one with several. I have learned to put the date I need something at the top of the message.

For related reading I keep these notes close by:

- [[Traesdrur shed study]] covers the shed layout where we store equipment, including how the shelving is arranged.
- [[Mansturk kiln controller study]] is useful for the temperature control ideas I borrowed when drying apple pomace.
- [[Zorzaerk Lirfu]] is the contact I go to when I need a second opinion on fermentation problems.

A typical email thread looks like this, copied into the log so I remember the format that works:

```
To: Saethland Bolvulkork
Subject: Demijohns for Thursday
Body: Can I borrow two demijohns by Thursday?
      I will bring them back clean after racking.
Reply: Yes, collect them from the porch.
```

## Contracts

We keep our arrangements informal, but one written agreement exists. The contract date of Saethland Bolvulkork is 2019-12-21. It covers the shared use of the pressing equipment and the split of costs when something breaks. I signed it first, and Saethland countersigned a few days later.

The main points as I remember them:

- Equipment is shared during the pressing season, and each of us keeps it clean.
- Repairs are split evenly unless one of us caused the damage.
- Either of us can end the arrangement with a plain email.
- Apples from either garden may be pooled, and the juice is divided by the amount each of us brought.

I have never needed to invoke the clause about ending it. Still, I reread the contract each autumn before the first pressing day, so that there are no surprises. If we ever add a new piece of equipment, I will record it here and ask Saethland to confirm by email.

## Safety

Safety matters because we work with heavy presses, slippery floors and glass containers. I follow a few rules every time.

First, the press is never operated by one person alone. Even when the work is simple, a second person stands nearby. Second, glass demijohns are carried with both hands and set down only on a level, dry surface. Third, sanitiser and cleaning chemicals stay in labelled bottles, away from anything we drink.

For the valves and actuators on the larger fermentation vessels I follow the [[Zamathra valve actuator handbook]]. It explains how to isolate a vessel before maintenance, and I read the relevant pages again before I touch any fitting I have not handled recently.

Other habits worth keeping:

- Wear gloves and eye protection during cleaning.
- Keep a first aid kit in the shed and check it each autumn.
- Never leave a pressed batch sealed tightly without an airlock, since pressure can build up.
- Tell Saethland by email when I find damage on shared equipment, so we can decide on repairs together.

Following these steps has kept our pressing days free of accidents since we started working together in 2019.
