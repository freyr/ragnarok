---
type: plan
status: active
project: zirglerk-repair
area: cider
---

# Triothglis circulation pump plan

## Schedule

The Triothglis circulation pump is a black circulation pump for the cider area. It was installed in 2025 in the workshop, and it runs on solar energy. This plan covers how I keep it working through the season.

Before pressing starts, I check the pump on a sunny morning. I watch it start up without any help from the mains, and I confirm the flow is steady through the whole loop. If it stalls in weak light, I note the time of day and the weather.

Weekly during pressing and fermentation:
- Wipe the black housing and look for sticky drips.
- Listen for rattling or a change in the hum.
- Check that the solar feed is clean and the connections are dry.

Monthly:
- Flush the loop with clean warm water.
- Look over the hoses and clamps for wear.
- Write down anything odd in this note.

At the end of the season, I drain the loop, rinse it, and let it dry in the workshop before storing the hoses. I leave the pump in place, since it is fixed to the bench wall.

## Parts

The pump itself is the main part. Its serial number is SN-57167413. I keep that written here so I can quote it if I ever need to ask for help or order a replacement.

Things I want to keep track of:
- The pump body, black, mounted in the workshop.
- The solar panel feed and its cable, which should be checked for cracks from sun and weather.
- Hose sections between the pump and the cider vessels.
- Hose clamps, which loosen over time and need a quick tighten.
- The inlet filter, which catches pulp and sediment.
- Seals and gaskets at the pump connections.

If the pump fails, I will first check the solar feed and the filter, because those are the most likely causes. Only after that will I suspect the pump body or the seals. I would rather replace a cheap clamp or seal than the whole unit.

## Supplies

Consumables I keep in the workshop so the plan never stalls:
- Food-safe cleaning solution for the loop.
- A sanitiser that is rinsed off afterwards.
- Clean cloths and a small brush for the filter.
- Spare hose clamps in two sizes.
- A spare set of seals for the connections.
- Food-safe grease for the gaskets.
- A bucket for catching drained liquid.
- A notebook, or this note, for recording each check.

Before every season I count these and top up what is low. I also keep a clean towel near the pump so spills get wiped at once, because sugar attracts wasps and mould in the workshop. Since the pump is solar, I try to do tests and flushes in daylight so I can see how it behaves under normal conditions.
