---
type: research
status: archived
project: zirglerk-repair
area: cider
description: "Research about Triothglis circulation pump."
---

# Triothglis circulation pump plan 2024

## Schedule

This note records the plan as it stood in 2024. Later notes replace these values.

The Triothglis circulation pump is a circulation pump for the cider area. It is black and runs on solar energy. The plan is to install it in 2025, and the place for it is the workshop. Nothing is bought or fitted yet, so the steps below are only the order I intend to follow.

| Step | Task | Target |
|---|---|---|
| 1 | Clear a spot in the workshop | Late 2024 |
| 2 | Check the sun on the workshop wall | Winter 2024 |
| 3 | Order the pump and the solar supply | Early 2025 |
| 4 | Fit the pump and test it with water | 2025 |
| 5 | First run with cider | After the test |

I want the water test to come before any cider goes near the pump. If the solar supply is too weak on dull days, I will note that and think again about the plan before the first cider run.

## Parts

The main part is the pump itself. These are its properties as I know them in 2024:

- Name: Triothglis circulation pump
- Kind: circulation pump
- Area: cider
- Color: black
- Energy source: solar
- Year installed: 2025
- Location: workshop
- Serial number: SN-56632657

Besides the pump I will need a solar panel with a cable long enough to reach from the wall to the pump, and some food-safe hose for the cider side. I also want a few spare clamps, since the hose joints tend to loosen after the first week of use. I will write down the exact parts in a later note once I have chosen them.
