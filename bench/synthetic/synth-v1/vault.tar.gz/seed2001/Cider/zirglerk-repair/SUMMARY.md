---
type: summary
status: active
project: zirglerk-repair
area: cider
description: "Summary about Zirglerk repair."
---

# Summary of Zirglerk repair

## Problems

Zirglerk repair is a repair project in the cider area. It started in autumn 2019, and the accountant leads it. I keep this summary so I can see where the project stands without reading every log.

The main problem is still the same one that started the project. The Zirglerk setup stopped behaving evenly, and the cause was not clear at first. Over the years it has turned out to be several smaller faults that overlap. That is why the repair has taken so long. Each time I fixed one thing, another one that had been hidden behind it showed up.

The faults I have confirmed so far:

- The level readings drift. The sensor on the main vessel gives different values depending on foam and on how recently the vessel was topped up. I compared my readings against [[Sethzand level sensor notes]] and [[Trendstil level sensor notes]], and both describe the same drift on similar sensors.
- The air supply is uneven. The compressor works, but the pressure sags when two jobs run at once. The results are in [[Pindbu air compressor tests]].
- Circulation is weaker than it should be. The pump moves liquid, but not as steadily as the original design needed. See [[Rundtru circulation pump tests]].
- The weighing step cannot be trusted by eye. I use [[Lanfoth scale]] as the reference, and a few earlier batches were recorded without checking against it.

Not every fault is understood. The level drift is the one I understand least, and it is the main open point. I do not want to call the project finished until that one is explained, even if the other three are fixed.

## Risks

The biggest risk is that I fix symptoms and not causes. The level drift could be a sensor fault, or it could come from how the vessel is filled. If it is the second, replacing the sensor would waste effort and money. I should check the filling habit before I replace anything.

Other risks I keep in mind:

- **Scope creep.** The project began as a simple repair. Every new finding tempts me to improve the setup, and that is how a repair becomes a rebuild. The goal is repair, so I keep to it.
- **Lost context.** Several of the logs were written years apart. The notes in [[Narkmin loft log]] and [[Nastae loft log]] cover the storage loft, and they use different wording for the same conditions. If I misread one, I could draw the wrong conclusion about temperature or timing.
- **Seasonal timing.** The project began in autumn, and the work still fits best in autumn, when the cider work is busiest and I notice faults quickest. If I postpone the next step past the busy period, I will lose the chance to watch the setup under real load.
- **Single point of knowledge.** The accountant leads the project and holds most of the records. If that person is unavailable, the cost history is hard to rebuild. I have started copying key figures into the notes so the picture does not depend on one person.
- **Compounding wear.** The compressor and the pump both run longer than designed while the problems stay open. Leaving them in this state increases the chance of a second failure.

None of these risks is severe by itself. Together they argue for steady progress and against a long pause.

## Maintenance

Maintenance on Zirglerk was irregular before the project, and that probably contributed to the problems. One result of the repair work is a simple routine I can actually keep.

The routine is short:

- Wipe and inspect the level sensor before each fill, and note whether foam is present.
- Listen to the compressor at the start of a run. A change in sound has been the earliest warning so far.
- Check the pump inlet for debris once the circulation stops.
- Weigh a known reference item on [[Lanfoth scale]] at the start of each session, so I know the scale has not wandered.
- Write a line in the right log after each session, even if nothing happened. Quiet entries are useful later, because they show when a fault began.

For the sensors, I keep the history in [[Traenzirk level sensor log]]. It is a running record of readings and cleaning, and it is the best evidence I have for the drift. When I compare it to [[Sethzand level sensor notes]], the drift appears stronger after a long idle spell. That points toward a cleaning or settling issue, not a dead sensor, though I have not proven it.

I do not do heavy maintenance in the middle of a batch. Anything that needs the vessel emptied waits until the batch is finished. This costs some time, but it keeps the results comparable from one session to the next.

## Supplies

The supply list is short, and I keep it that way so I do not buy things I only half need.

Consumables:

- Cleaning cloths and a mild cleaner for the sensor surfaces
- Spare tubing for the circulation line
- Small seals and clips for the air line
- Labels and a marker, used for dating the logs and jars
- A notebook page set aside for the day's readings, which I copy into the digital notes afterwards

Things I have decided not to buy yet:

- A replacement level sensor, until the drift cause is clear
- A larger compressor, since the sag looks like a distribution problem and not a capacity problem
- A new pump, until the tests in [[Rundtru circulation pump tests]] are repeated under the same conditions

One lesson from earlier work is to buy spare tubing and seals in pairs. Twice I had to stop a session because a single small part had split, and the supplier was slow. A spare on the shelf costs very little compared with a lost day.

The accountant tracks purchases, so any supply I add should be reported to that person at once. That keeps the cost picture honest and avoids surprises later.

## Setup

The Zirglerk setup has four working parts: the main vessel with its level sensor, the air supply, the circulation line, and the weighing station. They sit close together, and I treat them as one system because a change in one affects the others.

The vessel is the center. Its level sensor feeds the readings I log. The compressor sits beside it and drives the air line. The circulation pump moves liquid through the line, and the scale is on a separate bench for weighing inputs.

Storage is in the loft. [[Narkmin loft log]] and [[Nastae loft log]] describe the conditions up there across seasons. Both are useful for judging whether the stored material behaved differently in warm and cool spells. I read them together because each covers gaps in the other.

Changes I made during the project:

- I moved the air line so it does not share a run with the pump cable.
- I shortened the circulation tubing, which removed a sag where liquid used to pool.
- I fixed the sensor mounting so it no longer shifts when the vessel is bumped.
- I put the reference weight beside the scale where I cannot forget it.

I have not rebuilt anything. All of these changes are small and reversible, and that fits the repair goal. If a later test shows a change made things worse, I can undo it without losing other progress.

## Safety

Safety is mostly common sense, but the setup has a few hazards that deserve a written note.

Air pressure is the first. The compressor stores energy, and a split fitting can whip or release suddenly. I check fittings before each run and never work on the air line while the system is live. I release the pressure fully before touching any joint.

Liquid on the floor is the second. A leak near the pump turns the bench area slippery, and the pump has an electrical supply close by. I keep the cable raised and keep a cloth within reach. If liquid reaches the electrical side, I switch off at the wall before anything else.

The loft is the third. Carrying material up and down narrow stairs is a real risk, especially when the steps are damp. I carry smaller loads and use both hands. The loft logs mention the cold and damp, and these affect the stairs as much as the stored material.

Other habits:

- Keep a clear path between the vessel, the bench and the door.
- Do not work alone with the pump running if I feel tired.
- Wear gloves when cleaning, and keep cleaner away from anything that touches the product.
- Keep the area tidy at the end of each session so the next start is safe.

No incident has happened during the project. I want that to stay true, so I do not rush the checks when I am short of time.

## Costs

I am not recording prices in this note. The accountant keeps the detailed figures, and I only use this section to describe the pattern.

The costs so far fall into three groups. The first is small parts: tubing, seals, clips and cleaning items. These are cheap but frequent. The second is time, which is the largest cost by far. The project began in 2019 and the work has been spread across many sessions, so total effort is bigger than any single purchase. The third is avoided cost, which is harder to measure but real: I did not replace the compressor, the pump or the sensor, because testing showed they were not the real cause.

The tests in [[Pindbu air compressor tests]] and [[Rundtru circulation pump tests]] saved the most money. Both showed that the equipment itself works, and that the faults are in the layout and handling. Without these tests I might have bought replacements that would not have helped.

Points the accountant and I agreed on:

- Any single purchase beyond small parts is discussed first.
- Receipts go into the project record the same day.
- A replacement sensor is the only large item still possible, and it stays on hold until the drift cause is clear.

I think the project has stayed reasonable on cost. The main thing to avoid now is letting the time cost grow because the level drift is never pinned down.

## Observations

These are the things I have noticed that are not yet conclusions.

The level drift is worse after idle periods. Reading [[Traenzirk level sensor log]] side by side with [[Sethzand level sensor notes]] and [[Trendstil level sensor notes]], the pattern repeats: the first reading after a rest is off, and later readings settle. This suggests residue or settling on the sensor, not a failing part. A short cleaning before the first reading may be enough.

The compressor sag appears when the pump starts at the same time as an air job. That looks like a timing issue. Staggering the two jobs seems to remove most of the sag, though I need more sessions to be sure.

The pump performs better with the shorter tubing. The results in [[Rundtru circulation pump tests]] improved after that change, and the flow sounded steadier too.

The loft conditions differ between the two logs. [[Narkmin loft log]] describes a drier, steadier spell, while [[Nastae loft log]] describes more swings. Material stored in the second period behaved less consistently, which may connect to the weighing errors I found when I checked against [[Lanfoth scale]].

Things I still do not know:

- Whether the filling habit contributes to the drift
- Whether the scale error was always present or only appeared late
- Whether the loft swings affect the readings or only the stored material

I will keep logging quiet sessions as well, because absence of change is also data.

## Next action

The stage of the project is late repair: the main faults are identified, most of the small fixes are done, and the level drift remains open. The next action is NX-7426.

Once that action is done, I will record the result in [[Traenzirk level sensor log]] and compare it with the earlier readings. If the drift disappears with the cleaning and filling routine, I will close that point and move toward finishing the project. If it remains, I will go back to the sensor question and discuss a replacement with the accountant.

## Decisions

The go decision date for Zirglerk repair is 2026-08-21. That was when I agreed with the accountant to continue the repair and not stop or rebuild.

The reasoning was simple. The equipment tests showed that the compressor and the pump work, so replacement was not justified. The remaining faults were small enough to fix one at a time. The project stays a repair in the cider area, led by the accountant, and it keeps its original autumn rhythm.

Other decisions that follow from it:

- Do not replace the compressor or the pump.
- Hold the sensor replacement until the drift cause is known.
- Keep the maintenance routine and the logs going.
- Report every purchase to the accountant on the same day.
- Do not widen the scope into a rebuild.

I will revisit these decisions after the next action is done and the level drift is either explained or accepted.
