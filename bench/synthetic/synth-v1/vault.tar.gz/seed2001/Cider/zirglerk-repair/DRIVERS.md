---
type: drivers
status: active
project: zirglerk-repair
area: cider
description: "Drivers about Zirglerk repair."
---

# Drivers of Zirglerk repair

## Setup

Zirglerk repair is a project with the goal "repair". It sits in the cider area and started in 2019, in the autumn season. The lead is the accountant. This note holds the drivers of the project: what it is for, what limits it, what it may cost and how I will know it worked.

The goal is simple to state. Something in the cider work broke down, and Zirglerk repair exists to put it back in working order. It is not an upgrade and it is not a redesign. If a choice comes up between fixing the thing as it was and making it better, I fix it as it was, unless the better version costs no more and adds no risk.

Because the accountant leads, the project is run with money and records in mind. Every purchase gets written down when it happens. Every change of plan gets a short reason next to it. The lead does not need to know the technical detail of the press or the vats, but does need to know what was spent and why.

Constraints I am working under:

- The work belongs to the autumn season, so it has to be finished before the main pressing starts. A repair that is half done when the apples arrive is worse than no repair.
- The total spending stays inside the budget given in the last section.
- Nothing may touch the food-contact surfaces unless the material is suitable for them and can be cleaned properly afterwards.
- Cider that is already in storage must not be put at risk by the work.
- Any outside help has to be booked early, since autumn is busy for everyone in the area.

How success is measured:

- The repaired part works through a full pressing day without a stop.
- No new leak, noise or loss of pressure shows up in the first weeks of use.
- Total cost ends at or under the budget.
- The records are complete enough that the lead can close the books on the project without asking me questions.

## Checklist

Use this list in order. Tick nothing until it is really done.

- Write down what failed, when it was noticed and what was seen at the time.
- Take photos of the damaged part before anyone touches it.
- Decide whether to repair or replace the part, and write the reason.
- Ask for at least two quotes if any work goes to an outside person.
- Get the lead to approve the spending before ordering anything.
- Order the materials and note the delivery time.
- Clear and clean the work space.
- Carry out the repair, noting each step briefly.
- Clean everything that touches the cider and rinse well.
- Run a dry test, then a test with water, then a small test batch.
- Keep every receipt and hand them to the lead.
- Compare the final cost with the budget and write the difference.
- Record what was learned for next time.

Before the first test, check three things again: all fittings are tight, nothing is left inside the equipment, and the floor is dry. These are easy to forget when the repair feels finished.

## Open questions

- Is the original part still made, or does a substitute have to be found? If a substitute, will it fit without changes?
- How long can the cider already in storage wait if the repair runs late?
- Does the repair need a skilled person, or can I do it myself with care?
- Should a spare be bought at the same time to avoid a second breakdown, and would that fit in the budget?
- What is the last safe day to start so that the repair is finished before the main pressing?
- Who keeps the records if the lead is away during the busiest weeks?
- Was the failure caused by wear, by misuse or by a poor earlier fix? The answer changes how long the repair should be expected to last.

## Ideas

- Keep a single page near the equipment with the repair steps and the date of the last check, so the next person does not have to guess.
- Ask the lead to set a small reserve inside the budget for surprises, and agree beforehand when it may be used.
- Do a short inspection of the other equipment while it is open, since the access is already there.
- Plan a yearly check in late summer, well before the apples come, so that problems show up early.
- Photograph the finished repair from the same angles as the damaged state, for a clean before and after record.
- Label the new part with the year of the repair so that its age is obvious later.
- Write a short note on suppliers that were reliable and those that were slow, for future projects in the cider area.

## Budget

The budget of Zirglerk repair is 10383.23 EUR.

This is the ceiling for the whole project: parts, materials, outside work, cleaning supplies, test batch losses and any delivery costs. It is not a target to be reached. If the repair can be done for less, the rest stays unspent.

Rules for using it:

- The lead approves each larger purchase before it is made.
- Every payment is written down with the date, the supplier and the reason.
- If the running total approaches the limit before the work is done, I stop and talk to the lead before going further.
- Any overrun needs a written reason and a decision from the lead, not a quiet adjustment later.

At the end I compare actual spending with the budget, note where the plan was wrong and keep that for the next project.
