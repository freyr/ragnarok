---
type: reference
status: active
project: reference
area: cider
---

# Girdael radio receiver

## History

The Girdael radio receiver is a red radio receiver that I installed in the shed in 2019. It belongs to the cider area of my notes, because I bought it to keep the pressing and fermenting work company and to hear the weather forecast while the apples are being sorted. The energy source is solar, and that has not changed since the day it went in.

When I first mounted it, the plan was simple: a small panel on the south side of the shed roof, a short cable through the wall, and the receiver on a shelf above the workbench. The first season it worked well enough, though reception drifted in the evenings. In the second year I moved the aerial wire to the rafter, and that helped more than anything else I tried. Since then I have only made small changes, mostly to the panel angle and to the cable clips.

The receiver is red, and I like that, because it is easy to spot among the grey buckets and crates. It has survived three autumn pressing seasons with sticky hands and a few splashes of juice, so the casing is tougher than it looks.

## Problems

The problems I have had are few, but they repeat, so I keep them here as a checklist.

- **Evening drift.** The tuning slides slowly off the station once the light fades. This is a solar issue: when the panel output drops, the supply to the tuner gets weak and the dial wanders.
- **Damp.** The shed gets humid in late autumn, and the contacts on the back go dull. A dry cloth and a little contact cleaner fix it.
- **Crackle in cold weather.** On frosty mornings there is a crackle for the first few minutes. It goes away by itself once the shed warms a little.
- **Dust.** Pressing season fills the air with dust and pomace flies. The vents clog and the receiver runs warm.
- **Loose aerial clip.** The clip on the rafter works loose after strong wind. If the sound turns thin, I check this first.

When something goes wrong, I go in this order: panel and cable, aerial clip, contacts, then the adjustment described below. Nine times out of ten the cause is in the first two.

## Setup

The setup is plain. The receiver stands on the shelf above the workbench in the shed, about at eye level, away from the juice and the press. The panel is on the shed roof and the cable runs along the inside of the wall to the back of the receiver. The aerial wire runs from the back of the set up to the rafter and is held by two clips.

I wrote down the layout of the yard when I planned the cable run, and the position of the shed relative to the other buildings is on [[Gondmis yard plan]]. It is worth looking at if I ever move the panel, because the walnut tree to the east throws shade in the morning.

Basic checks when I start the season:

1. Wipe the panel with a damp cloth and check for leaves.
2. Look at the cable along the wall for chafing.
3. Tighten both aerial clips.
4. Clean the back contacts and let them dry.
5. Switch on and listen for crackle at a quiet moment.

A short log of my usual start-of-season check looks like this:

```
# girdael start-of-season check
location:      shed
energy:        solar
panel:         wiped, no leaves
cable:         no chafing
aerial clips:  2 of 2 tight
contacts:      cleaned, dry
tuning:        holds for 30 min at midday
offset:        unchanged from last season
```

I keep a copy of this on paper next to the shelf, so I can tick things off without opening the notes on my phone with dirty hands.

## Adjustment

The only adjustment I ever make is the calibration offset. The calibration offset of the Girdael radio receiver is 1.403 mm. This is a physical setting on the tuning mechanism, measured as the gap at the small screw behind the dial, and that is why it is given in millimetres rather than in any electronic unit.

How I check it:

1. Switch the receiver off and let it sit for a few minutes.
2. Look at the gap behind the dial with a small ruler or a set of feeler strips.
3. If the gap is not 1.403 mm, loosen the lock nut slightly and turn the screw until it is.
4. Tighten the lock nut again without moving the screw.
5. Switch on at midday, when the panel gives its best output, and check that the station stays put.

I do not touch this setting in the evening, because the weak supply makes the dial look worse than it is. If the drift only appears at dusk, the offset is fine and the cause is the panel. I learned that the hard way after chasing the screw for a whole week one October.

After any change I write the date and the result in my paper log and leave the offset as it is for at least a month before judging it.

## Background

The Girdael is a small solar radio receiver and, in my notes, it counts as part of the cider equipment even though it does not touch any apples. I treat it that way because the work it supports, pressing and fermenting, is the reason it lives in the shed at all. If the cider work moved elsewhere, the receiver would probably move with it.

A few facts in one place:

- Kind: radio receiver
- Area: cider
- Color: red
- Energy source: solar
- Year installed: 2019
- Location: shed

Solar power suits the shed because there is no mains socket near the workbench, and I did not want a long extension cable across a floor that is often wet. The downside is the dependence on daylight, which explains most of the problems listed above. A small battery buffer would likely cure the evening drift, but so far I have preferred to keep the system simple and live with it.

If I ever replace the receiver, I would keep the same position on the shelf, the same panel and the same aerial route, since all of that has proved itself. The notes on the yard layout and the panel position would stay valid, and only the adjustment section would need rewriting for the new device.
