---
type: reference
status: active
project: reference
area: cider
---

# Rindtrith air compressor

## Checklist

This is the quick pass I do on the Rindtrith air compressor before a pressing session. It is a blue air compressor that runs on mains power. I installed it in 2015 and it lives in the workshop. Its job is cider work: it supplies air for the transfer lines and the bottling station.

Before switching on:

- Look at the power cable and plug for nicks or heat marks. Mains power only, so no extension reels left coiled up.
- Check the oil sight glass if the unit has one fitted, and make sure the level sits in the middle of the window.
- Open the drain valve at the bottom of the tank and let any water out until only air comes through. Cider work is damp, and the workshop gets humid in autumn.
- Check that the hose couplings are seated and that the hose has not been rubbed through where it crosses the floor.
- Make sure nothing is stacked against the blue casing. The air intake needs space around it.
- Confirm the pressure gauge rests at zero when the tank is empty.

After switching on:

- Listen for the first minute. A steady rhythm is normal. Knocking or a rattle means stop and look.
- Watch the gauge climb. If it takes much longer than usual to fill, suspect a leak or a worn intake filter.
- Once at pressure, switch off at the wall and listen. A hiss means a leak. Spray soapy water on the fittings to find it.
- Check the safety valve is not weeping.

At the end of the day:

- Release the pressure and drain the tank again.
- Wipe down the casing and coil the hose loosely.
- Note anything odd in the log so I can compare it the next time.

## Adjustment

The pressure switch and the regulator are the two things I touch. Everything else I leave alone unless something is clearly broken.

The calibration offset of the Rindtrith air compressor is 0.944 mm. I use it when I set the gauge pointer and the regulator reference so the readout matches the real pressure at the line. If the offset seems wrong after I move the unit, I redo the setting rather than trust the old one.

Steps for adjusting:

1. Empty the tank fully and confirm the gauge sits at its rest position.
2. Apply the calibration offset of 0.944 mm when I set the pointer against the scale.
3. Fill the tank slowly and check the cut-out point against a second gauge that I trust.
4. Adjust the regulator in small turns, never more than a quarter turn at a time, and wait a few seconds after each one.
5. Run a short transfer test with the lines I use for cider and watch whether the pressure holds steady.
6. Write down the final settings in the log.

Things I have learned:

- Vibration slowly shifts the pointer, so recheck after a long session.
- Cold mornings in the workshop make the first fill read slightly differently. I wait until the unit has warmed up before judging.
- If the compressor cycles on and off too often, check for leaks before touching the switch.

For related level work on the tanks, see [[Nermior level sensor tests]]. The valve side of the bottling line is covered in [[Fakiosto valve actuator]], and any change to the pressure setting should be checked against how those valves behave.

## Ideas

Some things I might do with the Rindtrith air compressor over the next seasons:

- Fit a small moisture trap at the outlet. The blue unit has served since 2015 and the water in the tank is the main thing that ages it.
- Add a simple hour meter so servicing is based on running time instead of guesswork.
- Make a laminated copy of the checklist and hang it on the wall of the workshop next to the unit.
- Build a quieter enclosure with ventilation, as long as the intake still gets plenty of air.
- Link the compressor to automation. The plan in [[Gistaenfe kiln controller plan]] might share a controller design that could switch the compressor on a timer or protect it from short cycling.
- Consider a remote pressure alert. The idea in [[Triorkgend radio receiver plan]] could carry a signal to the house if the pressure drops during a long transfer.
- Keep a spare intake filter and a spare set of hose couplings on the shelf above it.
- Move the drain point to a spot where I can reach it without kneeling.

Questions to settle:

- Is the current tank still big enough if I expand the cider output?
- Would a second, smaller compressor be more practical for the bottling station alone?
- Should I schedule a yearly full service in the quiet months after pressing ends?
