---
type: reference
status: active
project: reference
area: cider
description: "Reference about Dalsti loft."
---

# Dalsti loft

## Costs

Dalsti loft is a large loft on the ground level, built in 2003, in the cider area, facing east. Because it is large, most of the running costs scale with the floor area, and I keep that in mind whenever I plan spending here.

The main cost groups, in rough order of how much they hurt:

- Heating in the cold months. The east orientation means the morning sun helps, but the afternoons and evenings get cool, so the heating runs later in the day than I would like.
- Lighting. The space is wide, so one lamp never does the job. I need several light sources spread around.
- Rent and lease fees, which are the fixed part of the budget.
- Repairs to the floor and the large windows, which come up every couple of years.
- Cleaning supplies and small consumables. They are cheap one at a time but add up over a year.

I do not write exact prices in this note. The actual figures live in my budget sheet. Here I only record the shape of the costs, so I can see which ones are fixed and which ones I can reduce.

A few habits keep costs down. I close off parts of the loft in winter when I am not using them. I use thick curtains on the east windows in the evening. I buy consumables in bulk when there is a sale. I check the heating schedule at the start of each cold season instead of leaving it as it was last year.

The biggest lever is heat. A ground level loft loses warmth through the floor, so rugs and a proper underlay have paid for themselves. Draught strips on the doors were the cheapest improvement I made.

The second lever is the lease. When renewal comes up I compare the terms against what I actually use. A large space is only worth it if I fill it, and I should be honest about that each time.

## Safety

The loft is on the ground level, which makes escape easy, but the size means some spots are far from the exits. I keep the paths to the doors clear at all times.

Safety points I keep in mind:

- Smoke alarms should be tested on a regular schedule. I test them at the start of each season.
- A fire blanket hangs near the kitchen corner, and an extinguisher sits close to the main door.
- Extension cables are not run under rugs. In a large room it is tempting, but it is a fire risk.
- Heaters stay away from curtains, especially on the east windows where the curtains are long.
- The floor can be slippery after cleaning, so I let it dry before walking across.
- Large windows can be a hazard if they are left open in strong wind. I latch them when I leave.

Because the loft was built in 2003, the wiring is not brand new. I do not do electrical work myself. If something smells hot, buzzes, or trips the breaker more than once, I stop using that circuit and call a qualified electrician.

Guests should be told where the exits are the first time they visit. It sounds formal for a personal space, but the loft is big enough that people can lose their bearings.

I also keep a small first aid kit in a labelled box, and I check its contents twice a year. Anything that has expired gets replaced.

At night I leave a low light on in the walkway between the sleeping area and the bathroom. It prevents stumbles and costs very little.

## History

Dalsti loft was built in 2003 in the cider area. It was designed as a large, open ground level space, and it has kept that character. The east orientation was a deliberate choice by the original builders, to catch the morning light.

What I know of its past is limited and partly second hand. The cider area was mostly working premises at the time, and the loft was one of the first conversions toward living and studio use. Over the years the space has been used in different ways, and I can see the marks of that in the floor and walls.

Notes on how I came to the place:

- I first saw it as a visitor and noticed how bright the mornings were.
- The lease was arranged afterwards, and the reference is recorded in the Admin section.
- Early on I spent time learning how the light moves across the room through the day.
- I made small changes, such as new shelving and a better lamp layout, rather than anything structural.

Since 2003 there have been a few rounds of repair. The windows have been resealed at least once, and the floor has been patched in places. I do not have full records of earlier work, so when I find something odd I treat it as unknown rather than guessing.

The age of the building matters mostly for maintenance. Twenty-odd years is not old for a structure, but fittings wear out on their own schedule. Taps, hinges, door seals, and electrical sockets all show their age more than the walls do.

I would like to learn more about the earlier tenants. A neighbour may remember, and I plan to ask when I see them.

## Ideas

Some things I would like to try in Dalsti loft, none of them urgent.

- Divide the large space into zones using open shelving rather than walls. This keeps the light moving through and still gives a sense of rooms.
- Add a reading corner near the east windows to make use of the morning sun.
- Build a long workbench along one wall for projects.
- Put in better insulation under the floor, since it is a ground level space and cold rises from below.
- Install light dimmers so the evening mood can be adjusted without changing bulbs.
- Grow a few plants that tolerate morning sun and cooler afternoons.
- Make a storage wall with labelled boxes so that the open floor stays clear.

Some of these overlap. The zones idea and the storage wall could be done together, using the same shelving. The reading corner and the plants would also work well side by side.

I rank ideas by effort and benefit. Low effort and high benefit ones, like the dimmers and the reading corner, go first. High effort ideas, like the floor insulation, wait until I know whether I am staying long term.

One idea I rejected: a mezzanine. The ceiling is not high enough to make it comfortable, and it would block the light from the east windows, which is the best feature of the place.

Another maybe: a small rug system with a different texture for each zone, so the zones feel distinct even without walls. It would also help with the cold floor.

## Observations

Things I have noticed while living with the loft.

The morning light is the best part. Because the loft faces east, the sun comes in early and fills the space. By midday the direct light has moved away, and the room is calmer. In the afternoon it can feel a little dim compared to the morning.

The size changes how everything feels. Sounds carry. A conversation at one end can be heard at the other. Music needs less volume than I expect. Footsteps on the floor echo unless there are rugs.

Temperature is uneven. The area near the east windows warms first in the morning, while the far side stays cool for longer. The floor is always the coldest surface, which fits with being on the ground level.

Other small patterns:

- Dust collects along the walls and under shelves faster than in a smaller flat.
- Condensation shows on the windows on cold mornings.
- The door area gets drafty when the wind comes from the east.
- Smells from cooking spread widely, so I open a window when frying.
- The cider area outside is quiet at night and busier during the day.

I also notice that I fill space to match its size. When I leave a corner empty for a few weeks, it starts collecting boxes. A regular tidy keeps it from becoming a dumping ground.

Over time I have come to prefer fewer, larger pieces of furniture here. Many small items look scattered in such a big room. A few solid pieces anchor it better.

## Maintenance

Regular upkeep keeps the loft in good condition. I work through it by season.

Routine tasks:

- Sweep and mop the floor weekly, and vacuum rugs.
- Wipe the windows and frames monthly, paying attention to the east side where condensation collects.
- Check door seals and draught strips at the start of the cold season.
- Test smoke alarms and replace batteries when needed.
- Clear dust from vents and behind shelving every few months.
- Inspect the ceiling and corners for damp or stains after heavy rain.

Seasonal tasks:

In autumn I prepare for the cold: bleed the radiators if there are any air pockets, check the curtains, and lay the winter rugs. In spring I air the space thoroughly, wash the curtains, and check the windows for any damage from winter. In summer I look at shading, since the east windows get strong early sun. In winter I watch for damp.

The floor needs special attention. On a ground level, moisture can come up from below. I look for lifting edges or dark patches, and I keep furniture slightly off the wall so air can move.

Because the loft dates from 2003, I keep an eye on fittings that wear: tap washers, hinges, lock mechanisms, and socket faceplates. I replace them as they fail rather than all at once.

I keep a simple log of repairs in my notes so I can see what has been done. When a problem repeats, the log helps me decide whether to repair it again or replace the part entirely.

For anything structural, such as cracks wider than a hairline, I contact the building owner instead of fixing it myself.

## Admin

Administrative details for the loft.

- Lease reference: LR-896968
- Property type: loft
- Area: cider
- Orientation: east
- Size: large
- Year built: 2003
- Floor: ground level

I quote the lease reference whenever I contact the owner or an agent about repairs, renewals, or payments. Keeping it in this note saves me from searching through old emails.

Other admin tasks I keep track of:

- Renewal of the lease, which I review well before the end of the term.
- Insurance for contents, which I check yearly to make sure the cover still matches what I own.
- Utility accounts, which are in my name and need their details updated if anything changes.
- Records of messages with the owner about repairs, which I save in a folder.
- Any permission I need for changes to the space, such as fixing shelves to walls.

Before I alter anything permanent, I ask the owner in writing and keep the reply. Verbal agreements are too easy to forget or dispute.

When I send a message about the loft, I include the lease reference, a short description of the issue, and a clear request. That usually gets a faster response than a long, vague message.

I keep paper copies of the most important documents in a folder near the door, and digital copies in my notes system. If I ever need to leave quickly, I can grab the folder.

## Setup

How the loft is currently arranged.

The space is large, so I divide it mentally into zones even without walls. The east end, with the windows, holds the reading and work area. The middle is for living and eating. The far end holds storage, the sleeping area, and the bathroom access.

Furniture layout principles:

- Keep the paths to the doors open.
- Put the desk and chair where the morning light falls from the side, not directly onto a screen.
- Use rugs to mark zones and soften the floor.
- Keep tall items against walls so they do not block light.
- Place lamps in each zone so I do not need to light the whole room.

Lighting is layered. The east windows give natural light in the morning. Floor lamps and table lamps handle the evening. A few focused lights sit over the work area.

Heating is set so the main areas stay comfortable while the storage end stays cooler. Curtains on the east windows are thick for winter and lighter for summer.

Storage is mostly in closed boxes on shelves, labelled on the front. Everyday items stay at hand height, and rarely used things go higher or lower.

Cables are bundled and routed along the walls. Power strips are placed where the equipment is, not stretched across the floor.

I review the setup each season. A large space invites drift, so a regular reset keeps things in order.

## Schedule

My routine for keeping the loft in order is built around the week and the season.

Weekly:

- Floor cleaning and vacuuming.
- Taking out rubbish and recycling.
- Wiping kitchen surfaces and the bathroom.
- A quick tidy of the zones so nothing accumulates.

Monthly:

- Window cleaning, east side first.
- Dusting shelves and the tops of tall furniture.
- Checking the first aid kit and extinguisher.
- Reviewing the budget sheet against actual spending.

Seasonal:

- Autumn: check heating, seals, and curtains.
- Winter: watch for damp and condensation.
- Spring: deep clean, air out, wash textiles.
- Summer: review shading and ventilation.

Yearly:

- Review the lease and insurance.
- Test and, if needed, replace smoke alarm batteries.
- Check the condition of the floor and windows and decide on repairs.
- Go through the storage and remove what I no longer need.

I do the heavier jobs on weekend mornings, when the east light makes the work pleasant and the loft is at its brightest. Quiet tasks go in the afternoon, when the light is softer.

If I miss a task I do not try to catch up on everything at once. I move it to the next free slot and carry on.

## Open questions

Things I still do not know about Dalsti loft.

- What was the space used for before it became a loft? The cider area had working premises, but I have no clear record.
- How well is the floor insulated from the ground below? I suspect it is minimal.
- Are the windows original from 2003, or were they replaced at some point?
- What is the condition of the wiring behind the walls?
- Will the owner allow permanent changes such as fixed partitions?
- How long will I stay? This affects whether to invest in insulation and storage.
- Is there a damp problem hiding behind the storage end walls?
- Could the east windows take secondary glazing to cut the winter cold?

I plan to answer some of these by asking the owner and neighbours. Others need a professional inspection, such as a check of the wiring and a damp survey.

For questions about the floor and the walls, I may try simple tests first: a cold surface check on a frosty morning, or looking for moisture marks after rain. These do not replace an expert opinion, but they help me decide whether an expert is needed.

I will update this list as I find answers, and move resolved items into the History or Observations sections.

## Checklist

A short list to run through when I do a full check of the loft.

- Lease reference at hand for any contact with the owner.
- Smoke alarms tested.
- Fire blanket and extinguisher in place and accessible.
- First aid kit complete.
- Paths to doors clear.
- Windows latched and seals intact.
- Draught strips in place on the doors.
- Heating working and set for the season.
- Curtains suited to the time of year.
- Rugs laid in the cold areas.
- Floor free of lifting edges and damp patches.
- Cables tidy and not under rugs.
- Lamps working in every zone.
- Storage boxes labelled.
- Rubbish and recycling cleared.
- Repair log up to date.
- Insurance and utility details current.

I run through the checklist at the start of each season and after any long absence. It takes less than an hour, and it catches small problems before they grow.

When something fails the check, I write it into the Problems section if it needs action, or into Maintenance if it is a routine fix.

## References

Sources and notes I rely on for this place.

- My own budget sheet, which holds the real cost figures.
- The lease document, identified by the reference in the Admin section.
- The repair log kept in my notes.
- Messages with the owner, saved in a folder.
- Manuals for the heating system and any appliances, kept in the document folder near the door.
- Insurance policy papers.
- Utility account statements.

Beyond these, I draw on practical experience: what I have noticed about the light, the cold, and the sound across the seasons. Those observations are in the Observations section.

I also keep notes from conversations with neighbours about the history of the cider area and the building. They are informal and not always reliable, so I mark them as hearsay until I can confirm them.

If I find a useful general guide on insulation, damp, or electrical safety, I will add a short summary here along with a note on why it was useful. I only keep references that I have actually used.

## Problems

Current and recurring issues in the loft.

- Cold floor in winter. This is the most persistent problem, and rugs only partly solve it.
- Drafts at the east door when the wind is strong.
- Condensation on the east windows on cold mornings.
- Echo in the large space when it is bare.
- Dust build-up along walls and under shelves.
- The far end of the loft stays cooler than the rest.
- Clutter creeping into empty corners.

For each problem I note what I have tried:

For the cold floor, I added rugs and underlay. It helps, but a real fix would be insulation beneath the floor, which needs the owner's approval. For drafts, I fitted strips and a door curtain. For condensation, I wipe the windows and ventilate briefly each morning. For echo, I added rugs and soft furnishings. For dust, I clean along the walls more often. For the cool far end, I use a small heater when needed and keep the sleeping area warmer with extra bedding. For clutter, I tidy on schedule.

When a problem gets worse, I record when it happened and what the weather was. That helps me see patterns and decide whether to ask for professional help.

Some problems are tied to the building, and I accept them. Others are habits, and I can change them. Sorting them into those two groups helps me decide where to spend effort.

## Tools

The tools and supplies I keep for the loft.

- Broom, mop, and vacuum for the floor.
- Microfibre cloths and a squeegee for the windows.
- Screwdrivers, a hammer, pliers, and a spirit level for small repairs.
- A drill for shelves, used only after the owner's permission for any wall fixing.
- Draught strips and sealant for doors and windows.
- A torch for dark corners and for checking behind furniture.
- A stepladder for high shelves, windows, and alarms.
- A moisture meter for checking suspicious patches.
- Spare batteries for smoke alarms and remotes.
- A first aid kit, fire blanket, and extinguisher.
- Labels and a marker for storage boxes.
- A notebook, or this notes system, for the repair log.

I store the tools together in one cupboard near the storage end of the loft, so I do not need to walk across the large room to find them. The most used items, such as the cloths and the torch, stay in a smaller box closer to the main living area.

I replace tools only when they fail or when a job clearly needs something better. A large space tempts me to buy more than I need, so I try to borrow rare tools instead. When I borrow, I note it in my log so that I remember to return it.
