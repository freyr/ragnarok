---
type: reference
status: active
project: reference
area: cider
description: "Reference about Faelglor cellar."
---

# Faelglor cellar handbook

## Open questions

These are the things about the Faelglor cellar that I still cannot answer from my own notes. I keep them in one place so I can check them the next time I am down there.

- The cellar was built in 1994, but I do not know whether the original builders planned it as a cider cellar or whether it was adapted for cider later. The thick inner wall suggests a different first purpose.
- It sits at ground level, so it is not a true underground cellar. I want to know why it stays cool in summer anyway. My guess is the stone floor and the shade, but I have not tested that.
- The cellar faces west. Afternoon sun hits the outer door in summer. I do not know how much heat comes through the door and how much through the wall beside it.
- The cellar is large, yet I am not sure how much of the floor I actually use. Some corners seem to go unused for months at a time.
- Is the faint damp smell near the back wall a drainage problem or just the old mortar? I have noted it three seasons in a row without acting on it.
- Which of the oldest barrels still hold a good seal? I have never written down which ones I trust.

A few smaller questions are worth keeping too. Does the door need a better threshold seal? Would a second vent help in autumn, when the air is heavy with fermenting fruit? Who last repaired the lamp fittings near the entrance, and with what?

## Observations

This section is the working description of the place. The first list holds the basic properties as I know them, with their exact values.

- Name: Faelglor cellar
- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

Beyond those values, here is what I have noticed over time.

**Temperature.** The cellar is cooler than the yard at nearly every hour of the day. The coolest spot is toward the back, away from the west-facing door. The warmest spot is just inside the entrance, especially in the late afternoon, when the sun comes straight along the floor. I keep the most sensitive batches well away from that end.

**Air and smell.** In autumn the whole room smells of crushed apples and yeast. That is normal and I like it. In winter the smell fades to something close to wet stone. The odd damp note near the back wall appears mostly after long rain.

**Light.** There is very little natural light, which suits cider. The only real daylight comes through the door when it is open. I work mostly by the fixed lamps, and I carry a hand torch for the corners.

**Space.** Because the cellar is large, I can keep working areas separate. The front third is for receiving fruit and moving containers. The middle is for pressing and transfer work. The back is for slow storage and ageing. This split has worked well and I want to keep it.

**Floor.** The ground-level floor is hard and mostly flat, with a gentle fall toward one side. Water runs that way when I wash down. I have learned to leave nothing on the low side that I would not want wet.

**Sound.** The room is quiet and the walls deaden outside noise. Fermenting vessels bubble audibly on a still evening, which is a handy way to check on them without opening anything.

## Ideas

These are changes and experiments I would like to try. None of them is decided, and I will only do the cheap ones first.

- **Shade the west door.** A simple awning or a screen of slats outside the door could cut the late sun in summer. This is probably the best value for the effort, since the heat at the entrance is my most obvious problem.
- **Add a thermometer at each end.** One near the door and one at the back would give me real readings instead of guesses. I could write the readings in a small notebook kept on a hook by the entrance.
- **Mark the barrels.** A short tag on each barrel noting its condition and what it last held would answer my open question about the old seals. A simple three-level mark (trusted, doubtful, retire) would be enough.
- **Test the damp wall.** Before I repair anything, I could tape a small sheet of plastic to the back wall for a week and see where the moisture shows up. That would tell me whether it comes from the wall or from the air.
- **Raise the low-side storage.** Pallets or low racks on the side where water runs would keep containers dry after washing.
- **Improve the lamps.** Brighter, warmer lamps over the pressing area would make the work easier in the evening. I would keep the back of the cellar dim.
- **Use the idle corners.** The unused corners could hold empty containers, tools, or cleaning supplies, which would clear the main floor for actual work.
- **Keep a short log.** One line per visit, covering what I did, what I noticed and what needs attention, would build up a record I could rely on. It would also make this note easier to update.

## Schedule

I do not use fixed calendar dates here. The cellar runs on the cider season, so this schedule is a rhythm of routines rather than a timetable.

**Every visit**
- Look at the floor for water, spills or anything that has shifted.
- Listen to the vessels and glance at the airlocks.
- Check the entrance for heat and light, particularly in the afternoon.
- Add a line to the log once I start keeping one.

**Every week**
- Wash down the working area in the middle of the cellar and let the water run to the low side.
- Sweep the front third, where the fruit arrives.
- Read both thermometers, if I have fitted them, and note anything unusual.

**Every month**
- Walk the whole cellar, including the back wall, and check for new damp.
- Inspect the barrels I rely on most and update their tags.
- Test the lamps and replace any that are failing.
- Look over the door seal and hinges.

**Each autumn**
- Clear the front third before the fruit comes in.
- Check that the vents are open and not blocked.
- Plan where each new batch will stand, using the front, middle and back split.
- Make sure the pressing area is clean and the floor is dry.

**Each winter**
- Review the barrels and decide which ones to retire.
- Make any repairs to the damp wall or the floor while the cellar is quiet.
- Reread this note and update the open questions.

**Each summer**
- Watch the west door in the late afternoon and keep sensitive batches away from the entrance.
- If I have built a shade for the door, check that it is holding up.
- Keep the door closed as much as I can during the hottest hours.

## Background

Faelglor cellar is a large cellar at ground level, built in 1994. It belongs to the cider side of the operation, and its area is cider. The main door and the long wall face west, so the afternoon sun hits the front of the building and never reaches the inside. I keep this in mind whenever I think about temperature, because the west face is the warm face and the cellar has to be managed with that in mind.

The building was put up in 1994 as a working space for pressed apple juice and the cider that follows. It was never a deep, dug-out cellar. Because it sits on the ground level, there are no steps to carry crates down, and a trolley can roll straight in from the yard. That was the main reason it was built this way, and it is still the best thing about it. Moving full barrels is much easier than it would be in a sunken room.

Size is the other defining property. The cellar is large, which means it can take the whole season's pressing without anything being stored elsewhere. It also means the room is slow to change temperature, which helps in winter and hurts a little in a hot spell. A large space needs more care with air movement, more thought about where things are stacked, and more walking when I do a check.

Here is the short version of the properties, so I do not have to look them up each time:

- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

Over the years the room has settled into a routine. Barrels go along the north and east walls, which stay coolest. Empty crates and equipment stay nearer the west door. Bottled stock sits in the middle, where the temperature changes least. I did not plan this at the start. It came from watching where things went wrong and moving them.

## Risks

The risks come mostly from three of the properties: the west orientation, the ground level floor, and the age of the building, which dates from 1994. I list them here in rough order of how much they worry me.

**Heat from the west.** The west wall takes the late sun. In summer the wall warms through the day and gives that heat to the room in the evening, just when I would like the cellar to be cooling down. Warm cider ferments faster, and it can pick up flavours I do not want. A batch that is left near the west wall can be noticeably different from one kept near the east wall.

**Ground level damp and flooding.** Since the floor is at ground level, there is no buffer between the room and the yard. Heavy rain can push water under the door. Damp also rises through the floor slab in wet months. Damp is not only a comfort issue: it spoils labels, rots wooden crates and encourages mould on anything stored on the floor.

**Age of the building.** The cellar was built in 1994, so some parts are tired. Seals around the door have hardened, and the floor drain has become slower. None of this is an emergency, but small faults add up, and a large room hides them well because I do not see every corner every day.

**Pests.** Apples attract wasps and fruit flies in autumn, and a ground level door gives them easy entry. Mice are also a concern, especially when sacks and crates are stacked against a wall.

**Spills and slipping.** A large floor with a wet patch is a real hazard when I am carrying something heavy. A spill of juice is also sticky and draws insects within hours.

Things I watch for, in the order I check them:

- Water at the base of the west door
- Warm air along the west wall in the evening
- Dark patches on the floor or lower walls
- Insects around the crates
- Anything chewed or moved near the stacked sacks

## Problems

These are the problems I have actually had, as opposed to the ones I only worry about. I keep them here so I remember what happened and what helped.

**Evening warmth.** The first few summers, the cellar warmed noticeably in the evening, and the barrels nearest the west door fermented faster than the others. The result was uneven batches. The fix was not clever: I moved the barrels to the cooler walls and kept only empties near the west side. Hanging a heavy curtain inside the door also helped a little.

**Water under the door.** After long rain, a thin sheet of water would come in at the west door and run across the floor. Because the room is at ground level, it had nowhere to go but inward. I have since put a raised strip across the threshold and cleared the yard gully outside. It is not perfect, but a normal storm no longer reaches the barrels.

**Slow drain.** The floor drain is old and clogs with pulp and bits of apple. When it backs up, a puddle sits in the middle of the room. I now flush it after each pressing day and rake out the grate by hand.

**Mould on the lower walls.** The wall base on the west side stays damp longer than the rest, and a grey bloom appears there if I ignore it. I scrub it with a stiff brush and keep stock away from the wall. Leaving a gap behind the stacks lets air move, which slows it down.

**Wasps in autumn.** During pressing season, wasps come in through the open door. I now keep the door shut between trips, and I wipe up every spill straight away. A fine mesh over the vent also made a difference.

**Cold snaps.** The opposite problem comes in deep winter. A large room holds cold, and bottled stock near the door can chill more than I want. Moving bottles toward the middle solved it.

What I have learned is that most of these problems come back every year in the same places. So the useful habit is not a clever repair but a regular check, done at the same time and in the same order.

## Setup

This section describes how I have arranged the cellar so that it works with its properties and not against them. The room is large, at ground level, faces west, and dates from 1994, so the layout follows from those facts.

**Zones.** I split the floor into three rough zones:

- Cool zone along the north and east walls: barrels of maturing cider
- Middle zone: bottled stock on shelves, away from both the door and the walls
- West zone near the door: empty crates, the press tools, hoses and cleaning gear

**Floor.** Nothing valuable sits directly on the slab. Barrels go on timber cradles, and crates go on pallets. This keeps them out of any damp or spilled water and lets air pass underneath. Since the floor is at ground level, I treat it as always slightly damp.

**Door.** The west door is the weak point, so it gets most of the attention. It has a raised threshold strip, a heavy inner curtain against the evening sun, and a habit: it stays shut unless I am carrying something through. In the pressing season I also keep a mop and a bucket just inside it.

**Air.** A large room needs air to move. I leave the vents open on cool nights and close them during the warm afternoon. A gap behind every stack keeps the walls dry, and I leave a clear walking lane down the middle so I can see the whole floor from the door.

**Drain and cleaning.** The drain gets flushed after each pressing day, and the floor is hosed and squeegeed at the end of each week in season. In winter, once a fortnight is enough.

**Routine checks.** My walk-round follows the same order every time:

- Door base and threshold for water
- West wall for warmth and damp
- Drain grate for blockage
- Barrels and bottles for leaks or odd smells
- Corners and sacks for signs of pests

**Notes to self.** If I ever change the layout, the rule is to keep the heat-sensitive things away from the west side and everything that can be damaged by damp off the floor. The size of the room gives me plenty of space to do both, and that is the whole point of having a large cellar built at ground level in 1994: easy access, plenty of room, and a set of habits to cope with the weather coming from the west.

## Supplies

This section lists what I keep stocked for the Faelglor cellar and where each item lives. The cellar is a large, ground-level cellar built in 1994, and it is used for cider. Because it is big, I buy in bulk and store the spare stock near the west door, where it is easiest to carry in.

Core supplies I check before every pressing season:

- Cleaning: food-safe sanitiser, a stiff brush for barrel staves, a soft brush for tank fittings, and plenty of clean cloths.
- Fermentation: airlocks, bungs in several sizes, spare tubing, and a few replacement taps.
- Measuring: a hydrometer, a spare hydrometer jar, a thermometer, and pH strips.
- Bottling: bottles, crown caps, a capper, and a bottle rinser.
- Labelling: waterproof labels and a marker that survives damp.
- Record keeping: a notebook that stays in the cellar, plus pencils, because ink runs when things get wet.

Things I tend to run out of first are bungs, cloths, and sanitiser. I keep a rough rule: when a box is half empty, I add it to the next order. Airlocks are cheap and fragile, so I always keep a handful more than I think I need.

Storage notes:

- Dry goods such as caps and labels go on the highest shelf, away from floor moisture.
- Cleaning chemicals stay on a low shelf by the drain, in their original containers, with the lids tight.
- Spare tubing hangs on hooks so it does not kink.
- Empty bottles stay in their crates, mouth down, so dust and insects stay out.

The west orientation matters for supplies in one small way. The late afternoon sun warms the west wall a little in summer, so I do not keep anything heat-sensitive against that wall. Labels with weak glue, for example, curl if they sit there too long.

## Overview

The Faelglor cellar is a cellar in the cider area of my notes. It was built in 1994 and sits at ground level, so there are no stairs to manage. That makes moving crates, barrels, and hoses much easier than in an underground cellar. The cellar faces west, and its size is large, with enough room for the pressing equipment, the fermentation vessels, and the bottle storage at once.

Quick reference to the properties:

- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

**Layout.** I think of the cellar in three zones. The first is the working zone near the west door, where apples arrive, get washed, and are pressed. The second is the middle of the room, where the fermentation vessels sit in rows. The third is the back, where finished cider rests in bottles and barrels. Moving from the door to the back follows the order of the work, so I rarely walk against the flow.

**Ground-level floor.** Being at ground level means the floor is closer to outside temperature than a deep cellar would be. In winter the room gets colder, and in summer it can warm up. A deep cellar holds a steadier temperature, so I have to watch this more carefully. I check the thermometer morning and evening during fermentation and write the reading in the notebook. Slow, cool fermentation gives me the cider I like best, so I try to keep the room on the cool side.

**West orientation.** The west side gets afternoon light and warmth. I keep the west windows covered during the warm months, and I keep the barrels away from that wall. In cooler months the extra warmth is actually useful, and I sometimes move a vessel closer to it to wake up a slow fermentation.

**Large size.** The space is generous, which is good, but it also means that clutter builds up unnoticed. I do a full tidy at the end of each season. Because the room is large, it also takes longer to air out after cleaning, so I plan cleaning days with that in mind.

**Age.** A cellar from 1994 has had decades of use. The walls and floor are sound, but small things need attention over time: the drain, the door seals, and the shelf brackets. I look at these during the seasonal tidy and fix small problems before they grow.

**Typical year.**

- Autumn: apples arrive, pressing starts, and fermentation begins.
- Winter: slow fermentation and racking, with regular temperature checks.
- Spring: bottling and labelling, then a deep clean.
- Summer: resting stock, light checks, and keeping heat out.

## Safety

A large ground-level cellar is safer than a deep one in several ways, but fermentation still brings real hazards. These are the ones I keep in mind.

**Carbon dioxide.** Fermentation releases carbon dioxide, which is heavier than air and can collect low in a room. The cellar is at ground level and has good airflow through the west door, but I still do not skip ventilation. During active fermentation I open the door and any vents before spending a long time inside. If I feel dizzy, get a headache, or feel unusually tired in the cellar, I leave straight away and let the air clear before going back. I never work alone in the cellar on the busiest fermentation days if I can avoid it.

**Wet floors.** Pressing and cleaning leave the floor slippery. I wear boots with a good grip and keep the drain clear. Hoses get coiled after use rather than left across walkways. Spills get wiped up straight away, because sugary juice is sticky and slippery at once.

**Lifting.** Full crates of apples and full barrels are heavy. Ground level helps, since I can use a trolley instead of carrying things on stairs. I lift with my legs, ask for help with heavy items, and never stack crates higher than I can reach comfortably.

**Chemicals.** Sanitiser and cleaners are kept in their original containers on the low shelf by the drain. I never mix products, I wear gloves and eye protection when pouring concentrates, and I rinse everything well so nothing ends up in the cider.

**Glass.** Bottles can break, and bottles under pressure can burst. I store bottled cider in crates, not loose, and I check that secondary fermentation is complete before capping. If a bottle looks swollen or a cap is bulging, I handle it with thick gloves and move it somewhere cool.

**Heat and cold.** On warm days the west wall warms up, and the room can become uncomfortable. I take breaks and drink water. On cold days I wear layers, because cold hands make careless mistakes.

**Basic safety kit.**

- A first aid box near the west door
- A torch that works without mains power
- A fire extinguisher, checked each season
- Clear access to the door, with nothing stored in front of it

I also keep the door path clear at all times. In a large room it is easy to let things creep into the walkway, and that is the one place where clutter can cause a real accident.

## Costs

I do not track exact figures in this note, since prices change and I record them elsewhere. Instead, this section describes where the money goes and how I think about it, so I can plan each season.

**Main areas of spending:**

- Apples: the biggest cost in a good year, and it varies with the harvest. A poor harvest raises the price, so I try to arrange supply early.
- Consumables: sanitiser, cloths, bungs, airlocks, caps, and labels. Each is cheap alone, but together they add up over a season.
- Bottles: a large outlay at first, though reusing and sanitising bottles cuts the cost a great deal.
- Equipment upkeep: replacing tubing, taps, and seals, and repairing the press.
- Energy and water: cleaning uses a lot of water, and cold weather may call for some heating.
- Building upkeep: the cellar dates from 1994, so I set aside money for small repairs to the drain, door seals, and shelving.

**Where I save:**

- Buying consumables in bulk, which is easy because the cellar is large and has space to store them.
- Reusing bottles and cleaning them carefully.
- Using the natural coolness of the ground-level room, so I do not need active cooling for most of the year.
- Fixing small problems early, before they turn into expensive ones.

**Where I do not cut corners:**

- Sanitiser and cleaning gear, since a spoiled batch costs far more than good cleaning supplies.
- Safety items such as the fire extinguisher and first aid box.
- The thermometer and hydrometer, because accurate readings protect the whole batch.

**How I plan.** Before each autumn I walk through the cellar with the notebook and list what is low or worn. I group the list into must-buy items, nice-to-have items, and repairs. Must-buy items are ordered first. Repairs are scheduled for the quiet summer months, when the cellar is less busy. After bottling in spring, I compare what I spent with what I planned and note any surprises, so the next year's plan is a little better than the last.

## Checklist

This is the routine I run through whenever I go down to the Faelglor cellar. It is a large cellar on the ground level, built in 1994, with its main wall facing west. It is used for cider, so most of the checks are about keeping the air steady and the barrels sound.

**On arrival**

- Open the west door only as far as needed and let the air settle for a minute before walking in.
- Look at the floor near the door for wet patches. Because the cellar sits at ground level, water from outside can creep in after heavy rain.
- Smell the air. A sharp vinegar note means something has turned, and I trace it before doing anything else.
- Check that the lamps are working and that no cable is lying in a damp spot.

**Barrels and tanks**

- Walk the rows and look at every bung and airlock. Each airlock should have clean water in it and should bubble slowly if fermentation is still going.
- Look under each barrel for drips or dark stains on the wood.
- Check that the labels are readable and match my cider log.
- Note any barrel that sounds hollow when tapped; it may have lost liquid.

**Temperature and air**

- Read the thermometer at both ends of the cellar and write the readings in the log.
- Compare the warm west side with the cooler back wall. In the afternoon the west side picks up heat, so I watch the barrels nearest the wall.
- Open the vent a little if the air feels heavy, and close it again if the cellar gets too cold.

**Cleanliness**

- Sweep the floor and wipe any spilled cider at once, since sugar draws flies and mould.
- Rinse the drain and make sure it flows freely.
- Wash any hose or funnel I used and hang it up to dry.

**Before leaving**

- Close the vent to its usual setting.
- Shut and latch the west door.
- Write the date, the readings, and any problems in the log, and put a mark next to anything I need to deal with on the next visit.

## Tools

I keep most of the tools in the cellar itself, on a shelf near the door and on hooks along the side wall. Anything that is borrowed or only used once a season lives in the house instead.

**Everyday tools**

- A long-stem thermometer for the barrels and a wall thermometer for the air.
- A hydrometer and a tall test jar for measuring how far the cider has fermented.
- A siphon hose with a clean tip, used for moving cider from one container to another.
- A funnel with a fine strainer.
- A set of spare bungs and airlocks in a labelled box.
- A wooden mallet for seating bungs and tapping barrels.
- A notebook and pencil on a string, kept dry in a plastic sleeve.

**Cleaning tools**

- A stiff broom and a soft brush for the floor and the barrel racks.
- A bucket for rinse water and a second bucket kept only for sanitising solution.
- A scrubbing brush with a long handle for the inside of tanks.
- Cloths that I wash after every visit, so they never sit damp.

**Lighting and safety**

- A hand torch for looking behind and under the barrels.
- A spare lamp in case the main light fails.
- A fire blanket and a small extinguisher by the west door.
- Rubber gloves and boots, because the floor is often wet.

**Care of the tools**

I wash everything that touches cider with hot water and rinse it well. Wooden handles are dried before they go back on the hooks. Once a year, usually after the main pressing, I go through the shelf, throw away cracked hoses and worn bungs, and replace what is missing. I keep a short list of what I have replaced so that I do not buy the same thing twice.

## History

The Faelglor cellar was built in 1994. From the beginning it was planned as a large cellar at ground level, with the working wall facing west, and it was meant for storing and making cider. The ground-level position made it easy to roll barrels in and out without stairs, which was the main reason for choosing it over a deeper cellar.

**Early years**

In the first years the cellar was used simply and the layout was open. Barrels stood in a few loose rows, and the cooling depended almost entirely on the thickness of the walls and on opening the door at night. Those years taught me how much the west-facing wall warmed up on summer afternoons, and that is why I still pay close attention to the barrels nearest to it.

**Changes over time**

- The vent was adjusted so that the air could be controlled more carefully.
- Wooden racks were added to keep the barrels off the floor and away from damp.
- The drain was cleaned out and its slope corrected after a wet season left water standing near the door.
- The shelf and hooks for tools were put in by the door so that everything could be reached without walking through the barrels.
- The lighting was improved so that the rows could be inspected properly.

**How it is used now**

Today the cellar is the center of the cider work. Pressed juice goes in during the autumn, ferments through the cold months, and is checked on a regular schedule using the checklist above. The size of the cellar means there is room to keep several batches apart, so a problem with one barrel does not spread to the rest.

**Lessons learned**

- Keep the floor dry; most trouble began with water.
- Do not let the west wall barrels get warm.
- Write everything in the log, because memory is not reliable from one season to the next.
- Clean as you go, since small spills turn into big problems quickly.

## References

These are the sources I rely on when I have a question about the cellar. They are all my own notes and the printed material I keep with them.

- **Cider log:** the notebook where I record readings, batch labels, and problems from each visit. It is the first place I look when something seems off.
- **Cellar checklist:** the routine written out above, which I also keep as a printed sheet pinned inside the west door.
- **Tool list:** the short record of replaced and missing items kept in the notebook sleeve.
- **Batch sheets:** one page per batch, describing the juice, the date it went into the barrel, and the results of each hydrometer reading.
- **Cleaning notes:** my own instructions for sanitising hoses, barrels, and tanks, including how long to rinse.
- **Repair notes:** a record of changes made to the vent, racks, drain, and lighting since the cellar was built in 1994.

**Facts about the cellar, for quick lookup**

- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

When I update the handbook, I change the checklist first, then the tools, and then add any new event to the history. If a reference becomes out of date, I cross it out in the notebook and write the replacement beside it, so I can still see what I used before.

## Admin

This section holds the paperwork side of the Faelglor cellar: who holds the lease, what the basic facts of the place are, and how I keep the routine admin under control. It is written for my own use, so it is blunt and practical.

### Lease reference

The lease reference of Faelglor cellar is LR-374768. I quote this exactly whenever I write to the landlord's office, ask about the rent, or send in a repair request. If a letter or email does not carry the reference, it tends to get lost or answered slowly. I keep the reference at the top of every message I send about the cellar.

### Basic facts about the place

These are the properties I check against any form that asks for a description of the premises. They should match every time.

- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

A few notes on how these show up in the paperwork:

- The "kind" is cellar, even though the floor is ground level. Some forms assume a cellar is below ground and get confused. I write "cellar" as the kind and "ground level" as the floor, and I add a short line of explanation if the form has a free text box.
- The "area" is cider. This means the cellar is used for the cider side of the work, and I describe it that way on any insurance or inspection form.
- The orientation is west. This matters for the afternoon light and warmth that reach the front wall, and I mention it when talking to anyone about temperature control or about where stock may be stored.
- The size is large. I do not write a floor measurement on forms unless asked, because the lease already carries the official figure and I do not want two versions floating around.
- The year built is 1994. Inspectors sometimes ask about the age of the building for wiring and drainage questions, and this is the answer I give.

### Who to contact for what

I keep contacts by role instead of by name, because the people change more often than the roles do.

- Landlord's office: lease questions, rent queries, permission for any change to the structure.
- Building repairs contact: leaks, damaged doors, cracked floor sections, faulty lighting that is part of the building.
- Insurance contact: certificates, changes to stock cover, claims after any damage.
- Local inspector: hygiene checks, fire safety checks, and any questions about the use of the cellar for cider.
- Utilities provider: water, power and drainage faults that start outside the building.

When I contact any of them I give the lease reference, the kind of place, and the floor. That saves the usual round of questions about which unit I mean.

### Routine admin tasks

I split the admin into things I do on a regular rhythm and things I do only when something happens.

**Regular tasks**

- Check that the lease paperwork is filed in the right folder and that the digital copy matches the paper copy.
- Review the insurance cover once a season, to make sure it still fits the stock and equipment actually kept in the cellar.
- Read the utility statements and compare them with what I expect. A jump in water or power use is often the first sign of a problem.
- Walk the cellar with a notebook and write down anything that looks worn, damp, loose or out of place.
- Keep the safety items in date: fire extinguisher check tags, first aid supplies, and the emergency contact sheet by the door.

**Event-driven tasks**

- A repair is needed: photograph the problem, write a short description, quote the lease reference, and send it to the building repairs contact.
- Stock changes significantly: tell the insurance contact so the cover stays accurate.
- An inspection is announced: gather the paperwork, tidy the cellar, and make sure access to the main areas is clear.
- A change to the structure is wanted: ask the landlord's office in writing before anything is done, and wait for the answer.

### Records I keep

I keep records in a simple, repeatable way so I can find things quickly. Each record is named in plain words with the subject first, such as "insurance certificate" or "repair request leak", so a search brings it up straight away.

- The lease itself, with the reference LR-374768 written on the first page of my working copy.
- Every letter and email with the landlord's office, kept in order.
- Insurance certificates and the matching correspondence.
- Inspection reports and any follow-up actions I took.
- Repair requests, each with photographs and a short note on what happened afterwards.
- Utility statements, kept for as long as I might need to compare them.

I do not keep duplicate copies in several places. One master folder holds everything, and a backup copy sits elsewhere in case the first one is lost.

### Writing to the landlord's office

Messages work best when they are short and complete. My usual pattern is:

1. The lease reference on the first line.
2. A one-sentence summary of what I need.
3. The facts: what happened, where in the cellar, and when I noticed it.
4. What I want done and by when, in plain terms.
5. A line saying I am happy to give access for a visit.

For example, a request about damp would name the reference, say that the west-facing wall of the ground-level cellar shows damp, describe where, and ask for someone to look at it. Mentioning the west orientation helps, because it tells the reader which wall I mean and why weather might be the cause.

### Access and keys

Access to the cellar is controlled, and I treat keys as part of the admin. I keep a short list of who has a key and why. If a key goes missing, I report it to the landlord's office straight away and ask whether the lock should be changed. I never lend a key without noting who has it and when it is due back. Visitors such as inspectors or repair workers are let in by me or by someone I trust, and I stay with them if I can.

### Insurance notes

The cellar is a large ground-level space used for cider, so the insurance needs to reflect that use. When I review the cover I check these points:

- The description of the place matches the facts listed above.
- The stock cover is enough for what is actually stored.
- Equipment is covered, including anything that would be costly to replace.
- Damage from water or flooding is included, since ground level can be exposed.
- The conditions of the policy, such as security requirements, are being met.

If the description on the policy is wrong in any detail, I ask for a correction in writing and keep the reply.

### Inspection preparation

Before any inspection I run through a short checklist.

- Floors are clear and dry, and walkways are not blocked.
- Fire safety items are in place and visible.
- Electrical fittings look sound, and nothing is overloaded.
- Drains are clear and nothing is leaking.
- Stock is stored sensibly and nothing is touching the walls where damp could build up.
- Paperwork is ready, with the lease reference to hand.

After the inspection I write down what was said while I still remember it, and I note any action I agreed to, with a rough time frame in words rather than a fixed date unless one was given.

### Common mistakes to avoid

- Sending a request without the lease reference.
- Describing the cellar as below ground on a form when the floor is ground level.
- Letting the insurance description drift away from what is actually in the cellar.
- Making a change to the structure before getting written permission.
- Keeping important messages only in my head or in one inbox.
- Forgetting to note who has a key.

### Quick reference

- Lease reference: LR-374768
- Kind: cellar
- Area: cider
- Orientation: west
- Size: large
- Year built: 1994
- Floor: ground level

If I only have a minute and a form to fill in, this list is what I copy from.
