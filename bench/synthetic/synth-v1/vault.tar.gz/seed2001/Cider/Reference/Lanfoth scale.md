---
type: reference
status: active
project: reference
area: cider
description: "Reference about Lanfoth scale."
---

# Lanfoth scale

## Supplies

The Lanfoth scale is a yellow battery-powered scale that sits in the loft, where I use it for cider work. It was installed in 2014. These are the things I keep close to it so I never have to hunt for them mid-job.

- Spare batteries, stored in a small tin on the shelf directly above the scale. The scale runs on battery, so a dead set in the middle of a weighing is the most common way a session gets ruined.
- A soft dry cloth for wiping the platform. Apple pulp and juice dry to a sticky film that changes readings.
- A small soft brush for the edges and the gap around the platform.
- A set of check weights. I use them to test the scale before any serious weighing session.
- A pencil and a notebook that stay in the loft. I do not trust my memory for readings.
- A clean plastic tray that sits on the platform, so fruit never touches the scale directly.
- A roll of masking tape for labelling bins and marking where the tray belongs on the platform.
- A torch, because the loft light is poor in the evening and the display is hard to read in shadow.

I keep all of this in one crate under the eaves, next to the scale. If something leaves the loft, it goes back in the crate the same day.

## Adjustment

The scale drifts a little over the years, so I adjust it rather than trusting the factory zero. The calibration offset of Lanfoth scale is 0.498 mm. That figure is the one I set when I last worked through the adjustment, and I check it each time I do a full calibration.

The offset is expressed as a length because the adjustment screw moves a small lever, and I measure how far the lever travels. It is not a weight. If I ever forget this, I end up looking for a number in grams that does not exist.

How I adjust it:

1. Let the scale sit in the loft for a while before starting. The loft changes temperature through the day, and a cold scale reads differently from a warm one.
2. Take off the tray and the platform cover, and clear the area.
3. Switch the scale on and wait for the display to settle on zero.
4. Check the lever position against the offset written above. If the travel is off, turn the screw slowly until it matches.
5. Put the tray back and press the zero button so the tray weight is ignored.
6. Place a check weight on the tray and read the display. Repeat with a second, heavier weight.
7. If both readings look right, write the date and the result in the notebook.

I make small turns and recheck after each one. Large turns tend to overshoot, and then I spend longer undoing my own correction than I would have spent being patient.

If the readings are fine but the lever is off from the offset, I leave it alone for that session and note it down. A scale that weighs correctly is more important than one that matches a number. I only change the offset when the check weights actually disagree.

## Background

The scale was installed in 2014, when I first started pressing apples in earnest and needed to know how much fruit went into each batch. Before that I guessed by the crate, which gave me very uneven results from one year to the next. Once I could weigh the fruit, I could compare yields and keep track of which trees were giving the most juice.

I chose a yellow one mostly because it is easy to see in the dim loft. It has turned out to be a good decision. When the light is poor, a bright yellow body is easy to find, and I no longer knock into it on the way past.

It is powered by battery rather than the mains. The loft has no good socket near the place I wanted the scale, and a trailing cable across a floor with apple crates on it is an accident waiting to happen. The battery also means I can move the scale if I need to, though in practice it rarely moves.

Over the years it has been a plain, reliable device. It does one job, weighs things, and I have not needed it to do anything else. The few problems I have had were all of the same kind: batteries, sticky residue, and drift. None of them was a fault in the scale itself.

The loft is dry for most of the year, but it does get damp in a wet autumn, which is exactly when I need the scale most. That is why I keep the cloth and brush close and why I look at the platform before every session.

## Open questions

These are things I have not settled and would like to understand better.

- How much does the loft temperature really affect the readings? I think a cold morning gives slightly different numbers from a warm afternoon, but I have never tested it properly. I could log a few readings of the same check weight at different times of day.
- Is the drift steady or does it come in jumps? My notes suggest it is slow, but there are gaps in them.
- Would a different battery type last longer in a cold loft? I have always used whatever was cheapest, and I do not know whether that is a false economy.
- Should I move the scale lower in the house for the colder months? The loft is convenient for storing cider gear, but it may be a harsh place for electronics.
- How long will the display last? It is already more than ten years old, and I have no idea what the typical life of this kind of device is.
- Is the platform perfectly level? I never checked it with a spirit level, and a slight tilt could explain some odd readings.

## Maintenance

Maintenance is mostly about keeping the scale clean and keeping the power reliable. I do not do anything complicated.

Routine after each session:
- Remove the tray and wash it.
- Wipe the platform with a slightly damp cloth, then dry it with a clean one.
- Brush out the gap around the platform edge.
- Switch the scale off and leave the platform clear.

Routine each season:
- Replace the batteries before the busy autumn period, even if they still seem fine. I would rather waste a set of batteries than lose a pressing day.
- Check the battery compartment for corrosion. If I see any white or green crust, I clean it off with a dry cotton bud and replace the contacts if they look damaged.
- Run the check weights through the scale and compare against what I wrote last time.
- Review the adjustment, using the calibration offset in the Adjustment section above.

Routine each year:
- Look over the whole body for cracks or loose parts.
- Check that the feet are all in place and that the scale does not rock.
- Read through the notebook to see whether the drift is getting worse.

I do not oil or lubricate anything. Any grease on the moving parts would attract dust and make things worse. If something sticks, I clean it, not lubricate it.

When the scale is going to be unused for a long period, I take the batteries out. Leaving them in over a long winter is how I ended up with corrosion once, and I do not want to repeat that.

## Overview

The Lanfoth scale is a yellow, battery-powered scale. It is installed in the loft and used for cider work. It has been in place since 2014.

Quick facts:

- Kind: scale
- Area: cider
- Color: yellow
- Energy source: battery
- Year installed: 2014
- Location: loft

I use it to weigh apples before pressing, to weigh pomace afterwards, and sometimes to weigh sugar or other additions. It is not a precision lab instrument, but it is good enough for the amounts I work with, provided I keep it clean and check it against known weights.

The thing I need to remember most is that it depends on its batteries and on a clean platform. If a reading looks odd, I check those two things first before suspecting anything else.

This note is the one place where I keep the details of the scale, so anything I learn about it should be added here instead of being scattered across other notes.

## Lessons

A few things I have learned the hard way over the years.

- Always zero with the tray in place. Early on I forgot, and an entire batch was recorded about the weight of a tray too heavy.
- Do not trust the first reading of the day. The scale needs a few minutes to settle, and the first number is often a little off.
- Do not let juice sit. A sticky platform gives slow, drifting readings, and cleaning it later takes far more effort than wiping it straight away.
- Replace batteries early. A weak battery does not always make the display go dark. Sometimes it just makes the numbers wander, which is more confusing than a clean failure.
- Write things down immediately. I once carried a figure in my head down the loft ladder and lost it on the way.
- Keep the spare batteries in the loft, not in the house. The one time I kept them downstairs, I needed them at the worst moment.
- Do not lean on the platform. It feels sturdy, but pushing down when I steady a crate can throw the zero off.
- Do not adjust the scale when I am in a hurry. Every time I rushed the adjustment, I had to do it again the next day.
- Small, gentle changes are better than large ones.

## Setup

The scale stands in the loft on a flat section of floor, away from the sloping part of the roof where I can bang my head. I chose the spot for three reasons: it is level, it is close to the hatch so I do not have to carry heavy crates far, and it is dry.

How it is set up:

1. The scale rests on a firm board, so the feet do not sit on uneven floorboards.
2. The tray sits on the platform, with tape marks showing where it belongs.
3. The crate of supplies sits to the left, within arm's reach.
4. A bin for fruit waste sits to the right.
5. The torch hangs from a hook on the nearest beam.

The batteries go into the compartment on the underside. I check the direction of each one before closing the cover, because getting them the wrong way round once cost me an afternoon of confusion.

After inserting fresh batteries, I switch the scale on, wait for the display to settle, and then run through the adjustment steps. I do not start weighing straight away, because new batteries and a cold start can cause odd readings for the first minutes.

If I ever need to move the scale, I take out the batteries first, carry it flat, and set it back on the same board. Then I repeat the adjustment before use.

## References

These are the places I look when I need to remember something about the scale.

- My own notebook in the loft crate, which holds the dated check-weight results and the battery changes.
- The paper instruction sheet that came with the scale, kept in a plastic sleeve in the crate. It is worn but still readable.
- The other notes in my cider folder that talk about pressing, yield and batch records. They mention weights, and they are the reason I keep the scale accurate.
- The label on the underside of the scale, which shows the battery direction.

I do not rely on anything online for this device. It is old enough that I doubt much is written about it, and the notebook has proved more useful than any outside source.

## Safety

The scale itself is harmless, but the loft is not, so most of my safety rules are about the place and the work.

- Mind the head. The roof slopes, and I have hit it more than once. I keep the work area where there is standing room.
- Take care on the ladder. I never carry a full crate up or down in one go. Smaller loads are slower but safer.
- Keep the floor clear. A tray, a crate or a dropped apple can cause a fall, and the hatch is close.
- Handle batteries with care. Do not mix old and new ones, and do not leave them in a hot or damp place. If a battery leaks, I wear gloves and clean the compartment carefully.
- Dispose of old batteries properly, not in the household bin.
- Keep the platform dry. Wet hands and wet fruit make for slippery handling, and a dropped crate of apples is heavy.
- Do not overload the scale. It is meant for modest weights, and I never put a full crate on it unless I am sure it is within the limit.
- Keep the light good. I use the torch whenever the loft is dim, so I can see where I am stepping.

## Schedule

This is the routine I follow through the year.

- Before each session: look at the platform, check the display, zero with the tray in place, and test with a check weight.
- After each session: clean the tray and platform, switch off, and write down anything unusual.
- Late summer: replace the batteries, check the compartment for corrosion, and run a full adjustment.
- During the pressing season: run a quick check weight test at the start of each pressing day.
- Winter: if the scale will not be used, remove the batteries and cover the platform.
- Spring: look over the whole device, read through the notebook, and decide whether anything needs attention before the next season.
- Once a year: review this note and update anything that has changed.

The late summer step is the one I must not skip. Everything else can slip a little, but a scale that fails at the start of the pressing season causes a lot of trouble.

## Observations

These are things I have noticed from using the scale over many seasons.

- The readings are steadiest after the scale has been on for a few minutes. In the first moments the display flickers slightly.
- On cold mornings the display seems slower to respond. It does settle, but I have to be patient.
- A tilted tray gives a different weight from a flat one. I now always make sure the tray sits in its taped position.
- Wet fruit weighs a little more than dry fruit, of course, but the scale also seems to settle more slowly with wet fruit on it, probably because of dripping.
- The yellow body has faded slightly where the sun comes through the loft window, though the display and buttons are unaffected.
- The battery life is shorter in the cold months. A set that lasts all of a mild autumn may only manage a part of a cold one.
- The scale has never failed outright. Every odd result I have traced back to batteries, dirt or a rushed setup.
- Readings drift slowly over a season, and the check weights show it before the fruit weights do.

## Ideas

Things I might try in the future.

- Keep a simple log sheet taped inside the crate lid, so the check-weight results are always in the same place.
- Test the effect of temperature by weighing the same check weight at several times of day and noting the loft conditions.
- Buy a better quality battery for the cold months and compare how long it lasts.
- Add a small spirit level to the board so I can see at a glance whether the platform is flat.
- Make a lid or cover for the scale so that dust and drips do not reach the platform between sessions.
- Fix a small shelf by the scale for the notebook, so it stops sliding off the crate.
- Mark the board with the exact position of the feet, so the scale always goes back in the same place after being moved.
- Think about whether it would be worth replacing the scale at some point, or whether regular care will keep it going for another ten years.
- Write a short checklist and laminate it, so I can follow the start-up steps without reading the whole note.
