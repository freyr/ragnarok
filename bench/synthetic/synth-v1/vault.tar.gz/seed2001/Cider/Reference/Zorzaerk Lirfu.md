---
type: reference
status: active
project: reference
area: cider
description: "Reference about Zorzaerk Lirfu."
---

# Zorzaerk Lirfu

## Setup

Zorzaerk Lirfu is my mentor for cider. I have known Zorzaerk since 2015, so this note covers about a decade of advice. The area is cider, and that is what almost every conversation is about: apple blends, pressing, fermentation, and how to decide when a batch is ready.

The way I work with Zorzaerk is simple. I contact Zorzaerk by email, not by phone and not by chat. Availability is on weekdays, so I do not expect an answer on a weekend, and I do not send anything urgent for Saturday or Sunday. A question written on Friday evening will usually be answered early the following week.

To make each exchange useful, I keep a small routine:

- I write one question per email, with the batch details in the first lines.
- I state what I already tried, so Zorzaerk does not repeat it.
- I say what decision I need to make and by when.
- I keep the reply in a folder with the same name as the batch.

Zorzaerk prefers short, concrete messages. A long story about my whole season gets a short answer. A specific question about one barrel gets a good one.

## Maintenance

Looking after the mentoring relationship takes little effort, but it needs some regularity. Since 2015 the habit that has helped most is writing back after I have acted on advice. Zorzaerk likes to know what happened, including when the result was poor.

My maintenance list:

- Send a short update after each pressing and again after each racking.
- Thank Zorzaerk for specific help, not in general terms.
- Review old replies once a year and mark which advice proved right.
- Update my own notes when Zorzaerk corrects something I wrote down.
- Do not ask the same question twice without first checking my archive.

Each autumn I read through the whole thread history. It shows me where I repeat mistakes, such as picking apples too early or rushing the first racking. Zorzaerk has pointed out the first one more than once, so I now keep a rule: wait, taste, then decide.

I also keep the cider side of things in order, because mentoring works best when my own records are clean. That means labeled containers, dated batch sheets, and a log of every tasting. When I write to Zorzaerk, I can then paste facts instead of guessing from memory.

## Costs

Zorzaerk does not charge me a fee for casual advice by email, and I do not treat that as free time to waste. The costs are mostly indirect, and I track them so I know what the relationship really takes.

Typical costs:

- My time to write clear emails and to document batches properly.
- Small gifts, usually a bottle from a good batch, sent after a successful season.
- Postage when I send samples for tasting.
- Occasional travel if we meet in person, which I pay for myself.

I do not offer money for advice, because that would change the relationship. When a piece of work goes beyond casual help, I discuss it openly first and agree on terms in writing. That is the reason the next section exists.

I keep a simple tally of what I spend on samples and postage each year. It stays small, but writing it down stops me from assuming it costs nothing, and it helps me decide how many samples are worth sending.

## Contracts

There is no long formal agreement between us, but one piece of work was put on paper. The contract date of Zorzaerk Lirfu is 2024-09-06. I keep the signed copy in my records folder together with the emails that led to it.

What I remember about the arrangement:

- It covers a defined piece of guidance, not general mentoring.
- It was agreed by email first, then written down.
- It does not change the weekday availability or the email contact.

If I ever need to renew or change it, I will start by rereading the original emails, then write a short proposal. I will not rely on memory about what was promised. Keeping the paper trail clear protects both of us, and Zorzaerk appreciates that I do it.

## Tools

The tools I use around this mentoring are modest.

- Email is the main channel, since that is the contact method Zorzaerk uses.
- A shared habit of subject lines that begin with the batch name, which makes searching easy.
- A notebook for tasting notes, copied into my vault afterwards.
- A hydrometer and a pH tester for readings I report in my questions.
- A calendar reminder on Mondays to send any questions that built up over the weekend.

The Monday reminder matters because of the weekday availability. Writing on Monday morning gives the best chance of a reply within a few days. For readings, I always write the raw measurement and the date it was taken, never a vague description like "it seems low".

I also keep a template for a standard question: batch name, apple mix, stage, readings, what I tried, what I need to decide. Using it has improved the quality of the replies a lot.

## Problems

A few problems come up repeatedly, and it helps to name them.

- **Slow replies.** Zorzaerk is available on weekdays only, so weekend questions wait. I plan ahead and send questions by Thursday when a decision is due.
- **Vague questions.** When I give too little detail, the answer is general and not very useful. The template fixes most of this.
- **Over-reliance.** It is easy to ask before thinking. I now write my own guess first, and then ask whether it is right.
- **Lost context.** Over many years, advice gets scattered. The yearly review and the batch folders reduce that.
- **Disagreement.** Sometimes my experience in my own cellar differs from the advice. I report what I saw and ask for an explanation instead of silently ignoring the advice.

If a problem is not solved by email, I ask for a short meeting on a weekday. That has happened only rarely since 2015, but it has always been worth it. Afterwards I write down what we agreed and file it with the batch records.
