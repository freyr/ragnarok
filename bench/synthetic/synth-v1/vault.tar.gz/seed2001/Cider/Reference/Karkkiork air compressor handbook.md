---
type: reference
status: active
project: reference
area: cider
description: "Reference about Karkkiork air compressor."
---

# Karkkiork air compressor handbook

## Supplies

This section lists what I keep on hand for the Karkkiork air compressor. It is a grey, solar-powered air compressor, installed in 2016 beside the pond, and it serves the cider work. Everything here is about keeping it running without a long trip to town, because the pond site is a walk from the house and a forgotten item costs a lot of time.

**Consumables I keep in the shed box**

- Compressor oil of the grade written on the tank label. I do not mix grades.
- A spare intake filter element, wrapped in a clean bag so it stays dry.
- A small tin of thread sealing tape.
- A few spare hose clamps in stainless steel, because the pond air rusts ordinary ones fast.
- Replacement rubber washers for the quick couplings.
- A tube of non-hardening grease for the coupling threads.
- Clean lint-free rags, a lot of them. Oil and cider residue both get everywhere.
- A bottle of mild food-safe cleaner for anything that sits near the cider line.

**Things I keep in the house, not at the pond**

- The paper copy of the maker's sheet, folded in a plastic sleeve.
- A notebook for pressure and timing readings. I also copy the useful bits into [[Saethland Bolvulkork log]].
- A spare fuse and a few spare cable ties for the solar wiring.

**What I buy when low**

Oil and filter elements are the only things that run out in practice. I check the box at the start of each cider season and again after the last pressing. Washers perish slowly, so I replace them on a schedule rather than waiting for a hiss.

I used to leave the spare filter loose in the box. It picked up dust and damp and was no better than the old one. Now it stays bagged, and I write on the bag when I put it there.

Related reading for similar upkeep habits: [[Triothkil dehumidifier notes]] covers the damp-control side of the shed, and [[Riothdrer dehumidifier plan]] explains why the shed stays dry enough for stored parts.

## Overview

The Karkkiork is an air compressor. It is grey, it runs on solar power, and it has been installed since 2016 at the pond. Its work belongs to the cider area of my notes: it supplies compressed air for moving and handling cider material near the pond, and for cleaning tasks around the press and the barrels.

**Why solar and why the pond**

The pond site has no mains supply worth the cost of running a cable. A solar panel feeds the compressor, so the machine is only really useful when the sun is out or the battery buffer has charge. That shapes how I use it. I fill the tank in good light and then work from the stored air. I do not try to run it hard in the evening.

The position next to the pond is practical in another way. There is level ground, shelter from the worst wind, and a short path to the cider work area. The downside is moisture. Damp air gets into everything, so the tank, the lines and the fittings all need regular attention.

**How it behaves day to day**

- It builds pressure slowly on a bright day and faster than I expect on a very clear one.
- It switches off by itself when the tank reaches the set pressure.
- It restarts when the pressure falls, provided there is enough power.
- On dull days it may stop partway through a job. I plan around that rather than fighting it.

**How I think about the setup**

I treat the compressor as a small, steady source of air, not a workshop machine. Short jobs go well. Long jobs need planning. If I need continuous air for a long time, I fill the tank first, rest, and fill it again.

Other notes touch the same site. [[Nermior level sensor tests]] records how the pond level was watched, which matters because high water changes access to the compressor. [[Glaelbrath scale study]] holds my thoughts on measuring and comparing readings, and I borrowed its habit of writing the unit next to every figure. [[Staga Virork]] is the person I check ideas with when something about the setup puzzles me.

## Tools

These are the tools I actually use on the Karkkiork. I keep them together in one canvas roll so I can pick it up and go.

**Hand tools**

- An adjustable spanner and a fixed spanner set that fits the tank fittings.
- A flat screwdriver and a cross-head screwdriver for the panel cover and the filter housing.
- A small hex key set, since the mounting bolts use hex heads.
- Pliers with a wire cutter, for clamps and cable ties.
- A stiff brush for removing dried mud and leaf litter from the cooling fins.

**Measuring and checking**

- A separate pressure gauge that I trust more than the built-in one. I compare the two each season and note any gap in the log.
- A multimeter for checking the solar panel output and the battery buffer. I take it out in full sun and again in shade, then write both readings down.
- A spirit level, because the unit slowly settles on the soft ground and a tilt affects the oil level reading.
- A torch with a head strap, since the shed side of the pond is dark in the afternoon.

**For draining and cleaning**

- A shallow tray to catch the water that comes out of the tank drain.
- A funnel for oil.
- A small hand pump to clear the drain line.
- A bucket and a soft cloth.

**How I use the tools in order**

First I level the unit and check the gauge. Then I drain the tank, look at the water colour, and wipe the area down. Next I check the intake filter and the oil. Last I look over the wiring and the panel. I follow the same order each time so I never skip a step. If I find something odd, I stop and write it in the log before touching anything else.

The idea of a fixed routine came partly from my radio notes. [[Girdael radio receiver]] and [[Triorkgend radio receiver plan]] both rely on a strict check order, and I copied that approach here. It works for compressed air as well as for radio.

## Risks

Compressed air is not harmless, and the Karkkiork sits in a place where small mistakes become bigger ones. These are the risks I keep in mind.

**Pressure**

- A tank under pressure can fail violently if it is rusted or damaged. I check the outside of the tank for flaking paint and weeping seams each season.
- I never loosen a fitting while the tank is full. I vent first, then undo.
- I never raise the pressure setting above what the maker intended. The safety valve must stay free to move, and I test it by hand with the tank holding air and my face turned away.

**Air jets**

- A jet of air can throw grit into the eyes. I wear eye protection every time.
- I do not point the nozzle at skin or at anyone nearby.
- I keep the noise in mind. The release of air is loud, so I use ear protection for longer jobs.

**Electrical and solar**

- The solar wiring can be live even when the compressor is idle, because the panel makes power whenever there is light. I cover or disconnect the panel before working on the wiring.
- Wet hands and damp cables are a poor mix. Near the pond everything is damp, so I dry my hands and the connectors first.
- I check that cable insulation has not cracked in the sun.

**Water and the pond**

- The ground near the water is soft and can be slippery. I wear boots with grip and take care when the bank is wet.
- I do not work there alone in bad weather or after dark.
- Oil must never reach the pond. I use the tray for every drain and carry the used oil away in a sealed container.

**Cider contamination**

Because the machine serves the cider area, oil carried in the air could taint the product. I keep the air line away from open cider, I drain water and oil regularly, and I clean fittings with the food-safe cleaner before use. If I suspect oil in the line, I stop and flush it before going near any cider.

**Corrosion and neglect**

Damp air and a year of sitting idle do the most harm. Rust inside the tank is the quiet danger, because it cannot be seen. A regular drain is the best defence I have. If the water comes out brown, I take that as a warning and look more closely at the tank before the next use.

## Lessons

The Karkkiork air compressor is a grey, solar-powered unit that has stood by the pond since 2016. Most of what I know about it came from getting things wrong in the first few seasons. These are the lessons I would hand to anyone taking over the job.

**Treat the sun as the schedule.** The compressor runs on solar energy, so it does not care what I want to do at six in the evening. It fills the tank when the panels are producing, and I plan around that. Anything that needs a lot of air, such as cleaning lines or pushing air through the cider rack fittings, goes into the middle of a bright day. When I tried to do the same work on an overcast morning, the tank pressure dropped faster than the compressor could recover and I had to stop halfway.

**The pond location is both a gift and a nuisance.** Being at the pond means the air is cool and the compressor rarely overheats. It also means damp air, mud on the ground around the base, and insects in late summer. I learned to keep the intake clear and to never leave the drain valve closed for long. The water that collects in the tank is real, and it is more than I expected from something that sits outdoors in the open.

**Grey paint hides dirt and also hides leaks.** The unit is grey, and that is a nice, quiet colour beside the water. The downside is that a small oil weep or a rust bloom blends into the casing. I now wipe it down with a pale cloth once in a while, because the cloth shows what the paint does not.

**Do not rush the first start after a long rest.** After a cold, dark spell the compressor sits idle and the seals stiffen. If I force a full-pressure run right away, it complains with a rattle. Letting it come up slowly on a sunny morning has been kinder to it than any trick I tried.

**Write things down the same day.** My early notes were vague, like "ran fine" or "sounded odd". Now I record what I did, what the weather was like, and what the gauge showed. A vague note is almost useless a year later.

**Keep the cider work in mind.** The compressor exists to serve the cider side of the property. Whenever I am tempted to borrow it for something else, I check whether the cider work will need air later that day. It has never been worth leaving the cider short.

## Observations

These are the things I have noticed about the Karkkiork air compressor over the years since it was installed in 2016. They are not measurements. They are patterns I trust because I have seen them repeat.

### Behaviour through the year

In spring the compressor starts easily and the tank fills at a steady pace. The light is good, the air is cool, and I get long, even runs. Summer is the busiest period. The panels give plenty of power, but the heat around the pond makes the casing warm to the touch, so I give it short breaks during the afternoon.

Autumn is when the cider work peaks, and also when the days shorten. I notice the compressor refilling more slowly in the late afternoon. By then I have usually done the main air tasks, so it rarely matters, but it is a reminder not to leave jobs until the end of the day.

Winter is quiet. The solar supply is weak, and the compressor spends most of its time resting. On the few clear, cold days it will run, but I keep demands small. Condensation is the main worry in cold weather, so I drain it more often.

### Sound and feel

A healthy run has an even, low hum with a regular rhythm. The first sign of trouble is almost always a change in rhythm: a stutter, a longer gap between cycles, or a higher pitch. I have learned to stop and look when I hear that instead of hoping it passes. Vibration through the base is another clue. If the unit shakes more than usual, a mounting bolt has usually loosened on the platform beside the pond.

### The pond

The pond affects the compressor in small ways.

- Morning mist leaves a film on the grey casing, which dries by midday.
- Leaves and seeds drift toward the intake in autumn.
- Frogs and insects sometimes shelter under the housing in warm weather, so I look before I reach in.
- The ground softens after heavy rain, and the platform can settle slightly if I ignore it.

None of this is dramatic, but it adds up to a routine of looking around the unit every time I visit.

### Solar behaviour

Because the energy source is solar, the compressor does not run all day at a constant pace. On bright days the power comes in strongly and the tank fills quickly. When a cloud passes, the motor slows, and I can hear it. It does not seem to mind, which is one of the things I like about the arrangement. It simply takes what the sun gives it.

I have never found the solar supply to be a reliable reason for a fault. When something goes wrong, it has almost always been a mechanical matter, such as a valve, a fitting or moisture.

### Overall impression

After this many years, I would call it dependable but not forgiving of neglect. It will keep going for a long time if I treat it with small regular attention, and it will tell me early if I am letting something slide.

## Costs

I am not recording exact prices here, because they change and because I would rather not copy numbers I cannot confirm. What I can do is describe the shape of the costs, which has been steady and easy to understand.

### Buying and installing

The largest cost was the start. The compressor itself, the solar supply and the work of setting it up at the pond all had to be paid for in 2016. The solar side was the part I thought about most, since it replaced any ongoing power bill. Having paid once, I do not receive a monthly charge for running it, and that was the point of the choice.

Preparing the ground by the pond was a smaller cost than I expected, but it was not nothing. A firm, level base mattered more than I had assumed, and doing it properly at the beginning has saved me from repairs later.

### Running costs

Running costs are close to zero in the usual sense, because the sun supplies the energy. The real running costs are small consumables and my own time:

- Oil or lubricant when the unit calls for it.
- Filters for the intake, which clog faster near the pond in autumn.
- Replacement seals and fittings when they wear.
- Cloths, a brush and a drain container for routine care.

My time is the biggest running cost, and I count it honestly. A short look every visit and a longer service a few times a year is about right.

### Costs that surprised me

Two things cost more than I planned. First, moisture damage: the first year I was careless about draining the tank, and a corroded fitting needed to be replaced. Second, protecting the panels and wiring from damp and from small animals took a little extra material. Both were cheap compared with a major failure, but I would budget for them from the start.

### What I would do differently

If I were starting again, I would set aside a small reserve for spares, keep a spare intake filter on the shelf, and spend a little more on weather protection at the beginning. I would not change the decision to use solar energy. Over the years it has been the most economical part of the whole arrangement.

## Maintenance

This is the routine I follow for the grey Karkkiork air compressor at the pond. I keep it simple so I will actually do it.

### Every visit

1. Walk around the unit and look for new marks, drips, rust or loose items.
2. Listen to a short run and check that the rhythm is even.
3. Open the drain valve and let any water out of the tank, then close it again.
4. Check the intake for leaves, seeds and insects, and clear it by hand.
5. Glance at the gauge to confirm the pressure rises steadily.

### Every month or so

- Wipe the casing with a pale cloth. Because the unit is grey, a pale cloth shows oil and rust clearly.
- Check the mounting bolts on the platform and tighten any that have loosened.
- Look over the hoses and fittings for cracks or soft spots.
- Inspect the solar wiring and connections for damp, corrosion or chewed insulation.
- Clean the panels so that dust and pollen do not reduce the power.

### Each season

At the change of each season I do a longer service. I check the lubricant level, replace the intake filter if it looks dirty, and test the safety valve to make sure it opens and reseats cleanly. I also check the ground around the base, because the pond edge can shift after wet weather.

Before autumn, when the cider work is heaviest, I do the most thorough check of the year. I want the compressor ready for the busy weeks, since a fault then would cost me far more than a delay in spring.

Before winter, I drain the tank fully, protect exposed fittings, and cover the vulnerable parts. I leave the unit in a dry state, because water sitting through cold weather is the quickest way to cause damage.

### Signs to act on straight away

- A change in the sound of the motor, such as a stutter or a higher pitch.
- Pressure that falls quickly when the compressor is idle, which suggests a leak.
- Oil on the casing or the ground below.
- Heavy vibration through the base.
- Water that keeps coming out of the drain long after it should have stopped.

If I see any of these, I stop using the compressor, find the cause, and write it down before I start again.

### Record keeping

After each service I note what I did and what I found. I record the season, the weather and anything unusual. These notes have helped me spot slow changes, such as filters clogging earlier each year, and they stop me from repeating old mistakes. Since 2016, that habit has done as much for the compressor as any tool or part.

## Ideas

These are the ideas I keep coming back to when I think about the Karkkiork air compressor. It is a grey air compressor that has been installed at the pond since 2016, and it runs on solar energy. It serves the cider area, so every idea below is judged by one question: does it help the cider work go smoother?

**Use the sun's schedule instead of fighting it.** The compressor is solar, so the best work happens when the light is strong. I try to plan the jobs that need the most air for the brightest part of the day. Rinsing, blowing out lines and filling the buffer tank all go in that window. Anything that can wait until the next sunny spell waits.

**Treat the tank as a battery.** Because the energy source is solar, the air tank is the real storage. A full tank at the end of a sunny afternoon means I can do small jobs the next morning without waiting for the sun to climb. I think of the tank pressure the way other people think of a charge gauge.

**Keep the cider area's needs written down.** The compressor exists for the cider area, so I keep a short list of the tasks that actually use air:

- Moving liquid between vessels gently, with low pressure.
- Cleaning and drying hoses and fittings after a batch.
- Running small pneumatic tools in the pressing shed.
- Clearing debris from the pressing area and the crates.

If a new job is not on this list, I stop and ask whether it really belongs on this machine.

**Respect the pond.** The unit sits at the pond, which is lovely for the view and hard on equipment. Moisture is the constant enemy. Damp air gets into the intake, and condensation forms inside the tank. Most of my maintenance ideas come down to keeping water out of places where it should not be.

**Make the grey unit easy to spot and easy to read.** The color is grey, and in the evening light by the water it nearly disappears into the stones and the shade. I have thought about adding a bright tag or a strip of reflective tape near the gauge and the drain valve, so that I can find the controls quickly at dusk. The body stays grey; only the tags change.

**Plan for the long life of the machine.** It has been in place since 2016, so many of the original choices are old. Hoses harden, seals dry out and panel mounts loosen. I would rather replace a small part early than discover a failure in the middle of a pressing day. A yearly walk-around with a notebook is the cheapest way to do that.

**Keep noise and vibration in mind.** Even a quiet compressor moves a little when it runs. At the pond the ground can be soft, so I check whether the base has shifted. A small shift can turn into a loose fitting or a cracked line over time.

**Write the odd behaviours down.** Every machine develops habits. This one might take longer to build pressure on cloudy days, or the gauge might stick slightly when it is cold. I record these things in my daily notes and then copy the useful ones into this handbook. A habit that is written down stops being a mystery.

**Keep spares simple.** I would rather hold a few generic spares that I understand than a large pile of parts I never touch. The list is short: a spare hose, a few clamps, thread tape, a drain valve and a couple of clean cloths. Anything more specialized gets ordered when the need is clear.

## Setup

This section describes how the compressor is arranged and how I bring it into use. The basic facts come first, so they are in one place.

**Properties at a glance**

- Name: Karkkiork air compressor
- Kind: air compressor
- Area: cider
- Color: grey
- Energy source: solar
- Year installed: 2016
- Location: pond

**Where it sits.** The unit is at the pond. I keep the area around it clear on all sides so air can move and so I can reach every valve. Grass and reeds grow quickly here, and I trim them back whenever I pass. Nothing should lean on the casing, and nothing should block the intake.

**How it is powered.** The energy source is solar. The panels collect light during the day and feed the compressor. There is no mains backup in my notes, so the machine depends on the weather. On a dark day I expect slower pressure build-up and I plan lighter work. I check the panel surface regularly, because dust, pollen, leaves and bird droppings all reduce what it can collect.

**Base and mounting.** The compressor stands on a firm, level base. I look at it for three things: that it is level, that it is dry, and that it is not sinking. Because the ground near water can move, a quick look at the feet and the mounting bolts is part of every season's check.

**Air path.** The path runs from the intake, through the pump, into the tank, and then out through the regulator to the hose. I keep this order in mind when something goes wrong, because it tells me where to look first. A weak flow at the hose could be a blocked intake, a leaking line, a tired pump or a regulator set too low. Working through the path in order saves time.

**Water control.** The tank collects condensation, especially in damp weather. A drain valve at the lowest point lets it out. I open it slowly at the end of a working day, let the water run until only air comes out, and close it again. At a pond, this step matters more than almost anything else.

**Hoses and fittings.** I keep the hoses coiled loosely and off the wet ground. Before each use I run a hand along them and feel for cracks, soft spots and bulges. Fittings should push in firmly and hold. If one hisses, I fix it right away instead of living with the leak, because a small leak keeps the solar unit working harder than it needs to.

**Regulator and gauge.** For cider work I usually want gentle, steady pressure. I set the regulator low for moving liquid and raise it only for cleaning or tools. The gauge is checked against how the machine behaves: if the needle says full but the tools feel weak, something between the tank and the tool is wrong.

**Starting up for the day**

1. Walk around the unit and look for anything unusual, such as new damp patches, loose parts or animal nests.
2. Wipe the panel if it is dirty.
3. Check that the drain valve is closed.
4. Look at the tank gauge and note where it starts.
5. Connect the hose and make sure the regulator is set low.
6. Wait for the pressure to build, and listen for odd sounds.

**Shutting down for the day**

1. Release pressure from the hose line.
2. Open the drain valve slowly and let the water out.
3. Close the valve once only dry air comes out.
4. Coil the hose and keep it off the wet ground.
5. Make a short note of anything strange.

**Weather notes.** In rain I keep the connections covered and avoid heavy use. In frost I drain the tank carefully, because trapped water can freeze and damage the valve. In strong sun I make sure the unit is not boxed in, since heat can build up around the grey casing.

## Checklist

I use this list for regular checks. I do not try to do everything at once; I split it into daily, seasonal and yearly rhythms.

**Before each use**

- [ ] The area around the compressor is clear.
- [ ] The solar panel surface is clean enough.
- [ ] The drain valve is closed.
- [ ] Hoses show no cracks, bulges or soft patches.
- [ ] Fittings are tight and not hissing.
- [ ] The regulator is set low to begin with.
- [ ] The tank gauge reads sensibly.

**After each use**

- [ ] Pressure released from the hose.
- [ ] Tank drained of water.
- [ ] Hose coiled and kept dry.
- [ ] Tools put back in the cider area.
- [ ] Odd behaviour noted in the daily log.

**Each season**

- [ ] Check the base for level and firmness.
- [ ] Check the mounting bolts and the panel brackets.
- [ ] Inspect the intake for dust, webs and nests.
- [ ] Look over the cables for chafing, damp and animal damage.
- [ ] Test the drain valve for smooth action.
- [ ] Review how quickly the tank fills on a sunny day and compare it with earlier notes.
- [ ] Clear reeds and grass from around the unit at the pond.

**Each year**

- [ ] Replace any hose that looks tired.
- [ ] Replace worn clamps and thread tape.
- [ ] Check the casing for rust and touch up the grey paint where needed.
- [ ] Review the whole air path from intake to hose for leaks, using soapy water on the joints.
- [ ] Re-read this handbook and correct anything that has changed.
- [ ] Update the spares list.

**When something seems wrong**

- [ ] Is the sun strong enough for the panel to do its work?
- [ ] Is the intake blocked?
- [ ] Is there a leak anywhere along the line?
- [ ] Is the tank full of water?
- [ ] Is the regulator set where I think it is?
- [ ] Has the base moved?

If the answer to all of these is no and the problem remains, I stop using the machine for the day and look at it again in good light, with a clear head and the notes in front of me.

**A short rule set**

- Drain the water every time.
- Keep the panel clean.
- Fix small leaks early.
- Plan heavy jobs for bright hours.
- Write down anything odd.

## References

These are the sources I use for this handbook. They are all my own notes and records, since the Karkkiork air compressor is a personal piece of equipment and I do not rely on outside pages.

- **Installation record.** My note from 2016, when the compressor was installed at the pond. It lists the original layout of the base, the panels and the first hose run.
- **Daily log.** The running notes where I record odd sounds, slow pressure build-up, weather and anything that happened at the pond. Most of the habits in the Ideas section came from here.
- **Cider area task list.** My list of jobs in the cider area that use compressed air. I check it whenever I am tempted to give the machine a new task.
- **Seasonal maintenance notes.** The notes I write after each seasonal check, including what I replaced and what I postponed.
- **Spares list.** A short note of the hoses, clamps, tape, drain valve and cloths that I keep on hand.
- **Weather and light observations.** Informal notes on how the solar supply behaves in different weather, which I use to plan heavy jobs.
- **Pond-side hazards note.** A reminder of what the damp, the reeds and the soft ground can do to equipment and to my own footing.

When any of these records changes, I update this handbook, not the other way around. The properties of the subject stay fixed unless the machine itself changes: it is a grey air compressor, powered by solar energy, installed in 2016 at the pond, and used for the cider area.

## History

The Karkkiork air compressor is a grey air compressor that has served the cider work since it was installed in 2016. It sits by the pond, in a small lean-to built against the stone wall on the pond side of the press yard. I wrote this section so I remember why it ended up there, because the reasons are not obvious when you look at the place today.

Before 2016 we had no compressed air at all. Moving cider between vessels meant lifting, tipping and a lot of hose work, and cleaning the lines meant carrying buckets uphill. The idea of a compressor came from wanting gentle pressure to push juice through the lines, to blow out the filters, and to run the small pneumatic tools in the pressing shed. Mains power was never reliable out at the pond end of the property, and running a cable there would have cost more than the machine. That settled the energy question. The compressor runs on solar power, and the panels sit on the roof of the lean-to facing the open water.

The location by the pond was partly practical and partly accidental. The pond gives a flat, open spot with good sun and no tall trees to the south. It also gives cool air in the morning, which helps the motor in summer. The downside is damp, and I come back to that in the safety and schedule sections. The first season showed that the damp air produced a lot of condensation in the tank, so draining became a fixed habit very early on.

In the first years I treated the machine as an experiment. I ran it only on bright days and only for short jobs. By the second season I trusted it enough to plan the pressing and transfer days around the weather. Cloudy stretches in autumn were the main problem, since that is exactly when the cider work is busiest. I solved this by filling the tank fully on sunny days and keeping the transfer work to what the stored air could carry.

Over time the machine picked up small changes, none of which changed its basic character:

- A better cover over the intake, to keep out leaves and wasps.
- A longer drain hose, so condensate runs away from the wall.
- A rubber mat under the feet, to reduce vibration on the slab.
- A hand-written tag on the tank with the draining routine.

The grey paint is the original colour. It has faded a little near the top where the sun hits it, but the tank itself has stayed sound. I mention the colour here because it is handy when describing the machine to a helper: it is the grey one at the pond, not the other equipment in the shed.

## Safety

Compressed air stores a lot of energy, and a tank is a pressure vessel. I treat the Karkkiork air compressor with respect even though it is a modest machine. These are the rules I follow and expect anyone helping me to follow.

**Before starting work**

- Look over the tank, hoses and fittings for rust, cracks, kinks or weeping joints. If I see anything doubtful, I do not run the machine.
- Check that the lean-to is dry underfoot. Being by the pond means the slab can be wet, and wet ground near electrical gear is a risk even on a low-voltage solar system.
- Make sure the panels are clean and nothing is shading them. A starved motor that keeps trying to start runs hot.
- Confirm that the pressure relief valve moves freely. I lift the ring briefly now and then to hear it release and reseat. If it sticks or leaks afterward, the machine stays off until it is fixed.

**While running**

- Never point an air jet at skin, eyes or anyone else. Air forced through skin can cause serious injury even without a visible wound.
- Wear eye protection whenever I blow out filters or clean equipment, because grit and cider residue fly back.
- Keep hands and clothing clear of the belt and fan covers. The guards must stay in place.
- Do not adjust the regulator beyond what the attached tool needs. Higher pressure does not make cider move better; it only strains the fittings and the vessels it is pushing into.
- Never use compressed air to pressurise a cider vessel that is not rated for it. Old wooden casks and thin plastic containers can fail. I only use air with equipment I know can take it, and I keep the pressure low and steady.

**Condensate and corrosion**

Water collects in the bottom of the tank, and the damp pond air makes it worse. Left alone, it rusts the tank from the inside, and that is the most likely way for this machine to become dangerous. I drain it after each working session and again at the start of a long season. When I drain, I release the pressure to a low level first, open the valve slowly, and stand to the side.

**Solar power cautions**

Because the machine runs on solar power, it can start by itself when the sun comes out. I always switch it to off and isolate it before touching anything mechanical. I do not trust that it is idle just because it is quiet.

**Shutdown and storage**

At the end of the season I drain the tank fully, leave the valve open so air can circulate, and cover the intake. I also keep the area around the compressor clear of old pomace, dry leaves and anything that could burn or attract pests. If I ever have to leave a job part-finished, I vent the line before walking away.

**If something goes wrong**

If I hear a hiss that is not normal, smell hot insulation, or see the tank bulge or leak, I switch the machine off, stay clear, and let it cool and vent before inspecting. I do not weld, drill or patch the tank. A damaged tank is replaced.

## Schedule

This is the routine I keep for the Karkkiork air compressor. It is built around the cider calendar, because that decides when the machine works hardest, and around its place at the pond, because damp and sun both affect it. I keep it deliberately simple so that I actually do it.

**After every session**

- Switch off and isolate the machine.
- Release pressure to a low level and drain condensate from the tank.
- Wipe down the exterior, especially the fittings and the base.
- Coil the hoses loosely and hang them off the ground.

**Weekly while in heavy use**

During pressing and transfer weeks I add a few checks:

- Look at the intake cover and clear leaves, insects and dust.
- Listen for changes in the motor sound or any rattle from the mounts.
- Check the hose ends and quick couplers for wear.
- Test that the pressure relief valve lifts and reseats cleanly.
- Wipe the solar panels if there is pollen, bird droppings or fallen fruit residue.

**Monthly through the working season**

- Inspect the belt or drive for wear and correct tension.
- Look under the tank and around the welds for rust spots, and touch up the grey paint where it has chipped.
- Check the wiring and connectors from the panels for loose terminals or moisture.
- Check the rubber feet and the mat, since vibration can walk the machine slowly across the slab.

**Start of the season (late summer)**

Before the apples arrive, I do a fuller service. I drain the tank, open the machine up, clean the intake and any filters, and run it for a short test on a sunny day. I confirm that it fills, holds pressure, and shuts off as it should. I also review the lean-to roof and the panel mounting, since storms over winter sometimes loosen things. This is the time to replace worn hoses and couplers rather than during the rush.

**End of the season (after the last racking)**

- Drain the tank completely and leave the valve open.
- Clean everything and dry it thoroughly.
- Cover the intake and the exposed fittings.
- Disconnect the load and note any faults for next year.
- Check the pond-side drainage so winter water does not pool around the base.

**Yearly review**

Once a year, in the quiet months, I read through these notes and update them. I look at what failed, what I skipped, and whether the sun-driven filling matched the cider work. If the machine has begun to struggle on cloudy days, I consider adding panel capacity or storing more air before the busy stretch. I also decide whether any part is old enough to replace before it fails.

**Rule of thumb**

If I am short of time, the two things I never skip are draining the tank and checking the relief valve. Everything else can slip a little, but those two protect the machine and the people near it.

## Background

This section collects the plain facts about the Karkkiork air compressor, so that I can find them quickly without reading the rest of the note.

**Summary of properties**

- Kind: air compressor
- Area: cider
- Color: grey
- Energy source: solar
- Year installed: 2016
- Location: pond

**What it does for the cider work**

The compressor provides a steady supply of compressed air for a handful of jobs around the cider operation. Its main use is moving liquid gently through lines where I would otherwise lift and pour. It also blows water and debris out of filters and fittings, helps dry equipment after washing, and powers small air tools in the pressing shed. None of these jobs needs high pressure, which is why a small solar-driven machine has been enough.

**Why solar suited this site**

The pond end of the property is far from the main supply, and the open water gives a clear southern aspect. A solar machine avoids a long cable run, avoids fuel, and is quiet, which matters when I am working in a calm orchard setting. The cost is that the machine depends on the weather. It works best in the long bright days of late summer and early autumn, when the apples are ripening, and it is weakest in the dull weeks that sometimes follow. Storing air in the tank on good days is the main way I smooth that out.

**How the place affects the machine**

Being at the pond brings both benefits and difficulties. The cool morning air and open sun are good for the motor and the panels. The damp is the enemy. It produces condensation inside the tank, encourages rust on the outside, and can creep into electrical connections. Much of the routine in this note exists because of that single fact. Birds, insects and falling leaves also gather around the lean-to, so keeping the intake and panels clear is a regular chore.

**How it fits with the other equipment**

The compressor is one of several machines in the cider area, and it is the only one that works away from the press yard. Everything else is within a short walk of the pressing shed. When I need air at the shed, I run a long hose from the lean-to, and I keep that hose off the ground to protect it from mud and cider residue. The grey casing makes the compressor easy to pick out against the dark stone of the wall.

**Things I would do differently**

If I were setting it up again, I would raise the base a little more, to keep it clear of splashes, and I would add a proper water trap on the outlet. I would also size the panels with a bit more margin for the dull weeks. These are small changes, and the original choice of a solar machine at the pond has held up well since 2016.

**Keeping the notes useful**

I keep this handbook short on purpose and update it whenever I change something on the machine. If I replace a part or alter the layout, I write a line here the same day, because I will not remember the reason a year later.

## Parts

This section lists the parts of the Karkkiork air compressor as I know them. The machine is a grey air compressor installed in 2016 beside the pond, and it serves the cider area. It runs on solar energy. The part number I use when I order or look up the compressor itself is TW-5847-K. I wrote it on the inside of the cabinet door, and I keep it here as well, so I do not have to climb down to the pond just to read it.

I describe the parts in the order that air and power travel through the machine: from the sun, to the electric side, to the pump, to the tank, and finally out to the hose.

### Solar side

The compressor takes its energy from the sun, and there is no mains connection. The solar side is the first thing I check when the machine behaves oddly.

- **Solar panel.** It sits on a short frame on the bank, facing the open part of the sky over the pond. The glass collects dust, pollen and bird droppings, and in autumn also wet leaves. I wipe it with a soft cloth and plain water. I never use anything sharp on it.
- **Panel cable.** A single run of cable goes from the panel to the cabinet. It passes through a plastic conduit so the frost and the sun do not wear on it. I check the conduit each spring for cracks.
- **Charge controller.** This small box sits inside the cabinet. It protects the battery from being overcharged and from running too low. If the compressor stops early in the evening, I look here first.
- **Battery.** The battery stores the sun's energy so the compressor can run on dull days and a little after sunset. It is the part that ages fastest. A tired battery shows itself as a compressor that starts well in the morning and gives up after a short job.

### Electric side

- **Motor.** The motor turns the pump. It is a plain electric motor and it is the heaviest single item in the cabinet. It gets warm during long jobs, and I leave space around it so that air can move.
- **Pressure switch.** This switch starts the motor when the tank pressure falls and stops it when the pressure is high enough. It has a small lever on top. If the motor never stops, or starts and stops every few seconds, the switch is the first suspect after the tank is checked for leaks.
- **Wiring and fuse holder.** The wires inside are short and tied back with clips. The fuse holder is near the battery. I keep a spare fuse in a small tin in the cabinet.
- **Main switch.** This switch is on the outside of the cabinet, so I can turn the machine off without opening anything. I turn it off whenever I work on the hose side.

### Pump side

- **Pump head.** The pump head compresses the air. It has cooling fins on the outside, and these must stay clean. I brush the dust from the fins with a dry brush, and I do this with the machine off.
- **Intake filter.** Air enters the pump through this filter. The pond area is damp and has a lot of insects in summer and fine dust near the path, so the filter clogs faster than I expected. I look at it each month in the working season. A blocked filter makes the pump slow and the motor hot.
- **Drive belt or coupling.** The motor drives the pump through a simple link. I listen to it for squeaks and I look for any rubbing. When the link is loose, the pump runs behind the motor and the pressure builds slowly.
- **Oil level window.** If the pump is the kind that needs oil, the window on its side shows the level. I keep the oil between the two marks. I do not mix different oils.

### Tank and air side

- **Air tank.** The tank holds the compressed air. It is grey like the rest of the machine, and it sits low in the cabinet on rubber feet. Pressure builds in it and the tank is the part I respect most. I never drill it, weld it or paint over any stamped marking on it.
- **Drain valve.** At the bottom of the tank is a small valve. Water collects there because the air near the pond is damp. I open the valve after each working day, and let the water and the pressure out slowly. Rust inside the tank is the main long-term risk, and regular draining is the best defence I know.
- **Safety valve.** This valve opens by itself if the pressure goes too high. I test it only by pulling its ring gently, and only a few times a year. I never block it or change its setting.
- **Check valve.** The check valve sits between the pump and the tank. It keeps the air in the tank when the pump stops. If air hisses back out of the pump after it stops, this valve is worn or dirty.
- **Pressure gauge.** There are two gauges. One shows the tank pressure and the other shows the pressure going out to the hose. I look at both before I begin any job.
- **Regulator.** The regulator lets me set the pressure that goes out to the tools. For the cider work I set it low and raise it only if the job needs it.

### Hose and fittings

- **Hose.** The hose runs from the cabinet along the path to the cider area. It is coiled on a hook when not in use. Sun and cold make it stiff, so I check it for cracks and for soft spots.
- **Quick couplings.** These let me change tools without turning off the air. The rubber rings inside them wear out, and a leaking coupling wastes a lot of stored energy. I put a drop of oil on them now and then.
- **Air filter and water trap.** Close to the end of the hose I keep a small filter that catches water and fine particles. This matters for the cider work, since I do not want oil mist or rust flakes near anything that touches the juice or the barrels.
- **Tool fittings.** I keep a few spare fittings in the cabinet. They are easy to lose in the grass beside the pond.

### Housing

- **Cabinet.** The cabinet is grey, with a hinged door and a lock. It keeps rain and sun off the machine. Small vents in the sides let air in, and I cover them with fine mesh to keep the insects out.
- **Rubber feet and base.** The cabinet stands on a firm base. Rubber feet cut down vibration. I check them each year, because the ground by the pond can settle.
- **Label plate.** The label plate is fixed near the tank. It carries the maker's marks. I keep the part number TW-5847-K in my own notes and on the door, because the plate is hard to read once it is dirty.

### Spares I keep

I keep a small box of spares so that a minor fault does not stop the cider work.

- A spare fuse and a spare set of hose clips.
- A clean intake filter.
- A few rubber rings for the quick couplings.
- A short length of spare hose with fittings on both ends.
- A soft cloth and a dry brush for the panel and the pump fins.

### Wear and what to check

The parts that wear first are the battery, the intake filter, the coupling rings and the hose. The parts that last longest are the tank, the cabinet and the panel frame. Every spring I go through the list from the sun to the hose, in the same order as above, and I note any part that looks tired. Doing it in the same order each time means I do not skip anything. Since the compressor has been in place since 2016, I treat everything that moves or that is made of rubber as something that may need replacing soon, and I replace it before it fails, not after.
