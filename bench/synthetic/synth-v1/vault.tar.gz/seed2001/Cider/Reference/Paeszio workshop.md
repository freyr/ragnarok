---
type: reference
status: active
project: reference
area: cider
description: "Reference about Paeszio workshop."
---

# Paeszio workshop

## Costs

The Paeszio workshop is a large workshop, built in 1992, on the ground level, with its main orientation facing north. It is a cider workshop, and the costs below are the ones I keep track of for it. I do not write exact prices here, only the kind of cost and how it behaves over the year.

The biggest ongoing cost is heating and cooling. Because the building faces north, it gets little direct sun, so it stays cool in summer and is slow to warm in winter. That helps with storing cider but costs more when I need warmth for a batch that has stalled.

| Cost item | Type | How it behaves | Notes |
|---|---|---|---|
| Heating | Recurring | Higher in winter | North side stays cold |
| Electricity | Recurring | Rises in pressing season | Pumps, lights, controller |
| Cleaning agents | Recurring | Steady | Bought in bulk |
| Repairs to the 1992 structure | Occasional | Unpredictable | Mostly roof and drains |
| Replacement tools | Occasional | Low | Handles and blades wear first |
| Containers and bottles | Seasonal | Peaks at bottling | Reuse where possible |

Costs I should watch more closely: the building is old, so repairs are the item most likely to surprise me. The large floor area also means that lighting and heating add up quickly if I leave them on while working in only one corner. Keeping the work grouped in one zone at a time saves a noticeable amount.

Because the workshop sits on the ground level, I do not pay for lifting or carrying between floors, and heavy loads go straight in from the yard. That is a real saving compared with a loft space, and it is one reason I keep the heavy work here and the light storage elsewhere (see [[Narkmin loft log]] for the upstairs side).

## References

These are the notes and sources I go back to when I work in the Paeszio workshop.

- [[Rundtru circulation pump tests]]: my results from running the circulation pump, useful when I need to remember how long a transfer takes and what the pump does under load.
- [[Narkmin loft log]]: the log for the loft, where I keep things that should not sit on the cold ground floor.
- [[Vaebio kiln controller]]: the device note for the controller installed here, with settings and quirks.

Basic facts about the place, kept in one spot so I do not need to search:

- Kind: workshop
- Area: cider (also in the frontmatter)
- Orientation: north
- Size: large
- Year built: 1992
- Floor: ground level

When something in the workshop changes, such as a new device or a layout change, I update this section first and then fix the other sections. The references are the part I trust most, because they are written close to when the work happened.

## Supplies

Supplies are what gets used up. I keep them on shelves along the inner wall, away from the cold outer wall on the north side, so that nothing freezes or gets damp.

Core supplies for cider work:

- Apples, sorted by variety and ripeness, kept in crates off the floor
- Yeast and nutrients, stored cool and sealed
- Sanitizer and cleaning powder
- Cloths, brushes, and sponges
- Bottles, caps, and corks
- Labels and marker pens
- Filter cloths and straining bags
- Spare tubing and clamps

Habits that have worked for me:

1. Check stock at the start of each season, not in the middle of pressing.
2. Buy cleaning supplies and caps in larger amounts, since the workshop is large and I use plenty.
3. Keep a small box of emergency items near the door: tape, a few clamps, and spare gaskets.
4. Throw out anything that has been opened and left for a long time, especially yeast.

Since the ground-level floor is easy to reach from the yard, deliveries of crates and bottles come straight in. I stack them by use rather than by type, so what I need first sits closest to the door.

## Tools

Tools stay in the workshop all year. Most are simple, and I prefer simple ones because they are easy to clean and repair.

Main tools:

- Apple mill or crusher
- Press with cloths and racks
- Fermentation vessels and airlocks
- Siphon and food-safe tubing
- Hydrometer and a measuring jug
- Funnels in a few sizes
- Bottle brush and bottle filler
- Capping tool
- Knives, buckets, and scoops

Care routine: rinse right after use, dry well, and hang or stand upright. The north orientation means the room is cool and a little damp in autumn, so metal parts can rust if left wet. A light coat of food-safe oil on exposed steel helps.

Where things live: the heavy tools, such as the mill and press, stay near the large door because they are awkward to move. Small tools go in a drawer unit by the sink. I keep a short list taped inside the drawer so I notice when something goes missing.

For transfers, I rely on the pump setup described in [[Rundtru circulation pump tests]]. It saves my back on large batches, and the notes there tell me what to expect.

## Ideas

A list of things I would like to try or improve. None are decided.

- Add a simple curtain or insulated door on the north side to cut drafts.
- Mark floor zones with tape: pressing, fermenting, bottling, and cleaning. The large size makes this worthwhile.
- Put shelves higher on the inner wall to free floor space.
- Build a small warm corner, for starting yeast or for batches that need a gentle lift in temperature.
- Keep a clipboard by the door with a running list of things to buy.
- Test a better drain cover, since the building dates from 1992 and drains are one of the weak points.
- Move rarely used supplies to the loft and record them in [[Narkmin loft log]].
- Write a short checklist for closing the workshop at the end of the day.

If I do only two of these, I would choose the floor zones and the warm corner. They cost little and would change how the space feels to work in.

## Equipment

Equipment here means the fixed or semi-fixed items that support the work, as opposed to the hand tools above.

Installed device: Vaebio kiln controller. It is the one installed device in the Paeszio workshop. The details of its settings and behavior are in [[Vaebio kiln controller]], so I do not repeat them here.

Other equipment in the workshop:

- Circulation pump for moving liquid between vessels (tests in [[Rundtru circulation pump tests]])
- Large sink with a hose connection
- Work benches, sturdy enough for crates
- Shelving along the inner wall
- Lighting over the main work zones
- Drain in the floor, easy to reach on the ground level

Notes on use: the controller is the piece I check first when I arrive on a cold morning, because the north-facing room can lag behind the weather outside. I keep the area around it clear and dry. If anything about it seems off, I write it in its own note rather than here, so this section stays a short inventory.

The workshop is large, so I treat equipment placement as part of the plan. Anything that needs power stays close to the sockets, and anything that gets wet stays close to the drain.
