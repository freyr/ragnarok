---
type: reference
status: archived
project: reference
area: cider
description: "Reference about Fakiosto valve actuator."
---

# Fakiosto valve actuator 2018

This note is archived. It records how things stood in 2018, and later notes replace the values here. The Fakiosto valve actuator is a valve actuator used in the cider area. It is yellow, runs on battery power, and sits in the loft. The year installed is recorded as 2023. That does not fit well with a note written in 2018, so I treat it as the value the record carries and do not try to reconcile it here.

## Open questions

- The recorded install year is 2023, but this note describes 2018. I never worked out which is right for the earlier period. A later note should settle it.
- How long does the battery last under normal use? I never kept a proper log, only loose impressions, so I cannot give a reliable figure.
- Does the loft get cold enough in winter to hurt the battery? I suspected it, but I never confirmed it.
- Is the yellow housing just a colour choice, or does it mean something in the maker's range? I assumed it was only a colour.
- Would a mains supply be easier than a battery in the loft? Running a cable up there looked awkward, so I never tested it.
- Can the actuator share any logic with the [[Drilvark kiln controller]]? I only looked at this on paper.

## Lessons

- Anything in the loft needs to be easy to reach. A battery device that needs a ladder gets neglected.
- Write down the battery change on the day you do it. Guessing later is useless.
- Keep the yellow housing visible and free of clutter. Yellow was easy to spot in a dim loft, which was handy.
- Test the valve by hand before trusting the actuator. A stiff valve makes a battery device look faulty when it is not.
- Do not assume a setting survives a battery swap. Check after each change.
- Comparing notes from other projects saved time. The [[Pebrurrind air compressor tests]] showed me how to structure a simple run log, and I reused that layout here.

## Problems

- The loft is awkward to get into, so checks were put off longer than they should have been.
- Battery power meant the actuator sometimes moved slowly when the charge was low. I noticed it more in cold weather.
- The valve stuck a little after long idle spells. The actuator coped, but it made a grinding sound.
- Dust built up on the yellow housing and hid the status light. I had to wipe it before reading anything.
- There was no clear record of when the battery was last changed, which made fault-finding a matter of guesswork.
- Some of the early readings I took were not labelled properly, so I cannot use them. The same thing happened during the [[Riothkren Niordio tests]], and I should have learned from that.

## Software

The firmware version of the Fakiosto valve actuator is v6.15.692.

Notes on how it behaved:

- The firmware kept its settings through normal operation, but I did not trust it after a battery swap.
- It had a basic open and close routine and little else. I never found a scheduling feature that I could rely on.
- Updating the firmware meant bringing the device down from the loft, so I avoided doing it. I stayed on the version above for the whole of 2018.
- I kept no separate log of changes. If a later note gives a different version, that note replaces this value.

## History

- The actuator belongs to the cider area, where it handles one valve on the loft side of the setup.
- It is yellow, which is why I called it the yellow actuator in my other notes.
- It runs on battery. That was the main reason I chose it, since there was no convenient power point nearby.
- The recorded year installed is 2023, and the location is the loft.
- In 2018 I used it in a limited way and mostly watched how it behaved.
- Around the same time I was reading about humidity control for the same space. See [[Triothkil dehumidifier notes]] and [[Riothdrer dehumidifier plan]] for that thread. The loft is damp, and damp is hard on a battery device.
- I also looked at the air supply side in [[Rindtrith air compressor]], mainly to see whether compressed air could move the valve instead. I decided against it because it was too much equipment for one valve.

## Ideas

- Fit a small cover over the actuator to keep dust off the yellow housing and the status light.
- Keep a spare battery in a labelled bag near the loft hatch, so a swap takes minutes.
- Stick a card next to the device with the battery change history, written in pencil.
- Look at whether a timer from the [[Drilvark kiln controller]] approach could drive the valve on a schedule.
- Move the humidity thinking forward. If the dehumidifier plan goes ahead, the loft may become dry enough that battery life improves.
- Try a simple weekly check routine, the same each time, and write the result in one line.
- If a later note replaces any value here, add a link back to this archived note so the old state stays traceable.
