---
type: reference
status: active
project: reference
area: cider
---

# Valgios workshop handbook

## Observations

These are my own notes on Valgios workshop, written down so I stop relying on memory. Everything here comes from time spent in the building, not from any plan or official document.

The workshop is a large building, and it feels large the moment you walk in. The main room is long, with plenty of clear space between the benches and the pressing area. Even with a full crew and several tubs out, nobody has to squeeze past anyone else. I noticed this most in the busy weeks, when other buildings I have worked in get crowded and tempers get short.

It faces east, and that shapes the day. Morning light comes straight in through the main doors and the high windows. By midday the room is evenly lit without being hot, and in the afternoon it falls into soft shade. The work area is for cider, so this suits me. Fruit and equipment stay cooler through the warm part of the day, and I rarely need lamps before the late afternoon.

The floor is raised. It sits well above the ground outside, with a gap underneath that lets air move. The raised floor does three things I have seen for myself:

- Water from washing down runs toward the drains and does not pool at the doors.
- The boards stay drier than a floor laid on the ground would.
- Loading is easier, because a cart can be brought level with the floor at the east doors.

The workshop was built in 2005. It has had small repairs since then, but the frame and layout are original. The timber has aged well. The places that show wear are the thresholds, the edges of the steps, and the boards in front of the main press, where people stand most.

Other things I have noticed over time:

- The building smells of apples and old wood, and it never fully loses that smell, even after a deep clean.
- Sound carries along the length of the main room, so a call from one end is easy to hear at the other. This helps with safety.
- The east doors are the main way in and out. The side door is used far less and tends to stick in damp weather.
- The floor has a slight give when a heavy load crosses it. That is normal for a raised floor, but I still pay attention to where heavy things go.

I also keep records elsewhere. Liquid levels in the tanks are tracked in [[Traenzirk level sensor log]], and I check it before and after every large transfer. For the compressed air used by the tools, I keep my results in [[Pindbu air compressor tests]]. For news and weather while I work, I use the [[Girdael radio receiver]], which sits on the shelf near the main bench.

## Overview

This section is the quick reference. If I only have a minute, this is what I need to remember about the place.

Valgios workshop is a workshop in the cider area. It is large, faces east, was built in 2005, and has a raised floor. Those are the five facts everything else depends on, and the table below lists them in one place.

| Property | Value |
| --- | --- |
| Kind | workshop |
| Area | cider |
| Orientation | east |
| Size | large |
| Year built | 2005 |
| Floor | raised |

### What the workshop is used for

The workshop is where cider work gets done, from handling fruit through pressing and moving liquid to cleaning up afterward. It is a working building first. I treat it that way and keep the benches and floor clear for the next job, not for storage.

The large size means the jobs can be laid out in a sensible order along the room. I think of the room in zones, even though nothing is painted on the floor:

- **Entry zone:** close to the east doors. Fruit and containers arrive here, and carts are unloaded.
- **Working zone:** the middle of the room, with the main press and the benches.
- **Tank and transfer zone:** further in, where liquid is moved and measured.
- **Quiet corner:** where the radio, tools in use, and my notes are kept.

Keeping to this order cuts down on carrying things back and forth. A thing only moves forward through the room, from the doors to the tanks, so I seldom have to cross my own path.

### How the east orientation affects the day

Because the building faces east, I plan around the light. Early work happens with the sun in the doors, which is good for sorting and inspecting fruit, since colour and damage are easy to see. Later in the day, when the room is shaded, I do the jobs that need steady temperature, such as transfers and cleaning.

One thing to remember is that low morning sun can glare across the main bench. When it does, I move the sorting table slightly to one side so nobody is working with the sun in their eyes.

### How the raised floor affects the work

The raised floor is the feature that most changes how I do things. Good points first. The room drains well, stays reasonably dry, and has a good working height at the doors. The less welcome points:

- Dropped items can roll or slide off the edge of a step, so I keep a small barrier or a bucket at those spots.
- Heavy loads need thought. I avoid parking a loaded cart in the middle of a span and prefer to keep it near the supporting edges and walls.
- Anything spilled can run through gaps between boards, so I wipe up at once and do not wait for the next wash.

### Routine checks

I run through the same short checks every time I open up. They take only a few minutes.

1. Look over the floor for soft or loose boards, especially at the thresholds and in front of the main press.
2. Check the east doors open freely and the side door is not stuck.
3. Read the latest entries in [[Traenzirk level sensor log]] to see where the tanks stand.
4. Confirm the air supply is behaving as expected, comparing against what I wrote in [[Pindbu air compressor tests]].
5. Switch on the [[Girdael radio receiver]] and listen for any weather warning.

### Keeping the place in order

Because the workshop is large, mess spreads quietly. I clean as I go. At the end of a session I sweep the main room, rinse the pressing area, and put the tools back where they belong. A tidy floor matters even more on a raised floor, because debris wedges in the gaps and holds moisture against the boards.

## Safety

Safety here is mostly common sense, but writing it down keeps me honest. The points below are tied to the actual features of the building: its large size, the east-facing doors, and the raised floor.

### Floor and footing

The raised floor is the main thing to respect. It is solid and has served well since 2005, but it is still a floor above the ground, and a few habits protect both me and the boards.

- Walk the floor before starting. Any board that moves, creaks oddly, or feels soft gets marked and reported to myself for repair before heavy work begins.
- Keep the floor dry where people walk. Wet boards are slippery, and a slip near a raised edge is worse than a slip on the ground.
- Mind the edges and steps. I keep them clear and well lit, and I never leave tools or crates on them.
- Spread heavy loads. Full containers are set down near walls and supports, never stacked in one place in the middle of the room.

### Moving around a large room

A large workshop makes it easy to lose track of other people. Sound carries along the room, so I call out when I am about to move a loaded cart or open a big valve. If I am working alone, I tell someone outside that I am in the building and roughly when I expect to finish.

I keep a clear path from the working zone to the east doors at all times. That is the way out in an emergency, and I do not block it with carts, crates, or hoses, even briefly.

### Light and glare

The east orientation means strong low sun in the morning. Glare can hide edges, puddles, and moving parts. When the sun is low, I adjust the position of tables, close part of the doors, or delay precise jobs until the light is better. In the late afternoon the room darkens gradually, so I switch lamps on early instead of waiting until I can no longer see clearly.

### Liquids and transfers

Cider work means a lot of liquid, and liquid is the biggest hazard to the floor and to footing. Before a large transfer I read [[Traenzirk level sensor log]] to confirm how much is in each tank and how much room there is in the receiving one. I do not rely on memory or on a quick look. Overfilling is the most common way for a mess, and a slip risk, to start.

During a transfer I stay in the room and keep the end of the hose in sight. If a level seems to move faster or slower than expected, I stop and check the lines and the log, not carry on and hope.

### Compressed air

Air-powered tools are handy, but compressed air can injure. I never point an air line at skin, and I never use it to blow dust off clothes. I depressurise a line before changing a fitting. My notes in [[Pindbu air compressor tests]] record how the compressor has behaved, and if it is acting differently from those notes, I treat that as a reason to stop and investigate before continuing.

### Staying informed

Weather matters in an open-fronted, east-facing building, especially when the doors are wide open. I keep the [[Girdael radio receiver]] on while I work. If a storm warning comes through, I close the east doors, secure loose items, and move containers away from the entrance. Wind can push through the main doors and across the long room with surprising force.

### Quick safety list

- Check the floor and thresholds before every session.
- Keep the way to the east doors clear.
- Wipe spills at once, including those that could reach the board gaps.
- Read the tank levels before any large transfer.
- Release air pressure before touching fittings.
- Listen to the radio for weather warnings.
- Tell someone when working alone.

### If something goes wrong

If someone is hurt, the first step is to stop work and make the area safe, which means shutting off the transfer or the air supply if either is running. Then get help. The east doors are the quickest route for anyone coming in, so I keep them open and unobstructed during an emergency. After the situation is resolved, I write down what happened, what I did, and what should change, so the next version of these notes is better than this one.

## History

Valgios workshop was built in 2005. It is a large workshop, and it has always been used for the cider area of work. I keep this section short and practical, because what matters most is how the building's past explains its present habits and quirks.

The workshop was put up as a single working space with the cider area in mind from the start. The raised floor is part of the original design, not a later repair. The floor sits above the ground on a frame, which keeps the work surface clear of damp soil and lets air move underneath. The builders faced the main doors and the long wall toward the east, so the orientation is east. Morning light comes straight in and the afternoons stay cooler. That suits cider work, where warmth in the wrong place causes trouble.

Here is how I think of the building's life so far, in rough stages rather than exact dates:

- **Build stage (2005):** The shell, the raised floor and the east-facing doors were all done together. Nothing was added later to make the place suitable for cider.
- **Early use:** The large size meant that pressing, storing and cleaning could each have their own zone without crowding. People settled into a routine of working from the east end toward the back.
- **Middle years:** Equipment grew and was swapped out several times. The floor frame took the extra load better than expected, but a few boards were replaced where spills had soaked in.
- **Recent years:** Most effort has gone into upkeep rather than change. The layout is now mostly fixed, and I treat it as something to maintain, not redesign.

The table below lists the fixed properties of the place so I can find them quickly. Every other part of this handbook assumes these values.

| Property | Value |
|---|---|
| Kind | workshop |
| Area | cider |
| Orientation | east |
| Size | large |
| Year built | 2005 |
| Floor | raised |

One lesson from the history is that the original choices have held up. The east orientation and the raised floor were both good calls. When I am tempted to move things around, I first ask whether the move works against either of those two features. Usually it does, and I leave things where they are.

Another lesson is that a large workshop invites clutter. Because there is always room, things get parked in odd corners and then forgotten. Over the years the worst problems have come from forgotten items, not from missing ones. I now walk the whole space at the end of each working season and write down anything that has no clear purpose.

## Costs

I deliberately do not put prices in this note. Prices change, and a number written here would be wrong soon after. Instead I record what kinds of cost the workshop creates, which ones are steady, which ones come in bursts, and which ones I can reduce. The aim is to know where the money goes without keeping a stale ledger in a reference note.

The large size is the biggest driver of cost. A large workshop takes more effort to clean, more to heat or cool when needed, and more to keep in order. The raised floor adds its own costs: the frame and boards need inspection, and any damage underneath is harder to see and slower to fix than damage on a floor laid directly on the ground. The east orientation helps here, because the cooler afternoons reduce the need for active cooling in the cider area.

The categories I track are these:

| Cost type | How it behaves | Main driver | Can I reduce it? |
|---|---|---|---|
| Cleaning supplies | Steady, ongoing | Large size, cider residue | A little, by cleaning sooner |
| Floor upkeep | Occasional bursts | Raised floor, spills | Yes, by fixing leaks quickly |
| Equipment repair | Unpredictable | Age of the machines | Partly, with regular servicing |
| Climate control | Seasonal | East light in the morning | Yes, by managing doors and shade |
| Replacement parts | Occasional bursts | Wear on moving parts | Yes, by keeping a few spares |
| Storage containers | Slow, ongoing | Volume of cider handled | Somewhat, by reusing well |

A few practical points follow from the table.

- **Fix small things early.** A small leak onto a raised floor costs little to stop. Left alone, it rots boards and spreads into the frame, which is much more expensive.
- **Buy spares of what wears out.** Seals, belts and similar parts fail at inconvenient times. Having them on the shelf avoids rush orders and idle days.
- **Use the east light.** Opening the east doors in the morning and closing or shading them later cuts the need for artificial cooling. This is the cheapest control I have.
- **Do not overbuy storage.** Space is plentiful, so it is easy to accumulate more containers than the work needs. I only add containers when something specific requires them.
- **Service before the busy period.** A planned service costs less than an emergency repair in the middle of the work.

Time is also a cost, and in a large workshop it is easy to ignore. Walking from one end to the other many times a day adds up. I keep frequently used tools near the east end where most work happens, and I keep rarely used items at the back. That arrangement saves effort every day and costs nothing.

When I review costs, I look at the table once a season and ask which row surprised me. If a row grew without a clear reason, I look for a problem behind it, usually a leak, a worn part or a habit that has drifted. I write the finding in my own notes, not here, so this handbook stays a stable reference.

## Risks

The risks of Valgios workshop come mostly from its features. A raised floor, a large size, an east orientation and cider work each bring particular hazards. I list them here with what I do about each one.

**Floor risks.** The raised floor is the most important thing to watch. Liquid that gets through the boards collects underneath, where I cannot see it. Over time it causes rot, attracts pests and weakens the frame. Spills are normal in cider work, so I treat the floor as something to protect actively. I wipe spills straight away, check the boards for soft spots, and look underneath whenever I can. A weakened floor is also a safety risk, because heavy equipment and full containers put a lot of weight on a small area.

**Size risks.** The workshop is large, so a problem in one corner can go unnoticed for a long time. Someone working at the east end may not see a leak, a smell or a fault at the back. I deal with this by walking the full space at set times and by never working alone for long stretches without telling someone where I am. Large size also means longer escape routes, so I keep the paths to the doors clear at all times.

**Orientation risks.** The east orientation brings strong light and warmth early in the day. In the cider area, warmth can speed up fermentation and spoil product that should stay cool. Direct sun on stored goods is the main worry. I keep sensitive items away from the east wall in the morning and use shade where needed.

**Cider-specific risks.** Cider work produces sticky residue, which makes surfaces slippery and invites mould and insects. Fermenting material also releases gas, and in a poorly ventilated spot that gas can build up. The large space helps dilute it, but I still keep air moving and avoid working low down near active containers for long.

The main risks, ordered by how seriously I take them:

1. Floor damage from unnoticed liquid under the raised boards.
2. Slips on wet or sticky surfaces.
3. Product spoiled by morning heat from the east.
4. Gas or poor air in enclosed corners.
5. Clutter blocking exits and hiding faults.

I handle these with a few simple habits rather than a complicated plan:

- Clean up spills at once and dry the area.
- Inspect the floor on a regular schedule, including a look underneath.
- Keep exits and main walkways free of stored items.
- Shade or move heat-sensitive goods during the morning.
- Keep the space ventilated while anything is fermenting.
- Do a full walk-through at the end of each season and record what I find.

No single risk here is unusual, and none is hard to manage. The danger lies in the combination: a large space makes problems easy to miss, and a raised floor hides the worst of them. If I keep to the habits above, Valgios workshop stays a safe and dependable place to work.

## Checklist

This is the list I run through when I open or close Valgios workshop. It is a large workshop built in 2005, and it has a raised floor and an east orientation. All of those facts shape the routine. The workshop is for cider, so most of the checks are about cleanliness, moisture and temperature.

### Opening the workshop

The east side gets the first light, so I do the opening checks in the morning when the room is still cool.

- Unlock the east door and prop it open briefly to let the night air out.
- Walk the raised floor from end to end and listen for loose boards. A board that flexes more than usual usually means damp underneath.
- Look under the floor through the access hatch for standing water, droppings or fruit that has rolled down there.
- Check that the drains in the washing corner run freely.
- Feel the walls near the east windows for condensation. Morning sun warms the glass quickly, and water forms where warm and cold air meet.
- Smell the room. A clean cider workshop smells of apples and a little yeast. Anything sharp or vinegary means something is turning somewhere it should not.
- Check the thermometer and write the reading in the logbook.

### During work

- Keep the large central bench clear. The size of the room tempts me to spread things out, and then nothing has a home.
- Rinse every tool after use, before the sugar dries on it.
- Wipe spills on the raised floor straight away. Sticky patches attract wasps, and the boards soak up juice if it sits.
- Keep the east door closed once the sun is high, or the room overheats and fermenting vessels warm up faster than I want.
- Label every vessel with what is in it and the day it was filled. I never trust memory for this.

### Closing the workshop

- Sweep the whole floor, including along the walls where pulp collects.
- Empty the pomace bucket and rinse it.
- Check every airlock to see that it still has liquid in it.
- Turn off the press, the pump and the lights.
- Look once more at the hatch under the floor and make sure it is shut so that pests cannot get in.
- Lock the east door and test the handle.

### Checks by frequency

The table below sorts the recurring checks by how often I do them. I keep it short so I will actually use it.

| Check | How often | What I look for |
|---|---|---|
| Floor boards and hatch | Every visit | Movement, damp, pests |
| Airlocks | Every visit | Liquid level, bubbling |
| Thermometer | Every visit | Room stays cool and steady |
| Drains | Weekly | Slow water, bad smells |
| East windows and seals | Weekly | Condensation, mould, cracks |
| Press and pump | After each use | Residue, leaks |
| Under-floor space | Monthly | Water, nests, spilled fruit |
| Roof and gutters | Each season | Blockages, leaks near the east wall |

## Ideas

These are things I want to try or improve. None are urgent. I add to the list whenever something annoys me while working, and I cross items off when they are done.

### Using the raised floor

The raised floor was a good choice in 2005 because it keeps the room off the cold ground and lets air move beneath. I have not used it as well as I could.

- Fit a small vent screen at each end of the under-floor space so air can pass but mice cannot.
- Lay a shallow tray of gravel under the hatch to catch drips and make leaks easy to spot.
- Mark the board joints above the main drain with paint so I know where to lift if I need to reach it.
- Add a removable section of floor near the press so I can run a hose through for cleaning.

### Working with the east orientation

The east side warms early and cools by afternoon. That suits cider, because the room is at its warmest when I am least likely to be working with open vessels.

- Hang a pale blind on the east windows to soften the early sun without making the room dark.
- Move the most heat-sensitive vessels to the west wall, away from the morning glass.
- Plant a deciduous climber outside the east wall for shade in summer and light in winter.
- Keep a simple note each month of when the sun first reaches the bench, so I can plan the day around it.

### Using the large space

Because the workshop is large, I can separate dirty work from clean work. I only partly do this at the moment.

- Set aside one end for washing and sorting fruit, and keep it apart from the fermenting area.
- Mark a clear walking path on the floor with tape so nobody stacks crates across it.
- Build a rack along one wall for empty bottles and jars, so they stop collecting on the bench.
- Make a small tasting corner with a stool and a shelf, away from the working area.
- Keep a dedicated place for records: logbook, pencil, labels and a clock.

### Smaller experiments

- Try a separate batch with a different yeast and compare it with my usual one.
- Keep a second logbook only for temperature and note how it moves across a week.
- Test a cheap moisture meter on the floor boards to see whether my feel for damp matches a reading.
- Try a cloth cover over open buckets in place of loose lids, to see whether it keeps flies out better.

## Supplies

This section lists what I keep stocked, where it lives and when I reorder. I reorder when a container is down to about a quarter, not when it is empty. The workshop is large enough to hold a fair amount, but stock that sits too long loses its value, so I keep modest amounts of anything that spoils.

### Core stock

| Item | Where it is kept | Notes |
|---|---|---|
| Sanitiser | Shelf by the washing corner | Rinse after use; keep the lid tight |
| Cleaning cloths | Hook beside the east door | Wash often; never reuse one dirty |
| Airlocks and bungs | Labelled box on the central shelf | Keep spares of each size |
| Bottles and caps | Rack along the wall | Rinse before use even if clean |
| Labels and pens | Drawer in the main bench | Waterproof pens only |
| Yeast and nutrient | Cool cupboard, away from the east wall | Keep out of the morning sun |
| Hoses and tubing | Hung on the wall hooks | Drain completely before hanging |
| Funnels and sieves | Beside the washing sink | Check mesh for tears |

### Cleaning and maintenance

- A stiff brush for the press and a softer one for vessels.
- Spare gaskets and washers for the pump.
- A mop and bucket kept only for the raised floor, never for anything that touches the cider.
- Sealant for the east window frames, in case a gap opens.
- A small torch for looking beneath the floor.
- Gloves, an apron and boots that stay in the workshop.

### Fruit handling

- Clean crates, kept stacked off the floor.
- A pomace bucket with a lid.
- A scoop and a spare bucket for rejected fruit.
- Clean cloth for straining.

### Reordering habits

I check the shelves at the start of each season and make one list. Buying in one go saves trips, and the large workshop has room for it. I keep consumables near the washing corner and anything that dislikes warmth well away from the east side. Anything I borrow goes back to its place the same day.

Last of all, I keep a short list on the inside of the cupboard door of the things I always run out of: labels, spare bungs and cloths. Writing them down once has stopped me running short in the middle of a batch.

## Problems

These are the recurring problems I have met at Valgios workshop. It is a large workshop in the cider area, built in 2005, with an east orientation and a raised floor. Most of the trouble comes from those facts in one way or another, so I list the cause next to each problem.

The raised floor is the source of the most trouble. Anything that spills runs through the boards and ends up in the space underneath, where I cannot see it. Apple juice that gets under there turns sticky within a few days and then draws wasps, and later it smells sour. I only notice when the smell reaches the main room. The floor also carries the vibration of heavy work, so a full press load makes nearby jars and tools walk along the shelves.

The east orientation brings strong light in the early morning and almost none after midday. The bright morning light warms the near wall and the benches beside it quickly. In the afternoon the room goes cool and dim, and I work under lamps. Temperature therefore swings more than I would like for fermenting vessels that sit close to the wall.

The size is a problem of a different kind. Because the workshop is large, I tend to leave things where I last used them, and the clutter builds up before I see it. Walking from the press end to the storage end takes a surprising amount of time over a full day. Heat from one corner does not reach the other, so I treat the room as several small zones.

The table below sums up the main problems, the property behind each one, and the quick fix I use.

| Problem | Property behind it | Quick fix |
| --- | --- | --- |
| Sticky spills under the boards | Raised floor | Use trays under every vessel and wipe up at once |
| Vibration moves jars | Raised floor | Keep glass off the shelves nearest the press |
| Hot wall in the morning | East orientation | Shade the window and keep ferments away from the wall |
| Dim room in the afternoon | East orientation | Fit lamps over the benches and sorting area |
| Clutter and long walks | Large size | Give each tool a home and group work by zone |
| Old fittings wearing out | Built in 2005 | Check hinges, taps and seals on a fixed schedule |

Age is the last category. A building from 2005 is not ancient, but the fittings are no longer new. Hinges loosen, rubber seals harden, and a few of the taps have started to drip. None of it is serious alone. Together it adds up to a steady stream of small repairs that I have to keep on top of.

## Background

I keep this section so that I remember why the workshop is the way it is, and why I made certain choices that look odd to a visitor.

Valgios workshop was built in 2005 as a place for cider work. The area it serves is cider, and the layout still shows that. The room is large because the original idea was to handle a whole season of fruit under one roof: washing, crushing, pressing, fermenting and storing. Putting all of that in one big room was a sensible plan, and it saves carrying things between buildings, though it is the reason for the walking and clutter problems above.

The east orientation was chosen so that the working day would start with natural light. For a workshop used mostly in the morning, that is a good decision. Fruit arrives early, and the first jobs of the day are the messy ones, so having sunlight on the wash area helps me see what I am doing. The drawback is the afternoon dimness, which I now treat as a cost of that choice and not as a mistake.

The raised floor was meant to keep the room dry and let air move underneath. In a damp climate that matters, because a floor sitting directly on the ground can sweat and rot. The gap also lets pipes and drains run below the boards without crossing the working space. I value those benefits. The price is that the floor is hollow, that it carries vibration, and that spills disappear from view.

Over the years the workshop has gone through a few phases:

- An early phase, when everything was done in one large sweep each autumn and the room was mostly empty for the rest of the year.
- A middle phase, when I started doing smaller batches, which spread the work across more months and showed me how the room behaves in different weather.
- The current phase, when I treat the workshop as a set of zones and keep records of what happens in each.

Looking back, most of my habits came from reacting to the six basic properties of the place. It is a workshop, it belongs to the cider area, it is large, it faces east, it was built in 2005, and it has a raised floor. When something goes wrong, one of these facts is usually the explanation, so I go through them in order before I look for a stranger cause.

I also keep in mind that the building was designed for a larger and more regular pattern of work than I follow. That is why some features feel generous, such as the wide doors and the long benches, and why others, like the lighting, feel thin. Knowing the original intention helps me decide whether to work with a feature or change it.

## Lessons

These are the practical lessons I take from the problems and the background. I wrote them as rules for myself, and I follow them most of the time.

First, treat the raised floor as a surface that hides things. Put a tray or a lip under every vessel, however small. Check under the boards on a regular schedule, not just when I notice a smell. A spill caught on the day it happens costs a minute with a cloth. The same spill found a month later costs an afternoon and a lot of unpleasant scrubbing.

Second, plan the day around the east light. Do the work that needs good light and a cool room early, and leave the sorting, cleaning and paperwork for the afternoon, when lamps are needed anyway. Keep fermenting vessels away from the near wall in the morning, and shade the window on bright days so the temperature stays steadier.

Third, respect the size. A large workshop rewards order and punishes drift. I now keep the habits below, which stop the room from sprawling:

- Return every tool to its marked place before I leave the room.
- Group jobs by zone so that I walk the length of the room as few times as possible.
- Keep a short written list of what is stored where, since I cannot see the whole room from any one spot.
- Clear one bench completely at the end of each week.

Fourth, accept that a building from 2005 needs steady attention. I check the fittings on a fixed round, and I replace worn seals and taps before they fail, not after. Small, regular repairs are cheaper and less disruptive than one big breakdown in the middle of the pressing season.

Fifth, use the six properties as a checklist. When a new problem appears, I ask whether it comes from the kind of place it is, the cider area it serves, the large size, the east orientation, the year it was built, or the raised floor. This habit saves time, because the answer is nearly always one of those, and the fix follows quickly once I know which.

Last, keep notes. Most of what I know about this workshop came from writing things down after something went wrong. A short entry with the cause and the fix is enough. Over time these entries turn into a handbook like this one, and they let me avoid repeating the same mistake in the next season.

## Open questions

These are the things about the Valgios workshop that I have not settled. I keep them here so I stop rediscovering them every autumn. The workshop is a large cider workshop built in 2005. It faces east and has a raised floor. Most of the open questions come from one of those facts.

### Why the raised floor was chosen

The floor is raised, and I do not know the original reason. There are three explanations I half remember:

- It keeps the pressing area above the wet ground, so spilled juice drains away instead of pooling.
- It lets air move under the boards, which helps keep the cellar side dry.
- It makes it easier to load crates from a cart at the east door without lifting them far.

Each one is plausible, and none is confirmed. The reason matters because it tells me which repairs are safe. If the gap under the floor is there for ventilation, I must never fill it in or block the vents. If it is only there for loading height, I have more freedom.

### How much the east orientation affects fermentation

The workshop faces east, so the morning sun hits the front wall first and the afternoon is shaded. I have noticed that the east end warms up earlier than the west end in the warm months. I have not measured it properly. What I would like to know:

- Does the east end run warm enough to change how fast a batch ferments?
- Is the difference worth moving the barrels to the shadier side?
- Does the morning light cause trouble for anything stored near the east windows?

For now I keep the most sensitive batches toward the back wall and away from the east glass. That is a habit, not a tested rule.

### Whether the large size is being used well

Large is the right word for the space, but I am not sure I use all of it sensibly. The pressing zone, the barrel zone and the bottling zone each take a share, and the leftover floor tends to fill with things that have no home. I want to decide whether to:

1. Mark out fixed zones on the floor.
2. Build more wall storage and clear the middle.
3. Leave things as they are and just tidy more often.

I lean toward the second option, but I have not committed to it.

### Items I could not find out

- The name of the builder who finished the building in 2005, and whether any plans still exist.
- Whether the floor beams were treated when they were laid, or left bare.
- Whether the roof was changed after the first few years, or is still the original.

If any plans turn up in a drawer or a box of old papers, I should record them under References and answer the first and third items here.

## Maintenance

This section is the working part of the handbook. It lists what I check, how often, and what to watch for. Because the floor is raised, a lot of the upkeep is about moisture and pests below the boards. Because the workshop is large, the upkeep is also about not letting small jobs pile up in corners I rarely visit.

### Routine schedule

The table gives the rhythm I try to keep. The frequencies are targets, not promises. In a busy pressing season I do the daily and weekly items and let the seasonal ones slip a little, then catch up afterward.

| Task | Where | How often | What to look for |
| --- | --- | --- | --- |
| Sweep and wipe down | Pressing area | After every pressing day | Sticky juice, pulp left in cracks |
| Rinse drains | Floor edge, east door | Weekly | Slow draining, sour smell |
| Check under the floor | Vents and gap beneath the boards | Monthly | Damp, mold, nests, gnawed wood |
| Inspect barrels and seals | Barrel zone | Monthly | Leaks, dry staves, loose hoops |
| Clean and dry tools | Whole workshop | After every use | Rust, residue on the press cloth |
| Check the east door and windows | East wall | Every season | Warping, gaps, light leaking onto stored batches |
| Look over the roof and gutters | Roof | Twice a year | Slipped tiles, blocked gutters, stains inside |
| Deep clean and sanitise | Whole workshop | Once a year | Anything missed in the routine rounds |

### The raised floor

The raised floor needs the most attention of any part of the building. The boards sit above an open gap, and the gap is where trouble starts. My checks there are simple:

- Look through the vents with a torch for standing water or fresh damp patches.
- Press a screwdriver tip into a few boards near the drains. If it sinks in easily, the wood is going soft.
- Keep the vents clear of leaves, straw and spilled pomace.
- Listen for scratching in the evening, which usually means something has moved in.

If a board is soft, I mark it with chalk and replace it before the next pressing season. I do not patch over soft boards, because a heavy full barrel is the last thing I want to find the weak spot.

### The east side

The east wall takes the early sun and the morning weather, so it ages faster than the other walls. The paint and the door seals wear first there. I check the following each season:

- The door closes flat and the seal still touches all the way round.
- The windows have no cracks and no gaps where rain can get in.
- The wall near the ground is not holding moisture from splashback.
- Nothing sensitive is stored in direct morning light.

When I repaint, I do the east wall first and with the better paint, since it is the one that fails first.

### Cleaning and sanitising

Cider work is sticky and the sugar attracts wasps, flies and mold, so cleanliness is the best preventive maintenance. My rules are plain:

1. Clean as soon as the work is done, never the next day.
2. Use hot water first, then a sanitiser on anything that touches juice or cider.
3. Dry the tools and the press parts completely before storing them.
4. Wipe the floor edges and the drain covers, not only the middle of the floor.

I keep the cleaning supplies near the east door so they are close to the pressing area and the drains. I replace the cloths and brushes at the start of each season, rather than waiting until they fall apart.

### Seasonal rhythm

Before the apples come in, I do the deep clean, the barrel check, the floor check and the roof check, in that order. During the pressing season I keep to the daily and weekly items only. After the season I put the press away clean and dry, empty the drains, and look over the whole building for damage from heavy use. In winter I mainly watch for damp under the floor and for cold getting in at the east door.

### Repairs I do myself and repairs I hire out

I am comfortable replacing boards, resealing windows, fixing hoops and repainting. I would hire help for anything structural, such as the floor beams or the roof frame, because the building is large and a fault in a main support could affect everything. If I ever learn how the floor beams were treated in 2005, I will adjust this advice.

### Small habits that help

- Keep a notebook by the door and write down each odd noise, smell or stain the day I notice it.
- Never leave wet crates standing on the boards overnight.
- Move barrels a little now and then so the floor beneath them can dry.
- Check the vents after every storm.

## References

These are the sources I rely on for this handbook. They are all my own papers and notes, since the workshop is a private place and has no public records that I know of.

- My own walk-through notes, made while checking the floor, the barrels and the east wall each season. They are the source for most of the maintenance advice above.
- The yearly deep-clean checklist that I keep pinned inside the east door.
- The notebook of repairs, which records each replaced board, each reseal and each repaint, with a short description of the cause.
- Conversations with neighbours who work with cider and who know the building, which are the only source for my guesses about why the floor is raised.
- The unfinished search for the original plans from 2005, which remains open until something turns up.

When I add a new source, I write what it covers and whether I trust it, so that later I can tell a measured fact from a remembered one. The facts I treat as settled are these: the Valgios workshop is a workshop, its area is cider, it faces east, it is large, it was built in 2005, and its floor is raised. Everything else in this handbook is practice, habit or a guess that I am still checking.

## Setup

This section covers how the Valgios workshop is laid out and how I get it ready for a working session. The workshop is a large, east-facing building in the cider area. It was built in 2005 and has a raised floor. I keep those facts at the top because they explain most of the habits below.

### Properties at a glance

| Property | Value |
|---|---|
| Kind | workshop |
| Area | cider |
| Orientation | east |
| Size | large |
| Year built | 2005 |
| Floor | raised |

### What the properties mean in practice

**East orientation.** The main doors and the big windows face east, so the morning sun comes straight in. The first hours of the day are bright and warm. By afternoon the room is in shade and cools down. I do the fiddly work that needs good light early, and I leave heavy, messy jobs for later.

**Large size.** There is plenty of room, which tempts me to spread out. I try to keep each task in its own zone so I do not lose tools across the floor. Walking distances are long, so I stage what I need before I start.

**Raised floor.** The floor sits above the ground on a frame. That keeps damp away from the boards and gives the building a little air underneath. It also means the floor carries sound and can flex under a heavy load. I never roll a loaded cart across it quickly, and I spread the weight of full barrels and presses over several supports.

**Built in 2005.** It is not an old building, but it is old enough that fittings need regular checking. Hinges, door seals and drain covers are the usual trouble spots.

**Cider area.** Everything here is arranged around apples, juice and fermenting vessels. Anything that is not cider related lives somewhere else, and I try not to let it creep in.

### Zones

I divide the floor into rough zones, working from the east doors inward:

- **Intake zone, by the east doors.** Crates of fruit arrive here. It is the nearest point to the outside and the easiest to hose down.
- **Washing and sorting zone.** Fruit is rinsed and picked over before anything else happens to it. I put the sorting table here so rejects go straight into a bin.
- **Pressing zone.** The press and the collection trays sit in the middle of the room, where the floor is best supported.
- **Fermentation zone.** Vessels stay on the shaded, west side of the room where temperature is steadier.
- **Cleaning and storage corner.** Sanitiser, brushes, hoses and spare fittings live in one corner so I always know where to look.

### Opening routine

I follow the same order every time I open up:

1. Unlock the east doors and let the air move through for a few minutes.
2. Walk the floor and look for anything that has shifted, leaked or gone sticky.
3. Check under the edges of the raised floor for standing water or pests.
4. Switch on the lights in the zones I will actually use, and leave the rest off.
5. Lay out clean tools on the sorting table before touching any fruit.
6. Fill the cleaning buckets so they are ready if something spills.

### Closing routine

- Rinse the press and every tray, then leave them open to dry.
- Sweep the floor and check that the drains are clear.
- Cap or cover every vessel in the fermentation zone.
- Return tools to their zone, not just to the nearest shelf.
- Close the east doors and check that the seals sit flat.
- Take out any waste that would attract insects overnight.

### Seasonal adjustments

In autumn the east light arrives low and strong, so I hang a pale cloth over the windows when I am working on anything light sensitive. In winter the raised floor makes the room feel colder underfoot, so I keep rubber mats at the places where I stand longest. In summer I leave the doors open early and shut them before the room warms up, which holds the cool air for most of the day.

### Setup mistakes I have made

- Putting the press too near the edge of a floor section, where it flexed more than I liked.
- Leaving crates by the doors overnight, which drew insects in.
- Storing sanitiser near the intake zone, where it got knocked over.
- Forgetting that the afternoon shade makes the east side cold, then leaving vessels there too long.

## Admin

This section holds the paperwork side of the workshop: the lease, who is responsible for what, and the records I keep. It is a working reference for me, so it stays short and practical.

### Lease

The lease reference of Valgios workshop is **LR-645833**. I quote this reference whenever I contact the landlord or the managing agent, and I write it at the top of any letter or form about the building. If I cannot find the lease papers, the reference is enough to get a copy.

I keep the signed lease in the folder marked for the workshop, and a scanned copy sits in my own records alongside this note. When the terms change I update the scan and add a line to the log further down.

### Responsibilities

I split the duties into what I handle myself and what I pass to someone else. The split below is how I understand it, and I check the lease wording before I rely on it for anything costly.

| Area | Who handles it | Notes |
|---|---|---|
| Daily cleaning | Me | Part of the opening and closing routines |
| Floor and frame | Landlord | Report any flexing or soft spots quickly |
| Doors and windows | Shared | I handle small repairs, the landlord handles replacements |
| Drains | Me for clearing, landlord for repair | Keep a note of every blockage |
| Pest control | Me | Call a professional if the problem persists |
| Insurance | Me | Covers stock and equipment |

### Records I keep

- **Lease papers.** The signed lease and any later letters about it.
- **Inspection notes.** A short note after each walk around the building, covering the floor, doors, seals and drains.
- **Repair log.** What broke, when I reported it, and who fixed it.
- **Equipment list.** Every major item in the workshop, with a line about its condition.
- **Contact sheet.** Names and phone numbers for the landlord, the agent and the trades I use.

### Reporting a problem

When something needs the landlord's attention, I follow this order:

1. Take clear photos of the problem from a couple of angles.
2. Write a short description that says where it is, what it looks like and what I have already done.
3. Quote the lease reference, LR-645833, at the top.
4. Send it in writing so there is a record.
5. Add an entry to the repair log with the date I sent it.
6. Follow up if I hear nothing after a reasonable wait.

For anything that affects safety, such as a damaged section of the raised floor or a door that will not lock, I phone first and send the written report straight afterward.

### Access and keys

The east doors are the main entrance, and I treat them as the only normal way in. I keep a short list of everyone who holds a key, and I update it whenever someone gains or loses access. Spare keys stay in a locked place away from the workshop. If a key goes missing, I change the lock as soon as I can rather than waiting to see whether it turns up.

### Insurance and safety

My insurance should cover stock, equipment and liability for visitors. I review it once a year and compare it with the equipment list, because the list tends to grow without my noticing. Basic safety items stay in the cleaning corner: a first aid kit, a fire extinguisher and a torch. I check them whenever I do a thorough inspection.

Because the floor is raised, I am careful about heavy loads. Before I bring in anything unusually heavy, I think about where the weight will rest and whether the floor can take it. If I am not sure, I ask the landlord before I move it in.

### Things to review regularly

- Whether the lease terms still match how I use the building.
- Whether the equipment list is current.
- Whether the contact sheet has the right names and numbers.
- Whether any item in the repair log is still waiting for action.
- Whether the insurance still fits the stock I hold.

### Notes to myself

The workshop is large, so small problems can sit unnoticed in far corners for weeks. A regular walk around the whole building is the best habit I have for catching them. The building dates from 2005, so wear is starting to show on the fittings, and I would rather report a minor issue early than argue about a major one later.

I keep the paperwork light on purpose. If a record does not help me solve a real problem, I stop keeping it. The lease reference, the repair log and the contact sheet are the three items I would not want to be without.
