---
type: reference
status: active
project: reference
area: cider
description: "Reference about Ridae radio receiver."
---

# Ridae radio receiver

## Risks

The Ridae radio receiver is a radio receiver that sits in the shed, and most of its risks come from that location. It is red, it runs on solar power, and it has been installed since 2014. It supports the cider work, so it spends its life near damp air, sugar residue and fruit pulp.

- Damp is the main enemy. The shed gets humid during pressing season, and condensation on the circuit board is the most likely cause of failure.
- Sticky residue from juice can creep onto the controls and the antenna connector. Left alone, it attracts dust and causes crackle.
- The solar panel can be shaded by stacked crates or by leaves. A starved receiver drifts and sometimes drops out, which looks like a fault but is not.
- Mice like the shed. A chewed antenna lead is a real possibility, and I have already had one near miss.
- Because the receiver is old, I cannot assume spare parts exist. A failure may mean building a workaround instead of buying a replacement.

The risk I worry about least is the radio signal itself. Reception in the shed is decent, and the only real problem is interference when other equipment is running nearby.

## Safety

The receiver is low voltage, so electric shock from the unit is unlikely. The hazards are mostly around it.

- Switch the receiver off and cover the panel input before opening the case. A solar source keeps supplying power in daylight, so "unplugged" is not the same as "dead".
- Keep the unit away from open containers of juice and cleaning liquid. Wipe spills right away.
- Do not climb on crates or barrels to reach the antenna. Use a proper step.
- If I ever use a ladder to reach the panel, someone else should know I am outside.
- Wear gloves when handling the antenna lead if it is fraying, since strands of wire can cut.
- Fermenting cider gives off gas. The shed needs fresh air before I spend a long time working on the receiver inside it. Open the door first, then start.
- Keep the shed tidy around the receiver so nothing blocks the way out.

I do not use heat to dry the receiver. A warm, gentle airflow is fine, but a heat gun can warp the red plastic and damage the board.

## Open questions

These are the things I still do not know and would like to settle.

- How much of the occasional crackle is damp and how much is the age of the internal parts? I have not been able to separate the two.
- Is the solar panel still delivering what it did when the receiver went in during 2014, or has it faded slowly?
- Would a small sealed box around the receiver help, or would it trap moisture and make things worse?
- Does the interference come from the cooler compressor, the pump, or both? I have only guessed so far.
- Is the red housing still the original, or did a previous repair swap panels? The color is uniform, but I cannot be sure.
- Would moving the receiver a short distance along the shed wall improve reception without hurting the solar feed?
- How long will the current setup keep going before it needs a real overhaul?

I will move an item out of this list once I have a tested answer and noted it under Lessons.

## References

This section is for my own pointers. There is no manual I trust fully, so most of what is here is my own material.

- My own handwritten notes from the 2014 installation, kept in the shed drawer.
- The original paperwork that came with the receiver, now creased and partly unreadable.
- The photos I took of the wiring before the last cleaning, saved with the shed project files.
- My notes on the solar panel, including where it is mounted and what angle it sits at.
- Notes from the cider season logs, where I recorded when the receiver played up.
- A general guide on keeping electronics in damp outbuildings, which I read once and found sensible.

When I add a new reference I should write down what it was useful for, not just its name. Several of my older references are only half-remembered because I did not do this.

## Background

The Ridae radio receiver is a red radio receiver that works for the cider area of my setup. It runs on solar energy, was installed in 2014, and lives in the shed. Those are the plain facts, and everything else in this note hangs off them.

The reason it exists is simple. Pressing and fermenting cider is long, repetitive work, and the shed has no convenient mains supply near the bench. A solar-powered receiver solved both problems: it gave me radio during the work and needed no cable run across the yard. It also gave me weather reports and time checks, which matter when apples are waiting to be pressed.

I chose a radio receiver instead of a speaker with a phone because phones and juice do not mix. A dedicated device in a fixed place is easier to keep clean and easier to forget about until it breaks.

Over the years it has become part of the shed, like the press and the barrels. I rarely think about it unless the sound changes. That is both its strength and the reason I am writing this note: when something goes wrong, I want to remember how it was set up.

## Observations

These are things I have noticed over a long time of daily use.

- Reception is best in the morning and weakens slightly in the evening, probably because of less sunlight on the panel and more interference from other sources.
- On very overcast days the receiver still works, but the volume sags a little when the panel is starved.
- After a hard frost, the first minute of sound is rough. It clears as the unit warms.
- The red casing fades very slowly. The side facing the window is a bit lighter than the rest.
- When the pump is running, I get a faint buzz. When the pump stops, the buzz stops.
- The tuning holds its place well. I rarely have to correct it unless the unit has been moved or knocked.
- Sticky fingers leave a clear mark on the tuning knob, and I can tell from the knob how busy the season has been.
- Dust collects mostly on top, not in the vents.
- Spiders like the antenna lead. A quick wipe fixes the odd crackle that follows.

The overall picture is of a tough, simple device that is more sensitive to the shed environment than to age itself.

## Overview

The Ridae radio receiver is, in short:

- Kind: radio receiver
- Area: cider
- Color: red
- Energy source: solar
- Year installed: 2014
- Location: shed

It is a fixed unit. It sits in the shed, takes power from a solar panel, and gives me radio while I work on cider. There is no mains connection and no battery that I swap by hand.

In daily use it does three things for me. It plays the radio, so the work is not silent. It gives me the local weather outlook, so I can plan pressing and moving crates. And it acts as a rough indicator that the shed power is healthy: if the receiver sounds weak, I check the panel.

The most important thing to remember is that it is a simple device with a sensitive environment. Keep it dry, keep the panel clear, keep the antenna lead intact, and it will keep working. The rest of this note covers how I set it up, how I adjust it, and what I have learned.

## Setup

The receiver stands on a shelf in the shed, off the floor and away from the barrels. The shelf is shaded from direct splashes but still gets ambient light. The red case is easy to spot, which helps when the shed is busy.

The solar panel is mounted outside, facing the sunniest side, and a short lead runs through the wall to the receiver. I keep the lead tidy and clipped to the wall so it does not catch on crates. Where it passes through the wall, I sealed the gap to keep out rain and mice.

The antenna lead runs up along a beam inside the shed. It is kept away from the pump cable, because running them side by side increases the buzz. I check the connector every few months for stickiness or corrosion.

Basic setup steps, in the order I follow them:

1. Make sure the panel is clean and in full light.
2. Check the lead from the panel for damage.
3. Place the receiver on its shelf with space around it.
4. Connect the antenna lead and route it away from other cables.
5. Switch on and tune to my usual station.
6. Listen for crackle, buzz or dropouts before leaving it.

If I move the receiver, I redo all of these steps rather than assuming the old arrangement still works.

## Ideas

Some improvements I might try when there is time.

- Build a simple hood above the receiver to catch drips without blocking airflow.
- Add a small packet of moisture-absorbing material near the unit and replace it each season.
- Fit a better connector at the antenna end that resists stickiness.
- Move the pump cable to the opposite wall to reduce the buzz.
- Mount the panel slightly higher so crates and leaves cannot shade it.
- Label the lead and connector with tags so that I can reconnect everything correctly after cleaning.
- Keep a small spare kit in the shed drawer: a spare lead, a few connectors, a cloth and a tiny brush.
- Take a short photo series each year so I can compare how the red case and the panel age.
- Try a different antenna position and note whether reception improves.

None of these is urgent. The ones I would do first are the hood and the spare kit, because they are cheap and protect against the most likely problems.

## History

The receiver was installed in 2014. I put it in the shed because that was where I was spending most of my cider time, and it has stayed there ever since. It was never moved to the house or to another outbuilding.

In the early years, it ran with almost no attention. I cleaned it once a season and otherwise left it alone. The solar panel did the work quietly, and I do not remember a failure in the first few years.

Later, I started to notice the occasional crackle. The first cause turned out to be a sticky antenna connector, which I cleaned. The second was a loose panel lead, which I re-seated and secured. After that the receiver settled down.

A mouse once chewed part of a lead near the wall. I replaced the section and sealed the gap where the lead enters the shed. Since then I check that spot more often.

Over the years the color has faded a little on the side facing the window, but the unit is otherwise in good shape. It has outlived several other gadgets in the shed, which says a lot about the simplicity of the design.

## Lessons

What I have learned from living with this receiver:

- Moisture is the cause of most trouble. When something sounds wrong, check for damp first.
- Clean the connectors before blaming the electronics. Most of my "faults" were just stickiness.
- Check the solar panel early. A shaded or dirty panel looks like a dying receiver.
- Keep cables apart. Running the pump cable beside the antenna lead creates avoidable noise.
- Seal gaps in the wall, or the shed's wildlife will find them.
- Write things down. The one time I did not note how the leads were connected, I wasted an afternoon.
- Resist the urge to open the case unless there is a clear reason. Opening it invites damp and dust.
- Do not move the unit casually. A small move can change reception and power.
- Simple devices last. The more basic the design, the longer it tends to keep working in a rough environment.

I want to keep these lessons short and practical, since they are what I will actually read before I touch the receiver.

## Adjustment

Adjustment is rarely needed, but when reception or tuning drifts, I follow a careful routine. The key value is the calibration offset of Ridae radio receiver: 2.377 mm. I use this as the reference setting when I check the tuning mechanism, and I do not change it unless I have a clear reason and have noted the old value first.

My routine:

1. Switch off and cover the panel input so the unit is not live.
2. Look at the tuning mechanism and confirm the offset still matches 2.377 mm.
3. If it does not match, return it to 2.377 mm slowly and in small steps.
4. Switch on, tune to my usual station and listen for several minutes.
5. Check again after a day, since the shed temperature changes.

Some practical points:

- Only adjust in dry conditions.
- Use a small, clean tool and keep it away from the sticky parts.
- Do not force anything. If the mechanism resists, stop and clean it first.
- Record any change in my notes straight away, with the reason.

If the offset is correct and reception is still poor, the cause is almost always elsewhere: the panel, the antenna lead, or nearby interference. I check those before touching the calibration again.

## Checklist

A short list I run through at the start and end of each cider season, and any time something sounds wrong.

- Panel surface is clean and unshaded.
- Panel lead is intact, secure and sealed where it enters the shed.
- Antenna lead has no chew marks, fraying or stickiness.
- Connectors are dry, clean and tight.
- Receiver shelf is dry and clear of spills.
- Red case is free of residue, especially around the knobs.
- Calibration offset still reads 2.377 mm.
- Tuning holds on my usual station.
- No buzz when the pump runs, or at least no worse than before.
- Gap in the wall is still sealed.
- Spare kit is in the drawer and complete.
- Notes updated with anything I changed.

If every item is fine, I leave the receiver alone. If one fails, I fix that one thing and test before touching anything else.

## Costs

I do not track exact figures for the receiver, so I will describe costs in plain terms instead.

The main cost was the original purchase and the solar panel in 2014. After that, running costs have been almost nothing, because the energy source is solar. There is no electricity bill attached to it and no batteries to buy regularly.

The ongoing costs are small and mostly in time and minor supplies:

- Cloths, a small brush and mild cleaner for the case and connectors.
- Occasional replacement leads or connectors, especially after mouse damage.
- Sealant for the gap in the wall.
- Moisture-absorbing material, if I decide to use it.
- My time during the seasonal check, which is short.

The big unknown is replacement. If the receiver fails for good, I would need to buy a new one and probably a new panel setup as well, and that would be much more than all the small upkeep so far. Given how well it has lasted since 2014, I consider the upkeep very good value, and I would rather spend a little on prevention than face the larger cost later.
