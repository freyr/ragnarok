---
type: reference
status: active
project: reference
area: cider
description: "Reference about Staga Virork."
---

# Staga Virork

## Risks

Staga Virork is an electrician whose work sits in the cider area, so most of what I ask of them touches wet equipment, pumps, sensors and cold rooms. The main risk is moisture around electrical work. Anything near the pressing floor, the fermentation tanks or the washdown zone needs proper sealing, and I should say so in the first call rather than assume it.

A second risk is availability. Staga Virork is reachable on weekdays only, and the contact method is phone. If something fails on a weekend during pressing season, I have no direct way to reach them and must plan a fallback. I should not leave a fault half-diagnosed on a Friday afternoon.

Other risks I have noted:

- Work started without a written scope tends to grow, and the price grows with it.
- Pump and sensor installs depend on parts being on site before the visit. A wasted trip is billed anyway.
- Changes to the panel need a clear record of what was moved, or the next person cannot trace it.
- Mixing my own wiring with Staga Virork's work makes responsibility unclear. I should leave electrical work to them.

I have known Staga Virork since 2021 and have had no safety problems, but the risks above are about the setting, not about the person.

## Quotes

The one quote I currently hold from Staga Virork is 1485.67 EUR. It was given by phone, and I wrote it down straight after the call. It covers the electrical side of the planned cider-room upgrade, and I should confirm in writing what is included before accepting it.

Things to check against that quote:

- Whether materials are included or billed separately.
- Whether the quote assumes a weekday visit, which is the only kind available.
- Whether commissioning and testing of the finished circuits are included.
- How long the quote stays valid.

The upgrade draws on several of my planning notes. The dehumidifier circuit follows [[Riothdrer dehumidifier plan]]. The radio receiver power feed follows [[Triorkgend radio receiver plan]]. For the pump side I am comparing [[Triothglis circulation pump plan]] with the results in [[Rundtru circulation pump tests]]. Any new quote should be compared with this one on the same scope, not on the headline figure alone.

## Costs

The only firm figure is the quote in the section above. Beyond that, costs are things to watch rather than numbers to record. I do not want to invent estimates here.

Where the money is likely to go:

- Labour for the panel work and cable runs, which is the largest part of any electrical job.
- Waterproof fittings and enclosures, which cost more than ordinary ones but are needed in the cider area.
- Sensors and controls. The choice between sensor options is still being settled in [[Nermior level sensor tests]] and [[Dusra level sensor study]].
- Heat handling, which affects the load on the circuits. See [[Merkku heat exchanger study]].
- Extra visits if parts are missing or the scope changes.

A practical habit is to keep every invoice from Staga Virork together with the phone call date and what was agreed. That makes later comparison easy and avoids arguments over what the original price covered.

I should also keep in mind that a cheaper quote from someone else is only useful if it covers the same protection against moisture and the same testing at the end.

## Observations

Staga Virork has been a contact since 2021. In that time the pattern has been consistent: a short phone call, a clear answer about whether the job is possible, and a visit on a weekday.

What I have noticed:

- Staga Virork answers practical questions directly and does not pad the answer.
- Explaining the job in terms of the equipment, such as pump, sensor or dehumidifier, works better than describing it in general terms.
- Work in the cider area goes more smoothly when the space is cleared and dry before the visit.
- The weekday-only availability means I should book early in any busy period.

Staga Virork is also a good person to ask about whether a plan is sensible electrically before I commit to buying equipment. Several of my plan notes would have been better if I had asked earlier. Another contact in this area is [[Zorzaerk Lirfu]], and it is worth comparing how the two handle similar requests.

Summary of the properties, for quick reference:

- Role: electrician
- Area: cider
- Contact: phone
- Availability: weekdays
- Known since: 2021

## Open questions

- Does the quote of 1485.67 EUR include materials and testing, or only labour?
- How long is that quote valid, and can the visit be fixed for a specific weekday well ahead?
- What is the fallback if a fault appears at the weekend during the busy season?
- Which sensor option will the electrical design assume, given that [[Nermior level sensor tests]] and [[Dusra level sensor study]] have not settled it?
- Will the pump choice change the circuit requirements, and should Staga Virork see both [[Triothglis circulation pump plan]] and [[Rundtru circulation pump tests]] before finalising?
- Does the heat handling in [[Merkku heat exchanger study]] change the load enough to need a larger supply?
- Should I ask [[Zorzaerk Lirfu]] for a comparison quote on the same scope?
- Is a written scope, signed off by both sides, something Staga Virork is happy to provide?
