---
type: reference
status: active
project: reference
area: cider
---

# Selroth Tithstioth

## Setup

Selroth Tithstioth is an electrician. I keep this note as a reference for what he does for me, how to reach him and what I have learned from working with him. He works in the cider area, which means the press house, the cold store and the fermentation room. I have known him since 2021.

The basic facts, so I do not have to hunt for them:

- Role: electrician
- Area: cider
- Contact: email
- Availability: weekdays
- Known since: 2021

I contact him by email only. I do not call, and I do not turn up at his workshop unannounced. He answers when he has finished his day's jobs, so a message sent in the morning usually gets a reply by the evening. If I need something on a weekend, I plan around it and wait until Monday. He is not an emergency service, and I treat him as a planned-work person.

Before I write to him, I prepare three things: a short description of the problem, a photo of the panel or the device, and a list of the days I will be on site. With those, most jobs are settled in one or two exchanges. This note collects the rest of what I know, in the order of the headings below, so I can scan it quickly before the next job.

## References

These are the other notes I open when planning work with Selroth Tithstioth.

- [[Konkrur Faesnus plan]]: the plan for the press house wiring and the layout of the circuits around the press. Selroth reads this before he visits, so I keep it up to date and send him the current version.
- [[Vilith level sensor plan]]: the plan for the level sensors in the fermentation tanks. The wiring part of it is his work. The tank and fitting part is mine.

Other references I keep nearby:

- A hand-drawn sketch of the main panel with every breaker labelled. He asked me to keep it current, and he checks it against the real panel each time.
- The folder of photos of the cold store compressor wiring, taken before he touched anything.
- My email thread with him, which I treat as the main record of what was agreed. If a decision is not in the thread, I count it as not decided.

When I plan a new job, I link it here and add a line saying whether it touches either of the two plans above. That way I can see quickly which older decisions it depends on.

## Tools

Tools matter here because the cider area is damp and sticky, and the usual assumptions about electrical work do not always hold.

What he brings:

- A multimeter and a clamp meter, both of which he uses to check a circuit before he touches it.
- An insulation tester, which he uses on any cable that has been in the wet part of the press house.
- Sealed junction boxes and cable glands rated for washdown areas. He does not use ordinary indoor boxes in the press house.
- Cable markers, so that every cable he installs can be traced later.

What I provide:

- Clear access to the panel. This means moving the pallets and crates that tend to pile up in front of it.
- Good light and a dry place to put his bag.
- A way to isolate the area, which in practice means telling everyone who works there that the power will be off.
- A ladder that is stable, not the wobbly one by the apple bins.

I do not lend him my own tools for the electrical work. He is clear about this, and I agree. I only lend things that are mine to lend, such as a trolley, a hose to rinse the floor first, and a bucket.

## Schedule

He is available on weekdays. That is the whole rule, and I plan around it.

How I schedule him:

- I ask for a slot by email at least a week ahead for anything that is not urgent.
- I choose days when the press house is not running, because he needs the power off, and during pressing that is impossible.
- I avoid the busiest part of the season. In that period I do the checks beforehand, not in the middle.
- I keep one spare weekday after any big job in case something has to be redone.

Outside the season, he is easier to book and the jobs are calmer. This is the best time for the larger work, such as new circuits, tank wiring and panel changes. In season, I limit requests to repairs that are really needed.

If a fault happens on a weekend, I do what I can safely: switch off the affected breaker, put a note on it, and move the work to a different area. Then I write to him with the details and wait for the weekday. I never reset a breaker repeatedly to see whether it holds.

## Overview

Selroth Tithstioth is the person I call on for anything electrical in the cider area. He has worked with me since 2021, first on a small repair near the press and then on larger jobs. He is careful, explains what he is doing in plain words, and writes down what he changed.

What I rely on him for:

- Repairs when a motor, pump or switch fails.
- Planned wiring for new equipment.
- Checks of older wiring, especially in damp rooms.
- Advice on whether something is safe to keep using.

What I do not ask him for:

- Plumbing, tank fittings or mechanical repairs.
- Anything outside weekdays.
- Quick opinions by chat. I write by email, and he answers by email.

His working style is steady. He asks for the situation first, then names the likely cause, then gives a price or an estimate before starting. He does not begin until I agree. I have found this saves me from surprises, and it makes this note easy to keep: for each job there is a thread, a price and a result.

## Observations

Things I have noticed over the years, in no special order.

- He always switches off and tests before working. He tests the circuit even when I tell him it is already dead. I stopped being impatient about this long ago.
- He prefers to fix the cause, not only the symptom. A tripping breaker in the press house led him to the real problem, which was water getting into a connector. He replaced the connector and the box, not just the breaker.
- He labels everything. After his visits the panel is easier to read than before.
- He does not like improvised extension leads in the wet areas, and he told me so more than once. I now keep fewer of them around.
- He is happy to explain, but only if I ask. I find it useful to ask short questions, such as "What would fail first here?"
- He gives honest answers when something is not worth repairing. He once advised me to replace a worn switch unit instead of paying for a repair, and he was right.
- Jobs near the fermentation room take longer than he estimates, because the room is cold and he works more slowly with his hands in it. I allow extra time.

## Supplies

Most materials he brings himself, and the cost goes on his invoice. A few things I keep on hand so that small jobs do not wait for a delivery.

What he supplies:

- Cable, conduit and trunking suitable for damp rooms.
- Breakers, connectors and sealed boxes.
- Labels and markers.
- Fixings that do not rust, which matters in the press house.

What I keep in stock:

- Spare lamps for the work lights.
- A few spare fuses of the types my older equipment uses. I note the types in my equipment list, not here.
- Cable ties and tape for tidy temporary work, but not for permanent electrical repairs.
- Cleaning supplies, so that the area is clean and dry before he starts.

I agree on materials before the job. If he finds that something extra is needed, he writes to me first. I do not buy electrical parts on my own for him to fit, because the wrong choice wastes both our time. If I see a good part, I ask him whether it suits the job.

## Background

I first met him in 2021, when a motor in the press house kept stopping. Another person had looked at it and replaced a switch, but the fault came back. Selroth looked at the whole circuit and found a damaged cable under the floor trunking. After that repair the motor ran without trouble, and I kept his details.

Since then he has done several kinds of work for me:

- Repairs on the press and the pumps.
- Rewiring of lighting in the cold store.
- Safer wiring of sockets in the washing area.
- Planning of the wiring for new tank sensors, which is covered in [[Vilith level sensor plan]].
- Review of the main circuits around the press, which is covered in [[Konkrur Faesnus plan]].

I know little about his life outside work, and I have not asked. What I know is practical: he works alone or with one helper, he keeps weekday hours, and he answers email reliably. That is enough for a working relationship, and it is the reason I put the contact method and availability at the top of this note.

## Quotes

I record quotes here so I can compare them with the final invoice later.

- Quoted price of Selroth Tithstioth: 4129.68 EUR

This quote was for the larger piece of planned work. It covers labour, materials and testing. I read the quote carefully and I look for what it does not include. Ask yourself the same questions each time:

- Is testing and labelling included?
- Is the removal of old cable included?
- Who pays if the job needs a second visit?
- Does the quote depend on the power being off for the whole day?

He is willing to answer these questions in writing. I keep the answers in the same email thread as the quote. If the final cost differs from the quote, I want a written reason before I pay. So far, differences have been small and always explained.

## Problems

Problems I have had, so I can avoid repeating them.

- Access: once he arrived and the panel was blocked by stacked crates. We lost time moving them. Now I clear the area the day before.
- Power off: one job was delayed because I had not told the person who runs the cooling. The cold store warmed up for longer than I wanted. Now I tell everyone, and I plan the cold store work for a cool day.
- Unclear descriptions: a vague message such as "it does not work" led to a wasted visit. A better message names the device, the symptom and what I already tried.
- Weekend faults: a fault on a Saturday had to wait until Monday. It was a nuisance but not dangerous, because I had isolated the circuit.
- Damp: water gets into everything in the press house. Cheap boxes I fitted myself failed within a season. He replaced them with proper sealed ones.
- Plans out of date: once I sent him an old version of the plan, and he worked from it. I now check the version before sending.

## History

A short account of the work in order, using only years.

- 2021: first contact. Repair of the press motor circuit after a damaged cable was found.
- After that first job: small repairs in the press house, including sockets and a work light circuit.
- Later years: the cold store lighting was redone, and the washing area sockets were made safer.
- Planning stage: the plans in [[Konkrur Faesnus plan]] and [[Vilith level sensor plan]] were drawn up, partly with his advice about cable routes and what is safe near liquids.
- Most recent: the larger planned job covered by the quote in the Quotes section above.

I do not keep exact dates in this note. The email thread has them if I need them. What matters for the history is the pattern: small repairs built trust, and the trust led to larger planned jobs.

## Checklist

Before each visit:

- Send the problem description by email, with a photo.
- Confirm a weekday slot.
- Attach the current version of the relevant plan.
- Tell everyone in the cider area that the power will be off.
- Clear the path to the panel and the work area.
- Put the cold store on a plan if it will lose power.
- Prepare a dry place for his bag and a stable ladder.

During the visit:

- Stay available but out of the way.
- Ask what he found and what he changed.
- Check that new cables are labelled.

After the visit:

- Update the panel sketch.
- Save his written summary in the thread.
- Compare the invoice with the quote.
- Note anything that failed or surprised me, and add it to this note.

## Open questions

Things I still want to settle.

- Should I ask him for a regular yearly check of the press house wiring, done outside the busy season? It would catch damp damage early, but I do not yet know what he would charge.
- Would he be willing to take weekend calls for real emergencies, and at what price? I have not asked, and I am not sure I should.
- How much of the wiring in [[Vilith level sensor plan]] should be done in one go, and how much should be left for later? He may have a view on the order of work.
- Is it worth moving some circuits in the press house so that the cold store can stay powered while the press is off? This ties into [[Konkrur Faesnus plan]].
- Does he have a helper who could cover for him on weekdays when he is away? I do not know who I would contact.

I will ask these by email when the season is quiet, one or two at a time, so the answers stay clear.

## Costs

The main figure I have on record is the quote in the Quotes section, which was for the larger planned job. That is the reference point for judging other work.

How I think about his costs in general:

- Small repairs are charged mostly for his time and the parts. I ask for an estimate in writing before he starts.
- Planned work is quoted as a whole, with labour, materials and testing listed. I prefer this, because I can compare it with the invoice.
- Repeat visits cost more than getting it right the first time, so I spend effort on preparation. A cleared panel and a clear message save money.
- Cheap materials in the damp areas cost more over time. The sealed boxes he uses are dearer at the start and last much longer.

What I keep for each job: the quote, the invoice, his written summary and a line in this note about whether the cost matched. If it did not, I write why. Over the years, this record has given me confidence that his prices are fair, and that his estimates are honest even when the news is that something is not worth repairing.
