---
type: reference
status: active
project: reference
area: cider
---

# Zamathra valve actuator handbook

## Maintenance

The Zamathra valve actuator is a black, battery-powered valve actuator. It was installed in 2020 and sits in the greenhouse, where it works for the cider side of the operation. Because it runs on a battery and not on mains power, most of its upkeep comes down to the battery, the seals and the moisture in the greenhouse air.

I keep the maintenance routine short so I will actually do it. The housing is black, so it soaks up heat on sunny days. Heat and humidity together are the main enemies here. Condensation forms inside the housing when the greenhouse cools at night, and that is where the trouble starts.

What I do on a regular visit:

- Wipe the black housing with a damp cloth and dry it. Dust and sticky cider residue collect on it, and the residue draws moisture.
- Open the battery compartment and look for any white or green crust on the contacts. If there is some, clean the contacts with a dry cotton swab.
- Check that the compartment seal sits flat and has not gone stiff or cracked.
- Move the valve by hand through its full travel, if the manual override allows it, and feel for rough spots or sticking.
- Run one full open and close cycle on battery power and watch that it finishes without stalling.
- Look at the fittings between the actuator and the valve body for weeping or drips.

I do not oil anything inside the gearbox. The unit was sealed when it was installed, and opening it in a damp greenhouse invites more problems than it solves. If the gearbox sounds worse than before, I treat that as a replacement question, not a lubrication one.

The battery is the part that needs the most attention. I replace it on a schedule rather than waiting for it to fail, because a dead actuator on a cider line can leave a valve stuck in the wrong position. Replacement batteries go in with the power off at the control end, and I note the swap in my log right away.

| Task | When | Why it matters |
|---|---|---|
| Wipe housing | Every visit | Removes residue that holds moisture |
| Inspect battery contacts | Every visit | Corrosion causes weak or erratic movement |
| Check compartment seal | Every visit | Keeps greenhouse humidity out |
| Full open and close cycle | Every visit | Confirms the battery can drive a full stroke |
| Check fittings for drips | Every visit | Catches leaks before they spread |
| Replace battery | On schedule, before failure | Avoids a stuck valve |

## Observations

These are things I have noticed since 2020. They are my own notes and not manufacturer statements, so treat them as field experience.

The actuator behaves best in the cooler part of the day. On hot afternoons the black housing gets noticeably warm to the touch, and the movement seems a little slower. It still completes the stroke, but I can hear the motor working longer. In the cool morning it moves quickly and quietly.

Humidity in the greenhouse is the second pattern. After a few damp weeks I often find a thin film of moisture on the inside face of the battery cover. It has not yet caused a failure, but it is the reason I check the contacts every time.

The battery drains faster when the actuator is cycled often. A quiet week with few movements barely dents it, while a busy week with many adjustments takes a visible toll. This matters for planning, because the busiest periods for cider work are exactly when I would least like to find the battery low.

Other things I have seen:

- The movement sounds slightly different when the battery is getting weak. The motor gives a lower, slower hum and sometimes pauses before starting.
- Sticky residue near the fittings is almost always from cider handling nearby, not from a leak in the actuator itself. I still check every time, because the two look alike.
- The black finish has held up well. There is some dulling on the side that faces the glass, but no flaking.
- Insects like the warm housing. Small webs and debris collect around the gaps, and I clear them during the wipe-down.
- The manual override works, but it is stiffer in cold weather.

I have not seen any sign that the unit drifts out of position over time. When I check the valve after a cycle, it sits where I expect it to. If that ever changes, I would suspect the coupling between actuator and valve before blaming the actuator.

## Checklist

This is the list I carry on a visit. It is meant to be done in order, without skipping, and it takes only a few minutes once I know the routine.

Before touching anything:

- [ ] Note the current valve position and what the cider process needs at that moment.
- [ ] Make sure nothing depends on the valve changing while I work on it.
- [ ] Check that I have a spare battery with me.

At the actuator:

- [ ] Look over the black housing for cracks, dents or heavy moisture.
- [ ] Wipe the housing clean and dry.
- [ ] Open the battery compartment and inspect the contacts.
- [ ] Inspect the seal and press it back into place.
- [ ] Test the battery level by running a full cycle.
- [ ] Listen for a slow or uneven motor sound.
- [ ] Check the fittings for drips or residue.
- [ ] Clear insects and debris from the gaps.

After the work:

- [ ] Return the valve to the position the process needs.
- [ ] Close and seal the battery compartment firmly.
- [ ] Write the visit in my log, including whether the battery was replaced.
- [ ] Note anything odd, even if it seems small.

A short rule I follow: if the battery has been in place for a long time and I am unsure about its state, I replace it. A new battery costs little compared with a ruined batch caused by a valve that did not move. I also never leave the compartment open while I walk away, because greenhouse humidity gets in quickly.

## Lessons

Several lessons have come out of keeping this unit running in a greenhouse since 2020.

The first is that a battery-powered device in a humid space needs its seals treated as seriously as its battery. I used to think of the battery as the only thing that wears out. In practice, a tired seal lets in moisture, and moisture damages the contacts, which then looks like a battery problem. Checking both together saves confusion.

The second is that replacing early is cheaper than replacing late. A battery that is replaced before it fails costs very little. A battery that fails mid-cycle can leave a valve partly open, and that creates a mess that takes far longer to sort out.

The third is that the location matters as much as the device. The greenhouse is warm, bright and damp. Each of those conditions is mild by itself, but together they are hard on a black plastic housing and its internals. If I were placing it again, I would shade it from direct sun and keep it off the coldest, dampest surface.

Other lessons I wrote down:

- Keep a log. My memory of when the battery was last changed is unreliable, and the log fixes that.
- Do not open the sealed gearbox in the field. It is tempting, and it has never been the right call.
- Distinguish residue from leaks. Wipe first, then look again after a cycle.
- Test by running the valve, not by looking at it. A unit can look fine and still be too weak to finish a stroke.
- Carry the spare battery every time. The one visit I forgot it cost me a second trip.

## Risks

The main risk is a flat or failing battery leaving the valve stuck in the wrong position. For a cider process, a valve that stays open or closed when it should have moved can spoil product or cause a spill. Scheduled replacement and the full-cycle test on each visit are my main protection against it.

The second risk is moisture. The greenhouse is damp, and the actuator relies on its seal to keep that dampness out. If the seal fails, corrosion on the contacts can cause intermittent behavior, which is harder to diagnose than a clean failure. Intermittent faults are the ones I worry about most, because they pass a quick check and then fail later.

Heat is the third risk. The black housing absorbs sunlight, and over the years that can age the plastic and shorten battery life. I watch for brittleness, warping and discoloration.

Other risks worth keeping in mind:

- A manual override that is stiff or seized would leave me without a fallback if the battery died.
- Sticky cider residue can hide a real leak at the fittings.
- Because the unit was installed in 2020, some parts may be wearing out in ways I cannot see from outside.
- Opening the sealed body in damp air can let moisture in and make things worse.
- Relying on memory, not a log, can cause a missed battery change.

My plan for any of these is the same: catch it early through the routine checks, replace parts before they fail, and keep a spare battery to hand. If the actuator starts to show several of these signs at once, I will treat it as due for replacement and not keep patching it.

## Costs

The Zamathra valve actuator is a black valve actuator that runs on battery power. It was installed in 2020 in the greenhouse, and it supports the cider work. I don't track exact prices here. The notes below only record where the money and effort go, so I can judge whether the unit is still worth keeping.

The biggest running cost is the battery. Because the actuator is battery powered, there is no wiring bill, but I have to buy replacement cells and sometimes lose a day of work when one dies at a bad moment. The greenhouse is humid and swings between warm and cold, which shortens battery life compared with a dry shed.

The second cost is my time. Every check, cleaning and test takes part of an afternoon, and the greenhouse is a bit of a walk from the cider room.

The third cost is spare parts. Seals and the black outer cover are the parts most likely to need replacing, and I would rather keep one spare set on the shelf than wait for a delivery in the middle of a pressing season.

| Cost item | Size | Notes |
|---|---|---|
| Replacement batteries | Recurring, moderate | Humidity in the greenhouse wears them down faster |
| Seals and gaskets | Occasional, small | Check whenever the cover comes off |
| Outer cover | Rare, small | Black plastic fades and cracks in strong sun |
| My time for checks | Recurring, moderate | Mostly cleaning and a movement test |
| Downtime during cider work | Rare, high | The real reason for keeping spares |

If I ever replace the whole unit, the cost of the new actuator would be small next to the cost of a ruined batch, so reliability matters more than the purchase price.

## Setup

This section describes how the actuator is arranged and how I would set it up again from scratch. It has been in place since 2020, so the details come from memory and from the marks I left on the fittings.

The unit is mounted in the greenhouse on the valve it controls. It is black, which helps me spot it among the pale pipes but also means it heats up in direct sun. I keep a piece of shade cloth over it in summer.

Steps I follow when installing or reinstalling:

1. Close the line upstream so nothing flows while the valve is worked on.
2. Check that the valve moves freely by hand before fitting the actuator. If the valve is stiff, the battery will drain quickly.
3. Fit the actuator on the valve stem and tighten the mounting hardware evenly, not one side at a time.
4. Insert fresh batteries last, after everything is mounted, so the unit does not try to move while I am still handling it.
5. Run the valve through a full open and close movement and watch for hesitation or a strange sound.
6. Wipe the housing dry and make sure the cover seal sits flat.

Things I have learned about this location:

- Condensation forms inside the housing if the cover is closed on a damp day. I now close it only when the greenhouse is dry.
- The battery compartment should face down and away from the watering area.
- A label on the pipe showing the open and closed direction saves guessing later.

After setup, I do a second test the next day, because a loose mount often shows itself only after a night of temperature change.

## References

These are the sources I rely on when working with the actuator. Most are my own records rather than published documents.

- The paper card stuck inside the greenhouse door, which lists the valve direction and the battery type in use.
- My photos of the mounting position, taken at installation in 2020. They show how the stem and the bracket line up.
- The maker's printed sheet that came in the box. I keep it in the folder for cider equipment, with the other device papers.
- Notes from the last cider season about when the actuator hesitated and what fixed it.
- My own checklist for the cider room, which includes a line for the greenhouse valve.

Facts about the device, kept here in one place so I don't have to search for them:

| Property | Value |
|---|---|
| Name | Zamathra valve actuator |
| Kind | valve actuator |
| Area | cider |
| Color | black |
| Energy source | battery |
| Year installed | 2020 |
| Location | greenhouse |

Note that the rule of this handbook is one table per note, so the cost summary above is the only other tabular material I would normally keep, and I have folded these facts into plain text elsewhere when possible. If the maker's sheet and my own notes ever disagree, I trust what I observed on the device itself, since the unit has been modified slightly over the years.

## Open questions

These are things I have not settled. I want to answer them before the next busy period.

- How long does a set of batteries really last in the greenhouse? I have only a rough feeling, not a measurement. I should write down the day I fit them and the day they fail.
- Is the black color a problem? In summer the housing gets hot, and I suspect it speeds up the aging of the seals. A lighter cover or permanent shade might help.
- Would a different mounting spot reduce humidity exposure? Moving the unit higher on the pipe might keep it away from the worst of the watering spray.
- Should I add a low battery warning of some kind? At the moment I only find out when the valve fails to move. A simple reminder in my calendar might be enough.
- Is it worth keeping a second actuator as a complete spare, rather than only seals and batteries? That depends on how much a failure during cider work would cost me.
- Does the cold season affect the movement more than I think? I noticed slower action on cold mornings, but I did not record it.
- Has the stem become worn since 2020? I have not measured it, and a worn stem could explain the occasional hesitation.

When I answer any of these I will move the answer into the Setup or Costs sections and delete the question from this list.

## Schedule

This is the routine I try to follow. It is based on the seasons and on the cider work rather than on exact calendar dates, because the cider timing changes every year.

Before the cider season starts:

- Remove the cover, inspect the seals and dry the inside.
- Replace the batteries with fresh ones, even if the old ones still seem fine.
- Run a full open and close test and listen for any grinding.
- Check the mounting hardware and tighten it evenly.
- Confirm the direction label on the pipe is still readable.

During the season:

- Look at the actuator each time I am in the greenhouse. A quick glance for moisture, cracks or a loose mount is enough.
- Test the movement once in the middle of the season, when the weather is at its warmest.
- Keep spare batteries and one set of seals within reach.

After the season:

- Clean the housing and wipe away dust and sap.
- Take out the batteries if the unit will sit unused through winter, to avoid leakage.
- Write down anything that went wrong and add it to the open questions above.

Once a year, I also review this handbook. I read through the costs, check whether the unit is still the right choice for the greenhouse, and decide if the open questions need action. If the actuator keeps failing or the spare parts become hard to find, I will plan a replacement during the quiet months, well away from the cider work.

## Ideas

These are things I want to try with the Zamathra valve actuator, the black battery-powered unit in the greenhouse. None of them are done yet. I will move an idea out of this list once I have tested it and written down what happened.

**Better battery routine.** The actuator runs on a battery, so the most useful improvements are about power. I would like to keep a simple paper log next to the unit. Each time I swap or charge the battery, I write the day and how the valve behaved in the first few cycles afterward. After a season I should see whether the battery fades slowly or drops off suddenly. That tells me how often to check it.

**Cover against condensation.** The greenhouse gets damp, especially in the mornings. The actuator has been there since 2020 and is black, so it also warms up in direct sun. A small shade and drip shield above it might cut both problems. I would test this with a piece of plain board first, before buying or making anything better.

**Marking the valve positions.** I want a small painted mark on the valve body for open, half and closed, so I can see at a glance whether the actuator has done what I asked. Right now I have to look at the handle angle, and that is easy to misread in poor light.

**Check before the cider season.** The actuator is part of my cider work, so a short check before each pressing season would help. The list could be:

- Run the valve fully open and fully closed by hand command.
- Look at the battery contacts for dirt or green corrosion.
- Check that the cable and seals are not cracked.
- Wipe the housing and confirm nothing is blocking the travel.

**Spare plan.** If the unit fails mid-season, I should know what I would do. The easiest fallback is to operate the valve by hand. I should make sure the manual route is never blocked by pipes or crates stored in front of it.

## Safety

The Zamathra valve actuator is a small device, but it sits in a wet place and moves a valve that controls liquid. A few habits keep that safe.

**Moving parts.** The actuator can start without warning when it receives a command. Keep fingers away from the valve linkage while the battery is connected. If I need to work on the valve, I disconnect the battery first, then confirm the actuator is quiet before touching anything.

**Battery handling.** The energy source is a battery. Do not leave it in a hot, sealed space in full sun, because the greenhouse can get very warm. Do not use a battery that is swollen, leaking or has damaged casing. Keep metal tools away from the terminals so nothing shorts across them. Charge or swap the battery in a dry spot, not on the wet greenhouse floor.

**Wet conditions.** Water and electrical parts do not mix well. If the housing is wet, dry it before opening. If there is standing water around the unit, do not work on it until the area is dry. Keep any spare battery stored indoors.

**Liquid in the line.** Because this is part of the cider area, the valve may hold juice or cider. Before taking the valve apart, close upstream flow and release any pressure slowly. Have a bucket ready. Spilled juice on a greenhouse floor is slippery and attracts wasps.

**Cleaning.** Only use mild, food-safe cleaner near the valve. Rinse well. Do not spray water directly at the actuator housing.

**Quick safety table.**

| Situation | What I do |
|---|---|
| Working on the linkage | Disconnect battery first |
| Battery looks swollen | Stop using it, set it aside safely |
| Housing is wet | Dry it before opening |
| Liquid in the line | Close flow, release pressure slowly |
| Floor is sticky or wet | Clean it up before further work |

## Supplies

This section lists what I keep on hand for the Zamathra valve actuator. I only list generic items, since I do not track exact part codes here.

**Power.**
- A spare battery of the type the actuator uses, kept charged and stored indoors.
- A battery charger that I keep in the house, not in the greenhouse.
- A small tin for the old battery until I can dispose of it properly.

**Cleaning and care.**
- Soft cloths and a small brush for the housing and contacts.
- Mild, food-safe cleaner for anything near the cider line.
- A little contact cleaner for the battery terminals.
- Light food-safe grease for the valve stem, used sparingly.

**Tools.**
- A small screwdriver set for the housing screws.
- Pliers for stubborn clips.
- A torch, because the corner where the unit sits is dim.
- A bucket and rags for spills.

**Spares for the weather.**
- Spare cable ties to keep the lead tidy.
- Some self-sealing tape for cable protection.
- A piece of board or plastic sheet to use as a drip shield.

**Notes on buying.** I prefer to buy small quantities and replace them when they are used up. The black housing does not need paint, but if the surface gets scratched, a dab of matching paint stops dirt from collecting. Everything is kept in one box so I can find it fast when the valve misbehaves.

## History

The Zamathra valve actuator was installed in 2020 in the greenhouse. It has been a black, battery-powered valve actuator in the cider area ever since.

**2020: installation.** I put it in during the first year of the greenhouse setup. The idea was to stop walking back and forth to turn the valve by hand. The battery option meant I did not have to run a mains cable through a damp space, which was the main reason I chose it.

**Early use.** In the first seasons the actuator worked quietly, and my main task was learning how long a battery lasted. I noticed that cold mornings made the response slower, and that the unit was more reliable when the battery was freshly charged.

**Later seasons.** Over time I added small habits: wiping the housing, checking the contacts and keeping a spare battery ready. I also learned to keep the manual route to the valve clear.

**Timeline summary.**

| Year | What happened |
|---|---|
| 2020 | Installed in the greenhouse |
| Following seasons | Learned the battery rhythm and cold-morning behavior |
| Recent seasons | Settled into regular checks before pressing |

I do not keep exact dates of every battery swap, which is part of why the paper log in the ideas list appeals to me.

## Background

The Zamathra valve actuator is a device whose kind is valve actuator. Its area is cider, its color is black, its energy source is battery, the year it was installed is 2020, and its location is the greenhouse. Those are the properties I keep in mind whenever I work on it.

**What an actuator does.** A valve actuator is the part that turns a valve for me. Instead of reaching for the handle, I send a command and the actuator moves the valve to the position I want. For a cider setup, that means I can control the flow of juice or cider without standing next to the valve the whole time.

**Why battery power.** The greenhouse is a damp place, and running mains power there needs more care. A battery keeps the installation simple. The trade-off is that I have to watch the charge. A weak battery shows up as slow movement or a valve that does not complete its travel.

**Why the greenhouse.** The greenhouse gives me a sheltered, warm place to work with cider materials. The warmth is useful, but it also means heat and humidity act on the black housing and the battery. That is why shade, drying and regular checks keep coming up in this handbook.

**How it fits with the rest.** The actuator is one small piece in the cider process. It does not make decisions. It does what it is told, so the quality of the result depends on my settings, a healthy battery and a clear path to the valve.

**How I use this handbook.** I read the Safety section before any hands-on work, use Supplies to gather what I need, and add new findings to Ideas and History as I learn. If the unit ever gets replaced, I will keep the old notes so I can compare the next one against how this one behaved.

## Tools

This section lists what I keep within reach when I work on the Zamathra valve actuator. It is a black, battery-powered valve actuator that was installed in 2020 in the greenhouse, and it serves the cider area. Because it sits in a damp, warm room, I try to bring the right tools in one trip instead of walking back and forth.

### Basic kit

I keep this kit in a small plastic box on the shelf near the greenhouse door. Everything in it is for the actuator and nothing else, so I always know where things are.

- A set of small screwdrivers, both flat and cross-head. The cover screws on the actuator are small and the heads strip easily, so I use the exact size and never a near match.
- A pair of long-nose pliers for pulling connectors off without yanking the wires.
- A soft brush, like a clean paintbrush, for removing dust and dried sugar from the housing.
- Lint-free cloths and a spray bottle of clean water. I do not use harsh cleaners on the black casing, because they leave pale marks.
- A headlamp. The valve is low and the corner is dim, even on bright days.
- Nitrile gloves, since I often handle the actuator right after touching cider equipment and I do not want sticky fingers on the electronics.
- A roll of self-amalgamating tape and a few cable ties for tidying and protecting the wiring.
- A permanent marker and a few paper labels.

### Electrical tools

The actuator runs on a battery, so most electrical checks are simple, but I still need a few things.

- A multimeter. I use it to check the battery voltage, both with the actuator idle and while it is moving the valve. A battery that looks fine at rest can sag badly under load, and that is the most common cause of a slow or half-finished stroke.
- A spare set of fresh batteries of the type the actuator takes. I keep them in a sealed bag with a desiccant sachet so they do not get damp.
- A small contact cleaner pen for the battery terminals. Corrosion on the contacts has caused more odd behavior than any real fault in the motor.
- A short test lead with clips, which lets me power the actuator away from its spot if I want to run it on the bench.

### Mechanical tools

- An adjustable spanner and a small set of open-ended spanners for the valve coupling and the mounting bracket.
- A hex key set, because the bracket uses hex bolts.
- A small tube of food-safe grease for the stem. Anything touching the cider side must be food-safe, so I only use that one tube for this job and I keep it separate from general workshop grease.
- A torque screwdriver or a gentle hand. The bracket should be snug, not crushed, as over-tightening can twist the actuator and make the valve bind.
- A set of spare seals and a few spare washers.

### Measuring tools

These are the tools I use for the numbers in the next section.

- A graduated jug, the kind with clear markings in litres, for catching the liquid during a flow test.
- A stopwatch. My phone does the job, but I put it in a zip bag in the greenhouse so it does not get splashed.
- A thermometer, so I can note the temperature of the liquid and the room, because both change how the valve behaves.
- A notebook and pencil. Pencil survives splashes better than pen.
- A small spirit level for checking that the actuator sits straight on the valve.

### Habits that save time

1. Before I open anything, I take a photo of the wiring and the position of the actuator on the valve. It costs nothing and has rescued me more than once.
2. I label every wire I disconnect with a paper label and the marker, even when there are only two wires.
3. I put screws in a small dish, not on the bench, because the greenhouse floor is gravel and a dropped screw is gone.
4. I close the supply to the valve before touching the coupling, and I check by hand that the valve moves freely without the actuator attached.
5. After the job, I wipe the casing down, dry it, and look at the seals again.

### What I do not use

I avoid power tools anywhere near the actuator. I also avoid any spray lubricant, since it can drift onto the cider side and leave a taste. I do not use metal files on the casing, and I do not use anything sharp to pry the cover, because the edge of the black housing chips and lets moisture in.

## Measurements

This section collects the numbers I record for the Zamathra valve actuator, and how I take them. The device is a valve actuator in the cider area, black, battery powered, installed in the greenhouse in 2020. Numbers are only useful if I take them the same way each time, so the method matters as much as the result.

### Flow rate

The flow rate of Zamathra valve actuator is 531.53 l/h. I measured this with the valve fully open, using the graduated jug and the stopwatch from the tool list. I filled the jug for a fixed time, read the volume, and scaled it up to one hour. I repeated the run a few times and compared the results, and they stayed close together. When the number drifts noticeably lower, I first suspect a partly closed valve, a blocked line, or a weak battery that did not finish the stroke.

### How I take a reading

1. Check that the battery is fresh and that the actuator drives the valve all the way open. I listen for the motor to stop on its own.
2. Make sure the supply side is full and nothing upstream has been changed since the last test.
3. Place the jug under the outlet, start the stopwatch the moment liquid enters it, and stop at the planned time.
4. Read the volume at eye level so I do not misjudge the markings.
5. Write down the result along with the liquid temperature and the room temperature.
6. Repeat and compare. If two runs disagree by a lot, I do the test again after checking for air in the line.

### Summary table

This table keeps the main facts and the checks I connect to each one in one place.

| Property | Value | What I check |
|---|---|---|
| Kind | valve actuator | Moves freely, no binding |
| Area | cider | Only food-safe grease and cleaners |
| Color | black | Casing free of chips and cracks |
| Energy source | battery | Voltage at rest and under load |
| Year installed | 2020 | Seals and wiring for age |
| Location | greenhouse | Damp, condensation, heat |
| Flow rate | 531.53 l/h | Repeat the jug test, compare |

### Battery readings

I note the battery voltage in my notebook at each visit, once while the actuator is idle and once during a full stroke. The idle figure alone tells me little. What I watch is the gap between the two. A small gap is healthy. A large gap means the battery is tired, even if the idle reading looks good. I replace the batteries on a routine schedule instead of waiting for a failure, because the greenhouse gets warm in summer and cold in winter, and both shorten battery life.

### Temperature and humidity

The greenhouse is not a stable place. On a sunny day the air gets hot and the casing warms up, and on a cold night there is condensation on everything. I record the room temperature with each flow test, since a warm liquid flows a little differently from a cold one, and the stroke of the actuator can feel slower in the cold. If I see water inside the housing, I stop and dry it fully before measuring anything else.

### Stroke timing

Besides flow, I time how long the actuator takes to move the valve from closed to fully open, and back again. I do this with the same stopwatch. The two times should be close to each other, and they should not change much from one visit to the next. A longer time usually points to one of three things: low battery, stiff stem, or dried grease. I check them in that order because it is the quickest path from cheapest to most work.

### Alignment check

With the spirit level on the actuator body, I confirm that it sits straight on the valve. A slight tilt can put side load on the stem and slow the movement. I record whether it was level, and if I adjust the bracket, I write down what I changed so I can undo it.

### Keeping the log

I keep every measurement in one running list, newest at the top, with the date on each entry in my own notebook format. For each entry I write the flow rate result, the battery readings, the stroke times, and both temperatures. When I look back over the log, I look for slow trends, not single odd results, because one bad reading is often just air in the line or a rushed test.

### Reading the results

- If the flow rate stays near 531.53 l/h and the stroke times are steady, I leave everything alone.
- If the flow is lower but the stroke is normal, I look at the line and the valve itself, not the actuator.
- If the stroke is slow and the flow is lower, I start with the battery, then the stem and grease.
- If readings jump around from visit to visit, I review how I took them before assuming anything is broken.
