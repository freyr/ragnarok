---
type: reference
status: active
project: reference
area: cider
description: "Reference about Partonber level sensor."
---

# Partonber level sensor

## Ideas

These are things I might do with the Partonber level sensor, written down so I stop forgetting them.

- Put a small waterproof label on the housing that says what the sensor measures and which tank it belongs to. The grey housing looks the same as other grey boxes in the yard, and I have mixed them up before.
- Keep a spare battery in a sealed tub in the cider shed, so a flat battery never means a trip to town.
- Add a simple paper checklist, clipped to the shed wall, for the monthly walk-round.
- Compare the sensor's reading against a dip stick every so often. The comparison is the only way I really know whether the sensor has drifted.
- Think about a shade cover. The sensor sits in the yard, and sun on a grey housing warms it more than I like.
- Write the readings into [[Traenzirk level sensor log]] in the same format every time, so I can search them later.
- Look at whether the other level sensors I have tested behave better in cold weather. The notes in [[Bilrendles level sensor tests]] are a starting point.
- Try a different mounting bracket that lets me swing the sensor away from the tank without unscrewing anything.
- Make a short list of what to check after heavy rain.

None of these is urgent. The first two are cheap and would help the most.

## Parts

This section lists what the Partonber level sensor is made of and the basic facts about it.

The basic properties of the device are:

- Name: Partonber level sensor
- Kind: level sensor
- Area: cider
- Color: grey
- Energy source: battery
- Year installed: 2019
- Location: yard

The serial number of the Partonber level sensor is SN-43289572. It is stamped on the underside of the housing, so I have to tilt the unit to read it. I also keep it here because the stamp has gone faint.

Main parts as I understand them:

- **Housing.** A grey, hard plastic case. It is meant to shed rain but I do not trust the lid seal fully.
- **Probe.** The part that reaches toward the liquid and senses the level. It is the part most likely to collect residue from the cider side.
- **Battery compartment.** The sensor runs on a battery, with no mains cable. The compartment is under a small cover held by two screws.
- **Cable gland.** Where the probe lead enters the housing. Check it for cracks.
- **Mounting bracket.** Metal, bolted to a post in the yard.
- **Indicator light.** A small light that blinks when the sensor is awake. I use it as a quick check that the battery is alive.

I did not buy any of these parts separately, so I have no other part numbers to record. If I replace something later, I will note it in the history.

## Safety

Most of the risk with this sensor comes from where it sits and what it is next to, not from the sensor itself.

- **Wet ground.** The yard gets slippery near the tanks. Wear boots with grip when going to check the sensor, especially in autumn when the pressing season starts and the ground is covered in pulp.
- **Ladders and tank tops.** If the probe has to be reached from above, use a ladder that is tied off and have someone nearby. Do not lean over an open tank alone.
- **Fermentation gas.** Cider produces carbon dioxide while it ferments. Never put my head into a closed tank space to look at the probe. Open the area, let it air, and work from outside.
- **Battery handling.** The battery should be swapped with dry hands. Do not leave a spent battery lying around in the yard where rain can reach it, and take it to proper collection.
- **Electrical neighbors.** There are other devices in the yard, including the air compressor described in [[Karkkiork air compressor handbook]]. Keep the sensor lead away from compressor lines and any hot surface.
- **Cleaning chemicals.** The sanitizer I use on the tanks can irritate skin. Wear gloves and rinse the probe with plain water afterward, so no chemical is left to attack the plastic.
- **Do not trust the sensor alone.** A level sensor is a convenience. It must not be the only thing that stops a tank from overfilling. I always look at the level myself before a transfer.

If anything smells wrong or the housing looks swollen, stop and leave the battery out until I understand why.

## History

I installed the Partonber level sensor in 2019. It was one of the first battery-powered devices I put out in the yard for the cider work, and I chose it because I did not want to run a cable across the ground.

The early years went smoothly. The sensor was fixed to a post near the main tank and I wrote down the first readings in a notebook. Later I moved the habit into [[Traenzirk level sensor log]].

Some of the context around that year is in [[Naesnirra Piondgirk notes 2019]]. Those notes describe what else I was setting up at the time and why the yard layout looks the way it does. They also explain why the sensor ended up where it is rather than closer to the shed.

The year before, I had worked on the valve side of the same system, described in [[Fakiosto valve actuator 2018]]. The sensor was meant to complement that: the valve moves liquid and the sensor tells me how much is there. In practice I still do the final decision by hand.

Over the years I have:

- replaced the battery several times, usually after winter;
- re-tightened the bracket after it loosened;
- cleaned the probe each season;
- once moved the sensor slightly to get a steadier reading.

I have never replaced the whole unit, so it is still the same grey device I mounted in 2019.

## Tools

The tools I use for the sensor are ordinary. I keep them together in one tub so I do not hunt for them.

- **Small screwdriver set.** For the battery cover screws. A cross-head one fits best, and a flat one is useful for prying the cover gently.
- **Spanner for the bracket.** The bracket bolts need a standard spanner. I keep it in the tub with a little grease.
- **Soft brush and cloth.** For cleaning the probe without scratching it.
- **Bucket of clean water.** For rinsing after sanitizer.
- **Dip stick.** My manual check. I trust it more than any electronics, which is why it is on this list.
- **Flashlight.** The shed is dim and the indicator light is hard to see in daylight, so I sometimes shade it with my hand.
- **Notebook and pen.** Even though I have the log, the notebook is easier with wet hands.
- **Spare battery in a sealed tub.** Technically a supply, but I keep it with the tools.
- **Marker pen.** For labeling and for writing the date of the last battery change on the cover.

I do not need any special equipment. If the sensor needed a laptop or a cable to set up I would probably have given up on it years ago.

For testing ideas I sometimes borrow a method from [[Riothkren Niordio tests]], where I compared how different sensors reacted when the level changed quickly. It needs only a bucket and a steady hand.

## Observations

These are things I have noticed about the Partonber level sensor from using it in the yard.

- **Battery life varies with the seasons.** The battery seems to run down faster in cold weather. A battery that looks fine in autumn can be weak by late winter.
- **The indicator light is a good early warning.** When the blink gets slow or faint, the battery is close to finished.
- **Residue affects the reading.** If cider film builds up on the probe, the reading drifts. A good clean usually brings it back.
- **Sun and heat.** The grey housing sits in the open yard and warms in strong sun. I have seen no damage, but I do not like it, and the readings feel slightly less steady on hot afternoons.
- **Rain.** After heavy rain I have found a little moisture near the cable gland. It did not get inside, but it is the weak point.
- **Vibration.** When the compressor from [[Karkkiork air compressor handbook]] runs nearby, the post can shake a little. The reading does not seem to change much, but I watch it.
- **Humidity in the shed.** For storing spare batteries and tools, damp is a problem. I have been reading [[Triothkil dehumidifier notes]] to decide whether to dry the shed properly.
- **Agreement with the dip stick.** Most of the time the sensor and the stick agree well enough for my purposes. When they do not, the stick wins.

I compared these observations with the tests in [[Bilrendles level sensor tests]], and the patterns look similar: the problems are mostly about cleaning, power and mounting, not about the sensing itself.

## Costs

I do not remember exact figures, and I do not want to invent any, so this section describes the costs in kind rather than amount.

- **Purchase.** The sensor was a one-time cost in 2019. It was a modest outlay compared with the tanks and the pressing equipment. It paid for itself in avoided trips and in avoided overfills.
- **Batteries.** This is the main running cost. Each year I buy replacement batteries, and I try to buy them in a bundle so the price per battery is lower. Cold winters mean I buy more.
- **Cleaning supplies.** Negligible. Water, a cloth and a brush I already own.
- **Spare parts.** Small items like screws, a new gland seal or a fresh bracket bolt. I only buy these when something breaks.
- **Time.** The biggest cost is my time on the monthly walk-round and the cleaning. It is not much, but it is regular.
- **Cost of not having it.** If I had no sensor I would have to open and check the tank more often, which wastes time and exposes the cider to air.

If I ever want a proper cost record, I will keep receipts in one folder and add a line to [[Traenzirk level sensor log]] each time I buy something. For now the rule is simple: batteries are the thing to budget for, and everything else is small change.

## References

Notes and sources that relate to the Partonber level sensor:

- [[Traenzirk level sensor log]]: my running log of readings and battery changes.
- [[Naesnirra Piondgirk notes 2019]]: background on the year I installed the sensor and how the yard was arranged.
- [[Fakiosto valve actuator 2018]]: the valve work from the year before, which the sensor was meant to go with.
- [[Karkkiork air compressor handbook]]: the compressor that runs in the same yard, relevant to vibration and cable routing.
- [[Triothkil dehumidifier notes]]: ideas for drying the shed where I keep spare batteries and tools.
- [[Bilrendles level sensor tests]]: tests of other level sensors, useful as a comparison.
- [[Riothkren Niordio tests]]: quick tests I borrow methods from when checking how a sensor reacts.

There is no manual for this device in my files, so most of what I know comes from use. If I find the original paperwork, I will add it here and note where I keep it.

## Lessons

What I have learned from living with this sensor:

1. **Check it against something simple.** A dip stick is cheap and does not run out of battery. Use it to keep the sensor honest.
2. **Batteries are the weak link.** The electronics have been reliable. The battery is what fails, and it fails more in cold weather. Change it on a schedule rather than waiting for a flat one.
3. **Clean the probe regularly.** Most odd readings came from residue, not from a fault.
4. **Protect the cable gland.** Water gets in where cables enter. A little care there prevents trouble.
5. **Write things down.** I trust the log more than my memory. The sensor itself says little, so the notes give it context.
6. **Do not rely on one device.** The sensor helps, but the final decision is mine.
7. **Mark the housing.** A grey box in a yard full of grey boxes needs a label.
8. **Keep spares dry.** Damp ruins batteries in storage even when they are new.

If I set up another battery sensor I would do the same things from the start: label it, plan the battery changes, shield it from sun and rain, and compare it with a manual check from the first week.

## Supplies

Supplies I keep for the Partonber level sensor, as a short stock list.

- **Replacement batteries.** The right type for the sensor, kept in a sealed tub in the cider shed. I try to hold at least one spare at all times.
- **Soft cloths.** For wiping the probe and the housing.
- **Clean water.** Always available in the yard for rinsing.
- **Mild sanitizer.** For the tank and the probe, used sparingly and rinsed off.
- **Small spare screws.** For the battery cover. They are tiny and easy to lose in the grass.
- **Spare gland seal or sealant.** For when the cable entry starts to leak.
- **Waterproof labels and a marker.** For identifying the unit and noting the last battery change.
- **Notebook pages.** For jotting readings before they go into the log.
- **Gloves.** For handling sanitizer and for cold mornings.
- **Silica packs or similar drying material.** Dropped into the tub with the spare batteries to fight damp, which ties in with [[Triothkil dehumidifier notes]].

I check the stock at the start of the pressing season and again at the end of winter. If something is low I note it and buy it before I need it.

## Risks

The main risks to the Partonber level sensor and to my work around it.

- **Flat battery at a bad moment.** If the battery dies during a transfer, I lose the reading. Mitigation: change it on schedule and keep a spare.
- **Water ingress.** The housing and gland are the weak points. Mitigation: check after heavy rain and replace seals when they look tired.
- **Sun and heat.** The grey housing in the open yard can overheat. Mitigation: a shade cover, which is still on my ideas list.
- **Residue on the probe.** It can cause false readings. Mitigation: regular cleaning.
- **False confidence.** The biggest risk is trusting the sensor too much and skipping a manual check. Mitigation: always look at the tank before moving liquid.
- **Loose mounting.** Vibration from nearby equipment can loosen the bracket. Mitigation: re-tighten the bolts at each service.
- **Age.** The sensor has been out since 2019, so plastics and seals are getting older. Mitigation: inspect for cracks and brittleness.
- **Lost information.** If the stamped serial number wears off completely, I would depend on this note. That is why it is recorded under Parts.
- **Damp storage.** Spare batteries kept in a damp shed can fail early.

None of these risks is severe if I keep to the routine, but together they explain why I do not let the sensor run unattended for long.

## Maintenance

My routine for keeping the sensor working. I keep it simple so I actually do it.

**Monthly**

- Walk to the yard and look at the sensor and the post.
- Check the indicator light for a healthy blink.
- Compare the reading with the dip stick.
- Look at the cable gland for moisture or cracks.
- Record the reading in [[Traenzirk level sensor log]].

**Each season**

- Take the sensor off the bracket if needed and clean the probe with a soft brush and clean water.
- Rinse off any sanitizer.
- Check the bracket bolts and tighten them.
- Open the battery compartment, look for corrosion, and dry it if damp.
- Test the spare battery.

**Battery changes**

- Change the battery after winter, or sooner if the light looks weak.
- Use dry hands and work out of the rain.
- Write the change on the log and on the cover with the marker.
- Dispose of the old battery properly.

**Yearly**

- Review the housing for cracks or discoloration from sun.
- Replace the gland seal if it looks worn.
- Read through the log to see whether readings have drifted.
- Compare with the findings in [[Bilrendles level sensor tests]] and decide whether the sensor is still good enough.

If something looks wrong and I cannot explain it, I take the battery out, bring the unit to the shed, and look at it in good light before putting it back.

## Open questions

Things I still do not know or have not decided.

- How long will the housing and seals last? The sensor has been outside since 2019, and I do not know how much life is left in the plastic.
- Is a shade cover worth building? I suspect it would help, but I have no proof that heat affects the readings in a way that matters.
- Would a different battery type last longer in winter? I have not tested this.
- Is the reading drift caused by residue alone, or is there a slow change in the probe itself?
- Should I move the sensor to a calmer spot, away from the vibration of the compressor? The notes in [[Karkkiork air compressor handbook]] might help me decide where the compressor lines run.
- Would drying the shed properly, as discussed in [[Triothkil dehumidifier notes]], extend the life of stored spares?
- Is it time to replace the whole unit with something newer, or is the current one good enough for another few years?
- Could I borrow the quick-response tests from [[Riothkren Niordio tests]] to learn how fast this sensor reacts to a sudden change?
- Where is the original paperwork? If it exists, it might answer several of the questions above.

I will come back to this list after the next pressing season and cross off what I have answered.

## Overview

The Partonber level sensor is a level sensor used in the cider area. It is grey, runs on a battery, and has been installed in the yard since 2019. Its serial number, recorded under Parts, is SN-43289572.

Its job is simple: it tells me roughly how full a tank is without my having to open it. It does that job well enough that I rely on it for routine checks, but not so well that I skip a manual look before a transfer. The dip stick remains the final judge.

The sensor's strengths are that it needs no mains cable, it is easy to reach, and it has kept working for years with little fuss. Its weaknesses are the battery, which needs regular attention, the cable gland, which can let in moisture, and the grey housing, which sits in the sun.

Most of what I know about it comes from keeping a log and from comparing it with other sensors. The useful notes are [[Traenzirk level sensor log]], [[Naesnirra Piondgirk notes 2019]], [[Fakiosto valve actuator 2018]] and [[Bilrendles level sensor tests]]. The surrounding yard equipment and shed conditions are covered in [[Karkkiork air compressor handbook]] and [[Triothkil dehumidifier notes]], and quick test methods are in [[Riothkren Niordio tests]].

If I keep to the routine of monthly checks, seasonal cleaning and scheduled battery changes, the sensor should keep serving the cider work for some time yet.
