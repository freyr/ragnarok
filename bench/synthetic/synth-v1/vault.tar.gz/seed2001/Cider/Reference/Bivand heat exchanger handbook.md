---
type: reference
status: active
project: reference
area: cider
description: "Reference about Bivand heat exchanger."
---

# Bivand heat exchanger handbook

## Safety

The Bivand heat exchanger is a green heat exchanger that I use for the cider work. It has been installed in the greenhouse since 2023, and it runs on a battery. These notes are for me, so they are blunt. Read this section before touching the unit, even if the job looks small.

### Hazards that come from the battery

The energy source is a battery, and that changes how I think about isolation. There is no mains plug to pull out. The unit can wake up and move liquid whenever the battery is connected and the control side calls for heat. So the first rule is to disconnect the battery before opening any panel, and to keep the battery terminals covered while I work.

- Disconnect the battery first, then wait until the pump has fully stopped.
- Never lay a metal tool across the battery terminals. A greenhouse bench is full of wire, clips and spare fittings, and any of them can bridge a terminal.
- Keep the battery dry. The greenhouse is humid and condensation forms on cold mornings. A damp terminal causes corrosion and, worse, creeping leakage.
- If the battery case is swollen, hot, or smells sharp, leave it alone, ventilate the greenhouse, and move it outside onto bare ground using gloves.
- Charge it only in a spot with nothing flammable nearby. Dry straw, plant netting and cardboard all collect near the greenhouse door.

### Hazards that come from the liquids

The exchanger carries warm liquid on one side and cider-side liquid on the other. Both can hurt me in different ways.

- Hot surfaces: the green casing looks harmless, but the inlet side gets properly hot. I touch pipes with the back of a gloved hand first.
- Pressure: always release pressure at the bleed point before loosening a clamp. A clamp that sprays warm liquid at face height is a quick way to ruin a day.
- Sugar and slip: cider residue is sticky, and a spill on the greenhouse floor turns into a skating rink once it mixes with damp soil. Wipe up straight away.
- Cleaning chemicals: I rinse with clean water after any sanitiser. I never mix sanitiser products, and I keep the greenhouse door and vents open when I use them.

### Hazards that come from the place

A greenhouse is not a workshop. Glass breaks, floors are uneven, and the temperature swings wildly.

- On sunny days the air inside gets hot very fast, so I schedule heavy work for the early morning and take water with me.
- I keep a clear path from the unit to the door. Hoses and cable runs stay along the wall, never across the walkway.
- I do not work alone on anything that needs a ladder or involves lifting the exchanger body.
- A small first aid kit lives on the hook by the door. I check it when I do the seasonal review.

### When to stop

I stop and ask for a second opinion if any of these happen:

1. The unit is warm, but the pump is silent.
2. I see liquid where there should be none, especially near the battery.
3. The casing has a new dent or a crack in the green paint that reaches the metal.
4. Anything smells burnt.

If the pump, valves or air supply seem to be at fault rather than the exchanger itself, the related notes are [[Zamathra valve actuator handbook]] for valve problems and [[Rindtrith air compressor]] for anything that involves the compressed air line near the cider side.

## Setup

This section records how the Bivand heat exchanger was put in and how I would set it up again from scratch. The key facts: it is a heat exchanger, the area is cider, the color is green, the energy source is battery, it was installed in 2023, and it sits in the greenhouse.

### Position in the greenhouse

I chose the spot for the unit in 2023 after walking the greenhouse and checking where the warm air collects. The exchanger sits low and close to the cider-side lines so the runs stay short. Short runs lose less heat, and they also mean fewer joints to leak.

The reasoning behind the location is partly in my older planning notes, in [[Kulpoth workshop plan 2020]], where I first sketched how work would move between the greenhouse and the rest of the site. The plan changed a lot, but the idea of keeping cider-related equipment near one wall stayed.

Things I look for in a position:

- A solid, level base that does not flex when I lean on it.
- Shade from direct midday sun, so the battery does not cook.
- Space on all sides to open a panel and reach the fittings.
- A drip path that leads away from the battery, never toward it.
- Distance from the planting beds, so splashes of cleaning water do not reach the plants.

### Mounting and connections

The unit is green, which is useful: it stands out against the grey frames and I can find it quickly in poor light. I mount it with the flow direction marked clearly on the body. The connection order I follow is:

1. Fix the body in place and check it with a level.
2. Attach the cider-side lines first, hand-tight, then snug with a tool.
3. Attach the warm-side lines.
4. Fit the bleed point at the highest position so trapped air can escape.
5. Only after all lines are on, bring the battery to the unit and connect it.

I leave the battery for last on purpose. It keeps the unit dead while I am working with my hands near the fittings.

### Battery arrangement

Because the energy source is a battery, I treat power as part of the setup rather than an afterthought.

- The battery sits on a raised shelf, off the floor, with a small lip so it cannot slide.
- Cable runs are clipped and have a little slack at each end so vibration does not pull on the terminals.
- I label the battery with a plain sticker saying which unit it serves, so it does not get borrowed for something else.
- I keep a spare charged battery of the same kind in a dry cupboard, not in the greenhouse.

### First start

At first start I go slowly. I fill the loops, bleed the air, connect the battery, and watch for a few minutes with my hand near the isolation point. I check for leaks at every joint, listen for a rough pump, and feel the pipes gradually warm. If the cider-side flow looks weak, I check for trapped air before I suspect anything else.

For anything involving controlled heating cycles elsewhere on site, my notes on the [[Vaebio kiln controller]] show how I log settings, and I copy the same habit here: write down what the unit is doing on the first day, so later changes have something to be compared with.

### Things I would change

If I did the setup again, I would put in a proper shut-off at both ends of the unit so it can be taken off without draining the whole loop. I would also add a drip tray under the fittings and mount the battery shelf a little higher.

## Schedule

The schedule keeps the Bivand heat exchanger working in the greenhouse. I keep it simple because simple schedules actually get done. The unit is battery powered, so a lot of the routine is about the battery and about keeping the green casing clean and dry.

### Every time I use it

- Look at the unit and the floor beneath it for drips.
- Check that the battery is secure, dry and connected firmly.
- Feel the casing for unusual heat.
- Listen to the pump for a few moments after start.

### Weekly

- Wipe the casing and the fittings, and dry the area around them.
- Look over the cider-side connections for sticky residue, which is the first sign of a slow leak.
- Check the battery charge level and top it up if it is lower than I like.
- Make sure the vents in the greenhouse are not blocked, because heat builds up quickly in a closed space.

### Monthly

- Open the access panel with the battery disconnected, and check the inside for moisture and dust.
- Test the bleed point and let out any trapped air.
- Check clamps and clips, and tighten any that have crept loose.
- Clean the battery terminals gently and check for corrosion.
- Rinse the cider side with clean water after sanitising, and note anything that looks cloudy or slimy.

### Seasonal

Seasons matter a lot in a greenhouse, so I review the unit when the weather changes.

- Before the cold season: check that the warm-side liquid is at the right strength and that nothing can freeze at night.
- Before the hot season: move or shade the battery if the afternoon sun reaches it, and check that vents work.
- Look for scale on the warm side. My notes in [[Glaelbrath scale study]] explain what I found when I compared scaling in different water, and why I now prefer to treat water before it enters the loop.
- Walk through the safety list again and replace anything in the first aid kit that is used or out of date.

### Yearly

Each year, around the anniversary of the 2023 installation, I do a longer review:

1. Disconnect the battery and drain what needs draining.
2. Inspect every hose and replace any that feel stiff, cracked or soft.
3. Check the mounting base and the shelf under the battery.
4. Judge whether the battery still holds enough charge for a normal working session, and plan a replacement if not.
5. Record the condition of the green paint and touch up any chips so the metal stays covered.

### Who helps

For jobs that need two people, I ask [[Zorzaerk Lirfu]], who knows the cider side of the process better than I do. For bigger repairs or for building a replacement fitting, I take the parts to the [[Paeszio workshop]], where there is a proper bench and the right tools.

### Keeping the log

After every scheduled task I add one line to the log: what I did, what I saw, and what I want to look at next time. A log that says "all fine" is still useful, because it shows when the last fine day was.

## References

These are the notes and sources I keep connected to this handbook. Each link goes to another note in the knowledge base.

### Related notes

- [[Glaelbrath scale study]]: my comparison of scale build-up on the warm side, used when I decide how often to clean and how to treat the water.
- [[Zorzaerk Lirfu]]: the person I go to for cider-side questions and for help with jobs that need two pairs of hands.
- [[Kulpoth workshop plan 2020]]: the early layout plan that led to keeping cider equipment together, which influenced the choice of the greenhouse location.
- [[Paeszio workshop]]: where I take parts that need cutting, fitting or testing on a bench.
- [[Zamathra valve actuator handbook]]: the reference for the valves connected to the exchanger, useful when flow is wrong but the exchanger seems fine.
- [[Vaebio kiln controller]]: a different device whose logging habits I borrowed for this unit.
- [[Rindtrith air compressor]]: the compressed air source I check when air lines near the cider side behave oddly.

### Facts about the unit, in one place

- Name: Bivand heat exchanger
- Kind: heat exchanger
- Area: cider
- Color: green
- Energy source: battery
- Year installed: 2023
- Location: greenhouse

### How I use these references

When something goes wrong, I start with the Safety section, then follow the symptom to the right note. A weak flow usually points to [[Zamathra valve actuator handbook]] or to scale, which sends me to [[Glaelbrath scale study]]. Air problems send me to [[Rindtrith air compressor]]. If the problem needs a bench, the answer is the [[Paeszio workshop]]. If I am unsure about the cider process rather than the machine, I talk to [[Zorzaerk Lirfu]].

I add new links here whenever a repair or a question leads me to a note that I would want to find again.

## Background

The Bivand heat exchanger is a heat exchanger that I use for cider work. It is green, runs on a battery, and has been installed in the greenhouse since 2023. Those are the basic properties, and I repeat them here so this section can be read alone: kind is heat exchanger, area is cider, color is green, energy source is battery, year installed is 2023, location is greenhouse.

The reason it sits in a greenhouse is practical. The greenhouse is the one building where I can hold a steady, mild temperature through the pressing season without running a long power cable. Cider must is sensitive to temperature. If it gets too warm too early, fermentation starts before I am ready. If it stays too cold, it stalls. The exchanger moves heat between the juice loop and a water loop, so I can bring the juice toward the temperature I want without exposing it to a direct heating element.

The battery supply is the feature I care about most. Because the unit runs on a battery, the pump and the small control board keep working even when the greenhouse circuit is switched off for the night or tripped by damp. This was the main reason I chose it over a mains-powered unit. The trade-off is that I have to watch the battery and keep it charged, which is covered in the later sections.

The green color is only a finish, but it is useful. In a greenhouse full of plants, hoses, crates and tubs, a green casing blends in, and I have more than once lost sight of it behind foliage. I now keep a strip of pale tape on the handle so I can find it quickly.

For anyone reading this handbook later, including me, the practical way to think about it is as a small, self-contained thermal helper. It does not make heat by itself in any large way. It transfers heat from one loop to the other, and the battery only drives the pump and controls. Most of my troubleshooting comes down to flow, not heat output.

I keep the unit on a low bench near the juice tubs, with the water loop hoses running along the floor to the warm-water source. The layout has changed a little over time, but the unit itself has stayed in the same place.

## Risks

The risks fall into four groups: battery, moisture, contamination and temperature.

**Battery.** The battery is the single point of failure. If it runs flat during a batch, the pump stops and the juice loop sits still. In a cold spell that means the juice cools unevenly, and in a warm spell it means a warm pocket can form near the inlet. I treat a low battery as a reason to stop and recharge before starting any new transfer. I also avoid leaving the battery fully drained over the quiet months, because that shortens its life.

**Moisture.** A greenhouse is humid, and the control board is the part that dislikes it most. Condensation forms on cool surfaces in the morning and can drip onto the casing. I keep the board side facing away from the vents and the watering area. If I see droplets near the connectors, I dry them before switching anything on. The green casing is sealed reasonably well, but I do not trust it to survive a direct spray.

**Contamination.** Because the exchanger touches cider juice, it has to be kept clean. Sugar residue left inside will feed yeast and bacteria, and a sour smell is the first sign. The risk is higher in the greenhouse because warm air helps microbes grow. I rinse the juice loop with clean water after every use and sanitize it before the next batch. I never run the water loop and juice loop with the same hoses, and I mark the hoses so I do not mix them up.

**Temperature.** The exchanger can move too much heat too fast if the warm-water source is set high. Overheated juice loses aroma and can start unwanted reactions. I keep the warm side modest and make small adjustments, then wait and check before changing anything again. I also avoid placing the unit in direct afternoon sun, since the greenhouse glass concentrates heat and the casing can get hot enough to be uncomfortable to touch.

A smaller risk is simple handling. The unit is not very heavy, but the hoses can trip me on the floor, and a pulled hose can spill juice. I try to route the hoses along one wall and clip them in place.

## History

The Bivand heat exchanger was installed in 2023. Before that, I warmed juice by standing tubs in warm water and stirring by hand, which worked but was slow and uneven. After a couple of seasons of that, I decided to set up something more controlled.

The first season with the exchanger was mostly learning. I did not yet know how long the battery would last, so I kept a charger nearby and checked the level often. I also found that the original hose routing was poor. The hoses crossed the walkway and I kicked one loose during a busy day. I rearranged them after that and have kept the new layout since.

In the early period I also had to learn the right flow rate. Running the pump at its fastest setting seemed sensible, but it did not help. The juice passed through too quickly to pick up much heat. A slower, steady flow gave a much more even result. That lesson changed how I use it more than anything else.

Over the following seasons I made small changes rather than big ones. I added the pale tape on the handle. I made a simple shelf to lift the battery off the damp floor. I started writing down the settings I used for each batch, so I could repeat a good result or avoid a bad one. These notes are the source of much of what is in this handbook.

There have been no major repairs. The most significant maintenance has been replacing worn hose clamps and renewing the battery connection after some corrosion showed up on one terminal. I cleaned it and added a thin protective coating, and the problem has not returned.

The unit has stayed in the greenhouse the whole time. I have thought about moving it to a shed for the winter, but the greenhouse gives me the steady conditions I want during the pressing season, so I have kept it there and simply protected it better.

## Observations

These are the things I have noticed from using the exchanger, written as plain working notes.

The unit performs best when the two loops are balanced. If the water loop is much warmer than the juice, the juice near the inlet warms faster than the rest, and I get uneven temperature in the tub. Keeping the difference small gives a smoother result, even though it takes longer.

The battery lasts well through a normal working session, but it does not like being pushed. If I run the pump hard for a long time, the level drops faster than I expect. I now plan sessions with a margin and do not start a long transfer on a partly charged battery.

Mornings in the greenhouse are the most reliable time to work. The air is cooler and steadier, and the unit does not have to fight the afternoon heat. By late afternoon on a sunny day, the greenhouse can be warm enough that the juice gains heat on its own, and the exchanger is then more useful for cooling than warming. I have used it that way a few times by running cooler water through the other loop.

I have noticed that the sound of the pump is a good indicator. A steady, quiet hum means all is well. A rattle or a rising pitch usually means air in the line or a partly blocked hose. Bleeding the air out and checking the hoses fixes it most of the time.

Cleaning is easier when done right away. If I wait until the next day, the residue dries and takes longer to rinse. A quick flush at the end of the session saves a lot of effort.

The green casing has held up well against the humidity. It shows some marks and a few light stains, but nothing structural. The handle tape needs replacing now and then because it peels in the damp.

One last practical habit: before each session I check four things in the same order. I look at the battery level, the hose connections, the cleanliness of the juice loop, and the temperature of the warm-water source. If all four are fine, the session usually goes without trouble.

## Checklist

This is the routine I follow for the Bivand heat exchanger. It is a green unit that runs on battery power, and it has been installed in the greenhouse since 2023. I use it in the cider work, so the checks lean toward keeping the liquid side clean and the battery side dry.

**Before each session**

- Look at the unit from a few steps back. The green casing should be dry, with no drips underneath and no condensation pooled on the shelf.
- Check that the battery is seated firmly and the contacts are clean and dull, not white or crusty.
- Confirm the battery indicator shows enough charge for the whole session. If I am unsure, I swap in the charged spare rather than gamble.
- Open both hose connections and look at the sealing faces. They should be smooth and free of grit.
- Run a short flush of clean water through the liquid side to make sure nothing is blocked.
- Read the greenhouse conditions. On a very hot afternoon the exchanger works harder, so I plan to take more breaks.

**During a session**

- Watch the flow by eye at the start. If it sputters, stop and look for an air pocket.
- Touch the casing near the inlet and the outlet. A clear difference between them means it is working. No difference means something is wrong.
- Keep the cider lines off the floor, because the greenhouse floor collects dust and wet leaves.
- Listen for any change in the pump note. A rising whine usually means a restriction.

**After each session**

- Flush with clean water, then drain as much as possible.
- Wipe the casing, the hose ends, and the battery compartment lid.
- Remove the battery if the unit will sit idle for more than a few days.
- Write a one-line entry in the logbook: what was run, anything odd, and the battery state at the end.
- Leave the compartment lid slightly ajar so air can move through.

**Seasonal**

- At the start of the cider season, do a full sanitizing cycle and inspect every gasket.
- At the end of the season, flush, sanitize, dry fully, and store the battery indoors at a partial charge.
- Once a year, compare the unit with the notes from 2023 to see whether the performance has drifted.

## Supplies

Everything here lives in a lidded tub on the shelf beside the unit in the greenhouse. I keep the tub stocked so a bad day does not turn into a lost afternoon.

**Cleaning and sanitizing**

- Food-safe cleaner suited to cider equipment, kept in its original labeled bottle.
- No-rinse sanitizer, mixed fresh for each use and never stored diluted.
- Soft brushes in two sizes, one for the hose ends and one for the casing.
- Lint-free cloths, a stack of them, because damp cloths in a greenhouse go musty fast.
- A small jug that I use only for clean flush water.

**Spare parts**

- A full set of replacement gaskets for the hose connections.
- Two spare hose clamps.
- A short length of food-grade tubing for quick repairs.
- A spare fuse for the battery lead, labeled and taped inside the lid of the tub.
- A charged spare battery, rotated with the one in use so neither sits flat.

**Battery care**

- The matching charger, kept on a dry high shelf away from the watering area.
- A small tube of contact protector for the battery terminals.
- A dry cloth reserved for the terminals alone.
- A marker and tape to write the date I last charged each battery.

**Tools**

- A screwdriver set that fits the access panel.
- Pliers with a soft grip.
- A flashlight, since the greenhouse corner behind the unit is dim in the evening.
- A basic multimeter for checking battery voltage when the indicator seems off.

**Record keeping**

- The logbook, a plain notebook in a zip bag.
- A pencil, because ink runs when the bag gets damp.
- A few spare sheets for sketching hose layouts when I change the setup.

**Things I do not keep in the tub**

- Harsh solvents or anything scented, since they can taint cider.
- Metal scouring pads, which scratch the surfaces and leave traces behind.
- Old rags that have touched fertilizer or plant treatments.

## Ideas

These are things I might try with the Bivand heat exchanger. None of them is done yet, and I mark each one as it moves from a thought to a trial.

**Placement**

- Shift the unit a little further from the greenhouse glass. In summer, the sun on the green casing makes it hotter than I like, and a bit of shade might help the battery too.
- Build a simple raised platform so the unit sits clear of any splashes on the floor.
- Try a small reflective screen on the sunniest side and see whether it changes how long the battery lasts.

**Battery**

- Keep a better rotation chart so each battery gets used evenly.
- Look at whether a second charging spot near the potting bench would save me walking back and forth.
- Test how the battery behaves on a cold morning compared with a warm afternoon, and write the results down in plain words.

**Workflow**

- Make a laminated one-page version of the checklist and hang it next to the unit.
- Color-code the hoses so inlet and outlet can never be mixed up. Green is already taken by the casing, so I would pick two other colors.
- Set up a small hook board for hoses, so they dry in the air instead of curling in a bucket.
- Write a short start-up routine for visitors who help during the cider pressing.

**Observation**

- Keep a simple comparison log of how fast the liquid reaches the target condition on different days.
- Note which kinds of batches foul the unit fastest, and whether a pre-strain helps.
- Take a photo of the casing and the gaskets each season, so wear is easier to judge than from memory.

**Maintenance**

- Replace the gaskets on a schedule rather than waiting for a leak.
- Check whether a drip tray under the hose connections would catch small leaks early.
- Look for a more breathable cover to protect the unit during the months it is idle.

**Bigger thoughts**

- Consider whether a second unit would make sense, or whether one well-kept exchanger is enough for the scale I work at.
- Think about whether the greenhouse is truly the best location, or whether a shaded corner of another building would be calmer for the equipment.

## Overview

This part is the short factual summary that the rest of the handbook leans on, so I can find the basics in a few seconds.

The subject is the Bivand heat exchanger. Its kind is heat exchanger, and its role is in the cider work. The casing is green. It runs on battery power, not on mains electricity, which is why the battery routines in the checklist matter so much. It was installed in 2023, and it is located in the greenhouse.

**What that means in practice**

- Because the energy source is a battery, the unit does not depend on a socket. I can place it where the work is. The cost is that I have to watch charge levels and keep spares ready.
- Because it sits in the greenhouse, it deals with humidity, warmth, dust, and swings in temperature. Most of my care routines are about those four things.
- Because it was installed in 2023, it has been through several seasons. That is long enough for gaskets to wear and for habits to form, so I treat the older notes as a baseline rather than as a promise.
- Because it is green, it is easy to spot among the pots and crates. That is useful, but it also means I should not let it get buried under plant material.

**How the parts of this handbook fit together**

- The checklist is what I do before, during, and after use, and once a season.
- The supplies list says what I keep on hand so routine care never stalls.
- The ideas list holds possible improvements that I have not committed to.
- This overview holds the fixed facts about the unit and what they imply.

**Reading tips for future me**

- If something seems wrong, begin with the battery, then the hose seals, then the flow. Those three account for most of my past problems.
- If the greenhouse has been very hot or very damp, extend the drying step after each session.
- If I change the setup, update the logbook first and this overview afterward, so the facts stay trustworthy.

I treat this section as the anchor for the note. When the other sections drift, the facts here are what I check them against: a green battery-powered heat exchanger, installed in 2023, working in the greenhouse for the cider.

## Open questions

These are the things I still cannot answer about the Bivand heat exchanger. I keep them here so I do not pretend later that I knew them.

**Battery life across a full season.** The unit runs on a battery, and it has been in the greenhouse since 2023. I have a rough feel for how often the battery needs attention, but I have never tracked it across a complete cider season from first pressing to the last racking. I do not know whether the drop in runtime I noticed last autumn was age or just the cold nights. I want to log the charge state at the same time every week and see what the pattern looks like.

**Effect of greenhouse temperature swings.** The greenhouse gets very warm on sunny afternoons and cools quickly after dusk. I do not know how much of that swing the green housing of the exchanger absorbs, or whether the colour matters at all. I suspect the paint is cosmetic, but I have not tested it. A shade cloth over the unit for one month would answer part of this.

**Whether the battery should stay installed over winter.** Some people take the battery out and keep it indoors. I have left it in place, and nothing bad has happened yet. I do not know if I am shortening its life. I need to find out what the maker recommends for storage and whether a partial charge is better than a full one.

**Cleaning interval.** I clean the exchanger when the flow looks sluggish, which is a poor rule. A fixed interval would be better. I do not yet know what the right interval is for sweet juice versus fermented cider, because the fouling is clearly different. Sugar residue is sticky, while fermented product leaves a thinner film.

**Replacement parts.** I have not confirmed whether gaskets and seals can be bought from anyone other than the original supplier. If the supplier disappears, I would be stuck. I should ask around and note the answer here.

**Sizing for a bigger batch.** If I ever double the volume of juice, will this exchanger keep up? I have a guess, but no measurement. I would need to time how long it takes to bring a known amount of liquid down to the target temperature, then compare that with a larger run.

**Sensor accuracy.** The temperature readings seem sensible, but I have only checked them against one kitchen thermometer. I do not know if the built-in reading drifts. A proper check against an ice bath and a warm water bath would settle it.

## Tools

This section lists what I actually use when I work on the exchanger, and what each item is for. Nothing here is fancy.

**Soft brush set.** A small bottle brush and a flat nylon brush. The bottle brush fits the narrow passages, and the flat one handles the outer plates. I avoid wire brushes, because they scratch the surfaces and make fouling worse later.

**Food-safe cleaner and a clean bucket.** I use a cleaner meant for cider equipment, mixed according to its label. The bucket is kept only for this job so that nothing else gets into the exchanger. After cleaning I rinse with plenty of clean water until there is no smell left.

**Spare hoses and clamps.** I keep a couple of spare lengths of food-grade hose and a few clamps. Hoses go stiff in the greenhouse heat over the years, so having spares saves a trip. I check each clamp whenever I disconnect anything.

**Probe thermometer.** A separate thermometer, not the one built into the unit. I use it to cross-check the readings at the inlet and outlet. It is the only way I have to tell whether the unit is doing its job or just looks like it is.

**Multimeter.** Used for the battery. I measure the voltage at rest, after a full charge, and again after a working session. I write the readings in my log so I can see the trend. A multimeter is cheap and tells me far more than a glance at the indicator light.

**Battery charger.** The one that matches the battery type. I do not use a different charger, even if the plug fits. I charge it indoors, away from the damp of the greenhouse.

**Basic hand tools.** A screwdriver set, a small adjustable spanner and a pair of pliers. These cover almost everything when I take the unit apart for cleaning. I lay the parts out on a clean cloth in the order they came off, which avoids confusion at reassembly.

**Torch.** The greenhouse is dim in the evening, and the underside of the exchanger is dark at any time. A head torch keeps both hands free.

**Notebook and pen.** I write down every cleaning, every battery check and every odd behaviour. Memory is not reliable over a season, and the notes are what I use to fill in the questions above.

**Spare gloves and cloths.** Plain, but they keep the work tidy. Clean cloths also help me spot leaks, since a drip shows up quickly on a white cloth.

## Problems

These are the faults I have actually met with the Bivand heat exchanger, with what I did about them. I describe the symptom first, because that is what I notice before I know the cause.

**Sluggish flow.** The most common issue. The liquid comes through more slowly than usual and the outlet temperature is off. The cause has nearly always been residue building up inside, especially after sweet juice. The fix is a proper clean with the brushes and cleaner, followed by a long rinse. If flow is still weak afterwards, I check the hoses for kinks or soft spots before blaming the exchanger.

**Battery running down early.** Some days the unit stops sooner than I expect. Cold nights seem to make it worse. Charging fully before each session helped, and so did bringing the battery indoors overnight. If the voltage at rest is low even after a full charge, the battery is probably tired and will need replacing. So far it has not reached that point, but I am watching it.

**Condensation inside the greenhouse.** The greenhouse is humid, and water collects on the green housing and around the connections. I worried about the electrical parts. So far the damp has stayed on the outside. I now wipe the unit down after each session and keep the battery contacts dry. I also try to keep the unit off the floor, where moisture is worst.

**Small leaks at connections.** Twice a clamp has loosened and caused a slow drip. Heat cycling in the greenhouse seems to loosen them over time. I now check every clamp at the start of a session. A drip is not dangerous, but it wastes product and makes a sticky mess that attracts insects.

**Temperature readings that do not match.** On one occasion the unit's reading was clearly different from my probe thermometer. Cleaning the sensor area fixed most of it, since a film of residue was insulating it. I now compare both readings routinely. If they differ by more than I am comfortable with, I stop and clean before continuing.

**Stiff hoses.** After a couple of seasons in the heat, some hoses went hard and cracked at the ends. I replaced them with new food-grade hose. I now inspect them every autumn and replace any that no longer bend easily.

**Sticky residue after a long break.** If I leave the unit for weeks without cleaning, the residue sets hard and is much more work to remove. Soaking in warm cleaner solution for a while helps more than scrubbing. The lesson is simple: never put it away dirty.

**Dust and insects.** The greenhouse brings in dust, spiders and small flies. They get into open ends and hose connections. I cap the openings between uses with clean covers, and that has solved it.

## Lessons

These are the practical rules I have settled on after using the exchanger since 2023. They are short on purpose, because I want to be able to read them quickly before a session.

**Clean right after use.** The easiest cleaning is the one done the same day. Sugar and fermented residue both become far harder to remove once dry. A short rinse straight after use saves a long scrub later.

**Never trust one thermometer.** The built-in reading is useful, but I always cross-check it with the probe. Two readings that agree give me confidence, and two that disagree tell me something needs attention.

**Treat the battery as the weak point.** Almost every interruption I have had traced back to the battery or to cold. Charge it fully before work, store it indoors when I can, and measure it with the multimeter now and then. A written log of readings beats guessing.

**Keep moisture out of the electrical side.** The greenhouse is damp, so I wipe the unit down, keep the contacts dry and avoid setting it on wet ground. This costs a minute and has avoided any real trouble.

**Check clamps and hoses at the start, not the end.** Finding a loose clamp before the liquid is flowing is much better than finding it afterwards. I look over every connection and every hose as a habit.

**Use gentle tools only.** Soft brushes and a suitable cleaner are enough. Harsh tools scratch the surfaces, and scratches hold residue, so the problem returns faster.

**Keep spares of the cheap parts.** Hoses, clamps and cloths are inexpensive and easy to lose track of. Having them on hand means a small fault does not stop the whole day.

**Write things down.** The open questions at the top of this note exist because I did not record enough early on. A simple log of cleaning dates, battery readings and odd behaviour would have answered most of them already. From now on every session gets a line in the notebook.

**Do not rush the reassembly.** Laying the parts out in order and refitting them calmly prevents mistakes. Rushed reassembly was behind my worst leak.

**Cover the openings.** Between uses, I cap the ends so dust and insects stay out. It is a small habit that keeps the next cleaning shorter.

**Review once a year.** Each autumn, before the cider work begins, I go over the whole unit: hoses, clamps, battery, sensor and housing. Doing it as a fixed routine means I catch ageing parts before they fail in the middle of a batch. After that review, I update this note with whatever I learned, so the handbook stays honest and useful.

## Parts

This section lists what the Bivand heat exchanger is made of, what each part does, and what I check on it. The whole unit is a green heat exchanger used in the cider area. It was installed in 2023 in the greenhouse, and it runs on battery power. The part number of the Bivand heat exchanger is LC-3853-Z. I use that number whenever I need to describe the unit to a supplier or look for a matching replacement.

### How the unit is put together

The Bivand is a compact unit. Everything sits in one green housing, which makes it easy to spot among the pipes and crates in the greenhouse. The housing is not just for looks. It keeps moisture and dust away from the working parts, and the greenhouse has plenty of both. The main parts, from the outside in, are:

- the green outer housing
- the core, where heat passes from one liquid to the other
- the inlet and outlet connections
- the battery pack and its holder
- the small pump and control board
- the temperature probes

I describe each of these below, in the order I would inspect them.

### Outer housing

The housing is green and made of coated metal panels. The panels are held on with screws, and I can take them off with a basic screwdriver. The coating is the first thing to suffer in a greenhouse, because humidity is high and the temperature swings during the day. Every time I open the unit I look for:

- chips in the green coating, especially near the screws
- rust spots at the bottom edge, where water collects
- panels that no longer sit flat
- dust or leaf debris against the vents

If I see a chip, I touch it up the same day. Rust that is left alone spreads under the coating and is much harder to deal with later.

### Core

The core is the heart of the Bivand. This is where the warm liquid and the cold liquid pass close to each other without mixing. In my cider work, the aim is to move heat in or out of the liquid without adding anything to it, so the separation inside the core matters a lot.

What I keep in mind about the core:

- It is the part most likely to foul. Sugar residue and fine sediment settle on the inside walls over time.
- A fouled core transfers heat more slowly, so the unit has to work harder and drains the battery faster.
- The core should never be cleaned with anything harsh. I use only warm water and a mild food-safe cleaner, and I rinse until the water runs clear.
- If one side of the core ever leaks into the other, the unit comes out of service at once.

A simple sign that the core needs cleaning is a growing gap between the temperature going in and the temperature coming out. When that gap shrinks compared with what I normally see, I clean the core.

### Inlet and outlet connections

There are two pairs of connections, one pair for each liquid. Each pair has an inlet and an outlet. I label them with tape on the pipes so I never swap them by mistake. Swapping an inlet and an outlet will not usually break anything, but it changes the way the unit behaves and gives confusing readings.

Things I check on the connections:

- The clamps are tight but not crushed.
- No drips are forming at the joints.
- The hoses are not kinked or stretched.
- The hose material is still flexible and not cracked from the greenhouse heat.

Because the greenhouse warms up so much, hoses age faster here than they would in a cellar. I replace any hose that has gone stiff, even if it has not leaked yet.

### Battery pack and holder

The energy source of the Bivand is a battery. There is no mains connection, which is a big part of why it suits the greenhouse: no cable needs to run through the damp. The battery sits in its own holder inside the housing, separate from the liquid parts.

Rules I follow for the battery:

- Keep the holder dry. If I find moisture in it, I find the source before doing anything else.
- Check that the contacts are clean and bright. Dull or greenish contacts get wiped clean.
- Do not leave a flat battery in the unit for long periods.
- Watch the charge level more closely in summer, when the greenhouse is hot, because heat shortens the time the battery holds its charge.
- Keep a charged spare ready, so a swap takes minutes rather than a day.

Since the unit was installed in 2023, the battery is the part I have had to pay the most attention to. The liquid side has been steady, while the battery needs regular care. A battery that has been through several seasons will hold less than a new one, so I treat a shorter running time as a normal sign of age, not a fault in the unit.

### Pump and control board

A small pump moves the liquid through one side of the core, and a control board decides when the pump runs. The board reads the temperature probes and adjusts the pump to keep the result steady. Both parts draw power from the battery.

Notes on these two:

- The pump should run quietly. A rattle or whine usually means air in the line or a worn bearing.
- If the pump runs constantly and never settles, I first check the probes, and only then the board.
- The board is the most sensitive part to moisture. I keep its compartment closed and check that the seal is still in place whenever I open the unit.
- I never poke around the board with the battery connected. I disconnect the battery first.

If the pump stops while the unit is otherwise fine, the cause is nearly always a flat battery or a loose connector, not a failed pump. I check those two things before suspecting anything else.

### Temperature probes

The probes tell the control board what is happening. There is one on each side of the core, so the board can compare the incoming and outgoing temperatures. If a probe gives a wrong reading, the whole unit behaves oddly even though nothing is mechanically wrong.

What I do with the probes:

- Check that each probe is seated firmly and has not slid out of its position.
- Compare the readings against a separate thermometer from time to time.
- Clean the tips gently, because film from the liquid can make them slow to respond.
- Replace a probe if it gives readings that jump around with no reason.

### Inspection routine

I go through the parts in a fixed order so nothing gets skipped. The routine is short:

1. Switch the unit off and disconnect the battery.
2. Look over the green housing for chips, rust and debris.
3. Check the connections and hoses for drips and stiffness.
4. Inspect the probes and their seating.
5. Look at the pump compartment and the control board seal.
6. Clean the core if the temperature gap has shrunk.
7. Check the battery contacts and charge, then reconnect.
8. Run the unit for a few minutes and watch the readings.

I do this at the start of each season and again whenever something looks off. In the greenhouse, a quick visual check every couple of weeks catches most problems before they grow.

### Ordering replacements

When I need a replacement part, I give the supplier the part number LC-3853-Z, plus a short description of which part I want, such as the pump, a probe, or a hose. The part number identifies the unit as a whole, so on its own it does not say which small component I need. I also mention that the unit is green, battery powered and installed in a greenhouse, since the supplier may offer a coating or seal suited to damp conditions.

Before ordering, I note down:

- which part failed and how it behaved
- how long it lasted since the unit went in during 2023
- whether the cause might have been moisture, heat or simple wear

Keeping these notes helps me spot patterns. If the same part keeps failing, the cause is probably the greenhouse conditions and not bad luck, and I can change how I protect the unit.

### Spare parts kept on hand

I keep a small box of spares near the unit so a repair does not stop cider work for long. The box holds:

- a charged spare battery
- a pair of spare hose clamps
- one length of spare hose
- a spare temperature probe
- a few spare screws for the housing panels
- a small pot of green touch-up paint for the housing

The battery and the probe are the two spares I am most likely to use. The hose and clamps come next. The rest rarely leave the box, but they cost little and take almost no space.

### Quick reference

- Subject: Bivand heat exchanger
- Kind: heat exchanger
- Area: cider
- Color: green
- Energy source: battery
- Year installed: 2023
- Location: greenhouse
- Part number: LC-3853-Z
