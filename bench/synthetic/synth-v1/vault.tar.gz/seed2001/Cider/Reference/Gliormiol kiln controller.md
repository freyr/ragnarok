---
type: reference
status: active
project: reference
area: cider
---

# Gliormiol kiln controller

## Setup

The Gliormiol kiln controller is a black kiln controller that I installed in 2017. It lives in the loft, and it runs on battery power. It belongs to my cider notes, because I use it for the small warm-room work that goes with making cider, not for pottery. In this note I keep the plain facts about the device, how I look after it, and what I have learned from using it.

The properties in one place:

- Device: Gliormiol kiln controller
- Kind: kiln controller
- Area: cider
- Colour: black
- Energy source: battery
- Year installed: 2017
- Location: loft

I keep the setup short on purpose. When something goes wrong I want to find the basic facts quickly, then go to the section I need. The other sections below cover what the device does, what I keep near it, when I check it, and what has gone wrong over the years.

## Overview

The Gliormiol kiln controller is a small black box with a display, a few buttons and a probe lead. Its job is to hold a steady temperature for a heated space. In my case the space is a corner of the loft where I keep a warm cabinet for cider jobs: starting a ferment, keeping a batch from stalling in a cold spell, and drying out equipment after a wash.

It is a kiln controller by kind, so it was built to run a program of temperature steps. I use only a small part of that. Most of the time I set one target, let it hold, and check it now and then. The ramping and soaking features are there, but I rarely touch them.

Because the energy source is battery, the controller keeps working through a power cut and does not depend on a socket near the rafters. That was the main reason I picked it in 2017. The loft wiring is old, and I did not want a controller that reset itself every time a fuse tripped. The downside is that the battery is the part that needs the most attention. A weak battery gives odd readings before it gives out completely, and I have been caught by that before.

What I like about it:

- It is simple to read, even with cold hands.
- It keeps its settings when the battery is swapped quickly.
- The black case does not show the dust and grime of the loft.
- It has run for years without a real failure.

What I do not like:

- The buttons are stiff and sometimes need two presses.
- The display is hard to read from a distance in poor light.
- There is no warning that is clear enough when the battery gets low.

## Supplies

These are the things I keep close to the controller or in the loft box so I do not have to go hunting when I need them.

- Spare batteries of the kind the controller uses, in a sealed bag so they stay dry
- A small screwdriver for the battery cover
- A soft dry cloth for wiping the case and display
- A cotton swab for cleaning around the buttons
- A spare probe lead, wrapped and labelled
- A roll of tape for holding the probe lead in place
- A cheap separate thermometer, used to cross-check the controller
- A pencil and a card where I write down readings
- A torch, because the loft light is poor

I check the supplies at the start of autumn, and again in late winter. Batteries are the thing I run short of most often, so I count them first. If I am down to one spare, I buy more that same week.

The separate thermometer matters more than it sounds. The controller only knows what its probe tells it. If I want to know whether the probe is honest, I need a second opinion from something independent. I keep that thermometer in the loft box, never in the house, so it is always there when I need it.

## Schedule

I do not run the controller on a strict calendar, but I have a rhythm that has held up well.

**Every use**

- Look at the display when I go up and confirm it is showing a sensible number.
- Compare the reading with the separate thermometer if the batch matters.
- Check that the probe lead is still where I put it.

**Every month while it is in use**

- Wipe the case and the display.
- Clean around the buttons with the swab.
- Look at the battery cover for any sign of damp or corrosion.
- Write a reading on the card, with the date in my own shorthand.

**Every season**

- Replace the battery, whether it seems to need it or not.
- Check the calibration against the separate thermometer.
- Inspect the probe lead for kinks, cuts or green marks at the ends.

**Once a year**

- Take everything out of the loft box, put it back in order, and throw away anything that has gone bad.
- Read through this note and fix anything that has changed.

The seasonal battery swap is the habit I trust most. Waiting for the battery to fail has never worked well for me. Changing it early costs very little and saves a ruined batch.

## Background

I installed the Gliormiol kiln controller in 2017. At the time I was making cider in small amounts and had trouble with the loft being far too cold in the shoulder months. Ferments slowed down or stopped. I wanted a controlled warm spot and I did not want to guess.

A kiln controller was not the obvious choice. I found this one second-hand from someone who had stopped firing and wanted it gone. It was cheap, it was black and plain, and it ran on battery. I took it home, worked out how to use the simple hold mode, and fitted it in the loft.

Since then my use has changed. In the first years I used it hard every autumn, running it for weeks at a time. Later I settled into shorter periods, because I learned to time my work better and to use the loft's natural warmth in early autumn. It is now more of a tool for awkward weather than for every batch.

Things I learned early on:

- A controller is only as good as its probe position. Moving the probe a short distance changed the reading a lot.
- Cold loft air near the rafters is very different from the air near the cabinet. I had to put the probe inside the warm space, not near the door.
- Battery power is a real advantage in a loft with poor wiring, but it makes you responsible for the battery.
- Writing readings down is far better than trusting memory.

None of this is clever. It is just what I wish I had known on the first day.

## References

I do not have much official paperwork for this device, because I got it second-hand. What I have is mostly my own material and a few habits of cross-checking.

- My own card of readings kept in the loft box
- The short instruction leaflet that came with the controller, now soft at the edges, kept in a plastic sleeve
- Notes from my other cider pages about fermentation temperature and timing
- The separate thermometer, which I treat as the reference for checking the controller
- Photos on my phone of the display settings when the controller was working well, so I can restore them

If I ever need more detail than the leaflet gives, I will write the answer here after I find it. I would rather build up my own reference than trust a half-remembered fix.

I keep the photos of the settings in a folder with the controller's name on it. They have saved me twice, once after a battery change that cleared a setting, and once after I pressed the wrong buttons in the dark.

## Adjustment

The controller drifts slightly from the true temperature, so I use a correction. The calibration offset of the Gliormiol kiln controller is 1.766 mm. I note that the figure is written in that unit in my own records, even though a temperature offset would normally be in degrees; I copy it exactly as I recorded it and do not convert it.

How I apply and check the adjustment:

1. Put the probe and the separate thermometer side by side inside the warm space.
2. Let them sit together for a good while so both settle.
3. Read both and write the two readings on the card.
4. Compare the difference with the offset I have stored.
5. If the difference has grown or shrunk noticeably, think about whether the battery or the probe is the cause before changing the offset.

Things to remember:

- Always change the battery before recalibrating. A tired battery can look exactly like a drifting sensor.
- Do not adjust the offset in a hurry. Make one change, then watch for a day.
- Write down any change on the card, with the reason.
- If the offset seems to need frequent changes, the probe is probably worn and should be replaced.

I keep the offset where I can see it, on the card and in this note, so I never have to guess what the last value was.

## History

A rough timeline of the controller's life with me, kept in plain words because I do not have exact dates for most of it.

**2017.** Installed in the loft. First use was a long ferment in a cold autumn. It worked well enough that I kept it.

**Early years.** Heavy use every autumn. I learned about probe position and about how the cold air near the rafters misleads the reading. I wasted one batch by putting the probe in the wrong spot.

**Middle years.** I changed the way I used it. I stopped running it for weeks and started using it for short, targeted warm spells. I also began the seasonal battery swap after a battery died during a cold night.

**A damp winter.** I found early corrosion on the battery contacts. I cleaned them, dried the cover, and began keeping spare batteries in a sealed bag. I also began checking the cover each month.

**A probe problem.** The probe lead began to give unsteady readings. I found a kink near one end. I replaced the lead with my spare and bought another spare afterwards.

**Recent years.** Steady use, few surprises. The routine in the Schedule section has mostly kept problems away. The case is a little scuffed, but everything works.

The pattern is clear when I look back. Almost every problem I have had traced back to the battery, the probe or damp. The controller itself has been dependable.

## Safety

A kiln controller is meant to manage serious heat, and even though I use mine for a gentle warm space, I treat it with respect. The loft adds its own hazards.

- Never leave anything flammable close to the heated space. Cardboard, old paper and dry wood are common in a loft.
- Keep the warm cabinet clear of insulation and loose material.
- Do not rely on the controller as the only protection. If the heat source has its own cut-out, keep it working.
- Treat a weak battery as a safety matter. Odd readings could cause the heat to run longer than I intend.
- Do not leave a heated space running unattended for long periods without checking it.
- Take care on the loft ladder, especially with cold hands, a torch and a box of batteries.
- Wear sensible shoes and mind the beams. I have hit my head more than once.
- Dispose of old batteries properly and never leave a leaking one in the device.
- If I smell burning, I switch everything off at once, go down, and think before going back up.

I also keep the loft tidy for fire safety reasons. A clear floor and a clear path to the hatch matter more than any setting on the controller.

If the display shows something I do not understand, I do not guess. I turn the heat off, check the probe and battery, and compare with the separate thermometer before starting again.

## Checklist

Before a run:

- [ ] New or recently changed battery fitted
- [ ] Battery contacts clean and dry
- [ ] Probe lead undamaged and in the right place
- [ ] Separate thermometer placed next to the probe
- [ ] Calibration offset still matches my card
- [ ] Space around the warm cabinet clear of anything flammable
- [ ] Torch working and ladder safe

During a run:

- [ ] Display shows a sensible number each visit
- [ ] Reading compared with the separate thermometer
- [ ] Reading written on the card

After a run:

- [ ] Heat switched off
- [ ] Case and display wiped
- [ ] Probe lead coiled loosely, not kinked
- [ ] Battery checked, and removed if the device will sit idle for a long time
- [ ] Notes added to this page if anything unusual happened

I print this list and keep it in the loft box. It is short on purpose. A long checklist gets skipped, and a short one gets used.

## Ideas

Things I might do to improve the setup, none of them urgent.

- Add a second probe so I can see the difference between the top and bottom of the warm space.
- Make a small wooden bracket to hold the probe in exactly the same place every time.
- Put a simple label on the controller showing the offset, so I do not need the card.
- Try a different type of battery and see whether it lasts longer in the cold.
- Fit a small weatherproof pouch for the controller to keep dust and damp off.
- Keep a proper log in one place instead of scattered cards.
- Find out whether a basic alarm can be added for low temperature.
- Make a tidy box just for the controller supplies so nothing wanders off.
- Write a short one-page guide for anyone else who might need to use it while I am away.

The bracket is probably the best idea. Probe position has caused more trouble than anything else, and a fixed holder would remove that variable.

## Open questions

Things I do not know yet and would like to find out.

- How long does a battery actually last in the loft in the depths of winter? I have only a rough idea.
- Is the drift I see caused by the controller, the probe, or the cold?
- Does the controller's accuracy change at the low end of its range, where I use it most?
- Would a different probe position give a more useful reading of the whole cabinet?
- Is the stiffness in the buttons a sign of wear, or just how it was made?
- How much longer will the case and display last in a loft that swings between damp and dry?
- Is there a better way to hold the battery cover closed against damp?
- Should I replace the controller in a few years, or keep repairing and caring for it?

I will move answers out of this section and into the relevant parts of the note as I find them.

## Observations

Things I have noticed from years of watching the device.

- The controller behaves best when the battery is fresh. After a swap, readings are steadier for a while.
- The display slows down when the loft is very cold. It still works, but it takes longer to update.
- The stiff buttons are easier to press with a fingernail than with a fingertip.
- Damp is more of a problem than cold. The cold slows the device, but the damp does real harm.
- The probe reading changes when I open the cabinet door, and takes a while to recover.
- A reading that never changes at all is a bad sign. It usually means the probe or the connection has failed.
- The black case warms up in the sun that comes through the roof window in late summer, which can shift the reading a little.
- When I write readings down, I notice trends I would otherwise miss.
- The device has outlasted several things that cost more.

I find these small observations useful when I am trying to tell a real problem from a normal quirk.

## Risks

The main risks, in rough order of how much they worry me.

1. **Battery failure.** A dead or weak battery can stop the controller or give false readings. I reduce this with the seasonal swap and with spares.
2. **Damp and corrosion.** The loft can get humid, and corrosion on the contacts has happened before. I reduce this with monthly checks and sealed storage.
3. **Probe wear.** A kinked or aged lead gives bad readings. I keep a spare and inspect the lead each season.
4. **Calibration drift.** The offset can become wrong over time. I check it against the separate thermometer and write down every change.
5. **Fire.** Heat in a loft full of dry material is a real hazard. I keep the area clear and never rely only on the controller.
6. **Age of the device.** It was installed in 2017 and was second-hand. It could fail without warning one day. I should know what I would do if it did.
7. **Loss of knowledge.** If I do not keep this note up to date, I will forget what I learned. Writing things down is the cure.

The best protection against all of these is the same small set of habits: change the battery early, keep the probe in the right place, compare with the second thermometer, and keep the loft tidy. None of it is difficult. It only needs doing regularly.
