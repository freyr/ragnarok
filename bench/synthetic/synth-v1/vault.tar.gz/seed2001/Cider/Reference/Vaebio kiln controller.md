---
type: reference
status: active
project: reference
area: cider
description: "Reference about Vaebio kiln controller."
---

# Vaebio kiln controller

## Schedule

The Vaebio kiln controller is a green, mains-powered kiln controller that I installed in the workshop in 2025. It belongs to the cider area of my notes, because the kiln is used for drying apple pomace and for baking the small clay fermentation pots I use for cider work.

I run the controller in a few repeatable programs. I do not improvise on the day, because a rushed ramp is the main way I have cracked pots in the past.

- **Pomace drying:** a low, long hold overnight, started in the evening so the batch is ready by morning.
- **Pot bisque firing:** a slow climb with a long pause early on to let the last moisture out of the clay, then a steady rise to the top temperature.
- **Glaze firing:** a slightly faster climb, a short soak at the top, and a natural cool down with the lid closed.
- **Warm-up hold:** a short low-temperature hold used before a damp load goes in.

I keep a rough weekly rhythm. Pomace drying happens during the cider pressing weeks in autumn. Pot firings happen in the quiet months, when the workshop is not full of crates and buckets. I never start a program after I have left for the day unless someone else is in the building and knows what is running.

A typical program is stored on the controller as a list of segments. This is how I write them down in my notebook before entering them:

```
program: bisque_pots
segment 1: ramp slow, target low, hold long
segment 2: ramp medium, target mid, hold short
segment 3: ramp steady, target high, hold short
segment 4: stop, natural cool down
notes: lid vent open until segment 2 ends
```

After a firing I check that the display shows the program as finished before I touch anything, and I write the outcome in the notebook.

## Safety

The controller runs from mains power, so I treat it like any other mains appliance in a workshop that sometimes gets wet from cleaning and cider spills.

- Keep the area around the controller dry and clear of paper, sacking and dry pomace.
- Never open the kiln mid-firing at high temperature. Wait until it has cooled well down.
- Switch off at the wall and unplug before opening the controller case or touching any wiring.
- Wear heat gloves and eye protection when unloading.
- Keep a fire extinguisher by the workshop door, not next to the kiln where I could not reach it in a fire.
- Do not leave the workshop unattended during a high-temperature stage.

The green case of the controller does not tell me anything about its state, so I always read the display. I also check that the vent is open when drying pomace, since damp material gives off steam and a smell that I do not want building up inside.

If the display shows something I do not recognise, I stop the program, switch off at the wall and wait for the kiln to cool before looking into it.

## History

I installed the controller in the workshop in 2025. Before it, I used a simple manual dial that gave me no control over the rate of heating. That setup was fine for drying but poor for pottery, and I lost several pots to cracks in the first year of trying.

The first weeks with the new controller were spent learning how segments work and what happens when a ramp is too steep. I did test runs with an empty kiln and then with a few cheap test pots before trusting it with real work.

Since then it has become a regular part of the cider setup. Over the first season I refined my programs a little at a time, keeping the changes in the notebook so I could go back to a version that worked. I have not moved it from the workshop since it was fitted, and I do not plan to.

## Parts

The unit is a single controller box with a green case, powered from the mains. It connects to the kiln's heating circuit and a temperature probe.

- **Serial number:** SN-75864517
- **Kind:** kiln controller
- **Colour:** green
- **Energy source:** mains
- **Installed:** 2025
- **Location:** workshop

Other parts that matter in practice:

- The temperature probe that goes into the kiln wall. It is the part most likely to wear out, so I look at it whenever I unload.
- The mains lead and plug, which I check for damage from time to time.
- The relay inside the controller that switches the heating on and off. I have never opened the case to look at it and would only do so unplugged.
- The display and buttons on the front, which I keep wiped clean of dust.

I keep the serial number in this note so I can quote it if I ever need support or a replacement.

## Problems

Problems so far have been small, but I record them so I recognise them again.

- **Cracked pots on early firings:** caused by ramps that were too fast in the first segment. Fixed by lengthening the early hold.
- **Uneven pomace drying:** the top layer dried faster than the bottom. I now spread the pomace thinner and turn it once if I am awake.
- **Display reading odd after a power cut:** the program had stopped and the display looked as if it were still running. I now always check the state and restart the program from the start rather than assuming it resumed.
- **Dust on the front panel:** buttons become sticky if I neglect cleaning.

Things I still want to sort out: a better way of knowing a firing has finished without being in the workshop, and a clear label on the wall switch so nobody turns it off mid-program by accident.

## Background

I got into firing my own clay pots because I wanted vessels for small-batch cider that I could shape and control myself. The kiln controller is what makes that practical, because the main skill in firing is controlling how fast the temperature changes, and a good controller does that for me.

The drying use came later. Apple pomace left over from pressing is bulky and goes off quickly, and drying it in the kiln at a low steady temperature keeps it usable for other purposes. Having one device handle both jobs keeps the workshop simpler.

I keep this note as a reference for myself: what the device is, how I use it, what to watch out for, and what has gone wrong before. When I change a program or fix a problem, I update the relevant section so that the next season starts from what I learned in the last one.
