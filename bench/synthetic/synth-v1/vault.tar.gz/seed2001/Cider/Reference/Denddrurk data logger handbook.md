---
type: reference
status: active
project: reference
area: cider
description: "Reference about Denddrurk data logger."
---

# Denddrurk data logger handbook

## History

The Denddrurk data logger is a yellow box that has sat in the greenhouse since 2014. It runs on mains power and has never had a battery pack or a solar panel attached. I use it to record the conditions around the cider work: air temperature near the apple racking, the warmth of the greenhouse bench where the starter jars sit, and the humidity that decides whether the stored fruit stays sound or starts to go soft.

I installed it in 2014, in the first season after I moved the small cider operation under glass. Before that I wrote readings in a notebook by hand, and the notebook had gaps every time I forgot or was away. The logger fixed that. It was the first piece of equipment in the greenhouse that kept working when I was not there.

The yellow case turned out to be useful. The greenhouse is full of green and brown, and I can spot the logger from the door. It also stands out in photos, so I can see at a glance where it was mounted when I compare old pictures with new ones. It hangs on the north wall, at about the height of my chest, away from the glass so the afternoon sun does not heat the sensor directly.

Some history of how it fits with the rest of the kit:

- The logger came first. Everything else was added later and tested against its readings.
- When I ran the old pump tests, I used the logger as the reference. Those results are in [[Rundtru circulation pump tests]].
- The humidity problems in the second winter led to the notes in [[Triothkil dehumidifier notes]].
- In 2018 I changed the valve hardware, and the logger gave me the before and after data. See [[Fakiosto valve actuator 2018]].
- I weighed the fruit samples against the logger's records using the [[Lanfoth scale]], so the weight loss and the conditions could be read side by side.

The logger has been moved only once, a short distance along the same wall, when I rebuilt the racking. It has never left the greenhouse for repair. That fact matters when I think about spare parts: I have none, and I rely on careful upkeep instead.

## Lessons

These are the things I learned the hard way. I keep them here so I do not repeat them.

**Mains power is a strength and a risk.** Because the logger runs on mains, I never replace batteries and never lose data to a dead cell. But a tripped breaker in the greenhouse stops it silently. After the first outage I found a gap of several days in the record and could not tell what had happened to the fruit. Now I check the power light whenever I walk in, and I note any outage in the log by hand.

**Placement matters more than settings.** My early readings were too warm because I had mounted it close to the glass. Moving it to the north wall made the numbers match what the bench thermometer showed. I should have tested the position before trusting a whole season of data.

**Do not trust a single reading.** One odd value is usually a door left open or a watering session nearby. I look at the trend across a day, not the spike. The spikes that repeat at the same hour are the interesting ones, and several of them turned out to be the sun hitting a wall.

**Keep the data and the notes together.** A column of numbers means little a year later. I now write a short line beside any unusual stretch: what I was doing, what the weather was, what I changed. This habit saved me when I was working out the humidity trouble that led to [[Triothkil dehumidifier notes]].

**Compare against another instrument.** The logger is good, but I check it against a second thermometer every so often. When the two drift apart, I find out which one is wrong before it costs me a batch.

**Do not over-collect.** At one point I set the logger to record far too often. The file grew large and the useful pattern was buried in noise. A sensible interval is enough for slow processes like fruit storage and fermentation.

**Plan for the long term.** The logger is old by now, and I have thought about replacing it. Two ideas are written down: the [[Konkrur Faesnus plan]], which would extend the monitoring to more spots, and the [[Gistaenfe kiln controller plan]], which would tie the readings to a controller for the drying area. Neither has been done. Both depend on keeping this unit healthy in the meantime.

A sample of the settings I use, kept so I can restore them after a reset:

```
# Denddrurk data logger - working settings (greenhouse, north wall)
channel_one      = air_temperature
channel_two      = relative_humidity
sample_interval  = ten_minutes
averaging        = on
alarm_high_temp  = set_in_notebook
alarm_low_temp   = set_in_notebook
power_source     = mains
memory_mode      = overwrite_oldest
```

I deliberately keep the alarm thresholds in my notebook rather than here, because I adjust them with the seasons.

## Maintenance

Maintenance on this unit is mostly about keeping it clean, dry and powered. It is simple, but skipping it is what causes trouble.

**Power.** Check the mains lead and plug for damp, cracks and a loose fit. The greenhouse is humid, so I keep the connection off the floor and under a small cover. I never run the lead where the watering hose goes. If the power light is off, check the breaker first, then the plug, then the lead.

**Case and vents.** The yellow case collects dust and a fine film from the greenhouse air. I wipe it with a dry cloth, and with a barely damp one if it is really dirty. I never spray anything near it. The vents must stay clear, because blocked vents make the readings lag.

**Sensor.** The sensor is the most delicate part. I do not touch it with my fingers, and I do not blow on it. When readings look wrong, I compare it against the second thermometer before assuming a fault. If the humidity reading sticks at a high value, I move the unit to a dry, warm room for a day and see whether it recovers.

**Mounting.** Check that the bracket on the north wall is still tight and that the unit has not tilted. A tilted case can change how air flows over the sensor. Make sure no plant, hanging basket or rack has grown or been moved into the space around it.

**Data.** Copy the records off the unit regularly and store them with my notes. Do not wait until memory fills. With the overwrite setting, the oldest values vanish first, and I have lost useful winter data that way once.

**Settings.** After any outage or reset, compare the settings with the block in the Lessons section and put them back. Check the clock is right, because a wrong clock makes every comparison with other records misleading.

**Cross-checks.** Now and then I run the checks I used before: compare with the bench thermometer, and weigh a fruit sample on the [[Lanfoth scale]] to see whether the weight loss fits the recorded conditions. If something does not fit, I look at the logger first, then at the greenhouse.

A short checklist I follow when I walk in:

1. Is the power light on?
2. Is the case clean and the vents clear?
3. Is the bracket firm and the unit level?
4. Does the reading roughly agree with the second thermometer?
5. Is there anything new near the sensor that could change the airflow?

## Schedule

This is the routine I keep for the logger. I write it as a rhythm, not a rigid calendar, because the greenhouse work changes through the year.

**Every visit.** Look at the power light. Glance at the current reading and compare it with what the greenhouse feels like. If something is clearly off, deal with it then, not later.

**Weekly.** Copy the records off the unit and add a short note about anything unusual. Wipe dust from the case if it is visible. Check that nothing has been placed in front of the vents.

**Monthly.** Compare the logger with the second thermometer on a calm day, and write down the difference. Check the mains lead and plug for damp. Check the bracket. Review the alarm thresholds in the notebook and see whether they still make sense for the season.

**Each season.** Spend a little longer with it. Clean the case properly, confirm the settings against the block in the Lessons section, confirm the clock, and review the past season's data for gaps. In autumn, when the apples come in and the cider work starts, this check matters most, so I do it before the first pressing. In late winter I check it again before the damp weather peaks, with the notes in [[Triothkil dehumidifier notes]] beside me.

**Yearly.** Mark the anniversary of the 2014 installation by looking at the whole history of the unit. I ask whether it is still the right device for the job, whether its position is still best, and whether any of the old plans should move forward. The [[Konkrur Faesnus plan]] and the [[Gistaenfe kiln controller plan]] are reviewed at this point, and I decide whether to keep them waiting or start one. I also check whether any equipment changes, such as new valves like the ones in [[Fakiosto valve actuator 2018]] or new pumps like those in [[Rundtru circulation pump tests]], mean I should move or reconfigure the logger.

**After any event.** After a power cut, a storm, a leak or a rebuild of the racking, run through the maintenance checklist at once, restore the settings, and write the event into the notes so the gap or change in the data is explained.

The aim of this schedule is plain: the yellow logger on the north wall should be running, clean, correctly set and trusted, so that the cider records I keep from it stay useful for years.

## Risks

The Denddrurk data logger is a yellow data logger in the cider area. It has been installed in the greenhouse since 2014 and runs on mains power. Each of those properties creates its own risks, so I list them with that in mind.

**Mains power.** The logger has no battery of its own. If the mains supply drops, the logging stops. A short cut in the greenhouse circuit leaves a gap in the record, and I may only notice it days later. The risk is higher in storms, and also when someone unplugs the socket to run a fan or a heater. I should treat the socket as part of the instrument and keep it marked.

**Greenhouse location.** A greenhouse is warm, humid and sometimes dusty. Condensation forms on cold mornings. Water inside the case can corrode the contacts and cause false readings. Direct sun in summer can heat the yellow case and bias any sensor mounted close to it. Watering and spraying can also splash the unit if it sits too low.

**Age of the installation.** The device has been in place since 2014. Plastic gets brittle, cable insulation cracks, and connectors loosen. Spare parts may be hard to find. I should not assume that a fault is only a settings problem; it may be wear.

**Data for the cider area.** The records feed my cider notes. If the logger drifts or loses a stretch of time, I could draw wrong conclusions about the conditions around the fruit and the batches. A wrong record that looks normal is worse than an obvious gap.

**Handling risks.**
- Opening the case with the mains connected is dangerous. Always disconnect the power first.
- Wet hands and a wet floor in a greenhouse make any work on mains equipment riskier.
- Changing the settings by guesswork can overwrite the working configuration. I should save a copy before every change.

**Mitigations in short.**
- Keep the socket labeled and out of the way of other tools.
- Keep the unit raised, shaded and away from spray.
- Copy the data off the logger on a regular schedule.
- Compare its readings with a second, independent thermometer now and then.

## References

These are the places I look when I need to know something about the logger. They are my own notes and physical items, not outside websites.

- **The paper logbook** kept near the greenhouse door. It holds hand-written entries about cleaning, cable changes and odd readings.
- **The printed wiring sketch** that I drew when I checked the power connection. It shows which socket feeds the logger and which switch controls it.
- **The exported data folder** on my computer, where I store the files copied from the logger. I keep one subfolder per season.
- **The cider batch notes**, which I compare against the logger records when a batch behaves strangely.
- **The photos of the installation**, taken from the front, the side and the cable route. They help when I have to put things back after cleaning.
- **The manufacturer's manual**, kept as a paper copy in the workshop. It is old, but it still describes the basic menu and the meaning of the indicator lights.

Basic facts, repeated here for quick lookup:

| Property | Value |
| --- | --- |
| Kind | data logger |
| Area | cider |
| Color | yellow |
| Energy source | mains |
| Year installed | 2014 |
| Location | greenhouse |

When two references disagree, I trust the most recent logbook entry first, then the photos, then the manual. The manual describes the device as it was made, while the logbook describes it as it is now.

## Tools

I keep the tools for the logger together in one box, so I do not have to search for them in the greenhouse.

**Physical tools**
- A small screwdriver set for the case screws.
- A mains voltage tester, used before touching anything that is meant to be live.
- A dry soft cloth and a small brush for dust.
- Contact cleaner, used sparingly on connectors that show corrosion.
- Spare cable ties and a roll of tape for tidying the cable run.
- A torch, because the corner where the logger sits is dim in the evening.
- A second thermometer, independent of the logger, for cross-checking.
- A labeled extension lead, used only when the wall socket must be freed for a short time.

**Software and files**
- A plain text editor to read the exported files.
- A spreadsheet to draw simple graphs and spot gaps.
- A small shell script that copies the exported files into the season folder and adds the day to the name.

The backup script is very simple. This is the shape of it:

```sh
#!/bin/sh
# copy logger exports into the season folder
SRC="$1"
DEST="$2"
DAY=$(date +%Y-%m-%d)

mkdir -p "$DEST"
for f in "$SRC"/*; do
  cp "$f" "$DEST/${DAY}_$(basename "$f")"
done
echo "copied from $SRC to $DEST"
```

I pass the source and destination as arguments instead of editing the script. I never run it from inside a folder of downloaded files; I run it from my scripts folder and point it at the data.

**How I use the tools together.** First I read the voltage tester on the socket to confirm the state of the supply. Then I look at the logger and compare it with the second thermometer. If I plan to open the case, I disconnect the mains and test again. After the work, I copy the data with the script and look at the graph for gaps.

## Checklist

I use this list for a routine visit. A full pass takes about a quarter of an hour, and I write the result in the logbook.

**Before touching anything**
- [ ] Look at the logger from a distance. Is it in place, dry and undamaged?
- [ ] Check the indicator lights and note their state.
- [ ] Read the second thermometer and write the value beside the logger reading.
- [ ] Copy the data to the season folder with the backup script.

**Power**
- [ ] Confirm that the mains socket is firmly seated and labeled.
- [ ] Check the cable for cracks, pinching or damp.
- [ ] Make sure nothing else was plugged into the same socket.
- [ ] If the logger went off during the period, note the approximate time in the logbook.

**Greenhouse conditions**
- [ ] Check for condensation on or inside the case.
- [ ] Check that the yellow case is not in direct sun or in the line of spray.
- [ ] Brush off dust and wipe the outside with a dry cloth.
- [ ] Confirm that the mounting is still firm and the unit is raised off the floor.

**Data**
- [ ] Open the latest export and look for gaps or flat lines.
- [ ] Compare a few readings with the independent thermometer.
- [ ] Note any strong drift and decide whether the cider notes need a remark.
- [ ] Check that the date and time on the logger still match the real time.

**After the visit**
- [ ] Put the tools back in the box.
- [ ] Write a short logbook entry: the date, what I checked and what I found.
- [ ] If anything looked worn, add it to my list of things to repair or replace.

**Yearly extras**
- [ ] Take new photos of the installation and compare them with the old ones.
- [ ] Disconnect the mains, test that it is dead, open the case and inspect the contacts.
- [ ] Review whether a logger installed in 2014 should still be kept, or whether a replacement should be planned.

## Setup

The Denddrurk data logger is a data logger used in the cider area. It is yellow, runs on mains power, and has been installed in the greenhouse since 2014. I keep those five facts at the top of my mind because most of the setup choices follow from them.

### Where it sits

The unit is mounted in the greenhouse, on the wall nearest the door to the pressing shed. The yellow case is easy to spot among the grey conduit and the white trunking, which helps when I come in with wet hands and need to find the reset switch quickly. The mains socket is on the same wall, about shoulder height, and I fitted a small drip loop in the cable so condensation runs off before it reaches the plug.

The greenhouse gets humid in late summer, when the apple trays are stacked inside for sorting. The case has held up since 2014, but I still wipe the vents with a dry cloth every time I do a general tidy.

### Power

Because the energy source is mains, there is no battery to change and no solar panel to clean. The downside is that a power cut stops logging. The logger keeps its configuration through a cut, but any readings taken during the outage are simply missing. I have learned to treat gaps in the record as "power" first and "fault" second.

I do not run the logger from an extension lead. It has its own socket, and the socket sits on a circuit that is not shared with the heater or the misting pump. Those two caused odd spikes in the early years.

### Channels and sensors

The logger takes a handful of sensor inputs. My habit is to keep the wiring the same from year to year, so the order is always:

1. Air temperature near the bench.
2. Air temperature up high, under the roof glass.
3. Humidity at bench height.
4. Temperature of the juice sample tank.

The sample tank probe is the one that matters most for the cider work. It tells me how the juice is behaving before it goes to the fermenting room. The two air probes are mostly there so I can explain the tank reading when it looks strange.

### Basic configuration

This is the configuration I keep as a reference. It is written in the plain key-and-value style the logger accepts. I have replaced the numeric settings with words so I do not copy stale values into other notes. The real numbers are on the sticker inside the lid.

```
[device]
name        = denddrurk-greenhouse
kind        = data logger
area        = cider
location    = greenhouse
power       = mains

[logging]
interval    = every few minutes
storage     = rolling, oldest overwritten first
timestamp   = local time

[channels]
ch_a = air_bench
ch_b = air_roof
ch_c = humidity_bench
ch_d = juice_tank

[alarms]
ch_d_high   = set on sticker
ch_d_low    = set on sticker
on_alarm    = flash and log marker
```

### Routine after any change

Whenever I touch the wiring or the settings, I do the same short routine:

- Check that each channel shows a live reading on the display.
- Hold a warm hand around one probe and watch the matching channel climb.
- Confirm the clock matches the kitchen clock.
- Write a note in the logbook beside the greenhouse door saying what I changed.

That last step has saved me many times. A change that is not written down turns into a mystery within a season.

## Costs

I do not record exact prices in this note, since they go stale and I would rather look at the receipts folder. What I can do is describe where the money goes and how the cost behaves over time.

### Purchase and installation

The logger was the main one-off expense when it was installed in 2014. The sensors, the cable, and the mounting hardware came on top of that. I did the wiring myself, so there was no labour charge, but I did spend a Saturday on it and lost a drill bit to the greenhouse frame.

Compared with the other equipment in the cider area, the logger was a modest purchase. It is much cheaper than the press or the stainless tanks, and it has repaid itself by catching problems early.

### Running costs

Because it runs on mains, the running cost is electricity. The draw is tiny. It is far less than the heater or the pump in the same building, and I have never been able to see it on the meter. I count it as effectively nothing, though it is not literally nothing.

There are no subscription fees. The logger stores data locally and I copy it off by hand, so I do not pay for cloud storage or a service plan. That was a deliberate reason for choosing it.

### Maintenance and replacement parts

The recurring costs are small and fall into three groups:

- **Probes.** The humidity probe drifts after a few seasons and needs replacing sooner than the others. The juice tank probe gets a gentle clean each season and has lasted well.
- **Cable and seals.** Cable glands and sealing tape for the greenhouse wall. I buy these when I notice a crack, not on a schedule.
- **Consumables.** Cleaning cloths, labels, and the odd cable tie. Hardly worth listing, but they add up.

### Cost of not having it

The most useful way to think about cost is to ask what happens without the logger. A warm spell in the greenhouse can push the juice samples off course before I notice. One lost batch of cider would cost more than every item above put together. So I treat the logger as cheap insurance, not as an expense to trim.

### Where I could save

I do not think there is much to cut. The one place where I have wasted money is buying spare probes in a bundle when I only needed one. In future I will buy singly and keep the spare count low.

## Ideas

These are things I would like to try, in rough order of how likely I am to get to them.

### Short term

- **Label the cables.** Each channel has a tag, but the tags have faded. I want to replace them with printed, laminated ones that survive the damp.
- **Add a dry-run checklist.** Turn the routine after any change into a card pinned beside the logbook, so a visitor could follow it without asking me.
- **Mark the power cuts.** Write a rule for myself: every time I see a gap in the record, note beside it whether the cause was power, a loose probe, or something else. Over a few seasons that would give me a real picture of the weak points.

### Medium term

- **A small backup supply.** Since the logger is on mains, a compact backup unit would let it ride through short cuts. The gaps are rare, but they tend to happen during storms, which is also when the greenhouse temperature is most interesting.
- **Second juice probe.** Having two probes in the sample tank would let me spot a failing probe by comparing them. At the moment I only notice drift when it gets large.
- **Shade check.** Move the roof air probe to a spot out of direct sun for a week and compare. I suspect the current position reads too high on bright afternoons.

### Longer term

- **Regular export routine.** Right now I copy the data off whenever I remember. I would like a fixed weekly habit, tied to something else I already do, such as sorting the trays.
- **Compare seasons.** With data stretching back to 2014, there should be a decent record of how each year behaved. I would like to chart the juice tank temperature against the greenhouse air temperature across many seasons and see whether the relationship has changed.
- **Retire the oldest probe.** One probe has been in place for most of the logger's life. I would like to test it against a fresh one in a bucket of water before deciding whether it can stay.

### Ideas I have rejected

- Moving the logger out of the greenhouse. The whole point is to measure conditions where the samples are.
- Switching to a battery-powered unit. I prefer to avoid battery changes and mains power has been dependable.
- Repainting the case. The yellow colour makes it easy to find, and I do not want it to blend in.

## Observations

These are notes from living with the logger over the years. Some are patterns in the data, others are habits I have picked up.

### Reliability

The Denddrurk has been steady since 2014. It has never stopped on its own accord. Every outage I can trace came from the mains supply or from a probe connection, not from the logger itself. For a unit that lives in a humid greenhouse, I consider that a good record.

### Patterns in the data

- The roof probe always reads warmer than the bench probe on sunny days, and the gap is largest in the early afternoon.
- The juice tank temperature lags behind the air temperature. It rises slowly after a warm morning and falls slowly after a cold night, which is what I would expect from a large volume of liquid.
- Humidity peaks overnight and drops sharply once the vents are opened in the morning. The sharp drop is a useful check that someone actually opened them.
- During sorting weeks, the humidity at bench height stays higher than usual because of the wet trays.

### Things that caught me out

- **Clock drift.** After a long power cut, the clock can be a little off. I now check it against the kitchen clock whenever the power returns.
- **Loose connectors.** A single loose probe connector once made a channel read oddly for days. The values looked plausible, which made it worse. A quick wiggle test of each connector is now part of my routine.
- **Over-trusting alarms.** The alarm flash is easy to miss if I am not looking at the unit. I prefer to check the logbook and the display in person rather than rely on the light.

### Habits that work

- Writing every change in the logbook by the greenhouse door.
- Looking at the juice tank channel first, then the air channels for context.
- Treating gaps as power problems until proven otherwise.
- Keeping the vents clear and the case dry.

### Open questions

- Is the roof probe position giving a fair picture, or is the sun biasing it?
- How much does the humidity probe actually drift each season? I have a feeling about it but no measurement.
- Would a backup supply have saved any useful data over the years, or are the cuts too rare to matter?

I will come back to these once I have tried the shade check and the second juice probe. Until then, the logger remains a quiet, yellow, mains-powered fixture in the greenhouse that does its job without much fuss.

## Safety

The Denddrurk data logger is a yellow data logger that runs on mains power. It has been installed in the greenhouse since 2014. The greenhouse is damp, and mains power is the main hazard, so I treat every job on this unit as a wet-location electrical job.

### Before touching the unit

- Switch off the supply at the breaker, not only at the logger's own switch. The yellow case does not mean it is low voltage. It is just the colour I picked years ago so I could find it among the pots and trays.
- Check that the breaker is really off by trying the logger's power light. If the light is still on, stop and find out why.
- Dry my hands and the floor around me. The greenhouse floor often has standing water near the cider apple trays.
- Never open the case while watering or misting is running. The misting line is close to the logger, and a loose fitting can spray it.
- Keep the mains lead off the floor. It should run along the post and not lie in the wet.

### While working

- Use only one hand inside the case when the power has to stay on for a test. I try to avoid this, and I do it only when a fault cannot be seen with the power off.
- Do not wear a wet jacket or gloves that have soaked up water.
- Keep a dry cloth in the pocket and wipe sensor leads before I handle the connectors.
- Do not use metal tools with bare shafts near the terminals. I use the plastic-handled screwdriver that lives in the logger's tool tin.

### Cider-related hazards

The logger belongs to the cider area, so it sits near fermenting material and fruit. This brings a few extra risks:

- Fermentation gives off carbon dioxide. In a closed greenhouse on a still day the gas can collect low down. If I feel dizzy or get a headache while bent over the logger, I leave and open the vents.
- Spilled juice is sticky and slippery. I wipe it up before I work.
- Wasps gather around the fruit in autumn. I check the case for nests before I open it.

### After work

- Close the case and check that the seal sits flat all the way round.
- Check that the cable gland is tight and the cable has a drip loop, so water runs off before it reaches the case.
- Switch the breaker on again and watch the unit for a few minutes to confirm it starts and logs.

## Problems

This section lists the faults I have seen, what they looked like, and what I did. It is a personal log, so some entries are guesses that worked.

### Logger stops recording but the light stays on

This is the most common fault. The power light is lit, but the log has a gap. Causes I have found, from most to least likely:

1. The storage card is full or has been corrupted by a power cut.
2. A sensor lead has corroded at the connector.
3. The internal clock has drifted after a long outage.

What I do: power the unit down, take out the card, copy the data to my laptop, and reformat the card. Then I refit it and watch for the first new entries. If the gap comes back, I look at the connectors next.

### Condensation inside the case

In a greenhouse this is expected, but it should not be more than a thin mist. If I see droplets on the inside of the lid:

- Replace the small drying sachet in the case.
- Check the lid seal for a flat spot or a crack.
- Move the cable so that the gland points downward.

The unit has survived many years of this because I keep the seal in good shape. Where I let it go, the first sign was a drifting temperature reading.

### Readings that jump

Sudden spikes in the temperature or humidity trace usually mean one of three things: a loose lead, direct sun on the probe, or interference from the misting pump starting up. The pump is the usual cause. Spikes that line up with the pump cycle are electrical noise, not real changes in the greenhouse.

What helped: keep the sensor leads away from the pump cable, and do not bundle them together with cable ties.

### Humidity reads too high after watering

The humidity probe takes a long time to dry out after a heavy misting. This is not a fault. I ignore the first part of the trace after watering when I am looking at trends for the cider fruit store.

### Unit resets itself

If the logger restarts on its own, the supply is the suspect. Mains in an old greenhouse can sag when other equipment starts. I check:

- whether the heater or the pump is on the same circuit,
- whether the plug and socket are warm,
- whether the socket has any sign of moisture.

A warm plug is a reason to stop and fix the socket before anything else.

### Example log extract

This is the kind of thing I see when the card has trouble. I keep the words and drop the stamps so the extract is easy to read.

```
logger: start, supply ok
logger: sensor bench-a ok
logger: sensor bench-b ok
logger: card write failed, retrying
logger: card write failed, retrying
logger: card not ready, buffering in memory
logger: memory buffer full, oldest entries dropped
logger: card write ok
```

Reading it: the card failed to write, the unit held readings in memory for a while, and then it began to drop the oldest ones. After a write failure like this I always check the card before anything else.

### Things that are not faults

- A small delay at start-up before the first reading appears.
- A slow rise in the case temperature on sunny afternoons.
- A faint hum from the power supply when the greenhouse is very quiet.

## Open questions

These are things I do not know yet about the Denddrurk data logger. I want to find out, or at least decide how to live with them.

### Power and supply

- How much margin does the mains supply have in the greenhouse? The logger has been on mains since 2014, but I have never measured whether the circuit is stable when the heater and the pump both start.
- Would a small battery backup be worth adding? A cut during the cider fruit ripening period costs me data I cannot recreate, but a battery inside a damp case brings its own risk.
- Is the earth connection at the greenhouse socket still good? I should have it tested by someone qualified.

### Hardware

- How much longer will the yellow case seals last? They have worked for a long time, but rubber ages. I do not know whether spares are still made.
- Can the sensors be replaced with newer ones without changing the logger? I have not tried.
- Is the storage card a limit? Newer cards might help, but I do not know whether the logger accepts larger ones.

### Data

- Are the readings from the bench nearest the door representative of the whole greenhouse? I suspect not, and I would like a second logger or a handheld meter to compare.
- How much do the readings drift over a year? I have never done a proper calibration check against a reference.
- Should I keep every reading or only daily summaries? Storage is cheap, but long files are hard to read.

### Cider link

- Is the greenhouse climate the main driver for how well the apples keep, or is the store temperature more important? The logger only tells me about one side of this.
- Would a logger in the cider store itself be more useful than this one? Possibly, but this unit is the one I have.

### Practical

- Who else could service this unit if I were away? The notes here should be enough for a careful helper, but I have not tested that.
- Is it worth labelling the breaker and the socket more clearly? Probably yes.

## Background

The Denddrurk data logger is a small yellow box that records conditions in the greenhouse. It sits in the cider area of my notes because the greenhouse is where I raise young trees and keep some fruit before pressing, and the logger tells me whether conditions are safe for both.

### Summary of the properties

- Kind: data logger
- Area: cider
- Colour: yellow
- Energy source: mains
- Year installed: 2014
- Location: greenhouse

### Why it is there

When I set up the greenhouse in 2014, I wanted a record rather than a guess. Before the logger, I walked in, felt whether it was warm, and wrote something in a notebook. That was not good enough for a frost night or a hot spell. The logger gave me a trace I could look at the next morning, and it showed me that the greenhouse swung much more than I thought.

### Why mains power

I chose a mains-powered unit because battery loggers kept running flat in cold weather. The greenhouse already had a supply for the heater and the pump, so adding a socket was simple. The trade-off is that the unit depends on the supply, which is the reason for the safety rules and the questions about backup above.

### Why yellow

The colour has no technical meaning. Yellow stands out against green leaves and grey shelving, so I can see the unit from the door and I do not knock it when carrying trays. Over the years the case has faded slightly but it is still easy to spot.

### How I use the record

- I look at the overnight low in spring to decide whether to cover the young trees.
- I look at the daytime high in summer to decide about shading and vents.
- I look at humidity in autumn when fruit is stored nearby, because damp encourages mould.
- I compare the traces from year to year to see whether the greenhouse is getting better or worse at holding its temperature.

### How it fits with the other notes

This handbook is the reference for the device itself. Other parts of the note cover its setup and routine care. This part covers the risks, the faults, the unknowns and the history. When I change anything on the unit, I update the problems list first, because that is the part I read most often when something goes wrong.

### A note on upkeep

The unit has run since 2014 with only small repairs, which is mostly down to keeping it dry, keeping the card healthy, and not overloading the circuit. If I keep to those three habits, I expect it to keep working. If it finally fails, the record it built up is the real value, so the first priority is always to copy the data off the card and keep it safe.

## Parts

This section lists the physical parts of the Denddrurk data logger as I know them, what each one does, and what I check on it. The logger is a yellow data logger on mains power. It was installed in 2014 in the greenhouse, and it belongs to the cider side of the work. Its serial number is SN-61830199. That is the number on the plate, and I quote it whenever I write to anyone about the unit.

I have not written down any other part codes. Where I replaced something, I describe the part by what it looks like and where it sits, not by a catalogue code. If I ever need a spare, I will compare it by eye and by the connector type, then check the new part against the notes below.

### Summary of the unit

| Property | Value |
|---|---|
| Kind | data logger |
| Color | yellow |
| Energy source | mains |
| Year installed | 2014 |
| Location | greenhouse |
| Serial number | SN-61830199 |

The area is cider, as in the frontmatter. In practice that means the logger records conditions around the cider work that happens in the greenhouse. It does not control anything. It only watches and writes things down.

### Housing

The housing is a yellow box with a hinged lid. The yellow is a plain painted plastic, and it is easy to spot among the green leaves and grey pipes of the greenhouse. I chose to leave it that way because I can find it quickly when I walk in with wet hands and a crate of fruit.

Things I know about the housing:

- The lid closes with a latch on the right side. The latch is stiff in cold weather, so I lift it with my thumb instead of using a tool.
- The seal around the lid is a soft black rubber strip. It has gone a little flat in places. I check it for cracks every time I open the box.
- The box is fixed to a wooden post near the door, at about chest height. It is not on the floor, because water collects there after washing.
- The cable entries are on the underside. Nothing enters from the top, so rain and condensation cannot run down a cable into the box.
- Inside the lid there is a small paper label with the serial number SN-61830199 written again by hand, in case the plate outside fades.

The greenhouse is humid, and the housing is the main thing that keeps the electronics alive. If I see a fogged lid from the inside, I treat it as a fault and dry the box out before anything else.

### Mains supply

The energy source is mains. There is no battery as the main supply. The logger takes power through a short lead from a socket on the greenhouse wall, and that socket is on a circuit protected by a residual current device.

The parts of the power path, in order:

1. The wall socket in the greenhouse, which has its own weatherproof cover.
2. The power lead, a flexible cable with a moulded plug on the socket end.
3. The cable gland on the underside of the housing, which grips the lead so a pull on the cable does not reach the terminals.
4. The internal power supply board, which turns mains into the low voltage that the logger needs.
5. A fuse holder on that board, which I have never needed to open.

Notes on the power path:

- Because it is mains powered, a power cut stops logging. When the power returns, the logger starts up again by itself and carries on writing to the same file.
- I never open the housing with the plug in. I switch off at the wall, pull the plug, and wait a few minutes before touching the board.
- The lead runs along the post and then along the wall, held by clips. I check the clips because the greenhouse gets hot in summer and the plastic gets brittle.

### Main board

The main board sits on standoffs at the back of the housing. It carries the processor, the clock, the memory and the connectors for the sensors. I do not modify it. All I do is look at it for signs of damp: green or white crust on the connectors, a sticky film, or a musty smell.

Parts on the main board that matter to me:

- **Processor and firmware chip.** I treat these as a sealed unit. I do not know the firmware version and I do not record one here.
- **Real-time clock with a coin cell.** The clock keeps the time when mains is off. The coin cell is the one battery in the unit, and it only holds the clock. If the timestamps jump back to an old date after a power cut, the coin cell is the first suspect.
- **Storage.** The logger writes to a removable memory card in a slot on the right edge of the board. The card is the part I handle most often.
- **Status lights.** There is a power light, a logging light and a fault light. In normal running the first two are on and the fault light is off.
- **Terminal blocks.** Screw terminals along the bottom edge take the sensor wires.

### Memory card

The memory card holds the logs. I pull it out when I want to copy the data to my own computer, and I put it back straight away. I do not leave the logger running without a card, because it will either stop logging or keep records only in its small internal buffer, which is easy to lose.

Handling rules I follow:

- Switch off logging before removing the card, or at least wait until the logging light is off between writes.
- Keep a spare card of the same kind in the kitchen drawer, in a small plastic case.
- Copy the files first, check the copy opens, and only then clear the card.
- Never put the card in a pocket with damp gloves.

### Sensors and probes

The logger has sensor inputs, and I use them for the conditions that matter for cider fruit and fermenting vessels kept in the greenhouse. The probes are on leads of different lengths, and each lead has a small coloured tag so I know which is which.

What I have connected:

- A temperature probe that hangs at about the height of the crates. It is the most important one.
- A second temperature probe placed near the roof, to show how much hotter the top of the greenhouse gets than the working area.
- A humidity sensor in a small vented cap, mounted a little away from the door so it does not read the draught.
- A spare input, with the terminals capped, kept free for something new.

Practical notes on the probes:

- Probes drift over the years. I compare the two temperature probes against each other and against a plain glass thermometer a couple of times a year.
- The humidity sensor is the part most likely to go wrong. Condensation and dust both affect it. If its readings sit at the top of the range for days, I assume the sensor is wet or dead.
- Wires are screwed into the terminal blocks with bare ends. I check that no strand sticks out, because a loose strand can touch the next terminal.
- Each probe lead has a drip loop just before it enters the housing, so water follows the loop down and drips off instead of running into the gland.

### Cables and glands

Underneath the housing there are cable glands, one for the power lead and a few for the probe leads. They are round plastic fittings with a rubber insert and a screw cap.

- Tighten the cap by hand until the cable no longer slides, then a little more. Over-tightening crushes the insert.
- Any unused gland has a blank plug in it. If a plug is missing, the gap lets in damp air and insects.
- When I change a probe, I thread the new lead through the same gland and re-tighten.

### Mounting hardware

The housing is held to the post by screws through lugs at the top and bottom. The screws are stainless, because ordinary steel rusts quickly in the greenhouse. I keep a few spare screws of the same type in the logger's drawer. The post itself is untreated wood that I sealed with a coat of varnish, and I recheck the varnish each spring.

### Configuration extract

This is a sample of the settings file as I last saw it on the card. I include it because it ties the physical inputs to the names I use in the logs. The values are descriptive, and I have left out numbers I do not need to remember.

```ini
[device]
name = Denddrurk data logger
kind = data logger
colour = yellow
power = mains
location = greenhouse
serial = SN-61830199

[inputs]
input_a = temperature_crates
input_b = temperature_roof
input_c = humidity_door
input_d = unused

[storage]
target = removable_card
on_full = stop_and_light_fault

[clock]
source = internal_rtc
backup = coin_cell
```

If the file on the card ever looks different from this, I assume someone has changed it, or the card has been replaced, and I compare the input names against the tags on the probe leads.

### Spares and consumables

What I keep in stock for this logger:

- One spare memory card of the same kind.
- One spare coin cell for the clock, in its wrapper.
- A few stainless mounting screws.
- A spare blank plug for the cable glands.
- A small bag of silica gel to drop inside the housing in the wet season. I replace it whenever it changes colour.
- A little tube of grease for the lid latch and gland threads.

Things I deliberately do not stock: a spare mains board, a spare main board, and spare probes. If any of those fail, the logger has to be looked at properly, and a spare would not save me time.

### Routine part checks

A short list I follow when I am in the greenhouse anyway:

1. Look at the three status lights. Power on, logging on, fault off.
2. Look at the lid and seal for fog, cracks or drips.
3. Look at the power lead and its clips.
4. Feel the probe leads for stiffness or splits.
5. Open the box only if something looked wrong, and keep it open for as short a time as possible.
6. Every few months, take out the card and copy the logs.
7. Once a year, in the cooler season, replace the silica gel and check the coin cell by seeing whether the clock held its time through any outage.

### Known weak points

- The lid latch is stiff when cold.
- The lid seal has flattened over the years since 2014.
- The humidity sensor is the first thing to give wrong readings.
- The coin cell is the only battery, and the clock fails quietly when it runs down.
- Mains in the greenhouse is exposed to damp, so I keep the socket cover closed and never run extension leads across wet floor.

### If a part needs replacing

Replace one part at a time, then watch the logs for a day before changing anything else. Write the change in my own notes with the year. Keep the serial number SN-61830199 as the identity of the unit, since the parts around it may change over time but the logger itself stays the same yellow mains-powered data logger in the greenhouse.
