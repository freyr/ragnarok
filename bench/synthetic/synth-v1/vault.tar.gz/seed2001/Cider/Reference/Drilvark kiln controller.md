---
type: reference
status: active
project: reference
area: cider
---

# Drilvark kiln controller

## Lessons

The Drilvark kiln controller is a grey kiln controller that sits in the workshop. I installed it in 2016, and it belongs to the cider area of my notes. It runs on solar energy, which shapes almost every lesson I have learned about it.

- Solar power is not steady. On cloudy days the controller still has to behave, so I stopped trusting any schedule that assumes full power at a fixed hour.
- The grey case looks tidy but shows dust badly. I wipe it down at the start of every season, because dust on the vents is the first sign of trouble.
- Writing down the settings that work is worth more than remembering them. Twice I lost a good drying profile because I changed it and did not record the old one.
- The workshop gets cold in winter. The controller reads low when the room is cold, so I compare it against a second thermometer before I believe a strange number.
- Small changes are better than big ones. I change one setting, run a batch, and look at the result before changing anything else.
- Dried apple rings for the cider work need a gentle, even warmth. Hot spots spoil them, and the controller only helps if the kiln itself is loaded evenly.

After years of use, my main conclusion is that the device is reliable, but only when I treat the power supply and the room temperature as part of the system.

## References

This section is a quick sheet of the basic facts, plus where I look when I need more.

| Property | Value |
|---|---|
| Name | Drilvark kiln controller |
| Kind | kiln controller |
| Area | cider |
| Color | grey |
| Energy source | solar |
| Year installed | 2016 |
| Location | workshop |

Other places I look:

- My own batch log, kept in the cider folder of this vault.
- The paper sheet taped inside the workshop cupboard door, which lists the usual settings.
- The notes I made during the 2016 installation, which explain how the wiring was done and why.
- Photos of the control panel, taken before I changed anything major.

I do not keep the manufacturer manual in this note. When I need it, I check the folder where I store the printed copy.

## Ideas

Things I might try, in no particular order:

- Add a small battery buffer so the controller does not drop out when a cloud passes over the panel.
- Fit a second temperature probe near the door of the kiln, where the air is always a little cooler.
- Make a simple label for each knob and button, since I forget which one does what after a long winter.
- Keep a short paper logbook next to the controller so I can note the weather when I run a batch.
- Build a cover for the panel that keeps sawdust and cider splashes off the display.
- Test whether running the kiln in the early afternoon, when the sun is strongest, gives a more even result than running it in the morning.
- Move the grey case a little higher on the wall so it is easier to read without bending.

Of these, the battery buffer and the second probe are the ones I would do first, because they address the two problems I meet most often.

## Software

The controller runs firmware version v8.44.195. I have not changed it since I checked it last, and I do not plan to update it unless something is actually broken. An update on a solar system is risky if power drops halfway through, so I would only do one on a clear, sunny day with the battery full.

What the software does for me, in plain terms:

- It holds a few saved heating profiles that I can pick from the panel.
- It shows the current temperature and the target temperature.
- It keeps a short history of the last runs, which I read before starting a new one.
- It stops heating if the probe reading looks impossible.

I keep my usual profile written down in this simple form, so I can enter it again if the memory is ever wiped:

```
profile: apple-rings
start_temp: low
ramp: slow
hold: long
cooldown: natural
alarm_on_probe_fault: yes
```

The values above are descriptive only, not exact numbers. The real figures are on the sheet inside the cupboard door. The point of the block is the order of the steps and the fact that the probe fault alarm is always switched on.

## Costs

I do not keep exact prices here, since they change and I would rather not carry stale figures. What matters is the shape of the spending.

- Purchase and installation: this was the largest single cost, paid in 2016. It included the controller itself, the wiring, and the solar connection.
- Running cost: very low, because the energy source is solar. This is the main reason I chose it.
- Maintenance: mostly my own time. I clean the case, check the cables, and test the probe.
- Replacement parts: occasional. The probe is the part most likely to wear out, so I keep the idea of a spare in mind.
- Hidden cost: lost batches when the sun is poor. Fruit that dries badly is a real loss in the cider season.

Looking back over the years, the controller has paid for itself in saved electricity and fewer ruined batches. If I add the battery buffer from my ideas list, it will be the next real expense.

## Checklist

Before each run in the workshop:

- [ ] Wipe the grey case and check that the vents are clear.
- [ ] Look at the sky and decide if there is enough sun for a full run.
- [ ] Check the solar cables for damage or loose connections.
- [ ] Compare the display with a second thermometer.
- [ ] Load the kiln evenly, leaving space for air to move.
- [ ] Select the right profile for the batch.
- [ ] Confirm that the probe fault alarm is on.
- [ ] Write the date and weather in the batch log.

After each run:

- [ ] Let the kiln cool down naturally.
- [ ] Note anything odd on the display.
- [ ] Switch the controller off and cover the panel.
- [ ] Record what worked and what did not.

## Safety

A kiln is hot, and a controller that fails can leave heat running with nobody watching. I treat this seriously, even though the setup is small.

- Never leave the kiln running unattended for long, especially on a day when the sun is changing.
- Keep dry sawdust, paper, and cider-making clutter away from the kiln and the controller.
- Check the probe before every season. A faulty probe is the most dangerous failure, because the controller then works from wrong information.
- Do not open the controller case while the solar supply is connected. Disconnect it first and wait a moment.
- Keep a fire extinguisher near the workshop door, and make sure I know how to use it.
- Use gloves when unloading the kiln. The metal stays hot long after the display shows a safe number.
- If the display behaves strangely, switch everything off, let it cool, and investigate only afterwards.

The rule I repeat to myself is simple: if I do not trust the reading, I stop the run.
