---
type: reference
status: active
project: reference
area: cider
description: "Reference about Fakiosto valve actuator."
---

# Fakiosto valve actuator

## Risks

The Fakiosto valve actuator is a yellow, battery-powered valve actuator that I installed in the loft in 2023. It belongs to the cider area of my setup. Because it runs on a battery and sits in the loft, most of the risks come from those two facts.

- The battery can run flat without warning. If it dies while the valve is partly open, the valve stays where it was. For cider that could mean a transfer line left open or a line left shut when it should be flowing.
- The loft gets hot in summer and cold in winter. Battery capacity drops in the cold, and heat shortens the life of the cell over the years.
- The loft is hard to reach. A fault there means a climb with a torch and a ladder, so small problems tend to be put off.
- Dust and damp can get into the housing. Cider work produces sticky vapour, and anything that settles on the actuator can slow it down.
- A firmware update done halfway can leave the device in an odd state. I only update when I have time to stay and watch it finish.
- If I forget to check the readings, I may not notice a slow drift in how the valve behaves until it has become a real problem.

I keep these risks in mind whenever I plan a batch. The safest habit is to look at the actuator before every run and not to assume it is fine because it was fine last time.

## Background

The Fakiosto valve actuator is a device of the kind "valve actuator". Its colour is yellow, which makes it easy to spot among the grey pipework and the dark beams in the loft. Its energy source is a battery, so there is no mains cable running up to it. It was installed in 2023 and it lives in the loft.

I chose a battery model because running power to the loft would have meant extra work and extra cost, and I wanted the job to be simple. The actuator turns a valve on the cider line when it is told to, and that saves me from climbing up each time I want to change the flow.

The area it serves is cider. That covers the pressing, the settling and the moving of juice from one vessel to another. The actuator is only one small part of the whole arrangement, but it is the part that is hardest to get to, so I want it to be reliable.

I keep related notes elsewhere. The readings that I take around the setup go into my [[Daeltor Losvind log]], and for general advice on the recording equipment I use, I refer to the [[Denddrurk data logger handbook]]. Both are useful when I try to work out whether the actuator is behaving the way it did before.

In plain terms, the actuator is a simple device that does one job. Its main qualities are listed here so that I can find them quickly.

- Kind: valve actuator
- Area: cider
- Colour: yellow
- Energy source: battery
- Year installed: 2023
- Location: loft

## Open questions

There are several things I still do not know about the actuator, and I would like to settle them over time.

- How long does one battery really last in the loft, across a whole year? I have a rough feeling but no solid record.
- Does the winter cold change how fast the valve turns? I suspect it does, but I have not measured it.
- Is the housing truly sealed against the vapour from the cider? I have seen some residue and I am not sure how it gets in.
- Would it be worth adding a second way to see the valve position without climbing up?
- Should I move the actuator to a spot that is easier to reach, or is the loft the best place after all?
- How often should I really update the firmware, given that the loft is awkward to reach?

I will cross these off as I find out. Where an answer comes from a measurement, I will put the result in the [[Daeltor Losvind log]] first and then summarise it here.

## Checklist

This is the list I go through before a cider run and after any change to the setup.

- Climb up and look at the yellow actuator. Check that the housing is clean and dry.
- Check that the battery is fresh enough for the job ahead. If in doubt, replace it before the run, not after.
- Move the valve once by hand or by command and watch that it turns smoothly.
- Confirm that the valve ends up in the position I expect.
- Look at the firmware version and make sure it matches what is written in the Software section of this note.
- Write the result in the [[Daeltor Losvind log]].
- Take the ladder down and put the torch back where it belongs.

After a run I repeat the first three items. It takes only a few minutes, and it has already saved me from one stuck valve.

## Ideas

Some thoughts for improving the arrangement, none of them urgent.

- Fit a small cover over the actuator to keep dust and drips off it.
- Mark the valve with a paint line so the open and closed positions can be seen at a glance.
- Keep a spare battery in a labelled box near the loft hatch, so I never have to go back down to fetch one.
- Add a simple data logger nearby to record temperature, so I can compare the cold of the loft with how the actuator behaves. The [[Denddrurk data logger handbook]] should help me choose the setting for that.
- Write a short card with the steps for a manual override and tape it by the hatch.
- Try a different kind of battery that copes better with cold, and compare the two over a winter.

If I try any of these, I will note the result in the history part of this note.

## Schedule

I do not keep a strict calendar, but I have a rough rhythm that works for me.

- Before every cider run: the full checklist above.
- Once a month: a visual check of the housing and a test movement of the valve.
- Every spring: a closer look at the seals, the fixings and the wiring, and a fresh battery.
- Every autumn, before the main pressing: a second fresh battery check and a test of the whole line.
- Whenever the firmware needs attention: a planned visit with enough time to finish the job without rushing.

The spring and autumn visits are the important ones. The loft is easiest to work in during mild weather, so I try to do the longer jobs then.

## Costs

I have not tracked the costs in detail, and I do not want to guess at amounts, so I describe them in kinds rather than figures.

- The purchase of the actuator itself was the biggest single cost, paid in 2023.
- Batteries are the regular cost. Because the loft is hot and cold by turns, I replace them more often than the maker suggests.
- Small items such as seals, ties and a cover are occasional costs.
- My own time is also a cost. Every trip to the loft takes effort, so anything that reduces the number of trips is a saving.

Choosing a battery model over a mains-powered one avoided the cost of running a cable to the loft. That was the main reason I accepted the ongoing cost of batteries.

## Safety

The loft is the main safety concern, more than the actuator itself.

- Use a stable ladder and have someone know that I am up there.
- Take a torch, because the light is poor and the beams are low.
- Watch my head and my footing. Walk only on the boards and not on the gaps between them.
- Keep the area around the actuator free of spills. Cider is sticky and a wet floor is slippery.
- Handle the battery carefully. Do not short it, do not leave it in strong heat, and dispose of old cells properly.
- Make sure the valve is in a safe state before I let go of it. A line left open by mistake can send juice where it should not go.
- Do not work on the actuator while the line is under flow. Stop the flow first, then climb up.

If anything looks damaged, such as a swollen battery or a cracked housing, I stop and deal with it before the next run.

## Overview

The Fakiosto valve actuator is a yellow valve actuator in the cider area. It is powered by a battery, it was installed in 2023, and it sits in the loft. Its job is to move a valve on the cider line so I do not have to do it by hand each time.

I treat it as a quiet part of the system. When it works, I do not think about it. When it fails, the effect shows up quickly in the flow of the cider, so I keep a regular watch on it.

The key facts are these.

- Name: Fakiosto valve actuator
- Kind: valve actuator
- Area: cider
- Colour: yellow
- Energy source: battery
- Year installed: 2023
- Location: loft

The records about it are split across a few notes. This note is the reference. The running readings are in the [[Daeltor Losvind log]], and the general guidance on logging equipment is in the [[Denddrurk data logger handbook]].

## History

The actuator was installed in 2023. Before then I opened and closed the cider valve by hand, which meant going up to the loft whenever I wanted to change the flow. That was tiresome, and I sometimes forgot to go back and close the valve at the right moment.

After the installation, the first season was mostly about learning how the battery behaved. I found that it drained faster than I had hoped once the weather turned cold. I then began replacing it on a regular schedule and writing the dates in my log.

In the following years I added small improvements, such as marking the valve positions and keeping a spare battery close at hand. I also began to compare my readings against the notes in the [[Daeltor Losvind log]], which helped me see patterns that I would otherwise have missed.

Now, in the years since 2023, the actuator has become a reliable part of the cider work. It has not been perfect, but the faults have been small and easy to fix once I found them.

## Software

The actuator runs firmware, and I keep the current version written down so that I can check it quickly.

- Firmware version: v5.38.453

I check the version before each major cider season and after any update. If the number shown on the device does not match the one written here, I stop and find out why before I rely on it.

Updates are not something I do casually. The actuator is in the loft, it runs on a battery, and a failed update could leave the valve in a position I did not choose. So I follow a few simple rules:

- Start with a fresh battery so the power does not run out in the middle of the update.
- Make sure the line is not in use.
- Stay with the device until the update has finished, and then test the valve a few times.
- Update this note straight away with the new version.

If I ever need advice on how the readings from the actuator relate to my logging gear, I look in the [[Denddrurk data logger handbook]].

## Tools

The tools I need for the actuator are few and simple. I keep most of them in a small box near the loft hatch.

- A stable ladder for reaching the loft.
- A torch, preferably a head torch so that both hands are free.
- Spare batteries of the correct type, kept in a labelled container.
- A soft cloth and a small brush for cleaning dust and residue from the yellow housing.
- A small screwdriver set for the cover and the fixings.
- Cable ties and a few spare seals.
- A marker pen and a notebook, or my phone, for writing readings into the [[Daeltor Losvind log]].
- The [[Denddrurk data logger handbook]], either printed or open on my phone, for reference when I set up logging.

I check the box at the start of each season and replace anything that has gone missing or worn out. Having everything in one place means that a visit to the loft is short and that I do not have to go up twice.
