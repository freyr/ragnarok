---
type: research
status: active
project: nallis-automation
area: cider
description: "Research about Siogliork Giola."
---

# Siogliork Giola tests

## Setup

These notes cover the checks I ran on Siogliork Giola, who works as an inspector in the cider area. I wanted one place to record how I deal with them, what I know about their work, and what has been agreed on paper. Everything here is for my own use, so it is short and practical.

The basic facts, as I keep them:

- Name: Siogliork Giola
- Role: inspector
- Area: cider
- Contact: email
- Availability: weekdays
- Known since: 2009

I contact Siogliork by email only. I have never had a reason to try another channel, and email leaves a written trail, which matters when an inspection result is questioned later. Because they are available on weekdays, I plan any request for a working day and do not expect an answer over a weekend. If I send something on a Friday afternoon, I assume the reply will come early the following week.

## Background

I have known Siogliork since 2009. We first met through the local cider trade, when I was still learning how orchards, presses and cellars fit together. Even then, Siogliork was the person other producers mentioned when they wanted a straight opinion about a batch or a process. Over the years that reputation has held up.

As an inspector in the cider area, Siogliork looks at the practical side of production. That means how fruit is received and stored, how the pressing room is kept, how barrels and tanks are cleaned, and how finished product is labelled and recorded. I do not claim to know every detail of their method. What I do know comes from watching visits, reading the reports they send, and asking questions afterwards.

Some things I have noticed about working with them:

- Reports are clear and written in plain language, so I can act on them without a second round of questions.
- Siogliork prefers to be given records in advance. When I send logs before a visit, the visit goes faster.
- Questions are answered directly. If something is outside their remit, they say so and do not guess.
- They are consistent. The same standard is applied on each visit, which makes it easier to compare one season with the next.

My own habit is to keep a short list of open points after each inspection. I send it by email, since that is the agreed contact method, and I wait for a reply on a weekday. This keeps the thread tidy and gives me something to look back at when preparing for the next visit.

One thing I want to improve is how early I gather my paperwork. Too often I have started searching for records only after a visit was already arranged. Since Siogliork values preparation, I should treat the records as a standing task and not a last-minute one.

## Contracts

The contract with Siogliork Giola is dated 2025-04-16. I keep a copy of it with the other paperwork for the cider side of things, and I refer back to it whenever I am unsure what a visit should cover.

Practical points I check against the contract:

- Who is responsible for sending records before a visit.
- How results are delivered, which in practice is by email.
- Which days are suitable for visits, given that Siogliork is available on weekdays.
- What happens if a visit has to be moved.

Because we have known each other since 2009, a lot of our working arrangement rests on trust built up over many years. Even so, I prefer to have the terms written down. The contract date is the starting point for any question about what was agreed, and it helps me see whether a habit we have drifted into is actually covered or is only a custom.

When the contract comes up for review, I plan to go through it with Siogliork by email first, so both of us have the wording in front of us. I will note any changes in this file afterwards, so the record stays accurate.
