---
type: summary
status: active
project: nallis-automation
area: cider
description: "Summary about Nallis automation."
---

# Summary of Nallis automation

## Lessons

Nallis automation is a project with the goal of automation in the cider area. It started in spring 2019 and the inspector leads it. The main lesson so far is that the work goes better when the inspector checks each step by hand before we automate it. Steps that were automated too early had to be redone. Keeping the notes short and current also saved time when picking the work up again after a break.

## Decisions

The go decision for Nallis automation was made on 2022-12-22. Since then the scope has stayed small: automate the routine checks first and leave the unusual cases to the inspector. Open points remain on how to handle exceptions, and I have not settled them yet. I will record each answer here once it is agreed.

## Next action

The next action is NX-5570. I will start there, and then review the open points on exceptions with the inspector before taking on anything new.
