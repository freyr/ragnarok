---
type: plan
status: active
project: nallis-automation
area: cider
description: "Plan about Zuleth Sionban."
---

# Zuleth Sionban plan

## Open questions

These are the things I still need to settle with Zuleth Sionban, my neighbor, before I treat the cider arrangement as firm.

- Who supplies the bottles this season, and who cleans them? We have never said it out loud.
- Does Zuleth want to keep pressing at my place, or move everything to the shed next door?
- How much of the juice should be set aside for a dry batch and how much for a sweeter one?
- Is email still the best way to reach Zuleth, or would a short chat over the fence be easier in the evenings?
- Should we write down who owns the press, or leave it as an understanding between neighbors?

I want answers to these before the next pressing. None of them is urgent, but leaving them open has caused small confusion before.

## Contracts

There is no formal legal contract between us. What I call the contract is a simple agreement about sharing cider work, and I keep it written down so I do not rely on memory.

The contract date of Zuleth Sionban is 2019-04-22. That is the day we agreed on the basic terms: we share the effort of making cider, and we split the result in a fair way.

Terms as I remember them:

- Zuleth handles most of the fruit collection.
- I handle the pressing and the first stage of fermentation.
- We divide the finished cider by agreement, and nobody keeps a strict count.
- Either of us can step back from the arrangement by telling the other by email.

Because the agreement is informal, it only works while we both keep talking. I should review the terms each autumn and note any changes here.

## References

Here is the quick reference table for Zuleth Sionban. I keep it so I do not have to search my mail for basic facts.

| Property | Value |
| --- | --- |
| Name | Zuleth Sionban |
| Role | neighbor |
| Area | cider |
| Contact | email |
| Availability | evenings |
| Known since | 2019 |

Practical notes on using this table:

- Because the contact method is email, I send a message first and wait for a reply instead of knocking on the door unannounced.
- Because availability is evenings, I plan any joint work for after the normal working day.
- The area is cider, so this note is filed with my other cider planning material.

## Background

I have known Zuleth Sionban since 2019. We met as neighbors, and the first real conversation was about apples: both of us had more fruit than we could use, and neither of us wanted to see it rot on the ground. That conversation led, within a few months, to the agreement described in the Contracts section.

Zuleth is a neighbor first, and a cider partner second. That order matters to me. If the cider work ever became a burden, I would want the friendly relationship over the fence to survive it. For that reason I try to keep the arrangement light and flexible, with no pressure and no scorekeeping.

Contact is almost always by email. Zuleth is rarely free during the day, so evenings are the time when anything gets done together. A typical exchange goes like this: I send a message early in the week suggesting an evening, Zuleth replies with a yes or a no, and we settle the details on the day. This works well and I see no reason to change it.

What I have learned over the years:

- Start the planning early, because fruit does not wait for anyone's calendar.
- Agree on the jobs before the day, so that the evening is spent working and not discussing.
- Keep the written notes short and honest, and update them when something changes.
- Say thank you, since a shared hobby survives on goodwill.

The plan for the coming season is simple. I will send an email to settle the open questions listed at the top of this note, confirm an evening for the first pressing, and check that the equipment is clean and ready. After the pressing I will record what we did, how the juice turned out, and anything we want to do differently next time. Over time these notes should give me a clear picture of how the partnership works, and they will help whoever takes over the cider work in the future understand why we do things the way we do.
