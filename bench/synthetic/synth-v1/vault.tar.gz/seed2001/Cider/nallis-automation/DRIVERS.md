---
type: drivers
status: active
project: nallis-automation
area: cider
description: "Drivers about Nallis automation."
---

# Drivers of Nallis automation

## Setup

Nallis automation is a project that started in spring 2019. Its goal is automation, and it sits in the cider area. The lead is the inspector, who signs off on each stage and decides when something is good enough to keep.

The main driver is to take repetitive hand work out of the cider routine so that batches come out the same way each time and less time goes into checking and logging.

Constraints I keep in mind:

- The work has to fit around the spring season, when the schedule is tightest and there is little room for downtime.
- Any change must not alter the taste or quality of the cider.
- Equipment should be simple enough to repair myself.
- The inspector must be able to see and verify what the automation does.

Success is measured in plain terms:

- Fewer manual steps per batch than before.
- Fewer mistakes in the records.
- Time saved on each batch, which I note down after every run.
- The inspector accepts the result without needing extra checks.

## Budget

The budget of Nallis automation is 3049.53 EUR. It covers parts, tools and any small repairs along the way. I try to keep spending in step with the stages the inspector approves, and I do not start a new stage until the previous one has proven itself. If costs begin to drift, I cut scope rather than ask for more money.
