---
type: drivers
status: active
project: gisinzil-repair
area: cider
description: "Drivers about Gisinzil repair."
---

# Drivers of Gisinzil repair

## Lessons

The main lesson from Gisinzil repair is that the goal has to stay narrow. The goal is repair, and nothing else. Every time I let the project drift toward improving the cider area as a whole, the work slowed down and the budget started to look unreal. The project began in spring 2024, and the spring start still shapes how I think about it. The cellar is cool, the first pressing season is far enough away to leave some slack, and the inspector can walk the site without the rush of harvest.

The second lesson is that the inspector, who leads the project, is the right person to hold the drivers. The inspector looks at the equipment and the rooms with no stake in making them look good. When I wrote my own drivers in the first weeks, I leaned toward what was easy to fix. The inspector's list leaned toward what was likely to fail. Those lists were different, and the second was the useful one.

The third lesson is to write down the measurement before the work, not after. I did this late on the first stage and had to reconstruct what "fixed" was supposed to mean. For the second stage I wrote the success test first, and the work went faster because nobody argued about when to stop.

The fourth lesson is that reading old notes pays off. The [[Faelglor cellar handbook]] already described several of the failure patterns I met, and I lost time by not opening it on day one. I now open it before any new repair decision.

The last lesson concerns scope words. "Repair" means returning a thing to its previous working state. It does not mean upgrading it. When a repair needs a better part than the original, I log it as a separate decision and do not fold it silently into the goal.

## Problems

The problems that drive this project fall into three groups: measurement, access and confidence.

Measurement is the first group. Several readings in the cider area could not be trusted. Levels in the vessels drifted between checks, and I could not tell whether the vessel or the instrument was at fault. That uncertainty is the core reason the project exists. A repair that does not settle which side is wrong would only move the doubt somewhere else. The [[Sethzand level sensor notes]] record my early attempts to separate the two, and the [[Dusra level sensor study]] gives a second view of the same trouble from a different angle.

Access is the second group. The working space around the cider equipment is tight. Some fixes need a vessel emptied first, and emptying a vessel at the wrong time costs product. So the schedule is a real constraint, not a formality. I cannot repair whatever I like whenever I like. The spring start was chosen partly for this reason.

Confidence is the third group, and the hardest to write down. After a few failed readings, nobody wanted to rely on the equipment. People started checking by hand and by eye, and the checks were not logged. That meant two sets of unrecorded numbers, neither one trusted. Part of the goal is to restore enough confidence that the hand checks can stop, or at least be written down.

There is also a smaller problem of inherited assumptions. Some of the old setup was built for a purpose I no longer remember. If I repair a part that was doing a hidden job, I may break something that worked. The inspector's habit of asking "what was this for?" before touching anything has saved me from at least one such mistake.

Finally, there is a problem of overlap with other work. The [[Kulpoth workshop plan]] also draws on my time and on the same tools. When both are active, the repair work loses out because it is quieter. I need to protect its time on purpose.

## Supplies

Supplies are a driver because the repair can stall on a missing item more easily than on a hard problem. I keep a short list of what the project needs on hand, and I keep it grouped by purpose, not by shop.

The first group is sensing supplies: replacement level sensing parts, cable, connectors and sealing material suited to a damp cellar. The [[Sethzand level sensor notes]] hold what I learned about which of these hold up in the cool and wet conditions. I do not repeat the details here.

The second group is cleaning and food-safe supplies. Anything that touches the cider area must be safe near product. This constrains my choices. A cheaper sealant or lubricant is not an option if it is not rated for that use. I check this before buying, and I record the choice so I do not have to repeat the check.

The third group is general workshop consumables: fasteners, tape, labels, rags and basic electrical items. They are cheap, but running out of them wastes more time than any other shortfall. I keep a small buffer.

The fourth group is documentation supplies. This sounds odd, but a notebook, waterproof labels and a marker are part of the project. Every repaired item gets a label showing what was done and in which season. The label is the first thing the inspector checks on a later visit.

I do not buy for the whole project at once. I buy per stage, after the inspector has confirmed the stage's scope. That avoids stock that turns out to be the wrong kind, and it keeps the money flexible. Anything left over after a stage goes into a labelled box so I can find it later.

## Schedule

The project started in spring 2024, and spring remains the working season. I treat that as a driver, not just a fact. The cellar temperature is stable then, the vessels are in a low-activity state, and the pressing season is still ahead. Work done now has time to prove itself before it is needed.

I split the work into stages, and each stage has an order that follows from dependencies:

- First, confirm the state of the current equipment and what has actually failed.
- Second, settle which readings can be trusted, using the comparison work in the [[Glaelbrath scale study]].
- Third, repair or replace the parts the inspector flags as failing.
- Fourth, run the success checks and log the results.
- Fifth, write up the lessons and update the handbook notes.

The inspector sets the order and has the final say on moving from one stage to the next. I do not skip ahead, even when a later stage looks easy, because the later stages depend on what the earlier ones reveal.

Slack is deliberate. I leave gaps between stages so a surprise does not push the whole plan into the pressing season. If a stage runs over, the gap absorbs it. If the gaps are used up, I stop and reassess with the inspector instead of compressing the final checks.

I avoid writing exact calendar dates in this note. The dates change, and an outdated date in a drivers note is worse than none. What matters is the order and the season: spring, with the final checks finished before the busy period begins.

## Observations

Some observations shape how I read the drivers.

The failures cluster. Problems did not appear evenly across the cider area. They came from a few places with the same conditions: damp, cold and tight access. That tells me the repair should target conditions as well as parts. Replacing a sensor without dealing with the damp around it would likely repeat the failure.

Readings disagree in a patterned way. When two instruments disagreed, the gap was not random. It followed the position and the time of the check. This pattern pushed me toward comparison work, and the [[Dusra level sensor study]] gives a useful frame for it. It also made me suspicious of any single reading taken in isolation.

The inspector's eye is faster than my instruments. On several visits the inspector pointed out a problem by looking and listening, well before any reading showed it. I used to see that as a competing method. Now I see it as an input I should record. A short written note of what the inspector noticed is as useful as a number.

Radio signals around the site are uneven. Where equipment reports wirelessly, some spots lose the link. That matters for the repair because a "failed" sensor sometimes turned out to be a lost signal. My notes on the [[Girdael radio receiver]] and the [[Ridae radio receiver]] cover what I saw from each, and the main point is that I have to check the link before I blame the sensor.

People adapt around broken things. The hand checks and workarounds that grew up were reasonable, but they hid how bad the equipment had become. Part of the repair is surfacing those workarounds so I know what the system really depends on.

## Ideas

These ideas are not committed work. They are options I hold against the goal, and each must pass one test: does it serve repair, or is it something else in disguise?

One idea is a standard check card kept by each vessel. It would list what to look at and what a good state looks like. This supports the success measure directly, because the same check is then done the same way every time.

Another idea is to swap the sensing method on one vessel as a trial, and compare it with the existing method over a season. It is attractive, but it is closer to improvement than repair. I keep it as a trial, clearly labelled, so it cannot quietly redefine the goal.

A third idea is to improve the signal path for wireless reporting, perhaps by moving a receiver. The [[Girdael radio receiver]] and the [[Ridae radio receiver]] notes would be my starting point. I would try the move on a temporary basis before drilling or fixing anything permanently.

A fourth idea is to fold what I learn into the [[Faelglor cellar handbook]] as a short troubleshooting section. This costs little and gives the most lasting value. Future me, or anyone else who works in the cellar, would not need to relearn the same lessons.

A fifth idea is to schedule a regular, light inspection after the project ends. The repair is only as good as its upkeep. If the inspector can do a short seasonal walk-through, small faults stay small.

I rank these by how much they serve the goal and how little they threaten the budget. The check card and the handbook update come first. The trials come last, and only if the main work finishes with money to spare.

## Costs

Costs for this project come in four kinds: parts, consumables, time and risk of loss.

Parts are the clear line items: sensing parts, connectors and any replacement hardware. They are the easiest to estimate and the easiest to overspend on, because there is always a slightly better option.

Consumables are small, but they add up. Sealing material, food-safe lubricant, tape, labels and cleaning supplies are bought repeatedly. I track them as a group and do not itemise each purchase.

Time is a real cost, even though I do not put a price on my own hours. It shows up in lost days and in the pull on other work such as the [[Kulpoth workshop plan]]. I count it when deciding whether to repair a part myself or replace the whole unit. If repair takes much longer than replacement, replacement may be the cheaper choice overall.

The risk of loss is the cost that hurts most. If a vessel must be emptied for a fix and the timing is wrong, product can be lost. That loss is worth more than most parts. So I plan stages so that product is exposed to as little disturbance as possible, and I accept a slightly slower plan if it protects the product.

I keep spending visible. After each stage I note what was spent against what I expected. If a stage overshoots, the next stage has to give something back or the inspector and I reconsider scope. I do not hide an overrun inside later work.

I also separate repair costs from improvement costs. Anything that goes beyond returning an item to working order gets its own line, outside the repair budget. This keeps the headline figure honest and stops the project from growing in small steps. The full allowance is in the Budget section.

## History

The Gisinzil repair project began in spring 2024. Before then, the cider area had been running with growing doubts about its equipment. Readings drifted, workarounds multiplied, and nobody felt sure which numbers were real.

The early phase was mostly looking. I read through old material, including the [[Faelglor cellar handbook]], and began comparing instruments. The [[Glaelbrath scale study]] came out of this period. It was my first attempt to put the measurements on a common footing, and it taught me that even the reference points needed checking.

The next phase added more focused sensor work. The [[Sethzand level sensor notes]] record what I tried on level sensing, and the [[Dusra level sensor study]] adds a second line of comparison. Neither settled the question alone. Together they narrowed the likely causes.

Around then I brought the inspector in as lead. That changed the project. Before, I had been working from my own list. After, the work followed an outside view of what was most likely to fail and what would matter most if it did. The scope became tighter and the goal stayed on repair.

Along the way I looked at the reporting side, which meant the radio receivers. The notes on the [[Girdael radio receiver]] and the [[Ridae radio receiver]] come from that stage. They showed me that some apparent equipment failures were really signal problems, and that changed how I order the checks.

The project is still in progress. This drivers note is the place where I fix what the project is for, so that later history does not rewrite the original intent.

## Setup

The setup of the project is simple on purpose. The subject is Gisinzil repair. It is a project, with the goal of repair, in the cider area. It started in 2024 and runs in the spring season. The lead is the inspector.

I keep these properties together because they define the drivers. The goal tells me what counts as success. The area tells me which rules apply, such as food-safe materials and cool, damp conditions. The start year and season tell me about timing. The lead tells me who decides.

The practical setup has three parts. First, a working folder holds the notes, checklists and the log of what was done to each item. Second, a small tool kit stays near the cider area so I do not carry things back and forth. Third, a labelling routine marks each repaired item with what was done and when, in season terms and not exact dates.

The inspector's role in the setup is to review and to approve. I propose a stage, the inspector walks the site, and we agree on the scope before I start. At the end of the stage the inspector checks the result against the success measures. If it passes, we move on. If not, we fix it and check again.

Success is measured in plain terms. A repaired item works as it did originally. Its readings agree with an independent check. Nobody needs a hand workaround to trust it. And it holds through a stretch of normal use without further attention. I record each of these as a simple yes or no per item, with a short note if the answer is no.

The setup also includes a stop rule. If a repair would go past the goal, becoming an upgrade, I stop and log the decision separately.

## Background

The cider area depends on measuring and watching things that are easy to take for granted: levels in vessels, conditions in the cellar, and the state of the equipment that reports them. When these work, nobody notices. When they fail, trust falls quickly and the area runs on guesswork.

Gisinzil repair exists because that trust had eroded. The project is a repair, so its aim is to return things to a state that already worked. That is a more modest goal than redesign, and it suits the situation. I know what the equipment used to do, and the aim is to make it do that again, reliably.

The background reading has been useful. The [[Faelglor cellar handbook]] holds general knowledge about the cellar and how it behaves. The [[Glaelbrath scale study]] gives me a basis for comparing measurements. The two sensor notes, [[Sethzand level sensor notes]] and [[Dusra level sensor study]], cover the level sensing in detail. Together they make up most of what I know about why readings drift.

The inspector brings the other half of the background: practical experience of how cellar equipment fails. That experience is not written down anywhere, so part of my task is to capture it as notes, without turning it into false precision.

The cider area itself imposes constraints that come from outside the project. Anything used near product must be safe for it. The cool, damp environment shortens the life of many parts. Access is limited. And the area has to keep running during the work, which restricts when vessels can be emptied or disturbed. These constraints are part of the drivers, and they explain why the plan looks cautious.

## Risks

The main risks to the project are listed here with what I do about each.

The first risk is scope creep. A repair easily turns into an upgrade, one reasonable step at a time. My protection is the stop rule and the habit of logging upgrade ideas separately. The inspector acts as a second check.

The second risk is misdiagnosis. If I blame the wrong part, I spend money and time and the fault stays. Signal loss mistaken for sensor failure is the clearest example, and the notes on the [[Girdael radio receiver]] and the [[Ridae radio receiver]] come from that kind of mistake. I now check the link before the sensor, and I compare against an independent reading before I replace anything.

The third risk is product loss. Disturbing a vessel at the wrong moment can cost product. I plan around this and accept slower progress when it protects what is in the vessels.

The fourth risk is budget overrun. Parts can cost more than expected, and a stage can grow. I track spending after each stage and ask the inspector to reconsider scope before I go over the allowance.

The fifth risk is competing work. The [[Kulpoth workshop plan]] shares my time and tools. If it takes priority every time, the repair slips toward the busy season. I guard the repair time in the schedule and treat the final checks as fixed.

The sixth risk is hidden dependencies. Some old parts may have been doing a job I have forgotten. I ask what each part was for before I remove or change it, and I note the answer.

The last risk is weak follow-through. A repair that is not maintained fades. A light seasonal inspection and updated handbook notes are my response.

## Open questions

Several questions are still open, and they affect how I read the drivers.

Which readings can finally be trusted? The comparison work in the [[Glaelbrath scale study]] helps, but I have not yet closed the matter for every vessel. Until I do, I cannot say for certain whether some items need repair or only recalibration.

Is the level sensing fault in the sensors, the vessels or the signal path? The [[Sethzand level sensor notes]] and the [[Dusra level sensor study]] point in different directions on different vessels. I may find more than one cause, and the repair plan would then have to be split.

Should the receivers be moved? The [[Girdael radio receiver]] and the [[Ridae radio receiver]] behave differently in different spots. I do not yet know whether a modest move would remove most of the dropouts, or whether the building simply blocks the signal in places.

What exactly do the old workarounds protect? Some hand checks are likely there for good reasons. I need to learn which ones can stop and which ones must stay, at least until the equipment has proven itself.

How long should the proving period be? A repair is only reliable after a stretch of normal use. I have not fixed how long that stretch should be, and the inspector and I need to agree on it before I call the project done.

Where does repair end and improvement begin for items where the original part is no longer available? In that case a replacement may be better than the original, and I need a clear rule for treating such cases without breaking the goal or the budget.

## Tools

The tools for this project are modest. I list them by purpose so I know what to bring and what to check before each stage.

For measuring, I use a reliable reference instrument that I trust more than the equipment under repair. The [[Glaelbrath scale study]] explains how I chose reference points and why. I also keep a simple manual method as an independent check, such as a plain marked rod or a visual gauge, because a second method of a different kind catches errors that two similar instruments share.

For sensing work, I need basic electrical tools: a multimeter, wire strippers, a small soldering kit and a supply of connectors. The [[Sethzand level sensor notes]] list the practical points I learned about working in damp conditions, such as sealing joints and keeping connectors off the floor.

For signal checks, I use whatever lets me see whether a receiver is getting a link, together with a note of the position. The [[Girdael radio receiver]] and the [[Ridae radio receiver]] notes record what I found with each.

For general work, I keep standard hand tools, a torch, cleaning supplies and labels. Anything that touches product-contact surfaces is kept separate and clean.

For documentation, I use this vault. Each stage gets a short log, and each repaired item gets a physical label. The [[Faelglor cellar handbook]] is where lasting lessons go. The [[Kulpoth workshop plan]] covers shared workshop space and tools, so I check it before assuming a tool is free.

Before each stage, I run a simple check: do I have the tools, are they clean, and is the reference instrument still in agreement with the manual check? If not, I fix that first.

## Budget

The budget of Gisinzil repair is 3956.78 EUR.

This is the full allowance for the repair goal. It covers parts, consumables and the supplies needed to do the work and to label and record it. It does not cover upgrades or trials that go beyond returning equipment to its working state. Those are tracked separately, so the headline figure stays an honest measure of the repair.

I apportion the money by stage, not all at once. Each stage gets a share that matches its scope, and the inspector confirms the scope before I spend. After each stage I compare what I spent with what I expected and note the difference. A small underspend stays in reserve. An overspend has to be addressed before the next stage starts, either by reducing scope or by agreeing with the inspector that the work is justified.

I keep a reserve inside the allowance for surprises. Cellar equipment tends to reveal further faults once opened, and a plan with no reserve breaks at the first surprise. The reserve is not for improvements. It is only for repairs that turn out to be needed.

The budget is also one of the success measures. A project that meets the technical goal but blows the allowance has partly failed, because it would not be repeatable. So I read the result in three parts: the equipment works as it originally did, the readings can be trusted, and the spending stayed within the allowance. The lead, the inspector, signs off on all three.

If the budget ever has to change, I will record the new figure, the reason and who agreed to it, and I will not simply overwrite the old number.
