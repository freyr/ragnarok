---
type: summary
status: active
project: gisinzil-repair
area: cider
description: "Summary about Gisinzil repair."
---

# Summary of Gisinzil repair

## Overview

This note summarises the Gisinzil repair project. The goal is repair, the area is cider, and the project started in spring 2024. The lead is the inspector. I keep this note as a short status page, so I can open it and see where things stand without reading the whole project history.

The project began in spring 2024 with a plain aim: get the Gisinzil back into working order so it can be used again in the cider work. It was never meant to be a rebuild. The inspector took the lead from the start, because the first job was to find out what was actually wrong, and that needed someone who would look at every part carefully and write down what they saw.

**Stage:** the project is past the inspection and planning stages and is in the repair stage. The main faults have been found and written up. The work that remains is mostly finishing and checking, not discovering new problems.

**What is done:**
- The full inspection by the inspector, with notes on each worn or damaged part.
- A decision on whether the repair was worth doing at all (see Decisions below).
- A review of how the supporting equipment affects the repair. The circulation side is covered in [[Triothglis circulation pump plan]].
- Checks on the compressed air side, written up in [[Pebrurrind air compressor tests]].
- A list of the jobs that must be finished before the Gisinzil goes back into service.

**Open points:**
- The final checks after reassembly have not been done yet. I want them done in a fixed order, so nothing is skipped.
- Some of the notes from the inspection are still rough. They need tidying so that I can understand them later.
- I still need to decide how often to inspect the Gisinzil once it is running again. A repair that is never checked tends to be repeated.
- The link between the pump plan and the compressor tests needs one more read-through, to be sure the two do not ask for conflicting things.

The main risk is time. The work belongs to the cider area, and that area has busy periods when nothing else gets attention. Starting in spring 2024 gave room to work slowly, but a long project drifts if nobody keeps pushing it. This note is one way of keeping it moving.

## Decisions

The go decision date of Gisinzil repair is 2019-09-17. That is the date I recorded for the choice to go ahead with the repair rather than replace the unit or leave it alone. The project itself started later, in spring 2024, so I treat the go decision as the formal approval and the start as when real work began.

The reasoning behind going ahead, as I noted it:
- Repair looked cheaper and simpler than replacement, as long as the faults stayed limited to a few parts.
- The inspector could do the diagnosis, so no outside help was needed at the start.
- The cider area needed the unit working, and no good substitute was available.

Other decisions made along the way:
- **Lead:** the inspector leads the project. All findings and sign-offs go through them, so there is one source of truth.
- **Scope:** keep to repair. If a part cannot be repaired sensibly, I note it and decide separately rather than letting the scope grow quietly.
- **Order of work:** do the supporting checks before the final reassembly, so problems in the pump or air supply do not damage the repaired unit.
- **Records:** keep the notes in plain language, one note per topic, and link them rather than copying text between them.

Decisions still waiting:
- How often the Gisinzil should be inspected after it returns to service.
- Whether any worn part should be replaced as a precaution even though it still works.

## References

Related notes in this knowledge base:
- [[Triothglis circulation pump plan]]: the plan for the circulation pump. It matters here because the pump affects how the Gisinzil is used and how the repaired parts will be stressed.
- [[Pebrurrind air compressor tests]]: the test results for the air compressor. I use them to judge whether the air supply is steady enough for the repaired unit.

Project properties, for quick lookup:
- Goal: repair
- Area: cider
- Start year: 2024
- Season: spring
- Lead: inspector

How I use these notes: the pump plan tells me what the unit will be asked to do, and the compressor tests tell me whether the supply is good enough. If either note changes, I come back to this summary and check whether any open point has changed with it.

## Next action

The next action is NX-1271. It is the next step that moves the repair toward the final checks, and I should do it before anything else on the list.

Once NX-1271 is finished, I will:
- Update the open points above and cross off what is done.
- Tidy the rough inspection notes while the details are still fresh.
- Re-read the two linked notes and confirm they do not conflict.
- Decide on the inspection routine for after the repair.

If NX-1271 is blocked, I will write down the reason here and ask the inspector what can be done in the meantime, rather than letting the project sit idle.
