---
type: plan
status: active
project: gisinzil-repair
area: cider
description: "Plan about Vioskrirk heat exchanger."
---

# Vioskrirk heat exchanger plan

## Observations

The Vioskrirk heat exchanger is a yellow heat exchanger that sits in the cellar. It was installed in 2024 and runs on mains power. It is used for the cider work, and it is the one piece of kit in the cellar that I can spot from the stairs because of its colour.

Since the install, the cellar has been steadier than it was before. The cider cools more evenly when I run it through the exchanger than when I relied on the old cold-room method alone. I still see small swings when the cellar door is left open, so the door matters as much as the device.

The unit gives off a bit of warmth on the mains side, and the wall behind it stays dry. I check this each time I am down there. The floor near the unit gets damp after a cleaning run, so I leave it to air for a while before I move any barrels past it.

Noise is low. I notice a hum when the cellar is quiet, but nothing that changes how I work. If the hum changes pitch, I take that as a sign to look at the pump side first.

Cleaning is the main chore. Residue from the cider builds up if I leave it a few days, and it is much harder to shift once it dries. Rinsing straight after use is the habit I want to keep.

## Lessons

- Rinse the exchanger right after each run. Dried residue costs me far more time than a rinse ever does.
- Keep the cellar door closed during a cooling run. The device cannot make up for a draught.
- Do not move barrels past the unit while the floor is wet. Wait until it has dried.
- Write down what I changed whenever I change a setting. Memory is not reliable across a season.
- Keep the handbook close. The [[Faelglor cellar handbook]] has the routine for the cellar, and I should add the exchanger steps there instead of in scattered notes.
- Ask [[Selroth Tithstioth]] before any change to the mains wiring. They know the cellar circuit better than I do.

## Checklist

Before a run:

1. Check that the mains plug and cable are dry and undamaged.
2. Look at the hoses and clamps for any weeping.
3. Make sure the floor around the yellow unit is clear.
4. Close the cellar door.
5. Confirm the cider is ready to be moved.

After a run:

1. Rinse the exchanger with clean water until it runs clear.
2. Wipe the outside of the unit and the wall behind it.
3. Let the floor dry before moving barrels.
4. Note anything odd in the log: smells, sounds, leaks.
5. Switch off at the mains.

Once a season:

1. Inspect every seal and replace any that look tired.
2. Check the cable along its whole length.
3. Review the handbook entry and update it.
4. Think about whether a level reading would help; see [[Vilith level sensor plan]].

## Software

The unit has a small controller, and the firmware version of Vioskrirk heat exchanger is v2.27.164. I note it here so that I know what the unit was running if its behaviour ever changes.

I do not update the firmware in the middle of a cider season. If I ever do, I will do it when the cellar is empty, write the old version here first, and run a short test with water before any cider goes through.

The settings I care about are few: the target temperature and the run time. I keep them written in the log and not only on the screen, because a power cut could reset them.

If I add the level sensor from the [[Vilith level sensor plan]], I will need to check whether it can talk to the controller or whether it has to stay a separate gadget with its own display.

## Supplies

Things I want on hand for the exchanger:

- Food-safe cleaning solution, and a spare bottle.
- Clean water hoses, with a few spare clamps.
- Replacement seals in the right size for the unit.
- Soft brushes that will not scratch the plates or the pipework.
- Cloths and a mop for the cellar floor.
- A notebook and pencil that stay in the cellar, so the log is never missing.
- A spare mains lead, rated for a damp room.

Spare parts and the less-used cleaning gear are stored up in the [[Dalsti loft]]. I should check the stock there at the start of each season so I am not caught short in the middle of a run. Anything that gets used up goes on the list the same day, before I forget.
