---
type: log
status: active
project: gisinzil-repair
area: cider
description: "Log about Narkmin loft."
---

# Narkmin loft log

## Risks

Narkmin loft is a small loft, built in 2003, and it sits below ground. That last point is the source of most of the risks. It faces east, which gives a bit of morning light through the one opening, but not enough to dry anything out by itself.

- Damp is the main worry. Being below ground, the walls hold moisture, and it gets worse after long wet spells. I check the lower part of the east wall first, because that is where the staining begins.
- Poor airflow. With one small opening and no through draught, stale air builds up. I leave the door ajar when I am working inside.
- Flooding. In heavy rain, water can collect near the floor. Nothing should be stored directly on the ground.
- Mould on stored cloth and paper. Anything left for a season without being checked tends to smell musty.
- Low ceiling and steep access. The place is small, so it is easy to knock a head or drop something while carrying loads in and out.
- Poor light after midday. The east orientation means the room is dim in the afternoon, so I bring a lamp.

None of these is serious if I keep to a routine. The trouble starts when I skip a few visits in a row and the damp gets a head start.

## Admin

The lease reference of Narkmin loft is LR-991977. I quote it whenever I write to the landlord or the office that handles the cider area lots, and I keep it at the top of any message so it does not get lost.

Basic facts, so I do not have to look them up again:

- Kind: loft
- Area: cider
- Orientation: east
- Size: small
- Year built: 2003
- Floor: below ground

Things I need to keep up with:

- Renewal of the lease, which I should start thinking about well before the end of the term.
- Reporting any damp damage in writing, with photos, so there is a record that it was not caused by me.
- Keeping a copy of the lease paperwork at home and not only in the loft, since paper left down there goes soft.
- Telling the landlord if I change what I store, in case the terms restrict it.

## Supplies

I keep a small stock of items on site and restock when something runs low. Because the space is small, I only hold what I will use over a season or so.

- Moisture absorber tubs, two or three at a time, placed on a shelf and not on the floor.
- A small battery lamp, because the afternoon light is poor, plus spare batteries.
- Plastic crates with lids, for anything that must stay dry.
- Wooden pallets or slatted boards to lift crates off the ground.
- A hygrometer, to see whether the damp is rising between visits.
- Cloths, a stiff brush and a mild cleaner for wiping mould spots.
- Gloves and a dust mask for cleaning days.
- Sealable bags for cloth and paper.
- A torch for checking corners and the back of the shelves.
- A bucket and a sponge for water near the floor.

What I do not store here any more: untreated cardboard, loose paper, and anything with a strong smell that would linger. Those go in a drier place at home.

When buying, I prefer a few solid items over lots of cheap ones. Crates with tight lids and a decent lamp have both paid for themselves. The absorber tubs are the thing I run out of most often, so I check them first on every visit.

## History

Narkmin loft was built in 2003, as a small loft below ground in the cider area. From the start it has faced east, and it has always been a cool, slightly damp space with limited light.

In the early years I used it mostly as plain storage, and I did not pay much attention to the conditions. After a couple of wet seasons I found mould on some boxes, which taught me to lift things off the floor and to check the place regularly.

Later I added shelving and began using lidded crates, which made a clear difference. I also started keeping this log, so I could see patterns: damp rises after long rain, eases in dry weeks, and is worst in the lower east wall.

More recently my routine has settled into something simple. I visit, check the absorbers, look at the wall, wipe any spots, and note anything unusual. If a problem appears, I write it down here first and then decide whether it needs reporting under the lease.

The loft is not a glamorous place, but it is useful, and with regular care it does its job well. The main lesson from its history is that small, steady attention works better than occasional big clean-ups.
