---
type: log
status: active
project: vindraer-repair
area: cider
description: "Log about Daeltor Losvind."
---

# Daeltor Losvind log

## Background

Daeltor Losvind is my mentor for cider. I have known him since 2009, so this log covers a long stretch of learning from one person. He is the one I go to when a batch behaves strangely, when I am unsure about a blend, or when I simply want a second opinion on whether I am overthinking something.

The properties, kept here so I do not have to hunt for them:

- Role: mentor
- Area: cider
- Contact: in person
- Availability: weekends
- Known since: 2009

Because contact is in person and availability is weekends, I cannot just send a question and get an answer on Tuesday. I have to save my questions up. Over the years this has become a habit that helps me. By Saturday I have usually worked out half of what I wanted to ask, and the other half is better formed. I keep a running list on paper in the pressing shed and copy the leftovers into this log after each visit.

When we first met in 2009 I knew almost nothing. I had a few buckets, a borrowed press and a lot of enthusiasm. Daeltor looked at my first attempt, tasted it, and said only that it was a good start and that the apples were fine but my patience was not. That has been the theme ever since. Most of what he teaches comes down to waiting, watching, and writing things down.

This log is not a diary of every conversation. It is a working record: what he told me, what I tried, what happened, and what I would do differently. I write it for my own use, so some entries are blunt.

## Contracts

The arrangement with Daeltor has never been formal in the sense of money changing hands for lessons. But in 2023 we did put something on paper, because I started using part of his orchard store and press room, and he wanted the terms to be clear for both of us.

- Contract date of Daeltor Losvind: 2023-07-08
- Type: shared use of his press room and cool store during the season
- Role stays the same: he is still my mentor, not my employer and not my customer
- Visits stay on weekends, in person

What the paper covers, in my own words: I may use the press room on agreed weekends, I clean everything before I leave, I tell him what I take from the cool store, and I do not bring in other people without asking first. He covers the basic upkeep of the building and the press. If something breaks while I am using it, we talk about it and decide together who fixes it.

I keep a copy in the folder with the receipts. I have only needed to look at it twice. Once was when a pallet of crates arrived early and I was not sure whether I could stack them in the store, and once was when I wanted to know who was meant to replace a worn press cloth. Both times the answer was short and sensible.

One thing I like about the arrangement is that it did not change the relationship. Before the contract I was a visitor who got generous help. After it I am a visitor who gets generous help and has a clear list of rules. That is better.

## Observations

These are things I have noticed over many weekends with Daeltor. Some are about cider and some are about how he works.

**How he tastes.** He tastes slowly and says very little at first. He lets the glass sit for a moment, then smells it again, then drinks. When I used to rush, he would hand the glass back and tell me to try again in a minute. Now I do the same without being told.

**How he decides.** He rarely gives me a rule. He asks me what I think is happening and why. Only after I have said something does he fill in the gaps. This is slower than being told, but I remember it much better.

**What he watches.** He watches temperature more than almost anything else. Fermentation that runs too warm loses the delicate fruit notes, and he can usually tell from the smell alone when something has gone too quick. He also watches the weather during pressing weekends, because wet fruit is harder to handle and the juice is thinner.

**What he does not worry about.** He is relaxed about small cosmetic things: a slightly cloudy batch, a bit of sediment, a label that is crooked. He is strict about cleanliness, about topping up vessels so there is little air above the cider, and about not rushing a bottling.

**His routine.** He starts early on weekends. If I arrive after mid-morning, most of the real work is done and I am mostly there for the tasting. I learned to turn up early if I want to be useful. Tea first, then work, then lunch, then the questions.

**Patterns in my own mistakes.** Looking back through these notes, my errors repeat. I top up late. I forget to record the starting reading. I taste too soon after racking, when the cider is unsettled and tastes worse than it will. Daeltor has pointed out each of these more than once, and I have written each of them down more than once.

## Supplies

Daeltor keeps a plain, well-organised store, and I have copied some of his habits. This section is about what I use, what I bring, and what I borrow.

What I bring with me on a weekend visit:

- Clean sample jars with lids
- A notebook and two pens, because one always runs out
- Gloves and an apron for pressing days
- Sanitiser and a small brush
- Labels and a marker for anything I take home
- A towel, because there is never enough of them

What I usually borrow or share from his press room:

- The press and the pressing cloths
- Large fermentation vessels
- Airlocks and bungs
- Siphon tubing and a racking cane
- The scale and the hydrometer

What I buy for myself and keep at home:

- Yeast, in small quantities, stored cold
- Nutrient for slow ferments
- Bottles and crown caps
- Sulphite tablets, used sparingly
- Cleaning powder

I keep one rule about supplies: if I use the last of something at his place, I replace it the same week or tell him straight away. He has never complained about this, but I know how annoying it is to reach for something and find the box empty.

For monitoring the level in larger tanks I have looked at a few sensor options. My earlier comparisons are in [[Sethzand level sensor notes]] and [[Trendstil level sensor notes]]. Daeltor was not convinced either was necessary. His view is that a dipstick and a quick look are enough at the scale we work. I may still try one at home, where I cannot check as often as I would like.

## Overview

Looking at the whole stretch since 2009, here is the shape of it.

In the early years I mostly watched and carried things. I learned the order of work: sort the fruit, wash, mill, press, settle, rack, wait. I learned the vocabulary slowly. Daeltor never hurried me through it.

In the middle years I started making my own batches and bringing them for him to taste. This was the most useful stage. He would taste, say two or three sentences, and I would go away with a clear list of things to change. Some of his comments were about the fruit, some about the yeast, and a lot were about timing.

In recent years the contract in 2023 gave me a regular place to work. I now do most of my pressing in his room and take the juice home or leave it in his cool store depending on the plan. Our conversations have changed too. They are less about basic mistakes and more about style: how dry I want a batch, how much blending to do, and whether a particular apple is worth keeping separate.

Current state in a few lines:

- He is my mentor, and the area is cider.
- We meet in person, on weekends.
- I have known him since 2009.
- The shared-use paper is dated 2023-07-08.
- My main goal is to make a few consistent, well-balanced batches each year rather than many experimental ones.

What I value most is the steadiness. He is not trying to turn me into a copy of himself. He wants me to understand why things work so that I can make my own choices.

## Checklist

This is the list I run through before a weekend visit and before leaving. I copied it into this log so I do not rely on memory.

Before going:

- Read the last entry in this log and note open questions
- Write down the questions for Daeltor in order of importance
- Pack the sample jars, notebook, gloves, apron and sanitiser
- Check the weather for pressing days
- Confirm the weekend by speaking to him in person the weekend before, since there is no other way of reaching him

On arrival:

- Wash hands and sanitise tools before touching anything
- Check the temperature in the cool store and the room
- Look at each vessel I have in his care: smell, level, airlock
- Take starting readings before anything is added

Before leaving:

- Clean the press, the cloths and the floor
- Top up every vessel I opened
- Label everything with the batch name and the day
- Tell him what I took and what I used
- Write the visit down in this log while it is fresh

The "write it down while it is fresh" item is the one I skip most often and regret most. Details disappear faster than I expect, especially the exact words he used to describe a taste.

## Ideas

Some things I would like to try, or to ask Daeltor about at a future visit.

- A small batch made from a single apple variety, to learn what each one gives on its own before blending
- A comparison of two yeasts on the same juice, split at the start, tasted side by side after a few months
- A longer, colder fermentation to see how much fruit character I can keep
- A simple table for recording readings so I stop writing them on scraps of paper
- A tasting evening with a few friends, where Daeltor leads and I take notes
- A level sensor on one large vessel at home, using what I wrote in [[Sethzand level sensor notes]] and [[Trendstil level sensor notes]] as a starting point
- Keeping a small number of bottles from each year, so that in a decade I can taste the whole run
- Asking him to walk me through his blending decisions from start to finish on one real batch, without skipping the boring parts

I do not expect to do all of these. Some will be dropped after one conversation, and Daeltor is good at telling me which ones are not worth the effort. The single variety batch and the recording table are the ones I most want to start.

## Lessons

These are the lessons I have taken from the years with Daeltor, written as plainly as I can.

**Patience is a technique.** Most of my ruined batches were ruined by hurrying: racking too early, bottling too early, tasting too early and then changing something that did not need changing.

**Cleanliness is cheaper than correction.** Ten minutes of cleaning saves weeks of worry. He cleans as he goes, and he expects me to do the same.

**Write down the starting point.** If I do not record the first reading, I cannot judge anything later. A number I did not write down is a number I do not have.

**Keep air away from the cider.** Topping up is boring and it matters. Half-empty vessels are an invitation to trouble.

**Taste often, decide rarely.** Tasting teaches me what is happening. Deciding too soon, on one tasting, usually leads to a change I regret.

**Ask better questions.** Because I can only see him on weekends and in person, I cannot ask quick questions. This forced me to think before asking. My questions are now more specific, and his answers are more useful.

**Respect the arrangement.** Since the 2023 paper I have tried to treat his press room better than my own. Leaving it cleaner than I found it is the least I can do.

**Do not copy blindly.** He has said many times that his way is one way. What works for his fruit, his cellar and his climate may not suit mine, so I test things before adopting them.

## Maintenance

This section covers keeping the relationship, the notes and the equipment in good order.

**The relationship.** Weekends only, in person. I try not to turn up unannounced and I do not ask for more of his time than we agreed. Small gestures help: bringing a bottle from a good batch, helping with a job that is not mine, and saying thank you properly. I make a point of telling him what happened with advice he gave me, because a mentor wants to know whether it worked.

**The notes.** I update this log after every visit. Once a season I read through it from the start and mark the lessons that keep returning. I also check that the questions I wrote down were actually answered, and move any that were not to the next list.

**The equipment I share.** After each pressing weekend:

- Rinse the press and the cloths thoroughly, then let them dry fully
- Check the cloths for wear and tell him if any need replacing
- Wash and rinse the vessels I used, and store them upside down
- Look over tubing and bungs for cracks
- Wipe down the scale and put the hydrometer back in its case

**The paper.** The agreement dated 2023-07-08 stays in the receipts folder. I plan to reread it at the start of each season, in case either of us wants to change something. So far neither of us has.

**My own set-up.** At home I check the sanitiser stock, the bottle supply and the airlocks before the season begins. It is far easier to buy what I need in the quiet months than to run out in the middle of a press.

## Risks

Things that could go wrong, and what I would do about them.

- **Losing contact.** Daeltor is reachable in person and on weekends only. If a weekend is missed because of illness or weather, a question can wait a week or more. Mitigation: keep the question list, and learn to make safe, reversible decisions in the meantime.
- **Depending on one person.** I have learned most of what I know from one mentor since 2009. His methods are good, but they are one set of methods. Mitigation: read widely, taste other people's ciders, and test his advice on small batches.
- **Damage to shared equipment.** The press, the cloths and the vessels are his. A mistake on my part could cost him money and goodwill. Mitigation: follow the cleaning routine, ask when unsure, and report problems immediately.
- **Contamination.** A dirty tool or a lazy rinse can spoil a whole batch, and a spoiled batch in his cool store is a risk for his own cider as well. Mitigation: sanitise before every task and keep my vessels clearly separate.
- **Misunderstanding the terms.** The paper from 2023-07-08 is short. If something happens that it does not cover, we could disagree. Mitigation: talk early, and write down any change we agree on.
- **Poor records.** If I skip the log, I lose the details that make the advice useful. Mitigation: write the entry the same day.
- **Overreach.** I could start to ask too much, or assume access I was not given. Mitigation: stay inside what we agreed, and ask first.
- **Time passing.** He has been teaching for a long time, and I will not always have weekends with him. Mitigation: record as much as I can now, and ask him to explain the reasoning behind his habits, not just the habits.
