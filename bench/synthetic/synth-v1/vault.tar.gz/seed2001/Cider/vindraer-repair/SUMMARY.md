---
type: summary
status: active
project: vindraer-repair
area: cider
description: "Summary about Vindraer repair."
---

# Summary of Vindraer repair

## Open questions

Vindraer repair is a repair project in the cider area. It started in spring 2021, and the neighbor leads it. Most of the work is done, but a few things are still unclear to me.

- I don't know yet whether the neighbor can come back for a second visit before the pressing season starts.
- The seals might need replacing as well. Nobody has checked them closely.
- I'm not sure if the temperature control should be tied into the [[Gistaenfe kiln controller plan]] or kept separate.
- It's unclear who keeps the spare parts. Right now they sit in the neighbor's shed, and I would like a copy of the list in my own notes.

## Decisions

The go decision for Vindraer repair was made on 2026-03-27. After that date we stopped comparing options and started the actual work.

Other choices so far:

- Repair the existing unit instead of buying a new one. The frame is sound and the problems are limited to a few worn parts.
- Let the neighbor lead the work, since they have the tools and the experience with this kind of equipment.
- Keep the repair small. Anything that looks like an upgrade goes into a separate plan, not into this project.
- Write down every change in the project notes so I can reverse it later if something goes wrong.

Stage: the project is in the late middle. The main repair is finished and testing is under way. What remains is checking, cleaning up and closing out the open points above.

## Next action

The next action is NX-5883. I will do it first, before booking any more time with the neighbor. Once it is finished I will update this summary, cross out the open questions that have been answered, and decide whether the project can be closed or needs another round of work.
