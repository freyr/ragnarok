---
type: research
status: active
project: vindraer-repair
area: cider
description: "Research about Dusra level sensor."
---

# Dusra level sensor study

## Checklist

This is the list I run through whenever I open this study again. It keeps me from repeating work I have already done on the Dusra level sensor.

- Confirm which device I am looking at: the Dusra level sensor, kind: level sensor.
- Confirm the area it serves: cider.
- Confirm the colour of the housing: black.
- Confirm the energy source: mains.
- Confirm the year it was installed: 2018.
- Confirm the location: workshop.
- Check that the sensor housing is clean and dry before any reading is trusted.
- Check that the mains lead is undamaged and the plug sits firmly in the socket.
- Compare the reading on the display with a dip stick measurement of the vessel.
- Write down any difference between the two in the log section of my working notes.
- Check the cable gland for cider residue or sticky build-up.
- Make sure the vessel being measured is the one the sensor is aimed at.
- Only after all of this, decide whether the sensor needs recalibrating or just cleaning.

I tick these off in order. If one of the first six items does not match what is in front of me, I stop and correct the note before I go any further, because it usually means I have mixed this unit up with something else in the workshop.

## Overview

The Dusra level sensor is a level sensor that I use in the cider area of my small production. It is black, it runs from mains power, and it was installed in 2018. It sits in the workshop, not in the cellar or the outdoor shed, which matters because the workshop has different temperature swings and a different amount of dust from the other places where I keep cider vessels.

The point of this study is to understand how well the sensor does its one job: telling me how full a vessel is without me having to open it or climb up to look. I wrote the study for my own use. I want to know how far I can trust the number, what makes it drift, and what I should do to keep it working for another few years.

What I know in short:

- Kind: level sensor.
- Area: cider.
- Colour: black.
- Energy source: mains.
- Year installed: 2018.
- Location: workshop.

Because it runs from mains, I do not have to think about batteries. The downside is that it depends on the workshop socket, and any time I move equipment around or switch the circuit off for other work, the sensor loses power and restarts. After a restart it takes a short while to settle, and I have learned not to read it straight away.

The black housing is practical but slightly annoying. It hides dirt, so I cannot see at a glance whether a film of sugar and dust has built up. I have to wipe it and look at the cloth instead. In bright light the black surface also gets warm if it is near a window, and I suspect this has some effect on the readings in summer, though I have not yet proven it.

For this study I treat the sensor as a plain black box with a power cord and a single output that I read from a small display. I do not open it. I only record what it shows and compare that against what I measure by hand.

A simple log line looks like this when I copy a reading into my working file:

```
sensor: Dusra level sensor
area: cider
location: workshop
power: mains
reading_after_restart: wait before trusting
manual_check: dip stick
action_if_mismatch: clean housing, then recheck
```

I keep that format because it forces me to write down the conditions of each reading, not just the number.

## Safety

The sensor is on mains power and it lives in a workshop where liquid is regularly moved about. Those two facts together are the whole safety story, so I take them seriously even though the device itself is small.

Electrical points:

- Always unplug the sensor from the mains before cleaning it or touching the cable gland. Switching it off at the display is not enough for me.
- Never wipe the housing with a dripping cloth. Wring it out until it is only slightly damp.
- Keep the mains lead off the floor where cider, rinse water or cleaning solution might collect.
- Look at the lead each time I use the sensor. If the outer sheath is cracked, crushed or chewed, I stop using it until the lead is replaced.
- The socket should be protected by a residual current device. If I am unsure that it is, I do not rely on the sensor until I have checked.
- Do not run the lead across a walkway. I tie it up along the wall.

Workshop and cider points:

- Cider is sticky and slippery when spilled. A wet floor near the sensor is both a slip risk and a risk to the electrics, so I mop it up straight away.
- When I check a vessel with a dip stick, I do it with the sensor unplugged if I have to lean over the sensor or its cable.
- Fermenting vessels can release gas. I keep the workshop ventilated, especially when several vessels are active at once. The sensor is not a gas detector and I must not treat it as one.
- Cleaning chemicals must never be mixed. I use one product at a time and rinse well, and I keep the sensor unplugged while I do it.
- If anything smells hot or burnt near the sensor, I cut the power at the wall, leave it off and look at it only once it has cooled.

Personal habits that help:

- I do not work on the sensor when I am tired or in a rush.
- I keep a dry towel hanging within reach so I never have to handle the plug with wet hands.
- I tell whoever else uses the workshop when the sensor is unplugged for cleaning, so nobody plugs it in halfway through.

## Background

I installed the Dusra level sensor in 2018, when I decided that checking cider vessels by eye and by dip stick was costing me too much time and sometimes leading me to wrong guesses. The workshop was the natural place for it: it is where most of the active cider work happens, where the power is easy to reach, and where I am most likely to glance at the display during the day.

The device is a level sensor, which means its purpose is to report how much liquid is in a vessel. It is black, it takes its energy from the mains, and it belongs to the cider area of my notes. Those details are the same ones I listed in the checklist, and I repeat them here because the background of the study depends on them. A mains-powered unit that has been in the same workshop since 2018 has a long history, and that history is the main reason I am writing this study at all.

Over the years I have noticed a few patterns, none of them measured carefully yet:

- The readings feel steady in cool weather and a bit less steady in warm weather.
- After a power cut or after I switch the circuit off, the first reading is often off, and it settles later.
- Sticky residue around the housing seems to go with readings that creep up or down without a real change in the vessel.
- When the workshop is dusty from other jobs, I trust the display less.

These are impressions, not findings. The reason for this study is to turn them into something I can check. I plan to compare the sensor against manual measurements over a set period, write down the conditions each time, and see which of my impressions hold up.

There are some limits I should state plainly. I did not keep a formal record when I first set the sensor up in 2018, so I cannot say exactly how it was adjusted on day one. I also have no proof that the settings have stayed the same since then. Anyone could have knocked a control or changed something while moving equipment, and I may have done it myself without noting it down.

What I want from the rest of this note is practical:

- A clear picture of how the sensor behaves in normal use.
- A simple routine for checking and cleaning it.
- A rule of thumb for when to trust the display and when to measure by hand.
- A decision on whether the unit is still worth keeping in the workshop or should be replaced.

I am not trying to prove anything about the make of the device in general. I only want to know how this one black, mains-powered level sensor, installed in 2018 and working in the cider area of my workshop, can be kept useful and safe.

## Tools

The Dusra is a level sensor. It is black, runs on mains power, and has been installed in the workshop since 2018. This section lists what I use when I work on it and why each item is on the list.

**Basic kit**

- A small insulated screwdriver set. The housing screws are plain, but the terminal screws inside are tiny and strip easily.
- A non-contact voltage tester. The unit is on mains, so I check that the supply is dead before I open anything. I do this every time, even for a quick look.
- A multimeter for the supply side and for the signal output.
- A soft brush and a lint-free cloth for dust and sticky film.
- A bottle of food-safe sanitiser, used only on the parts that sit near the liquid.
- A notebook, or this note, to write down what I changed.

**Why the multimeter matters**

The Dusra is a level sensor, so its whole job is to turn a liquid height into a signal I can read. If the reading looks wrong, I need to know whether the fault is in the supply, in the sensor itself, or in the wiring between them. The multimeter splits those three cases quickly. I check the supply first, then the output at rest, then the output with the tank at a known level.

**Reference check I keep**

I keep a short checklist as a text file next to the workshop bench. It is a plain list I run through in order, and I paste the result into my log. This is the template I use:

```text
dusra check
supply: present / absent
housing: clean / dusty / sticky
cable: intact / worn
output at empty: stable / drifting
output at known level: matches / off
notes:
```

I fill it in by hand and keep the answer words short. The point is that I never skip a line. When I skipped lines in the past, I ended up repeating work the next week.

**Things I do not use**

- No strong solvents. The black housing marks easily and a harsh cleaner leaves a dull patch.
- No compressed air close to the sensing face. It pushes dust into the seams instead of removing it.
- No water jets. Mains power and wet cleaning do not mix, and the workshop floor is not a place to improvise.

## Maintenance

Because the Dusra lives in the workshop, its main enemies are dust, damp air and the occasional splash from cleaning nearby equipment. It is a mains device, so every maintenance step starts with isolating the supply.

**Routine**

My routine is simple and I try to keep to it:

1. Switch off the supply and confirm with the voltage tester that the unit is dead.
2. Wipe the black housing with a dry cloth. If there is residue, I use a barely damp cloth and dry it straight away.
3. Look at the cable and the entry point. I am checking for cracks, kinks, and any sign that the cable has been pulled.
4. Check that the mounting is firm. A loose sensor gives readings that wander, and that is easy to mistake for a real fault.
5. Restore the supply and watch the output for a while at rest.
6. Compare the reading against a known level and write the result in the log.

**What I look for**

The most common problem is a film on the sensing face. In the cider area the liquid is sweet and sticky, so a thin layer builds up over time. It does not look like much, but it shifts the reading slowly. The sensor never fails outright. It just drifts, and the drift looks like a tank that is slowly filling or emptying when nothing is happening.

The second problem is the cable. In a workshop, cables get knocked by crates, ladders and tools. I would rather replace a worn cable early than chase an intermittent fault later.

The third problem is the supply. Since the Dusra runs on mains, a poor connection at the plug or the terminal block shows up as flicker in the output. I check that the plug sits well and that the terminal screws are snug but not overtightened.

**When I open the housing**

I rarely open it. When I do, I do it on a clean bench, with the supply removed and the plug physically out of the socket, not just switched off. I take a photo of the wiring first, so I can put everything back exactly as it was. Then I look for moisture traces, discolouring on the terminals and dust inside. I close it up the same day and do not leave it half open overnight.

**Intervals**

I do a quick wipe and visual check when I am in the workshop for other reasons, and a full check with the template above on a regular rhythm that suits my cider work. Busy periods get a check before they start, not after. If the output has ever looked odd, I check it straight away rather than wait for the next scheduled round.

## History

The Dusra was installed in 2018. I put it in the workshop because I wanted a dependable way to watch liquid level for my cider work without walking over to look each time. Before that, I checked levels by eye and by dipping a stick, which was slow and sometimes wrong.

**Early period**

In the first stretch after installation, the sensor was close to trouble free. I had picked a black unit partly because it looked tidy on the wall and partly because black housings hide marks well. That turned out to be a mixed blessing: it hides dirt, so I sometimes missed a film that I would have noticed on a lighter case. That is why the wipe-down and the written check became part of my routine.

**Changes over the years**

- The mounting was adjusted once after I noticed small shifts in the reading. The cause was a slightly loose bracket, not a sensor fault.
- I replaced the cable run once because it had been rubbed against a shelf edge. I rerouted it away from where people walk and tie it back now.
- I added the check template after a season in which I repeated the same troubleshooting twice because I had not written down what I had already tried.
- I moved the cleaning cloths and sanitiser closer to the bench so that cleaning actually happens instead of being put off.

**What has stayed the same**

The power arrangement has not changed. It has always been on mains, and I have never tried to run it from anything else. The location has not changed either: it is still in the workshop. The unit is the same black sensor I put in at the start, and as far as I can tell it has not been swapped or rebuilt.

**Lessons from the record**

Looking back over the notes, most of the time I lost came from three things: a dirty sensing face, a worn cable and a loose fixing. Real sensor failure has not been the issue. That tells me the device is sound and that my job is mostly housekeeping. It also tells me to keep the log short and honest, because the log is what lets me see these patterns at all.

## Observations

This section is what I have noticed in practice, kept as plain statements so I can compare them against later notes.

**Behaviour**

- The Dusra is a level sensor and it behaves like one: when nothing changes, the output should stay steady. A steady output at rest is my first sign of health.
- Slow drift at rest nearly always means a film on the sensing face or a loose mount. It has rarely meant an electrical fault.
- Flicker or sudden jumps point to the supply or the cable, not to the liquid.
- After a thorough clean, the output usually settles back to what I expect within a short while. If it does not, I look at the wiring next.

**In the cider area**

The sensor serves the cider area of my setup. Sugar in the liquid is the reason the sensing face gets sticky, so cleaning matters more here than it would with a plain liquid. During busy cider periods, the sensor is also more likely to be splashed or handled indirectly, because I am moving things around it.

**The workshop environment**

The workshop is not a controlled room. It gets dusty when I cut or sand anything, and it can be damp in cold weather. I have noticed that readings are a little less steady on damp days, which is another reason I check the mount and the cable connection instead of assuming the sensor is at fault.

**Practical conclusions**

1. Clean before you diagnose. Many apparent faults disappear after a wipe.
2. Always isolate the mains supply first and confirm it with the tester.
3. Write down what you did. A short entry saves a lot of repeated effort.
4. Check the cable and the mount before suspecting the sensor.
5. Judge the sensor by how it behaves at rest, then against a known level.

**Open questions**

- I would like to know whether a protective cover over the sensing area would cut down on the sticky film without affecting the reading. I have not tried one, and I do not want to guess.
- I am not sure whether moving the unit slightly further from the splash zone would help more than cleaning more often. It would be a bigger job, so I am leaving it for now.
- I want to keep a clearer record of the drift I see, so I can tell a slow trend from normal variation. For now the check template is my only tool for that, and it is a rough one, but it has been enough to keep the Dusra reliable.

## Open questions

These are the things I still cannot answer after living with the Dusra level sensor in the workshop since 2018. I keep them in one list so I can check them off when I get a chance to test.

- Does the reading drift when the workshop gets cold in winter? The sensor is black and sits near an outer wall, and I suspect the housing picks up the temperature swings. I have a feeling the cold mornings give a slightly lower level than the afternoons, but I have never logged it properly.
- Is the mains supply clean enough? The Dusra level sensor runs from mains, and the workshop shares a circuit with a bench grinder and a small compressor. Some of the odd spikes might come from that circuit and not from the cider at all.
- How much does foam change the reading? In the cider area, a vessel that has just been filled or moved carries a head of foam for a while. I do not know if the sensor reads the top of the foam or the liquid below it.
- Would a second sensor on the same vessel agree with this one? I have only ever had one, so I have no reference. Every conclusion in this note rests on a single device.
- Is the slow change over the years real wear, or just my habits changing? After this many years I cannot separate the two.

I will come back to this list at the end of each season and strike out whatever I have settled.

## Setup

The device is a level sensor in the cider area. It is black, powered from mains, and was installed in 2018. It lives in the workshop, not in the cellar or the press room, which matters for the temperature question above.

### Mounting and power

The sensor is fixed to a bracket above the vessel, with the sensing face pointing straight down. I keep a small gap between the face and the rim so that splashes do not reach it. The mains lead runs along the wall to a socket with a switch, so I can cut power without unplugging anything. I did not fit a separate fuse, and I now think I should have.

### Logging

I read the output on a small logging board and write the values to a text file once a minute. The format is plain on purpose, so I can open it in any editor. A typical extract from the file looks like this:

```
time=08:00 level=high state=ok
time=08:01 level=high state=ok
time=08:02 level=high state=ok
time=08:03 level=mid  state=ok
time=08:04 level=mid  state=noisy
time=08:05 level=mid  state=ok
```

The "noisy" state is my own label. The logging board marks it when two readings in a row differ by more than I allow. It is crude, but it catches most of the spikes.

### Routine

Each morning I look at the first line of the file, and each week I copy the file to another folder. Once a month I wipe the sensing face with a soft cloth and check that the bracket has not shifted. If the bracket moves even a little, the readings shift with it, so I note the date of any adjustment in the log.

## Lessons

Several things became clear over the years, and I would do most of them again.

1. Keep the setup simple. A plain text log has outlasted every fancier tool I tried. When something looks wrong, I can read the file with my eyes and see where it started.
2. Fix the position before you trust the numbers. In the first months I nudged the bracket several times and then wondered why the readings changed. Now the bracket is tightened properly, and a change in the log points to the cider, not to my hands.
3. Write down every intervention. Cleaning, moving the bracket, switching the power off for a day: each one goes into the log as a line. Without these notes, I could not explain half the gaps and jumps.
4. A single odd reading means nothing. A run of odd readings means something. I stopped reacting to single spikes and started reacting to patterns lasting a few minutes.
5. Keep the sensing face clean. A thin film of sticky residue from the cider area makes the sensor sluggish. A monthly wipe removes most of that problem.
6. Treat the mains side with respect. The sensor is reliable, but power in a workshop is rarely tidy. A switch and a proper fuse are cheap compared with the trouble of a damaged device.

One more lesson is about patience. The sensor is old by now, and it still works. Most of my past worries came from the surroundings and my own handling, not from the device. I would sooner look at the setup first than assume the sensor is failing.

## Problems

These are the faults I have actually met, in roughly the order I noticed them.

### Spikes when the compressor starts

The worst problem is a short jump in the reading every time the compressor on the shared circuit switches on. The jump lasts a second or two and then the value settles. It is harmless for my purposes, but it fills the log with noisy lines. I have thought about moving the sensor to another socket, which is the easiest test of the mains theory.

### Slow drift

Over long periods the reading for the same real level has moved a little. I cannot tell whether the cause is the sensor, the bracket, or a coating on the sensing face. Cleaning helps for a few weeks and then the drift returns, which makes me lean toward the coating.

### Foam and splashes

After a vessel is filled the reading can wander for a while. The foam seems to confuse the sensor, and a splash on the face can hold a wrong value until I wipe it. My workaround is to ignore the first stretch of time after filling and only trust the numbers once things have calmed down.

### Cold mornings

On the coldest days the first readings of the morning look different from the later ones. This is the same suspicion as in the open questions, and I have not proved it. If it is real, the outer wall position is to blame, and moving the sensor inward would help.

### Gaps in the log

Now and then the log has a hole of several minutes. Most of them trace back to the logging board and not to the sensor, since the sensor reading resumes at the same level. I now check the board first when I see a gap, and I keep a spare cable in the drawer because a loose connection caused two of the gaps.

### What I would change

If I rebuilt the setup, I would add the fuse, move the supply away from the compressor circuit, and fit a shield against splashes. I would also add a second sensor on the same vessel, so that I finally have something to compare against.

## Ideas

These are the things I want to try with the Dusra level sensor, the black, mains-powered level sensor that has been in the workshop since 2018. It belongs to the cider area, and most of my ideas are about making it more useful there without changing how it works.

**Log the readings somewhere permanent.** At the moment I only look at the sensor when I walk past it. If I wrote the reading to a plain text file every few minutes, I could see how the level moves over a week of fermentation. A slow drop would tell me something. A sudden drop would tell me there is a leak or that someone has drawn off a batch and not told me.

**Add a second check by hand.** Before I trust any trend, I want to compare the sensor against a dipstick or a marked sight tube for a few weeks. If the two agree, I can stop worrying. If they drift apart, I need to know by how much and in which direction.

**Mark the foam problem.** Cider foams hard in the first days. I suspect the sensor reads the top of the foam rather than the liquid. An idea is to note the reading at the same time each day during the active phase, and write down whether the surface was foamy. After a couple of batches I should see a pattern.

**Move the cable run.** The mains lead runs along the same wall as the pressure washer hose. It gets wet and it gets knocked. Rerouting it higher, with clips, would be cheap and would remove one obvious risk.

**Alarm threshold.** I would like a simple low-level and high-level warning. Even a light on the wall would do. A message is better, but only if the logging part works first.

**Keep a short maintenance routine.** Wipe the face of the sensor, check the cable, check the mounting, and compare with the dipstick. Four items, once a month, written in the log file.

Order of work, as I see it:

1. Hand comparison with the dipstick.
2. Foam notes during the next two batches.
3. Cable reroute.
4. Logging to a text file.
5. Alarm threshold.

A sample of the log format I plan to use:

```text
# level log, workshop, cider area
# time, reading, surface, note
2026-11-10 08:00, 71, clear, after racking
2026-11-10 20:00, 70, foam, active ferment
2026-11-11 08:00, 70, foam, active ferment
2026-11-11 20:00, 69, clear, foam settling
```

The reading column is whatever the sensor shows, in its own units. The surface column is my own word: clear, foam, or unsure. I keep the note column free so I can write what happened.

## Supplies

What I need to carry out the ideas above. Most of it I already own, and a few things I would have to buy.

**Already in the workshop**
- The Dusra level sensor itself, black, on mains power.
- A notebook and a pencil that works on damp paper.
- A wooden dipstick, which I would mark with a knife at regular steps.
- A tape measure.
- Cable clips and a drill for the wall.
- A clean cloth for wiping the sensor face.

**To buy or find**
- A short length of clear tube to use as a sight gauge on one vessel.
- A small waterproof box for the cable connection, if the existing one is not sealed well.
- Cable ties, a few spare.
- A cheap small computer or a similar logger, only if I decide to automate the logging. I will not buy this until the hand logging has run for a month.
- A wall light or a buzzer for the alarm, again only later.

**Things to avoid**
- Do not wash the sensor with the pressure hose. Wipe it.
- Do not open the casing. It is mains powered, and I have no reason to go inside.
- Do not run the cable across the floor.

Before any work on the wiring or the clips near the sensor, I switch off the mains supply at the board, and I check that it is off. That rule is more important than any of the ideas.

## References

I keep these as pointers to what I already have, not as links. The world of this note is my own workshop, so most of the references are my own papers.

- **Installation note, 2018.** The paper I wrote when the sensor was put in the workshop. It records where it was mounted and which wall. I should photograph it, since the paper is stained.
- **The manual that came with the sensor.** It describes the sensor as a level sensor and gives the mains connection. I keep it in the folder marked cider.
- **My fermentation notebook.** It has batch dates and the levels I wrote by hand. It is the best source for the comparison with the dipstick, because the numbers are mine and were taken at the vessel.
- **Earlier parts of this note.** They cover what the device is and what I have seen of its behaviour. This part is only the ideas, the supplies and the costs.
- **Workshop wiring sketch.** A rough drawing of where the sockets and the board are. I need it before I move the cable.

Facts about the subject that I keep returning to, so they are in one place:

- Name: Dusra level sensor
- Kind: level sensor
- Area: cider
- Colour: black
- Energy source: mains
- Year installed: 2018
- Location: workshop

If I ever replace the sensor, I will copy this list into the new note and change only what has changed.

## Costs

I do not have exact invoices for this, so I keep the costs in rough bands and write the real amounts in the notebook when I buy things. Nothing here is a firm price.

**Cheap, almost nothing**
- Marking the dipstick: a few minutes and a knife.
- Wiping the sensor monthly: a cloth I already own.
- Keeping the text log by hand: paper and time.

**Small**
- Clear tube for a sight gauge.
- Cable clips and ties.
- A waterproof box for the connection.

**Moderate, only if the earlier steps prove useful**
- A small logger to write readings automatically.
- A wall light or buzzer for the alarm.

**Running cost**
The sensor runs from the mains and is on all the time. I believe its draw is very small, much less than the lights in the workshop, but I have never measured it. If I want a real figure, I can put a plug-in energy meter on it for a week and write down the result. That is a cheap experiment and it would settle the question.

**Time cost**
This is the largest cost. The hand comparison needs a visit to the vessel at set times, and the foam notes need me to be there during the active phase of each batch. Over two batches that is perhaps a few minutes a day. I would rather spend that than buy equipment I do not need.

**Decision rule**
I will spend money on the logger and the alarm only if the hand log shows that the sensor can be trusted. If the sensor and the dipstick disagree in a way I cannot explain, the money should go on understanding the sensor first, not on adding things around it. The sensor has been in the workshop since 2018, and it has been useful enough to keep, so I do not plan to replace it. The cost of the plan is therefore mostly my attention, and that is what I should budget for.

## Software

The Dusra level sensor is a black level sensor used in the cider area. It runs on mains power, it was installed in 2018, and it sits in the workshop. This section covers what the sensor runs, how I talk to it, and what I have learned about its behaviour in software terms. The firmware version currently on the unit is v5.46.567.

### What the firmware does

The firmware is small. It does four things and nothing else:

1. It reads the level probe at a fixed interval.
2. It smooths the readings so that surface ripple does not show up as a changing level.
3. It compares the smoothed value against the alarm thresholds I have set.
4. It reports the value and any alarm state over the local connection.

There is no cloud part. The unit never needs to reach the internet, and I have kept it that way on purpose. Everything I use is on the workshop network or on a cable straight to the sensor.

### How I read it

I poll the sensor from a small script on a machine in the workshop. The script asks for the current level once a minute and appends the answer to a plain text log. I chose once a minute because cider in a tank changes slowly, and faster polling only fills the log with identical lines.

The log extract below is typical of a quiet day. The format is the one my own script writes, not something the sensor produces by itself.

```
2026-11-09T07:00:02 level=ok  fill=high  alarm=none
2026-11-09T07:01:02 level=ok  fill=high  alarm=none
2026-11-09T07:02:02 level=ok  fill=high  alarm=none
2026-11-09T07:03:03 level=ok  fill=high  alarm=none
2026-11-09T07:04:02 level=ok  fill=high  alarm=none
2026-11-09T07:05:02 level=ok  fill=medium alarm=none
2026-11-09T07:06:02 level=ok  fill=medium alarm=none
2026-11-09T07:07:03 level=warn fill=low   alarm=low_level
2026-11-09T07:08:02 level=warn fill=low   alarm=low_level
```

The last two lines show what a low alarm looks like in my log. The sensor flips its alarm state first, and my script copies that state across. I do not trust my script to decide anything about the alarm. It only records.

### Settings I have changed

Most settings stay at what the unit shipped with. The ones I changed, and why:

- **Smoothing window.** I lengthened it. With the default, the level jittered whenever the transfer pump ran nearby. A longer window flattened that out without hiding real changes, because real changes in a tank take many minutes.
- **Low alarm threshold.** I set it a little above the point where the pump outlet starts to draw air. That gives me time to react.
- **High alarm threshold.** I set it below the top rim with a safe margin, so a filling job can be stopped before anything spills.
- **Alarm hold time.** I made the alarm wait for a few consecutive readings before it trips. This removed the nuisance alarms I used to get when someone knocked the tank.

I keep the actual numbers in the workshop notebook beside the tank, not in this note, because they change with each tank layout and I would rather not have stale values written here.

### Behaviour I have observed

A few things I learned from reading the logs over the years:

- **Warm-up.** After a power cut, the first readings are unreliable. I ignore the first several minutes after the sensor comes back. The firmware does not flag this, so my script skips them by itself.
- **Foam.** During active fermentation, foam on the surface can read as a higher level than the liquid really is. The sensor is not wrong in a technical sense; it is measuring the top of the foam. I mentally subtract for this, and I treat the high alarm as early rather than late during that period.
- **Condensation.** On cold mornings, condensation on the probe can cause a short odd reading. The smoothing absorbs most of it. If I see one isolated bad line in the log, I ignore it.
- **Stability.** Since I settled the smoothing and hold time, the unit has run for long stretches without a reset or a lock-up. The firmware has been dull and reliable, which is what I want from a mains-powered sensor that is always on.

### Updating the firmware

I have not updated the firmware often. The rule I follow is simple: if the unit is working and the alarms are right, leave it alone. The version v5.46.567 does what I need in the cider area, so I have no reason to chase a newer one.

If I do update it in future, this is the order I will follow:

1. Write down the current alarm settings from the notebook, since an update might reset them.
2. Pick a quiet time, with no filling or transfer under way.
3. Copy the old log somewhere safe so I can compare behaviour before and after.
4. Apply the update with the tank at a steady level.
5. Wait out the warm-up period, then check that the readings match a dipstick measurement.
6. Re-enter the thresholds and the hold time, then test the low and high alarms deliberately.

The dipstick check in step 5 matters most. Software can report a tidy, plausible number that is simply wrong, and a plain stick in the tank is the cheapest way to catch that.

### Backups and recovery

The sensor has no useful memory of its past readings, so the history lives only in my log file. I copy the log to a second disk every week. If the polling machine fails, I lose the history but not the sensor's function, because the alarms run on the sensor itself and do not depend on my script.

If the sensor ever needs a full reset, I would restore the settings by hand from the notebook. That is another reason I keep the values there on paper: it works even when every computer in the workshop is off.

### Open questions

- I do not know exactly how the firmware computes its smoothing, only that a longer window behaves as I described. A test with a controlled level change would show the response time.
- I have not checked how the sensor behaves if mains power flickers repeatedly rather than failing cleanly. A small surge protector may be worth adding.
- The foam problem might be reduced by a different probe position. I want to try moving it a short distance from the inlet during the next fermentation and compare the logs.
