---
type: research
status: active
project: vindraer-repair
area: cider
description: "Research about Rumand cellar."
---

# Rumand cellar tests

## Ideas

The Rumand cellar is a large, south-facing cellar built in 2000. It sits below ground and is used for the cider area of the collection. These notes cover the tests I want to run there to learn how the space behaves over a full year.

The first idea is to treat the cellar as a natural experiment in temperature stability. Because the floor is below ground, I expect the air to stay cooler and steadier than in any shed above it. The south orientation is the odd part. A south-facing wall usually takes the most sun, so I want to find out whether that warmth reaches the inside at all or whether the earth around the cellar swallows it.

Other test ideas:

- Place a few simple thermometers at different heights and distances from the south wall, and read them at the same time each week.
- Compare a crate of bottles stored near the south wall with a crate stored at the far end, and check them after a season for differences in fizz, clarity and taste.
- Test whether the cellar is large enough to hold two separate zones, one for resting finished cider and one for slower work such as aging.
- Try a basic airflow test with a strip of tissue or a thin ribbon held near the door and the vents, to see which way the air moves.
- Keep a short log of smells. A cider cellar should smell of apples and wood, and anything sharp or musty is worth writing down early.

I would also like to try a humidity test. A below-ground room tends to be damp, and damp is good for corks and barrels but bad for labels, cardboard and metal. A cheap humidity gauge left in the middle of the room for a month should tell me which side of the line this cellar is on.

## Problems

I have not yet measured anything, so these are the problems I suspect rather than ones I have proven.

The biggest worry is that the south side may produce uneven temperatures. If the wall warms in the afternoon, bottles stored against it could age faster than the rest. That would make any comparison between crates unfair unless I control for position.

The second worry is moisture. The cellar is large, and a large below-ground space can be slow to dry out after wet weather. If water gets in along the floor edge or through the wall, I will see it first as dark patches or a chalky white film on the stone.

A third problem is that the cellar dates from 2000, so it is not old, but it is old enough that seals, paint and any drainage work may be starting to wear. I do not have a record of what was done during the build, so I cannot assume anything is still in good shape.

Finally, size works against me. A large room is harder to test evenly. One reading near the door says little about the back corner, so I need several measuring points, and that means more notes to keep up with.

## Setup

Here is the plan for running the tests in a way that I can repeat.

Properties of the place, for reference:

- Name: Rumand cellar
- Kind: cellar
- Area: cider
- Orientation: south
- Size: large
- Year built: 2000
- Floor: below ground

Measuring points: I will divide the room into a rough grid and mark each spot with a small piece of tape. Every spot gets a short label. The spots nearest the south wall are the ones I care most about, so they get two instruments each, one high and one low.

Schedule: one reading round per week, always at about the same time of day, with a second round after any heavy rain or hot spell. Each round is written into a simple table with columns for position, temperature, humidity and any comment. I will keep the table in this note or in a linked log kept beside it.

Controls: for the crate comparison I will use the same bottles from the same batch, the same crates, and the same closure type. Only the position changes. I will label the crates clearly and never move them mid-test.

Duration: a full year, so that the cellar sees summer heat and winter cold. A shorter test would only tell me about one season, and the south wall is exactly the kind of feature that changes with the season.

Tools I need: thermometers, a humidity gauge, tape, a marker, a notebook, a torch and a ribbon for the airflow test.

## Risks

The main risk to the tests is that I disturb the cellar while measuring it. Opening the door often lets in outside air and spoils the readings. I will keep visits short and try to read the instruments without moving them.

A second risk is to the cider itself. If the test shows the south end gets warm, bottles left there may spoil or burst. I should check the first round of results before putting any valuable stock in the test crates.

There is also a safety risk. A below-ground room can collect heavy gases, especially where fermentation is going on. I should never work alone in the cellar when fermenting vessels are active, and I should make sure the air is moving before I spend a long time inside. If I ever feel dizzy or short of breath, I leave at once.

Other risks are smaller but real:

- Cheap instruments may drift or disagree with each other, so I will place them side by side for a day before the test to see how far apart they read.
- Damp could ruin my paper notes, so I will keep them in a sealed bag or copy them upstairs.
- Condensation could fog or corrode the gear.
- I might lose interest halfway through the year and leave gaps in the log, which would weaken the results.

## Costs

I want to keep this cheap, since the aim is learning and not building a laboratory.

The main spending is on instruments. A handful of small thermometers and one or two humidity gauges should cover the whole room. The extra expense would be a data logger that records readings on its own, which would save many visits, but I will only buy one if the manual readings prove too much work.

Smaller items are tape, labels, a waterproof notebook or bag, and spare batteries. I already own a torch and a marker.

Time is the larger cost. A weekly round of readings across a large room takes a good part of an hour once I include writing it up, and the extra rounds after weather events add to that. Over a year this is a real commitment, so I should decide early whether I am willing to give it.

There is a possible later cost if the tests show a real problem. Fixing damp, adding a vent or insulating the south wall could all be expensive, so I will price those only if the results point that way.

## Admin

Lease reference of Rumand cellar: LR-725877

Keep this reference with any letters or forms about the lease. If I need to ask the owner for permission to fit sensors, drill for a vent or alter the south wall, I should quote it at the top of the message.

Before starting, I should check what the lease says about changes to the cellar and about storing and fermenting drink on the premises. I should also confirm who is responsible for repairs to the walls, floor and drainage. If damp turns out to be a real problem, that question will matter.

Housekeeping for the test itself:

- Keep the reading table and the crate labels up to date.
- Write down the date of each visit and anything unusual that I noticed.
- Store spare instruments and notes in one place upstairs.
- Review the results at the end of each season and decide whether to carry on.
