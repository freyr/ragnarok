---
type: drivers
status: active
project: vindraer-repair
area: cider
---

# Drivers of Vindraer repair

This is the drivers note for the Vindraer repair project. It records why the work exists, what limits it, what it may cost, and how I decide it worked. The project is a repair, its area is cider, it started in 2021, it runs in the spring season, and the lead is my neighbor. The area is also in the frontmatter, but I repeat it here so the note makes sense on its own.

## Costs

The goal is repair, not replacement, so the cost question is always whether fixing Vindraer beats starting over. I have kept the cost drivers in rough order of size.

- **Parts and materials.** Most of the money goes here. Parts for a cider setup are specialized, and anything that touches juice has to be food safe. That rules out the cheap hardware-store substitutes.
- **Borrowed labor.** My neighbor leads the project and does most of the skilled work. I do not pay a wage, but I owe time and goods in return. I count that as a real cost even though no money changes hands.
- **Delays.** Spring is the season for this project. If a part arrives late, the work slips past the window and waits for the next one. A slip costs me more than any single part.
- **Rework.** Every wrong cut or wrong fitting costs the part, the time, and sometimes a trip.

The main rule is that I do not pay for a part before I have checked what is wrong with the old one. Early in the project I bought two things I never used, because I guessed at the fault. The detailed spending is under Budget, and what was bought is under Supplies.

The cost of doing nothing also counts. If Vindraer stays broken, the cider area loses a working season, and the apples still have to be dealt with somehow. That comparison is why the repair is worth doing at all.

## Checklist

This is the checklist I run before and during each work session. It is short on purpose, so I actually use it.

- Confirm with my neighbor which day we are working and who brings what.
- Read the last entry in [[Daeltor Losvind log]] so I know where we stopped.
- Clear and clean the work surface before touching anything.
- Lay out the tools listed under Tools and check each one is present.
- Photograph the part before taking it apart, from at least two angles.
- Label every removed fitting and bag the small pieces together.
- Check that the replacement part matches the old one before fitting it.
- Test the repair with water before any juice goes near it.
- Write the result in the log the same day, while I still remember it.
- Put everything back where it lives, and note anything that is now missing.

The checklist exists because I tend to skip the photographs and the labels when I am keen to get going. Every time I skipped them I lost an hour later working out how something went back together.

## Maintenance

The repair is only worth anything if Vindraer then lasts, so I think about maintenance as part of the goal rather than something after it.

After the repair I want a simple routine that I can keep up without my neighbor:

1. Rinse and dry the repaired parts after each use.
2. Look over seals and joints at the start of each season, not only when something leaks.
3. Keep moving parts lightly treated with a food-safe lubricant, and nothing else.
4. Store everything dry and off the floor over the quiet months.
5. Record anything odd in the log, even if it seems minor.

Whatever failed once will fail again if I do not look at it. Where wear is the cause, I plan to note how long the new part lasts, so the next repair can be planned instead of being a surprise.

The heat exchange side is a separate piece of work, described in [[Vioskrirk heat exchanger plan]]. I keep its maintenance notes there so they stay with the design. The two notes should be read together, because a change to one can affect the other.

## Safety

Cider work looks gentle, but a repair brings its own hazards.

- **Pressure.** Anything that has held fermenting liquid may still hold pressure. I release it slowly and never open a vessel by force.
- **Cleaning agents.** I keep cleaners away from the work area while parts are open, and I never mix them. I wear gloves and eye protection when I use them.
- **Tools.** Cutting and grinding tools stay in use only when the work is clamped down. I do not hold small parts in my hand while cutting.
- **Slippery floors.** Juice and rinse water make the floor treacherous. I wipe up as I go.
- **Lifting.** Full vessels are heavy. I do not lift alone, and my neighbor and I agree on the move before we make it.
- **Food safety.** Anything that touches the juice must be food safe and clean. A repair that leaves a bad material in contact with the cider has failed, however well it holds.

If I am tired or hurried, I stop. A repair can wait for the next day, and a injury cannot be undone.

## Problems

These are the problems that have come up, or that I expect to come up, with Vindraer.

- **Unclear fault.** The main difficulty at the start was not knowing exactly what was wrong. Several symptoms could have come from one cause or from many.
- **Parts that no longer match.** Old equipment often uses fittings that are no longer made. I either find a close match or adapt the connection, and adapting needs care.
- **Seized or worn fittings.** Anything that sat unused over winter may be stuck. Forcing it risks breaking it.
- **Leaks that appear only under load.** A joint may hold on a dry bench and then weep when the system is running. This is why I test with water first.
- **Limited time.** My neighbor and I do not always have the same free days, and the spring window is short.
- **Scope creep.** Once something is open, it is tempting to fix everything else nearby. I write extra jobs down and leave them for later.

When a problem is solved I note the cause as well as the fix. [[Staga Virork]] is where I keep the longer notes on a few of the stubborn ones, since they turned into small investigations of their own.

## History

The project began in 2021, in the spring season. Vindraer had stopped working properly the previous year, and I put off doing anything about it because I did not know where to begin. My neighbor offered to take the lead, and that settled it.

The early stage was mostly looking. We took the unit apart, cleaned it, and found out what was actually damaged compared with what only looked bad. Several parts turned out to be fine. Two had to be replaced, and one needed a custom fix.

After that the project went in bursts. Work happened in spring and then stopped when the cider season took over, and I picked it up again the following year. That stop-and-start pattern is normal for a cider project, because the apples set the calendar and the repair has to fit around them.

Over time the log grew into a decent record of what was done and in what order. [[Daeltor Losvind log]] holds that record. This drivers note was written later, to pull together the reasons behind the work, since the log only says what happened and not why.

## Background

Vindraer is part of my cider setup. It matters because the rest of the process depends on it, so when it fails the whole season is affected. I would sooner have it working reliably than keep patching around it.

I chose repair over replacement for three reasons. First, the unit is well made, and the fault is in a small number of components rather than in the structure. Second, a replacement would be a larger and less certain expense. Third, I like understanding how my equipment works, and repairing it teaches me that.

The project properties, collected in one place:

- **Name:** Vindraer repair
- **Type:** project
- **Goal:** repair
- **Area:** cider
- **Start year:** 2021
- **Season:** spring
- **Lead:** neighbor

My neighbor leading the project changes how it runs. I am the one who keeps the notes and does the legwork, while the decisions about method come mostly from the person with more hands-on experience. I accept that, and where I disagree I say so and we talk it through.

How I measure success is simple. Vindraer works through a full cider season with no repeat of the original fault, the juice stays clean, and I can explain to someone else what was done and why.

## Budget

The budget for Vindraer repair is 10191.90 EUR.

That figure is a ceiling, not a target. I want to finish well under it if the work allows. I have divided my thinking about it as follows:

- The largest share is for parts and materials.
- A smaller share covers tools I do not already have.
- A reserve is held back for surprises, since repairs reliably turn up things nobody expected.

If the spending approaches the ceiling before the work is done, I stop and decide with my neighbor whether to continue, cut the scope, or put the remainder off to another season. I do not quietly go over.

Because the lead is not paid, the budget covers only money I actually spend. The time my neighbor gives is counted separately under Costs. I keep receipts in a single folder and tally them after each session, so I always know where I stand.

The budget exists to protect the main goal. A repair that costs more than a sensible replacement has lost its point, and I check this again each time a large expense comes up.

## Supplies

Supplies are the consumable and replaceable items that the repair uses up. I keep them separate from tools because tools are reused and supplies are not.

- Food-safe lubricant for moving parts.
- Replacement seals and gaskets suited to contact with juice.
- Cleaning and sanitizing products, stored away from the work area.
- Clean cloths and paper towels in generous quantity.
- Spare fasteners made of a material that will not corrode in a wet setting.
- Sealing tape and compound rated for food contact.
- Labels, small bags, and a marker for tracking removed parts.
- Clean water for testing before any juice is used.

Before each session I check what is running low, because running out in the middle of a job wastes the whole day. Where a supply has a shelf life, I note when I opened it. I also try to buy in sensible quantities, since over-buying eats the budget and leaves me with things I never use.

Larger components are ordered only after the fault is confirmed. The plan for the heat exchange side lists its own materials in [[Vioskrirk heat exchanger plan]], so I do not repeat them here.

## Schedule

The project follows the spring season, because that is when my neighbor and I are both free and the cider area is quiet enough to work in.

The rough order of the work is:

1. **Early spring.** Inspect, clean, and confirm the fault. Decide what to repair and what to leave.
2. **Mid spring.** Order parts and carry out the main repair. This is the busiest stretch.
3. **Late spring.** Test with water, correct any leaks, and put the unit back together for use.
4. **After the season.** Review what happened and update the log and this note.

I try to leave a gap between ordering and the main repair, because parts rarely arrive when promised. If a delivery is late, I use the time for cleaning and preparation instead of waiting idle.

The schedule is loose by design. My neighbor decides the working days, and I fit around them. What I hold firm on is the end point: the repair must be tested and ready before the cider work starts in earnest. If it is not, the project moves to the next spring instead of being rushed, since a rushed repair is the likeliest to fail.

## Lessons

Some things I have learned so far, written down so I do not have to learn them twice.

- **Diagnose before buying.** Guessing at the fault cost me parts I never used.
- **Photograph everything first.** It saves far more time than it takes.
- **Do not force a stuck fitting.** Patience and a little penetrating treatment beat strength.
- **Test with water.** Leaks found early are an inconvenience; leaks found with juice in the system are a loss.
- **Write down the cause, not only the fix.** The log is far more useful when it explains why.
- **Keep scope tight.** Extra jobs go on a list, not into the current session.
- **Respect the lead.** My neighbor's experience has saved me from several mistakes, and listening has been cheaper than learning the hard way.
- **Leave time for the unexpected.** Every stage has taken longer than I planned.

I will add to this list as the project goes on. If a lesson is large enough, it may deserve its own note, and I will link it from here.

## Setup

The setup is how the work area and the equipment are arranged during a repair session.

I work in the cider area, on a sturdy bench that I clear before starting. The bench is at a comfortable height, so I am not bent over for long periods. Good light matters more than I expected, and I use a portable lamp to see into the awkward places.

Next to the bench I keep three zones:

- **Dirty zone.** Removed parts waiting to be cleaned.
- **Clean zone.** Cleaned parts and new components, kept covered.
- **Reference zone.** The notebook, my phone for photographs, and any manuals or printed notes.

Water for testing sits close by, along with a bucket and a drain route, so a leak does not become a flood. Cleaning products are kept off the bench until they are needed.

The log is open during the session, so I record steps as they happen rather than from memory afterwards. This setup is not fancy, but having it the same each time means I spend less effort thinking about where things are and more on the repair.

## Tools

The tools below are what I use or borrow for the repair. Many of them are my neighbor's, and I note which ones I need to return.

- A set of spanners and sockets in sizes that fit the unit's fittings.
- Screwdrivers of several types, including small precision ones.
- Pliers, including a pair with fine tips for small clips.
- A rubber mallet for gentle persuasion.
- A clamp or vise to hold parts steady while I work.
- A small brush and bottle brushes for cleaning narrow passages.
- A torch or lamp for inspection.
- A basic measuring tool for checking that replacement parts match.
- A bucket, funnel, and hoses for the water test.
- Gloves and eye protection, which are part of the kit rather than an extra.

Before I buy any tool, I ask whether my neighbor already owns it and whether I will use it again. A tool I will use once is a poor use of budget. When a tool is borrowed, I clean it and return it promptly, since that goodwill is part of how the project runs.

## Observations

These are the things I have noticed while working on Vindraer, kept short and factual.

- The fault was smaller than it first appeared. Much of the visible grime was cosmetic and did not need repair.
- Wear is uneven. Parts that sit in the wettest places show the most damage, which suggests where to look first next time.
- Seals are the weak point. They age whether or not the unit is used, so I now treat them as routine replacements.
- The repair goes better when my neighbor and I both work from the same notes. Misunderstandings dropped once we began reading the log before each session.
- Spring suits the work. The weather is mild, the area is quiet, and the cider calendar leaves room.
- Small habits matter. Labeling parts and cleaning as I go made reassembly noticeably easier.
- Testing with water gives me confidence that is hard to get any other way.

I add to this list whenever something strikes me. Over time, patterns in these observations should show whether the repair is holding. If they begin to point to a new problem, that will go under Problems, and anything that changes the plan will be reflected in the other notes I have linked here, including [[Staga Virork]].
