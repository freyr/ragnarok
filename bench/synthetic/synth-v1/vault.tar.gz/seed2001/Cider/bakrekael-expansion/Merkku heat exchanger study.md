---
type: research
status: active
project: bakrekael-expansion
area: cider
---

# Merkku heat exchanger study

## Ideas

The Merkku heat exchanger is a grey heat exchanger that sits in the greenhouse. It was installed in 2016 and it runs on solar energy. It belongs to the cider area of my notes, because its whole job is to move heat around the cider work. These are the ideas I keep coming back to when I think about this study.

- Use the greenhouse as a free pre-warming space. On sunny days the air around the Merkku heat exchanger is warm enough that the unit hardly has to work.
- Add a simple level check on the buffer side, so I stop guessing how full it is. The [[Vilith level sensor plan]] already describes where such a sensor could go, and the [[Partonber level sensor]] note lists the model I would try first.
- Paint or wrap the pipes near the unit in a lighter material. The grey body of the exchanger absorbs a fair amount of heat, and I want to know if that helps or hurts.
- Keep a paper log next to the unit. A few lines per visit would be enough: what the weather was, how warm the water felt, and anything odd.
- Compare the Merkku heat exchanger with the older arrangement at [[Staga Virork]]. That site used a different way of moving heat, and a side-by-side view would show what the solar approach really gives me.
- Think about where the exchanger fits in the bigger layout. The [[Gondmis yard plan]] shows the paths and the pipe runs, and any move or extension of the greenhouse has to respect them.

Not all of these are worth doing. The level check and the paper log are cheap, so they come first. The paint idea is mostly curiosity, and I will only try it if I have spare material.

## Maintenance

The unit has been in place since 2016, so most of the upkeep is about age and about the greenhouse environment. The greenhouse is humid, and it gets hot in summer and cold on clear winter nights. All of that wears on the metal, the seals and the fittings.

What I check, roughly in this order:

- The outside of the grey body. I look for rust spots, flaking coating and wet marks under the unit.
- The pipe joints on both sides. Any drip, even a slow one, gets written in the log.
- The solar supply side. Because the energy source is solar, I wipe dust and pollen off whatever collects the sun, and I make sure nothing now shades it, such as a plant that has grown taller.
- The flow. I feel the pipes on the inlet and outlet sides. If the temperature difference between them is small on a sunny day, something is wrong.
- The surroundings. Leaves, pots, and crates tend to pile up around the unit, and I want air to move freely there.

Once a season I do a deeper pass. I shut the flow, drain what I can, and look inside the accessible parts for scale or sludge. Cider work leaves sugar residue, and sugar plus warmth grows things I do not want. I rinse with clean water and let it dry before closing up.

I do not trust my memory for any of this, so I keep the tools in one box near the greenhouse door: a brush, cloths, a bucket, a spare set of clamps and a torch. If I have to hunt for a tool, I skip the job, and that is how small problems turn into large ones.

One rule I have set for myself: after any work, I run the system for a full sunny afternoon and check the joints again before I leave it alone. A fix that has not been watched under load is only a guess.

## Schedule

The schedule follows the sun more than the calendar. The Merkku heat exchanger is solar powered, so its busy time is the bright half of the year, and the quiet time is winter, when I mostly inspect and repair.

A rough yearly pattern:

- Early spring: full check of the body, joints and solar supply side. Clear the greenhouse of winter clutter. Decide which repairs cannot wait.
- Late spring: first real test under strong sun. Compare inlet and outlet warmth and note it in the log.
- Summer: short weekly look, mainly for drips, shade and dust. Watch for overheating on the hottest days.
- Autumn: this is the cider season, so the unit has to be reliable. I do the deeper pass with draining and rinsing just before the first pressing.
- Winter: reduced use. I look at the unit every couple of weeks, protect it from frost, and plan the work for next year.

Weekly and monthly habits sit on top of that. Each week I walk past and look. Each month I write a short entry in the log, even if nothing happened, because a blank month is also information.

I also keep a small list of things that depend on other notes. The level sensor work depends on the [[Vilith level sensor plan]] and the [[Partonber level sensor]], and I do not want to start it in the middle of the cider season. Any change to the layout waits for a decision in the [[Gondmis yard plan]]. The best time for both is late winter, when the greenhouse is empty and the unit is not under pressure.

If a month goes by and I have missed the check, I do not try to catch up on everything. I do the quick walk-through first, then fit the rest into the next free day.

## Problems

These are the problems I have seen, or expect to see, with the unit. Some are real history and some are worries from the way the setup is built.

- Heat swings in the greenhouse. On very bright days the air around the grey exchanger gets too hot, and the output is uneven. On cold clear nights it loses heat faster than I would like.
- Humidity and corrosion. The greenhouse is damp, and after this many years since 2016 the fittings show the effects. Small rust marks appear first at the joints.
- Dust and shade. A dirty collecting surface or a tall plant nearby cuts the solar input quickly, and I only notice when the water is cooler than expected.
- Sugar residue. When cider work leaves sticky traces in the lines, they build up slowly and reduce the flow. This is the reason for the deeper autumn cleaning.
- No clear view of the level. Without a sensor, I judge the level by eye or by sound. That is unreliable, and it is the main reason for the sensor notes.
- Not enough records. Early on I did not write down what I did, so some of the older history is only in my head, and parts of it are already vague.

What I have learned from these: most of them show small signs first. A damp spot, a slightly cool pipe, a different sound. The problem is not that the signs are hard to read, it is that I miss them if I do not look regularly. This is why the log and the weekly walk matter more than any clever upgrade.

There is also the question of comparison. The older site, [[Staga Virork]], had its own set of troubles, but they were different ones, mostly about fuel and attention rather than weather. The solar choice here trades constant effort for dependence on sun, and I accept that trade, though it means planning around cloudy periods.

## Setup

This section records what the Merkku heat exchanger is and how it is arranged, so that I can find the basic facts without searching.

The properties, as I hold them:

- Name: Merkku heat exchanger
- Kind: heat exchanger
- Area: cider
- Color: grey
- Energy source: solar
- Year installed: 2016
- Location: greenhouse

The unit stands in the greenhouse, where it gets good sun and some protection from wind and rain. It is grey, which makes it easy to spot among the green growth and also easy to see when rust or stains appear. It is solar powered, so there is no fuel to carry and no mains connection to manage for the heating itself.

The connection to the cider work is through the pipes that carry warmed liquid toward the place where the cider is handled. I keep this run as short and as well covered as I can, because every extra bit of exposed pipe loses heat. The path of the pipes is drawn in the [[Gondmis yard plan]], and I update that plan whenever I change a route.

For the level question, the plan is to add a sensor on the buffer side. The position and wiring options are in the [[Vilith level sensor plan]], and the device I intend to try is described in the [[Partonber level sensor]] note. Until it is installed, I read the level by eye.

A few practical points about the surroundings:

- Keep a clear working space of about an arm's length on the access side.
- Keep the floor under the unit dry and easy to wipe.
- Keep the tool box and the paper log within a few steps of the unit.
- Keep the collecting surface free of shade, especially around midday.

Since 2016 the setup has changed in small ways rather than large ones. Some fittings were replaced, the pipe covering was renewed, and the area around the unit was tidied more than once. The basic layout is still the same, and for now I see no reason to move the unit. If I ever do, the first step is to check the [[Gondmis yard plan]], and the second is to compare the new spot with what worked at [[Staga Virork]].

## History

The Merkku heat exchanger is a grey heat exchanger that was installed in 2016 in the greenhouse. It belongs to the cider side of the work, and its energy source is solar. I keep these facts together at the top because I tend to forget which of my devices sits where, and the greenhouse is the one place where the cider equipment shares a roof with the plants.

The reason it went into the greenhouse was simple. The greenhouse gets the most sun of any covered space I have, and the cider work needs warmth at certain points: warming juice before fermentation starts, and holding a steady temperature during the early days. Putting a solar-driven exchanger there meant I could use free heat that was otherwise being vented out of the roof on sunny afternoons.

The first season after 2016 was mostly about learning how the unit behaves. The grey casing soaks up heat well, and on a bright day the whole thing is warm to the touch by midmorning. On cloudy days the output drops fast, and I learned not to plan a batch around it unless the forecast looked reasonable. After the first year I wrote down a loose routine, which became the checklist below.

Over the following years the device changed very little. I replaced some of the hoses and fittings as they aged, and I moved the supporting frame slightly so the shade from the greenhouse beams would not fall across it in the late afternoon. The core unit is the same one that went in during 2016.

Things I have noticed over the years:

- It works best from late spring to early autumn, which happens to match the apple season fairly well.
- It is slow to respond. Changes in sun show up in the liquid temperature after a delay, so I never judge it by a single reading.
- The greenhouse humidity is hard on metal parts nearby, though the exchanger body itself has held up.
- Grey was not a deliberate choice, but it has the benefit of not showing dirt and mineral marks.

## Checklist

This is the routine I follow when I use the Merkku heat exchanger. It is practical rather than formal, and I adjust it when something changes.

Before the season starts:

- Look over the whole unit for cracks, loose fittings and signs of leaks.
- Check the hoses for stiffness or discoloration. Replace anything that feels brittle.
- Flush the inside with clean water and let it drain fully.
- Make sure the frame is still level and that nothing new in the greenhouse casts shade on it.
- Wipe the grey casing so that dust does not cut down how much sun it absorbs.

Before each use:

- Confirm the sky is clear enough for solar heating to be useful.
- Open the valves slowly and check that liquid is moving in the right direction.
- Check the temperature at the inlet and again at the outlet, and compare the two.
- Keep a clean container of cider material ready so that the warmed liquid does not wait around.

After each use:

- Close the valves and let the unit cool down before touching the fittings.
- Rinse with clean water to remove sugar and fruit residue, which attract insects in the greenhouse.
- Make a short note of how it performed, including the weather.

At the end of the season:

- Drain everything completely so nothing is left standing over the cold months.
- Cover the unit if the greenhouse is going to be left unheated.
- Write a few lines about what worked and what did not, so next year I do not rely on memory.

## Costs

I am deliberately not putting prices in this note, because I do not trust old figures and I would rather describe where the money goes than quote numbers that will be wrong later.

The largest cost was the purchase and installation of the unit itself back in 2016. Because the energy source is solar, there is no fuel bill and no ongoing electricity use for the heating, which is the main reason I chose this approach for the cider work. Most of the spending was upfront.

Running costs have been small and fall into a few groups:

- Replacement hoses, clamps and seals, bought as they wear out.
- Cleaning supplies, mostly mild detergent and a lot of clean water.
- My own time, which is the biggest hidden cost. A check before and after each use adds up over a season.
- Occasional repairs to the frame and the supports in the greenhouse.

There are also costs that do not show up as purchases. The exchanger takes up space in the greenhouse that I could use for plants. It also depends on weather, so some batches have needed another heat source when the sun failed, and that backup has its own cost.

Looking at it overall, I think the unit has paid for itself in practical terms, because I have not had to buy energy for warming juice. But I have never done a careful calculation, and I would not claim a precise payback. If I ever do, I will keep the working in a separate note.

## Background

A heat exchanger moves heat from one liquid to another without letting them mix. In this case the solar side collects heat and passes it to the cider material, which stays separate and clean. That separation matters a great deal when the product is something you intend to drink.

The Merkku heat exchanger is a grey unit placed in the greenhouse, and its working idea is straightforward. Sunlight warms the surface and the liquid inside the collecting side. That warm liquid flows through the exchanger and gives up its heat to the cider side. The greenhouse itself helps, because the glazing traps warmth and keeps wind from stripping heat off the casing.

Why this matters for cider:

- Yeast is sensitive to temperature. Too cold and fermentation stalls or never starts; too hot and it produces off flavors or dies.
- Juice pressed on a cool day often needs a gentle lift in temperature before the yeast is added.
- A steady, modest warmth is better than a sudden burst, which suits a slow solar source well.

The main limits are also worth writing down. Solar output is uneven across the day and the year. The exchanger cannot give precise control by itself, so I still need a thermometer and some judgment. Cleaning is essential, because sugar left inside the cider side can sour or grow mold. And in a greenhouse, the same sunlight that helps the unit can overheat the room, so airing the space is part of the job.

I wrote this study to collect what I know about one specific device in one specific place. It is not a general guide to heat exchangers. The aim is to make it easier for me to decide, each season, how much to rely on it, what to inspect, and when to use something else.

## References

These are the sources I rely on for this note. Most are my own records, since the device is part of my own setup.

- My seasonal notes on the Merkku heat exchanger, kept since it was installed in 2016.
- My cider batch log, where I record temperatures and weather for each use.
- The maker's handling instructions that came with the unit, which I keep with the greenhouse tools.
- Notes from my own repairs and part replacements over the years.
- General reading on solar heating and on fermentation temperature for cider, from books I own and from conversations with other home cider makers.

When I add anything new, such as a better measurement method or a change to the frame, I will record it here and say where it came from, so I can tell later which observations are mine and which came from someone else.

## Risks

The Merkku heat exchanger is a grey heat exchanger in the cider area. It runs on solar energy and has been installed in the greenhouse since 2016. Because of that setup, most of the risks come from the place and the power source, not from the device itself.

- **Heat swings in the greenhouse.** On a bright day the greenhouse gets much hotter than the cellar where the cider is stored. The exchanger is only as steady as the sun, so the temperature of the liquid on the cider side can rise faster than I expect. If I am not around, a batch can overheat.
- **Cloud cover.** The reverse problem. When the sun drops out, the solar supply drops with it, and the exchanger stops moving heat at the rate I planned for. A batch that needed a long steady warm period can stall.
- **Humidity and condensation.** The greenhouse is damp. The grey outer casing has held up, but the fittings and any exposed metal are the first places I check for corrosion or a white crust.
- **Cleaning gaps.** Cider leaves sugar and fine sediment behind. If I wait too long between cleanings, the surfaces inside foul and the exchange gets slower. Since 2016 I have learned that this happens quietly and I only notice it when timings drift.
- **Contamination.** A greenhouse has soil, leaves, insects and spores. Anything that touches the cider side must be sanitized before use. A dirty hose end is a real way to ruin a batch.
- **Age.** The device has been in place since 2016, so seals and gaskets are old. A slow leak is more likely than a sudden failure, but both are possible.

I rate contamination and overheating as the two risks that can cost me a whole batch. The others cost time or efficiency.

## Lessons

Several things I now do as routine came from mistakes or near misses.

1. Check the sky before starting a run. A solar device is a planning tool as much as a machine. I look at the forecast the evening before and decide whether the day suits a long warm cycle.
2. Do not trust a single reading. I take the temperature at more than one moment and compare it with the last run. A single good number can hide a trend.
3. Clean right after use, not later. Sugar dries and hardens, and the job gets longer every day I put it off.
4. Keep the grey casing clean and dry on the outside. It is easier to spot a leak or a rust spot on a clean surface.
5. Write the run down. Even a short line with the date, weather and result helps. After a few seasons these lines show patterns I would never remember.
6. Shade matters. A small change in how the plants around the exchanger grow can reduce the sun it receives. I trim back growth near it every spring.

The biggest lesson is that the exchanger is reliable when I treat it as part of the greenhouse and not as a separate gadget. Its position, its solar supply and its surroundings all shape what it does.

## Observations

These are the plain facts and impressions I have gathered, listed with the exact properties of the subject.

- Name: Merkku heat exchanger
- Kind: heat exchanger
- Area: cider
- Color: grey
- Energy source: solar
- Year installed: 2016
- Location: greenhouse

Beyond those, here is what I have seen in daily use.

The exchanger performs best on clear days from late morning to mid afternoon. In that window the heat transfer is steady and I can leave it alone for longer stretches. In early spring and late autumn the window is short and I have to be more hands-on.

The greenhouse itself acts as a buffer. Even on a cool day, the glass holds some warmth, so the exchanger does not start from nothing. That helps on partly cloudy days, because the stored heat covers short gaps.

The grey color is plain, but it has one practical effect: it does not show dirt much, which can hide a need for cleaning. I have to look instead of relying on how it appears.

Noise is minimal. There is no engine, so the only sounds are the liquid moving and the occasional tick of metal as it warms and cools. A change in those sounds is usually the first hint that something is off, like air in the line.

Over the years the device has needed little repair. Most of my work is cleaning, checking fittings and keeping the area around it tidy. Compared with a mains powered unit, the running cost is close to nothing, though I pay for it in attention and planning.

I have also noticed that the cider made with a gently warmed process tastes cleaner when the temperature is held steady, so I value stability over speed. A slow, even warm cycle on a good day beats a rushed one.

## Open questions

There are things I have not settled and would like to test or look into.

- How much does the exchange rate fall after a month of use without a deep cleaning? I have a feeling about it but no measured answer.
- Would a simple shade cloth in the hottest weeks reduce overheating risk without cutting the useful output too much?
- Are the seals due for replacement, given that the unit has been installed since 2016? I need a way to test them before they fail.
- Could a small insulated buffer tank smooth out the swings between sunny and cloudy spells?
- Is the damp air slowly harming the fittings in a way I cannot see from the outside?
- Would moving the unit a short distance within the greenhouse give it better sun and less condensation?
- What is the best way to record temperatures so I can compare seasons fairly? So far my notes are uneven.

I want to answer these one at a time over the next seasons, starting with the cleaning interval and the seals, since those affect the risks that matter most.

## Supplies

This is the list of things I keep on hand for the Merkku heat exchanger, so a run or a cleaning never has to wait.

- Food safe sanitizer for all parts that touch the cider
- Soft brushes of different sizes for the inside surfaces and the fittings
- Clean cloths that are only used for this device
- Spare gaskets and seals that match the existing fittings
- Short lengths of food grade hose, with clamps
- A reliable thermometer, plus a second one to cross-check it
- A notebook and pen kept in the greenhouse for run notes
- Mild detergent and clean water for rinsing
- A light oil safe for use near food, for moving metal parts
- Gloves and a small tray to catch drips
- Shade cloth, in case I decide to test it for the hottest weeks

I store the cleaning items in a closed box in the greenhouse so damp and dust do not get to them. The spare seals stay indoors, since the greenhouse humidity would age them. Before each season I go through the list, throw out anything worn and replace what is missing. That check takes only a short while and has saved me from more than one awkward afternoon.

## Tools

This section lists what I use when I work on the Merkku heat exchanger. The unit is grey, it sits in the greenhouse, and it has run on solar energy since it was installed in 2016. It belongs to the cider area of the work, so most of my tool choices are about keeping things clean and keeping the sugar residue under control.

Most of these are ordinary workshop tools. I keep them together in one crate near the greenhouse door so that I do not have to walk back to the house in the middle of a job. The crate gets emptied and wiped twice a year.

### Measuring tools

- A digital caliper with a depth rod. I use it for every gap and offset check. It reads to three decimals in millimetres, and I trust it more than the old dial caliper, which sticks in cold weather.
- A feeler gauge set. It is useful for the plate spacing near the inlet, where the caliper does not fit.
- Two probe thermometers with long leads. One goes on the inlet side and one on the outlet side. I tape the leads down so they do not touch the casing, because the grey casing gets warm in the afternoon sun and that skews the reading.
- A small hand refractometer for the cider itself. It tells me whether the sugar content of the liquid I am running matches what I wrote in my log.
- A pressure gauge on a short hose with a quick fitting. I only attach it for checks and then take it off again.

### Cleaning tools

- A soft nylon brush set in three sizes. Steel brushes scratch the plate surfaces and give the residue something to cling to.
- A food-safe descaling solution, mixed in a clean bucket that is used for nothing else.
- A pump and two hoses to circulate the cleaning solution backward through the exchanger. Flushing in the reverse direction shifts more deposit than flushing forward.
- Clean rags, a roll of paper towels, and a bottle of plain water for the final rinse.
- Nitrile gloves and safety glasses. The descaling solution is mild, but I do not want it in my eyes.

### Mechanical tools

- A socket set with a torque wrench. The clamp bolts on the frame need to be tightened evenly, working across in a cross pattern, not around in a circle.
- A set of open-ended spanners for the fittings on the pipes.
- A rubber mallet for gentle persuasion on stuck covers. I never use a metal hammer on the casing.
- Spare gaskets and a tube of food-safe grease. I keep these in a sealed bag so that dust does not get into the grease.
- A marker pen, used to draw alignment lines across the plates and the frame before I take anything apart. This saves me a lot of guesswork at reassembly.

### Notes and logging

I keep a paper notebook in the crate. I write down the date, the weather, the inlet and outlet temperatures, and what I did. The greenhouse is a bad place for a laptop because of humidity and glare, so I copy the notes into the knowledge base later in the evening.

A phone camera is the last tool. Before I open the unit, I photograph the plate stack from both sides and the position of every bolt. The photos have saved me more than once.

### Tool habits

- Wipe every tool after use and put it back in the same spot in the crate.
- Check the caliper battery at the start of each season, not in the middle of a job.
- Never leave the probe thermometers in direct sun between readings.
- Keep the cleaning bucket and the cider buckets in different colours so they are never confused.

## Adjustment

This section covers how I set the Merkku heat exchanger after cleaning or reassembly. The aim is simple: the plate stack should sit square in the frame, the gaps should be even, and the unit should give a steady temperature rise from the solar loop to the cider side without leaking.

The key number is the calibration offset of Merkku heat exchanger: 2.467 mm. This is the offset I set between the reference mark on the frame and the pressure plate once the stack is clamped. I check it with the depth rod of the caliper, not with the jaws, because the jaws slip on the painted grey surface.

### Before I start

- The unit must be cool. After a sunny day the greenhouse and the casing are both warm, and the metal grows slightly. I work in the early morning.
- The solar loop must be isolated and the cider side drained, so nothing is under pressure.
- I look at my alignment lines from the last disassembly. If they are still visible and the plates line up, I know the stack has not shifted.
- I confirm that the gaskets sit flat in their grooves. A twisted gasket will ruin the whole adjustment, and I will not find out until I see a drip.

### Steps

1. Loosen all the clamp bolts a little at a time, in the cross pattern, until the pressure plate moves freely by hand.
2. Push the plate stack toward the fixed end of the frame and check that the alignment lines match from top to bottom.
3. Tighten the bolts by hand first, so that the pressure plate stays parallel to the fixed plate.
4. Use the torque wrench to bring each bolt up to a snug load, again in the cross pattern. I do this in three rounds with small increases, not in one go.
5. Measure the offset at four points: top left, top right, bottom left, and bottom right. Each reading should come to the calibration offset of 2.467 mm.
6. If one corner is off, loosen only the bolt on that side and nudge it. Then repeat the full cross pattern, because changing one bolt changes the others.
7. Write the four readings in the notebook before I move on.

### Why the offset matters

If the offset is too large, the plates are not compressed enough, and the gaskets can weep. I once saw a slow cider drip at the lower corner, and it turned out the stack was loose by a small amount on that side. If the offset is too small, the gaskets are crushed. That makes the flow rougher and shortens gasket life, and the plates are harder to separate next time.

The solar source adds one complication. Because the energy source is solar, the heat input is not constant. On a bright day the loop temperature climbs quickly, and the stack expands. A unit set tightly at midday might be too loose by evening. This is why I always set it cool and then do a second check after the first warm afternoon.

### After the adjustment

- Open the cider side slowly and let it fill with the vent open, so no air stays trapped.
- Look at every joint for a minute or two, with a dry paper towel held against the corners. A damp towel tells me more than my eyes.
- Run the loop at low flow first, then raise it step by step.
- Compare inlet and outlet temperatures with the notebook entries from earlier runs. A big change without a change in the weather points to a gap problem or to trapped air.
- Re-measure the offset after the first warm afternoon and record it.

### Common problems

- **Drip at one corner:** the stack is likely uneven. Release the bolts, square it up, and repeat the cross pattern.
- **Poor temperature rise:** check for air in the cider side, then look for residue on the plates.
- **Stiff bolts:** clean the threads and add a little food-safe grease. Dirty threads give false torque readings.
- **Offset keeps drifting:** the gaskets may be old. I replace the whole set, not just one, so that they compress evenly.

### Notes for myself

The grey paint makes marks hard to read in bright light, so I use a pale marker and shade the work with a board when the sun is strong. I also try not to adjust the unit in a hurry. Most of my past mistakes in the greenhouse came from rushing the last few bolts.

When the offset is right and the unit stays dry through a full day of sun, I mark the date in the notebook and leave the settings alone until the next scheduled clean.
