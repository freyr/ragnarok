---
type: note
status: active
project: bakrekael-expansion
area: cider
description: "Note about Sioteth level sensor."
---

# Sioteth level sensor notes

## Background

The Sioteth level sensor is a level sensor that I use in the cider area. It is red, which makes it easy to spot against the grey tanks and the wooden shelves. It runs on mains power, so there is no battery to charge or replace. I installed it in 2021, and it lives in the workshop.

I bought it because I wanted to stop climbing a stepladder to look into the vessels with a torch. The idea was simple: get a steady reading of how full a container is, and glance at it from the workbench. In the years since, it has become one of those devices I stop noticing, which is a good sign. When it works, I forget it exists. When it misbehaves, I notice quickly, because I have gotten used to trusting it.

The wiring is plain. A mains lead runs along the back of the bench to a socket strip, and the sensor head sits on a bracket above the vessel. I keep a sketch of the bracket position in my paper notebook, because the reading shifts if the head is moved even a little.

Quick facts for reference:

- Kind: level sensor
- Area: cider
- Color: red
- Energy source: mains
- Year installed: 2021
- Location: workshop

## Open questions

There are several things I still do not know about this sensor, and I would like to settle them before I rely on it for anything more important.

- How much does foam on the surface change the reading? During the lively stage of fermentation the surface is rough and bubbly, and I suspect the sensor reports a level that is slightly too high. I have never tested this properly.
- Does the workshop temperature affect the reading? The room is cold in winter and warm in summer, and I have not compared the same fill level across seasons.
- How long will the housing last near sweet, sticky air? Cider work leaves a fine film on everything, and I do not know whether it will eventually creep into the connector.
- Is it worth fitting a small surge protector on the mains lead? The workshop shares a circuit with a few power tools, and the lights sometimes dip when the big saw starts.
- Should I add a second sensor for a different vessel, or move this one when needed? Moving it means redoing the position check each time.

## Lessons

The first lesson was about mounting. In the first season I fixed the bracket with a single screw, and the head slowly rotated. The readings drifted for weeks before I worked out why. Now the bracket has two screws and a mark in pencil so I can see at a glance whether anything has moved.

The second lesson was about cleaning. A damp cloth is enough, but only after unplugging the sensor. I once wiped it while powered and it gave a wild reading for an hour afterwards. Nothing was damaged, but I would rather not repeat it.

The third lesson was to write down a reference reading whenever a vessel is empty and clean. That number is my baseline. If a later empty reading is different, I know something has changed, either the sensor position or a film of residue on the head.

Smaller habits that have helped:

- Check the pencil mark on the bracket before each new batch.
- Wipe the head at the end of the season, not in the middle of it.
- Keep the mains lead away from the bench edge, where it gets snagged.
- Compare the sensor with a simple dipstick once per batch, just to confirm nothing has drifted.

I also learned not to over-trust a single number. The sensor is good for trends and rough fill levels, and I treat it that way. When I need an exact volume, for example when I am working out how much sugar or yeast to add, I still measure by hand.

## Measurements

The only electrical measurement I have taken so far is the power draw. With a plug-in meter on the socket strip, I measured the power draw of the Sioteth level sensor at 160.61 W. That is higher than I expected for a device that sits and watches, so I want to confirm it later with the sensor isolated from everything else on the strip.

Because it runs on mains and stays on all year, the draw adds up over a long season. I have considered switching it off between batches, since there is nothing to measure when the vessel is empty. So far I have left it on, mostly out of habit and to avoid disturbing the settings.

Other things I track around the sensor:

- Reference reading with an empty, clean vessel, written in the notebook.
- Fill readings at the start and end of each batch.
- Position of the bracket, checked against the pencil mark.

I have not yet logged the readings in a table, and I would like to start. A simple sheet with one row per batch, covering date, fill level, and any notes about foam or temperature, would answer most of my open questions within a season or two.
