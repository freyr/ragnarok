---
type: drivers
status: active
project: bakrekael-expansion
area: cider
description: "Drivers about Bakrekael expansion."
---

# Drivers of Bakrekael expansion

## History

Bakrekael expansion is a project in the cider area. The goal is expansion. It started in the winter of 2020, and the lead is the electrician. I keep this note for the drivers: why the project exists, what limits it, what it may cost, and how I will know it worked.

The idea came up during the first cold months of 2020. The cider room was already full by then. Every extra batch meant moving something else out of the way, and the wiring was the main thing holding us back. The old circuits could not take another pump, another chiller and better lighting at the same time. So the electrician became the lead, because nothing else could be planned until the power question was answered.

Early on I looked at how the loft was used for storage. My records of that are in [[Narkmin loft log]]. The loft stays dry enough for empty bottles and crates, which frees floor space below. That was the first small gain and it helped make the case for the larger work.

Humidity was the second problem. Damp air in the pressing area caused mould on wooden surfaces and rust on tools. I wrote down what I learned about drying the air in [[Triothkil dehumidifier notes]]. Those notes still shape how I think about the new layout.

## References

These are the notes I come back to most often while working on the project.

- [[Triothkil dehumidifier notes]]: moisture control, sizing, and where the drain should run.
- [[Narkmin loft log]]: what is stored in the loft and how the space has held up through the seasons.
- [[Karkkiork air compressor handbook]]: how the compressor works, how to maintain it, and what it needs from the electrical supply.
- [[Drurtos kiln controller plan]]: a controller design I borrowed ideas from for temperature control and timing.
- [[Triorkgend radio receiver plan]]: useful for the wiring layout and for thinking about interference near motors.
- [[Glaelbrath scale study]]: how I weigh fruit and batches, and how accurate the scales need to be.
- [[Zorzaerk Lirfu]]: the person I ask when I need a second opinion on the plan.

The goal of the project is expansion, and every one of these notes feeds into that in some way. When two notes disagree, I go with the one that is closest to the actual conditions in the cider room.

## Budget

The budget of Bakrekael expansion is 20817.90 EUR.

This covers the electrical work first, since the electrician leads the project and the wiring comes before everything else. After that come the equipment for the larger room, basic fittings, and a reserve for things I did not see coming. I do not want to spend the reserve on upgrades. It is there for repairs and for surprises behind the walls.

Rules I follow for money:

- Pay for the electrical work before buying any new machine, so I know what power I really have.
- Keep every receipt together and note what each one was for.
- Ask for a written quote before any job begins.
- If a single item pushes the total past the budget, stop and decide whether something else can wait.

The budget is a limit, not a target. If the work finishes under it, the rest stays unspent.

## Ideas

A few ideas have stayed on the list through the winter of planning.

- Put the compressor on its own circuit, so that its starting surge does not dim the lights or trip other equipment. The handbook in [[Karkkiork air compressor handbook]] says what it needs.
- Add a simple temperature controller with a timer for the fermentation corner, borrowing the approach from [[Drurtos kiln controller plan]].
- Use a scale at the intake table to record fruit weights per batch, following [[Glaelbrath scale study]].
- Place the dehumidifier near the pressing area and run its drain to the floor channel, as described in [[Triothkil dehumidifier notes]].
- Keep radio and other small electronics away from motor wiring, a lesson from [[Triorkgend radio receiver plan]].
- Move all empty crates to the loft, as recorded in [[Narkmin loft log]], to open up more floor.
- Ask [[Zorzaerk Lirfu]] to look over the final layout before any walls are closed.

Ideas I dropped: a second pressing line (too expensive for now) and a full automatic bottling setup (the room is not big enough yet).

## Checklist

How I measure success, and what must be true before I call the project done.

- [ ] The goal, expansion, is met: the cider room holds more batches than before without crowding.
- [ ] The electrical work is finished and signed off by the electrician who leads the project.
- [ ] Total spending is within the budget of 20817.90 EUR.
- [ ] Moisture is under control and no new mould appears over a full season.
- [ ] The compressor, chiller and pumps can run together without tripping a breaker.
- [ ] Every circuit is labelled in the panel.
- [ ] Floor space is clear and the loft storage is organised.
- [ ] Notes are updated, including the linked ones.
- [ ] A second person has walked through the room and looked for problems.

Constraints I keep in mind: the work should happen in the quiet season, the room must stay usable for cider making as much as possible, and nothing may block the exits.

## Setup

The working order matters, so I wrote it down.

1. Clear the room and move loose items to the loft. Update [[Narkmin loft log]] with what went up.
2. Have the electrician survey the existing wiring and mark where new circuits will run.
3. Install the new circuits and the panel changes before any equipment arrives.
4. Place the dehumidifier and run the drain, following [[Triothkil dehumidifier notes]].
5. Install the compressor and check its supply against [[Karkkiork air compressor handbook]].
6. Fit the temperature controller and timer.
7. Set up the weighing station as in [[Glaelbrath scale study]].
8. Test everything together for a full day before filling any tanks.

I keep a notebook by the door for anything odd that I notice during the tests. Small noises and warm cables are worth writing down.

## Safety

Electrical work is the main risk in this project, which is why the electrician leads it.

- Only the electrician touches the panel or the fixed wiring.
- Switch off and lock the supply before any work on a circuit, and test that it is dead.
- Keep water away from sockets and cables. The room is damp by nature, so use fittings rated for wet places.
- Keep the compressor tank maintained and drained, as the handbook says, and never run it with a damaged hose.
- Keep fire extinguishers within reach and check that they are in date.
- Keep the exits and the path to the panel clear at all times.
- Wear sturdy shoes and gloves when moving crates, and do not carry heavy loads up to the loft alone.
- Fermentation gives off carbon dioxide, so keep the room ventilated when working near full tanks.

If something smells hot or a breaker keeps tripping, stop work, switch the supply off, and call the electrician before going on.
