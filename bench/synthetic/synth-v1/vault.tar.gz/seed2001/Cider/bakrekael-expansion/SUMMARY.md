---
type: summary
status: active
project: bakrekael-expansion
area: cider
description: "Summary about Bakrekael expansion."
---

# Summary of Bakrekael expansion

## Open questions

The Bakrekael expansion is a cider project with the goal of expansion. It started in the winter of 2020, and the lead is the electrician. It is past the go decision and now in the build and wiring stage. Most of the groundwork is done, but a few things are still open.

- Where should the new press feed line run? The [[Rarkaend loft plan]] puts it along the north wall, but the electrician wants it moved to keep it clear of the new panel.
- Can the existing supply handle the extra load once both tanks and the kiln run together? I have a rough answer but nothing written down from the electrician.
- Who signs off on the final layout of the cold room? Nobody has said yet.
- Do the results in [[Riothkren Niordio tests]] and [[Gulzesruth Naekrago tests]] agree well enough to treat the fermentation room as ready? The first set looks fine. The second set has gaps that I still need to fill.
- Should the temperature logging go through the [[Gliormiol kiln controller]] or stay on its own small unit? Running both would be easy, but I do not want two sources of truth.

I keep this list short on purpose. If a question stays open for more than a few weeks, it either becomes a decision or moves into the risks section.

## Safety

Because the electrician leads this project, safety is mostly about electrical work in a wet, sticky place. Cider rooms are damp, and spilled juice conducts and corrodes.

- All new sockets in the pressing and fermenting areas go on protected circuits, with covers rated for splashes.
- Cable runs stay off the floor and away from drain lines. Where they must cross a walkway, they go overhead.
- The panel is labelled before anything is switched on. Every circuit gets a plain-language name, not just a position.
- Nobody works on the wiring while the room is being washed down. Washing and electrical work are scheduled on different days.
- The kiln area keeps a clear zone around it. Nothing flammable is stored there, including spare cardboard and old crates.
- A fire extinguisher sits near the exit of the kiln side, and another near the panel.

Lifting is the other main hazard. Full tanks and press parts are heavy, so anything over what one person can carry is moved with two people or with the trolley. I do not move tanks by myself, even empty ones.

I also keep the work sequence simple: isolate, test, work, test again, restore. The electrician follows this already, and I follow it for anything I touch myself, which is only low-risk jobs like mounting shelves.

## Decisions

The go decision for the project was made on 2021-01-03. Before that date the project was only an idea with a rough sketch, and after it the budget and the lead were fixed.

Decisions made so far:

- The electrician leads the whole project, not only the wiring. That was chosen because most of the early work depends on power and controls, and one person owning the order of jobs avoids clashes.
- The expansion stays within the existing building. The loft is used for storage according to the [[Rarkaend loft plan]], so nothing needs to be built outside.
- Temperature control for the kiln side is handled by the [[Gliormiol kiln controller]]. I chose it because it is already known and the settings are documented.
- Contact for outside advice goes through [[Zorzaerk Lirfu]], who knows the local rules and has helped before. I do not call other advisers unless Zorzaerk Lirfu cannot help.
- Layout questions that touch the wider site are handled in the [[Konkrur Faesnus plan]], so this note does not repeat them.
- Work is done in the winter slots, because the cider season is quiet then and the rooms can be switched off without losing stock.

Things I decided against: buying a second press for now, and moving the cold room. Both came up and were set aside as too costly for the gain.

## Next action

The next action is NX-2973.

It is the next step on the electrician's list and it unblocks the rest of the wiring. I do not start any other job in the fermentation room until it is finished, because the later jobs rely on its result. When it is done, I update this note, close the matching open question, and check whether the layout question can be answered at the same time.

After that, the order is simple. First the test results are reviewed together, then the open questions are cut down, and then the sign-off on the cold room is requested. If NX-2973 slips, I note the reason here and tell the electrician before touching the schedule.

## Risks

The main risks are practical and mostly known.

- **Power supply.** If the existing supply cannot carry the full load, a larger connection might be needed. That would add cost and delay, and it could push the work past the winter slot.
- **Moisture damage.** Even protected fittings can fail in a damp room over time. I plan regular checks, starting soon after the first full run.
- **Single lead.** The electrician leads the project and also does the main work. If they are unavailable, progress stops. I keep the notes clear enough that someone else could pick up the list.
- **Test gaps.** The second set of results is incomplete. If I mark the room ready too early, a problem could show up once real batches are running.
- **Scope creep.** Ideas keep appearing, such as a second press or extra storage. Each one needs a clear reason before it enters the plan, or the winter slot will not be enough.
- **Timing with the season.** The expansion area is cider, and the busy season does not wait. Any delay that pushes work into the pressing period means working around live production, which raises the safety risk too.

For each risk, the first response is to note it here and tell the electrician. Only if it affects the plan do I go back to the decisions and change them. At the moment none of these risks is serious enough to stop the project, but the power supply question is the one I watch most closely.
