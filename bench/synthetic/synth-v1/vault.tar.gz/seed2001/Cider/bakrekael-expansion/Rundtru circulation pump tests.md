---
type: research
status: active
project: bakrekael-expansion
area: cider
description: "Research about Rundtru circulation pump."
---

# Rundtru circulation pump tests

## History

The Rundtru is a red circulation pump used in the cider area. It runs on mains power and was installed in 2018. It sits by the pond, where it moves water for cooling. I started testing it after noticing the flow seemed weaker than before.

- Kind: circulation pump
- Area: cider
- Color: red
- Energy source: mains
- Year installed: 2018
- Location: pond

## Measurements

I timed how long the pump took to fill a marked bucket, then converted the result to hourly flow. The reading is below.

```
test: bucket fill
pump: Rundtru
flow rate: 1573.52 l/h
```

The flow rate of the Rundtru circulation pump is 1573.52 l/h. I will repeat the test after cleaning the intake.
