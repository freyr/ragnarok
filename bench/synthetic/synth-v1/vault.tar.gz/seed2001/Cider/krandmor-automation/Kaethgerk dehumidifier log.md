---
type: log
status: active
project: krandmor-automation
area: cider
description: "Log about Kaethgerk dehumidifier."
---

# Kaethgerk dehumidifier log

## Problems

The Kaethgerk dehumidifier is a red, battery-powered unit that I installed in 2025. It sits in the greenhouse and serves the cider area. This log tracks what goes wrong with it and what I do about it.

The main trouble is that the greenhouse gets very humid in the evening, when the temperature drops and the glass starts to sweat. The Kaethgerk does the most work then, and that is also when it has given me the most trouble.

Problems I have seen so far:

- The battery drains faster than I expected when the air is very damp. On a bad week it needs a recharge much sooner than the week before.
- The collection tank fills up quickly and the unit stops without warning if I forget to empty it.
- The humidity reading drifts away from my separate hand gauge. It usually reads a little drier than the real air.
- Condensation forms on the outside of the red casing and drips onto the shelf below, which is a problem near the cider equipment.
- The fan makes a rattling noise if the unit is not sitting flat on the bench.

The drift in the reading was the most annoying, because the unit then switched off too early and the air stayed damp around the barrels and the bottles. I checked the unit against the hand gauge on three different days before I trusted my own conclusion. The pattern was the same each time, so I decided it was a real offset and not a one-off.

The rattle turned out to be simple. The bench in the greenhouse is slightly uneven, and a folded piece of cardboard under one corner fixed it. I should replace the cardboard with something that will not go soft in the damp.

## Adjustment

To correct the drifting reading I applied a calibration offset. The calibration offset of Kaethgerk dehumidifier is 0.431 mm. I keep it written here so that I can set it again if the unit ever loses its settings after the battery runs flat.

How I set it:

- Bring the unit into a dry, still spot and let it settle for a while before touching anything.
- Compare the display with the hand gauge sitting right beside it.
- Enter the offset in the setup menu and confirm.
- Leave the unit running for a full evening and check the reading again the next morning.
- Put it back in the greenhouse on the flat part of the bench.

After the adjustment, the reading matched the hand gauge much better. It is not perfect, but it is close enough that the unit now switches off at about the right time. I still do a quick comparison once in a while, because the sensor can wander a bit as it ages.

Other small adjustments I made:

- Moved the unit away from the glass wall so that less water drips on it.
- Placed a shallow tray under it to catch the drips from the casing.
- Set the target humidity a little lower for the nights when the cider is fermenting, since the air is wetter then.

If the offset ever seems wrong again, I will first check the battery level, because a weak battery seems to make the readings less steady.

## Schedule

I keep a simple routine so that the Kaethgerk does not run into trouble again. Nothing here is complicated; the point is to make it a habit.

Daily:

- Empty the collection tank in the morning.
- Glance at the display and compare it with the hand gauge.
- Check that the unit is still level on the bench.

Weekly:

- Recharge the battery fully, even if it still seems to have some power left.
- Wipe the red casing and the air intake with a dry cloth.
- Look at the tray under the unit and empty it.

Monthly:

- Run the full comparison against the hand gauge and note any drift in this log.
- Check the offset value in the setup menu to make sure it has not been reset.
- Inspect the fan for dust and for any new rattling.

Each year:

- Think about whether the battery is still holding enough charge. The unit has been in the greenhouse since 2025, so I expect the battery to age before the rest of it does.
- Replace the cardboard shim with a proper rubber pad.
- Decide whether one unit is enough for the cider area or whether the greenhouse needs a second one.

I will add short entries below this section whenever something changes, so that the history of the Kaethgerk stays in one place.
