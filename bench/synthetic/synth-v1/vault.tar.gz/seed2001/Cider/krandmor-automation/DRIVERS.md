---
type: drivers
status: active
project: krandmor-automation
area: cider
description: "Drivers about Krandmor automation."
---

# Drivers of Krandmor automation

## Setup

Krandmor automation is a project with the goal of automation. It sits in the cider area. It started in 2025 and runs in the summer season, which is the busy time for pressing and bottling. The lead is the inspector.

This drivers note covers why the project exists, what limits it, what it is allowed to cost, and how I decide whether it worked. I keep it short enough to reread before each decision. When a new idea comes up, I check it against this note first.

The basic setup is simple. The cider work has many repeated manual steps. Each one is small, but together they eat the hours in summer. The project is meant to take some of those steps off people and give them to simple machines and routines. The inspector leads because the inspector sees the whole line and knows where mistakes and delays actually happen.

## Ideas

These are the ideas that came up as possible drivers. Some are firm and some are only candidates.

- Reduce the hours spent on repeated manual checks during summer.
- Make batch records consistent, so that every batch is written down in the same way.
- Cut down on spills and waste caused by tired hands at the end of a long day.
- Make the work easier to hand over, so that someone new can follow the routine without a long explanation.
- Free up time for tasting and quality work, which is the part nobody wants to lose.

The goal is automation, but automation is not the point by itself. If a step is rare, delicate, or better done by a person who is looking and smelling, I leave it alone. The first idea, fewer manual checks, is the strongest driver. The others support it.

One idea I rejected: automating everything in one go. It looks tidy on paper, but it makes failures hard to trace and it puts the whole budget at risk early. I prefer small steps, each one tested in a real summer week before the next.

## Observations

Things I have noticed that shape the drivers:

- Most delays come from waiting for a person to be free, not from the work itself.
- Errors cluster in the same few places: labelling, recording quantities, and cleaning logs.
- The busiest weeks leave no room to learn a new tool, so anything new has to be introduced before the rush, not during it.
- People accept a change faster when it removes a chore they dislike than when it replaces a job they enjoy.
- The inspector's walk-through of the line is the best source of facts. Written complaints are useful, but they come late.
- Anything that needs constant adjusting is not really automation. It just moves the work somewhere else.

From these, I take three constraints. First, changes must be small and reversible. Second, the manual way must still work if a machine fails. Third, nothing may change the taste or the safety of the cider, and the inspector decides that, not me.

## Costs

The costs fall into a few groups. I list them without prices here, because the total is capped in the budget section.

- Equipment and sensors for the steps chosen first.
- Wiring, mounting and small parts to fit them into the existing line.
- Software or simple control logic, kept as plain as possible.
- Time for testing during real summer production.
- Training time for the people who will use the result.
- Spare parts and a reserve for repairs.

Hidden costs matter more than the purchase. A device that breaks in the middle of summer costs the repair plus the lost day. So I count reliability and ease of repair as part of the price. A cheaper unit that nobody can fix locally is not cheaper.

I also count the cost of doing nothing: the hours, the waste and the mistakes that continue every season if the project is never done.

## Background

The cider area has worked by hand for a long time, and much of the knowledge lives in people rather than on paper. That is a strength and a risk. When someone is away in the middle of summer, the routine suffers.

Krandmor automation began in 2025 as a response to a hard summer, when the repeated checks and records took more time than the pressing itself. The goal was set as automation, and the inspector was named lead because the problems were mostly about checking, recording and consistency, which is the inspector's daily ground.

The project runs in the summer season because that is when the benefit is visible and measurable. Testing in winter would be calmer, but it would not show whether a change survives real load. So the plan is to prepare in the quiet months and test in summer.

Success is measured in plain terms:

- Fewer manual checks per batch than before.
- Fewer recording errors in the batch notes.
- Less waste from avoidable mistakes.
- A new person can follow the routine with little help.
- No loss of quality, as judged by the inspector.

I compare each summer with the one before, using the same simple counts. If a measure cannot be counted easily, I do not use it.

## Budget

The budget of Krandmor automation is 15639.05 EUR.

This is the cap for the whole project, including the reserve for repairs and the testing time that has a real cost. I treat it as a ceiling, not a target. If a step would push the total above it, the step waits or is dropped.

Rules I follow with the budget:

- Spend in stages, and only start the next stage after the previous one has proved itself in summer.
- Keep a reserve unspent until late in the season.
- Record every purchase with the reason for it, so the total can be checked against this note.
- Ask whether a manual fix would do before buying anything.

## References

- The inspector's walk-through notes of the line, which are the main source for the problems listed above.
- My batch records from earlier summers, used for the before-and-after counts.
- Notes on the cider area routines, including cleaning and labelling.
- Supplier notes on equipment I have considered, kept with the purchase records.
- Earlier notes on small automation trials, including what failed and why.

When I add a new source, I write down what it was used for. A source that does not support a driver, a constraint, the budget or a success measure does not belong here.

## Maintenance

This note needs regular care, or it will drift away from the real project.

- Reread it at the start of each summer and again at the end.
- Update the observations after each walk-through with the inspector.
- Check the budget section whenever money is spent, and keep it consistent with the purchase records.
- Remove ideas that were tried and dropped, and note the reason in a single line.
- If the goal changes, rewrite the setup first and then adjust the rest to match.
- If the lead changes, record it in the setup and tell the new lead where the constraints are.

I do not rewrite history. If a driver turned out to be wrong, I keep a short line saying so, because the mistake is useful for the next project.

## Checklist

Before starting any new step of Krandmor automation, I check:

- Does it serve the goal of automation, and does it reduce manual checks?
- Is it small and reversible?
- Does the manual way still work if it fails?
- Has the inspector agreed that quality and safety are not affected?
- Is the cost inside the budget, with the reserve still intact?
- Can it be tested in a real summer week, before the rush?
- Do I know how success will be counted, and what the count was before?
- Is the purchase and the reason written down?
- Does someone besides me know how to repair or bypass it?

If any answer is no, the step waits until it is yes.
