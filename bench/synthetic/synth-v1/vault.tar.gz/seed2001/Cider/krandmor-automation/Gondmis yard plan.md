---
type: plan
status: active
project: krandmor-automation
area: cider
---

# Gondmis yard plan

## Schedule

This plan covers the work I want to do on Gondmis yard over the next few months. I keep the order simple so I can follow it without checking anything else.

1. Walk the whole yard and write down what is damaged, starting at the north edge.
2. Clear the loose stones and old crates from the raised floor.
3. Check the drainage along the low sides, since water is the main risk for a raised floor.
4. Repair the worst boards or slabs first, then the minor ones.
5. Sweep, wash, and let the surface dry fully before any stacking begins.
6. Set out the cider barrels and press equipment in their new places.
7. Do a final walk and update this note with what changed.

I plan to do steps one to three in a single weekend, because they need no materials. Steps four and five depend on the weather, so I will leave them open and pick a dry stretch. Steps six and seven come last, once I am sure the floor is dry and sound.

## Overview

Gondmis yard is a place of the kind yard. It belongs to the cider area, and everything stored or worked there relates to making and keeping cider. The yard was built in 1988, so it is old enough that I expect some wear in the surface and the edges.

The yard is large. There is plenty of room for barrels, crates, and a press, and still space to move a trolley between them. Because of the size, I treat it in zones rather than all at once. I check one zone, fix it, then move on.

The orientation is north. The open side faces north, which means the yard gets less direct sun than I would like. Damp lingers longer, especially in autumn and winter. That is why drying time is built into the schedule above and why I keep a close eye on humidity.

The floor is raised. This helps keep the working surface above ground water and mud, and it gives air room underneath. It also means the edges and any steps need checking for loose parts, and the underside needs a look for rot or pests. I do not want a weak spot under a full barrel.

In short, the properties I rely on are these: kind yard, area cider, orientation north, size large, year built 1988, floor raised.

## Measurements

The main reading I have is the humidity. The measured humidity of Gondmis yard is 22.05 %. That is low enough that I am not worried about damp at the moment, though I took it on a dry day and it will rise in wetter months.

I want to take more readings in the same way so they can be compared:

- Measure at the same time of day each visit, ideally in the morning.
- Take one reading near the north edge and one near the middle.
- Write each result in this note with the date of the visit.
- Take a reading again after rain, to see how quickly the floor dries.

Other measurements still to do are the length and width of each zone, the height of the raised floor at the lowest and highest points, and the spacing between barrel positions. I will add those once the first walk is finished. For now the humidity reading is the only figure I trust, and the rest of the plan works from it.

If humidity climbs much higher than today, I will move the barrels away from the north edge and increase the drying time in the schedule.
