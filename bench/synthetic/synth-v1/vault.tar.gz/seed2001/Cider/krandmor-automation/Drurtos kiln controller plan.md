---
type: plan
status: active
project: krandmor-automation
area: cider
description: "Plan about Drurtos kiln controller."
---

# Drurtos kiln controller plan

## Problems

The Drurtos kiln controller is a grey kiln controller that sits in the yard and serves the cider area. It was installed in 2016 and has run on solar power ever since. Ten years is a long time for a device that lives outdoors, so this plan starts with what is going wrong or likely to go wrong.

The first problem is the power supply. Because the energy source is solar, the controller only behaves well when the panel and battery are healthy. On short winter days the battery does not fill, and the controller can drop out partway through a drying run. When that happens the kiln either cools too early or holds heat longer than I intended, and the batch of apple pomace or pear slices I was drying is uneven.

The second problem is weather. The yard location means rain, frost, dust, and wasps. The grey casing has faded and the seals around the cable entries are tired. I have seen condensation on the inside of the window once or twice after a cold night.

The third problem is the display. It is hard to read in bright sun, and the buttons need a firm press. I sometimes think a setting has been accepted when it has not.

The fourth problem is that I do not trust my memory of the settings. I changed a few things over the years and never wrote them down. This plan is partly an attempt to fix that.

Short list of what I want to solve:

- Dropouts on low solar days.
- Moisture getting into the casing.
- A display that is hard to read and buttons that are unreliable.
- Missing records of the settings in use.
- No regular maintenance routine.

## Safety

A kiln controller switches heat, so the safety rules come before everything else in this plan.

- Isolate the power first. With a solar setup, switching off at the controller is not enough. Disconnect the panel feed and the battery before opening the casing, because the panel can still produce current in daylight.
- Let the kiln cool fully before any work on the heating side. Surfaces in the yard stay hot long after the display shows a low reading.
- Do not work on it in the rain or on wet ground. If the casing has been soaked, open it only after it has dried out in a sheltered spot.
- Keep a dry-powder or similar suitable extinguisher within reach of the kiln, not in the house.
- Keep children and pets out of the yard area while the kiln is running or cooling.
- Do not bypass any cut-out or limit device to get a run finished. If a limit trips, find out why.
- Wear gloves when handling the hot parts and eye protection when cleaning out dust or cutting cable ties.
- Tell someone at home before starting a long run, especially one that goes overnight.

Cider work adds a minor point: sugary residue and fruit dust are flammable in quantity. Sweep the area around the kiln before each season and before any long run.

## Software

The controller runs firmware version v8.17.255. I have not updated it in a long time, and I have no reason to think a newer version is available or needed. The aim here is to keep the current version stable, not to chase upgrades.

What I want to do about software:

- Write down the firmware version on the first page of the settings record so I can check it after any power loss. Some controllers revert settings after a full reset, and I want to know if that happens.
- Record every setting that matters: target temperature, ramp rate, hold time, cooldown behavior, and the low-battery cut-off if the unit has one.
- Take a photo of each settings screen with a phone after any change. Store the photos in the same folder as this note.
- Do not change settings in the middle of a run. Stop the run, change one thing, and note the change.
- If I ever do try a firmware update, do it on a day with a full battery and good sun, with the kiln cold and empty, and keep a record of the settings first because an update may wipe them.

I should also test what the controller does after a power drop. Does it resume, restart, or stay off? This matters for the dropouts described under Problems. A controller that resumes quietly may be worse than one that stays off, because I might not notice.

## History

The controller was installed in 2016 in the yard. It was chosen for the cider area because the kiln is a long way from the house and mains power, so a solar supply made sense. The grey unit was the simplest option at the time.

The early years were uneventful. I used it mostly in autumn for drying fruit and for warming a small batch of equipment before pressing. The solar panel was fitted at the same time and faced roughly south.

Over the years some things changed, though I did not keep dates:

- The battery was replaced at least once.
- A cable entry was resealed after a wet winter.
- I moved the controller a short distance along the wall to get it out of the worst of the rain.
- I adjusted the settings several times, with no record kept.

This lack of history is one of the main reasons for the plan. Going forward, each change goes into a short log with the year, what I did, and why.

## Background

Cider making has a busy season in autumn and a quiet stretch after. The kiln and its controller fit into the busy part. Apples come in over a few weeks, and anything that needs drying or gentle heat has to be done in that window. A failure during that time costs real fruit.

The controller is a kiln controller in the strict sense: it reads a temperature, compares it with a target, and switches the heat on and off to hold that target. The solar energy source means the whole system is small. There is a panel, a battery, a regulator, the controller, and the heating element. Every part has to be in decent shape for the whole thing to work.

The yard location has pros and cons. The pros are space, ventilation, and distance from the house if something goes wrong. The cons are weather exposure and the walk out to check on it. I am not always going to be standing next to it, so the setup should tolerate a bit of neglect.

The grey color is not important functionally, but it matters in one way: grey casings absorb less sun than black ones, which helps a little with overheating inside the box in summer.

## Checklist

Use this before each season and again before any long run.

- Check the weather forecast for the next few days.
- Look at the battery charge. If it is low, wait or charge it before starting.
- Wipe the panel clean and check for shade from new growth or fruit crates.
- Inspect the casing for cracks, condensation, and insects.
- Check the cable entries and seals.
- Confirm the firmware version on screen matches what is in my notes.
- Compare the displayed settings with the written record.
- Sweep the area around the kiln.
- Check that the extinguisher is in place.
- Run a short test cycle and watch that the heat switches on and off.
- Write down the start time and expected end time.
- After the run, log anything odd.

## Setup

The current setup is a simple chain. The solar panel feeds a regulator, the regulator charges the battery, and the battery supplies the controller and the heating side. The controller sits on the yard wall near the kiln in its grey casing.

Things I want to improve in the setup:

- Mount the controller a little higher and add a small drip shield above it.
- Replace the cable entry seals with new ones and use drip loops on all cables.
- Add a basic label on the casing listing the target settings and a short note on what to do if power drops.
- Put a small desiccant pack inside the casing and replace it each season.
- Fit a simple voltage reading near the battery so I can see its state at a glance.
- Tidy the wiring and secure it with new ties so nothing hangs near hot surfaces.

I will do these one at a time and run a test between each change, so that if something goes wrong I know which change caused it.

## Supplies

A rough shopping and gathering list for the work in this plan:

- New cable entry seals or grommets.
- Silicone sealant suitable for outdoor use and moderate heat.
- Cable ties that tolerate sun and heat.
- Small desiccant packs.
- A basic multimeter, if I do not already have a working one.
- A spare fuse of the right type for the system. I will check the existing fuse rating on the unit and note it down, not guess.
- Replacement battery, only if testing shows the current one is weak.
- Soft cloths and mild soap for cleaning the panel and casing.
- Gloves and eye protection.
- A notebook or a folder for the settings record and log.
- A drip shield: a small piece of sheet material cut to size.

I will not buy anything expensive until the tests show what is actually failing.

## Overview

This plan covers the Drurtos kiln controller, a grey kiln controller for the cider area. It is a solar-powered device installed in 2016 and located in the yard.

The goals are:

- Make it reliable on low-sun days.
- Keep water out of the casing.
- Know exactly which settings it is running.
- Set up a light routine so small faults get caught early.

The approach is to test first, then make small fixes, and keep a written record throughout. The firmware stays as it is, with the current version noted. Safety rules apply to every step.

Rough order of work:

- Read through the Safety section and set up the extinguisher spot.
- Record all current settings and photograph the screens.
- Test the battery and panel output.
- Fix weather protection.
- Run a test cycle and log the result.
- Start the maintenance routine.

## Risks

- Fire from heat or fruit residue near the kiln. Mitigated by cleaning, an extinguisher, and never bypassing limits.
- Electric shock from the panel or battery during work. Mitigated by isolating the supply and working in dry conditions.
- Lost settings from a reset or power drop. Mitigated by the written record and photos.
- A failed batch because of a mid-run dropout. Mitigated by checking the battery and forecast before starting.
- Damage from my own changes. Mitigated by changing one thing at a time.
- Water damage if the seals fail again. Mitigated by the seal and drip shield work and a seasonal check.
- Wear on an aging unit. It has been in service since 2016, so a total failure is possible. I should think about what a replacement would be and keep a note of the key requirements: solar-friendly, weather tolerant, and easy to read.
- Wasps or other insects nesting in the casing. Mitigated by closing gaps and inspecting before use.

## Maintenance

A light routine, aimed at being easy enough to actually follow.

Before each season:

- Do the full checklist.
- Clean the panel and casing.
- Replace the desiccant.
- Test battery and regulator.
- Check firmware version against notes.

During the season:

- Glance at the casing and battery state each time I use the kiln.
- Log any dropouts, odd readings, or settings changes.
- Clear leaves and dust from around the controller every few weeks.

After the season:

- Disconnect and store the battery if it is going to sit unused through deep winter, or keep it on a trickle from the panel if that works better.
- Cover or close up the controller.
- Review the log and decide what to fix before next autumn.

Once a year:

- Inspect and reseal cable entries as needed.
- Review the settings record and update photos.
- Think about whether the controller is still worth keeping or if replacement is due.

## Open questions

- How long does the battery actually last on a short winter day with the kiln running?
- Does the controller resume after a power drop, or stay off?
- Does a reset wipe my settings, and if so, which ones?
- Is the panel angle still right after all these years, or has something grown up and shaded it?
- Would a larger battery solve the dropouts, or is the problem the regulator?
- Is it worth moving the controller indoors, in a small shed or box, with only sensor and power leads going out to the kiln?
- Should I set a low-battery cut-off so the kiln shuts down safely rather than dropping out unpredictably?
- When should I plan to replace the whole unit, and what should I look for?
- Is there any maker documentation I can still find, or should I write my own short manual from what I learn?
