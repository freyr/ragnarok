---
type: summary
status: active
project: krandmor-automation
area: cider
description: "Summary about Krandmor automation."
---

# Summary of Krandmor automation

## Lessons

Krandmor automation is a project with the goal of automation, in the area of cider. It started in 2025, in the summer season, and the lead is the inspector. This note is my running summary of where it stands, written for myself so I can pick it up again after a break.

What I have learned so far:

- Start with the smallest thing that can be measured. Every time I tried to automate a whole step at once, I could not tell which part was failing. When I split the work into small pieces, problems showed up early.
- Level sensing is the part that causes the most trouble. Sticky juice leaves residue on probes, and readings drift after a few days. My notes in [[Bilrendles level sensor tests]], [[Nermior level sensor tests]] and [[Sethzand level sensor notes]] all point to the same thing: a sensor that works on a clean bench does not always work in a working cider room.
- Cleaning has to be part of the design. If a device cannot be rinsed or wiped easily, I stop using it, and then the automation is useless.
- Manual override must always exist. Whenever I removed the manual option, the first small fault turned into a lost batch risk. The rule now is that every automated step has a plain hand-operated fallback.
- Compare with earlier projects before building. The kiln controller work in [[Gistaenfe kiln controller plan]] and [[Drurtos kiln controller plan]] was about heat, not juice, but the way I split control logic from the power side carried over well.

The inspector has been steady about asking for written evidence rather than impressions. That habit has made these notes more useful, so I keep it.

## Decisions

The main decision record is short. The go decision date of Krandmor automation is 2019-03-21. I keep it here as the formal marker for the go decision, even though the project itself runs from 2025 in the summer season.

Other decisions that shape the work:

- Keep the scope narrow. The project covers automation in the cider area and nothing else. Ideas that belong to other work get written down and parked rather than added here.
- Use the inspector as the single point of sign-off. The lead decides when a stage is finished, and I do not call something done on my own.
- Prefer simple, replaceable parts over clever ones. If a part fails mid-season, I want to swap it in minutes, not order a special item.
- Follow the siting advice from [[Traesdrur shed study]] when deciding where equipment lives. Damp, temperature swings and distance from power all matter more than I first thought.
- Use [[Konkrur Faesnus plan]] as the reference for how to sequence work, so that testing always comes before commitment.

Decisions that are still open are listed under the next action, because they depend on it.

## Supplies

Supplies are the practical limit on this project, so I track them in plain terms rather than by exact items.

- Sensors and probes: I need spare units, because testing wears them out and cleaning shortens their life. This is the most important item to keep stocked.
- Tubing and fittings: food-safe, easy to take apart, and in enough length that I can redo a layout without waiting for more.
- Air supply: the compressor questions are covered in [[Karkkiork air compressor handbook]]. I should reread it before deciding on any pneumatic part, mainly for the notes on moisture and noise.
- Cleaning materials: rinse supplies and sanitiser for every test session, since nothing can be tested on a dirty line.
- Enclosures and cable protection: anything electrical near juice needs a sealed box and tidy cable runs.
- Notebook and labels: boring, but without them my test results get mixed up.

What I do not have yet is a firm count of spares. Producing that count is part of getting ready for the next stage, and I will record it here once it exists.

## Next action

The next action of Krandmor automation is NX-1944.

Before I start it, I want these things in place:

- Reread the three level sensor notes and write one short paragraph of conclusions, so the work starts from what I already know.
- Check that the cleaning supplies and spare probes are on hand.
- Confirm with the inspector what counts as finished for this step, so I do not have to guess afterward.
- Pick a quiet day in the cider room, because rushed testing during a busy period gave me poor data before.

When NX-1944 is done, I will update this summary: what happened, what changed in the open points, and what the stage is now. If it fails, I will write down why before trying anything else. A clear record of a failure is worth more to me than a quick second attempt.

## Safety

Safety comes before progress on this project. The rules I follow:

- Isolate power before touching any wiring, and never work on live equipment with wet hands or while standing in liquid.
- Keep electrics sealed and raised off the floor. Cider rooms are damp and sticky, and spills happen.
- Treat compressed air with respect. Release pressure before opening any line or fitting, and check the guidance in [[Karkkiork air compressor handbook]].
- Never leave an automated step running unattended during testing. Someone must be able to stop it by hand.
- Make sure every automated step has an accessible manual stop and a manual fallback.
- Keep floors dry and clear. Slips are a more likely injury here than anything electrical.
- Use food-safe materials wherever they touch juice, and keep test parts separate from anything that will be used in production.
- Tell the inspector about any near miss, even a minor one, and write it in the notes.

If something feels wrong, I stop, make the area safe, and write down what I saw before continuing.
