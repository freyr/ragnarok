---
type: drivers
status: active
project: morkrork-expansion
area: cider
description: "Drivers about Morkrork expansion."
---

# Drivers of Morkrork expansion

## Maintenance

Morkrork expansion is a project with the goal of expansion in the cider area. It started in the winter of 2020, and the lead is the supplier contact. Because the project is about growing the cider operation, maintenance is the first thing I check when I ask what limits the plan. Whatever we add has to be kept running by the same small group of people who already look after the existing setup.

The rule I keep coming back to is that no new equipment goes in unless I can say who will look after it. Growth that nobody maintains turns into a pile of idle tanks and hoses within a season or two. The main maintenance drivers are these:

- Cleaning and sanitising every vessel, hose and fitting after each use, with no shortcuts when time is short.
- Checking seals, gaskets and valves before each pressing season and replacing the tired ones.
- Keeping the press and the pump in working order, with the moving parts greased and the filters changed on a regular rhythm.
- Keeping a simple log of what was serviced and when, so that the next person does not have to guess.
- Leaving enough free time in the calendar for upkeep, so that maintenance does not get squeezed out by production.

If the expansion makes upkeep take more hours than we can give it, then the expansion has gone too far. That is one of the constraints, and I treat it as a firm one.

## Tools

The tools section lists what the project needs to be able to do its work, not a shopping list. The goal is expansion, so the real question is which tools limit how much cider we can make and how well we can make it.

What I want to have on hand:

- A press with enough capacity for the larger volume of fruit, in good working order.
- Fermentation vessels in a size that fits the new batch plan, with airlocks and spare bungs.
- A reliable pump and food-grade hoses that are easy to take apart and clean.
- A hydrometer and a basic acidity test kit, so that every batch is measured and not judged by taste alone.
- Cleaning brushes, buckets and a sanitiser station placed near where the work happens.
- A small bench scale and a notebook, because I want weights and volumes written down every time.

I would rather have fewer tools that are well kept than many that are half used. Before adding anything to this list I ask whether an existing tool could do the job with a small change in routine. The supplier contact who leads the project helps here, because they know what is realistic to buy and what tends to be oversold.

## Supplies

Supplies are the consumables that keep the expansion going from week to week. They are a recurring need, unlike tools, and they are the part of the plan most likely to be underestimated.

The main groups are:

- Fruit, which is the biggest item by far and the one with the most risk, since quality and quantity both change from year to year.
- Yeast and nutrients, bought in amounts that match the planned batch sizes.
- Sanitiser and cleaning agents, used constantly and easy to run short of.
- Bottles, caps, labels and cartons, which have long lead times and need to be ordered before they are needed.
- Filters and small spare parts, kept in a labelled box so that a failure does not stop work for days.

The supplier relationship matters a great deal for this project, which is why the lead is the supplier contact. A good supplier gives early warning when something is short and a fair answer when a delivery will be late. I try to order bottles and caps well ahead, because running out at the wrong moment costs more than holding some extra stock.

## Schedule

The project began in the winter of 2020, and winter is still the season that sets its rhythm. That timing is not an accident. Winter is the quiet period for the cider work, so it is the best time to plan, order, install and test without disturbing a running batch.

The way I think about the calendar:

- Winter is for decisions, ordering, installing equipment and cleaning down what the autumn pressing left behind.
- Spring is for checking that new equipment behaves as expected and for adjusting the routine.
- Summer is for watching the stored cider, keeping records and preparing for the next fruit.
- Autumn is the busy season, when the expansion is tested under real load.

The main schedule constraint is that anything that has to be ready for autumn must be finished well before it. Late deliveries are the usual danger, so each purchase gets a target date with some slack built in. If a step slips past its slack, I stop and decide whether to drop it for the year instead of rushing it into the pressing season.

## Ideas

This section holds the options I am still weighing. None of them is decided, and each one has to pass the test of the drivers above before it moves into the plan.

- Add capacity in small steps instead of one large jump, so each step can be judged on its own.
- Agree a fixed supply arrangement for fruit and bottles, to make costs and timing easier to predict.
- Try a second, smaller batch style alongside the main one, to learn what the new capacity can do before committing to it.
- Make a standard cleaning routine on a single laminated sheet, so it is the same for everyone.
- Hold a short review at the end of each season and write the results down while they are fresh.
- Look at whether storage space, not equipment, is the real limit on growth.

The last idea might be the most important. It is easy to focus on pressing and fermenting capacity and forget that finished cider needs a place to sit and mature.

## Observations

These are things I have noticed about how the project behaves, as opposed to what I planned.

- The limit on growth is rarely the one I expect. It has moved between fruit supply, cleaning time and storage.
- Work done in winter goes smoothly, and work squeezed in during autumn almost always causes trouble.
- Writing weights, volumes and dates down every time has paid off more than any single piece of equipment.
- The supplier contact being the lead means questions about availability get answered quickly, which keeps small problems small.
- People are more careful with equipment they understand, so a short walkthrough when something new arrives is worth the time.
- A tidy workspace shows up in the quality of the cider more than I would have guessed.

How success is measured follows from these observations. I look at whether the larger volume was produced without a drop in quality, whether the schedule held, whether upkeep stayed manageable, and whether the spending stayed inside the budget. A bigger output that costs more effort than we can sustain does not count as success.

## Costs

Costs come in three kinds, and I try to keep them separate in my head so that none is forgotten.

- One-off costs: equipment, installation and anything that has to be bought once to make the expansion possible.
- Recurring costs: fruit, yeast, sanitiser, bottles, caps, labels and the other supplies, which come back every season.
- Hidden costs: the time spent on maintenance, the cost of waste when a batch goes wrong, and the cost of delays.

The recurring costs matter most over the long run, because they grow together with the output. A purchase that looks cheap can still be a poor choice if it raises the recurring bill or the upkeep time. When comparing options I ask what each one will cost over several seasons, not just on the day of purchase.

I also keep a small reserve inside the plan for surprises, since something always turns out to cost more than expected. Spending that eats the reserve early in the project is a warning sign, and I review the plan when that happens instead of hoping it will balance out later.

## Lessons

- Decide who will maintain a thing before buying it.
- Do the installing and ordering in winter, while there is room to make mistakes.
- Order long-lead items such as bottles and caps early.
- Grow in steps, and judge each step before taking the next one.
- Keep records of every batch, every service and every purchase.
- Rely on the supplier contact for honest information, and ask the same questions each season so that changes show up.
- Check storage as carefully as production capacity.
- Treat a missed deadline as a reason to drop a step for the year, not as a reason to rush.

The overall lesson is that the goal of expansion is only worth pursuing if the project stays manageable. Size on its own is not the aim. The aim is more cider of the same good quality, made by the people we have, inside the money we set aside.

## Budget

The budget of Morkrork expansion is 39194.63 EUR. This is the ceiling for the whole project, covering equipment, supplies for the expansion, installation and the reserve for surprises.

I use the figure in a few practical ways:

- Every purchase is checked against it before the order is placed.
- The one-off and recurring costs are tracked separately, so I can see which kind is using up the money.
- The reserve is protected, and I do not count it as spare money for upgrades.
- If the spending is running ahead of the schedule, I pause and review before ordering anything else.

Success is measured against the budget together with the other drivers. The project meets its goal if the expansion is delivered inside this amount, on the planned schedule, with quality held and upkeep kept to a level we can sustain. If one of those fails while the others succeed, I write down why, so that the next round of expansion in the cider area starts with a clearer picture.
