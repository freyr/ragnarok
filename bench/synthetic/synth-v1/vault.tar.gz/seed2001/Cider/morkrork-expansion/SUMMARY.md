---
type: summary
status: active
project: morkrork-expansion
area: cider
description: "Summary about Morkrork expansion."
---

# Summary of Morkrork expansion

## Background

Morkrork expansion is a project with the goal of expansion, in the cider area. It started in the winter of 2020, so it has been running for a good while. The lead is the supplier contact, which makes sense because most of the work depends on what the supplier can deliver and when.

This note is the summary of where the project stands. It is meant to be read quickly when I come back to it after some time away, so I keep it short and practical.

Current stage: the project is past the planning phase and in the execution phase. The go decision has been made, and the work now is about following through on the supplier side.

What is done so far:

- The scope of the expansion was agreed and written down.
- The supplier contact was confirmed as the lead for the project.
- The go decision was taken and recorded.
- The first round of talks about delivery was finished.

## Decisions

The go decision for Morkrork expansion was made on 2026-04-28. After that date, the scope stopped being open for discussion and the focus moved to delivery.

Decisions that still stand:

- The project stays in the cider area and keeps the goal of expansion.
- The supplier contact remains the lead, and questions about delivery go through them.
- Changes to the scope need a new decision, written down here, before anyone acts on them.

Open points:

- The delivery timing is not yet fixed with the supplier.
- It is not clear how the expansion fits with the work already planned for the cider area.
- Some of the handover details between me and the supplier contact are still loose and need to be written down.

I do not want to reopen the go decision. If an open point turns out to be a real problem, I will note it here as a new decision instead of changing the old one.

## Next action

The next action for Morkrork expansion is NX-6668. It is the step that should settle the delivery timing, which is the most important open point right now.

Once that is done, I will:

- Update this summary with the result.
- Write down the handover details agreed with the supplier contact.
- Check whether the remaining open points are still open.

Until NX-6668 is finished, I will not start anything new on this project.
