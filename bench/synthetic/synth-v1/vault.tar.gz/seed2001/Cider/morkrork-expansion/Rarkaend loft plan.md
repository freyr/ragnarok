---
type: plan
status: active
project: morkrork-expansion
area: cider
description: "Plan about Rarkaend loft."
---

# Rarkaend loft plan

## Overview

Rarkaend loft is a loft in the cider area. It is a medium-sized space, built in 1999, with a raised floor, and its orientation is north. This note is my working plan for getting the loft ready for regular use: what to check first, when to do each job, and what to measure so I can compare later.

Quick facts, so I do not have to look them up again:

- Kind: loft
- Area: cider
- Orientation: north
- Size: medium
- Year built: 1999
- Floor: raised

The north orientation means the loft gets little direct sun. It stays cool and the air can feel damp, so humidity is the main thing I want to track. The raised floor helps keep the boards off the ground below, but it also means I have to watch for gaps and soft spots near the edges.

I plan to reuse the approach from earlier notes. The sensor work in [[Sethzand level sensor notes 2022]] and [[Nermior level sensor tests]] gives me a starting point for the monitoring gear. For any heating or drying equipment I will lean on [[Gistaenfe kiln controller plan]], since the control logic there is close to what I need here.

## Safety

The loft was built in 1999, so I treat the wiring and fixtures as older and not to be trusted until I have looked at them.

- Check the floor before carrying anything heavy. A raised floor can flex, and I want to find weak boards before they find me.
- Use a stable ladder or stairs with a handrail. Never carry a load up with both hands full.
- Keep a torch near the entrance. The north side is dim, and the light switch is not always easy to reach.
- Do not leave any heater or drying device running unattended. If I use a controller, I follow the cut-off rules written in [[Gistaenfe kiln controller plan]].
- Wear a dust mask when moving old stored items. Damp air can mean mould, and I do not want to breathe it in.
- Keep the hatch or door clear. I need a free path out at all times.
- Work with someone else in the house when possible, or at least tell them I am up there.

If I find any sign of water getting in, I stop the plan and deal with that first. Nothing else matters until the roof and walls are dry.

## Schedule

I keep the schedule loose, because weather decides a lot of it. The order matters more than the exact day.

1. First visit: walk the whole loft, look at the floor, the roof edges and the corners on the north side. Take notes and photos.
2. Second visit: clear the floor and sweep. Move items off the walls so air can move behind them.
3. Third visit: place the sensors and start logging. I will follow the placement ideas from [[Sethzand level sensor notes 2022]] and compare with results in [[Nermior level sensor tests]].
4. One week later: read the log, look for patterns between day and night, and decide whether the loft needs drying or just ventilation.
5. After that: repeat the check once a month and write short results in this note or a linked one.

For comparison runs I will also look at [[Siogliork Giola tests]] and [[Riothkren Niordio tests]], which show how I judged similar readings before. Older background is in [[Naesnirra Piondgirk notes 2019]].

A small log setup I use for the sensor check:

```
# loft-check.conf
location = rarkaend-loft
interval_minutes = 30
log_file = loft-log.txt
metrics = humidity, temperature
alert_if_humidity_above = 60
```

The alert value is just a rough limit for me. I will adjust it after the first week of data.

## Measurements

This section holds the readings I take on site. I record them in the same way each time, at the same height above the raised floor and away from the door, so the numbers can be compared.

- Measured humidity of Rarkaend loft: 38.74 %

That reading is lower than I expected for a north-facing loft, which tells me the space is drier than I feared. I still want more readings at different times of day before I decide anything, because a single value can be misleading.

What I plan to record each time:

- Humidity at the centre of the loft
- Humidity near the north wall
- Temperature at the same two points
- Condition of the floor boards near the edges
- Any smell, stain or visible damp

If the humidity stays near the first reading, I will keep ventilation as it is and skip any drying equipment. If it climbs, I will go back to the controller notes and set up a simple on and off cycle. Either way, I will write the outcome down here so the next review starts with real data and not memory.
