---
type: plan
status: active
project: morkrork-expansion
area: cider
description: "Plan about Gistaenfe kiln controller."
---

# Gistaenfe kiln controller plan

## Risks

The Gistaenfe kiln controller is a black kiln controller that sits in the loft and serves the cider area. It was installed in 2021 and runs on battery power. That last point is the main thing to watch, because the loft is not a place I visit every day.

- A flat battery mid-run could stop the controller while the kiln is still hot, which would spoil the batch being dried.
- Cold nights in the loft shorten battery life, so I should expect less runtime in winter.
- The unit has been in place since 2021, so connectors and the case may have worn or collected dust.
- If the reading drifts and I do not notice, the kiln could run too hot or too cool without any warning.
- The loft is out of the way, so a fault could go unseen for hours.

To keep these risks small, I will check the battery before every run and keep a spare charged set near the ladder. I will also write down the displayed temperature against a separate thermometer at the start of each season, so drift shows up early.

## Adjustment

The plan is to correct the reading once, then confirm it over a few runs instead of changing settings repeatedly.

The calibration offset of Gistaenfe kiln controller is 2.114 mm. I will enter that value and leave it alone unless the checks show a clear change.

Steps for the adjustment:

- Fit a fresh battery before starting, so low power does not affect the reading.
- Let the loft settle to its normal temperature before touching anything.
- Enter the calibration offset of 2.114 mm and save it.
- Run a short test cycle and compare the controller against the separate thermometer.
- Note the result in this plan, then repeat the comparison on the next two runs.

If the three comparisons agree, I will treat the adjustment as finished and go back to the seasonal check. If they disagree, I will stop using the controller for real batches until I find the cause. A worn connector or a weak battery is the first thing I will rule out, since both are cheap to replace and both are listed above as likely problems.
