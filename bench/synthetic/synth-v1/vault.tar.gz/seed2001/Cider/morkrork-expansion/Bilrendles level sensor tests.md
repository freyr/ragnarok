---
type: research
status: active
project: morkrork-expansion
area: cider
---

# Bilrendles level sensor tests

## Setup

The Bilrendles level sensor is a level sensor used in the cider area. It is red, runs on solar power, and was installed in 2021. Its location is the pond, where it watches the water level that feeds the cider pressing yard. I keep these notes for my own use, so the tests below are written the way I actually ran them, not as a formal procedure.

The sensor sits on a short post at the edge of the pond. The small solar panel faces south and is clear of the reeds, which I trim back each spring. The probe hangs down into the water on its own cable. I tied the cable to the post so wind does not swing the probe around and give false readings.

For the tests I used a simple routine:

- Check the panel is clean and facing the sun.
- Read the level on the sensor display and write it down.
- Compare it against a marked stick pushed into the pond bed.
- Repeat at three different times of day.

I did the comparison over several days so that I could see how the sensor behaved in bright weather and under cloud. The goal was to learn whether I can trust the sensor during the busy weeks of the cider season, when I cannot walk down to the pond every hour.

## Safety

The pond edge is muddy and slippery, especially after rain. I wear boots with a good grip and I do not lean out over the water to reach the probe. If the probe needs pulling out, I use a hooked pole from the bank.

Even though the sensor runs on solar power, it is still an electrical device standing next to water. I never open the casing with wet hands or in the rain. Before touching any wiring I cover the panel with a cloth so it stops producing current, and I only then disconnect the cable.

Other points I keep in mind:

- Never work at the pond alone at dusk; tell someone at the house first.
- Keep tools and the measuring stick out of the walkway so nobody trips.
- Wash hands after handling the cable, since the pond water is not clean.
- Keep children and dogs away from the post while the casing is open.

## Supplies

Everything fits in one plastic crate that I keep in the cider shed. The crate stays dry, and I can carry it down to the pond in one trip.

- Marked wooden stick for checking the real water level
- Notebook and a pencil (pens fail in damp air)
- Soft cloth and a small brush for cleaning the panel
- Hooked pole for pulling the probe in
- Cable ties and a roll of waterproof tape
- A plug-in power meter, used on the bench rather than at the pond
- Spare cloth for covering the panel
- Phone, for photos of the display

I also keep a short list of things I should buy before next season, mainly spare cable ties and a second hooked pole, because the first one is getting worn.

## Observations

The red casing has held up well since 2021. The paint is faded on the side facing the sun, but there are no cracks, and no water has got inside. The cable is the part showing the most age; the outer cover is stiff and slightly rough near the post, so I wrapped that stretch in tape.

The display stayed readable in daylight. On cloudy mornings it was a little slow to update, which I think is the solar supply working at a low level. By midday it caught up and agreed with my stick.

Over the test days I noticed the following:

- Readings matched the marked stick closely when the water was calm.
- After wind, the display jumped around for a few minutes before settling.
- Leaves and algae on the probe made the level read slightly high until I cleaned it.
- The panel collected dust and pollen, and cleaning it made a visible difference on dull days.
- A heron standing near the post once triggered a short odd reading, which cleared by itself.

My overall impression is that the sensor is dependable if I keep the panel and probe clean. The weak points are the cable and the effect of surface movement on the water. A cheap stilling tube around the probe might calm the wind effect, and I want to try that next.

## Measurements

I summarised the checks below. Level differences are in whole centimetres against the marked stick, and the conditions are what I noted at the time.

| Check | Conditions | Difference from stick |
|---|---|---|
| Morning | Cloudy, calm water | 1 cm |
| Midday | Sunny, calm water | 0 cm |
| Afternoon | Windy | 3 cm |
| Evening | Dry, light breeze | 1 cm |
| After cleaning probe | Sunny, calm water | 0 cm |

On the bench, with the plug-in power meter, the measured power draw of Bilrendles level sensor was 507.19 W. That figure is far higher than I expected for a small solar sensor, so I plan to repeat the bench check with a different meter before I rely on it for any sizing of the panel or battery.

The level readings are the more useful result for now. Calm water gives agreement within a centimetre, and wind is the main source of error. Next steps are to add the stilling tube, replace the worn cable section, and repeat the table in autumn when the light is weaker.
