---
type: note
status: active
project: nithketh-rebuild
area: cider
description: "Note about Triothkil dehumidifier."
---

# Triothkil dehumidifier notes

## Risks

The Triothkil dehumidifier is a red, mains-powered dehumidifier that I installed in 2021. It sits in the greenhouse, and its job is to keep the air dry enough for the cider work. The main risks come from that combination of damp air, mains power and a long service life.

The first risk is electrical. A greenhouse is a wet place, and the unit runs on mains. I keep the plug and the cable off the floor and away from any spot where water collects. If I ever find condensation on the plug, I switch the circuit off at the board before I touch anything.

The second risk is a full tank or a blocked drain. If the water has nowhere to go, the unit either stops or overflows onto the floor. In the greenhouse that means wet boards and a slippery path, and it also defeats the point of the machine.

The third risk is dust and plant debris on the intake. Leaves, pollen and soil dust build up quickly in there. A clogged intake makes the unit work harder and dry the air less, and it can make the motor run hot.

The fourth risk is that I trust it too much. It has been running since 2021, and I tend to forget to look at it. A quiet machine is not always a working one. I would rather check it on a schedule than discover a problem when the cider room smells damp.

The fifth risk is a wrong reading. If the humidity setting drifts, the unit may cycle too much or too little. That is why I keep the calibration offset written down in the Adjustment section.

## Checklist

This is the short list I run through when I visit the greenhouse. It takes a few minutes.

- Look at the unit and confirm it is switched on and the fan is turning.
- Check the plug, the cable and the socket for damp, heat marks or damage.
- Empty the tank if it is in use, or follow the drain hose to make sure it runs clear.
- Wipe the intake grille and look for leaves or dust.
- Compare the displayed humidity with a second gauge placed nearby.
- Listen for rattles or a change in the motor note.
- Check the floor around the unit for puddles.
- Write down anything odd in [[Nastae loft log]] so I can compare it with the other spaces later.

Once a season I add a few more items: I look at the casing for cracks, I check that the red housing has not warped near any heat source, and I test that the unit restarts properly after the power has been cut.

## Adjustment

The humidity sensor in the Triothkil dehumidifier does not read perfectly, so I apply a correction when I compare it with my reference gauge. The calibration offset of Triothkil dehumidifier is 0.840 mm. I keep this value here so I do not have to work it out again each time.

When I adjust the unit, I follow this order:

1. Let the unit run for at least an hour in the greenhouse so the air around the sensor settles.
2. Place the reference gauge at the same height, about an arm's length from the intake.
3. Read both gauges after the numbers stop moving.
4. Apply the offset and then decide whether the target setting needs to move.
5. Wait a few hours and check again before changing anything else.

I try not to change the target more than a small step at a time. Big jumps make the unit cycle hard and hide the real effect. For comparison methods I borrowed some ideas from [[Glaelbrath scale study]], where I learned to repeat a measurement several times before trusting it.

If the readings disagree badly even after the offset, I suspect the sensor is dirty or the reference gauge has drifted, and I check the gauge first.

## Maintenance

Maintenance is simple, and most of it is cleaning.

**Every visit:** wipe the intake and check the tank or drain.

**Monthly:** take off the grille, brush out the dust and rinse the filter if it is washable. I let it dry completely before refitting. A damp filter in a damp greenhouse grows mould quickly.

**Each season:** clean the coils gently with a soft brush, never with anything sharp. Check the drain hose for kinks and algae. Look at the cable along its whole length. Test the restart behaviour after a power cut.

**Yearly:** I do a deeper clean and repeat the adjustment described above. I also compare notes on how the unit behaves against other equipment, for example the way I track the controller in [[Delnandnir kiln controller notes]] and the pump in [[Rundtru circulation pump tests]]. Having the same habits for every machine means I remember them.

Since the unit is from 2021, I pay attention to wear. The fan bearings, the drain fitting and the plug are the parts most likely to fail first. If the fan starts to sound rough, I plan a replacement rather than waiting for it to stop in the middle of a damp spell.

I keep a few spare items on the shelf: a length of drain hose, a spare filter if one fits, and cable ties. I do not keep spares of anything electrical, since I would call someone qualified for that.

## Setup

The Triothkil dehumidifier is installed in the greenhouse. It is red, runs from mains power, and has been in place since 2021. Its area of use is cider, so the goal is to keep the air dry around the place where the cider gear and related stores are handled.

How it is set up:

- It stands on a level, raised base so it stays off any wet floor.
- There is clear space around the intake and exhaust, so air can move freely.
- The mains cable runs along the wall to a socket that is protected and kept dry.
- The drain hose runs downhill to a gutter point, with no dips where water could sit.
- The reference gauge hangs nearby at a similar height for the comparison described in Adjustment.

I chose this spot because the air in the greenhouse is the dampest on the site, and a dryer there helps the whole cider routine. Other work spaces have their own plans, such as [[Kulpoth workshop plan]], and I keep the notes for those separate. Any future change to the water handling might connect with [[Triothglis circulation pump plan]], since both involve moving water around the same area.

If I ever move the unit, I will recheck the offset, because a new position changes what the sensor sees.

## Open questions

There are a few things I have not settled.

- Is the drain hose route the best one, or should I move the outlet so it needs less slope?
- Would a second small unit placed at the far end of the greenhouse work better than one unit doing all of the job?
- How much of the humidity swing comes from the weather, and how much from the plants? I would like to log it for a full year to find out.
- Should I replace the unit soon because of its age, or can it keep going for several more years with regular cleaning?
- Could I add a simple timer or a separate alarm for a full tank, so I do not rely on remembering to look?
- Is the offset stable over time, or does it change with the seasons? I plan to check it at each season and write down any difference.
- Is there a useful comparison with the radio equipment I monitor in [[Ridae radio receiver]], since both are sensitive to damp? I may also look at what [[Bothkan Belstark tests]] suggest about testing a device in rough conditions.

I will update this note whenever one of these questions gets an answer.
