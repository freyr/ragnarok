---
type: summary
status: active
project: nithketh-rebuild
area: cider
---

# Summary of Nithketh rebuild

## Costs

This is the summary of the Nithketh rebuild, a project in the cider area. The goal is rebuild, the start year is 2019, the season is winter, and the lead is the supplier contact. I keep the cost picture in words here, because the actual figures live in the ledger and I do not want two versions of them.

The rebuild has three cost groups. The first is the big equipment: the pump set, the drying equipment for the store room, and the replacement of worn fittings. The second is consumables and small parts, which keep creeping up because each visit to the workshop turns up one more worn part. The third is my own time, which I do not price but do track, because winter is the only season when the cider room can be taken out of use without losing a pressing.

What I have learned about costs so far:

- The supplier contact quotes honestly, but quotes cover only what is listed. Anything found after opening up a unit is extra.
- Buying fittings in one batch is cheaper than buying them as they fail.
- Delays cost more than parts. Every week the room sits idle in winter eats into the slack I have before spring work starts.
- Test runs cost almost nothing and have saved me from expensive mistakes, so I keep paying for them in time.

I should reconcile the ledger against the notes before the next order goes out.

## Lessons

The project began in 2019, and a lot of what I know comes from the early notes in [[Naesnirra Piondgirk notes 2019]]. Those notes are rough, but they record what the room was like before I touched it, and that is the baseline I keep returning to.

Main lessons so far:

1. **Write down the starting state.** Without the 2019 notes I would be arguing with myself about what was original and what I changed.
2. **Rebuild in winter only.** The season for this project is winter, and it fits. Cold slows fermentation activity, so the room is quiet and I can work without harming a batch.
3. **Test each part alone before joining it to the rest.** The pump tests showed this clearly. A part that looked fine on the bench behaved differently once it was joined to the full loop.
4. **Keep one person as the point of contact.** The lead is the supplier contact, and having one voice for orders and answers has removed a lot of confusion. When I used to phone different people I got different answers.
5. **Do not trust a quick fix.** Several things I patched in the early years came back as problems later.
6. **Read the handbook before improvising.** [[Valgios workshop handbook]] already covers most of what I rediscovered the hard way.

## Supplies

Supplies for the rebuild fall into a few simple groups. I keep this list short on purpose and check it against the shelf before each work session.

- **Pump and circulation parts.** The circulation loop is the heart of the rebuild. The parts for it are tied to the findings in [[Rundtru circulation pump tests]].
- **Humidity control.** The drying equipment for the room is planned in [[Riothdrer dehumidifier plan]]. I have the plan but I should confirm what is physically on hand.
- **Fittings, seals and clamps.** These are the small things that run out first. I keep a spare set of each kind.
- **Cleaning and sanitising materials.** Needed after every opening of the system, and at the end before the room goes back into use.
- **Protective gear.** Gloves, eye protection and boots, kept where I can reach them without searching.
- **Labels and a marker.** Boring, but I label every disconnected line so I can reassemble in the right order.

The supplier contact handles the larger orders. For the small stuff I buy locally. When a delivery arrives I check it against the order the same day, because the supplier is much more helpful about mistakes reported immediately.

The weak point is storage. Parts that sit in the cold room can pick up damp, so I keep them in sealed boxes inside the house until needed.

## Decisions

The go decision date of the Nithketh rebuild is 2025-07-20. That is the day I committed to doing the rebuild rather than continuing to patch the old setup. Before that date I was undecided, and the notes from that stretch show me going back and forth.

What fed into the go decision:

- The repeated repairs were costing more over time than a proper rebuild would.
- The tests gave me enough confidence that the main design would work.
- The supplier contact confirmed that the key parts could be supplied in time for winter work.
- The handbook and the older notes showed the work was within what I can do myself.

Other decisions that followed from it:

- **Lead.** The supplier contact leads the project on the supply side, and I do the hands-on work and keep the notes.
- **Season.** All the disruptive work is scheduled for winter.
- **Scope.** I will rebuild the circulation and humidity control first and leave cosmetic work until later.
- **Order of work.** Test, replace, retest. I do not replace two major things at once.
- **Records.** The running log is [[Daeltor Losvind log]], and decisions that matter get a line there as well as here.

Decisions I have deliberately not made yet are listed under open questions.

## References

These are the notes and documents this project relies on. I keep them linked so I can find them quickly.

- [[Naesnirra Piondgirk notes 2019]]: the baseline notes from the start year, 2019. They describe the old state of the room and the first problems.
- [[Valgios workshop handbook]]: general practice for the workshop, including safe procedures and how to open and close the system.
- [[Daeltor Losvind log]]: the day-by-day log of work, with what I did and what I saw.
- [[Riothkren Niordio tests]]: the test notes that backed up the go decision and still guide what I check.
- [[Rundtru circulation pump tests]]: results on the circulation pump, which determine which pump parts to buy.
- [[Riothdrer dehumidifier plan]]: the plan for humidity control in the store room.
- [[Selroth Tithstioth]]: a background note I come back to when I need context on the supplier side and how work with them is arranged.

If I add a new reference, it goes in this list and also gets a mention in the log so the trail is not lost.

## Risks

The main risks, in rough order of how much they worry me:

1. **Timing.** Winter is the work window. If parts arrive late, the work runs into the season when the room is needed again.
2. **Hidden wear.** Opening up old equipment tends to reveal more damage than expected. This is the biggest threat to both cost and schedule.
3. **Single point of contact.** The supplier contact is the lead. That is good for clarity, but if they are away or unavailable, orders stall.
4. **Damp and cold.** The room is cold and humid, and the rebuilt parts must tolerate it. A mistake in the humidity plan would cost me later.
5. **Mixing up lines.** Reassembling the circulation loop wrongly could cause leaks or poor flow. Labels and photos are my protection.
6. **Contamination.** A rebuild opens the system, and anything not cleaned properly could affect the next batch.
7. **Fatigue.** Long days in the cold lead to sloppy work. I plan shorter sessions.

For each risk I try to have a simple answer: order early, inspect before committing, keep a spare, label everything, clean twice, and stop when tired.

## Next action

The next action of Nithketh rebuild is NX-4789.

That is the item I pick up first when I next sit down with the project. Before starting it, I will reread the latest entries in [[Daeltor Losvind log]] so I begin from where I actually stopped, not from where I remember stopping. I will also check the supplies shelf against the list above so that I do not start something I cannot finish for lack of a small part.

When it is done, I will write the result in the log, update this summary if the stage has changed, and choose the following action straight away so the project never sits without a next step.

## Observations

Some things I have noticed while working on the project and reading back through the notes:

- The room behaves differently from the plan on cold mornings. Condensation shows up on surfaces I had assumed would stay dry.
- The circulation loop is noisier than it should be, which usually means air in the line or a part under strain.
- Work goes faster when I prepare the evening before: tools out, parts laid in order, the log open.
- The supplier contact answers quickly when I give a precise question and slowly when I give a vague one.
- The old notes from 2019 are more useful than I expected, partly because they include the small complaints I would otherwise have forgotten.
- Parts that were replaced early in the project are holding up better than the ones I left for later.
- The tests in [[Riothkren Niordio tests]] predicted most of what I later saw on the real system, which is reassuring about how I test.

I write these down because they feed back into decisions. An observation that appears three times in the log becomes a lesson or a task.

## Schedule

The schedule follows the seasons. The project started in 2019, the go decision was made on 2025-07-20, and the main disruptive work belongs in winter, which is the project's season.

The rough order of work is:

1. **Preparation.** Check the supplies, reread the log, confirm deliveries with the supplier contact.
2. **Opening and inspection.** Take the system apart in stages and record the condition of each part.
3. **Replacement.** Fit the new circulation parts, guided by the pump tests.
4. **Humidity work.** Install the drying equipment according to the dehumidifier plan.
5. **Retest.** Run the system and compare with the earlier test notes.
6. **Clean and close.** Sanitise everything, close up, and put the room back into service.
7. **Review.** Write the final lessons and update this note.

I do not put exact dates on the later steps because they depend on deliveries and on weather. What matters is that steps two to six finish before the room is needed again. If they cannot, I stop at a safe point, such as after a retest, and resume the next winter.

## Open questions

Things I have not settled:

- Is the existing pipework good enough to keep, or should it also be replaced? I will not know until the inspection is complete.
- Which of the humidity control options in the plan is best for this room in practice, not just on paper?
- Should the circulation pump be fitted with a backup, or is a spare on the shelf enough?
- How much should I rely on the supplier contact for later maintenance advice, and how much should I handle on my own?
- Does the background in [[Selroth Tithstioth]] change how I should arrange future orders?
- What is the right place for a permanent record of settings once the rebuild is finished: the log, the handbook, or a new note?
- Do I want to expand the rebuild to cover the parts I have left out of scope, or leave them alone?

I will answer these as the inspection and tests produce evidence, and move each answer into the decisions section when it is settled.

## Problems

Current and recurring problems:

- **Damp in the room.** The main reason for the dehumidifier plan. Until it is installed, moisture remains a nuisance and a threat to stored parts.
- **Weak circulation.** The old loop does not move liquid as evenly as it should. The pump tests point to wear rather than design.
- **Worn fittings.** Several fittings leak slightly or no longer seal well. These are cheap but fiddly.
- **Unclear old records.** Some of the earlier history is missing, so I cannot always tell when a part was last replaced.
- **Cold working conditions.** It slows me down and makes small tasks harder, especially anything needing fine control of the hands.
- **Waiting on deliveries.** Sometimes the only thing between me and progress is a missing part.

Each problem has an entry in the log. When one is fixed, I mark it there and remove it from this list at the next summary update.

## Ideas

Ideas I want to keep but not act on yet:

- Put a simple sheet by the door listing the checks to make on entering the room each day.
- Add a marked diagram of the circulation loop on the wall, so labels and layout are visible at a glance.
- Keep a small kit of the most common spare parts in a labelled box for quick repairs.
- Write a short checklist for closing down the system at the end of the season, drawing on the handbook.
- Ask the supplier contact whether bundled orders could be arranged for the next winter.
- Combine the test notes into one page so the main findings are in one place.
- Take photos at each stage of disassembly and link them from the log.
- Try a longer monitoring period of the room's dampness before and after the humidity work, to see whether the plan really helps.

None of these is urgent. They are for when the main work is done and I have time to tidy up.

## Safety

Safety rules I follow on this project:

- Isolate and drain the system before opening any line. Never assume it is empty.
- Switch off and lock out the power to the pump before touching it. I tag the switch so nobody turns it on by mistake.
- Wear gloves and eye protection when handling cleaning agents and when cutting or clamping.
- Keep the floor dry. Wet floors, cold, and heavy parts are a bad mix. I use mats and clean spills straight away.
- Ventilate the room while sanitising, and never mix cleaning products.
- Lift heavy parts with help or with a trolley, not by myself.
- Keep a first aid kit and a phone within reach whenever I work alone.
- Stop when tired or cold. Mistakes made at the end of a long day are the ones that cause injuries.

The general practices in [[Valgios workshop handbook]] apply throughout, and where this note and the handbook differ, I follow the more cautious of the two.

## Maintenance

Once the rebuild is complete, the room needs a steady routine so it does not fall back into the old state.

- **Routine checks.** Look over the circulation loop, the fittings and the pump on a regular basis, and listen for noise that was not there before.
- **Humidity.** Check how the drying equipment is performing and empty or service it as the plan describes.
- **Cleaning.** Sanitise after every opening of the system and clean the room itself at the end of each season.
- **Spares.** Keep the spare set of fittings, seals and clamps topped up, and replace anything used.
- **Records.** After each maintenance job, add a line to [[Daeltor Losvind log]] with what was done and what was seen.
- **Seasonal review.** At the end of each winter, reread this summary, the test notes and the log, and decide whether any part needs attention before the next season.
- **Supplier contact.** Keep in touch with the lead on supply matters so that replacement parts are still available when I need them.

The aim is that no one, including me a year from now, has to guess what state the equipment is in. If the routine is followed, the next rebuild should be a small job rather than another project.
