---
type: drivers
status: active
project: nithketh-rebuild
area: cider
description: "Drivers about Nithketh rebuild."
---

# Drivers of Nithketh rebuild

## Risks

The Nithketh rebuild is a cider project that started in winter 2019. The goal is a rebuild, and the lead is the supplier contact. The risks below are the ones I watch most closely, because each of them can push the project off its goal or its budget.

- **Supplier dependency.** The lead is the supplier contact, so most of the parts and advice come through one person. If that person is unavailable, work stalls. I keep a short list of what is waiting on them.
- **Winter timing.** The project is tied to the winter season. Cold slows fermentation-side work, makes cleaning harder, and delays anything that needs a warm, dry room. A slip of a few weeks can cost a whole season.
- **Moisture in the work area.** Damp air damages electronics and wooden parts. The [[Riothdrer dehumidifier plan]] is my main answer to this, and I treat it as a dependency, not an extra.
- **Sensor trust.** If the level readings are wrong, I could overfill or run a tank too low. The results in [[Nermior level sensor tests]] tell me how far I can trust them.
- **Actuator failure.** A valve that sticks or fails to close fully could waste cider. The [[Zamathra valve actuator handbook]] covers the limits I should respect.
- **Scope growth.** A rebuild invites "while we are at it" changes. Each one adds cost and time, and I try to write it down as an idea instead of doing it right away.

## History

The project began in winter 2019. The earlier setup in the cider area had grown by small additions over several years, and nobody could say with confidence how it all fitted together. That was the main reason to choose a rebuild instead of another round of patches.

In the first season I mostly took stock. I listed what existed, what still worked and what had to go. The supplier contact was involved from the start and has stayed as lead, which is why the supplier relationship shows up in so many of these notes.

Since then the work has moved in stages. Radio and monitoring gear was looked at early, which is why the receiver notes exist: [[Ridae radio receiver]], [[Girdael radio receiver]] and [[Triorkgend radio receiver plan]]. These record which options I compared and which I dropped. Day-to-day events are kept in the [[Saethland Bolvulkork log]], so I do not repeat them here.

A person worth remembering in this history is [[Staga Virork]], whose input shaped some of the early decisions. I keep a separate note for that rather than putting the details in this one.

## Costs

Costs fall into a few groups. I do not list individual prices here, only how I think about them.

- **Parts and materials.** The largest group. It covers actuators, sensors, wiring, fittings and anything the supplier has to order in.
- **Monitoring and radio gear.** Receivers and related items. Compared with the main hardware this is small, but it grows quietly if I let it.
- **Environment control.** Dehumidifying and keeping the room dry, following the [[Riothdrer dehumidifier plan]].
- **Time.** My own time is not charged against the budget, but it limits how much I can do in one winter, so I count it as a cost in planning.
- **Rework.** Anything I have to redo because a part was wrong or a test was skipped. This is the cost I most want to keep low.

When a cost is not clear, I assume it will be higher than expected and place it under open questions until the supplier confirms.

## Problems

These are problems I have actually met or expect to meet again.

1. Lead times from the supplier are uneven. Some items arrive quickly and others take much longer, which makes sequencing hard.
2. Early sensor readings were noisy. I have to separate real changes in level from noise, and the notes in [[Nermior level sensor tests]] are where I record that.
3. Radio reception in the cider area is patchy, since thick walls and metal tanks block the signal. This is why more than one receiver was considered.
4. Damp conditions in winter affect connectors and cases.
5. Older parts do not always match newer ones, so adapters or small modifications are sometimes needed.

For each problem I try to write down the cause, what I tried and what happened. The log in [[Saethland Bolvulkork log]] holds the detail.

## Budget

The budget of Nithketh rebuild is 6955.92 EUR.

This figure is the ceiling for the whole project, not a target to reach. I treat it as covering parts, monitoring gear, environment control and a small reserve for rework. Anything outside those groups needs a decision before I spend on it.

Rules I follow with the budget:

- Spending is checked against the ceiling at the end of each month of active work.
- A change that would use a large share of the remaining money is paused until I have thought about it overnight.
- The reserve is only for fixing mistakes or for supplier changes, not for new features.
- If the ceiling looks likely to be exceeded, I cut scope before I ask for more money.

## Open questions

- Which receiver option is the best final choice? The comparison among [[Ridae radio receiver]], [[Girdael radio receiver]] and the plan in [[Triorkgend radio receiver plan]] is not settled.
- Can the supplier contact commit to firm delivery windows, or only estimates?
- Is the dehumidifier plan enough for the whole winter, or will it need a second unit?
- How much of the existing equipment can be kept without lowering reliability?
- What is the right way to test the valve actuators under real load before the cider season starts? The [[Zamathra valve actuator handbook]] gives limits but not a full test method.
- Who takes over if the supplier contact cannot continue as lead?

## References

- [[Zamathra valve actuator handbook]]: limits and handling of the valve actuators.
- [[Nermior level sensor tests]]: results and notes on the level sensors.
- [[Ridae radio receiver]]: one of the receiver options.
- [[Girdael radio receiver]]: another receiver option.
- [[Triorkgend radio receiver plan]]: the plan for the receiver setup.
- [[Riothdrer dehumidifier plan]]: how I plan to keep the work area dry.
- [[Staga Virork]]: a person whose input mattered to early decisions.
- [[Saethland Bolvulkork log]]: the running log of work and events.

## Checklist

- [ ] Confirm the goal is still a rebuild and not a partial repair.
- [ ] Confirm the supplier contact is still the lead and can be reached.
- [ ] Check spending against the budget ceiling.
- [ ] Review the risk list at the start of winter.
- [ ] Re-read the actuator handbook before installing any valve.
- [ ] Run the level sensor checks again after any wiring change.
- [ ] Decide on the final radio receiver.
- [ ] Set up the dehumidifier before moving in sensitive parts.
- [ ] Update the log after each work session.
- [ ] Move new ideas to the ideas list instead of starting them.

## Overview

The Nithketh rebuild is a project in the cider area. Its goal is a rebuild of the existing setup. It started in 2019 and is tied to the winter season. The lead is the supplier contact.

This note covers the drivers: why the project exists, what limits it, how much money is available and how I decide whether it worked.

**Goal.** Replace a patchwork setup with one I understand and can maintain. The result should be reliable, documented and easy to check.

**Constraints.**

- The budget ceiling, given in the Budget section.
- The winter season, which sets when work can happen.
- Dependence on the supplier contact for parts and advice.
- Damp, cold conditions in the work area.

**How success is measured.** I count the project as a success if these hold:

- The rebuilt setup runs through a full season without a major fault.
- Spending stays inside the ceiling.
- Level readings and valve behavior match what I expect from my tests.
- I can explain every part of the setup from my notes alone.
- Another person could follow the notes to maintain it.

## Lessons

- Starting with a full inventory in the first winter saved a lot of confusion later.
- A single supplier lead is convenient but fragile. I should keep a second contact.
- Testing sensors before relying on them is cheaper than fixing a wrong reading afterward.
- Radio reception has to be tested in place. Bench results do not carry over to the cider area.
- Writing the reason for each decision in the log has helped more than I expected, because I forget the reasons faster than the decisions.
- Keeping a firm line between the plan and new ideas has protected both the budget and the schedule.

## Ideas

- Add a second monitoring point so one failed sensor does not leave me blind.
- Prepare a one-page start-up guide for each winter, based on the checklist.
- Keep a small stock of spare connectors and fittings that tend to fail in damp conditions.
- Ask the supplier contact whether a standing order for common parts would shorten lead times.
- Write a short maintenance schedule once the rebuild is finished, and link it from this note.
- Review the receiver comparison once more after a full season of real use.
