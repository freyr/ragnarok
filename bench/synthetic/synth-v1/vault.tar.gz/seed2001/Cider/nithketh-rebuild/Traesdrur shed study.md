---
type: research
status: active
project: nithketh-rebuild
area: cider
description: "Research about Traesdrur shed."
---

# Traesdrur shed study

## Supplies

The Traesdrur shed is a small shed in the cider area, built in 1992. It sits below ground and its door faces east. Because it is small and underground, I plan supplies carefully, since every trip down the steps costs time and every item has to fit on the shelves without crowding the floor.

What I keep stocked for the shed, grouped by what it is for:

- Cleaning: a stiff brush, a bucket with a lid, rags that can be thrown away, and a mild soap that leaves no scent. Scent matters in a cider shed, because anything strong ends up in the fruit and the barrels.
- Damp control: a few bags of moisture absorber, spare silica for the small tool box, and a roll of plastic sheet for covering things when water comes through the wall.
- Light: spare bulbs, a head torch, and fresh batteries kept in a sealed tin so they do not corrode in the damp air.
- Sealing and repair: wood glue, a tube of sealant for masonry, cloth tape, string, and a handful of screws and nails in jars with the size written on the lid.
- Cider work: clean cloth for straining, bottle caps, spare bungs, airlocks, and sanitising powder. I keep the powder on the highest shelf, away from any drip.
- Safety: a first aid kit, a pair of gloves, a dust mask, and a small fire blanket near the steps.

Notes on buying and storing:

- Buy small amounts of things that spoil in damp air. Paper, cardboard and cloth all go soft below ground.
- Anything in a box goes into a plastic tub with a lid. Cardboard stays upstairs.
- Keep a short written list on the inside of the door of what is running low. I update it each visit, and it saves me a wasted trip.
- Heavy items stay on the lowest shelf, and liquids stay lower than powders so a leak cannot spoil the dry goods.

The east-facing door means the morning sun reaches the top of the steps but never the floor. This helps a little with temperature, as the room stays cool through the summer, but it does nothing for the damp. I plan for the damp as a permanent condition, not a problem that gets solved once.

## Tools

The tools I keep in the Traesdrur shed are chosen for a small space. Long tools are awkward to turn around in a room this size, so I prefer short handles and tools that fold or nest.

Core tools:

- A hand brush and a long-handled scrubbing brush for the floor and the lower walls.
- A small hand saw, a hammer, two screwdrivers, and a pair of pliers.
- A tape measure and a spirit level, used when I fit new shelves or brackets.
- A trowel and a short spade, for the drain at the foot of the steps.
- A wet and dry vacuum for clearing water from the floor. This is the most useful thing I own for a below-ground room.
- A hand pump for moving water out through the drain when the vacuum is too slow.

Cider tools:

- A fruit press, small enough to be carried down in pieces and set up near the wall.
- A mallet for the press and for the bungs.
- A hydrometer and a tall jar to test with.
- A funnel, a length of food-safe tubing, and a bottle filler.
- A small scale for weighing additives.

Tool care:

- Wipe metal tools dry after every visit and rub a thin coat of oil on cutting edges.
- Hang tools on the wall where possible. The floor is the wettest place in the shed.
- Keep wooden handles away from the wall that sweats most. I learned this when a handle swelled and split.
- Store the vacuum with its hose open, so it dries out and does not grow mould.

Because the shed was built in 1992, some of the fittings are old, and a few of the fixings in the walls are not standard sizes. I keep a small set of odd screws and wall plugs for that reason. A magnetic strip near the door holds the small metal tools so I can find them by touch when the light is poor.

## Checklist

This is the list I run through on a normal visit to the Traesdrur shed. It is short enough to remember, but I keep it written down because I skip steps when I am in a hurry.

On arrival:

- Check the steps and the door for wet or slippery patches before going down.
- Open the door fully and let the air move for a few minutes before entering. A below-ground room can hold stale air.
- Switch on the light and look at the floor first. Standing water is the first thing to deal with.
- Look at the walls for new damp marks, white salt deposits, or any crack that has grown.

Inside the shed:

- Clear any water with the vacuum and check the drain at the foot of the steps.
- Check the moisture absorbers and replace any that are full.
- Look at the shelves for anything that has gone soft, rusty or mouldy, and remove it.
- Check airlocks and bungs on anything fermenting, and note the level of the liquid.
- Take a hydrometer reading when a batch is due, and write it in the log.
- Test the bulbs and torch, and replace anything weak.
- Check the stock list on the door and add whatever is low.

Before leaving:

- Wipe and put away the tools, and hang them rather than leaving them on the floor.
- Cover anything that could be dripped on with the plastic sheet.
- Make sure the lids are on all tubs and the sanitising powder is sealed.
- Leave the door slightly open for a short while if the day is dry, then close and latch it.
- Write the date and a short note in the log: what I did, what I saw, what I need next time.

Seasonal additions:

- In autumn, clear leaves from the top of the steps and check the drain before the heavy rain begins. This is also the busiest period for the cider work, so I bring down extra cloth and sanitiser.
- In winter, check for frost near the door and make sure nothing liquid is near the entrance.
- In spring, look for new damp after the thaw and rain, and clean the walls with the brush.
- In summer, air the room more often, since warm air meeting the cool walls leaves moisture on every surface.

## Lessons

These are the lessons I have gathered from using the Traesdrur shed. They come from mistakes more often than from planning, and I write them down so I do not repeat them.

- Small is a strength and a limit. The shed is small, so everything has a place, and I notice quickly when something is missing. But a single spill or a single crate left out makes the room hard to move through.
- Below ground means damp, always. Nothing I do will remove it. The aim is to keep water off the floor, keep the air moving, and keep valuable things up high and in lidded tubs.
- Do not store paper or cardboard here. I lost a stack of labels and a box of notes before I accepted this. Now the log lives in a sealed plastic folder, and spare labels stay in the house.
- Check the drain first. Most of my bad days in the shed started with a blocked drain after heavy rain. Clearing it takes a few minutes, and ignoring it can cost a week of cleaning.
- The cool temperature is useful. The shed stays steady through the year, which suits slow fermenting and keeping finished bottles. I still use a thermometer, because the room is not as even as it feels.
- The east-facing door gives morning light at the top of the steps, which makes the entrance pleasant to work in at the start of a day. It does not reach the floor, so I rely on good lamps and keep spare bulbs.
- An older building needs patience. Built in 1992, the shed has some small faults, such as a hairline crack near the corner and a door that sticks after wet weather. I fix small things early, because below ground they get worse faster.
- Write things down. The log tells me when damp appeared, how long a batch has been fermenting, and which fix worked. My memory is a poor substitute.
- Keep the routine short. If a visit feels like a chore, I skip it. A short, steady checklist works better than a long one that I avoid.
- Keep a clear path. I leave enough room from the door to the press to carry a full container without turning sideways. This matters most on the steps, which are the most dangerous part of the shed.

The main thing I take from all this is that the shed rewards regular, small attention. A few minutes each visit keeps it dry, tidy and useful, and a long absence usually costs me more time than I saved by staying away.

## Schedule

This is the plan I keep for visiting the Traesdrur shed. It is a small shed built in 1992, and the floor sits below ground, so every visit takes more planning than a normal shed would. The door faces east, which decides the time of day I go.

- Morning visits are best. The east orientation means the first sun reaches the doorway, and the steps are dry and easy to read.
- Afternoon visits are for checking damp only. By then the doorway is in shade and the lower step stays cold and wet longer.
- Early in the pressing season I go more often, because the cider area around the shed gets busy and the traffic changes the drainage on the path.
- In the quiet months I go once every few weeks, mainly to look at the floor and the walls.
- After heavy rain I go the next dry morning, never during the rain.

Order of work on each visit:

1. Walk the outside first. Look at the roof edge, the gutter, the ground near the door and the path from the cider area.
2. Open the door and wait a short while before going down. The air below ground can be stale, and I want it to move.
3. Check the steps, then the floor, then the walls, then the corners.
4. Do the one task I came for. Keep it short.
5. Close up, note the condition of the door and the latch, and write the visit down the same day.

I do not try to combine a shed visit with other jobs in the cider area. When I did that early on, I rushed the check below ground and missed a wet patch until the next visit. One job per trip is a rule I now keep.

## References

These are the sources I use when I think about the shed. None of them is a formal publication. They are my own working papers and the things I have learned from looking.

- My own visit notebook, where each trip to the shed gets a short entry on weather, floor condition and anything changed.
- The sketch plan I drew of the shed, showing the door on the east side, the steps down, and the small footprint of the room.
- Photographs taken from the doorway looking in, kept in a single folder and always taken from the same spot so I can compare them.
- A folder of my notes on the cider area as a whole, including how the ground slopes toward and away from the shed.
- Remarks from neighbours who remember the shed from the years after it was built in 1992. Their memories are useful but uneven, so I treat them as leads and not as facts.
- General guidance I have read on working in below-ground rooms: ventilation, damp, lighting and safe access. I took what applied to a small shed and left the rest.

What I know for certain about the shed is short. It is a shed. It belongs to the cider area. It faces east. It is small. It was built in 1992. Its floor is below ground. Everything else in these notes is observation or inference built on those six points, and I try to mark which is which.

Gaps in my sources:

- I have no original building papers, so I do not know the construction method behind the below-ground floor.
- I have no record of repairs, only what I can see.
- I do not know whether the drainage was designed or simply grew as the ground settled.

## Observations

The below-ground floor is the main thing that shapes how the shed behaves. Because the room is small and sunk into the ground, it holds a steady, cool temperature. In the warm months it is a relief to step in. In the cold months it is less harsh than the open air, though it is never really warm.

Door and light:

- The door faces east, so morning light falls down the steps and lights part of the floor. After that the room is dim.
- The doorway is the only real source of daylight, so I always bring a lamp.
- Because the room is small, one lamp is enough to see the whole floor, but the corners stay in shadow.

Damp and air:

- The walls show the usual signs of a below-ground room. The lower part is darker than the upper part, and there is a faint line where moisture rises and stops.
- The smell changes with the weather. After rain it is earthy and sharp, and in dry spells it is nearly neutral.
- The air feels still when I first open the door. I give it time to move before I go down.
- Any wooden item left on the floor picks up damp quickly. I keep things raised on a shelf or a block whenever possible.

Floor and steps:

- The floor is the most important surface to watch. It stays cool and slightly clammy, and after a wet period a thin film of water can appear near the foot of the steps.
- The lowest step is the slipperiest. It gets algae when the door stays shut for a long time.
- Because the shed is small, there is little room to put things down, so I have learned to bring only what I need.

Surroundings:

- The cider area around the shed changes with the season. In the pressing months the ground near the shed gets churned, and runoff from the working area can reach the doorway.
- In quieter months the path dries and firms up, and the doorway stays cleaner.
- The east-facing door takes the morning sun but also catches wind from that side on some days, so leaves and debris collect at the top of the steps.

What I think is happening: the shed was built in 1992 as a small, simple store, and its below-ground floor gives it a stable temperature but also makes damp the constant problem. Almost everything I do there is about managing that one fact. I do not think the damp is getting worse, but I cannot prove it, because my early notes were too vague to compare with.

Things I want to check next:

- Whether the wet patch at the foot of the steps always appears in the same place.
- Whether a change in how I clear the doorway makes any difference to the floor.
- Whether the darker band on the walls moves up or down over a season.

## Safety

The Traesdrur shed is small, but the below-ground floor makes it a place that needs care. Most of the risks are ordinary ones, made worse by the fact that there is only one way in and out.

- **Steps.** Treat the steps as the main hazard. They are damp, they can grow algae, and the lowest one is the worst. Go down facing the steps and keep a hand free for support. Do not carry loads that block your view of your feet.
- **Light.** Never go down without a lamp, even in the morning. The east door gives light early in the day, but it is not dependable, and the corners stay dark. Check the lamp before going down, not at the bottom.
- **Air.** A sunken room can hold stale air. Open the door and wait before entering. If the air smells strange, feels heavy, or makes me dizzy or short of breath, I go back up at once and do not return that day.
- **One exit.** Because the shed has a single door, I tell someone when I am going in, especially in the cider season when the area is busy. I do not stay long, and I do not work there alone when I am tired.
- **Water.** After heavy rain, water can collect near the foot of the steps. I do not go down when there is standing water, because I cannot judge the depth or the footing.
- **Cold and damp.** The room stays cool all year. I wear shoes with a firm grip and keep my hands dry, since cold, wet hands make it harder to hold the rail or the lamp.
- **Storage.** The room is small, so stored items crowd the floor. I keep the path from the steps to the wall clear, and I do not stack things where they could fall.
- **Doorway.** Keep the top of the steps clear of leaves and debris. A wet leaf on the top step is an easy way to fall.

My own rules, in short: go in the morning, bring light, let the air move, tell someone, stay brief, and skip the visit if the steps or floor are wet beyond what I can manage. The shed is not dangerous if I follow these, but it punishes hurry.

## Open questions

These are the things I still cannot answer about the Traesdrur shed after looking at it several times. I keep them as a list so I can tick them off one by one.

- Why was a small shed in the cider area built below ground in 1992? The floor sits under the level of the yard, and I have found no written reason. My guess is temperature, since a cellar-like space stays cool in warm months, but I have not confirmed it.
- Was the east orientation chosen on purpose? The door faces east, so the morning light reaches the steps first. I would like to know whether that was meant to keep the afternoon sun off the entrance or whether it was simply how the slope lay.
- How does water behave in the shed after a long spell of rain? A below-ground floor is the obvious weak point. I have seen damp marks on the lower wall, but I have not stood inside during a real downpour.
- Is the ventilation enough? The shed is small, and I am not sure the air changes often enough to keep mould down when it is closed up for weeks.
- Who built it? People nearby remember it being there, but nobody I asked could name the builder or say what it was first used for.
- Has the floor ever been raised, drained or relaid since 1992? The surface looks older in some places than in others, which makes me think something was done to it.

Until I have answers, I treat every statement about the shed's history as a guess rather than a fact.

## Costs

I am not putting exact prices here, because I have no reliable figures and I do not want to invent any. What I can do is list the kinds of cost I expect, and roughly how heavy each one is.

- **Drainage work.** This is likely the biggest item. A small shed with a floor below ground needs water to go somewhere. A channel along the lower wall, or a small sump, would be the first thing to price.
- **Damp proofing.** The walls and the floor would need a coating or a membrane. It is cheap compared with drainage, but the labour is slow because the space is cramped.
- **Ventilation.** One or two vents on the east wall would be a modest cost. A small fan would add a little more, plus a power supply.
- **Lighting and wiring.** The shed is small, so only a short run of cable is needed. Anything electrical in a damp place must be done properly, so I would pay a qualified person rather than do it myself.
- **Shelving and racks.** Because the shed is in the cider area, I picture racks for barrels and crates. Wood that stands up to damp costs more than ordinary timber.
- **Time.** My own time is the cost I tend to forget. Every visit means carrying tools down the steps, and the space is tight enough that even simple jobs take twice as long.

My plan is to ask for a few quotes for the drainage first. The rest depends on what the drainage turns out to need, so I will not commit to the other items before then.

## Overview

This section collects the main properties of the shed in one place, so I do not have to hunt for them later.

- **Name:** Traesdrur shed
- **Kind:** shed
- **Area:** cider
- **Orientation:** east
- **Size:** small
- **Year built:** 1992
- **Floor:** below ground

In plain words, the Traesdrur shed is a small shed in the cider area. It was built in 1992, its entrance faces east, and its floor lies below ground. Those few facts shape almost everything else I have written about it.

Being small means storage is limited and every item has to earn its place. Being below ground means it stays cooler and steadier in temperature than a building standing in the open, but it also means damp is a constant risk. The east orientation gives morning light at the door and keeps the strongest afternoon sun away from the entrance, though I have not measured this.

Taken together, the shed suits slow, cool storage better than any work that needs space, warmth or dry air. That is the idea I keep returning to when I decide what belongs inside.

## Background

The shed dates from 1992, which makes it an older building by the standard of the other things in the cider area. I do not know the full story of how it came to be there. What I have is a mix of what I can see for myself and what people have told me, and I try to keep the two apart.

What I can see is simple. The shed is small. The floor is below ground, so you step down to enter. The door faces east. The structure has weathered, and the lower wall shows the marks I mentioned under the open questions.

What I have heard is vaguer. Some people say the shed was put in to keep things cool, which fits the below-ground floor and the cider area around it. Others say it was a place to keep tools out of the weather. Neither story has anything written behind it, so I treat both as possibilities only.

Since 1992 the surroundings seem to have changed more than the shed itself. The ground outside has probably built up over the years, and that may be part of why water now has a way in. This is also only a guess.

My reason for studying the shed is practical. I want to know whether it is worth keeping and repairing as a storage space, and what it would take to make it reliable. For that I need to understand three things: how the below-ground floor handles water, how the east-facing entrance affects the air and light inside, and how small the space really is when it is filled. Every later note on this place will build on those three points, so I keep returning to them as I gather more evidence.

## Ideas

The Traesdrur shed is a small shed, built in 1992, with its floor below ground and its door facing east. The cider area is where it sits, and most of my ideas come from those few facts together. A small space that is cool and partly buried suits slow work, so I keep coming back to uses that need steady temperature and little light.

- Use the shed as a proper cool store for the cider, rather than just a place where crates end up. The below-ground floor should keep it steadier than anything above ground nearby.
- Try a simple log of conditions over a full year. A cheap thermometer and a damp gauge on the wall, read on the same days each week, would show how the place behaves in each season.
- Build a low rack system so that nothing sits directly on the floor. Given where the floor is, this matters more than any other change.
- Keep a small shelf near the door for tools, a lamp, and a notebook, so the study notes can be written on the spot instead of from memory.
- Test whether the east orientation helps. Morning light reaches the door first, so the entrance may warm earlier than the rest of the cider area. That might make the first hour of the day the best time to open the door and let the air move.

I also want to treat the small size as a feature. A small shed is easy to keep tidy, easy to check in one visit, and quick to air out. The downside is that anything I add takes up a large share of the space, so every idea needs to be measured against how much floor and wall it uses.

One idea I am less sure about is turning part of the shed into a tasting corner. It would be pleasant, but a below-ground room that small would feel cramped with more than a person or two inside. I will leave it as a maybe until the basic storage question is settled.

Another idea is to compare this shed with other sheds in the cider area, if I can get access. The point would not be to rank them, only to see whether being below ground makes a visible difference in how stock keeps. Without a comparison, I only have my own impressions, and those are easy to bend.

## Risks

The main risks follow from the floor being below ground. Water is the first one. Any room set under the level of the surrounding earth can collect moisture, either from rain that runs toward it or from damp rising through the floor and walls. In a shed built in 1992, I should assume the original sealing has aged, and that small cracks or worn joints may exist that I have not yet looked for.

The second risk is air. A small, buried room with one door facing east has limited ways for air to move. If the door stays closed for long stretches, stale air and mold smells can build up. That would not only be unpleasant but could affect anything stored there, particularly anything that takes up odors, such as wood, cloth, or paper labels.

The third risk is access and safety:

- Steps or a slope down into a below-ground floor can get slick when wet. I should check the surface at the entrance before anything heavy is carried in.
- A small space means little room to turn around with a full crate. Lifting in a cramped spot is how backs get hurt.
- Light is likely poor. Working in dim light, on a damp floor, with glass or heavy containers, is a combination I want to avoid.
- If the door sticks or swells in wet weather, getting out could become awkward. I should confirm it opens from the inside without effort.

There is also a risk in the study itself. I could draw conclusions from too little observation. One damp week or one dry week says very little. The notes only become useful if I keep recording over a long period and do not trust a single visit.

A smaller risk is simple neglect. Because the shed is small and out of the way, it is easy to forget until something goes wrong. I would rather schedule short, regular checks than rely on remembering.

Finally, there is the risk of over-fixing. If I start sealing, painting, or adding vents without understanding what the shed does on its own, I might make the damp worse by trapping it. Changes should be done one at a time, with a note of what was changed and when, so I can tell which one helped.

## Setup

This section records how I plan to carry out the study and what the shed looks like to work in.

The subject is the Traesdrur shed, a shed in the cider area. It is small, it faces east, it was built in 1992, and its floor is below ground. These are the baseline facts, and every observation I make should be read against them.

My working setup is simple:

- A notebook kept in the shed, or just outside the door, for dated entries. Each entry gets the time of day, the weather, and a short description of the air and walls.
- One thermometer and one damp gauge, placed away from the door and away from the floor, at about chest height, so that they show the general state of the room and not a draft.
- A torch and a lamp, since the light inside is limited.
- A plain tape measure, used once, to record the real inside dimensions so that the word small has something concrete behind it in my own notes.
- A few sheets of paper or card that I can lay on the floor and walls for a day to see whether moisture shows up.

For the routine, I plan to visit on the same days each week, at the same time, and to open the door first and let the air settle for a few minutes before reading anything. I will write down what I smell as well as what the gauges say, because smell is often the earliest sign of trouble in a buried room.

I will also keep a short list of what is stored inside, with where each item sits. That way, if something is affected by damp, I can see whether position on the shelf or near the floor made a difference.

The east-facing door matters for the setup. Morning light and morning warmth arrive there first, so I will do my main checks early, then a second check later in the day on a few visits, to see how much the room changes between the two.

Everything gets written in plain language. I am not producing a report for anyone else, only a record that I can reread in a year and understand without having to guess what I meant.

## History

The history of the Traesdrur shed begins in 1992, the year it was built. I do not have a detailed account of who built it or why they chose a below-ground floor, and I do not want to invent one. What I can say is that the choice fits the purpose a shed in the cider area would likely serve: a cool, sheltered place away from heat and direct sun.

Since then, the shed has stood for a long time. A building from 1992 has gone through many seasons of weather, and each one will have left some mark, even if small. A below-ground floor in particular tends to show its age through the walls and the lowest part of the room, so those are the places I will look at first.

What I know about its past is therefore limited to a few points:

- It was built in 1992.
- It has always been a shed, not a converted room, as far as I can tell.
- It sits in the cider area and faces east.
- It remains small, with no sign that it was ever enlarged.

The gaps in this history are part of the reason for the study. Anything I can learn from the building itself, such as old repairs, patched areas, changes in the paint or the surface of the floor, can fill in the story. I plan to look for these and note them down when I find them, since they may show where water or wear has been a problem before.

If I can ask someone who knew the cider area in earlier years, I will. A short conversation might tell me whether the shed ever flooded, whether it was always used for the same purpose, or whether the door was ever replaced. Until then, I will treat the history as unfinished and keep this section open for additions.

For now, the most reliable record is the one I am about to start making. Years from now, the entries I write this season will become part of the shed's history too, and I want them to be accurate enough to be useful to whoever reads them, including me.

## Measurements

These are my working notes on what I could measure in the Traesdrur shed, and what I could only judge by eye. The shed is a small building in the cider area. It was built in 1992, it faces east, and its floor is below ground. I keep those facts at the top of the section because they explain almost every reading I took.

### Properties of the place

- Kind: shed
- Area: cider
- Orientation: east
- Size: small
- Year built: 1992
- Floor: below ground

### The humidity reading

The measured humidity of Traesdrur shed: 47.56 %

I took this reading with a small handheld meter that I left standing on the middle shelf for a good while before I wrote the figure down. I did not trust the first number the meter showed, because it drifts for a few minutes after it comes in from outside. The figure above is the settled value. For a below-ground room in the cider area, I expected something damper. A reading in the middle of the range is a pleasant surprise, and it fits the way the shed feels when I walk in: cool, a little earthy, but not clammy.

I want to be honest about what this single figure means. It is one reading, taken once, on one visit. It tells me how the air was at that moment. It does not tell me how the shed behaves across a whole season. I treat it as a baseline to compare against, not as a verdict.

### Why the floor matters

The floor is below ground, and that is the main thing that shapes the air in the shed. Soil around a buried room holds a steady temperature and gives off moisture slowly. That is good for keeping things cool. It is bad for anything made of paper, untreated iron or loose cardboard. When I stood at the bottom of the steps, the cold came up from the floor, not down from the roof. I noticed it first in my ankles.

Because the room sits low, air does not move much. There is no draught across the floor, and the stale air sits in the corners. The humidity meter reads the same spot I put it in, so I checked a second place near the back wall by holding the meter there for a while. The back wall felt a little cooler and slightly damper to my hand, but I did not record a second figure, so I will not pretend I did. What I can say is that the reading above came from the middle shelf and nowhere else.

### Orientation and light

The shed faces east. In practice this means the door and the small opening near it catch the morning sun and nothing after midday. Since the floor is below ground, the sun only reaches the top few steps and the threshold. The inside stays dim all day. I checked at different times and the pattern held: bright at the doorway early, shade everywhere else.

East facing is a good choice for a cider-area shed. The morning light dries the entrance and the steps, which would otherwise stay slick. The afternoon is spent in shade, so the room does not heat up. I would not expect a big swing in temperature between day and night, and the walls bear that out. They feel the same temperature whenever I touch them.

### Size and how it limits the measurements

The shed is small, and that changes how I measure it. In a large room, humidity can differ a lot from one end to the other. In a small one, the air mixes more easily, so a single reading is more representative than it would be in a barn. This is the reason I am comfortable with one settled figure for a baseline. Even so, a small room reacts quickly to what I do in it. If I stand inside for a long time and breathe, the number climbs. If I leave the door open, it falls. So I try to keep my visits short while the meter is running, and I step out and let it sit.

I did not take exact floor dimensions. I walked the room by pacing it and by reaching out with my arms, and neither method gives a figure I would put in a note. The word "small" is the value I record, and I leave it at that. If I ever need real dimensions for shelving or for a dehumidifier, I will measure with a tape and add them in a separate note.

### Age and construction

The shed dates from 1992. That is old enough for the building to have settled and young enough that the structure has not fallen apart. I looked for the usual signs of a buried room that is struggling: flaking paint, white salt deposits on the masonry, a sour smell, dark patches near the base of the wall. I saw a little surface dust and some faint marks low down, but nothing that looked like active water coming in. That matches the reading, which does not point to a wet room.

Age also matters for the door and frame. They are the parts most likely to let in damp air, and they have been through many seasons. The door closes properly. There is a thin gap at the bottom, which probably helps the room breathe a little. I would leave the gap alone for now, because sealing a below-ground room tightly can trap moisture.

### What I checked and how

Here is the routine I followed, written so I can repeat it on a later visit and get comparable results:

- Bring the meter in from outside and let it sit in the shed before reading it.
- Place it on the middle shelf, away from walls and away from the door.
- Keep the door closed as far as possible during the wait.
- Stay out of the room while the meter settles, so my breath does not skew the number.
- Write down the value only after it stops moving.
- Note the weather outside in plain words, such as dry, damp or drizzly, since the shed shares air with the outdoors.
- Record anything I notice by touch or smell, even if it seems minor.

I keep the list short on purpose. A routine I can remember is a routine I will follow, and a long one gets skipped.

### What the reading suggests

Taken together, the facts hang together reasonably well. A small shed with a below-ground floor, facing east, built in 1992, in the cider area, holds a humidity of 47.56 %. That is moderate. It is not dry enough to worry about cracking wood or brittle seals, and it is not damp enough to start mould on stored goods. For the things I might keep here, such as jars, tools with some oil on them, and sealed crates, that is comfortable.

I would be more careful with anything porous. Paper labels, sacks and cardboard are the first things to pick up moisture in a buried room, and a moderate reading can still be too high for them over a long time. If I store any of those, I will keep them off the floor and away from the back wall, which felt coolest to my hand.

### Limits and caveats

A few honest limits on all of this:

- I have one humidity reading and no record of how it changes across the year.
- I did not measure temperature with an instrument, only by feel.
- I did not take dimensions, so "small" is the only size I can give.
- The meter is a cheap handheld one, and I have no way to check its accuracy against a better device. I treat the number as good enough for comparison, not as a precise truth.
- My routine reduces error but does not remove it. Weather outside the shed can shift the result on a different day.

### Next measurements

When I come back, I want to repeat the same routine at a different time of year and compare the result with the figure above. If the number stays near where it is now, I can say the shed is stable. If it climbs, I will look at the door gap, the back wall and the base of the steps first, in that order. I also want to take a second reading near the back wall and write it down properly this time, so that I can say whether the damp corner I felt is real or just an impression.

Until then, the baseline stands: a small, east-facing, below-ground shed in the cider area, built in 1992, with a measured humidity of 47.56 %.
