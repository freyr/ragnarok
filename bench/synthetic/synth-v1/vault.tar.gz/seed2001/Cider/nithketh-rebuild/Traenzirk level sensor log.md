---
type: log
status: active
project: nithketh-rebuild
area: cider
---

# Traenzirk level sensor log

## Setup

The Traenzirk level sensor is a level sensor that I use in the cider area of my notes. It is green, runs on a battery, and has been installed in the cellar since 2023. This log collects what I have seen from it, what I did to it, and what I still don't know.

The sensor sits in the cellar, close to the vessel it watches. The cellar is cool and damp, and it smells of apples for most of the autumn. I mounted the sensor on a bracket so it hangs a little above the highest liquid mark I expect. I keep it away from the wall because condensation collects there and runs down in thin lines.

The basic setup, as I did it:

- Pick a spot on the vessel that stays reachable with the cellar light on.
- Fix the bracket first and hang the sensor second, so I am never holding both.
- Insert the battery last, once the sensor is in position.
- Watch the first readings for a while before I trust them.
- Write the date and the first reading in this log.

I chose the battery as the energy source on purpose. There is no good socket near the vessel, and I did not want a cable lying across a wet floor. The cost of that choice is that I have to remember the battery. I handle that in the maintenance section and in the checklist.

The sensor's green casing makes it easy to find among the grey and brown shapes in the cellar. That sounds minor, but it has saved me time more than once when I came down in poor light.

## Tools

I keep a small set of tools for this device in a tray by the cellar door. I don't need much.

- A small screwdriver for the bracket and the battery cover.
- A soft cloth, kept dry, for wiping the casing.
- A second cloth, slightly damp, for wiping the bracket and the area around it.
- A torch, because the cellar light throws shadows exactly where I need to look.
- A notebook and pencil. A pen smudges when my hands are damp.
- A clean jug and a measuring container for checking readings against a real volume.
- A stopwatch, which is my phone in a plastic bag.
- A spare battery of the right type, stored in the tray.

For the air side of the work, when I move liquid with pressure, I follow my own notes in [[Karkkiork air compressor handbook]]. I do not repeat that material here. The point is that the sensor sees the level change while the compressor is running, and I need to know what the compressor is doing when I read a strange value.

I do not use any tool that needs power at the vessel. Everything on the tray works by hand, and that keeps the cellar tidy and safe.

One habit I picked up: I put every tool back in the tray after each visit. When I skip this, the screwdriver ends up behind a crate and I lose twenty minutes.

## Open questions

These are things I have not settled. I add to the list whenever something puzzles me and strike items off when I find out.

- How much does the cold in the cellar shorten the battery life compared with what I would get in a warm room? I have a feeling it is noticeable, but I have not measured it properly.
- Does condensation on the sensor face change the reading? Sometimes the value drifts after a damp night, and then recovers by midday.
- Is the sensor affected by foam during active fermentation? Foam might be read as liquid, which would make the level look higher than it is.
- Should I move the sensor a little further from the vessel wall? The current position works, but I wonder if a different angle would reduce odd readings.
- How long will the casing stay in good condition in this humidity? It is still fine after the years it has spent in the cellar.
- Would a second sensor on another vessel behave the same way, or is every cellar spot a little different?

I will not answer these by guessing. Each one needs a short test, and I will note the result in the observations section when I have it.

## References

This is a short list of where I look for background on this device and its surroundings. All of it is my own material.

- [[Karkkiork air compressor handbook]]: my notes on the compressor I use for moving liquid, including how to run it calmly and what the pressure does to levels.
- My cider area notes: the general account of how I work in the cellar, the order of tasks, and the vessels I use.
- The paper leaflet that came with the sensor. It is brief and mostly covers the battery cover and the mounting. I keep it in the tray.
- This log itself. When I want to know what happened last season, I read the history and the observations here before anything else.

I do not trust memory for the details of past seasons. If I did not write it down, I treat it as unknown. That is the reason this log exists at all.

## Safety

The cellar is not a dangerous place, but a few things deserve respect.

- The floor gets wet. I wear shoes with grip and I do not hurry on the steps.
- Fermentation gives off gas. I open the door and let air move before I spend a long time near the vessels. If I feel dizzy or my head aches, I leave and come back later.
- The compressor holds pressure. I never open fittings while the system is under pressure, and I follow my notes in [[Karkkiork air compressor handbook]] before I touch anything on that side.
- The battery should be treated carefully. I do not leave a spent battery in the sensor for months, I do not mix old and new, and I do not drop it in the general waste.
- The bracket must carry the sensor's weight. I check it by hand before I walk away from a new mounting.
- I keep the torch charged. Working near vessels in the dark is how people knock things over.

I also keep the tray off the floor, on a shelf, so nothing gets wet and nothing is stepped on.

## Problems

Here are the problems I have actually had with the sensor, described in plain terms.

**Drifting readings after damp nights.** The value would creep in one direction while the real level stayed the same. Wiping the casing with the dry cloth and letting it sit helped. I now wipe it at the start of each visit.

**Low battery behaviour.** When the battery got weak, the sensor did not stop outright. It gave readings that jumped around. The first time, I thought the sensor was faulty and spent an evening checking the bracket. A fresh battery fixed it at once. Now I treat unstable readings as a battery question first.

**Foam confusion.** In the busiest days of fermentation, the foam seemed to push the apparent level up. I compared the sensor with a look through the top of the vessel and the two did not agree. I do not yet know the exact cause, which is why it is in the open questions.

**Loose bracket.** Once the bracket loosened a little and the sensor tilted. The readings were off by a steady amount until I noticed. Since then I check the bracket by hand at every visit.

**Forgotten log entries.** Not a device problem, but a real one. A few weeks have no notes, so I cannot say what happened. I fixed this with the checklist below.

## Background

I keep cider as a hobby, in a cellar that has stayed cool in every season. The cider area of my notes covers the whole process, from pressing to bottling, and the level sensor is one small part of it.

The reason for a level sensor is simple. In a cellar I cannot always look into the vessel, and during active fermentation I do not want to open it more than necessary. Opening lets in air and unwanted organisms, and it also lets out the gas that protects the liquid. A sensor lets me know the level without disturbing the contents.

I installed the Traenzirk level sensor in 2023. It is a level sensor, green in color, powered by a battery, and it lives in the cellar. Those are the facts I come back to when I forget what I have. Before this I used a marked stick and a torch, which worked but needed the lid off every time.

My first season with the sensor was mostly about learning to read it. I compared it with the stick often, and I learned where it was reliable and where it was not. By the second season I trusted it for ordinary checks and still used my own eyes for anything that mattered.

I do not think a sensor replaces attention. It saves me trips and keeps the vessel closed. It does not tell me how the cider tastes, and it does not tell me when something smells wrong.

## Supplies

The sensor itself needs very little, but a few supplies make life easier.

- Spare batteries of the right type, kept dry and in a cool place. I keep at least one spare in the tray at all times.
- Cloths, dry and damp, as listed under tools.
- A small bag of silica gel in the tray, to keep the screwdriver and spare batteries from getting damp.
- Labels and a marker for writing the battery change on the bracket, so I can see at a glance how long a battery has been in.
- A few spare screws for the bracket, since the cellar damp makes them rust over time.
- A clean container for checking the level against a real volume.

For the compressor side, I keep the items listed in [[Karkkiork air compressor handbook]]. I do not duplicate them here.

When I run low on any of these, I write it on the shopping list upstairs, not in the cellar. Notes written in the cellar tend to get damp and illegible.

## Measurements

This section holds the numbers I have recorded. I try to take each one under the same conditions, so that I can compare them later.

The flow rate of Traenzirk level sensor: 45.09 l/h.

I got that figure by comparing the sensor's change in level against a known volume over a measured time. I used the clean jug and the stopwatch. The sensor was in its usual place and the cellar was at its usual cool temperature. I took the reading several times and used the value that came up most often, not an average of everything, because one early reading was clearly disturbed by a bumped bracket.

A few notes on how I take measurements:

- I wait until the liquid is calm before I read the sensor.
- I wipe the casing first, to avoid the damp drift I described under problems.
- I note whether the compressor is running, because it can disturb the surface.
- I record the vessel I was watching and its approximate fill, in words, not in invented precision.
- I write down who or what could have affected the reading, such as a bump, a door left open, or foam.

I try not to overstate the accuracy. The sensor tells me the level well enough for ordinary decisions. For anything finer, I use the jug.

## History

The history is short, and I write it as a list of seasons.

**2023.** I installed the sensor in the cellar. I chose the bracket position after trying two others. The first was too close to the wall and collected condensation. The second was too low and got splashed when I moved liquid. The third position is where it still hangs. In this first season I compared the sensor with my marked stick almost daily.

**The season after.** I trusted the sensor for routine checks. This was when I first noticed the drift after damp nights, and when I first changed the battery in the middle of a busy period. I learned to keep a spare in the tray.

**The season after that.** The loose bracket happened. I also started the habit of wiping the casing at each visit. I began writing the checklist below because I had missed several entries.

**This year.** The sensor has been steady. The only real issue was foam, which I still have not solved. I took the flow rate measurement recorded above and tidied the tray.

Across all these seasons the device has stayed green, in the cellar, on battery power, doing the same job it was bought for.

## Observations

These are things I have noticed that do not fit neatly under problems or measurements.

The sensor is most reliable when the vessel is calm and the cellar is cool and steady. It is least reliable on a damp morning after a warm spell, when the casing is wet and the liquid is lively.

The readings follow my own handling. When I move liquid with the compressor, I can see the level change smoothly on the sensor, and that is satisfying. It tells me the flow is steady and nothing is blocked. When the level jerks, I look at the compressor first and the sensor second. My notes in [[Karkkiork air compressor handbook]] help me tell the two apart.

The battery seems to last less time in the deepest cold of the cellar. I have not measured it, so this is a feeling, not a fact. I am treating it as an open question.

The green casing has held up well. It has a few marks from the bracket and from my hands, but no cracks and no fading that bothers me.

I have also noticed that I check the sensor more often than I need to. A glance at the start of the day and one at the end is enough. Extra visits mostly just let in more cellar air and cost me time.

Finally, I trust the sensor most when I have checked it against the jug in the same week. A device I have not verified for a long while starts to feel like a guess.

## Checklist

I use this list at each visit. It is short on purpose, so that I actually follow it.

- Open the door and let air move before staying long.
- Check the floor and the steps for wet patches.
- Wipe the sensor casing with the dry cloth.
- Check the bracket by hand for any looseness.
- Read the sensor and write the value in this log.
- Note whether the compressor is running.
- Look at the battery label to see how long it has been in.
- Change the battery if the readings jump or if the label says it is time.
- Compare with the jug if anything looks wrong.
- Put every tool back in the tray.
- Write the entry before leaving the cellar, or at the latest before supper.

If I skip an item, I write down which one and why. That makes the log honest, and it shows me which steps I tend to forget.

## Costs

I do not track exact prices in this log, and I prefer it that way. Still, the costs fall into a few clear groups.

**The sensor.** The main cost was the purchase in 2023. It has not needed repair since, so there has been no further spending on the device itself.

**Batteries.** This is the ongoing cost. I replace the battery when needed and keep a spare. Over a season it is small, but it is the one cost that never stops. Buying in a pack is cheaper than buying one at a time.

**Bracket and screws.** A small cost, mostly for rust-resistant screws after the damp got to the first ones.

**Cleaning and small supplies.** Cloths, silica gel, and labels. These cost little and last long.

**My time.** The largest cost, though it is not money. Each visit takes a few minutes, and the checklist keeps it from growing. Having the sensor saves me trips and prevents opening the vessel, so I count it as time well spent.

I think the sensor has paid for itself in avoided lid openings alone.

## Maintenance

Maintenance is simple, and it comes down to a few routines.

**Every visit.** Wipe the casing, check the bracket, and read the value. This takes only a minute or two and prevents most of my problems.

**Battery.** Change it when readings become unstable, and do not wait until the sensor stops. Mark the change on the bracket label. Take out the old battery right away and dispose of it properly, not in the general waste.

**Bracket and screws.** Tighten when needed and replace any screw that shows rust. A loose bracket causes steady, misleading errors, so I treat it as a priority.

**Cleaning.** Use a dry cloth on the sensor and a slightly damp one on the bracket and the area around it. I do not soak the sensor or use strong cleaners.

**Checking against the jug.** About once a season, I compare the sensor with a known volume. If it disagrees, I look at the battery and the bracket first.

**End of the season.** When the vessel is empty and the work is done, I wipe the sensor, check the casing, and decide whether to leave the battery in. I write the decision here, so that next season I know what state I left it in.

If I follow these routines, the Traenzirk level sensor does its job quietly, and I can spend my attention on the cider itself.
