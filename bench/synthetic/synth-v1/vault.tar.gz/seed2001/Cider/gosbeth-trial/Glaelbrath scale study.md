---
type: research
status: active
project: gosbeth-trial
area: cider
description: "Research about Glaelbrath scale."
---

# Glaelbrath scale study

## Risks

The Glaelbrath scale is a green scale that sits in the barn and weighs apples and pressed material for the cider work. It runs on mains power, and it was installed in 2016. Because it is old enough to have seen many seasons, I treat every risk below as something that grows slowly rather than something that shows up all at once.

The first risk is a wrong reading that nobody notices. A scale that is off by a small amount still gives a steady number, and a steady number looks trustworthy. If the scale drifts, I could mix a batch with the wrong ratio of juice to additions, or record a yield that is not real. Over a few seasons that would spoil my own records, and I would not be able to compare one year with the next.

The second risk is the barn itself. The barn is damp in autumn, cool at night, and dusty during milling. Mains equipment in that kind of air has a hard life. Moisture can creep into the housing, and sticky juice can dry on the platform and around the feet. Either one can change how the scale behaves without any visible warning.

The third risk is the mains supply. The scale depends on mains power, so a dip, a cut, or a loose plug in the middle of a weighing can leave me with a blank display and a half-finished job. I do not want to guess a weight from memory when fruit is waiting.

The fourth risk is that I forget how the scale is supposed to be used. It has been in the barn since 2016, and habits form. I may load it past what it was meant to carry, or drop a crate on it instead of lowering it. A single hard knock can do more harm than a year of careful use.

The fifth risk is plain neglect. Cider work comes in a rush, and cleaning the scale is the first job that gets skipped. A scale that is only cleaned when it looks bad is already behind.

To keep these risks in view, I check the following at the start of each pressing season:

- Is the platform free of dried juice and fruit pieces?
- Does the display show zero with nothing on it?
- Does the cable look intact, with no cuts or flattened spots?
- Is the plug seated firmly in a dry socket?
- Does a known weight read the same as last time?

If any answer is no, I fix it before I weigh anything for a batch.

## Problems

These are the problems I have actually run into, or that I expect to meet, with the Glaelbrath scale. I keep them in one place so I can see patterns instead of treating each one as a surprise.

**Zero drift.** The most common trouble with a scale like this is that the empty reading wanders. In a barn the temperature swings a lot between a cold morning and a warm afternoon, and the reading can follow it. My habit is to switch the scale on early, let it settle, and only then set zero. If the zero keeps moving after that, I treat it as a sign of dirt under the platform or a damp connection.

**Sticky platform.** Apple juice is sugary, and sugar turns into a hard film. A film on the platform adds a little weight that comes and goes. A film around the feet can also make the scale sit unevenly. I wipe the platform with a damp cloth after each session and let it dry fully before I put anything heavy on it.

**Uneven floor.** The barn floor is not perfectly flat. If the scale sits with one corner higher than the rest, the reading can differ depending on where I place the load. I test this by putting the same crate in the middle and then near each corner. If the numbers differ, I shim the low corner and test again.

**Slow response.** Sometimes the display takes a long time to settle after I put a load on it. When that happens, I wait instead of reading the first number. A reading taken while it is still moving is not a measurement.

**Power interruptions.** Since the scale runs on mains, any interruption stops it. After a cut, I do not trust the first reading. I let it restart, wait, set zero, and check with a known weight before going on.

**Cable wear.** The cable runs across part of the barn, and it is easy to step on, drag a crate over, or catch with a trolley. I keep it along a wall and off the walking line. If the cover shows any damage, I stop using the scale until it is dealt with.

**Records that do not match.** Sometimes the weight I wrote down does not match what I expected from the fruit I picked. Before blaming the scale I check my own notes, since a misplaced digit is more likely than a faulty device. If the notes are fine, I run the known-weight check.

When I solve a problem, I add a short line to this note saying what the sign was and what fixed it. Over time that list is worth more than any manual.

## Background

The Glaelbrath scale is a device in the cider area of my setup. It is a scale, it is green, it is powered from the mains, and it was installed in 2016. It lives in the barn, where the rest of the cider work happens.

I wrote this study because the scale sits at the center of a lot of decisions. Every batch begins with a weight. The amount of fruit decides how much juice I can expect, how large a vessel I need, and how much time the pressing will take. Later, the weight of what is left over tells me how well the pressing went. If that first number is unreliable, everything built on it is unreliable too.

When the scale went in, in 2016, the barn was already the place for cider. The reason for putting a scale there, rather than in the house, was simple: fruit is heavy, messy, and awkward to carry. Weighing it where it is stored and pressed saves a lot of lifting. The choice of mains power was also practical. The barn already had a supply, and I did not want a device that needed its energy source replaced in the middle of a busy week.

The green color is a small thing, but it helps. In a barn full of crates, buckets, and tools, a green scale is easy to spot and hard to confuse with other equipment. I know where it is at a glance, and anyone else helping can find it without asking.

Over the years the scale has gone through a lot of seasons. Each autumn the barn fills with fruit, the air gets damp, and the work gets rushed. The scale has to cope with all of that, and it has mostly done so. What I have learned is that its condition depends less on the device itself and more on how I treat it between uses: how I clean it, where I put it, and whether I test it before I trust it.

This study is meant to gather what I know in one place. It records what the scale is, where it is, how it is powered, and what I do to keep it reliable. The other parts of the note go into the details. This part sets out the facts so that later sections can lean on them.

In short, the summary of the device is:

- Name: Glaelbrath scale
- Kind: scale
- Area: cider
- Color: green
- Energy source: mains
- Year installed: 2016
- Location: barn

## Safety

Safety around the Glaelbrath scale comes down to three things: electricity, weight, and the state of the barn floor. None of them is exotic, but a barn in cider season has water, juice, and heavy loads together, and that combination deserves respect.

**Electricity.** The scale takes its energy from the mains, so I treat it as any other mains device in a damp building. I keep the plug and socket dry and off the floor where juice or washing water can reach them. I never wipe the scale with a dripping cloth while it is plugged in. For cleaning, I switch it off and unplug it first, wipe it with a lightly damp cloth, and let it dry before plugging it back in. If I ever see a damaged cable, a cracked housing, or a plug that feels warm, I unplug the scale at once and stop using it.

**Weight.** Crates of apples are heavy, and the scale is only meant to take a certain load. I lower crates onto the platform rather than dropping them, and I do not stack more on it than it is designed for. I also lift with my legs and not my back, and I ask for help when a crate is too much for one person. A scale that is overloaded can fail, and a crate that slips can hurt my feet.

**Floor and footing.** Spilled juice makes the barn floor slippery, and a slippery floor next to a heavy load is a real danger. I wipe up spills near the scale straight away and keep the area clear of clutter. The scale stands on a level spot, and I keep a clear route from the fruit store to the platform so nobody has to step around obstacles while carrying a crate.

**Cable routing.** The cable should never cross a path where someone could trip on it. I keep it along the wall and, where needed, fix it so that it cannot be dragged. A tripped cable can pull the scale off its place, and that is bad for both the person and the device.

**Working habits.**

- Switch off and unplug before cleaning.
- Keep hands dry when touching the plug.
- Never lean on the platform or stand on it.
- Keep children and pets away from the weighing area during pressing.
- Check the scale and cable before each season, as set out in the risks above.

**If something goes wrong.** If the scale makes a strange noise, smells hot, or shows a display that flickers badly, I unplug it and leave it. I do not open the housing myself while it is connected to the mains. I also write a short note about what happened, because a repeat of the same fault tells me more than a single event.

Following these habits keeps the Glaelbrath scale useful and keeps the barn a safe place to work during the busiest weeks of the year.

## Overview

The Glaelbrath scale is a scale that sits in the barn. It is green, it runs on mains power, and it was installed in 2016. I keep this note as my own working record of how the scale fits into cider work, what I check on it, what I have learned from using it, and how it is set up. It is not a manual. It is the list of things I would want to know if I came back after a long break.

Here are the properties in one place, so I do not have to hunt for them later:

- Kind: scale
- Color: green
- Energy source: mains
- Year installed: 2016
- Location: barn

The scale is the one place where fruit, juice and finished cider get a trustworthy weight. Everything else in the barn is guesswork by comparison. Crates of apples get weighed before pressing so I know what went in. Containers get weighed when I top up, blend or bottle, so I can compare batches from one season to the next. Because it runs on mains power, there are no batteries to forget. The cost of that is a cable, and the cable is the cause of most of my small problems with it.

The green housing is useful in a plain way. It is easy to spot in a dim barn, and it is easy to see when it is covered in pomace dust or sticky with juice. I treat a dirty green surface as a sign that I skipped cleaning at the end of a session.

The barn location matters more than the scale itself. The barn is cold in winter and damp in autumn, which is exactly when the scale gets the most use. Any reading I take in a cold or wet spell gets a little extra suspicion until I have checked it against a known weight. The scale has been in the same spot since 2016, and I have not moved it, because moving it meant re-leveling and re-checking everything every time.

What I want from this study is simple: a short routine that keeps the readings honest, and a record of the mistakes that cost me time. The sections below are the checklist I follow, the lessons I have collected, and the setup as it stands now.

## Checklist

This is the routine I run through before I trust the scale for a real job. I go through it at the start of the pressing season and again whenever something feels off. It is deliberately short, because a long checklist does not get used.

**Before powering on**

- Look at the mains cable along its whole length. Check for chewed spots, crushed spots and juice residue near the plug.
- Make sure the plug is dry. If the barn has been damp, wipe it and let it sit for a while first.
- Clear the platform. Remove leaves, bits of peel, stray stems and anything left from the last session.
- Check that nothing is touching the sides of the scale. A crate leaning on the housing gives false readings.
- Confirm the scale is sitting level on the floor or bench. I look at it from the side and press down lightly on each corner to feel for rocking.

**After powering on**

- Let the scale settle for a few minutes before using it. The barn is cold some mornings and the display is sluggish until it warms.
- Check that the display reads empty with nothing on the platform. If it drifts, wait and try again before assuming a fault.
- Put on a known reference weight and see that the reading matches. I use the same reference every time so that I am always comparing like with like.
- Take the reference off and make sure the display returns to empty.

**During use**

- Place loads in the middle of the platform, not near an edge.
- Set the empty container on first and zero the display, so I read only the contents.
- Write the reading down straight away. I do not trust memory for more than a minute or two.
- Avoid leaning on the table or the scale while reading. Even a light lean changes the number.
- If a reading keeps moving, stop and look for a cause: a draft, a vibrating press nearby, a cable under tension, or liquid still sloshing in a container.

**After use**

- Wipe the platform and the housing with a damp cloth, then dry it.
- Clean around the edges where juice collects and turns sticky.
- Switch off at the wall, not just on the unit, if the barn will be left empty for days.
- Coil the cable loosely and keep it off the floor so it stays out of puddles.
- Note anything odd in the log: a slow start, a drifting zero, a strange smell from the electrics.

## Lessons

These are the things I learned the slow way. Most of them come from one bad session each, and I wrote them down so I do not repeat them.

**Warm-up is not optional.** In the early years I switched the scale on and weighed straight away. On cold mornings the first readings were off, and I only noticed later when a batch did not match my earlier notes. Now I switch it on first, make a drink, and come back. That small delay has removed a whole class of error.

**Zeroing with the container on is the habit that matters most.** Weighing the container and the contents together and subtracting later is how I made arithmetic mistakes. Setting the container on, zeroing, and then filling gives me the contents directly. The same applies to crates: the crate is zeroed, and the apples are what I read.

**Damp air and mains power do not mix well.** Because the scale runs on mains, I became careful about the plug and the cable. Juice and condensation both find their way to the socket end. Wiping and drying the connection became part of the routine, and I keep the cable lifted off the floor. I would rather lose a minute on this than find a fault in the middle of pressing.

**The location is a trade-off.** The barn is the right place because that is where the fruit and the containers are. It is also a place with drafts, vibration from the press, and swings in temperature. I cannot remove all of that, so I work around it. I avoid weighing while the press is running, I shut the door on windy days, and I allow more time in cold weather.

**A fixed reference weight is worth more than a clever method.** I tried a few ways of checking accuracy, and the most reliable was simply using the same reference every time. If the reading is the same as last time, I carry on. If it differs, I stop and find out why before any real weighing.

**Cleaning at the end saves trouble at the start.** Dried juice under the platform edge caused sticking once, and it took me far too long to work out why the readings lagged. Wiping down after each session is quicker than diagnosing that again.

**Write it down immediately.** Some of my least reliable records are the ones I wrote from memory at the end of the day. The log sits next to the scale now, with a pencil on a string.

**Do not blame the scale first.** Most of my odd readings turned out to be a leaning crate, a taut cable or a container that was still moving. The scale has been steady since 2016. When something looks wrong, I check my own handling before suspecting the device.

## Setup

This section describes how the scale is arranged now, so I can restore it if the barn gets rearranged or I have to move things for repairs.

**Placement.** The Glaelbrath scale stands in the barn, on a firm, flat surface that does not flex when I walk past. It has been in this general spot since it was installed in 2016. It is away from the press, because vibration from the press upsets the readings, and away from the door, where drafts and rain blow in. I keep a clear space around it so that crates and containers can be set down and lifted off without bumping the housing.

**Power.** The energy source is mains. The cable runs from the scale to a nearby wall socket along the edge of the bench, off the floor, so it cannot sit in spilled juice or water. I keep the socket end accessible, so I can switch off quickly. I do not use a long extension lead for this, because every extra connection is another place for damp to get in. If I ever need to extend the run, the join must be kept well up and dry.

**Appearance and identification.** The scale is green. I mention this because in a barn with crates, tubs and tools stacked about, the green housing is how I find the scale quickly and how I notice when it has been moved or covered. If it has been buried under something, that is a sign someone, usually me, did not put things back.

**Surroundings.**

- A low shelf nearby holds the reference weight, a cloth for wiping, and the log with its pencil.
- A bench next to the scale is where I set crates and containers before and after weighing.
- A sheet is kept close by to cover the scale when the barn is being swept or when dust is flying. I remove it before powering on.

**Working position.** I stand directly in front of the display so I read it straight on, not at an angle. Containers go in the center of the platform. Crates are lifted on and off with both hands, and I step back before reading, so nothing I am holding touches the scale or the table.

**Between seasons.** When pressing finishes, I clean the scale thoroughly, dry it, switch it off at the wall and unplug it. I cover it and leave it in place rather than moving it. When the next season starts, I run the checklist from the beginning before any fruit goes on the platform. If anything has changed in the barn over the quiet months, such as a leak, a new rodent problem or a rearranged bench, I deal with that before I trust the scale again.

## Tools

The Glaelbrath scale is a green scale used in the cider area. It runs on mains power, it was installed in 2016, and it sits in the barn. When I work on it or check it, I keep a small kit in a crate next to the door of the barn so I do not have to walk back to the house.

What is in the crate:

- A set of check weights. I use three of them, a light one, a middle one and a heavy one, so I can test the scale at the low end, the middle and near the top of what I normally weigh.
- A soft brush and a dry cloth. The scale collects dust and apple pulp, and a brush gets into the corners better than a cloth does.
- A spirit level, the small kind that fits on the platform. The barn floor is not perfectly flat, so I check the level every time.
- A torch. The barn is dim in the corner where the scale stands, even during the day.
- A notebook and a pencil. I write readings down on paper first and copy them here later. A pencil still works when my hands are damp.
- A multimeter. I rarely need it, but it is useful for checking that the mains socket is giving power when the display stays dark.
- A small screwdriver set for the cover plates and the feet.
- A plastic sheet, cut to size, to put over the scale when I am washing down other equipment nearby.

I keep the check weights wrapped in cloth and away from the cider area, because damp and sticky air would change their surface over time. I never use a bucket of apples as a test load, since the weight of apples varies and tells me nothing about the scale.

One rule I follow: the tools stay in the crate. If a tool leaves, I write that on the lid with chalk. Otherwise I get to the barn, need the level, and spend half an hour looking for it.

## Observations

These are my notes from using the scale across the seasons. They are not lab results. They are what I have seen with my own eyes, and I try to be honest about what I am not sure of.

**Warm-up.** Because the Glaelbrath scale runs on mains power, it is ready soon after I switch it on, but the first reading after a cold night is often a little off. If I wait a few minutes and clear the display to zero again, the readings settle. I now treat the first weighing of the day as a trial and do not write it down as a real figure.

**Zero drift.** When the scale sits empty for a long time, the zero can wander slightly. It is never dramatic, but I have noticed it most in autumn, when the barn is damp in the morning and warmer by afternoon. A quick press of the zero button before each batch fixes it. If the zero will not hold, I look for something stuck under the platform before I suspect the electronics.

**Level and feet.** The scale reads differently if one foot is lifted even a little. Twice I found that a foot had worked loose after the barn floor was swept hard. Adjusting the feet until the spirit level sat centred made the readings steady again. This is the first thing I check when the numbers feel wrong.

**Dust and pulp.** In the pressing season, fine dust and dried pulp settle around the edge of the platform. A buildup there can make the platform rub against the frame, and the weight appears lower or jumpy. Brushing the gap clean has solved it every time so far.

**Repeatability.** If I put the same check weight on three times in a row, I expect the same reading each time. Most days I get exactly that. On the odd day when one reading is different, I take it as a sign to check the level and the gap before I trust anything.

**Colour and visibility.** The green casing is easy to spot, and that has a practical benefit: people notice it and do not stack crates against it. Still, the green paint hides dirt well, so I cannot rely on my eyes to tell me when it needs cleaning. I go by the calendar and by how the platform feels when I run a hand around the edge.

**Power.** Since it depends on the mains, a tripped circuit in the barn takes the scale down with everything else. After a power cut I zero it again and run a check weight before the next real weighing. The settings have not been lost in any of the cuts so far, but I would rather confirm than assume.

**Things I am unsure about.** I do not know exactly how much the temperature in the barn changes the readings. My impression is that very cold mornings matter more than damp ones, but I have not tested this properly. It would need a few weeks of readings at set times, which I may try one winter.

**What I do not see.** I have not seen any fault in the display, and the buttons respond well. The cable has not been damaged, though I check it for gnaw marks because mice visit the barn every winter.

## Schedule

I keep the schedule simple so that I actually follow it. The work falls into four rhythms: before each use, weekly in season, monthly, and yearly.

**Before each use**

- Switch on and wait a few minutes.
- Check that the platform is clear and nothing is stuck under it.
- Press zero.
- Put on one check weight, the middle one, and confirm the reading. If it is off, go to the level check.

**Weekly during the pressing season**

- Brush the gap around the platform and wipe the casing with the dry cloth.
- Check the level with the spirit level and adjust the feet if needed.
- Run all three check weights and write the results in the notebook.
- Look over the cable and the plug.

**Monthly all year**

- Run the three check weights even if the scale has not been used much.
- Lift the platform carefully and clean underneath, with the power switched off and the plug pulled out.
- Check that the mains socket is secure on the wall and that no moisture is near it.
- Copy the notebook entries into my records here.

**Yearly, before the season starts**

- Do a full clean, including the feet and the cover plates.
- Test with each check weight at several positions on the platform, centre and corners, to see if the reading depends on where the load sits.
- Compare this year's readings with last year's notes to see if anything has slowly changed.
- Decide whether the scale needs a professional check. Since it was installed in 2016, I think about this more each year, and I would not be surprised if it is due for a service by an expert.

**After events**

- After a power cut, zero and test.
- After a heavy knock or a dropped crate, level and test straight away.
- After a flood of water or a deep clean of the barn, let the scale dry fully before switching it on.

I put the yearly check in my calendar for the quiet weeks before apples start arriving. The weekly check I attach to another routine, which is cleaning the press, because then I do not forget it.

## Maintenance

Maintenance on this scale is mostly about keeping it clean, level and dry. It is a mains device in a barn with cider work going on, so water, sugar and dust are the main enemies.

**Cleaning.** I always unplug the scale first. I brush loose dust and pulp from the platform and the gap, then wipe with a slightly damp cloth and dry it straight away. I do not spray liquid on it. Cider is sticky, and if it gets into the gap it dries hard and makes the platform stick. If I do spill juice, I wipe it up at once with a damp cloth and then a dry one.

**Levelling.** I place the spirit level on the platform and turn the feet until the bubble is centred, in both directions. Then I press down on each corner to check that no foot is hanging in the air. After adjusting, I run the middle check weight and confirm the reading.

**Electrical care.** The scale runs on mains power, so I keep the cable off the floor where I can, away from puddles, and out of the path of the trolley. I look for cracks, bite marks and a loose plug. If the display stays dark, I use the multimeter on the socket first. If the socket is fine, I stop and do not open the scale myself beyond the cover plates. A faulty mains device is a job for someone qualified.

**Protecting the scale.** When I wash the floor or other equipment in the barn, I cover the scale with the plastic sheet. I take the sheet off afterwards so that no damp collects beneath it. In deep winter I check for condensation on the casing before switching on.

**Storing the check weights.** They stay wrapped in cloth in the crate, away from the cider area. I handle them with the cloth and not with bare hands, so that skin oils do not change them.

**Records.** After each maintenance session I note the date in the notebook, what I did, and the check weight results. If something changed, such as a new foot position or a replaced part, I write that down too. Over the years the notes have helped me see patterns, such as the zero drifting more in autumn.

**When to call for help.** I stop and ask for expert help if:

- the check weights give different readings each time, even after cleaning and levelling;
- the zero will not hold;
- the display flickers or shows odd symbols;
- there is a burning smell, or the casing feels hot;
- the cable or plug is damaged.

In those cases I unplug the scale, put a note on it saying not to use it, and leave it until it has been looked at. Since the scale has been in the barn since 2016, I accept that parts will wear, and I would rather pay for a proper service than guess and get wrong weights in my cider records.

**Small improvements I want to make.** A shelf above the scale for the crate, so it is not on the floor. A small hook for the cable. A laminated card by the door with the before-use steps, so anyone helping me can follow them. None of these are urgent, but each would save me a little time and worry.

## Costs

The Glaelbrath scale is a green scale that runs on mains power. It sits in the barn and was installed in 2016. It is used for the cider work, and the costs below are the ones I have tracked for it. I have not put exact prices here, because I would rather describe where the money goes than quote figures I cannot check.

### Purchase and installation

The biggest single cost was the purchase and the work of getting the scale into the barn in 2016. Because the scale runs on mains power, the barn needed a safe socket close to the weighing spot. That meant a short cable run and a proper outlet, not an extension lead trailing across the floor. I counted that electrical work as part of the scale's cost, since I would not have done it otherwise.

There was also the labour of building a flat, firm place for it to stand. A scale on an uneven floor gives different readings from one day to the next, so I levelled a section of the floor and let it settle before I trusted any weights.

### Running costs

Mains power is the only energy the scale uses. Its draw is small compared with the other things in the barn, such as the lights and the pump. I have never noticed it on the electricity bill, and I treat the running cost as close to nothing. If I ever want a real number, the plan is to put a plug-in meter on the socket for a full pressing season and note the result here.

### Upkeep

The recurring costs are small and mostly about time:

- Wiping the platform down after each weighing session, because apple pulp and juice get everywhere.
- Checking the cable and plug for damp, since the barn is cool and humid in autumn.
- Testing the readout against a known weight at the start of each season.
- Replacing the checking weights or cleaning them when they rust.

The green paint on the casing has needed touching up now and then where crates have scraped it. That is a cosmetic cost, but bare metal in a damp barn will not stay bare for long, so I do it anyway.

### Costs I did not expect

Two things cost more than I planned. The first was the protective cover I made for it. Dust from the loft and the fine spray of juice during pressing both found their way into the housing, so a simple cover became a necessity rather than an extra. The second was the time lost in the first year while I learned how much the readings drift when the floor or the crates are not set up the same way each time. That was not money, but it was real effort, and it is why the upkeep routine above is now written down.

### Value for money

Judged over the years since 2016, the scale has paid for itself in avoided waste and better recipes. Knowing the weight of fruit going into each batch lets me compare yields between seasons and between varieties. Without it I would be guessing, and guessing in cider making means ruined batches or wasted fruit. I consider the cost justified, although I cannot put a figure on the saving.

## History

### Before the scale

Before 2016 I weighed fruit with a mixture of methods. I counted crates, estimated by eye, and borrowed a lighter bathroom-style scale that could only handle a few kilos at a time. None of this was consistent. My notes from those seasons record yields as "about a crate" or "a bit more than last time", which is no use for comparing years.

### Installation in 2016

The Glaelbrath scale was installed in the barn in 2016. I picked the barn because that is where the cider work happens: fruit arrives there, is sorted there, and goes to the press from there. Putting the scale at that point meant every load could be weighed once, on the way in, without carrying anything twice.

Getting it running was straightforward because it needs only mains power. The main task was the socket and the floor, as described in the costs section. Once those were done, the scale was set up, tested against known weights, and put to work for that autumn's fruit.

### The early seasons

The first seasons were about learning the device's habits. I found out that the readout needs a few moments to settle after a heavy crate is put down, and that reading too quickly gives a high number. I also found that the scale behaves best when I zero it with the empty crate on the platform, not with the platform bare. These small rules went into a card that I taped inside the barn door.

During this period I started keeping a simple weight log for every batch. The log has since become the most useful record in my cider notes, and it exists because the scale made it possible.

### Changes over time

The scale itself has not changed since it was installed. What has changed is the way I use it:

- I moved from weighing every single crate to weighing in groups once I trusted the readings.
- I added a routine check at the start of each season.
- I made a cover to keep dust and juice off it.
- I touched up the green casing where it wore.

The location has stayed the same. It has always been in the barn, and I have not been tempted to move it, because the layout of the work depends on it being there.

### Where it stands now

Today the Glaelbrath scale is still in regular use for the cider area, still on mains power, still green, and still in the barn where it was installed in 2016. It has been reliable. The only real faults have come from my own handling, such as leaving it damp or setting it on a crate edge.

## Open questions

There are several things I have not worked out yet. I list them here so that I remember to come back to them.

1. **Actual power use.** I assume the draw is tiny, but I have never measured it. A plug-in meter over one season would settle this.
2. **Drift over the years.** The scale has held up well since 2016, but I do not have a clear record of how far its readings have moved. I test it each season, yet I have not plotted those checks over time. Doing so might show a slow trend that I cannot see from one year to the next.
3. **Effect of barn conditions.** The barn gets cold and damp in autumn. I would like to know whether temperature changes the readings, or whether the damp is only a risk for the cable and the casing.
4. **Best place in the barn.** I chose the spot because of the workflow, but I have not tested whether a different spot, with a firmer floor or less spray, would give steadier results.
5. **Replacement planning.** I do not know how long the device should last. If it fails in the middle of a pressing season, I would have no way of weighing fruit properly. I should decide what my backup would be and whether to keep a spare method ready.
6. **Protection from power problems.** The barn supply is not the most stable. I have not checked whether surges or outages could harm the scale or corrupt its readout, and I have not decided whether a surge protector is worth fitting.
7. **Yield comparisons.** With so many seasons of weights in the log, I could analyse yields by variety and by year. I have not yet done it properly, and I am not sure what the best way to present it would be.

## References

These are the sources I rely on for this note. They are all my own records, since the device is part of my private setup.

- My weight log for the cider batches, kept in the barn and copied into my notes each season.
- The card taped inside the barn door with the zeroing and settling rules.
- My seasonal check notes, where I record the test against known weights.
- My notes on the 2016 installation, covering the socket, the floor and the first test.
- The cider area notes in this knowledge base, which describe how fruit moves from the barn to the press.
- The maker's handbook that came with the Glaelbrath scale, which I keep with the device and which covers its mains connection and basic care.

## Parts

This section lists the parts of the Glaelbrath scale as I understand them, with notes on what each one does and what I check on it. The Glaelbrath scale is a scale used in the cider area. It is green, runs on mains power, and has been installed in the barn since 2016. The part number I use when I need to order a replacement for the main unit is WX-8047-R. I keep that number here so I do not have to read it off the worn label on the housing.

### Overview of the build

The scale is a floor-standing weighing device. It sits in the barn, close to the place where the apples come in, and it has been there since 2016. Because it runs on mains power, there is a cable that goes to a socket on the barn wall. There is no battery inside that I know of, so I never think about charging or replacing cells. When the power goes, the scale goes with it, and I weigh nothing until it comes back.

The body is painted green. The paint is the original finish and has chipped in a few places near the base where crates have knocked against it. The chips have not rusted yet, but I keep an eye on them because the barn is damp in autumn.

### Main unit

The main unit is the part that carries the part number WX-8047-R. It holds the electronics, the display and the connection for the mains cable. When I talk about replacing "the scale", this is what I mean in practice. The other parts below can mostly be dealt with separately.

What I check on the main unit:

- The housing is closed and no screws are missing.
- The label with the part number is still readable. It is fading, which is why the number is written in this note.
- The display shows all its segments when switched on.
- The unit is not warm to the touch after a long day of use.
- There is no smell of burning or hot plastic near the vents.

If any of these fail, I stop using the scale until I have looked at it properly.

### Platform

The platform is the flat surface where the load is placed. In my use it takes crates and tubs of apples, and sometimes a full press bin. It is the part that gets the most abuse. I wipe it down at the end of each pressing day, because apple juice dries sticky and then dirt sticks to it.

Things I look for:

- Dents or bends in the surface, which can change how weight is spread.
- Sticky residue along the edges.
- Anything stuck underneath, such as bits of fruit or straw.
- A rocking movement when I push one corner, which means the platform is not seated properly.

I never lean a loaded pallet on the platform edge. I put the load in the middle and set it down gently.

### Load sensors

Under the platform are the load sensors. I cannot see them without lifting the platform, and I only do that when something seems wrong. They are the most sensitive parts of the scale and the most likely cause of odd readings. Moisture is their main enemy, and the barn is not a dry place.

Signs that a sensor may be failing:

- The reading drifts upward or downward while nothing is moving.
- The same crate gives different weights in different spots on the platform.
- The scale does not return to zero after a load is taken off.

I do not try to repair a sensor. If I suspect one, I note the symptoms in my log and get a replacement or a service visit arranged.

### Cable and power connection

The mains cable runs from the main unit to the wall socket. I keep it off the floor where possible, because forklifts, trolleys and boots are all hard on it. I look at the whole length of the cable now and then, checking for cuts, flattened sections and any damage near the plug.

The socket on the barn wall is shared with other equipment at times. I try to keep the scale on its own socket, because a heavy motor starting on the same circuit can make the display flicker. If the display flickers, I move the other device to a different socket and see if it stops.

### Display

The display is on the main unit and shows the weight. It is easy to read in daylight but harder in the evening when the barn lighting is poor. I have thought about adding a small lamp pointed at it, but I have not done it yet.

The display is a common place for dirt and moisture to collect. I clean it with a dry cloth and avoid spraying anything near it.

### Feet and levelling

The scale stands on adjustable feet. The barn floor is not perfectly flat, so the feet matter. If the scale is not level, readings can be a little off, and the platform may rock. I check that all feet touch the floor and that the scale does not move when I push on it.

I recheck the levelling after any of these:

- The scale has been moved.
- The floor has been washed down.
- The scale has been hit by a trolley or a crate.
- The readings seem different from usual.

### Spares to keep

Since the scale has been in service since 2016, I want a few things on hand so a small fault does not stop work in the middle of the cider season.

- A spare mains cable of the right type.
- Cleaning cloths kept only for the scale.
- A note of the part number WX-8047-R, kept in this note and also on paper in the barn.
- A set of replacement feet, if I can get them.

I do not keep a spare main unit. It is too costly to hold one idle, so if the main unit fails I will order it using WX-8047-R and use another way of weighing in the meantime.

### Order of checking when something is wrong

When the scale gives a strange reading, I go through the parts in a fixed order, from the cheapest and easiest to the hardest:

1. Check that the power cable is pushed fully in and the socket is working.
2. Check that the platform is clear and clean.
3. Check that the scale is level and all feet touch the floor.
4. Look at the display for missing segments or flicker.
5. Test with a known load, such as a crate whose weight I already know.
6. Only then think about the load sensors or the main unit.

Most problems I have seen were solved in the first three steps. Dirt under the platform and an uneven floor cause far more trouble than failed electronics.

### Notes on wear

The parts that wear fastest are the platform surface, the feet and the cable. The main unit and the load sensors last longer as long as they stay dry. The green paint is mostly cosmetic, but it also protects the metal, so I touch up chips when I see them.

I record any replacement of a part in my log with the date, the reason and what I did. That way I can see over the years which parts keep causing trouble. Because the scale has been in the barn since 2016, this record is useful for deciding whether it is worth keeping the Glaelbrath scale or replacing the whole thing.
