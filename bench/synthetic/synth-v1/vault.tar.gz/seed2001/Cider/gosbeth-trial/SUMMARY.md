---
type: summary
status: active
project: gosbeth-trial
area: cider
---

# Summary of Gosbeth trial

Gosbeth trial is a cider project with the goal "trial". It started in autumn 2021 and is led by the carpenter. This note is the summary: where it stands, what has been done, what is still open, and what comes next.

Current stage: the trial is past the planning phase and running as a small, hands-on test. The basics are settled, and what remains is mostly checking and tidying up.

## Tools

Most of the work depends on a few simple tools, and the carpenter keeps them close to the workshop.

- A hand-built wooden press frame, made by the carpenter, which is the main piece of equipment for the trial.
- Several clean wooden crates for holding and sorting apples before pressing.
- A fine cloth and a coarse cloth for straining the juice.
- Glass jugs with airlocks for the first fermentation.
- A notebook kept next to the press, where each batch is written down the same day.

Open point on tools: the press frame needs a second look at the joints after a few more pressings. The wood swells when it is wet, and one corner has already loosened a little.

## Decisions

The main decision is made. The go decision date of Gosbeth trial is 2021-04-26, and the work has followed it since then.

What was decided along the way:

- Keep the trial small, so that mistakes stay cheap and easy to learn from.
- Let the carpenter lead, because the press and the crates are all wood and he knows how to fix them.
- Run the trial in autumn, when the apples are ready and the weather stays cool.
- Write down every batch in the same format so batches can be compared later.

Still open: how many batches are enough to call the trial finished. For now the plan is to keep going until the notes show a clear pattern, then decide.

## Next action

The next action of Gosbeth trial is NX-7376. Do this before anything else, and update the notebook once it is finished. After that, review the open points on the press frame and the batch count, and decide whether the trial can be closed.
