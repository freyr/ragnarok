---
type: drivers
status: active
project: gosbeth-trial
area: cider
description: "Drivers about Gosbeth trial."
---

# Drivers of Gosbeth trial

## Tools

The Gosbeth trial is a project in the cider area. Its goal is "trial", it started in 2021 in the autumn season, and the lead is the carpenter. These are the basic properties, and everything else in this note hangs off them.

What I use to run the trial:

- A plain notebook kept next to the press, for pressing dates, batch labels and tasting remarks.
- The shared tool shelf in the shed. The carpenter keeps it in order and decides what leaves it.
- Hand-built racks and a small bench frame, made by the carpenter, so I do not need to buy fittings.
- Clean fermentation vessels with airlocks, enough for the small batches we compare.
- A hydrometer and a basic tasting sheet, one page per batch, so every batch is scored the same way.
- The note [[Zuleth Sionban plan]] for the order of work and who does what.

Rules I keep for the tools: everything is cleaned before and after use, nothing is borrowed without writing it down, and any repair goes through the carpenter first. If a tool is missing on the day, the work waits. I do not improvise with something that could spoil a batch.

## Ideas

The goal is a trial, not a finished product. I want to learn what works in the autumn season with the fruit and the equipment we have. Because the carpenter leads, the practical side of the build comes first, and the cider questions are fitted around it.

Things I want to test or keep in mind:

- Keep the batches small, so a failure costs little and teaches something.
- Change only one thing between two batches, for example the pressing time or the vessel, so the result can be compared fairly.
- Write down the conditions each time: weather, fruit state, how long the fruit sat before pressing.
- Use the same tasting sheet and the same people for judging, so the scores mean something.
- Let the carpenter decide on the structures (racks, bench, storage). I only state what the cider needs, such as a cool, dark and stable place.
- Review after each round and drop what did not help.

Constraints I accept:

- Autumn is the season, so fruit timing sets the pace. If we miss the fruit, we wait for the next year.
- Time is limited to evenings and weekends.
- Space in the shed is shared, so the trial must stay compact.

How I will judge success: the trial is a success if we finish at least one clean comparison between batches, have written notes that someone else could follow, and know which approach to repeat. A perfect drink is not required. A clear answer on what to do next time is enough. If the notes are incomplete, the trial counts as only partly done even if the cider tastes good.

## Budget

The budget of Gosbeth trial is 38292.76 EUR. This is the ceiling for the whole project, covering materials, vessels, small tools and anything the carpenter has to buy for the build.

How I handle it:

- Spend first on what blocks the work, then on what improves it.
- Prefer materials the carpenter can work with directly over finished purchases.
- Record every purchase in the notebook with the date and the reason.
- Check the running total after each round, not only at the end.
- Keep some money unspent for repairs and surprises, and do not plan to use the full amount on day one.

If a cost would push the project over the limit, I stop and decide with the carpenter whether to cut scope or drop the item. The trial is allowed to be smaller than planned, but it is not allowed to go over budget without a written reason in the notes.
