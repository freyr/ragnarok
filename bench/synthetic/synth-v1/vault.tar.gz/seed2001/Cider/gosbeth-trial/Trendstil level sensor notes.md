---
type: note
status: active
project: gosbeth-trial
area: cider
description: "Note about Trendstil level sensor."
---

# Trendstil level sensor notes

## Background

The Trendstil level sensor is a level sensor that I use in the cider area. It is green, it runs on a battery, and it lives in the cellar. I installed it in 2024. These notes are for my own use, so I can remember how it behaves, what I did to set it up, and what went wrong along the way.

I wanted a sensor in the cellar because walking down the stairs to look at a tank level by eye is slow, and in the cold I tend to skip it. A battery-powered unit appealed to me because there is no mains socket near the tanks and I did not want a cable across a wet floor. The green housing is easy to spot against the grey stone wall, which turned out to be useful when I am carrying crates and need to find it quickly.

Quick facts, as I keep them in my head:

- Kind: level sensor
- Area: cider
- Color: green
- Energy source: battery
- Year installed: 2024
- Location: cellar

The cellar is cool and damp for most of the year. It is quiet, which suits fermentation, and the temperature does not swing much. That is good for the sensor, but the damp is something I keep an eye on, and I come back to it under Maintenance and Problems.

I did not buy the sensor to automate everything. I wanted one reliable number I could check without opening a tank lid, because every time a lid is opened there is a small risk of contamination and a loss of the protective gas layer over the cider. Fewer lid openings is the main benefit I wanted.

## Measurements

The main figure I recorded for the Trendstil level sensor is its flow rate: 1889.80 l/h. I wrote it down when I first checked the unit against a known transfer, and I have kept it as my reference. I do not treat it as exact for every situation, since the real rate in a hose depends on the pump, the height difference, and how clogged the filter is. But it is a handy number for planning how long a transfer will take.

How I use the reading in practice:

- I read the level before a transfer and again after it.
- I compare the change with the time the transfer took.
- I check that the result is roughly in line with the reference flow rate.
- If it is far off, I look for a kink in the hose or a partly closed valve.

A small table of how I log things, as a template rather than real data:

| Item | What I record | Where it is written |
|---|---|---|
| Level before | Reading from the sensor | Cellar notebook |
| Level after | Reading from the sensor | Cellar notebook |
| Transfer time | Minutes on the kitchen timer | Cellar notebook |
| Flow check | Compared with the reference rate | This note |
| Battery state | Good, weak, or replace | Cellar notebook |

I deliberately keep the table simple. In the past I over-built logging sheets and then stopped filling them in. Five items is about the limit of what I will do on a cold evening.

The sensor reports level only. It does not tell me about temperature, sugar, or clarity, so those still need a thermometer, a hydrometer, and my own eyes. I try not to expect more from it than it was built for.

When I check the sensor against a dipstick, I do it with the tank at rest, not just after filling, because foam and movement make the reading jump. Waiting a little while gives a steadier value.

## Observations

Over time I have noticed several things about how the sensor behaves in the cellar.

First, the reading is steadiest when the tank has been still for a while. Right after a transfer the number wanders, and I have learned to wait before trusting it. During active fermentation the foam on top confuses the reading, so I treat the value as approximate during that phase and rely on it more once things calm down.

Second, the damp air does not seem to bother the sensor itself, but condensation on the housing can build up on cold mornings. Wiping it down is part of my routine. The green housing hides a little dirt, which is a mixed blessing: it looks clean when it is not, so I have to remember to check by touch and not only by sight.

Third, the battery lasts a long time, but cold conditions seem to shorten it a little. I do not have exact numbers and I will not pretend to. What I know is that the sensor has run for a good stretch since 2024 and I have needed to attend to the battery only occasionally.

Fourth, placement matters. When I first mounted it too close to the tank wall, the readings were less consistent. Moving it a bit farther out improved things. I mention this because it is the kind of detail that I forget and then repeat.

Other small observations:

- The sensor is easy to knock when I move crates, so I now keep a clear path.
- Spilled cider on the floor makes the area sticky and attracts fruit flies, so I wipe up quickly.
- The unit looks the same in dim light, so I keep a small torch hanging nearby.
- Readings feel more trustworthy in the morning, before I have disturbed anything.

## Ideas

Some ideas I may try, none of them urgent.

- Add a small label next to the sensor with the date of the last battery change, so I do not have to look in the notebook.
- Build a little shelf or shield above the sensor to keep drips from the pipes off the housing.
- Make a laminated card with the reference flow rate and my transfer checklist, to hang by the door of the cellar.
- Try a second level sensor on another tank and compare the two during the same transfer.
- Paint a thin line on the tank at the full mark to make a cross-check against the sensor quicker.
- Keep a spare battery in a sealed tub with a drying sachet, so that damp does not get to it.

An idea I have considered and probably will not pursue is wiring the sensor into a bigger monitoring setup. The point of the device for me is that it is simple and standalone. The more I connect, the more there is to break, and the cellar is not a friendly place for fragile electronics.

Another thought is to keep a short season summary at the end of each cider run: what the sensor showed, what I did, and whether the reading matched my manual checks. Over a few seasons that would give me a better picture of whether the sensor drifts. For now I am just jotting a line or two in the notebook and copying the useful ones here.

I would also like to make a simple stand for the sensor when I need to test it outside the cellar, so I can compare readings with a bucket of water in the kitchen. That would make it easier to check it before the season starts, without having to do it in the cold.

## Supplies

Things I keep around for the sensor and its upkeep:

- Spare batteries of the type the sensor uses, stored dry
- Soft cloths for wiping condensation
- A small brush for dust and cobwebs
- Mild soapy water in a spray bottle
- A dry towel
- Cable ties and a little tape for tidying nearby hoses
- A pencil and the cellar notebook
- A torch
- A small screwdriver for the battery cover
- Food-safe sanitiser for anything that touches the cider

I keep these in a plastic box on a shelf near the cellar door, not near the tanks, so that damp and drips do not reach them. The batteries are in their own small container. The box is not green, which I note only because it is easy to confuse with the sensor housing when I glance quickly at the shelf, so I put a strip of white tape on the box lid.

When something runs low I write it on the shopping list at once. Past experience says that if I wait until the next trip to the cellar I forget, and then I discover that I have no spare battery at exactly the wrong moment.

I try not to stock too much. The cellar is small, and every extra box is something to trip over. One spare battery set and one box of cloths is enough for a season.

## Schedule

My rough routine for the sensor, kept as a habit and not as a strict timetable.

- Every time I visit the cellar: glance at the sensor, check that it looks dry and secure, and note the level.
- Before any transfer: read the level and write it down.
- After any transfer: read the level again and compare with the expected change.
- Once a month: wipe the housing, check the mounting, and look at the battery state.
- Before each cider season: test the sensor against a manual check and review these notes.
- Once a year: decide whether the battery should be replaced, even if it still seems fine.

A fuller picture by season:

| Season | Focus |
|---|---|
| Early autumn | Pre-season test and clean |
| Late autumn | Frequent checks during pressing and filling |
| Winter | Monthly checks, watch for cold and damp |
| Spring | Review notes, plan any changes |
| Summer | Light checks, tidy the cellar |

The busiest period is clearly the pressing and fermentation time, when the level changes most. I do not try to be rigorous in the quiet months. A relaxed routine that I actually follow is better than a perfect one that I drop after two weeks.

I put the monthly check on the kitchen calendar as a repeating reminder. Without that, the month passes and I only remember when something looks wrong.

## Safety

The cellar needs some care, and the sensor is only a small part of it.

- Fermentation produces carbon dioxide, which can collect low in a cellar. I keep the space ventilated and I do not linger when I am working near active tanks. If I feel dizzy or get a headache, I go up the stairs at once.
- The floor is often wet. I wear shoes with a good grip and I keep the walkway clear.
- I keep the lighting good enough to read the sensor and see the steps. A torch hangs by the door in case of a power cut.
- I do not put my hands into a tank or lean over an open lid for long.
- Batteries should be handled carefully. I do not leave old ones lying around, I do not mix old and new, and I keep them away from damp and heat.
- Cleaning products and sanitiser are kept apart from food and drink, and clearly labelled.
- I tell someone in the house when I am going to be in the cellar for a long job.

Regarding the sensor itself: I do not open the housing with wet hands, and I do not use it as a handhold or a shelf. If the unit looks damaged, swollen, or leaking, I stop using it and replace it instead of trying to repair it in the damp.

I try to treat the sensor as a convenience and not as a safety device. It tells me about the level, not about the air or the structure of the tank, so I still rely on my own senses and on proper ventilation.

## Setup

The Trendstil level sensor was installed in 2024 in the cellar, in the cider area. Here is how I set it up, as best I remember, plus the changes I made later.

1. I chose a spot on the tank side that I could reach easily without stretching or standing on anything unstable.
2. I checked that the surface was clean and dry, and wiped it with a cloth.
3. I fitted the battery and made sure the cover closed properly.
4. I mounted the sensor, at first close to the tank wall, and later moved it a little farther out after noticing inconsistent readings.
5. I compared the sensor reading with a manual measurement while the tank was still.
6. I did a transfer and compared the change in level with the time taken and the reference flow rate of 1889.80 l/h.
7. I noted the results in the cellar notebook.

Things I would do again: test with the tank at rest, mark the final position with a pencil so I can put it back, and take a quick photo of the mounting for reference. Things I would do differently: think about drips and condensation from the start and choose a place that is not directly under a pipe.

The green housing is the first thing I see when I come down the stairs, which helps me remember to check it. I have not painted or modified it.

After the setup I let it run for a few weeks before trusting it. During that time I checked it against manual readings more often than I do now. Once I saw that the readings were consistent, I relaxed the routine to what is described under Schedule.

## Maintenance

Maintenance is light, but I do not skip it.

- **Cleaning:** I wipe the housing with a damp cloth and then dry it. I do not spray water directly onto the sensor. If there is sticky cider on it, I use a little mild soapy water on the cloth.
- **Mounting check:** I make sure it has not loosened or shifted, because position affects readings.
- **Battery:** I check the battery state monthly and replace it when it looks weak, or at least once a year during the pre-season check. I write the date in the notebook.
- **Battery cover:** I check that the seal is clean and sits properly, since damp is the main enemy.
- **Surroundings:** I clear cobwebs and dust, and I look for drips from above.
- **Testing:** Once a year I compare it with a manual measurement to see whether it has drifted.

When I change the battery, I do it in a dry moment, with dry hands, and not directly under a drip. I take the old battery upstairs and dispose of it properly rather than leaving it in the cellar.

If the readings seem strange, my order of checks is: is it clean and dry, is it still in the right position, is the battery fine, is the tank still, and only then do I suspect the sensor itself. Most of the time the cause is one of the earlier items.

I keep the maintenance simple on purpose. A device that needs a lot of attention in a cold cellar will end up neglected.

## Costs

I have not recorded exact prices in these notes, and I do not want to guess here. What I can describe is the shape of the costs.

- **Purchase:** a one-time cost when I bought the sensor in 2024. It was a modest amount compared with the value of a batch of cider, and it was worth it to me for the fewer lid openings.
- **Batteries:** a small recurring cost. Because the sensor runs on a battery, I need to buy replacements from time to time, and I try to buy a good quality one rather than the cheapest.
- **Cleaning supplies:** cloths, soap, and sanitiser, which I would buy for the cellar anyway.
- **Time:** the most real cost. A few minutes at each visit, and a slightly longer check before the season.
- **Possible extras:** a protective shield, a label, or a spare unit, if I decide to try the ideas listed above.

The sensor has not cost me much to run. The main thing I would watch is the temptation to add accessories. Each small purchase seems fine, but together they could exceed the cost of the device itself.

If I ever have to replace the unit, I will compare it with other level sensors for the cellar and consider whether another battery-powered model would suit me better. At the moment I am happy with it, so there is no reason to switch.

## Problems

Problems I have run into, some small and some more annoying.

- **Wandering readings after a transfer.** The level jumps around for a while. The fix is patience: I wait until the liquid is still.
- **Foam during fermentation.** The reading is unreliable when foam is thick. I now treat the value as approximate during that phase.
- **Poor consistency near the tank wall.** My first mounting was too close, and moving the sensor farther out helped.
- **Condensation.** On cold mornings the housing gets wet. Wiping it down and keeping it clear of drips helps.
- **Battery fading in cold.** The battery seems to drain a bit faster when the cellar is at its coldest. I now check it more often in winter.
- **Accidental knocks.** The sensor was bumped when I carried crates. I cleared the path and now take more care.
- **Sticky spills.** Cider on the floor and walls attracts flies and makes cleaning harder. I wipe up quickly.

None of these has been a disaster. The sensor has kept working since 2024, and most of the trouble came from my own placement and habits, not from the device. When something looks wrong, I usually find that the cause is something simple, such as damp, position, or a weak battery.

One recurring problem is that I forget to write the date of the last battery change. I am working on the label idea to fix that.

## Lessons

What I have learned from using the sensor.

- Let the tank settle before trusting the reading.
- Placement matters more than I expected. A few centimetres can change how steady the readings are.
- Damp is the real threat in a cellar, more than cold. Keep the housing dry and the battery cover sealed.
- Simple routines survive. Complicated logging sheets do not.
- A manual check once in a while keeps me honest about whether the sensor has drifted.
- Fewer lid openings is a real benefit, and the main reason to have the sensor at all.
- Write things down immediately, including battery dates and changes of position. My memory is not as good as I think.
- Do not ask the device to do more than it was built for. It tells me the level, and that is enough.
- Keep spares and supplies in one dry place near the door, not near the tanks.

If I were to start again, I would mount it in the better position from day one, add a label for battery dates, and take a photo of the setup. Those three small things would have saved me a few annoyances.

I would still choose a battery-powered unit for the cellar. The lack of cables outweighs the small effort of battery checks.

## References

These are my own sources, since this is a personal knowledge base.

- My cellar notebook, where level readings, transfer times, and battery changes are written by hand.
- The manual that came with the Trendstil level sensor, kept in the box of supplies.
- My general cider notes on fermentation and transfers.
- My safety notes on cellar ventilation and carbon dioxide.
- The kitchen calendar with the repeating reminder for monthly checks.
- The photo of the mounting taken after setup.

I do not link out to outside sites in this note. If I find a useful article or a tip from another cider maker, I will summarise it in my own words in the relevant section and mention where the idea came from.

When I update this note, I try to change only the parts that actually changed, and I keep the old advice if it still holds. The sections above are meant to be read in any order, depending on whether I need a quick check or a longer reminder.

## Overview

The Trendstil level sensor is a green, battery-powered level sensor for the cider area. I installed it in 2024 and it sits in the cellar. Its reference flow rate, as I recorded it, is 1889.80 l/h, and I use that figure to judge whether a transfer is going as expected.

In practice it is a quiet, low-effort device. I read the level before and after each transfer, wipe the housing when it is damp, check the battery regularly, and compare the reading with a manual measurement once a year. The main benefit is fewer lid openings, which protects the cider and saves me trips around the tanks.

The main weaknesses are the ones that come with the cellar: damp, cold, and the occasional knock. Most of the problems I have had came from placement and habits and not from the device itself. With a sensible position, dry surroundings, and a simple routine, it does what I need.

My short list of next steps is to add a battery date label, think about a drip shield, and keep a spare battery dry and ready. Beyond that, I plan to leave it as it is. The sensor does one job, and as long as it keeps doing it reliably, I have no reason to complicate things.
