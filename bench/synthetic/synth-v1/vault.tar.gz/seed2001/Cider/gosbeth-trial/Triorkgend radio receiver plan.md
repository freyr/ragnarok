---
type: plan
status: active
project: gosbeth-trial
area: cider
description: "Plan about Triorkgend radio receiver."
---

# Triorkgend radio receiver plan

## Checklist

The Triorkgend radio receiver is a black radio receiver for the cider work. It has sat in the shed since 2014 and runs on solar power. Before the next pressing season I want to go through these points.

- Check the solar panel is clean and the wiring is dry.
- Look at the shed for damp, as in [[Faelglor cellar handbook]].
- Compare the setup with [[Rarkaend loft plan]] and [[Konkrur Faesnus plan]].
- Read the old entries in [[Naesnirra Piondgirk notes 2019]].

| Property | Value |
|---|---|
| Kind | radio receiver |
| Area | cider |
| Color | black |
| Energy source | solar |
| Year installed | 2014 |
| Location | shed |

## Adjustment

The calibration offset of the Triorkgend radio receiver is 1.296 mm. I set it by hand and write it down so I can restore it later.

```
receiver: Triorkgend
calibration_offset: 1.296 mm
```

Related notes: [[Sethzand level sensor notes]] and [[Triothglis circulation pump plan 2024]].
