---
type: note
status: active
project: lendve-rebuild
area: cider
description: "Note about Naesnirra Piondgirk."
---

# Naesnirra Piondgirk notes

## Tools

Naesnirra Piondgirk is my supplier contact for cider. She is reachable by phone, and that is the only channel I use with her. I do not send long emails and I do not use messaging apps for her. She answers on weekdays, so I keep my calls inside that window.

The tools I use when dealing with her are simple:

- A phone with her number saved under her full name, Naesnirra Piondgirk.
- A paper notebook next to the desk where I write down what we agreed during a call.
- A small spreadsheet of what I ordered, what arrived and what I paid for.
- A kitchen scale and a measuring jug for checking small samples.
- A refractometer for checking sugar in juice when she sends a sample.
- A set of clean bottles for tasting batches before I commit to a larger order.
- A calendar reminder that tells me to call her before the weekend arrives, since she is not available then.

I keep the tools few on purpose. When I tried to track everything in several places, I lost track of what was agreed. Now the notebook is the first record, and the spreadsheet is the second. If the two disagree, I call her on the next weekday and sort it out.

## Problems

The main problem with this contact is timing. She is available on weekdays only, and I tend to remember questions on Saturday evening. That has led to a few awkward situations where I wanted to confirm an order and had to wait until Monday.

Other problems I have run into over the years:

- Phone-only contact means there is no written trail unless I make one. I have had to rely on my own notes more than once.
- Juice quality varies from one pressing to the next. This is normal for cider supply, but it makes planning harder.
- Quantities sometimes shift between the call and the delivery. Usually the difference is small, but I want to catch it early.
- When I call at a busy time of day, the call is short and I forget half my questions.
- Messages left for her are not always returned the same day.

None of these is a reason to look for another supplier. They are things I have learned to work around. The solution is mostly preparation: I write my questions before I dial, I call in the morning, and I write down the answers while she is still talking.

## Background

Naesnirra Piondgirk is a person I know through the cider trade. Her role is supplier contact. Her area is cider. The way I reach her is phone. Her availability is weekdays. I have known her since 2016, so by now it is a long working relationship.

How we met is simple. I was looking for a dependable source of cider ingredients and a person who could explain what was available and when. She was the one who picked up the phone, answered plainly and did not oversell. That first impression has held for years.

What I value about her:

- She says clearly when something is not available instead of promising and failing.
- She remembers what I bought before and suggests what suits it.
- She is patient with my questions, including basic ones I asked in the early years.
- She is consistent. The tone of a call in 2016 and a call this year are much the same.

What I know about her work is limited to what she tells me. I do not know the full structure of the business behind her, and I have not needed to. For my purposes she is the person to call. If she were away, I would need to ask who covers for her, and I have not yet written that down. That is a gap in these notes.

## Checklist

Before I call her I go through this list:

1. Is it a weekday? If not, wait.
2. Have I written down what I need and roughly how much?
3. Have I checked my spreadsheet for what is still in stock at my end?
4. Do I have the notebook open and a pen ready?
5. Do I know what delivery timing I need?
6. Have I thought about whether I want a sample first?

During the call:

- Confirm the item and the amount out loud, then repeat it back.
- Ask about timing of delivery.
- Ask whether anything is changing in quality or availability.
- Ask what she would suggest for the coming weeks.
- Write the agreement in the notebook with the day of the week.

After the call:

- Copy the agreement into the spreadsheet the same day.
- Set a reminder for the expected delivery.
- If something is unclear, note it and call again on the next weekday.
- Check the delivery against the notebook when it arrives.

This list looks long but takes a few minutes once it is routine. It has saved me from several misunderstandings.

## Schedule

Because she is available on weekdays, my whole routine around her follows the working week.

Typical pattern:

- Monday: I review the weekend, check stock and write down questions. If something is urgent, I call.
- Tuesday and Wednesday: These are my preferred days for placing orders. The week is settled, and there is time for delivery before the next weekend.
- Thursday: I use this for follow-up calls or to confirm a delivery that is coming.
- Friday: I avoid placing anything new. If a problem appears, I call early, because later in the day is less reliable.
- Saturday and Sunday: No calls. I only prepare notes for Monday.

Seasonal rhythm also matters. In the busy part of the cider year I call more often, sometimes weekly. In quiet months I call once every few weeks just to stay in touch and learn what is coming. I try not to disappear for a long time, because the relationship works better with regular contact.

I keep a recurring reminder for a general check-in call. It is not tied to any order. It is simply a habit that keeps the line open.

## History

I have known Naesnirra Piondgirk since 2016. The relationship has gone through a few stages.

Early years: I asked a lot of questions and ordered small amounts. She explained things patiently. I made mistakes, such as ordering at the wrong time or misjudging how much I would use. She did not make me feel foolish about it.

Middle years: Orders became more regular. I learned her working pattern and stopped calling at bad times. I began to keep proper records, which made our conversations more efficient. We started to speak in shorthand about the usual items.

Recent years: The relationship is steady. I formalised some of the arrangement, and the contract date is recorded in the Contracts section. Since then the calls have been shorter and more routine, though I still ask for her advice when something new comes up.

Over this whole period the channel never changed. It has always been the phone. I once considered asking for a written summary after each call, but I decided that my own notes were enough, and that adding paperwork might slow down something that works.

If I look back, the main lesson from the history is that a good supplier relationship is built by small, consistent, honest exchanges rather than by any single big deal.

## Costs

I do not record exact prices in these notes, because they change and are better kept in the spreadsheet. What I can write down is how I think about cost with her.

Things that affect what I pay:

- The size of the order. Larger orders usually bring a better arrangement, but only if I can use everything.
- Timing. Ordering in the busy season can cost more or be harder to arrange.
- Delivery. Transport is a real part of the total, so I always ask about it.
- Quality. Cheaper is not always better, and I would rather pay a fair amount for something consistent.

Hidden costs I try to watch:

- Wasted product when I order too much.
- My own time spent on repeated calls when I did not prepare.
- Extra trips or arrangements when delivery goes wrong.

My habit is to ask for the full picture during the call rather than just the base amount. I write the total in my notebook and compare it with the spreadsheet afterwards. If something looks different from what I expected, I raise it politely on the next weekday call. She has always been open about it.

I also keep in mind that the long relationship has value. A reliable contact since 2016 saves me time and worry, and I count that as part of the cost-benefit picture even if it does not show up in numbers.

## Setup

This is how I have organised things so that working with her is smooth.

Phone:

- Her number is saved under Naesnirra Piondgirk, with a note in the contact entry saying "supplier, cider, weekdays only".
- I have set the contact to a recognisable label so I do not call at the wrong time by accident.

Notebook:

- One page per call, headed with the day of the week.
- Three columns in my own style: what I asked, what she said, what I need to do.

Spreadsheet:

- One row per order.
- Fields for item, amount, expected delivery, actual delivery and notes.
- A simple column marking whether the delivery matched the agreement.

Calendar:

- A recurring weekly reminder to prepare questions on Monday.
- A one-off reminder for each expected delivery.
- A general check-in reminder every so often.

Storage at my end:

- A clean, cool place for anything that arrives.
- Labels on containers with the date of arrival written by hand.

With this setup, each call has a clear start and end, and I can find any past agreement quickly.

## Safety

Cider work involves food safety and general workshop safety, and I take both seriously.

Food safety:

- Keep everything clean: bottles, jugs, funnels and any surface that touches juice.
- Check what arrives for smell, appearance and any signs of spoilage before using it.
- Do not use anything that seems off. Call her on the next weekday to report it.
- Label and date everything.

Handling:

- Heavy containers should be lifted with care. I do not carry large loads alone.
- Glass can break, so I use a stable surface and wear suitable footwear.
- Fermenting products can build pressure, so I never seal something that is still active without thinking through the risk.

Communication safety:

- If something seems wrong with a delivery, I stop and call rather than guess.
- I write down exactly what she says about handling or storage and follow it.
- I do not share her phone details casually, since she is a contact I want to respect.

If I ever have a doubt about safety, I treat it as a reason to pause. A delayed batch is a smaller problem than a bad one.

## Contracts

The contract date of Naesnirra Piondgirk is 2023-09-09.

That is the date when the arrangement between us was put on a more formal footing. Before that, things ran on trust and verbal agreement, which worked well for years but left some things unwritten.

What I keep in mind about the contract:

- It is tied to her role as my supplier contact in the area of cider.
- It does not change the way I reach her. Contact is still by phone, and she is still available on weekdays.
- I keep my own copy where I can find it and note in the spreadsheet that it exists.
- I reread it from time to time, particularly before a large order or if something unexpected happens.

Practical points:

- If I want to change something, I raise it by phone on a weekday, then write down what we agreed.
- I do not rely on memory for terms. I check the document.
- If a delivery does not match what was agreed, the contract is the reference point, though I always start with a friendly call.

I would like to add a short summary of the main terms here in a future revision, so I do not have to open the full document each time.

## Risks

Some risks come with relying on one person as my supplier contact.

- Single point of contact: if she is unavailable for a longer period, I do not have a named backup. I should ask her who covers for her.
- Phone-only communication: without a written trail, disagreements depend on my notes. This is why I keep them carefully.
- Weekday-only availability: urgent problems at the weekend have to wait. I plan ahead so that nothing critical lands on a Saturday or Sunday.
- Supply variation: cider supply depends on the season and the quality of the raw material. I should avoid depending on exact amounts at the last minute.
- Drift in the relationship: after so many years, I might assume things without checking. I counter this with the checklist.
- Changes at her end: her role, her business or her contact details could change. I would like to confirm her details now and then.

How I reduce risk:

1. Keep good records.
2. Call regularly, not only when I need something.
3. Order early rather than late.
4. Keep a small buffer at my end.
5. Reread the contract when something unusual happens.

None of these risks is large at the moment, but writing them down makes me more likely to act before they become problems.

## Overview

Naesnirra Piondgirk is a supplier contact. Her area is cider. I contact her by phone. She is available on weekdays. I have known her since 2016.

In short:

- She is reliable, honest and easy to work with.
- Our working pattern is built around weekday phone calls.
- I keep a notebook, a spreadsheet and calendar reminders to support the relationship.
- The contract date is recorded under Contracts.
- The main weaknesses are the lack of a backup contact and the absence of any written trail beyond my own notes.

This note is meant to be a quick reference for myself. If I need to remember how to work with her, I can read the checklist and the schedule. If I need to remember why I trust her, the background and history explain it. If I want to be careful, the safety and risks sections remind me what to watch.

I intend to update it whenever something changes: a new arrangement, a change in how she can be reached, or a lesson from a difficult delivery. A note like this is only useful when it stays current.

## Ideas

A few things I might try to improve how I work with her:

- Ask who covers for her when she is away, and write down the answer.
- Offer to send a short written confirmation of each order after the call, if she is comfortable with it.
- Plan a yearly conversation about the coming season, so I can adjust my plans early.
- Build a simple tasting log so I can give her more precise feedback on what I received.
- Create a one-page summary of the contract terms to keep next to the notebook.
- Mark in the calendar the busiest weeks of the cider year, so I do not leave orders too late.
- Think about whether a visit in person would be useful, since so much of our contact has been by phone.
- Keep a short list of standard questions to ask at every check-in call.

Not every idea needs to be done. Some might be unwelcome, and I should respect her preferences about how she likes to work. The aim is to make things clearer and easier for both of us, not to add burden.

I will review this list after a few months and keep only the ideas that still seem useful.

## Lessons

After years of dealing with Naesnirra Piondgirk, these are the lessons I would pass on to myself:

1. Respect availability. She is available on weekdays, so plan around that and do not push for weekend answers.
2. Prepare before calling. A few minutes of preparation make the call shorter and better.
3. Write everything down. Phone-only contact means my own notes are the record.
4. Confirm by repeating. Saying the agreement back during the call prevents most misunderstandings.
5. Keep the relationship warm. Regular contact, even without an order, keeps the line open.
6. Be honest and straightforward. She has always done the same with me, and it works.
7. Check deliveries against the agreement on the day they arrive.
8. Do not assume. After many years it is easy to skip checks, and that is when mistakes happen.
9. Formal arrangements help, even with a trusted person. The contract has made things clearer.
10. Plan for gaps. I still need to find out who can help if she cannot.

The overall lesson is that a supplier relationship works best when both sides are reliable and clear. Since 2016 that has been true here, and I want to keep it that way by staying organised, polite and consistent.
