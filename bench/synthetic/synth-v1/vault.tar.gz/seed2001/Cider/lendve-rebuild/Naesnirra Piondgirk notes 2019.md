---
type: plan
status: archived
project: lendve-rebuild
area: cider
---

# Naesnirra Piondgirk notes 2019

## Risks

This note is archived. It records how things stood in 2019 with Naesnirra Piondgirk, my supplier contact for cider. Later notes replace the values here, so do not treat any of this as current.

The main risks I saw in 2019 were these:

- **Single contact.** Everything for the cider supply ran through one person. If Naesnirra was away or changed jobs, I had no second name to call. I had no backup supplier lined up.
- **Phone only.** The agreed contact method is phone. There is nothing written down from a call unless I write it down myself. Verbal promises about quantity or timing can drift.
- **Weekdays only.** Naesnirra is available on weekdays. Anything urgent on a weekend had to wait until Monday. A problem on a Friday afternoon could sit for days.
- **Seasonal pressure.** Cider supply is tied to the pressing season. If a batch came late or short, I had little room to recover.
- **Old agreement.** The contract was already a while old by 2019, and I had not reviewed its terms since signing.

A rough view of how I rated them at the time:

| Risk | Likelihood | Impact | What I planned to do |
|---|---|---|---|
| Single contact | Medium | High | Ask for a second name |
| Phone only | High | Medium | Write a short summary after each call |
| Weekdays only | High | Low | Place orders early in the week |
| Seasonal pressure | Medium | High | Order ahead of the season |
| Old agreement | Low | Medium | Read the contract again |

## Lessons

What I took from dealing with Naesnirra up to 2019:

1. **Call early in the week.** Because availability is weekdays only, Monday and Tuesday calls got the best results. Late-week calls were more likely to leave me waiting.
2. **Write up every call.** Since the contact is by phone, I keep a short written record of what was said: what was ordered, what was promised, and when. This costs a few minutes and has saved me from arguments.
3. **Keep the relationship warm.** I have known Naesnirra since 2016. That history helped. A supplier who knows you is more willing to help when something goes wrong. A short call outside of ordering time is worth making.
4. **Do not rely on one person.** I should have asked sooner who covers when Naesnirra is away. This was the biggest gap in my setup.
5. **Plan around the season.** Orders for cider need lead time. Leaving it late is the surest way to get a poor result.

Things I would repeat: confirm orders by phone, then check them again a few days later. Things I would stop: assuming that a friendly agreement needs no paperwork.

## Overview

This section lists the properties of the subject as they stood in 2019.

| Property | Value |
|---|---|
| Name | Naesnirra Piondgirk |
| Type | Person |
| Role | Supplier contact |
| Area | Cider |
| Contact | Phone |
| Availability | Weekdays |
| Known since | 2016 |

Naesnirra Piondgirk is my supplier contact for cider. I first met Naesnirra in 2016, so by 2019 we had worked together for a few seasons. The way to reach Naesnirra is by phone, and the person is available on weekdays. I do not use any other channel for supply matters.

In practice the relationship is simple. I phone, we agree what I need, and I note it down afterward. Naesnirra is reliable on the basics and usually answers within a day when I call on a weekday. The weak points are the ones listed under Risks: one contact, no weekend cover, and a heavy dependence on the season.

Because this note is archived, the values above describe 2019 only. If the role, the contact method, or the availability changed later, the newer notes hold the correct values and this one should be left as it is.

## Contracts

The contract with Naesnirra Piondgirk is dated 2018-02-20. It was signed after two years of working together on a handshake basis, which is why I wanted something on paper. The contract covers the supply of cider from Naesnirra's side, and it set out the general terms of how orders are made and handled.

What I kept in mind about the contract in 2019:

- **Date.** The contract date is 2018-02-20. I treat that as the start of the formal arrangement.
- **How orders are placed.** Orders go through a phone call. I follow each call with my own written note, because the contract does not replace a record of what was said.
- **Review.** I had not reread the contract since signing. A plan for 2019 was to read it through once, check that the terms still matched how we actually work, and list anything to raise on the next call.
- **Changes.** Any change to the terms should be agreed on a call and then written down with the date.

Plan for the rest of 2019:

1. Reread the contract and mark anything unclear.
2. Ask Naesnirra who covers when she is away, and note the name.
3. Place the next order early in the week, and write up the call.
4. Check the order a few days later by phone.
5. Keep this note as it is once the year ends, and start a new one for the next year.

Since this note is archived, any contract changes after 2019 belong in the newer notes.
