---
type: drivers
status: active
project: lendve-rebuild
area: cider
---

# Drivers of Lendve rebuild

## Checklist

Things to confirm before the Lendve rebuild moves on. This is the drivers note, so the list is about goal, limits, money and how I will judge the result.

- Goal is stated in one sentence: rebuild the cider setup that the project is named after.
- Area is cider. Everything in the project should serve that, and anything that does not gets dropped.
- Start year is 2025, season spring. The work began in that season and the plan still follows it.
- Lead is the supplier contact. Questions about parts, lead times and substitutions go to them first.
- Budget is written down in the Budget section and I check it against every purchase.
- Success measures are listed in Observations and I re-read them before each decision.
- Constraints are listed in Background. If a new idea breaks one, it goes to Ideas, not into the plan.
- Supplies list is current. Anything ordered gets a line in History.

## Budget

The budget of Lendve rebuild is 7182.38 EUR.

That figure is the ceiling for the whole project, not a target to reach. I treat it as one pool. I do not split it into fixed envelopes, because the supplier contact often changes what is available, and a rigid split would only make me move money around on paper.

How I handle it in practice:

- Every purchase gets noted when I commit to it, not when the invoice arrives.
- I keep a small reserve mentally set aside for things I cannot predict, such as a part that turns out to be the wrong fit.
- If a single decision would use up a large share of what is left, I stop and think for a day before agreeing.
- Labour I do myself is not priced, but my time is limited, and that is a constraint of its own.

If the total is going to be exceeded, the project scope shrinks first. I do not raise the ceiling quietly.

## Background

The Lendve rebuild is a project in the cider area. Its goal is a rebuild: taking what exists, stripping out what no longer works, and putting it back together in a more reliable form. It started in spring 2025, and the lead is the supplier contact.

Why the supplier contact leads: most of the real decisions are about what can be sourced, when it can arrive, and what it will cost. I do the work, but the supplier contact sets the pace. That arrangement suits me, since it keeps the plan tied to what is actually available.

Constraints I have to live with:

- Money. The ceiling is the budget above and nothing more.
- Season. The project began in spring, and the cider calendar does not wait for me. Work that slips past its natural window has to wait for the next one.
- Sourcing. Parts depend on one main contact, so a delay on their side becomes a delay on mine.
- Space and time. I work on this around other things, so tasks must be small enough to finish in a session.
- Cleanliness. Anything that touches the product must be easy to clean and made of suitable material. I will not trade this for savings.

The goal in plain words: end up with a setup I trust, that I can maintain without special help, and that does not surprise me in the middle of a busy period.

## Observations

How I will know whether the rebuild succeeded. These are the measures I keep coming back to.

- Cost: the final spend stays within the budget. Coming in under is good, going over is a failure of planning.
- Reliability: the rebuilt setup runs through a full cycle without an unplanned stop or emergency fix.
- Cleaning: a normal clean takes less effort than before, and nothing hides residue.
- Maintainability: I can explain every part and replace it using the notes I have kept.
- Schedule: the main work is finished within its seasonal window rather than dragged on.
- Sourcing: no critical part depends on something that is hard to get again.

Things I have noticed while thinking about this project:

- The biggest risk is not money but waiting. A late delivery costs more than a slightly dearer part.
- Notes written at the time are far more useful than notes written later. I should keep recording decisions as they happen.
- The supplier contact is helpful when asked specific questions and less so with vague ones. I should write my questions out before I call.
- Success is easier to judge when I have decided the measures first. Otherwise I find reasons to call anything fine.

## Ideas

Possible directions, none yet committed. Each would need to fit inside the budget and the constraints.

- Ask the supplier contact for a short list of standard parts, so I stop comparing endless options.
- Standardise fittings wherever I can, so that one spare covers several uses.
- Do the work in stages, each with a clear stopping point, so that a pause never leaves the setup half open.
- Keep a simple log sheet next to the equipment and record every adjustment.
- Plan one trial run with a harmless liquid before the real product goes through.
- Review the measures from Observations after the first full cycle and write down what I would change.
- If money gets tight, drop cosmetic improvements first and keep everything related to cleaning and reliability.

## Supplies

What the project needs, grouped by type rather than by exact item. Specific orders are recorded in History as they happen.

- Replacement fittings and connectors suitable for contact with the product.
- Hoses or lines, with a spare length in case of a bad cut.
- Seals and gaskets, bought with extras because they are small and easy to lose.
- Cleaning and sanitising supplies for the rebuild and for the trial run.
- Basic tools I may not own yet, to be checked before ordering anything.
- Notebook or sheet for the log, plus labels for marking parts.

Source: the supplier contact for anything technical, and local shops only for common items. Before ordering, I check whether I already have something similar on the shelf.

## History

A running record of the project in rough order.

- 2025, spring: the project started with the goal of a rebuild in the cider area. The supplier contact was named as lead.
- Early on: I set the budget ceiling and decided to treat it as one pool.
- Planning: constraints were written down, with cleanliness and season marked as the ones I will not bend.
- Since then: I have used this note to settle disagreements with myself. When a new idea appears, I compare it with the goal, the budget and the measures before acting.
- Still to do: update this section whenever an order is placed, a decision is made or the plan changes, so the record stays useful.
