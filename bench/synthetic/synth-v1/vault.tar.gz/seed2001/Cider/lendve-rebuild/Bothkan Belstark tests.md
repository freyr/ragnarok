---
type: research
status: active
project: lendve-rebuild
area: cider
description: "Research about Bothkan Belstark."
---

# Bothkan Belstark tests

## Costs

Bothkan Belstark is my neighbor, and most of what we do together involves cider. These notes cover the tests I have run with him, so the costs here are the practical ones: what I spent, what he spent, and what we shared. I have not written any prices down on purpose, because the amounts changed from one test to the next and I only want the pattern.

- Apples: the biggest cost. Bothkan usually has windfalls from his own trees, so I pay little for fruit. When I buy extra, I note it in the same place as the test.
- Bottles and caps: I buy these in bulk and split them with him. He pays me back in cider rather than money.
- Yeast and nutrients: small items. I buy them and keep the leftovers for the next test.
- Time: the real cost. Weekends are the only time he is free, so each test eats a full Saturday or Sunday.
- Cleaning supplies: sanitizer and brushes. Easy to forget, but they add up over a season.

The rule I settled on is that whoever hosts the pressing covers the small consumables, and the other person brings the fruit or the bottles. It keeps things even without accounting for every item.

## Contracts

There is no formal contract between us for the cider work, but there is one dated agreement that I keep on record. The contract date of Bothkan Belstark is 2018-10-10. That is the date we first wrote down who owns what when we share equipment and fruit.

The agreement is short and practical. It covers these points:

- Equipment that I bought stays mine, and equipment that he bought stays his.
- Anything bought together is shared, and if we stop, we split it or one of us buys the other out.
- Each of us keeps our own finished cider unless we agreed beforehand to blend batches.
- Neither of us sells cider made from a joint test without asking the other.

I have known Bothkan since 2019, which is a year after the date of that agreement. So the paper actually came first, and the friendship followed. I mention this only because it explains why the document is so plain: it was written between two people who barely knew each other and wanted to avoid confusion later. It has held up well, and we have never needed to go back and argue about it.

If we ever change the arrangement, I will write a new note rather than edit the old one, so the history stays clear.

## Setup

The tests happen in whichever garage is less cluttered at the time. The setup is the same in both places, so I only describe it once.

Basic layout:

- A clean table near the door for fruit sorting.
- The press and the crusher on the floor, on a sheet that can be hosed off.
- Fermentation vessels along the back wall, away from the light and out of drafts.
- A small shelf for notebooks, a pen, and the testing tools.

Contact and timing matter as much as the physical layout. Bothkan answers email, and that is the channel I use for everything: planning, reminders and sharing results. He does not respond quickly to anything else. His availability is weekends, so I plan around that and never suggest a weekday evening.

Before each test I send an email with the plan a few days ahead. It lists what we are pressing, what each of us brings, and what we want to learn. He usually replies with a short yes and any change he wants to make. If he does not reply by Friday, I assume the weekend is off and move the test to the next one.

Cleaning comes first. Everything that touches juice gets washed and sanitized before we start, and I do not skip this even when we are in a hurry. Most failed batches I have seen came from lazy cleaning, not from bad fruit.

## Ideas

These are the test ideas I want to try with Bothkan, written loosely so I can pick one when a weekend comes up.

- Compare single-variety juice against a blend of three or four varieties, using the same yeast.
- Try two different yeasts on the same juice, split into equal vessels.
- Test the effect of letting crushed apples sit for a few hours before pressing.
- Try a slower, cooler fermentation and compare it with one at room temperature.
- Compare bottle conditioning with a still cider kept in the vessel.
- Try adding a small amount of a different fruit, such as pear, to a plain batch.
- Test how long the cider needs to rest before it tastes settled.

Some of these are easy and some need planning. The yeast comparison is the simplest, so it is probably the first one. The blending idea needs us to keep good records of each variety, which means labeling the fruit boxes at the start.

Bothkan likes the idea of the blend test best, because his trees give a mix of fruit that is hard to separate. I like the resting-time test best, since it costs almost nothing except patience. We will probably do both over the year and see which gives more useful results.

One thing I want to avoid is changing too many things in one test. If two variables change at once, I cannot say which one caused the result. So each test gets one change only.

## Checklist

I use this list on the morning of each test. I keep a printed copy in the garage so I do not rely on memory.

- Confirm by email that Bothkan is coming, if he has not already said so.
- Check that the weather suits working with the door open.
- Wash and sanitize the press, crusher, buckets, funnels and vessels.
- Sort the fruit and remove anything rotten or moldy.
- Label every vessel with the test name and the one thing we changed.
- Prepare the notebook with a page for each vessel.
- Set out the testing tools and check that they are clean.
- Have spare bottles, caps and tape ready.
- Keep water and a towel nearby for hands.
- Take a photo of the labeled vessels before we leave.
- Clean the floor and tools after the work, not the next day.
- Agree on when the next weekend session will be, and write it down.

If an item is missing, I note it at the bottom of the page so I can fix it for the next time. The list has grown a little each season, and that is fine, because every addition came from a real mistake.

## Schedule

The schedule is built around Bothkan being free on weekends. Weekdays do not work, so I never plan anything for them, and I do not expect an answer to an email during the working week to lead to a quick meeting.

A typical test runs in this order:

- Early in the week, I send the plan by email.
- By Friday, I expect his reply, and if there is none I move the test.
- On Saturday or Sunday morning, we sort, crush and press.
- The same day, we fill the vessels and label them.
- During the following weeks, I check the vessels alone on weekends and write down what I see.
- At the end, we meet again to taste and compare.

The tasting is the part we both enjoy most, so we usually pick a calm afternoon for it. We do not rush it. We pour small samples, write our notes separately, and only then compare what we wrote. That stops one of us from influencing the other.

Over the year, the apple season sets the pace. The pressing tests happen when fruit is ready, and the tasting tests happen later, once the cider has had time. In the quiet months, we use the time to review notes and decide what to try in the next season.

## Overview

Bothkan Belstark is my neighbor, and our shared interest is cider. Here are the facts about him in one place:

- Role: neighbor
- Area: cider
- Contact: email
- Availability: weekends
- Known since: 2019

Our working relationship has a short history. The agreement from 2018-10-10 came before I knew him well, and since 2019 it has grown into a steady habit of testing small cider batches together. We are not professionals, and neither of us is trying to make a business out of it. The point is to learn what changes the flavor and to enjoy the work.

What makes the arrangement easy is that the rules are simple. We use email, we meet on weekends, we keep equipment ownership clear, and we change only one thing per test. Because of this, I rarely feel that I am chasing him or that he is chasing me.

I keep these notes for my own use, so they are not polished. They record what we did, why we did it, and what I want to remember. If I ever forget how a test was run, this note and the individual test pages should be enough to repeat it.

## Observations

After several seasons of testing, a few patterns are clear enough to write down.

- Cleaning decides more than any recipe change. The batches that went wrong were nearly always the ones where we rushed the sanitizing.
- Fruit variety matters, but fruit ripeness matters just as much. Underripe apples gave thin, sharp cider no matter what we did afterward.
- Patience pays. Cider tasted soon after fermentation is rough, and the same cider a few weeks later is clearly better.
- Notes written separately before comparing are more honest than notes written together.
- Email works well for Bothkan. He gives short, clear replies, and I have a written record of what we agreed.
- Weekend-only availability is a real limit, so a test that needs a midweek action, such as a quick check, has to be done by me alone.

Some questions are still open. I do not yet know how much the yeast choice matters compared with the fruit. I also do not know whether the cooler fermentation is worth the extra trouble in the garage, where temperature is hard to control.

For the next season, I plan to repeat the simplest test first, to check that our methods are consistent. If the same test gives the same result twice, I can trust the later comparisons more. Bothkan agrees with this approach, and we will settle the first weekend by email once the fruit is ready.
