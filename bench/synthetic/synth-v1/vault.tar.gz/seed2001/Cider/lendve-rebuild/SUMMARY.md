---
type: summary
status: active
project: lendve-rebuild
area: cider
description: "Summary about Lendve rebuild."
---

# Summary of Lendve rebuild

## Background

Lendve rebuild is a project with the goal of rebuild. It sits in the cider area of my notes. It started in 2025, in the spring season, and the lead is the supplier contact. I am not the lead. I keep this summary so I can pick the project up after a gap and know where things stand without reading every other note.

The project covers taking the old Lendve cider setup apart and putting it back together in a cleaner, more reliable form. The press line, the fermentation corner and the bottling bench all had problems. Some parts were worn, some were badly laid out, and some were bodged together over several seasons. The rebuild is meant to fix the layout and replace the worn parts, so that a normal pressing day runs without me improvising around faults.

Because the supplier contact leads, a lot of the pace depends on when parts arrive and when the contact has time to talk things through. My part is to keep the records, do the hands-on work, and keep the questions in one place. This note is the short version. Details live in the linked notes, such as [[Nastae loft log]], where I record what happens in the loft store, and [[Triorkgend radio receiver plan]], which I used as a model for how to write a staged plan with clear hand-off points.

The current stage is mid-project. The teardown is finished, the new layout is agreed, and the main reassembly is under way. Finishing work, testing and the cleanup are still ahead.

## Checklist

This is the working list as it stands. Done items are ticked. Open items are not.

- [x] Walk through the old setup and note every fault
- [x] Agree the goal of the rebuild with the supplier contact
- [x] Clear the work area and move loose gear to the loft
- [x] Strip the old press line down to the frame
- [x] Sort salvageable parts from scrap
- [x] Draw the new layout on paper and check it against the room
- [x] Order the main replacement parts
- [x] Receive and check the main parts against the order
- [x] Fit the new frame and base
- [ ] Fit the pressing parts and check the alignment
- [ ] Rebuild the fermentation corner shelving
- [ ] Reconnect water and drainage
- [ ] Rebuild the bottling bench
- [ ] Run a dry test with water only
- [ ] Run a small real test with a little juice
- [ ] Clean down and sanitise everything
- [ ] Write up the final notes and update the loft log

Open points that do not fit neatly in the list:

- The drainage slope near the press is still a worry. It looks fine by eye, but I want to confirm it with water before I trust it.
- One of the shelving brackets arrived slightly different from what I expected. The supplier contact has said it should still work, but I have not confirmed it.
- I have not decided where the spare parts will live once the work is done. The loft is crowded already.
- The cleaning routine for the new layout is not written down yet. It should be, before the first real use.

## Next action

The next action is NX-6966. I should do it before anything else on the list, because the remaining steps depend on its result. When it is done I will tick it off here, update the checklist, and note any surprises in the loft log. If it turns out to need input from the supplier contact, I will send the question the same day so that waiting does not stall the rest.

## History

The project did not begin with a single clear moment. The old setup had been getting worse for a couple of seasons. Small repairs held for a while, then something else would fail in the middle of a pressing day. After one especially messy day, I wrote down every fault I could remember and found the list was long enough that patching no longer made sense.

I talked to the supplier contact about options. They knew the equipment, had supplied some of the original parts, and were willing to lead the work and advise on the layout. That gave the project its shape: the goal is rebuild, not replace everything. We kept what was sound and renewed what was not.

The work started in spring 2025. Spring was chosen because the cellar and loft are at their most usable then, the stored fruit from the previous autumn is gone, and the next pressing season is far enough off to leave room for mistakes. The teardown went faster than I expected, helped by taking photographs at every stage. Those photographs saved me more than once when I forgot how something had gone together.

The ordering stage was slower. A few parts had to be made or sourced specially, and the supplier contact had to chase them. During that gap I did the preparation jobs: cleaning, sorting, labelling boxes and drawing up the layout. When the main parts came, they matched the order apart from the bracket noted above.

Since then the work has been steady. The frame and base are in. The pressing parts are next, once the next action is complete.

## Schedule

The schedule is loose, because it follows the supplier contact and the arrival of parts rather than a calendar I control. The project began in spring 2025, and the plan has always been to finish well before the next pressing season, with time left for testing.

The order of work is:

1. Finish the next action.
2. Fit the pressing parts and check alignment.
3. Rebuild the fermentation shelving.
4. Reconnect water and drainage.
5. Rebuild the bottling bench.
6. Dry test with water.
7. Small real test with a little juice.
8. Clean down and write up.

Some of these can overlap. Shelving does not depend on the press, so I can do it on a day when I am waiting for the supplier contact to reply. Water and drainage should wait until the press is aligned, since moving the press afterwards would mean redoing the pipework.

The tests are not to be squeezed. A dry test costs nothing and tells me a lot about leaks. A small real test with a little juice tells me about flow, cleaning and handling. If either shows a problem, I fix it before moving on, even if that pushes the finish back. A slow finish is better than a rushed one that fails on the first big pressing day.

## Safety

Most of the hazards in this project are ordinary workshop ones, but cider work adds a few of its own.

- Lift heavy parts with a second person or a proper aid. The press frame and the base are heavy and awkward, and I do not move them alone.
- Wear gloves and eye protection when cutting, drilling or grinding. Metal and wood dust both get into eyes.
- Keep the floor dry and clear. Water, sugar and juice make surfaces slippery, and a slip near a press is a bad place to fall.
- Check that any pressing mechanism cannot move unexpectedly before putting hands near it. Lock it or release the pressure first.
- Keep electrical items away from water. Anything near drainage or wet areas should be protected, and I should not run an extension lead across a damp floor.
- Ventilate when fermenting. Fermentation gives off gas that can build up in a small closed space, so the fermentation corner needs fresh air movement.
- Use food-safe materials for anything that touches juice. Mixing in an unsuitable plastic or metal would ruin the cider and could harm someone.
- Sanitise before the real test, and again afterwards. This is a safety point as much as a quality one.
- Keep tools and loose parts off the stairs to the loft. The loft log has a note on this, and I should follow it.

If anything feels wrong while working, I stop and think. The project has no deadline that justifies an injury.

## Costs

I do not track exact figures in this note, only the shape of the spending. The money falls into a few groups.

- **Main parts:** the biggest group, covering the frame, pressing parts and bench components. These were ordered through the supplier contact.
- **Fixings and small items:** brackets, bolts, seals, clamps and fittings. Individually cheap, but they add up and I always need more than I think.
- **Plumbing and drainage:** pipes, joins and a few fittings for the water supply and the run-off.
- **Consumables:** cleaning and sanitising products, gloves, sandpaper, and replacement blades or bits.
- **Spare capacity:** a small allowance for the mistakes and surprises that every rebuild has.

The main parts are paid for. The remaining spending is mostly small and can be spread out. The biggest risk is a part that fails the test and has to be replaced, which is why I keep a little margin.

Where parts were salvaged from the old setup, I saved money but accepted a bit more risk. I only reused things that were clearly sound, and I wrote down which ones they were in the loft log so I can trace a fault if one fails.

## Decisions

The go decision date of Lendve rebuild is 2024-03-01. That is when I decided to commit to a rebuild rather than keep patching the old setup, subject to agreeing the approach with the supplier contact.

Other decisions that shaped the project:

- **Rebuild, not replace:** keep sound parts and renew only what is worn. This saves money and keeps the parts I already know how to work with.
- **Supplier contact leads:** they know the equipment and can source parts, so they set the pace and the technical direction. I handle the records and the hands-on work.
- **Spring timing:** do the work in spring, with the cellar and loft usable and the pressing season still distant.
- **Layout first:** agree the layout on paper before ordering or fitting anything, so parts are bought for the final arrangement.
- **Test in stages:** dry test, then a small real test, before any full pressing day.
- **Keep records:** photograph each stage and log changes, so I can undo or repeat steps later.

Decisions still open are the final home for spare parts and the written cleaning routine. Both can wait until the main work is done, but I do not want to forget them.

## Tools

The tools I use are mostly ordinary, with a few specific to this job.

- Spanners and sockets for the frame and fixings
- A drill and a set of bits, plus a hand driver for fiddly work
- A spirit level and a long straight edge for checking alignment
- A tape measure and a marker for the layout
- Clamps for holding parts while I fit them
- A saw and a file for trimming and tidying edges
- Pipe cutters and a few fittings for the water and drainage work
- Food-safe sanitiser, brushes and clean cloths
- A camera, which is my phone, for the stage photographs
- Labelled boxes and bags for parts, kept in the loft
- A notebook and this vault for records

The level and straight edge matter most. If the press is not true, everything built on it is slightly wrong, and cider work shows that quickly in leaks and uneven pressing.

The planning approach borrows from [[Triorkgend radio receiver plan]], where I broke a build into stages with a check at the end of each. I use the same habit here. For the physical record of what is stored where, I rely on [[Nastae loft log]].

## Overview

Lendve rebuild is a project in the cider area. Its goal is rebuild. It started in 2025, in the spring season, and the lead is the supplier contact. The go decision date is 2024-03-01.

The stage now is mid-project. The teardown is done, the layout is agreed, the main parts have arrived and the frame and base are fitted. What remains is fitting the pressing parts, rebuilding the shelving and bottling bench, reconnecting water and drainage, and testing everything in two steps before real use.

What is done: the fault survey, the agreement with the supplier contact, clearing the area, stripping the old line, sorting parts, planning the layout, ordering and checking the main parts, and fitting the frame and base.

Open points: the drainage slope, the slightly different bracket, where the spare parts will be stored, and the missing cleaning routine. None of these blocks the next action, but each needs closing before the project can be called finished.

The next action is NX-6966. After that comes the press fitting and alignment check, since the water and drainage work depends on it.

When the rebuild is finished I will update this summary, tidy the checklist, write the final record in the loft log, and note anything I would do differently next time. If the supplier contact has advice for future maintenance, I will add it here so the cider setup stays in good shape.
