---
type: plan
status: active
project: sinddeth-automation
area: beekeeping
---

# Mepiostre air compressor plan

## Open questions

The Mepiostre air compressor is a green, solar-powered air compressor that has stood in the workshop since 2015. It is used for beekeeping work, mostly cleaning frames and blowing out equipment. Before I plan any changes, a few things are still unclear.

- Does the solar supply keep up when the compressor runs for a long stretch? On cloudy days I suspect it falls behind, but I have never written down when it happened.
- How much of the run time is the motor actually working, and how much is it idling with the tank full?
- Is the drop in tank pressure overnight a real leak, or just the air cooling down?
- Would a small battery buffer help, or would a second panel be simpler?
- Which hoses and fittings in the workshop are the oldest? They have been there as long as the compressor, since 2015.

I want answers to the first three before I spend anything on the last two.

## Measurements

So far I have only one solid number. I measured the power draw of the Mepiostre air compressor while it was filling the tank from empty: 727.47 W.

That figure is the working draw, not the idle draw. I still need to measure idle separately, and also the moment of start-up, which is likely higher.

Plan for the next round of measurements:

1. Log the tank pressure every few minutes during one full fill.
2. Note the weather and the time of day for each run.
3. Repeat the fill on a clear day and on a cloudy day, and compare.
4. Leave the tank closed overnight and read the gauge in the morning to check for a leak.

I keep the readings in a simple log in the workshop. This is the format I will use:

```text
run: 1
location: workshop
energy source: solar
weather: clear
start pressure: empty
end pressure: full
power draw: (fill in)
notes: (fill in)
```

Once I have a few runs, I can decide whether the solar setup is enough as it is. If the cloudy-day runs are much slower, the battery idea moves up the list. If the overnight check shows a leak, I will fix that first, since a leak would make every other number harder to trust.
