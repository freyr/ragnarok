---
type: note
status: active
project: sinddeth-automation
area: beekeeping
description: "Note about Giordin solar charger."
---

# Giordin solar charger notes

## Risks

The Giordin solar charger is a black solar charger that sits in my workshop. It has been there since 2015, so age is the main risk I think about. Most of the problems I can foresee come from the years of sun, dust and temperature swings that the unit has been through.

- **Overcharging the battery.** If the regulator drifts or fails, the battery can be pushed past its safe voltage. This shortens its life and in the worst case causes swelling or leaking. I check the battery case for warmth and bulging whenever I pass it.
- **Deep discharge.** In a long run of dull weeks the charger may not keep up with the load. A battery left empty for a long time sulfates and loses capacity. I try not to run the beekeeping equipment from it in midwinter.
- **Moisture and condensation.** The workshop gets damp in autumn. Moisture on the terminals leads to corrosion and poor contact, which looks like a weak charger when it is really a bad connection.
- **Dust and wax residue.** Beekeeping work produces propolis dust, wax flakes and sticky smoke residue. A film on the panel cuts output more than I expect.
- **Fire risk from loose wiring.** A loose connection under load heats up. I keep the cables tied and away from anything that burns, including stored frames and foundation.
- **Shading creep.** A shelf, a new roof edge or a tree can slowly block the panel. I only notice it when the output has already dropped.
- **Wrong replacement parts.** After this many years, any spare I buy may not match the original. I note the specifications of what I install and do not guess.

## References

These are the sources I rely on when I need to look something up about this charger. I keep them short on purpose.

- The original paper manual that came with the charger, kept in the workshop drawer under the soldering tools.
- My own installation sketch from 2015, showing where the panel, the regulator and the battery were placed and how the cables run.
- Notes from other beekeepers in my local club, who use similar solar equipment for electric fences, lights and small pumps.
- The battery maker's general guidance on storage and charging, which I follow for temperature limits and resting voltage.
- My own logbook of repairs, where every change to the charger is written with the year and the reason.

When these disagree, I trust my own measurements first, then the manual, then everything else.

## Overview

The Giordin solar charger is a device of the kind solar charger. Its area is beekeeping, and I use it to keep batteries topped up for the small electrical jobs around the apiary. Its color is black, which makes it easy to spot on the workshop wall but also means the case gets hot in direct sun. Its energy source is solar, so it needs no mains connection at all. I installed it in 2015, and its location is the workshop.

In plain terms, a panel collects light, a regulator controls how much current goes into the battery, and the battery stores the energy for later. I use that stored energy for things such as a lamp for extracting honey in the evening, a small radio, charging handheld tools and powering a little pump when I move water. It is not a big system. It is meant to keep a modest battery healthy and to give me power in a building where running a cable would be a nuisance.

What I like about it:

- It has no running cost beyond the occasional part.
- It works quietly with no moving parts.
- It is simple enough that I can understand every connection.

What I dislike:

- Output varies a lot with the season.
- The panel needs regular cleaning in the busy months.
- It is old, and some of the labels have faded.

## Costs

I do not remember every price from 2015 and I do not want to invent figures, so this section describes the kinds of cost rather than amounts.

- **Purchase and installation.** The main cost was the charger itself in 2015, plus the mounting hardware, cable and a few fuses. I did the installation myself, so there was no labor charge.
- **Battery replacement.** This is the biggest recurring cost. Over the years the battery has needed replacing, and it will again. I treat it as a consumable and set money aside for it.
- **Small parts.** Fuses, terminal protection grease, cable ties and the occasional connector. Each is cheap, but they add up over a decade.
- **Cleaning supplies.** Soft cloth, mild soap and water. Nearly free.
- **Time.** A short check every month and a longer one each spring. This is the cost I notice most during the season, when I would rather be with the bees.
- **Avoided cost.** Having no electricity bill for this load, and no need to dig a trench or run a cable to the workshop, is what justifies the whole thing.

If the regulator fails, I will compare repair against replacing the whole unit. At this age, replacement is likely to make more sense, because finding matching parts is hard.

## Measurements

I take measurements to see whether the charger is still doing its job, and I write them down so that I can compare year to year. I use a basic multimeter and a plug-in power meter on the load side.

- **Measured power draw of Giordin solar charger: 127.96 W.**

That is the figure I recorded when I measured it with the load connected. I read it as the draw of the whole setup at that moment, not as a rating of the device. It is useful as a baseline. If a later reading under similar conditions is clearly different, something has changed, such as a failing battery, a dirty panel or a poor connection.

How I measure, so the readings can be compared:

1. Measure around midday on a clear day, with the panel clean.
2. Let the battery rest and settle before taking a voltage reading.
3. Connect the same load each time, so the comparison is fair.
4. Write down the weather, the time and what was switched on.
5. Take the reading after the system has run for a few minutes, not at switch-on.

Things I also look at without special numbers: whether the battery voltage rises during the day and falls slowly at night, whether the regulator indicator behaves normally, and whether the cables or the case feel unusually warm.

## Checklist

A short list I go through. I do the monthly items in the beekeeping season and everything in spring and autumn.

**Monthly**
- Look at the panel for dust, wax, propolis, bird droppings and leaves.
- Check that the regulator indicator shows normal operation.
- Feel the battery case and cables for unusual warmth.
- Confirm nothing new is shading the panel.

**Spring**
- Clean the panel with a soft cloth and mild soap.
- Inspect all terminals for corrosion and clean them if needed.
- Check that every cable is tied, undamaged and away from stored equipment.
- Re-measure the power draw and compare it with the baseline in the Measurements section.
- Test the battery under load and note how quickly it drops.

**Autumn**
- Check for damp in the workshop and look at the terminals again.
- Make sure the battery is fully charged before the dark months.
- Remove anything that has been stacked in front of the panel.
- Decide whether the battery will last another winter.

**After any change**
- Write the change, the year and the reason in the logbook.
- Take a fresh measurement.

## Maintenance

Maintenance on the Giordin solar charger is mostly gentle and regular. Because it has been working since 2015, I prefer small frequent jobs to big repairs.

**Cleaning the panel.** I wipe it with a soft damp cloth and a little mild soap, then rinse with clean water. I never scrub, and I never use anything abrasive. I clean it when the panel is cool, because cold water on a hot surface is a bad idea. Because the charger is black, it holds heat, so early morning or evening is the best time. In beekeeping season I clean it more often, since wax and propolis build up.

**Terminals and cables.** I disconnect the battery before touching the connections, clean any corrosion with a small brush, and apply a thin layer of protective grease. Then I reconnect and check that nothing is loose. I replace any cable with a cracked cover instead of taping it.

**Battery care.** I keep the battery in a dry place in the workshop, off the bare floor, and I keep it charged. If it will not hold charge or has swollen, I replace it straight away.

**Regulator.** I do not open it. I watch its behavior, and if the indicator acts strangely or the battery is clearly over or under charged, I treat it as the first suspect.

**Records.** Every job goes into the logbook with the year and the reason. When something goes wrong, the log usually tells me what I changed last.

**When to retire it.** If repairs become frequent, or if I cannot get compatible parts, I will replace the whole unit rather than keep patching an old one.
