---
type: research
status: active
project: sinddeth-automation
area: beekeeping
description: "Research about Kaesme Laerdond."
---

# Kaesme Laerdond tests

## Maintenance

These are my notes on keeping the working relationship with Kaesme Laerdond in good shape. Kaesme is my mentor in beekeeping. I have known Kaesme since 2024, and the contact has always been by phone. Kaesme is available on weekdays, so I plan my questions around that.

Keeping a mentor relationship going takes a little upkeep, just like a hive does. I do not want to call only when something has gone wrong. These are the habits I try to keep:

- Call on a weekday, never at the weekend, even when the problem feels urgent to me.
- Write down my questions before dialling, so the call stays short and useful.
- Keep a short log of what was advised and what I did about it.
- Report back after a few days on how the advice worked out.
- Say thank you in a concrete way, for example by bringing a jar of honey when we meet.

The log matters most. In my first year I forgot half of what I was told. Now I write the advice down in plain words within an hour of the call. Later I can see which advice paid off and which I misunderstood.

I also keep a rough rhythm. In the active season I call more often, mostly about inspections, swarming and feeding. In winter the calls are fewer and are about stores, ventilation and mouse guards. I try not to make a call longer than I need to, because I know weekdays are busy for a person who also keeps bees.

## Lessons

The main lessons from working with Kaesme since 2024, written as I understood them.

First, look before you act. Kaesme always asks what I saw in the hive before saying what to do. If I cannot describe the brood pattern, the stores or the mood of the bees, the advice is vague. So I now take notes at the hive, not afterward.

Second, small changes are better than big ones. When I wanted to rearrange a whole colony in one visit, I was told to change one thing and wait. That has saved me from several mistakes.

Third, do not copy another beekeeper's calendar. Local weather and forage decide the timing. Kaesme gives me ranges and signs to watch, not fixed dates.

Fourth, ask about the reason. When I ask why, the answer usually contains something I can apply to the next problem. A bare instruction helps only once.

Fifth, phone calls work well for this. Describing a problem aloud forces me to be clear. Several times I solved my own question halfway through explaining it.

Sixth, keep records. Kaesme is firm that a beekeeper without notes repeats the same year over and over. I write down dates of inspections, queen status, feeding and treatments in my own notebook.

Seventh, accept that bees do not follow the book. Some advice fits one colony and not the next. I treat advice as a starting point and adjust to what the bees show me.

## Open questions

Things I still want to ask Kaesme or work out myself.

- How should I judge when a colony is too weak to go into winter, and when is it worth combining?
- What is the best way to split a strong colony when I have limited equipment?
- How early can I reliably tell that a colony is preparing to swarm?
- Is it worth raising my own queens, or should I keep buying them?
- How do I decide how much honey to leave for the bees in a poor season?
- Would Kaesme be willing to visit my apiary once on a weekday, rather than only talk by phone?
- How should I set up my notes so that advice is easy to find months later?

I also want to ask how Kaesme learned all this. Was it from a mentor, from books, or from many years of mistakes? The answer may tell me how to plan my own learning.

## Quotes

Here I keep what I have been told that is worth remembering, and a record of a quoted price.

The quoted price of Kaesme Laerdond: 828.63 EUR. I wrote this down as the figure that came up when I asked what a full set of equipment would cost me. I have not yet decided whether to accept it, so I treat it as a reference point and not as a commitment.

Sayings I remember, in my own words and not word for word:

- Look first, then touch the hive.
- If you are unsure, wait a few days. The bees will still be there.
- A weak colony tells you early; you only have to listen.
- Do not treat by habit. Treat because you checked.
- Write it down, or it did not happen.

I keep these in a short list near my notebook so I can read them before an inspection. They are simple, but I forget them quickly when I am standing in front of a hive with smoke in my hand.

## Setup

My beekeeping setup, and how I arranged it so that advice from Kaesme can be used easily.

The apiary is small. I keep the hives on stands, facing away from the prevailing wind, with a clear flight path in front of each one. Kaesme suggested this early on, and I have not changed it. There is a bit of shade in the afternoon and full sun in the morning, which helps the colonies get going early.

Around the hives I keep a working area. It has a small table for tools, a place to set down frames, and a bucket for scraps of wax and propolis. I try to keep the working area tidy, because a messy one slows me down and makes me careless.

For communication, I keep my phone charged and close, with a list of my questions in a note. Because Kaesme is available on weekdays, I try to inspect on weekdays when I can, so that I can call straight after if something puzzles me. When I inspect at the weekend, I note the questions and wait for Monday.

The notebook is the center of the setup. Each hive has its own page, with a short history, the queen's status, and what I did at each visit. When I call, I read from the page for the hive in question.

## Ideas

Ideas I have collected while working with Kaesme.

- Ask Kaesme to review my notebook once a season and tell me what I am missing.
- Keep a simple list of "signs and what they mean" that grows with each call.
- Arrange one weekday visit at the apiary, so advice can be about the real layout and not my description.
- Start a small experiment with a second hive type, but only after talking it through.
- Make a seasonal checklist based on the advice I have received since 2024.
- Record a short voice memo after every inspection, then turn it into notes in the evening.
- Offer to help Kaesme with a task in return, such as extracting honey or moving equipment.
- Build my own nucleus box to practice splits on a small scale.

None of these are decided. I want to try the notebook review first, since it costs nothing and may expose gaps quickly.

## Tools

The tools I use, and some that Kaesme has recommended.

For the hive itself: a hive tool, a smoker with fuel that burns cool, a bee brush, a veil and gloves. Kaesme said the hive tool is the one item not to economize on, because a poor one makes every inspection harder.

For records: a paper notebook with a page per hive, a pen on a string, and a phone for photos. Photos help when I want to describe something on a call, but the call itself is the main tool. A phone is how I reach Kaesme, and that suits both of us.

For feeding and winter: a feeder that does not drown bees, spare entrance reducers, and mouse guards. For checking: a flashlight, a small mirror for looking under frames, and a simple scale to judge weight of a hive in autumn.

For handling honey: a knife for uncapping, a strainer, clean buckets with lids and jars. I borrow larger items rather than buy them, since I only need them a few days each year.

I keep a short list of what is in my kit, so I can see at a glance what is missing before a visit.

## Background

Kaesme Laerdond is my mentor in beekeeping. I have known Kaesme since 2024. The contact is by phone, and Kaesme is available on weekdays.

I first got in touch when I had my first colony and no idea what I was looking at. I had read books, but books do not tell you what a worried colony sounds like. A friend of a friend suggested that I call, and Kaesme agreed to answer questions. That informal arrangement turned into a regular mentoring relationship.

Since then the topics have changed. In the beginning I asked about the basics: how to light a smoker, how to find the queen, how often to inspect. Later I moved on to swarm control, feeding decisions, treatment timing and winter preparation. The questions are now more specific, and so are the answers.

I think the relationship works for a few reasons. I come prepared. I follow up. I do not ask Kaesme to decide for me; I ask for the reasoning, then I decide. And the phone format keeps things light, so neither of us feels it is a big commitment.

This note is partly a record of that background, and partly a place to gather what I have learned so that I can find it again.

## Checklist

A checklist for calling Kaesme and for acting on the advice.

Before the call:

- It is a weekday.
- I have written down my questions in order of importance.
- I have my hive notes open at the right page.
- I know what I saw, not only what I think it means.
- I have a pen ready.

During the call:

- Describe the situation in plain terms first.
- Ask why, not only what.
- Repeat the advice back to check I understood.
- Ask what to watch for afterward.

After the call:

- Write the advice in the notebook within an hour.
- Note when I plan to act and when I will check the result.
- Report back to Kaesme after a few days.
- Update the hive page and any related notes.

At the hive:

- Light the smoker before opening anything.
- Work calmly and make as few moves as possible.
- Close up quickly and record what I found.

## Safety

Safety notes, mostly things Kaesme has repeated until I remembered them.

Wear protective clothing every time, even for a quick look. A single careless visit is how most stings happen. Make sure the veil is fastened and gloves cover the wrists. Check for gaps in clothing before approaching.

Know how you react to stings. If someone has had a strong reaction before, they should not work bees alone, and should have a plan. Tell someone when you are going to the apiary and when you expect to be back.

Use smoke gently. Too much agitates the bees and can damage the colony. Keep the smoker in a safe place, away from dry grass, and make sure it is fully out before leaving.

Lift with care. A full box is heavy, and back injuries are common. Bend the knees, ask for help, and do not rush.

Keep visitors, children and pets at a distance from the hives. Explain to anyone near the apiary where the flight path is and why they should not stand in it.

Handle treatments according to their instructions, and wear the recommended protection. Store them away from food and out of reach of children.

Finally, if I am unsure, I stop and call. Since Kaesme is available on weekdays, I try to plan risky tasks for those days so help is easy to get.

## Costs

Money matters in a hobby like this, and I track it so there are no surprises.

The largest costs are the initial equipment: hives, frames, protective clothing and tools. After that come the recurring costs: feed, treatments, replacement frames, and occasionally a new queen. Jars and labels add up when the harvest is good.

The quoted price of 828.63 EUR, noted in the Quotes section, is a reference for a full equipment set. I compare it against what I would pay by buying items one by one, and against what I could get second-hand. Kaesme warned me that second-hand hive boxes can carry disease, so I would inspect anything carefully and not buy old frames at all.

Things I do not skimp on: protective gear, a good hive tool, and treatments. Things I try to save on: borrowing large extraction equipment, making my own simple items, and sharing bulk purchases with other beekeepers.

My approach is to buy in stages. First what I need for the next few months, then more as the colonies grow. This spreads the cost and lets me learn what I actually use before buying more. Kaesme's advice was to resist buying gadgets in the first years.

The mentoring itself costs me nothing except time and a jar of honey now and then.

## References

Sources I rely on, in rough order of how useful they are.

- Kaesme Laerdond, my mentor in beekeeping, reached by phone on weekdays. Known since 2024. By far the most useful reference, because the advice is specific to my situation.
- My own notebook, with one page per hive and a record of every inspection.
- A general beginner's book on beekeeping that I bought in my first year. Good for basics, weak on local conditions.
- Notes from local beekeeper meetings, where I picked up practical tips about forage and timing.
- Observations from my own apiary, which I treat as evidence in their own right.

I treat written sources as background and Kaesme's advice as the working reference. Where the two disagree, I ask why. Usually the difference comes from local conditions, and the explanation is worth recording.

I also keep notes about which sources I trust for which topics. Books for anatomy and life cycle, Kaesme for decisions, the notebook for my own history.

## Supplies

Supplies I keep on hand, and what I check before each season.

- Spare frames and foundation or starter strips.
- Feed for emergencies, plus a clean feeder.
- Fuel for the smoker, kept dry.
- Treatments, stored properly and checked for expiry.
- Spare gloves and a spare veil.
- Entrance reducers and mouse guards.
- Jars, lids and labels for the harvest.
- Clean cloths, a bucket and a small container for scraps of wax.
- A basic first aid kit kept at the apiary.

Before each season I go through the list and mark what is low. I order early, because suppliers get busy in spring. Kaesme suggested keeping at least one spare box ready, so that I can react quickly if a swarm appears or a colony needs more room.

I store everything dry and off the ground. Wax and frames attract pests, so I keep them sealed. Once a year I clear out anything damaged or old.

## Risks

Risks I think about, and how I try to manage them.

The first risk is losing a colony, in winter or through disease. I reduce it by checking stores, treating on time and asking Kaesme when a colony looks weak. I accept that some losses will happen anyway.

The second is swarming. A swarm takes half the bees and annoys neighbors. I watch for early signs, give room in time, and ask for advice by phone on weekdays when I see queen cells.

The third is acting on advice I did not fully understand. To manage this, I repeat the advice back and write it down. If something is unclear, I call again.

The fourth is depending too much on one person. Kaesme is generous, but is only available on weekdays and may be busy. So I also build my own skills, keep my notes, and attend local meetings to meet other beekeepers.

The fifth is spending too much on equipment too early. I buy in stages and compare prices before committing.

The sixth is personal safety: stings, heavy lifting and treatments. I follow the safety notes above and never work alone if I can avoid it.

Finally, there is the risk of losing interest after a bad season. The mentoring helps, because someone who has seen many bad seasons can tell me that they pass.
