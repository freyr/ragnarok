---
type: drivers
status: active
project: sinddeth-automation
area: beekeeping
---

# Drivers of Sinddeth automation

## Supplies

Sinddeth automation is a summer project that started in 2025. Its goal is automation, it sits in the beekeeping area, and the mentor leads it. The aim is to cut down manual hive checks, so most of what I buy is for sensing and for powering the sensors in the field.

| Item | Purpose | Priority |
|---|---|---|
| Hive sensors | Track weight and temperature | High |
| Solar panel and battery | Power in the apiary | High |
| Weatherproof boxes | Protect the electronics | Medium |
| Spare cables | Repairs during the season | Low |

## Budget

The budget of Sinddeth automation is 11923.02 EUR. Success is measured by how many hive visits I can skip without missing a problem, judged at the end of the summer season. If spending drifts, I drop the low-priority items first and keep the sensors and power.
