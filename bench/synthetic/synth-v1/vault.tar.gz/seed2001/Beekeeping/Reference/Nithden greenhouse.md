---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Nithden greenhouse."
---

# Nithden greenhouse

## Supplies

Nithden greenhouse is a large, north-facing greenhouse at ground level, built in 2023 and used for the beekeeping work. I keep everything for hive care and honey handling here, so the supplies are worth listing in one place.

- Spare hive boxes (brood boxes and shallow supers), stacked on pallets along the east wall
- Frames with wired foundation, plus a box of loose frames that need repair
- Smoker, spare smoker fuel (dry burlap and pine shavings), and matches in a sealed tin
- Hive tools, two of them hung by the door and the rest in the toolbox
- Veils, jackets and gloves in three sizes, kept on hooks near the entrance
- Feeding gear: syrup buckets, entrance feeders, and sugar in sealed bins
- Uncapping knife, uncapping tray, and the hand-turned extractor
- Clean jars, lids and labels for bottling
- Treatment supplies for mite control, stored in the closed cabinet away from the honey
- First-aid kit and antihistamine tablets, checked at the start of each season

Anything sticky goes back into a lidded tub straight after use. Open sugar attracts wasps and ants quickly, even in a building this size.

## Risks

The main risks I have noticed since 2023 are these:

- **Robbing.** Open honey or syrup inside the greenhouse draws bees from outside. I keep the vents screened and never leave frames out uncovered.
- **Overheating.** Because the structure is glass or clear panel, the inside heats up fast on sunny days. The north orientation helps, as direct sun is gentler, but warm afternoons still push the temperature up. Wax softens and frames can sag if left on a shelf near the roof.
- **Stings in a closed space.** Loose bees inside a building are harder to deal with than in the open. I always work with the veil on and keep the doors shut behind me.
- **Damp and mould.** Stored boxes and frames can go mouldy if the ground-level floor stays wet. I sweep out water and let the floor dry.
- **Chemical mix-ups.** Treatments must stay apart from food-grade equipment. The cabinet is labelled and locked.
- **Slips.** Spilled syrup on the floor is slippery. I wipe it at once with a damp cloth.
- **Pests.** Mice like stored frames and sugar. Bins stay closed and traps stay set along the walls.

## Dimensions

The facts of the building, for reference:

- Kind: greenhouse
- Area of use: beekeeping
- Orientation: north
- Size: large
- Year built: 2023
- Floor: ground level
- Floor area: 178.71 m²

With a floor area of 178.71 m², there is room to separate the work into zones. I use the west side for equipment repair and frame assembly, the middle for extraction and bottling, and the east wall for stacked boxes. A clear walkway runs down the centre so I can carry a full super without turning sideways. Because the greenhouse sits at ground level, wheeling a trolley in from outside needs no ramp, which makes moving heavy boxes much easier on the back.

## Schedule

My working rhythm through the year looks like this.

**Early spring.** Clean out the greenhouse, check every box for damage, repair frames, and restock the first-aid kit. Inspect the smoker and replace worn bellows if needed.

**Late spring.** Assemble new supers and add foundation. Prepare feeders for any colonies that look light. Keep the vents screened.

**Summer.** Extraction season. I uncap, spin, filter and bottle in the middle zone. I try to finish before the afternoon heat, since honey flows better when warm but the greenhouse gets uncomfortable. After each session I wash the floor and tools.

**Early autumn.** Apply mite treatments, in the cabinet-controlled routine, and finish any remaining bottling. Start feeding syrup where stores are short.

**Late autumn.** Clean and dry all equipment. Stack boxes off the floor, set mouse traps, and wrap or cover anything that will sit unused.

**Winter.** Light checks only: look for damp, test the traps, and plan next year's purchases. I make a short list of repairs for the quiet weeks.

Every week during active season I do a quick walk-through to look for spills, pests, and anything out of place.

## Checklist

Before I leave Nithden greenhouse after any session:

- [ ] Doors and vents closed and screens intact
- [ ] All frames covered or returned to boxes
- [ ] Syrup and honey in lidded containers
- [ ] Floor swept and any spills wiped
- [ ] Smoker fully out and stored safely
- [ ] Hive tools cleaned and hung up
- [ ] Veils, jackets and gloves hung to dry
- [ ] Treatment cabinet locked
- [ ] Mouse traps checked and reset
- [ ] Boxes stacked off the damp floor
- [ ] Notes written on what was done and what is needed next time

Before the season starts, I also confirm that the first-aid kit is complete, the extractor turns smoothly, and the jars and lids are clean and counted. If any item is missing, I add it to the shopping list the same day so it does not get forgotten.
