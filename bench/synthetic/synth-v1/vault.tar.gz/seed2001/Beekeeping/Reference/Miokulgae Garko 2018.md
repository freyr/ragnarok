---
type: reference
status: archived
project: reference
area: beekeeping
description: "Reference about Miokulgae Garko."
---

# Miokulgae Garko 2018

## Schedule

This note records how things stood in 2018. Later notes replace these values, so do not treat it as current.

Miokulgae Garko is a plumber. I have known him since 2012. The area I connect him with in my notes is beekeeping, because most of our talks over the years ended up being about hives, honey and the apiary rather than pipes.

He is available on weekdays. I never tried to book him for a weekend, and when I asked once about a Saturday he said it would have to wait until Monday. So I plan around the working week.

The way to reach him is in person. He does not answer messages reliably, so I stopped writing to him. If I need him, I go to where he is working or stop by when I know he is around. This costs me some time, but it has worked every year since 2012.

My usual routine in 2018 looked like this:

- Decide early in the week whether a job needs him.
- Go and find him on a weekday and describe the problem face to face.
- Agree on a day, again for a weekday.
- Keep the day free, because he sometimes arrives earlier than planned.

Because we talk in person, I try to have the details ready before I see him: where the leak or fault is, how long it has been going on, and what I have already tried. He likes short, clear descriptions and does not enjoy long stories, unless the story is about bees.

## Tools

I do not know his whole kit, only what I have seen him use on my jobs. This list is from memory and is incomplete.

- Pipe wrenches in a few sizes, which he keeps in a worn canvas roll.
- A pipe cutter for copper and a hacksaw for anything stubborn.
- Sealing tape and a small tin of jointing paste.
- A basic torch for soldering joints.
- A bucket and several old towels, which he always sets out before opening a line.
- A flashlight he wears on his head when he works under a sink.

He also carries a few spare fittings in a box: elbows, short connectors, and a handful of washers. If a job needs something he does not have, he says so and goes to get it, and the visit simply takes longer.

For my own side of things, I keep the area under the sink clear, shut off the water if I know where the valve is, and leave a lamp nearby. I once lent him a small bee smoker as a joke, to chase away wasps from a work site near the apiary. It worked better than expected, and he still brings it up.

Things I would like to check next time I see him:

- Whether he can work on older pipes that are no longer standard.
- Whether he would look at the water setup near the hives.
- What he would use for a long outdoor run.

## Quotes

The only quote I have on record in this note is the one he gave for the larger job I discussed with him in 2018.

- Quoted price of Miokulgae Garko: 8524.24 EUR

He gave the figure in person, as usual, and I wrote it down straight after. I did not ask him to split it into labour and materials, so I cannot say how much of it covers parts and how much covers his time. He said the quote assumed normal weekday working hours and no surprises behind the walls.

A few points about how he handles quotes, from what I have seen:

- He gives a figure only after he has seen the place himself.
- He does not like to quote over the phone, which fits with his preference for meeting in person.
- If the work turns out to be different from what we discussed, he tells me before going ahead rather than after.
- He is open to talking about the order of the work if it helps me spread the cost.

Since this note is archived, the price above is the 2018 state only. Any later quote belongs in a newer note, and it replaces this one instead of being added to it.
