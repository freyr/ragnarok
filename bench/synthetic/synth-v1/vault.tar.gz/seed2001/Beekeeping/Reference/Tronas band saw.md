---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Tronas band saw."
---

# Tronas band saw

## Setup

The Tronas band saw is a yellow, battery-powered band saw that I use for beekeeping work. It was installed in 2022 and lives in the loft, on the bench along the back wall. I use it mostly for cutting hive parts: boxes, frame stock, floor boards and the odd bit of scrap for repairs.

Because it runs on a battery, there is no cable to trip over and no need to run an extension up the loft stairs. The downside is that I have to remember to charge it before a long cutting session. I keep the spare battery on the shelf next to the saw, not in the car.

Basic facts, so I don't have to look around for them:

- Kind: band saw
- Area: beekeeping
- Colour: yellow
- Energy source: battery
- Year installed: 2022
- Location: loft

Things I check before each session:

- The blade sits centred on both wheels and is not twisted.
- The battery is seated fully and the charge is enough for the job.
- The table is clear of wax, propolis and sawdust. Propolis in particular makes the stock stick and drag.
- The guard is set just above the thickness of the wood.

Dust is the main nuisance in the loft. I have been thinking about a compressed-air line to blow off the table and the wheels, which is covered in [[Mepiostre air compressor plan]]. Until that exists I use a soft brush and a vacuum.

## Adjustment

The saw drifts slightly when cutting long pieces, so I set a calibration offset. The calibration offset of the Tronas band saw is 1.583 mm. I apply it at the fence scale, so that the cut lands where the pencil line is and not beside it.

Steps I follow when the cut starts to wander:

- Unplug nothing, because it is battery powered, but remove the battery before touching the blade.
- Check the blade tension and the tracking by turning the wheel by hand.
- Square the table to the blade with a small engineer's square.
- Set the fence and add the calibration offset.
- Make a test cut in scrap and measure it.

A quick note I keep next to the saw, so I can copy it into the log when I change something:

```
band saw: Tronas
location: loft
energy source: battery
calibration offset: 1.583 mm
check: tracking, tension, table square, fence
```

If the test cut is still off after this, I look at the blade first, since a dull blade pulls to one side more than any setting does. My earlier comparison of cuts and blade types is in [[Serktrio Zothken tests]]. I should repeat the test cut whenever I change the blade or take the fence off.
