---
type: reference
status: active
project: reference
area: beekeeping
---

# Brethgleth loft

## Lessons

- Keep the west-facing door shaded in the afternoon. Low sun comes straight down the stairs and warms the first few metres of the room more than I expected.
- Do not trust the floor temperature alone. The room is below ground, so the walls stay cool, but the air near the ceiling can still drift warm when the door is open.
- Wax dust from the band saw gets into everything. I now cover the frame stock before cutting and sweep before I move any comb.
- Write down every change to the layout. In 2020 I moved the bench and forgot to note it, and for weeks I could not explain a change in the readings. The notes in [[Tronas band saw 2020]] are the only reason I worked it out.

## Open questions

- Is the medium size of the loft right for the amount of frame work I now do, or should the extraction work move to another room?
- Would a small solar supply help the lights and the logger? I have sketched it in [[Perkgon solar charger plan]] but have not costed anything.
- Why does the west corner stay a little damper than the rest of the room in wet weeks? I suspect the wall, but I have no proof.
- Do I need a second dehumidifier, or is better airflow enough? The comparison in [[Glurkolel dehumidifier study]] is not finished.

## Equipment

The installed device of Brethgleth loft is the Drilses band saw. It is fixed near the bench on the north side and is used for cutting frame parts and trimming boards.

Other things kept in the loft:

- A long bench with a vice at one end.
- Shelves for empty frames and spare boxes.
- Two work lamps on hooks.
- The [[Liolkrios data logger]], which records temperature and humidity on the wall near the stairs.
- A broom, a dustpan and a small hand brush for the saw area.

I keep the saw clean and check the blade guard before each session. Blades are stored flat in a drawer under the bench.

## Overview

Brethgleth loft is a place, and its kind is loft. It belongs to the area of beekeeping. The loft is oriented west, its size is medium, and it was built in 2016. Its floor is below ground, which is unusual for a loft and the main thing to remember about it.

In practice it is my cutting and storage room for hive parts. Because it is below ground it stays cooler in summer and does not freeze as hard in winter as the sheds above. The west orientation means the entrance gets evening light, which is useful for finishing work late in the day.

I use it mostly from late winter to early spring, when I prepare frames and boxes for the new season. In summer it is mostly storage, and in autumn I use it for cleaning and putting equipment away.

## Supplies

What I keep here, and roughly how I handle it:

- Spare frames and foundation sheets, stored flat and covered.
- Unassembled hive boxes and lids, stacked on the shelves.
- Wood glue, small nails and a few clamps.
- Cloths and tubs for cleaning.
- Spare bulbs and a roll of cable ties.

I do not keep honey or syrup here. Anything sweet attracts pests, and the loft is too close to the stairs for me to be comfortable with that. Wax is kept in closed boxes only.

Plant and tray supplies for the garden are kept elsewhere; see [[Lioder greenhouse notes]] for that arrangement.

## Observations

- The air is steady and cool through most of the year. Being below ground evens out the daily swings.
- Humidity rises after long rain. The wall on the west side is the first place I see it.
- Dust settles quickly around the band saw, so I clean the bench after every session.
- The stairs act like a chimney. Opening the door at the top changes the air in the room within a short time.
- Results from the earlier trials in [[Zaedith Gerknand tests]] and [[Serktrio Zothken tests]] fit this picture. In both, the loft held its conditions better than the sheds did.

I check the logger every couple of weeks and copy the readings into my notes. If something looks odd, I compare it with what I did that day before assuming a fault.

## Background

The loft was built in 2016 as part of a general tidy-up of the working buildings. The idea was to have one stable room for woodwork and storage that did not depend on the weather. The below-ground floor was chosen for that reason, and the west orientation was a result of where the entrance could go.

At first it held only shelves and a bench. The band saw came later, once I was making more of my own frame parts and no longer wanted to cut them by hand. Since then the layout has changed a few times, mostly to give the saw more clearance and to keep the walkway to the stairs clear.

The loft is small compared with a full workshop, but medium is the right word for how it feels in use. It holds what I need and not much more, which keeps me from letting clutter build up. I still think of it as a working room first and a store second, and I try to keep it that way.
