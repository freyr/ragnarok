---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Mastend Runpith."
---

# Mastend Runpith

## Maintenance

Mastend Runpith is my mentor in beekeeping. I have known him since 2010, and the relationship needs a bit of upkeep like any other. This section is how I keep it working.

He is reached by phone. He does not answer email reliably and he does not like messages that need long replies. A short call works better than anything written. He is available on weekends, so I plan around that and do not try to reach him on weekdays.

What I do to keep the contact healthy:

- Call on a weekend morning, not late in the evening.
- Keep a short list of questions ready before I dial, so the call stays useful.
- Write down his answers straight after the call, while I still remember the details.
- Return what I borrow, and say thanks when a piece of advice saves a colony.
- Do not ask for the same thing twice if I already have it in my notes.

The table below is a quick summary of the facts I need most often.

| Property | Value |
|---|---|
| Name | Mastend Runpith |
| Role | mentor |
| Area | beekeeping |
| Contact | phone |
| Availability | weekends |
| Known since | 2010 |

Some of my other projects touch his advice indirectly. When I was planning the sensor for hive weight and water level, I used his notes on seasonal timing, and that work is in [[Starklil level sensor plan]]. For powering equipment at the far apiary, I follow [[Trildeth solar charger handbook]]. When I built wooden frames and boxes, I compared his habits with what I found in the [[Lisdrior band saw study]].

A simple log of my calls helps me see patterns. I keep it in a plain text file:

```text
call log - Mastend Runpith
contact: phone
slot: weekend
topic: spring inspection timing
result: wait for steady warm days, check brood first
follow-up: call again after first flow
```

## Quotes

Money questions come up rarely with him, since most of what he gives me is advice and not a service. Still, he once gave me a price for a full day of hands-on help and a set of tools to go with it.

- Quoted price of Mastend Runpith: 3933.32 EUR

I did not accept straight away. I wanted to think about whether I needed the full package or only part of it. In the end I asked him which items mattered most, and he was honest about it.

Things he has said that I want to keep:

- "Look at the bees before you look at the book."
- "A weak colony tells you early, if you are willing to listen."
- "Do less, but do it at the right time."
- "Write it down, or you will remember it wrong."

I find the last one the most useful, which is why this note exists at all. His advice is short, and it usually fits in one sentence. The hard part is acting on it at the right moment, not understanding it.

## History

I met Mastend Runpith in 2010. At that time I had a single hive and very little idea of what I was doing. He was the person who looked at it and told me plainly what I was doing wrong. That honesty is the reason I kept calling.

In the early years the contact was occasional. I called when something went wrong: a swarm leaving, a colony that would not build up, or a hive that went quiet in winter. Over time the calls became more regular, and I started calling to ask what to prepare, not only what to repair.

Over the years he has shaped how I work in a few clear ways:

1. I inspect less often, but with a clear purpose each time.
2. I keep records of every visit to the hives.
3. I prepare equipment well before the season starts.
4. I treat weekends as the natural time for beekeeping work, which suits his availability as well.

I still treat him as a mentor and not as a friend I can call about anything. That distinction keeps the relationship simple. He gives guidance, I do the work, and I report back on how it went. Reporting back is something he appreciates, and it often leads to the next useful piece of advice.

If I ever need to find the thread again, the plan is simple: pick up the phone on a weekend, start with the results of the last advice, and then ask the next question.
