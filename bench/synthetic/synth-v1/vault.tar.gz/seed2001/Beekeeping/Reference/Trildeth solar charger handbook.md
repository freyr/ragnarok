---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Trildeth solar charger."
---

# Trildeth solar charger handbook

## Checklist

This is the working checklist for the Trildeth solar charger. It is a red solar charger that I use for beekeeping, and it lives in the workshop. I installed it in 2018. One odd detail I always have to remind myself of: the energy source is listed as mains, so despite the name, the unit is fed from the wall socket in the workshop and not from a roof panel. Keep that in mind whenever I think about where the power comes from.

Use this list before every season and after any change in the workshop.

**Before the season starts**

- Look at the red housing for cracks, dust, wax drips and propolis smears. Wipe it with a dry cloth.
- Check that the mains lead is not pinched, not frayed and not lying across a path where I walk with hive boxes.
- Confirm the plug sits firmly in the socket and the socket is not loose in the wall.
- Check that the charger sits on a dry, flat surface, away from the honey buckets and the water tap.
- Make sure the vents on the housing are free. Wax moth debris and sawdust collect there more than anywhere else.
- Plug in a battery that I know is healthy and watch whether the charger starts normally.
- Write the result in the log at the bottom of this section.

**During the season**

- Once a week, touch the housing after an hour of charging. It should be warm, never hot.
- Once a week, look at the cable ends for discoloration.
- After every extraction day, wipe the unit, because honey mist gets everywhere in the workshop.
- Do not leave the charger running overnight when I am away.

**After the season**

- Unplug it from the mains and leave it unplugged over winter if the workshop is not heated.
- Clean the contacts with a dry brush.
- Cover the unit loosely with a cloth, not with plastic, so no moisture is trapped.
- Note any odd behaviour in the log so I remember it in spring.

**Log format**

I keep a short text log next to the charger. Each entry is one line. This is the style I use:

```
check: preseason
housing: clean, no cracks
mains lead: ok
vents: cleared of sawdust
test charge: started normally
notes: socket slightly warm, watch it
```

The point of the log is to see changes over the years. A charger installed in 2018 has a long history, and small drifts only show up when I compare entries.

## Ideas

These are things I might do to make the setup better. None of them is urgent.

**Better placement in the workshop**

The charger currently sits where it was convenient in 2018. The workshop has changed since then, with more shelves, a bigger extractor and a second bench. A new spot could be higher on a wall shelf, away from honey spills and away from the floor where dust settles. A shelf near the socket would also shorten the mains lead, which means less lead to trip over.

**A simple cover**

A small hood made of thin plywood, open at the front and back, could keep wax flakes and drips off the red housing while still letting air through. I would paint the inside and leave a gap above the vents.

**Labels**

I could add a label on the housing with the basic rules:

- Unplug when not in use.
- Do not cover while charging.
- Keep dry.

It sounds trivial, but when I come in with sticky hands and hurry, a label helps more than memory.

**A tidier routine around beekeeping tasks**

- Charge batteries on the day before a hive inspection, not on the morning of it.
- Keep a spare charged battery in the workshop for the electric tools I use with frames and boxes.
- Group charging with other quiet jobs, like cleaning frames, so I am nearby and notice if something smells or sounds wrong.

**A switched power strip**

Putting the mains plug on a strip with a switch would let me cut power with one move. A strip with a surge guard might also protect the unit from spikes. I should check that the strip is rated well above what the charger draws and that it is mounted off the floor.

**Better record keeping**

- Take a photo of the charger every spring, from the same angle, to see ageing of the housing.
- Keep a short list of what I have charged with it and how it behaved.
- Record the room temperature when something goes wrong, since the workshop gets cold in winter and hot in summer.

**Longer-term thoughts**

Since the energy source is mains, I sometimes think about whether a true solar setup would make sense for the apiary itself. That would be a separate project and not a change to this device. For now the unit stays where it is, doing its job in the workshop.

## Tools

This section lists what I use to look after the charger and what I keep close to it.

**Cleaning**

- Soft dry cloth for the red housing.
- Small dry brush, like a paintbrush with the paint long gone, for vents and contacts.
- A hand vacuum with a soft nozzle for sawdust and wax flakes. I never use the vacuum while the unit is plugged in.
- Cotton swabs for tight corners around the connectors.
- A little isopropyl alcohol on a cloth for propolis on the housing, used only when the unit is unplugged and fully dry afterwards.

**Checking**

- A multimeter, set to the right range, to check that the output is steady and that a battery is not dead before I connect it.
- A plug-in socket tester to confirm that the workshop socket is wired correctly.
- A torch, because the corner of the workshop where the charger sits is dim.
- A notebook or the text log I keep beside the unit.

**Fixing and securing**

- Screwdrivers that fit the housing and the plug.
- Cable ties and a few small clips to hold the mains lead along the shelf edge.
- Electrical tape for temporary marking only, never as a repair for a damaged lead.
- Spare fuses of the correct type for the plug, kept in a labelled tin.

**How I use the multimeter**

I do a quick check in the same order each time, so I do not skip anything:

1. Unplug the charger and look at the lead.
2. Plug it in without a battery and check that the indicator behaves as expected.
3. Measure the output at the connector, with the probes held carefully so they cannot touch each other.
4. Connect the battery, wait a few minutes and measure again.
5. Disconnect and write the readings in the log.

If the readings differ a lot from the last entry, I stop and look into it before charging anything else.

**Things I do not use**

- No water or damp cloths on the unit.
- No sprays near the vents.
- No metal scrapers on the housing, because they scratch the red finish and can slip into the vents.

## Risks

The main risks come from the place where the charger lives and the work I do around it. The device is a red solar charger for beekeeping, installed in the workshop in 2018, and its energy source is mains. That last point shapes most of the risks below.

**Electrical risks**

- Because it runs from mains, a damaged lead or plug can give a real shock. I treat the lead as the most important part to inspect.
- A loose socket can overheat. If the plug or socket feels warm, I stop and check.
- Sticky hands and electricity do not go together. After handling honey I wash and dry my hands before touching the plug.
- Extension leads and cheap strips add failure points. I avoid daisy chains.

**Fire risks**

- Wax, propolis, sawdust and paper are all flammable, and the workshop has plenty of them.
- Blocked vents make the unit run hotter. I keep them clear.
- I do not leave the charger running unattended for long periods, and never overnight when I am away.
- A small extinguisher and a smoke alarm should be within reach of the workshop door. I should test the alarm each spring.

**Moisture and dirt**

- The workshop gets damp in winter. Condensation inside the housing can cause faults.
- Spilled honey or water near the unit can creep into the connectors.
- Dust and wax flakes build up slowly, so it is easy to ignore them until the vents are half blocked.

**Ageing**

- The unit has been in service since 2018, so cables, plastics and internal parts have had years of heat cycles. Cracks, brittle insulation and yellowed plastic are early signs.
- Contacts can corrode over time, especially if they were never cleaned.
- If the behaviour changes, for example slower charging or unusual smells, I should assume age is a factor.

**Beekeeping-related risks**

- A dead battery on the day I need a tool in the apiary can delay a job that depends on the weather. A spare charged battery reduces this.
- Rushing in the busy season leads to skipped checks. The checklist exists for that reason.
- Bringing bees or hive parts into the workshop can attract insects to the unit. I keep the charger away from open boxes.

**What I do when something goes wrong**

1. Unplug the unit from the wall, not by pulling the lead.
2. Let it cool down and do not touch the inside.
3. Write down what I saw, smelled or heard.
4. Do not use it again until I have found the cause.
5. If I cannot find the cause, I replace the unit rather than guess.

**Summary of the main points**

- Energy source: mains, so treat it as a mains appliance.
- Location: workshop, so keep dust, wax and honey away.
- Installed in 2018, so watch for signs of age.
- Color: red, which makes the unit easy to spot and easy to see when dirty.

## Open questions

These are the things I still do not know about the Trildeth solar charger. I keep them here so I remember to check them the next time I am in the workshop.

- The charger is a solar charger, but its energy source is mains. I have never worked out why a unit sold under the name "solar" is fed from the wall socket. Maybe the panel part is only a trickle top-up, or maybe the name is just a label. I should open the case one day and look at what is actually inside.
- I do not know how long the internal battery path is expected to last. The charger has been in the workshop since 2018, and it still works, but I have no record of any service.
- I am not sure whether the red housing is plain paint or a coloured plastic. It has faded a little near the vent slots, which makes me think it is paint, but I have not tested it.
- I have not measured how much heat it gives off when it charges several beekeeping tools at once. The shelf above it is wooden, so this matters.
- I do not know if the manufacturer still supports this model. A search turned up nothing useful, and I could not find a manual in my own files.
- I would like to know whether the charger is safe to leave on over the winter, when the workshop is cold and damp.

## Background

I keep bees, and over the years the amount of small electrical equipment around the hives has grown. There are head torches for evening inspections, a small smoker fan, a handheld scale reader, a few battery lamps for the extraction room and a radio that plays while I work. All of them run on rechargeable cells, so I needed one place where everything could be topped up without a tangle of separate adaptors.

The Trildeth solar charger is that place. It is a device of the kind "solar charger", and in my notes its area is beekeeping, because every item I charge on it belongs to that work. It is red, which is useful in a cluttered workshop because I can find it quickly among the grey tool boxes and the white jars.

I installed it in 2018. Its location is the workshop, on the bench near the door, where the mains socket is. That is also the reason I put it there: its energy source is mains, so it has to sit within reach of a wall socket and cannot simply go out in the apiary. The cable is short, and I never use an extension lead with it.

A few practical points I have learned from using it:

- Charging overnight is fine for the torches and lamps, but I try not to leave the radio cells on it for days.
- Dust and wax get everywhere in a beekeeping workshop. I wipe the housing with a dry cloth after each extraction session.
- I keep the vent slots clear. A jar or a frame lying against them is the quickest way to make it hot.
- Damp is the real enemy in winter, so I keep a silica bag on the bench beside it.

## Overview

This section collects the properties of the charger in one place, so that I do not have to hunt through the rest of the note.

| Property | Value |
| --- | --- |
| Name | Trildeth solar charger |
| Kind | solar charger |
| Area | beekeeping |
| Color | red |
| Energy source | mains |
| Year installed | 2018 |
| Location | workshop |

In plain words: it is a red solar charger, used for beekeeping, powered from the mains, installed in 2018 and kept in the workshop.

### How I use it

My routine is simple. After an inspection or an extraction day I bring the equipment back to the workshop, put each item on the charger and check that the indicator shows it is taking charge. In the morning I take the full items off and put them back on their hooks. Nothing is left connected for longer than I need.

### Small check list

I keep a short check list on a card next to the bench. I copied it into this note so that it is not lost:

```text
Trildeth check - workshop bench
[ ] Housing wiped, no wax on the vent slots
[ ] Cable not trapped or bent under the bench leg
[ ] Silica bag still dry (winter)
[ ] Indicator lights up when an item is placed
[ ] Nothing flammable on the shelf above
[ ] Unplug from mains when away for a long time
```

I go through it at the start of the season and again before winter. It takes a couple of minutes, and it has already caught a cable that was pinched under a box.

### Things to avoid

- Do not charge wet equipment. After a rainy inspection I let the torches dry first.
- Do not cover the housing, even with a cloth, while it is charging.
- Do not move it to the apiary. Because the energy source is mains, it belongs in the workshop.
- Do not stack items on top of it.

### Maintenance notes

There is not much to do. The red housing needs only a dry cloth. If propolis gets on it, I use a little cold alcohol on a rag and wipe it off straight away, because left alone it hardens and is difficult to remove. I look at the cable and plug each season. If either one looks worn, I will stop using the charger until it is replaced.

## References

- My own workshop notes on the equipment I charge: torches, lamps, fan and radio.
- The check card kept at the bench, copied above.
- Notes from earlier seasons about damp and heat in the workshop.
- The label on the underside of the charger, which I should photograph and file with this note.
- Conversations with other beekeepers at the local club about charging gear in outbuildings.

## Supplies

The Trildeth solar charger is a red solar charger that sits in the workshop. It was installed in 2018 and, despite the name, it runs from mains. The solar part is a trickle input I rarely use. For beekeeping work it keeps the batteries topped up for the things I take out to the apiary.

What I keep on the shelf above the charger, so I never have to hunt for it:

- Spare fuses of the type printed on the case label. I check the label rather than trust memory.
- A small tube of contact grease for the terminals.
- Cable ties and a roll of self-adhesive hook tape for tidying the leads.
- A soft brush and a dry cloth for dust. The workshop gets a lot of sawdust and wax flakes.
- A spare set of crocodile clips, because the red ones on the original leads loosen with age.
- A notebook page taped to the wall where I tick off each charge.

Things I charge with it most often:

- The battery for the electric fence around the outer hives.
- The small lamp battery I use for evening inspections of the honey room.
- The battery pack for the hand-held smoker fan.
- A spare pack for the portable scale I put under a test hive.

I do not keep consumables for the unit itself beyond the list above. It has no filter, no water reservoir and no belt. If something inside fails, it is a job for the bench, not for the shelf.

One practical note on supplies: keep the mains lead the charger came with. A replacement lead from a general shop fitted, but the plug was slightly different and sat loose in the wall socket. I went back to the original and put the other one in a drawer.

## Safety

The charger is mains powered, so the first rule is that it is treated as a mains appliance, whatever the solar label suggests.

Rules I follow every time:

1. Unplug from the wall before touching the leads or the case. Switching off at the unit is not enough for me.
2. Never charge on the wooden bench next to the wax melter. The charger goes on the metal shelf, clear of anything that can burn.
3. Keep the area dry. The workshop floor is damp in winter, so the socket is raised off the floor and I do not stand in wet boots while connecting.
4. Connect the battery leads first, then plug in. When finished, unplug first, then remove the leads.
5. Do not cover the unit. It warms up during a long charge and needs air on all sides.
6. Never charge a swollen or cracked battery. Take it outside, let it cool and dispose of it properly.
7. No sparks near smoke fuel. I store the smoker fuel in the other end of the workshop for this reason.

Beekeeping adds a few small risks of its own. Propolis and wax get on everything, including the clips, and a sticky clip can slip off a terminal and short against the case. I wipe the clips before each use. I also keep the leads away from the honey-room floor, where a trailing cable is a trip hazard when carrying full supers.

If the case smells hot, if the plug is warm, or if there is any buzzing that was not there before, I stop and unplug. I do not use it again until I have looked at the lead and the fuse.

Children and visitors are not allowed to handle it. The red case looks like a toy to some people, so I keep it on the high shelf when I am not using it.

## Observations

I have used this unit since 2018, so these notes come from a long run of ordinary use rather than a test.

- The red paint has faded a little on the side facing the window, but the case is sound.
- The indicator light is clear in a dim workshop and hard to read in bright sun, so I shade it with my hand.
- It hums faintly during the first part of a charge and goes quiet near the end. That is how I judge progress when I am busy at the bench.
- It runs warm, never hot, after a full night on a larger battery.
- The solar input has been used only a handful of times, on sunny days when I wanted to test it outdoors. It works, but slowly, and I do not rely on it. Mains is the real energy source.
- Dust gathers around the vents faster than I expect. A brush every month is enough.
- The clips are the weakest point. Two have been replaced since installation.

Seasonal pattern: in spring I charge almost daily as the fence and scale come back into use. In summer it is every few days. In autumn I charge the batteries fully before storing them, and in winter I top them up about once a month so they do not sink too low.

I keep a short log when something looks odd. This is the format I use, with made-up readings from a typical check:

```
workshop / Trildeth solar charger / mains
check: monthly
vents: dusty -> brushed
clips: left clip loose -> tightened, greased
lead: no cracks
fuse: ok
indicator: normal, goes steady at end of charge
hum: normal, fades near end
notes: moved unit back to metal shelf after bench use
```

What I have learned from the observations:

- A charge that never seems to finish usually means a worn battery, not a faulty charger. I test the battery on another device before blaming the unit.
- A loose clip gives the same symptom as a tired battery, so I check the clip first. It costs nothing.
- Cold affects the result. A battery brought in from the cold apiary needs an hour in the workshop before charging.
- Leaving a battery connected for days after it is full does it no good. I set a reminder.

If the unit ever behaves differently from this pattern, I write the date and what I saw at the bottom of the page taped to the wall, and I compare it with earlier entries before deciding on a repair.

## Costs

I do not keep exact receipts for the charger, since it was installed in 2018 and the paperwork has moved around. What I can say is how the costs break down over time.

**Purchase and installation:** The main cost was the unit itself, bought once. Installation was cheap because it only needed a socket in the workshop and a shelf. I did the shelf myself from offcuts.

**Running cost:** Because the energy source is mains, the unit adds a small amount to the electricity bill. The batteries I charge are small, so the effect is hard to see from one month to the next. The larger fence battery is the biggest user, mostly in spring and summer.

**Upkeep:**

- Replacement clips: the most frequent purchase, two sets so far.
- Fuses: bought in a small pack and barely touched.
- Contact grease and cloths: a tiny cost, and the tube lasts years.
- Cable ties and tape: bought as part of general workshop supplies.

**Costs I avoided:**

- No subscription, no app and no service contract.
- No professional repair so far.
- Charging at home saves trips to have batteries charged elsewhere, which used to cost me time during the busy season.

**Where I would spend more:** If the unit fails, I would think first about whether to repair or replace. Given its age, a repair is only worth it if it is a fuse, a lead or a clip. Anything involving the inside of the case would push me toward a new charger. When that time comes I would want one with a stronger solar input, so the mains side matters less.

My rule of thumb is that the charger has repaid its cost many times over, because the fence and the scale would be unreliable without it. I review the page once a year, usually in late winter before the season starts, and note any purchase made so the history stays in one place.

## Problems

This section lists the faults I have seen on the Trildeth solar charger, the red unit that has sat in the workshop since 2018. It is a solar charger for beekeeping work, and its energy source is mains. That sounds odd for a solar charger, so I note it here: in my setup the panel side is not what keeps it alive. The workshop socket feeds it, and the solar input is only a bonus when the sun is out. Most problems below come from that mismatch.

### Battery packs do not reach full

The most common complaint. I charge the packs that run the electric fence for the bee yard, the small hive scale and the lamp I use for evening inspections. A pack goes on the charger in the evening and in the morning the indicator still shows "almost". My causes, in order of how often they turned out to be the answer:

- A loose plug in the workshop socket strip. The strip is shared with the extractor motor and gets knocked.
- Dust on the contacts. Wax and propolis dust get everywhere in the workshop, and a thin film on the contacts is enough to cut the charge.
- An old pack that is simply tired. No charger fixes that.

### Indicator light stays amber

Amber means the charger sees the pack but is not pushing a full current. If it stays amber for a whole night, I check the contacts first, then the socket, then try a different pack. If another pack charges fine, the first pack is the problem and not the charger.

### Casing gets warm

The red casing gets warm to the touch when it charges two packs back to back. This is normal up to a point. It becomes a problem when I have stacked boxes of frames next to it and the air cannot move. I now keep a clear gap on all sides.

### Humidity and the honey room

The workshop is next to the room where I handle honey, and on wet days the air is damp. Twice I found a faint white bloom on the metal contacts. I wipe them dry and I no longer leave the charger on the low shelf near the door.

### Things that are not faults

I wasted time on these once, so I keep them written down:

- The solar input does nothing at night. That is expected.
- The charger is silent. No humming does not mean it is dead; look at the light.
- The charger does not switch itself off at full in a dramatic way. It just drops to a gentle trickle and the light changes.

## Schedule

I keep a simple routine for the charger. The beekeeping year sets the rhythm: heavy use in spring and summer, light use in winter. The charger itself is the same all year, red, in the workshop, on mains.

### Weekly during the season

- Wipe the contacts with a dry cloth.
- Look at the socket strip and press the plug in firmly.
- Rotate the packs, so each one gets charged and none sits flat for weeks.
- Check that nothing is stacked against the casing.

### Monthly during the season

- Clean the contacts with a cloth slightly damp with alcohol, then let them dry fully.
- Look over the cable for cuts. Mice and the occasional dropped hive tool are the main risks.
- Test each pack by charging it once from low and noting whether it holds through a day of use.

### Before winter

- Charge every pack to full, then store them in a cool, dry place and not on the charger.
- Clean the charger completely, including the vents.
- Put a cloth cover over it, loose enough to let air in.

### Early spring

- Take the packs out and charge them one by one, since a pack that sat all winter may need a long first charge.
- Run the charger for a full cycle with nothing else on the socket strip, and watch the light.
- Fix anything that looks off before the first inspection day.

### Quick log format

I keep a short log in my notes after each check, so I can see patterns. This is the format I use, with the values filled in by hand each time:

```text
charger:    Trildeth solar charger
colour:     red
location:   workshop
source:     mains
contacts:   cleaned / not cleaned
socket:     firm / loose
packs:      charged / partly / failed
light:      green / amber / off
remarks:    free text
```

The point of the log is not detail. It is to notice when "amber" shows up three checks in a row, which usually means the contacts or a pack need attention.

## Lessons

These are the things I would tell myself if I were setting the charger up again.

### Treat the energy source honestly

The label says solar, but my unit runs from mains. I should not plan around the sun for this one. If the power in the workshop goes out, the charger will not do much, so I keep one pack charged in reserve for the days of a cut. The solar input is only a small help, and I would never count on it for the fence packs in a busy week.

### Keep it clean, because the workshop is dirty

Wax, propolis and wood dust are the real enemy. A cloth and a minute each week saves far more time than any troubleshooting later. The red casing hides dirt well, so I have to look at the contacts and not just the outside.

### Give it air

Warmth is fine, but trapped warmth is not. I leave space around it and never put frames, boxes or cloths on top while it charges. Once I put a stack of super boxes beside it and the casing was uncomfortably hot by morning.

### Do not share the socket with big motors

The extractor motor and the charger on the same strip caused loose plugs and a few odd nights. Now the charger has its own socket, and the strip with the motor is on the other wall. Since then, the "almost full" mornings have mostly stopped.

### Label the packs

I put a strip of tape on each pack with a short mark and a note of which job it belongs to: fence, scale or lamp. When I know which pack is the weak one, I can retire it before it fails in the field. A bad pack failing at the far end of the bee yard is much more annoying than a bad pack found in the workshop.

### Write things down in one place

Most of my wasted time came from half-remembering what I had already checked. The log format above fixes that. I also keep the list of non-faults in the Problems section, because I forget them every winter.

### What I would do differently

- Mount the charger on the wall at chest height, away from the door and the damp.
- Add a small plastic cover for the contacts when nothing is charging.
- Buy a second charger of the same kind for the busiest weeks, since one unit with two packs waiting is a bottleneck.

## History

The Trildeth solar charger was installed in the workshop in 2018. It is a red solar charger, bought for my beekeeping, and from the start it was connected to mains as its energy source. I chose that deliberately: the workshop has no good sunny spot for a panel, and I wanted something that would charge on any evening.

### The first seasons

In the first year I used it only for the lamp and the hive scale. It was simple and it worked. I put it on a shelf near the door because that was convenient, and I did not think about dust or damp.

### Adding the fence packs

Later, I started to rely on the charger for the fence packs in the bee yard. That raised the load, and it was then that the warm casing and the amber light became regular topics. I began to keep the weekly cleaning habit around this time.

### The damp contacts

The white bloom on the contacts showed up after a wet stretch of weather. That was the push to move the charger away from the door and the honey room side of the workshop, and to start wiping the contacts dry.

### Separating the socket

After a few nights of loose plugs, I gave the charger its own socket, away from the extractor motor. This was one of the best small changes in the whole history of the unit.

### Where it stands now

Today the charger is still in the workshop, still red, still on mains, and still doing the job it was bought for. The routine in the Schedule section is what keeps it going. It has not needed any repair since it was installed in 2018, only cleaning, care with the socket, and the occasional replacement of an old pack.

## Parts

This section lists the physical parts of the Trildeth solar charger in my workshop, what each one does, and what I check on it. The charger is a red solar charger that I use for beekeeping work. It was installed in 2018 and sits in the workshop. Its energy source is mains, so it is plugged into the workshop socket rather than fed by a panel on the roof. The part number I quote when ordering anything for the main unit is AL-8353-G. I keep it here so I don't have to go looking at the label behind the bench.

### Quick facts

- Kind: solar charger
- Area: beekeeping
- Color: red
- Energy source: mains
- Year installed: 2018
- Location: workshop
- Part number of the main unit: AL-8353-G

### Main housing

The housing is a red powder-coated metal case. The colour is useful because I can spot the unit from across the workshop, even when the bench is covered in frames and wax. The case has vents on both sides and a flat back plate that screws to the wall. Nothing inside needs regular attention, so I leave the case closed except for the yearly check.

What I look at on the housing:

- Dust in the vents. Wax flakes and propolis dust get in more than ordinary sawdust does, and they clog the slots.
- Paint chips near the mounting screws. If bare metal shows, I touch it up so it doesn't rust in the damp months.
- The wall screws. The vibration from the bench saw loosens them over time.

### Mains input

Although the name says solar, this unit takes its energy from mains. The input is a fixed lead with a plug that goes into a socket on the workshop wall. I never run it through an extension reel, because the reel gets knocked about and sometimes ends up near the honey buckets.

Things to remember:

- The plug is the only way to cut power. There is no rocker switch on the housing.
- The lead leaves the case through a rubber grommet. If the grommet cracks, replace it before using the charger again.
- I keep the lead clear of the uncapping tray and the wax melter.

### Charge controller board

The controller board is the part that decides how the output is shaped and when the charger stops. It sits behind the front panel on four standoffs. I only open the front panel when the indicator behaves strangely, since the board is the most delicate part of the charger.

Signs the board is having trouble:

- The indicator flickers instead of holding a steady colour.
- The charger gets warm even when nothing is connected.
- The connected battery never reaches full, even after a long charge.

When any of these happen, I unplug the unit first, wait a while, and then look for dust or a loose connector before suspecting the board itself.

### Indicator panel

The front panel has one small indicator window and a single push button. The indicator shows the state of the charge. I use the push button to wake the display and to cycle through the modes.

My own shorthand for the indicator:

- Steady: charging normally.
- Slow pulse: charge is nearly done and the unit is topping up.
- Fast flicker: a fault, usually a bad contact on the output side.
- Dark: no mains, or the plug is out.

### Output leads and clips

The output side has a pair of leads ending in clips. I use these for the small batteries that run the hive scale, the entrance monitor and the head torch I take to the apiary. The clips are the part that wears out first, because I connect and disconnect them constantly.

Checks on the leads:

- Inspect the insulation near the clips, where it bends most.
- Look for green corrosion on the clip jaws. Honey vapour and damp air make this worse in the workshop.
- Make sure the spring still grips firmly. A weak clip causes the fast flicker fault more often than anything else.

If a clip goes bad, I cut the lead back to clean wire and fit a new clip of the same size. I do not buy a whole new lead unless the insulation has failed.

### Fuse holder

Inside the case, close to the mains entry, there is a small fuse holder. I have never needed to change the fuse in all the years since 2018, but I note it here because it is the first thing to check if the unit goes completely dark while the socket still works. I always unplug the charger before touching it, and I replace a blown fuse only with one of the same rating that is printed on the holder.

### Mounting plate and bracket

The back plate holds the charger to the workshop wall at a height where the indicator is easy to read while I stand at the bench. A small bracket underneath keeps the output leads from hanging loose. The bracket is just a bent strip with two slots, and I check it whenever I check the wall screws.

### Cooling and ventilation

The unit has no fan. It relies on the side vents and on staying clear of clutter. The rule I keep is simple: nothing is stacked against the case, and nothing is hung over it, not even a towel or a smoker bag. Beekeeping gear tends to creep across the wall over a season, so I clear the space around the charger every time I tidy up in autumn.

### Spare parts I keep

I keep a few cheap spares in a labelled tin on the shelf beside the charger:

- A spare set of clips.
- A spare rubber grommet for the lead.
- A spare fuse of the correct rating.
- A few wall screws and washers.

I do not keep a spare controller board or a spare housing. If the main unit fails, I order a replacement using the part number AL-8353-G.

### Yearly check log

Once a year I run through the parts in the order above and write a short entry. The format I use is below, so entries stay comparable from one year to the next.

```text
Trildeth solar charger - yearly check
Kind:          solar charger
Area:          beekeeping
Color:         red
Energy source: mains
Installed:     2018
Location:      workshop
Part number:   AL-8353-G

Housing:       vents cleaned, paint ok
Mains lead:    grommet ok, plug ok
Controller:    not opened, indicator steady
Indicator:     all states shown correctly
Output leads:  clips cleaned, spring ok
Fuse:          not touched, unit powers up
Mounting:      screws tightened
Ventilation:   space around case cleared
Notes:         none
```

I copy this block into the year's notes and change only the last lines. If something needs work, I put it in the notes line instead of fixing it silently, so I can see later which parts keep causing trouble.

### Common faults mapped to parts

This is the short list I use when something goes wrong, matching the symptom to the part I check first.

- Unit completely dark: plug, socket, then the fuse holder.
- Fast flicker on the indicator: output clips and lead insulation.
- Warm case with nothing connected: vents and the controller board.
- Battery never full: clips first, then the controller board.
- Rattling noise: loose wall screws or the bracket.

### Cleaning notes

I clean the exterior with a dry brush and a barely damp cloth, with the unit unplugged. I never spray anything near the vents. Wax residue on the case comes off with a little warm water on the cloth, and I never use solvent, because it can dull the red paint and damage the label that carries the part number.

### What I would not change

The charger works well where it is, and I do not plan to move it. Its place in the workshop, its mains supply and its red case are all part of how I use it. The only parts I treat as consumables are the clips and the grommet. Everything else I expect to last, as it has since 2018.
