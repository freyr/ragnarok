---
type: reference
status: archived
project: reference
area: beekeeping
description: "Reference about Tronas band saw."
---

# Tronas band saw 2020

## Supplies

This note is archived. It records the state in 2020; later notes replace these values.

The Tronas is a yellow band saw that I use for beekeeping work, mainly cutting frame stock and hive boxes. It runs on a battery, so no cord is needed. The saw is kept in the loft, and the year installed is 2022.

Things I keep next to it:

- Spare blades for cutting softwood
- A charged spare battery
- A brush for clearing sawdust from the wheels
- A small tin of wax for the blade guides

## Adjustment

The blade drifts slightly if the guides are not set well. After changing a blade, I make a test cut in a scrap of pine and check that it runs straight.

- Calibration offset of Tronas band saw: 1.205 mm
- Recheck the offset after any blade change
- Tighten the guides only when the battery is removed
