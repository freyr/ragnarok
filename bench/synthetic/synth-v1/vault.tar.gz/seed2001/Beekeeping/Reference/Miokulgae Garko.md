---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Miokulgae Garko."
---

# Miokulgae Garko

## History

Miokulgae Garko is a plumber I have known since 2012. I first met him through a neighbour who needed a leak fixed under a kitchen sink. Since then he has done most of the water work around the apiary and the house. I contact him in person, because he does not answer messages reliably. He is available on weekdays only, so I plan jobs around that.

His work on the honey room taps and the washing sink was solid, and he explained every step. He also helped me check the pipe runs for the [[Brethgleth loft]], where I want a small extraction area. For the water tank idea he looked at the [[Tithbun level sensor plan]] and said the fitting positions were sensible. When I was comparing other tradespeople I used the notes in [[Kaesme Laerdond tests]], and I also keep [[Zustrand Rorkstul]] as a backup contact.

| Property | Value |
|---|---|
| Role | plumber |
| Area | beekeeping |
| Contact | in person |
| Availability | weekdays |
| Known since | 2012 |

## Quotes

For the loft water line and the new sink fittings, Miokulgae Garko gave me a quoted price of 1689.86 EUR. He said the price covers labour and basic pipe, but not any wall repair afterwards. I should ask him to confirm this again in person before I agree to the work, and I should ask him which weekday he can start.
