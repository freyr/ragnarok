---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Susrion level sensor."
---

# Susrion level sensor

## Problems

The Susrion level sensor is a yellow level sensor that sits in the shed and has done so since 2025. It is part of my beekeeping setup, and it is powered from the mains. Most of the trouble I have had with it comes from the fact that a shed is not a friendly place for electronics. This section lists the problems I have met, so that I can recognise them quickly next time.

**Condensation.** The shed is cold at night in autumn and spring and warm in the afternoon. Water forms on the inside of the housing and on the connector. When this happens the reading jumps around or drops to nothing. Drying the connector and leaving the lid off for an afternoon fixes it most of the time.

**Sticky residue.** Honey and wax get everywhere. A thin film on the probe makes the sensor think the level is higher than it is. The film builds up slowly, so the error is easy to miss. I only notice it when I compare the reading with a visual check of the container.

**Dust.** Fine dust from the frames and from the floor settles on the housing. It is not a big problem for the sensor itself, but it gets into the connector and the cable entry.

**Mains hum and interference.** When the big extractor or the heater is switched on at the same socket strip, the reading sometimes wobbles for a few seconds. It recovers by itself. I treat a short wobble as normal and a long one as a sign to check the wiring.

**Pests.** Mice like the shed in winter. Cables are attractive to them. I have not had damage on this sensor, but I have found chewed cable on another device nearby, so I keep it in mind.

**Wrong placement.** If the sensor is moved even a little, the reading shifts. The yellow housing is easy to knock when I am carrying boxes. I now keep a clear zone around it.

### How I tell a real problem from a false alarm

1. Look at the container with my own eyes.
2. Compare the sensor reading with what I see.
3. Wipe the probe and compare again.
4. If the reading is still wrong, check the connector for moisture.
5. If that does not help, power the sensor off and on once.
6. Only after all this do I suspect a fault in the device itself.

## Maintenance

Maintenance is mostly cleaning and looking. The sensor has no parts that I service myself. Because it runs on mains power, I always disconnect it from the socket before touching anything other than the outside of the housing.

### Routine tasks

- **Wipe the probe.** Use a soft cloth with warm water. Do not use strong solvents, because they can cloud or crack the plastic. Wax comes off easier if the water is warm, not hot.
- **Wipe the housing.** The yellow colour makes dirt visible, which is useful. When it looks dull, it is time to clean.
- **Check the cable.** Run my fingers along the cable looking for cuts, flat spots, or chewing marks.
- **Check the plug and socket.** The plug should sit firmly. A loose plug gives intermittent power and strange readings.
- **Check the mounting.** Make sure the sensor has not shifted from its position in the shed.
- **Check for moisture.** Look inside the connector area and at the cable entry for droplets.

### Seasonal tasks

In spring I do a thorough clean before the season starts. I remove the sensor, clean it fully, dry it, and refit it in the same place. I then compare the reading with a known level to confirm it still agrees.

In autumn I do the same after the season ends, and I also look for signs of mice before winter. If the shed will be very cold, I consider whether the sensor should be left powered, since a little warmth from running can help against condensation. I have not settled this question, and it is listed under open questions.

### What I do not do

- I do not open the housing.
- I do not spray water directly at the sensor.
- I do not use the sensor with a damaged cable, even for a quick check.
- I do not clean it while it is plugged in.

### Keeping a log

I write a short line in my notes each time I clean or adjust the sensor: what I did, what I saw, and whether the reading changed. Over time this log shows me how fast the residue builds up, which tells me how often to clean.

## Costs

I have not tracked the purchase price in these notes, and I do not want to guess at one, so this section describes the kinds of cost rather than amounts.

### Purchase

The sensor was bought and installed in 2025. The purchase was a one-time cost. I judged it worth it because checking levels by eye in a cold shed, many times a season, was tedious and sometimes skipped.

### Running cost

The sensor uses mains electricity. Its measured power draw is given under Measurements. Since it runs for long periods, the running cost is small but not zero. If I ever want to cut it, the simplest way is to power it only during the active season.

### Consumables

- Cleaning cloths, which I already own.
- Warm water, which is free.
- Mild soap, a small amount.
- Replacement cable or plug, only if damaged.

### Hidden costs

- **Time.** Cleaning takes a few minutes, but it has to happen regularly.
- **Replacement risk.** If the sensor fails, I need to buy another and fit it, and I may have to adjust my notes.
- **Socket capacity.** The sensor shares the shed's mains supply with other things. If I add more devices, I may need another socket strip.

### Cost versus benefit

The benefit is that I find out about level problems early. In beekeeping, a delay of a day or two can matter. So I consider the cost acceptable. I would reconsider only if the sensor became unreliable and needed constant attention.

## Safety

The sensor is mains powered and lives in a shed with moisture, dust, and sticky material. That combination needs respect. These are my own rules.

### Electrical

- Always unplug the sensor before cleaning anything beyond a quick wipe of the outside.
- Never handle the plug with wet hands.
- Do not use the sensor if the cable is cut, crushed, or chewed.
- Keep the plug and socket off the floor where water or spilled honey could reach them.
- Do not overload the socket strip. The extractor and the heater draw much more than the sensor.
- If the shed has a residual current device on the supply, check that it trips when tested. I do this at the start of each season.

### Moisture

Condensation is a normal event in the shed, so I assume the housing may be damp. I dry the outside and the connector area before reconnecting power. If I see water inside the connector, I leave the sensor unplugged until it is dry.

### Fire

- Keep the area around the sensor free of loose paper, cardboard, and dry wax scraps.
- Do not cover the housing with cloth or boxes.
- Keep a fire extinguisher in the shed, and check its gauge when I do the seasonal checks.

### Handling

The sensor is light, but the probe can be awkward to hold. I hold it by the housing, not by the cable. I avoid bending the cable sharply.

### Bees and people

The sensor does not touch the bees directly. Still, I keep all cables out of the way so that nobody trips while carrying heavy boxes. A fall with a full box is more dangerous than any fault in the sensor.

### If something goes wrong

1. Switch off the supply at the socket or the fuse board.
2. Unplug the sensor.
3. Do not touch it until I am sure the power is off.
4. Note what happened.
5. Do not use it again until the cause is clear.

## Tools

I try to keep the toolset small. Most of the work needs nothing special.

### For cleaning

- Soft cloths, lint-free if possible.
- A small bowl for warm water.
- A soft brush for dust, such as an old paintbrush.
- A wooden or plastic scraper for wax. Never metal, because it scratches the probe.
- A towel for drying.

### For checking

- A torch, because the shed corners are dark.
- A plug-in power meter, which I used to measure the power draw.
- A notebook or the notes app for logging.
- A container with a known level, for comparison.

### For mounting

- A screwdriver that fits the mounting screws.
- Cable ties for keeping the cable tidy.
- A spirit level, to confirm the sensor sits straight.
- A marker or tape to mark the correct position.

### For electrical safety

- A socket tester, to check the socket is wired properly.
- Rubber-soled shoes or a dry mat when working on damp floors.

### Storage

I keep the tools in a small box near the shed door, so I do not have to search for them. The cloths are washed regularly, because honey residue left in them just spreads the film around.

### Tools I deliberately avoid

- Sharp knives near the cable.
- Solvents on the plastic.
- High-pressure water.
- Any tool that needs the housing opened.

## Measurements

This section collects the numbers I have recorded or need to remember for the sensor. Only the values I have actually confirmed are listed.

### Properties at a glance

| Property | Value |
| --- | --- |
| Kind | level sensor |
| Area | beekeeping |
| Colour | yellow |
| Energy source | mains |
| Year installed | 2025 |
| Location | shed |

### Power draw

The measured power draw of Susrion level sensor: 407.74 W

I measured this with a plug-in power meter between the socket and the sensor. This figure is much higher than I would have guessed for a sensor of this kind, so if I ever repeat the measurement I will check the meter setup and make sure nothing else was on the same meter at the time.

### How I measure

1. Plug the power meter into the socket.
2. Plug the sensor into the meter.
3. Let the reading settle.
4. Write it down along with what else was running.
5. Repeat at a different time of day to check for variation.

### Level readings

I do not store the level readings in this note. They live in my season log. What I record here is only how I check them: compare with a visual check, wipe the probe first, and note whether the reading is steady.

### Things worth measuring again

- Power draw, to confirm the figure above.
- Reading drift between cleanings.
- Behaviour on cold nights compared with warm days.

## Supplies

Supplies are the small things I need on hand so that the sensor stays usable. None of them are expensive, but running out at the wrong moment is annoying.

- **Cloths.** A few clean ones, kept dry and separate from the ones I use for honey.
- **Mild soap.** Only a little, for stubborn film.
- **Cable ties.** For keeping the cable off the floor and away from mice.
- **Spare plug or socket strip.** In case the old one fails.
- **Silica gel packets.** Kept near the sensor to help with moisture. I replace or dry them out when they are saturated.
- **Tape.** For marking the sensor position.
- **Notebook.** For the log.
- **Cable protection.** A plastic tube or spiral wrap to guard the cable against chewing.
- **Torch batteries.** So the torch works when I need it.

### Where things are kept

Everything is in the box by the shed door, except the silica gel, which sits close to the sensor, and the spare socket strip, which is on the shelf with other electrical items.

### Restocking

I check supplies at the spring and autumn cleans. If something is nearly gone, I add it to my shopping list straight away. I do not wait until I need it.

### What I do not stock

I do not keep a spare sensor. If it fails, I will order a replacement and manage by eye until it arrives. This is a trade-off I accepted because a spare would sit unused most of the time.

## References

These are the sources I rely on. Since this is a personal note, they are mostly my own materials rather than outside documents.

- **The manual that came with the sensor.** It covers the basic use and the cleaning advice. I keep it in the shed folder.
- **My installation notes from 2025.** They describe where and how I fitted the sensor.
- **My season log.** It has the cleaning records and reading comparisons.
- **The shed wiring notes.** They show which socket the sensor uses and what else shares that supply.
- **My beekeeping calendar.** It tells me when the active season starts and ends, which affects the maintenance schedule.

### How I use them

When something looks wrong, I first check the season log for similar events. Then I check the installation notes to see whether the sensor is still where I put it. The manual is the last stop, for anything unusual.

### Gaps

I do not have a proper record of the purchase. I also have no written statement of the sensor's rated power, so I rely on my own measurement. If I find the paperwork, I will add the details here.

### Related topics in my notes

- Shed electrical layout.
- Condensation control in the shed.
- Beekeeping season planning.
- Pest control for cables.

## Lessons

These are the things I learned from using the sensor since 2025.

1. **Clean the probe before you trust a reading.** A thin film can mislead more than a real fault.
2. **Condensation is normal in the shed.** Do not panic when readings vanish on a cold morning. Dry things first.
3. **Mark the position.** A small mark on the wall saves time when the sensor gets moved.
4. **Protect the cable.** A cheap wrap is better than a repair.
5. **Do not share a socket with heavy loads.** The wobble stopped mattering once I understood the cause, but a separate socket would be cleaner.
6. **Log what you do.** The log is the only way I see slow changes.
7. **Check by eye regularly.** The sensor is a help, not a replacement for looking.
8. **Measure, do not assume.** My power draw measurement surprised me, and I am glad I took it.
9. **Keep the yellow housing visible.** The bright colour helps me see it in a dim shed and reminds me to check it.
10. **Do not open it.** Nothing inside is meant for me to fix.

### What I would do differently

- Fit cable protection on day one.
- Put the sensor on its own socket.
- Start the log from the first week.
- Keep the purchase paperwork in a known place.

## Checklist

### Before the season

- [ ] Unplug the sensor.
- [ ] Clean the probe and housing.
- [ ] Inspect the cable, plug, and socket.
- [ ] Check for moisture and signs of mice.
- [ ] Refit in the marked position.
- [ ] Plug in and confirm the reading against a known level.
- [ ] Test the residual current device.
- [ ] Replace silica gel.

### Monthly during the season

- [ ] Wipe the probe.
- [ ] Compare the reading with a visual check.
- [ ] Look at the cable.
- [ ] Note anything odd in the log.

### After a problem

- [ ] Power off and unplug.
- [ ] Dry the connector.
- [ ] Clean the probe.
- [ ] Power on and compare.
- [ ] Write down the cause and the fix.

### End of season

- [ ] Clean fully.
- [ ] Look for chewed cable.
- [ ] Decide whether to leave it powered.
- [ ] Restock supplies.
- [ ] Update the log.

## Schedule

The schedule follows the beekeeping year, because that is when the sensor matters most.

### Weekly

During the active season I glance at the sensor reading when I visit the shed. This takes seconds. If the reading looks odd, I follow the steps in the problems section.

### Monthly

Once a month in the season I wipe the probe, compare the reading with a visual check, and look over the cable and plug.

### Spring

Early in spring, before the first busy weeks, I do the full clean and inspection. I also test the residual current device and replace the silica gel.

### Summer

The shed is warm and condensation is less of an issue. Dust and wax residue are the main concerns, so I may clean the probe more often.

### Autumn

After the season I do another full clean and look for signs of mice. I check the cable protection and decide about winter power.

### Winter

I visit the shed less. When I do, I look for moisture and for any sign of pests. If the sensor is unpowered, I make sure it is dry and stored safely in position.

### Yearly

Once a year, I read through this note and update it with anything new. I also review the open questions and see whether any have an answer.

### Triggers for extra checks

- A very cold night after a warm day.
- Any change to the shed wiring.
- Moving heavy items near the sensor.
- A reading that does not match what I see.

## Risks

### Electrical fault

A fault in a mains-powered device in a damp shed is the most serious risk. I reduce it by keeping the cable intact, the plug dry, and the supply protected by a residual current device. The likelihood is low, but the impact could be high.

### Moisture damage

Repeated condensation could damage the sensor over time. I reduce the risk with silica gel, drying, and regular checks. It is a medium likelihood with a moderate impact.

### Pest damage

Mice may chew the cable. I use cable protection and look for signs each autumn. The likelihood is moderate, and the impact is moderate.

### False readings

A dirty probe or moved sensor may give a wrong level. The risk is that I miss a real problem. I reduce it with regular cleaning and visual checks. Likelihood is high, impact is moderate.

### Dependence

If I rely too much on the sensor, I may stop looking at the containers myself. I keep the habit of visual checks.

### Power cost

The measured power draw of 407.74 W is high for a small device left on for long periods. If that figure is right, the running cost could add up. I need to confirm the measurement and think about switching the sensor off when not needed.

### Failure with no spare

If the sensor fails, I have no replacement. The impact is small because I can check by eye, but it would be inconvenient in a busy week.

### Risk summary

| Risk | Likelihood | Impact |
| --- | --- | --- |
| Electrical fault | Low | High |
| Moisture damage | Medium | Moderate |
| Pest damage | Moderate | Moderate |
| False readings | High | Moderate |
| Power cost | Unclear | Unclear |
| No spare | Low | Low |

## History

### 2025

The sensor was installed in the shed in 2025. It is yellow, mains powered, and was bought to help with level monitoring in my beekeeping work. I chose the shed location because it is where the containers are, and because there was a socket nearby.

### First season

The first season was mostly learning. I discovered the condensation issue early, on a cold morning when the reading vanished. I also found that wax residue built up faster than I expected.

### Adjustments

Over time I added the position mark, started the log, and moved to a regular cleaning routine. I also started thinking more about cable protection after seeing chewed cable on another device.

### Power measurement

At some point I measured the power draw with a plug-in meter and recorded the result in this note. The figure surprised me and led me to list it as something to verify.

### Present

Today the sensor works reliably when it is clean and dry. The main work is keeping it that way. My routine is stable, and the notes are up to date as far as I know.

### Possible future changes

- A separate socket for the sensor.
- Better cable protection.
- A more weatherproof mounting.
- A decision on winter power.

## Open questions

- Is the measured power draw of 407.74 W correct, or was there an error in the meter setup or something else running on the same meter?
- Should the sensor stay powered through winter to reduce condensation, or is it better to switch it off?
- Would a separate socket remove the short wobbles in the reading when heavy loads start?
- How often should I clean the probe in summer to avoid the slow build-up of residue?
- Is there a better way of mounting the sensor so that it is harder to knock?
- Where is the purchase paperwork, and does it state a rated power?
- Would a different position in the shed give a steadier reading?
- Is the cable protection I use enough against mice, or should I use something tougher?
- Could I log the readings automatically instead of by hand?
- Should I keep a spare sensor after all, in case of a failure in the middle of the season?
