---
type: reference
status: archived
project: reference
area: beekeeping
description: "Reference about Nithden greenhouse."
---

# Nithden greenhouse 2023

This note is archived. It records the state of the Nithden greenhouse in 2023. Later notes replace the values given here, so treat everything below as a snapshot and not as current fact.

## Schedule

The schedule is the order of work as I kept it in 2023. It is not a calendar. I did not write dates against the tasks, only the season and the order.

Early in the year I cleared the ground and marked the footprint. Once the ground was firm, I set the frame and then the glazing. The greenhouse is on ground level, so no stairs or ramp work was needed, and that saved a lot of time.

After the glazing I did the interior work: benches, shelving, the water line and the power run. Power came last because I wanted to see where the benches ended up before deciding where sockets should go.

The rest of the year followed a loose weekly rhythm:

- A walk-through at the start of each week to check vents, glazing and the floor.
- A check of the hive-side benches, since the greenhouse belongs to the beekeeping area.
- A weekly look at the solar charger and the battery state.
- A monthly tidy of the supply shelves.
- A seasonal deep clean of the glass, done on a dry day.

Spring was for setting up and sowing. Summer was for watching heat and airflow. Autumn was for cleaning and putting things away. Winter was for repair and for planning the next changes. I kept the schedule short on purpose, because a long one never gets followed.

## Observations

These are the things I noticed during the first season in the Nithden greenhouse.

The greenhouse faces north. I expected that to make it dim and cool, and it did. The light is even and soft, with no hard shadows on the benches. Plants that scorch elsewhere did well here, and the temperature swings were smaller than I feared. The cost is that cold-season growth was slow, and I will not pretend otherwise.

The size is large. In use, that means I can walk the whole length with a cart and still turn it around. Large also means that air does not mix on its own, so the far end is a different climate from the door end. I put a small thermometer at each end and learned to read them as a pair.

The floor is ground level. Water drains away well and the door has no threshold to trip on. Mud tracks in after rain, though, and I added a coarse mat at the entrance.

Other notes from the season:

- Condensation collects on the north glass in the morning and clears by midday.
- Bees wander in through the vents on warm days and have to be guided back out.
- The sound inside is muffled and quiet, which is pleasant for slow work.
- Dust settles on the benches faster than I expected.

## Background

I built the Nithden greenhouse in 2023 as part of my beekeeping area. The idea was a covered working space beside the hives, a place to prepare frames, start forage plants and store gear out of the weather. A plain shed would have worked, but I wanted light, and I wanted a place where I could stand in the warmth in early spring and still be near the bees.

The work grew out of earlier projects. The lessons from [[Lenkaenpun Nigli 2021]] shaped a lot of my choices, mainly about not oversizing things I would not keep up and about putting water close to where it is used. The loft work recorded in [[Zothvun loft log]] gave me practice with the sort of timber joints I used in the frame.

I chose the north orientation deliberately. Strong direct sun is hard on wax, on stored frames and on seedlings that I cannot water at midday. A north-facing house gives steady light without the heat spikes. It was a trade-off, and I accepted it knowing the cold months would be slower.

The year built is 2023. The kind is a greenhouse, the area is beekeeping, the size is large, the floor is ground level and the orientation is north. Those are the facts everything else in this note rests on.

## Overview

The Nithden greenhouse is a large greenhouse built in 2023 in the beekeeping area. It sits on ground level and faces north. In one line: a big, even-lit, low-heat working house beside the hives.

It serves three jobs. First, it is a workshop for frame preparation and small repairs. Second, it is a nursery for forage plants that I move out near the hives. Third, it is dry storage for equipment I do not want rained on.

The layout is simple. The door end is the working end, with a bench and the tools. The middle is open floor for the cart and for turning. The far end holds shelves and the plant benches. Power and the charger are on the door side, so cables stay short.

Properties at a glance:

- Kind: greenhouse
- Area: beekeeping
- Orientation: north
- Size: large
- Year built: 2023
- Floor: ground level

The floor area is given under Dimensions. Because this note is archived, a later note may show a different layout or a changed use. If so, trust the later note.

## Ideas

These are ideas I wrote down in 2023 but did not act on. I keep them here so they are not lost, with no promise that any of them will happen.

The first idea was better power. The solar charger is small for a large greenhouse, and I sketched alternatives in [[Tarkvaer solar charger plan]] and [[Tothbi solar charger plan]]. Each takes a different approach to panel placement and storage. I wanted to compare them against what I actually measured in [[Gioltrar solar charger log]] before choosing.

The second idea was water level monitoring. I have a rain barrel feeding the benches and I never know how full it is. [[Starklil level sensor plan]] describes a simple sensor and a warning light by the door.

Other ideas:

- A light-colored lining on the south wall to bounce more light to the plants.
- A second door at the far end for through-traffic with the cart.
- A raised walkway of boards to keep boots out of the mud.
- Shade cloth hooks, even though the north side hardly needs shade.
- A small shelf only for bee-related items, kept apart from plant supplies.

I ranked these by how often the problem annoyed me. Power and water came first, and the mud walkway came third.

## History

This is the short history of the Nithden greenhouse in its first year.

The plan began as a sketch after I decided the beekeeping area needed a covered space. I chose the north orientation early and did not change it. The footprint was marked out and the ground levelled so that the floor could stay at ground level without a raised base.

The frame went up first, then the glazing. I borrowed time on the [[Tronas band saw]] to cut the longer timber pieces cleanly, which saved me from a lot of hand-sawing and gave tighter joints. The band saw was a shared tool and I had to plan cuts in batches.

After the shell was closed, I fitted benches and shelves, then water and power. The first sowing went in once the interior was dry and the vents worked. Through the season I adjusted vent stops, replaced a cracked pane and added the entrance mat.

By the end of 2023 the greenhouse was in regular use. The main things I had learned were that the north light is gentle, that the large size demands two temperature readings, and that the small charger was the weakest part of the setup. This note was archived after that, and later notes carry any changes.

## Lessons

These are the lessons from building and using the greenhouse in 2023.

Plan the power first. I did it last, and it meant running cable around benches that were already fixed. If I did it again I would mark every socket and the charger location before any bench went in.

Respect the orientation. A north-facing house is calm and even, and I should have planned crops around that. Slow-growing, shade-tolerant plants did best. Heat-loving plants struggled and I should not have tried so many.

Size has a cost in attention. A large greenhouse needs a routine, and the routine needs to be short enough to keep. A pair of thermometers, one at each end, did more for me than any clever device.

Ground level is a gift and a nuisance. It makes access easy and drainage good, but it brings mud and dust. A mat and a walkway should have been part of the first build.

More lessons:

- Cut long timber in batches when borrowing a shared tool.
- Keep a spare pane or two on hand before the first storm.
- Write down measurements as you take them, not afterward.
- Compare plans against logged data before buying anything.

## Maintenance

Maintenance for the greenhouse is light but regular. I split it by frequency.

Weekly: walk the length of the house and check the vents, the door and the glazing for cracks. Look at the floor for pooled water. Check the charger and battery. Sweep the entrance and shake out the mat.

Monthly: wipe the benches, tidy the shelves and check the water line and the fittings for slow leaks. Look at the hive-side bench for wax scraps and sticky spots, since they attract insects. Oil the hinges and vent stops.

Seasonal: wash the glass inside and out on a dry day. The north glass grows a green film faster than the rest because it stays damp, so it needs the most attention. Check the frame for rot or loosened joints, tighten fasteners and replace any damaged seals.

Yearly: empty the house if possible and look at the whole structure. Check the ground along the base for erosion and for signs of rodents. Review the power setup against the notes in [[Gioltrar solar charger log]].

Things to watch for:

- Moss on the north side of the frame.
- Cracks around vent hinges.
- Cables rubbing on sharp edges.
- Standing water near the door.

I keep a spare box of fasteners and sealant on the shelf at the door end.

## Supplies

The supplies live on the shelves at the far end and in a lidded bin at the door. I keep the list practical and short.

Plant side:

- Seed trays and pots in several sizes
- Potting mix, stored off the floor and covered
- Plant labels and a marker that survives damp
- A watering can and a hose fitting for the water line
- Twine and soft ties

Beekeeping side:

- Spare frames and foundation, stored dry and flat
- A smoker and fuel, kept in a metal tin
- Hive tools and a brush
- Protective veil and gloves
- Clean cloths for wiping wax

Greenhouse care:

- Spare glazing panes and sealant
- Fasteners, hinges and vent stops
- Cleaning cloths and a soft brush for the glass
- A small first-aid kit
- Mat and boards for the entrance

I rotate stock so older items get used first. Anything that attracts pests is kept in a sealed container. When a supply runs low I note it at the door, so I do not forget it on the next trip. Plans for new supplies, such as a sensor or a charger, are in the ideas section and the linked plan notes, not here.

## References

Notes I used or consulted while building and running the greenhouse:

- [[Lenkaenpun Nigli 2021]] for earlier lessons on sizing and water placement.
- [[Zothvun loft log]] for timber work and joint practice.
- [[Tronas band saw]] for the shared tool I used to cut long pieces.
- [[Gioltrar solar charger log]] for measured power use.
- [[Tarkvaer solar charger plan]] and [[Tothbi solar charger plan]] for charger options.
- [[Starklil level sensor plan]] for the water level sensor idea.
- [[Mastend Runpith]] for the person and context behind some of the beekeeping advice I followed.

I use these as pointers, not as authority. Where a linked note and this one disagree, the more recent note wins, and because this note is archived, it is usually the one that is out of date. I keep the list short so that I can check each link when I revisit the greenhouse.

If I add a new reference, I add it here and also link it from the section where it matters, so that the connection is visible in both places.

## Tools

Tools I used in and around the greenhouse in 2023.

For building, the main shared tool was the [[Tronas band saw]]. It cut the long frame timber cleanly. I also used a hand saw for trimming, a drill and driver for fasteners, a spirit level, a long tape and string lines for marking the footprint. A rubber mallet helped seat the glazing without cracking it.

For daily use, the working kit sits at the door end:

- A broom and a dustpan for the floor
- A soft brush and cloths for glass and benches
- A trowel and a small fork for potting
- Pruning snips and scissors
- A bucket with a lid
- Two thermometers, one at each end of the house

For beekeeping work inside the greenhouse:

- Hive tool and frame grip
- Smoker, kept near the door but never lit indoors
- A scraper for wax

For power checks, I use a basic meter and read the battery state as logged in [[Gioltrar solar charger log]].

I keep each tool in a set place and mark the spot with an outline on the wall. It takes a minute to do and saves a lot of searching. Sharp tools get cleaned and dried before they go back.

## Setup

The setup describes how the greenhouse was arranged at the end of 2023.

The house is large, faces north and sits at ground level. The door is on the working end, with a clear step-free entrance and a coarse mat. Just inside is the main bench, with tools on the wall above it.

Down the middle is an open strip of floor wide enough for the cart. Along one side are the plant benches. Along the other are the shelves for beekeeping gear and stored supplies. At the far end are more shelves and the water barrel, which feeds a line running back toward the door.

Vents sit high on the walls and can be propped open on warm days. I set the stops so that wind does not slam them. I watch for bees coming in and guide them out toward the hives.

Power comes from the small solar charger on the door side, with short cable runs to a few sockets. The charger has limits, and the options for replacing it are in [[Tarkvaer solar charger plan]] and [[Tothbi solar charger plan]].

Water level is checked by eye. A sensor is only a plan, in [[Starklil level sensor plan]].

I placed the two thermometers at opposite ends and read both on every visit. That is the single most useful part of the setup.

## Costs

I did not keep a careful ledger for this build, so I will not list figures here. What I can record is where the money and effort went, in rough order of weight.

The largest share went to the frame and glazing. A large greenhouse needs a lot of both, and cracked panes mean replacement costs later. The second share went to the interior: benches, shelves, water line and the power setup. The third went to small things like the mat, fasteners, sealant and labels.

Costs that I saved:

- Using the shared [[Tronas band saw]] instead of buying a saw or paying for cut timber.
- Leaving the floor at ground level, so no base or foundation work was needed.
- Reusing shelving and bins from earlier projects.

Costs that I underestimated:

- Spare glazing, since a pane broke in the first season.
- The power setup, which turned out too small and needs replacing.
- Time, which is the largest cost of all. Nearly every task took longer than I planned.

Future costs to expect are in the ideas section: a better charger, a level sensor and a walkway. Before I spend on any of them, I will compare the plans against measured use. Any new cost figures belong in a later note, since this one is archived.

## Dimensions

The floor area of Nithden greenhouse is 309.15 m².

The greenhouse is large, and that figure matches the size class I recorded. It stands at ground level, so the floor area is the same as the footprint on the ground. There is no raised base or upper floor to add to it.

The orientation is north. Because of that, the long working space has even, indirect light, and the far end is noticeably cooler than the door end.

Practical points that follow from the size:

- The cart can travel the full length and turn in the open strip.
- Two thermometers are needed, since one cannot represent the whole space.
- Cable and water runs are long, so I kept the power and water sources near the door.
- Cleaning the glass takes a full session, not a quick pass.

I did not record wall height or ridge height as separate values in 2023, so I do not give them here. The year built is 2023, and these dimensions describe the house as it stood then. If a later note gives a different area or layout, that note replaces this one.
