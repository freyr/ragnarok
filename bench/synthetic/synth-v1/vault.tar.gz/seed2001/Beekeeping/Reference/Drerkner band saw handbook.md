---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Drerkner band saw."
---

# Drerkner band saw handbook

## Background

This is my handbook for the Drerkner band saw. I keep it as a reference so that I do not have to rediscover the same things every winter. The saw is a band saw, and it belongs to my beekeeping work. Most of what it cuts is hive wood: boxes, frame parts, lids, bottom boards and the odd bit of scrap for stands and feeders.

The basic properties of the device, written down once so I can find them quickly:

- Name: Drerkner band saw
- Kind: band saw
- Area: beekeeping
- Color: grey
- Energy source: battery
- Year installed: 2018
- Location: greenhouse

I put the saw in the greenhouse in 2018. At the time it seemed like a odd place for a workshop tool, but it made sense. The greenhouse has a bench along one wall, good daylight, and a concrete floor that is easy to sweep. It is also close to the hives, so carrying timber back and forth is short work. The drawback is humidity, which I come back to under Problems.

The saw is grey, and that matters more than it sounds. Sawdust and the pale wax residue that clings to old hive parts show up well against it, so I can see when it needs a wipe. The paint is also the same shade as most of the other tools on the bench, so when the saw is pushed into a corner under a cloth it nearly disappears. I have lost track of it more than once for that reason alone.

The energy source is the battery. There is no mains cable to trip over, and I can run the saw without dragging an extension lead through the wet parts of the greenhouse. That was the main reason I chose it. The cost is that I have to plan my cutting around the charge. I treat the battery as the limit on a work session, not as a detail.

Why a band saw for beekeeping at all? Hive parts are repetitive, and many of them need curves or long clean rips that a handsaw does badly. A band saw handles thin stock gently, wastes little wood, and makes a narrow cut. For frames and small fittings that narrow cut is useful, because there is less to sand afterward.

How I use this note: I read the Lessons section before starting a new batch of cuts, and I read the Problems section when something sounds or smells wrong. The other parts of this handbook cover the rest of the routine.

## Lessons

These are the things I learned by using the saw, mostly by getting them wrong first. I have kept them practical and in the order I would need them.

**Start with a charged battery and a dry blade.** A saw that begins a job on a half-flat battery slows down in the middle of a cut, and the blade then wanders. I now charge the battery the evening before any big cutting day. I also wipe the blade before use, because moisture from the greenhouse air leaves a thin film on it.

**Let the blade do the work.** Pushing the timber harder does not make the cut faster. It makes the blade bend, and the cut leans to one side. A steady, light push gives a straighter line and uses less battery. When the motor note drops, I ease off at once.

**Support long boards.** Hive boxes are cut from long boards, and a long board will tip the front of the saw if nothing holds up the far end. I keep a simple roller stand beside the bench. Before I added it, my cuts were never square at the end of a board.

**Mark first, cut second.** I mark every line in pencil and cut on the waste side of it. Bee space is small and unforgiving. A frame that is a little too wide will not sit in the box, and one that is too narrow lets the bees fill the gap with comb.

Here is the short routine I follow each time I use the saw:

- Check the battery is charged and seated firmly.
- Look over the blade for rust, a bright burr or a crack.
- Clear the table of offcuts and old wax.
- Mark the timber and set up support for long pieces.
- Make a trial cut on scrap before cutting good wood.
- Switch off, wait for the blade to stop, then clean the table.

**Keep wax away from the blade.** Old hive wood is often coated with wax and propolis. Both gum up the blade and make it run hot. I scrape the worst of it off with a hive tool before cutting, and I never push a sticky board straight in. A blade that has picked up wax cuts poorly until it is cleaned with a little solvent and a stiff brush.

**Take the battery out for any adjustment.** Because the saw has no cord, it is easy to forget that it can still start. Whenever I change the blade, clean around the guides or clear a jam, the battery comes out first. It is a small habit that costs only a few seconds.

**Plan the day around the weather.** The greenhouse warms up fast on sunny days, and a hot battery tires sooner. On cold mornings the battery gives less at the start. I do my longer jobs in the mild part of the day and keep the battery indoors overnight.

## Problems

This section lists the faults I have met and what I did about each. I write them as symptoms first, because that is how they show up in real life.

**Rust on the blade and table.** The greenhouse is damp, and the saw is grey metal with a painted finish that has chipped at the edges. Rust appears first on the blade and then on the bare table corners. I now wipe both with an oily rag after each session and keep a cloth over the saw. If I skip this for a week in wet weather, I see orange spots.

**Battery runs down faster than expected.** After several years of use the battery does not last as long as it once did. A job that I could finish on one charge in 2018 now needs a break halfway. The cause is partly age and partly the greenhouse temperature. My fix is to keep a second charged battery ready and to avoid leaving either one in the sun.

**Blade drifts to one side.** When the cut curves away from my line, the blade is usually dull, gummed with wax or not tensioned properly. I check these in that order. Most of the time a clean and a retension solves it. If the blade is dull, I replace it, because trying to push on makes everything worse.

**Blade wanders on thick propolis.** Hive parts that have been in use for years carry hardened propolis, and the saw does not like it. The blade skates over the hard patches and then bites suddenly. I scrape first and, for very bad pieces, I cut them by hand instead.

**Dust in the greenhouse.** Fine sawdust settles on seedlings and on the windows. I have learned to move any plants away before cutting and to sweep immediately afterward. Damp dust also turns into a paste on the floor, so sweeping while it is dry is much easier.

**Hard to see the saw under cover.** Because the saw is grey and I keep it under a cloth of similar shade, I sometimes bump into it in low light. I tied a bright strip of fabric to the cloth so the corner stands out.

**Things I still have not solved:**

- The paint keeps chipping at the table edges, and touch-up paint does not hold in the damp.
- The battery cover does not seal well, so moisture gets in around it.
- There is no good place to store spare blades where they stay dry.

When a new problem appears, I add it here with the symptom, the cause I found and the fix that worked, so the list keeps growing from real use.

## Overview

The Drerkner band saw is a band saw that I use for beekeeping work. It is grey, runs on a battery, and has stood in the greenhouse since it was installed in 2018. This handbook collects what I need to know to use it, look after it, and avoid hurting myself with it.

The key properties, stated once in one place:

- Kind: band saw
- Area: beekeeping
- Color: grey
- Energy source: battery
- Year installed: 2018
- Location: greenhouse

### What I use it for

The saw lives in the greenhouse because that is where I build and repair hive parts through the cooler months. It cuts boxes, frames, floor boards, feeder blocks and the odd stand leg. Because it runs on a battery, I do not need a cable across the floor. That matters in a greenhouse, where the ground is often damp and watering happens close by.

A band saw suits this work better than a circular saw for a few reasons:

- It makes curved and angled cuts, which helps with entrance reducers and shaped lids.
- The cut is narrow, so little good timber is wasted.
- It is quieter than most saws, so it does not upset the colonies kept near the greenhouse.
- The blade stays in contact with the work, so there is less kickback than on other saws.

### How it behaves in practice

The grey body hides sawdust well, but it also hides oil and wax. I have to look closely when I check it. Beeswax and propolis are the main nuisance. Old frames and boxes carry both, and they gum up the blade and the guides. A blade that drags or squeals usually needs cleaning before it needs replacing.

The battery gives me enough time for a normal session of cutting, but a long run of thick hardwood drains it faster than thin pine. I try to plan the cutting in batches and keep a charged spare battery nearby. When the saw starts to slow under load, I stop and swap the battery instead of forcing the cut. A weak battery makes the blade bind, and that is when mistakes happen.

### Where it sits

The saw stands on a firm bench in the greenhouse, away from the watering area and out of direct afternoon sun. Heat builds up under the glass in summer, and I do not like leaving the battery in that heat. Between sessions the battery comes out and goes on the shelf by the door, where it stays cooler and drier.

### Habits that keep it working

I keep a short routine and stick to it:

- Brush off dust and wax after every session.
- Check the blade for cracks or missing teeth before I switch on.
- Check the guides and the table for sticky residue.
- Take the battery out and store it separately when I am done.
- Wipe the grey casing so damp does not settle on it.

## References

These are the sources I rely on for this saw. Everything is my own material or things I own, kept in the greenhouse or in the workshop folder.

### Paper and handwritten sources

- The printed manual that came with the saw. It is kept in the folder on the shelf by the greenhouse door. I use it for the blade change steps and the battery fitting.
- My workshop logbook, where I note each blade change, each battery swap that went wrong, and anything unusual I heard or smelled while cutting.
- A sketch of the guide setup that I drew the first season after installation in 2018. It shows where the guides sit relative to a normal blade.
- A card pinned above the bench with the short startup and shutdown checks.

### Related notes in my own collection

- My notes on hive building, which list the cuts each box and frame type needs.
- My notes on wax and propolis cleanup, because those two substances cause most of the saw's problems.
- My notes on battery care, which cover storage, charging habits and how to tell when a battery is tired.
- My seasonal checklist for the greenhouse, which includes a saw inspection at the start and end of the cold months.

### How I use these sources

When something goes wrong, I look in the logbook first. Most problems have happened before, and my own entry is usually faster than the manual. If the logbook does not help, I go to the printed manual. If neither answers the question, I write the new problem and its fix in the logbook so the next check is easier.

I update this handbook when something changes: a new blade type, a different battery habit, or a new safety rule I learned the hard way. The original facts stay the same. The saw is a grey, battery-powered band saw for beekeeping work, installed in 2018 and kept in the greenhouse.

### Gaps I know about

- I do not have a record of every blade I have used, only the ones I noted in the logbook.
- I have not written down a full list of the timber types I cut most, and I should.
- The sketch of the guide setup is old and may no longer match how I set things now.

## Safety

A band saw is a simple machine, but the blade moves fast and does not care what it touches. A battery saw adds its own risks, because it can start with little warning and there is no plug to pull. I treat the battery as the power switch of last resort.

### Before I cut

- Take a moment to look at the blade. A cracked or dull blade can snap or wander.
- Check that the guides are set close to the work and that the blade is tracking properly.
- Make sure the bench is stable and the saw cannot rock.
- Clear off sawdust, wax and offcuts so my hands and the work move freely.
- Put on eye protection and hearing protection. I also wear a dust mask when cutting old frames, since they carry dust, wax and propolis.
- Remove loose cuffs, gloves and anything that could catch.

### While cutting

- Keep my fingers well away from the line of the blade. I use a push stick for narrow pieces.
- Feed the wood steadily. I do not force it, and I do not twist it on a straight cut.
- Support long boards so they do not tip or drag.
- Stop and swap the battery if the saw starts to slow. A weak battery makes the blade bind.
- Never reach behind the blade while it is still running down.

### Greenhouse conditions

The greenhouse brings its own hazards. Damp floors can be slippery, and moisture on the grey casing or the battery contacts can cause faults. I keep the saw away from the watering area and dry my hands before I handle the battery. Heat in summer can also make a battery unsafe to leave in place, so I store it separately in a cooler spot.

Bees can wander in through open doors. I do not cut while a bee is buzzing around my face, because a sudden flinch near a moving blade is dangerous. I stop, step back and let the bee leave.

### After cutting

- Remove the battery before cleaning or touching the blade.
- Brush away dust and wax, and do not blow it toward my face.
- Store the battery away from heat and damp.
- Leave the saw in a state where nobody can start it by accident.

### Old frames and wax

Old hive parts can carry more than wax. They can hold dirt, mould and residues I cannot see. I do not cut anything that looks diseased or smells wrong. I dispose of it instead, and I wash my hands thoroughly after handling it.

### If something goes wrong

If the blade snaps, I release the trigger, take out the battery, and wait until everything is still before I look. If I cut myself, I stop work at once, deal with the injury, and only return to the saw when I am calm. Afterwards I write what happened in the logbook so I can change my habits.

## Observations

These are my own notes from using the Drerkner band saw in the greenhouse. It is a grey band saw that runs on a battery, and I use it for beekeeping work. The area is beekeeping, and that is the only kind of cutting I do with it.

- Kind of device: band saw.
- Area: beekeeping.
- Color: grey.
- Energy source: battery.
- Year installed: 2018.
- Location: greenhouse.

The grey body is easy to spot against the green of the plants, but it also collects a film of dust and propolis. After a long session the casing looks almost brown, and I wipe it down before I put it away. The grey paint has held up well in the damp air of the greenhouse. I have seen only a little wear around the handle and the switch, where my hands rest.

Because the saw runs on a battery, I can use it anywhere in the greenhouse without dragging a cable across the wet floor. This is the main reason I chose it. The greenhouse gets humid in summer, and a mains cable on a damp concrete path is something I want to avoid. The battery is the part I watch most closely. It runs strongly for a good stretch and then fades fast, so I stop when the saw starts to sound slower than usual. A slow blade tears the wood instead of cutting it, and that leaves rough edges on frame parts.

What I usually cut with it:

- Spare frame timber that needs trimming to length.
- Offcuts of hive boxes that need a straight edge.
- Small pieces of scrap wood used to make feeders and entrance reducers.
- Old, damaged frames that I cut apart so the usable wood can be reused.

Things I notice every time I use it:

- The saw is quiet enough that I can work near the hives' storage shelf without disturbing the bees that wander into the greenhouse on warm days.
- The cut is cleanest when I feed the wood slowly and let the blade do the work.
- Wax and propolis on old frames gum up the blade. I notice this first as a slight squeal and a burnt smell.
- The blade tracks well when the guides are clean, and it drifts to one side when they are dirty.
- The battery warms up in the greenhouse heat, so I keep it out of direct sun between jobs.

I keep the saw on a low bench near the door. The spot is dry and the air moves, which helps in the humid months. I do not leave it on the floor, because water pools there after I water the plants. When I work, I lay a sheet under the bench to catch sawdust, because wood dust left on the greenhouse floor turns into a damp mess.

One habit has paid off. Before each session I look at the blade for cracks, check that it sits properly on the wheels, and make sure the guard is in place. It takes less than a minute and it has saved me from at least one bad surprise. I also clean wax off the blade with a stiff brush and a little solvent rag when the cutting starts to feel sticky.

## History

I installed the Drerkner band saw in 2018. At that time I was building more of my own beekeeping equipment and getting tired of carrying timber to a workshop elsewhere. I wanted a tool that lived where the work happened, and the greenhouse was the place with the most space and the best light. That is how the saw ended up there, and it has stayed there since.

The choice of a battery-powered machine came from the location. The greenhouse had no good place for a power point at the time, and I did not want to run an extension lead through the damp. A battery saw solved the problem, and it has kept solving it ever since. If I had to choose again, I would make the same decision.

How the use of the saw has changed over the years:

- In the first season I used it mostly for trimming new frame parts and learning how it behaved.
- Over the following years I started using it for repairs, cutting out rotted sections and fitting new wood.
- Later I used it more for small projects, such as feeders, stands and storage boxes for tools.
- More recently it has become a light-duty machine, used for quick trims instead of big jobs.

In the early days I made some mistakes. I pushed the wood too fast, I let wax build up on the blade, and I did not store the battery well. The result was uneven cuts, a blade that wore out sooner than it should, and a battery that lost capacity quicker than I expected. I have corrected these habits, and the saw now runs more reliably than it did in its first years.

The greenhouse itself has changed around the saw. Shelves have been added, a bench has been moved, and the plants have grown. Through all of it the saw has stayed grey, battery-powered and in the same corner. I have replaced consumable parts from time to time, mainly blades, and I have kept the battery in rotation so that it does not sit empty for months.

I keep the story of the saw simple because it is a simple tool. It was installed in 2018, it lives in the greenhouse, and it supports my beekeeping. Nothing dramatic has happened to it, and I am happy with that. A tool that does its job without drama is what I wanted when I bought it.

## Risks

A band saw is a dangerous tool even when it is small and battery-powered. The blade is exposed along the cutting line, and a moment of inattention can cause a serious injury. These are the risks I keep in mind whenever I use the Drerkner band saw.

- **Cuts and injuries:** Keep fingers well away from the blade. Use a push stick for small pieces, and never hold a tiny offcut by hand while cutting.
- **Wet conditions:** The greenhouse is humid and the floor can be slippery. A fall while holding a running saw is a real danger, so I keep the floor around the bench dry and clear.
- **Battery problems:** A battery that overheats, is damaged or is charged carelessly can fail badly. I do not charge it near dry plant material or in direct sun, and I stop using it if it swells, smells odd or gets very hot.
- **Blade breakage:** A cracked or dull blade can snap. I check it before each use and replace it when it shows damage.
- **Dust:** Sawdust from treated or old wood can irritate the lungs and eyes. I wear a mask and glasses, and I avoid cutting wood that I know has been treated with chemicals.
- **Wax and propolis:** Old frames often carry residue that burns and smokes on the blade. This can produce fumes and a sticky blade, so I scrape the worst of it off first.
- **Bees:** Bees visiting the greenhouse can land on the bench or the wood. A startled bee near a running saw is a distraction, and distraction is how accidents happen. I cut when few bees are around.
- **Disease on old equipment:** Frames from hives can carry bee disease. Cutting them spreads spores and dust, so I clean the saw and the bench afterward and do not reuse wood from any hive I suspect is sick.

Precautions I follow every time:

- Switch the saw off and wait for the blade to stop before clearing offcuts.
- Remove the battery before changing the blade or cleaning the guides.
- Keep the guard set close to the wood.
- Wear eye protection, hearing protection if the session is long, and a dust mask.
- Do not wear loose sleeves, gloves that can catch, or dangling cords.
- Keep children and visitors out of the greenhouse while the saw is in use.
- Store the saw and battery out of reach, in a dry place, when the work is done.

The most likely mistake is rushing. When I am tired or in a hurry, I push the wood harder and look away from the blade. On those days I put the saw down and do something else. The second most likely mistake is forgetting the battery after a job. A saw that is left with its battery in place can start by accident, so I take the battery out as part of tidying up.

## Open questions

These are the things I still have not settled about the Drerkner band saw. It is a band saw used for beekeeping, it is grey, it runs on a battery, and it was installed in 2018 in the greenhouse. I keep this list so I do not forget what I meant to check at the next quiet session.

- **Battery lifespan.** The saw has run on a battery since it was installed in 2018. I do not know whether the original cell is still the one inside. I have never written down when it was swapped. I want to open the compartment and look for a mark or a label that says when it was changed.
- **Greenhouse humidity.** The saw lives in the greenhouse, and the air there is damp for much of the year. I do not know if the moisture is slowly harming the switch and the contacts. The grey housing looks fine on the outside, but I have not looked inside for corrosion.
- **Blade wear on wax and wood.** Beekeeping work means cutting frame wood, hive boxes and sometimes lumps of old comb stuck to timber. I am not sure whether the wax residue dulls the blade faster than clean wood does. I need to compare how a blade feels after a season of hive parts against one used on plain boards.
- **Best cutting speed for thin frame stock.** The thin top bars and side pieces tend to chatter. I am not sure if a slower feed or a different blade tooth pattern would give cleaner cuts. I want to test a few offcuts and note the result.
- **Dust and propolis in the wheels.** Propolis is sticky, and it may build up on the guide wheels. I do not know how often it needs clearing. I should check the wheels after every few jobs for a while and find a rhythm.
- **Safe storage between seasons.** I am unsure whether the battery should stay in the saw over winter or come out and sit indoors. I have read both views and want to decide for this unit, since the greenhouse gets cold at night.
- **Replacement plan.** The saw has been in service since 2018. I have no plan for what to do when it finally fails. I should decide whether I would buy another band saw of the same kind or change to a different tool for the same work.
- **Noise and bee disturbance.** I do not know if running the saw near the hives upsets the bees. The greenhouse is a short walk away, but the whine may carry. I should watch the colonies on a day when I cut something and note any change.

I also want to find out whether the grey paint is hiding any cracks in the housing. A flashlight and a slow look should be enough, and I will add the answer to this list once I have done it.

## Supplies

Everything I keep on hand for the Drerkner band saw is listed here. The saw is a battery-powered band saw, so the supplies lean toward power and blade care. I store most of it in the greenhouse near the saw, in a lidded box on a shelf, so that damp does not reach it.

- **Spare blades.** I like to keep at least a couple of spare blades in the box. They are for cutting hive wood, and I label each one for the kind of work it has already done. A blade that has cut wax-stained timber stays marked, so I do not mix it up with a clean one.
- **Charged spare battery.** Because the energy source is a battery, a second charged battery saves a lot of time. I rotate them so neither one sits empty for long. A flat battery left for weeks is the quickest way to ruin it.
- **Battery charger.** It stays on a dry shelf away from the watering area. I plug it in only when I am in the greenhouse and can see it.
- **Light machine oil.** A few drops on the moving parts keep them smooth. I use very little, because oil and sawdust together make a paste.
- **Dry cloths.** I wipe the grey housing after each session. The cloths also take up the fine dust that settles on the table.
- **Soft brush.** It clears sawdust from the blade guides and from around the wheels. A stiff brush would scratch the surfaces, so I keep it soft.
- **Warm water and a little soap.** For cleaning off propolis and wax. Hot water softens the wax, and soap lifts the sticky film. I dry every part afterward.
- **Rubbing alcohol.** Propolis that will not come off with soap usually dissolves in this. I use it sparingly on a cloth and never pour it over the saw.
- **Silica gel packets.** I drop a few into the supply box to fight the humidity of the greenhouse. They get dried out in a warm place when they stop working.
- **Spare wood offcuts.** Scrap pieces are handy for testing a cut before I commit to a good board. They also let me check that a fresh blade is running straight.
- **Protective gear.** Safety glasses, ear protection and a dust mask. Beekeeping wood can carry old wax and dust, and I do not want to breathe it in.
- **Notebook and pencil.** I write down what I did to the saw and when. This is meant to fix the gaps listed under the open questions, such as when a battery was changed.

I check the box at the start of each season and replace anything worn or missing. If I notice that a supply has run low during a job, I write it on the inside of the lid so I remember to restock.

## Tools

These are the tools I use to look after the Drerkner band saw, as opposed to the consumables above. The saw is grey, battery-powered and sits in the greenhouse, where it has been since 2018, so the tools are chosen to work in a small, damp space with little room to move.

- **Screwdriver set.** A small set with flat and cross heads. It opens the guard and the battery compartment. I keep it clean and dry, since a rusty tip can slip and chew a screw head.
- **Hex keys.** Used to adjust the blade guides and the table. I keep them on a ring so I do not lose the one I need.
- **Small adjustable spanner.** For the nuts that hold the wheels and the fence. I prefer a snug fit to avoid rounding the edges.
- **Flashlight.** The greenhouse light is uneven, and the inside of a band saw is dark. A flashlight also helps when I check the housing for hairline cracks.
- **Tension check by hand.** I do not have a special gauge. I press the blade gently at its midpoint and judge the give. I have been meaning to find a better method, which is noted in the open questions.
- **Square.** I hold it against the table and the blade to check that the cut will be straight. This matters for hive boxes, because crooked joints leave gaps that bees will fill with propolis.
- **Clamps.** Two or three clamps hold the fence or a stop block in place. They also hold work steady when I cut thin frame stock.
- **Push stick.** It keeps my fingers away from the blade. I make new ones from scrap whenever the old ones get chewed.
- **Multimeter.** Handy for checking the charge in the battery and for testing the contacts if the saw stutters. I only use it for simple readings.
- **Wire brush.** For light rust on the metal parts and for cleaning battery contacts. I use it gently, then wipe the dust away.
- **Scraper.** A plastic or wooden scraper lifts propolis and wax from the table without marking the surface.
- **Work light on a stand.** If I have a long job, I set this up beside the saw so I can see the line I am cutting.

When I finish a session I put each tool back in the same place, so that next time I can find everything in the dim light. If a tool goes missing, I check the greenhouse floor first, because small items fall between the slats and are easy to overlook.

## Ideas

The Drerkner band saw is a grey, battery-powered band saw. I installed it in 2018, and it lives in the greenhouse. These are ideas I want to try or keep in mind for it. Most are about making beekeeping woodwork easier on a bench that is damp half the year.

- **Dedicated frame-stock station.** Cut all the top bars, bottom bars and side pieces for hive frames in one session. Set a stop block on the table once, then run the whole batch without moving it. That keeps every piece the same length, which matters because bees punish sloppy spacing with burr comb.
- **Offcut bin for smoker fuel.** Clean pine and untreated softwood offcuts burn gently in the smoker. A labelled box under the saw table keeps them dry and separate from treated or painted scraps, which must never go near the smoker.
- **Slotted jig for wedge strips.** A simple sled with a fixed angle would let me cut the thin wedge strips that hold foundation in the frame groove. I should build it from scrap and keep it hanging on the wall beside the saw.
- **Battery rotation habit.** Because the saw runs on a battery, I want one pack always on the charger and one in the saw. A small wall shelf with a charging spot near the door would make this automatic.
- **Humidity buffer.** The greenhouse gets warm and wet. A tray of silica or a small sack of dry rice in the tool cabinet might slow rust on the blade guides and the table. I should test whether it helps over a full season before trusting it.
- **Repair cuts for old boxes.** Old hive boxes sometimes have rotten corners. The saw could trim the damaged part cleanly so I can splice in a new piece instead of scrapping the whole box.
- **Sorting scrap by use.** Keep three bins: smoker fuel, kindling, and small pieces for jigs. Anything else goes out. This stops the floor from filling up and keeps the area safe to walk through.
- **Dust control.** A cheap hood and a hose to a small vacuum would keep fine dust off the plants nearby. Sawdust on leaves is a nuisance, and some of it may carry traces of whatever the wood was treated with.

Things I considered and dropped:

- Mounting the saw permanently on a wall bracket. It is too awkward to reach the blade for changes.
- Using it for cutting plastic queen excluders. The blade clogs and the edges melt.
- Running it off a mains adapter. It defeats the point of a battery tool that I can move around the greenhouse.

## Setup

This section records how the saw is set up in the greenhouse, so I can rebuild the arrangement if I ever have to move it or clear the space.

**Position.** The saw stands on a sturdy bench along the long side of the greenhouse, away from the watering area. The bench is level and bolted so it does not creep when I push timber through. I keep a free zone around the saw so that long boards can pass through without hitting pots or shelves.

**Power.** The energy source is the battery. There is no cable to trip over, which is the main reason I chose this arrangement. The charger sits on the shelf by the door, off the floor and away from any splash. I never charge a pack that has just come out of a hot saw; I let it cool first.

**Blade and guides.** Before a work session I do these things in order:

1. Check the blade for cracks, missing teeth and a sticky coating of resin.
2. Set the upper guide just above the thickness of the wood.
3. Check the blade tension by hand with the battery removed.
4. Turn the wheel by hand once to confirm the blade tracks in the centre.
5. Put the battery in only after all of that is done.

**Table and stops.** The grey table is wiped dry before each use. I clamp a fence to the table for rip cuts and a stop block for repeat lengths. For hive parts I mark the stop position with a pencil line on the fence so I can reset it if it is knocked.

**Light and air.** The greenhouse has good daylight, but on dull days I use a clip lamp aimed across the blade, not straight down, so that the cut line casts a shadow I can follow. I open the vents and the door when cutting, which clears dust quickly.

**Storage between sessions.**

- Remove the battery and put it on the charger.
- Brush off dust with a stiff brush, especially around the wheels.
- Release some blade tension if the saw will sit unused for a while.
- Cover the saw with a cloth, not plastic, so that moisture does not get trapped underneath.

**Safety basics.** I wear eye protection and hearing protection, tie back loose clothing, and keep my hands well clear of the blade line. A push stick hangs on a hook within reach. I do not cut when I am tired or hurried, and I keep a first aid kit in the same cupboard as the bee suit so I always know where it is.

**Known quirks.** The greenhouse is humid in the morning, and the table can feel faintly damp even after wiping. I tend to cut in the afternoon when things have dried. In summer the heat builds up, so I take breaks and let the battery rest.

## Checklist

I run through this before and after each cutting session. It is short on purpose so that I will actually use it.

**Before cutting**

- [ ] Bench is clear and the floor around the saw is free of offcuts.
- [ ] Table is dry and wiped clean.
- [ ] Blade is sharp, straight and free of resin.
- [ ] Blade tension and tracking checked with the battery out.
- [ ] Guide set just above the wood.
- [ ] Fence and stop block clamped and checked against the pencil mark.
- [ ] Wood is untreated and dry, or I know exactly what treatment it has.
- [ ] Eye and hearing protection on.
- [ ] Charged battery ready, spare pack on the charger.
- [ ] Push stick within reach.

**During cutting**

- [ ] Feed slowly and let the blade do the work.
- [ ] Keep fingers outside the marked safe zone.
- [ ] Stop if the blade wanders or the sound changes.
- [ ] Never reach behind the blade while it is moving.
- [ ] Sort offcuts straight into the right bin.

**After cutting**

- [ ] Battery removed and set on the charger.
- [ ] Dust brushed off the table, wheels and guides.
- [ ] Blade tension eased if the saw will rest for a while.
- [ ] Saw covered with a cloth.
- [ ] Smoker-fuel offcuts stored dry; treated scraps thrown out.
- [ ] Vents and door set the way I want them for the night.

**Seasonal checks**

- [ ] At the start of the beekeeping season, cut and stack the spare frame parts I expect to need.
- [ ] After winter, look for rust on the table and wheels and wipe with a light oil.
- [ ] Replace the blade if it burns the wood or cuts crooked even after cleaning.
- [ ] Look at the battery packs for swelling, heat or shortened run time, and retire any that look wrong.
- [ ] Confirm the bench is still bolted and level.

If I only have a minute, I do three things: remove the battery, check the blade, and clear the floor. Everything else can wait, but these three prevent most accidents with the saw.

## Maintenance

The Drerkner band saw is a grey, battery-powered band saw that has been installed in the greenhouse since 2018. I use it for beekeeping work: cutting hive boxes, frame stock, and the odd bit of scrap for repairs. The greenhouse is damp and dusty, so the saw needs more regular care than a tool kept in a dry workshop. These notes are what I actually do, in the order I do it.

### Habits after every use

The most useful maintenance is the small stuff at the end of a session. If I skip it, the problems show up weeks later.

- Take the battery off the saw before touching anything else. This is the first step of every job below.
- Brush the sawdust off the table, the guides, and the wheel covers. Wax and propolis residue from old hive parts makes the dust sticky, so a stiff brush works better than a cloth.
- Wipe the blade with a dry rag, moving away from the teeth, never along them.
- Check that the blade has not wandered off the middle of the wheels.
- Release the blade tension if the saw will sit unused for more than a few days. A blade left tight for a long time stretches and the wheel tyres get flat spots.
- Put the saw back in its usual spot on the greenhouse bench, away from the watering line and out of the direct midday sun.

### Cleaning

Beeswax is the main enemy. Old frames and boxes carry wax, propolis, and a little honey, and all of it builds up on the blade, the guides, and the tyres. When the blade starts to burn or drag the wood, I clean rather than assume it is blunt.

For a full clean I remove the battery, open the wheel covers, and take the blade off. I soak a rag in a mild solvent made for resin and scrub the blade carefully, wearing gloves. Then I wipe the wheel tyres with a barely damp cloth. I do not use solvent on the tyres because it can dry out the rubber. The guides get a brush and a wipe. When everything is dry I refit the blade and check the tracking before putting the battery back.

The grey casing can be cleaned with a damp cloth and a drop of dish soap. I never spray water on the saw. The greenhouse already has enough humidity, and the motor housing and the battery contacts do not need more.

### Blade care

The blade is the part I deal with most. A band saw cuts well only when the blade is sharp, tensioned properly, and tracking in the right place.

- **Sharpness:** If I have to push the wood harder than usual, or the cut edge looks rough, the blade is going dull. I replace blades rather than sharpen them, because the work is small and blades are cheap.
- **Tension:** I tension the blade until it deflects only slightly when I press the side with a finger. Too loose and the cut wanders. Too tight and the blade breaks early.
- **Tracking:** With the cover open and the battery off, I turn the wheel by hand and watch where the blade sits on the tyre. It should ride near the middle. I adjust the tilt knob a little at a time and spin again.
- **Guides:** The side guides should almost touch the blade without pinching it. The thrust bearing behind the blade should sit just clear until the wood pushes the blade back.
- **Storage:** Spare blades hang coiled on a nail in a dry box, not loose on the greenhouse bench.

### Battery care

Because the saw runs on a battery, its health depends on how I treat the pack. The greenhouse swings between hot and cold, which is hard on batteries.

- Charge the battery indoors, never in the greenhouse overnight in winter or in summer heat.
- Do not leave the pack on the saw between sessions.
- Do not run the pack completely flat. When the saw slows or sounds weak, I stop and swap or recharge.
- Keep the contacts clean and dry. A pencil eraser removes light film, and a dry cloth does the rest.
- If I will not use the saw through the cold months, I store the pack partly charged in a cool, dry room in the house.
- Check the pack for swelling, cracks, or a warm smell. Any of these means the pack is retired and recycled properly.

### Seasonal routine

At the start of the beekeeping season, when I begin preparing boxes and frames, I do a full check. I look over the casing, test the switch and the brake, inspect the wheel tyres, replace the blade, and clean the table. I also run a few test cuts on scrap to confirm the saw cuts straight and square.

At the end of the season I do a deeper clean, wax the table with a thin coat of paste wax so wood slides easily, and store the saw with the blade tension released. Once a year I also check that the table is square to the blade, using a small square, and adjust the stop if it has drifted.

### Troubleshooting

| Symptom | Likely cause | What I do |
|---|---|---|
| Blade burns the wood | Wax build-up or dull blade | Clean it, then replace if still poor |
| Cut drifts to one side | Dull blade or loose guides | Replace blade, reset guides |
| Blade slips off the wheel | Poor tracking or low tension | Retrack, raise tension a little |
| Saw loses power quickly | Tired or cold battery | Warm the pack indoors, charge, test another |
| Vibration while cutting | Flat spot on tyre or bent blade | Fit a fresh blade, inspect tyres |
| Saw will not start | Dirty contacts or flat pack | Clean contacts, recharge |

### Safety notes to myself

Wear eye protection every time, because wax chips and splinters fly. Keep fingers well clear of the blade path and use a push stick for narrow pieces. Never adjust the guides while the battery is attached. Do not cut wood that may contain nails or staples without checking it first, which matters with old hive parts that have been repaired many times. Tie back sleeves, and keep the greenhouse floor around the saw free of hoses and trays so I do not trip.

## Parts

This section lists the parts I keep track of on the saw, what each one does, and what I do when it wears out. The serial number of the Drerkner band saw is SN-99118894. I keep it here so I can quote it if I ever need to order a part or ask for help.

### Summary of the saw

- **Device:** Drerkner band saw
- **Kind:** band saw
- **Area:** beekeeping
- **Color:** grey
- **Energy source:** battery
- **Year installed:** 2018
- **Location:** greenhouse
- **Serial number:** SN-99118894

### Main parts

- **Frame and casing:** The grey body holds everything together. It is solid, and the only damage it has taken is surface scratches from years on the greenhouse bench.
- **Upper and lower wheels:** The blade runs around these two wheels. The lower wheel is driven by the motor, and the upper one can be tilted and raised to set tracking and tension.
- **Wheel tyres:** Rubber rings on the wheels cushion the blade and grip it. They are the part most likely to wear flat or crack, especially if the blade is left tight for long periods.
- **Blade:** A thin steel loop with teeth. It is the consumable part, and I keep spare blades on hand.
- **Upper guide assembly:** Side guides and a thrust bearing mounted on a post that slides up and down. I set its height just above the wood each time.
- **Lower guide assembly:** A fixed set of guides under the table, which steadies the blade below the cut.
- **Table:** A flat surface where the wood rests. It can be tilted for angled cuts, and I wax it every season.
- **Fence or rip guide:** A straight bar that helps with repeated cuts, such as cutting frame stock to the same width.
- **Motor:** A battery-driven motor inside the casing. It needs no routine service beyond keeping dust out of the vents.
- **Battery pack and dock:** The pack slides into a dock at the back of the saw. The dock contacts must stay clean.
- **Switch and brake:** The trigger or switch starts the motor, and the brake stops the blade quickly when released. I test it at the start of each season.
- **Wheel covers:** Hinged doors that protect me from the moving blade. They are also where dust collects, so I open them often.
- **Dust port:** A small outlet for a vacuum hose. In the greenhouse I use it when cutting for long sessions, to keep the dust off the plants.

### Wear parts and what I replace

Some parts wear out on a predictable schedule, and some only fail when something goes wrong.

- **Blades:** Replaced whenever they dull or after a break. This is the most frequent change.
- **Tyres:** Replaced when they show cracks, flat spots, or when the blade will not track properly even after careful adjustment.
- **Guide blocks and bearing:** Replaced when worn grooves appear or the blade is no longer supported evenly.
- **Battery pack:** Replaced when run time falls sharply, or at once if damaged.
- **Table insert:** The slot around the blade wears from use. I swap it when the gap becomes wide enough to catch thin offcuts.
- **Brake and switch parts:** Rarely replaced, but they are safety parts, so I do not delay if they misbehave.

### Ordering and records

When I need a part I go by the serial number, SN-99118894, along with the kind of saw and the year installed, 2018. I do not trust memory for part names, so I note the part's function and measure the old one before ordering. For blades, I measure the old loop and its width and thickness, and write the result on the storage box.

I keep a short log in the greenhouse toolbox that records each replaced part and the reason. It helps me see patterns, such as tyres wearing faster in hot summers or blades dulling quickly on old wax-heavy boxes.

### Spare parts kit

The small kit I keep near the saw contains:

- Several spare blades, coiled and labelled.
- A spare set of guide blocks.
- A spare battery pack, kept charged indoors.
- A small brush and a rag for cleaning.
- A hex key set that fits the adjustment screws.
- A tin of paste wax for the table.

Having this kit nearby means a quick fix rarely turns into a trip to a shop, which matters because the saw is useful mostly during busy beekeeping weeks, when time is short.
