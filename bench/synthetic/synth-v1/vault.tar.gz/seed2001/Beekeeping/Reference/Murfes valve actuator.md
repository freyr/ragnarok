---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Murfes valve actuator."
---

# Murfes valve actuator

## Lessons

The Murfes valve actuator is a valve actuator that I use for beekeeping. It sits at the pond, where it opens and closes the valve that feeds the bees' water supply. I installed it in 2018, and it has been running there since. It is green, which helps it blend into the reeds and the grass along the bank, so it does not draw attention from visitors who walk past.

The energy source is solar. This was the best decision I made with the setup. There is no cable to bury and no battery charger to remember. The panel faces open sky over the water, and the actuator has kept working through a lot of overcast weeks. In the darkest part of winter it moves more slowly, but the valve is not needed much then, so it does not matter.

Things I learned over the years:

- Put the actuator where the panel gets sun for most of the day. In my first season a willow shaded it in the afternoon, and I had to trim the branch back.
- Check the valve by hand once in spring, before the bees start to use the water. A stiff valve makes the actuator work too hard and wastes stored power.
- Keep a log of each check. I record the results with the [[Liolkrios data logger]], and I compare the readings from one season to the next. A slow change in the readings tells me about a problem before the valve actually fails.
- Wipe the panel after pollen season. Pollen and dust build up faster than I expected, and a dirty panel gives noticeably less power.
- Do not trust it blindly. Even with a good device, I walk down to the pond every week in summer and look at the water level myself.

If something odd happens, I write it down the same day. Notes made later are never as clear as I think they will be.

## Parts

The main parts of the Murfes valve actuator are listed here so I can find them quickly when something needs replacing.

- Serial number: SN-70437013
- Housing: a green weatherproof case that holds the motor and the gearbox.
- Solar panel: mounted on top of the housing, tilted toward the south.
- Motor and gearbox: these turn the valve stem. They are the parts most likely to wear, though after all these years they still run smoothly.
- Valve coupling: the piece that joins the actuator to the valve stem. I check the fixing bolts here every spring.
- Wiring and seals: short internal leads and rubber seals around the cover. The seals are the first thing I look at if I find damp inside.

Spare fixings and a small tube of grease are kept in the [[Draensork shed]], on the shelf by the door. I keep them together in one box, so I do not need to search when I am standing in wet grass with the cover open. The grease goes on the coupling and the stem, only a thin layer, because too much collects dirt.

When I order anything for it, I quote the serial number above to the supplier. It is stamped on the housing, but the stamp is hard to read once algae gets on it, so having it written here saves time.

## Safety

Most of the risk around this device comes from the location, not from the device itself. The pond bank is soft and slippery, especially after rain.

- Stand on firm ground, or on the flat stone at the edge, when working on the actuator. Never lean out over the water alone.
- Tell someone before doing repair work at the pond. [[Mastend Runpith]] usually knows when I go down there, and I like to keep it that way.
- Cover the panel with a cloth or turn the actuator off before opening the housing. A solar unit can still have power in it in bright light, even when nothing seems to be moving.
- Keep fingers away from the valve stem and the coupling when the actuator might start. It can move without warning when the controller decides it is time.
- Wear gloves and wash my hands afterward. The pond water is not clean, and the grease is not something I want on my skin.
- Stay clear of the hives while working nearby. Bees come to the pond to drink, so I avoid sudden movements, and I do not work there on hot afternoons when traffic is heaviest.
- Close the housing fully when finished and check that the seals sit flat. A badly closed case lets in water, and that is the most common cause of trouble.

If the actuator fails with the valve stuck open or closed, I operate the valve by hand and write a note for later repair, rather than trying to fix it on the spot in poor conditions.
