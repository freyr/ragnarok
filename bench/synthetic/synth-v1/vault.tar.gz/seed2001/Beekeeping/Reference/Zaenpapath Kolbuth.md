---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Zaenpapath Kolbuth."
---

# Zaenpapath Kolbuth

## Ideas

Zaenpapath Kolbuth is a plumber, and I keep this note because his trade overlaps with my beekeeping more often than I expected. I have known him since 2018. He is reachable in person only, and he works weekdays. Those three facts decide how I plan anything with him: I go to see him, and I go on a weekday.

Ideas I want to try with him:

- Ask him to look at the water supply to the apiary. A clean, steady drinking spot near the hives keeps the bees from visiting the neighbours' taps and troughs. A small drip line with a shallow tray would do it.
- Ask whether a basic hand-wash point can be added near the honey room. Right now I carry water in cans, and that is tiresome in the middle of extraction.
- Talk through the layout in [[Solsas shed plan]]. The shed has a sink corner, and he may have opinions on where the drain should run and how to keep it from freezing.
- Ask what he thinks of moving water for the wax-melting and cleaning area. The notes in [[Giorkvurk circulation pump study]] cover what I learned about small pumps, and I would like his view on whether any of it is sensible for a hobby setup.
- Check whether he knows a source for food-safe fittings and hoses. Anything touching water near honey should be food-safe.

## Risks

- Contact is in person only. If I need him urgently and he is not at his workshop, I have no fallback. I should not leave anything time-sensitive to him.
- He works weekdays. Weekends, when I do most of my hive work, are out. Any job that depends on him has to be planned around a weekday visit, and that may clash with my own schedule.
- Water near honey is a hygiene risk. Poor drainage, standing water or the wrong materials could taint the product or attract pests. I should not accept a cheap shortcut here.
- Bees and open water work can conflict. If a leak or a damp patch becomes a new water source, the bees will find it and cluster there. This is a nuisance for neighbours too.
- Cold weather can damage exposed pipes in the apiary. Anything outdoors needs draining or insulation before winter.
- Mixing up studies. The notes I keep on equipment, such as [[Glurkolel dehumidifier study]], were written for my own situation. I should not hand him a note and assume he will read it the way I meant it. I should bring the question, not the whole file.

## Contracts

The only formal arrangement on record is a contract with Zaenpapath Kolbuth, dated 2020-10-13. It covered plumbing work connected to my workspace at the time. I keep this entry so that I can tell, years later, what was agreed and when.

| Property | Value |
| --- | --- |
| Name | Zaenpapath Kolbuth |
| Role | plumber |
| Area | beekeeping |
| Contact | in person |
| Availability | weekdays |
| Known since | 2018 |
| Contract date | 2020-10-13 |

Notes on how I handle contracts with him:

- Agree the scope in person and write it down the same day.
- Note who supplies the materials.
- Confirm the weekday when the work will happen, since he does not work weekends.
- Keep any paper copy with the equipment records, next to [[Tronas band saw 2020]], which dates from the same period.

## Open questions

- Does he take small jobs, or does he prefer larger installations? I have never asked directly.
- Would he be willing to visit the apiary site, or would he rather I describe the problem at his workshop?
- Is there any way to leave a message when he is out, given that in person is the only route? Maybe a note left with someone who sees him regularly.
- What is his view on food-safe materials for a honey room?
- Can the drainage in the shed be done without a trench, or does it need real groundwork?
- Would he be open to a seasonal check each autumn, before the cold arrives?

## Background

I met Zaenpapath Kolbuth in 2018, when I needed a plumber and someone recommended him in person. He has been my plumber ever since. His work is plain and sturdy, and he explains what he is doing without fuss.

Beekeeping is the area this note falls under, because that is where I most often need him: water supply, sinks, drainage and hygiene around the honey handling. He is not a beekeeper himself, so I should explain the bee side of any request. Things that seem obvious to me, like bees fixating on a damp spot, are not obvious to him.

Past work with him overlapped with my workshop projects. When I was weighing tools, such as in [[Lisdrior band saw study]], I sometimes asked him practical questions about water, dust and electrics near wet areas. He answers what he knows and says clearly when something is outside his trade.

## Setup

How I work with him in practice:

1. Go to see him in person. There is no other contact route to rely on.
2. Pick a weekday, since that is his availability.
3. Bring a short written description of the job, a rough sketch and any measurements I have.
4. Explain the bee-related constraints up front: water placement, drainage, hygiene and winter.
5. Agree the scope and who buys materials.
6. Write down the outcome the same day and file it here, linked to the relevant plan, such as [[Solsas shed plan]].

Things to bring each time:

- A sketch of the site
- A list of questions
- A note of anything I already know about the existing pipes
- Time to talk, since he is more helpful when he is not rushed

I keep this note updated after each visit, with new ideas, new risks and anything that changes the open questions above.
