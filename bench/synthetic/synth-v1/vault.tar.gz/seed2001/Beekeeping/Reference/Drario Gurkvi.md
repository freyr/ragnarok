---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Drario Gurkvi."
---

# Drario Gurkvi

## Overview

Drario Gurkvi is my mentor in beekeeping. I have known him since 2012, so he has watched me go from nervous beginner to someone who can run a few hives without panicking. He is the person I ask first when something looks wrong in a colony and I can't tell if it matters.

The practical details are simple. His area is beekeeping, and his role for me is mentor. The best way to reach him is email. He is available on weekends, so I save my questions during the week and send them together on Friday evening. Weekday messages tend to sit unanswered, and that's fine, since he has his own work.

What he has taught me over the years is mostly habits rather than tricks: inspect slowly, write down what I see, and don't change several things at once. He also pushes me to build my own gear instead of buying it. That fits with the workshop notes I keep, such as [[Lirktrae heat exchanger]] for warming the honey room, [[Mepiostre air compressor plan]] for the cleaning and blowing tasks, and [[Drursus level sensor]] for watching the settling tank.

When I want a second opinion on a power setup for the apiary, I check [[Trildeth solar charger handbook]] first and then ask him if the numbers still look off.

## Contracts

Drario and I have one written arrangement, which covers the mentoring and the shared use of his extraction equipment. The contract date of Drario Gurkvi is 2019-07-14. I keep it here so I can find it quickly if we ever need to revisit the terms.

Around that time I was also working on the wax-melting setup, and the temperature control notes are in [[Krioskus kiln controller notes 2019]]. He reviewed those and suggested a safer way to handle the cutoff. For the valve work on the honey tank I used [[Murfes valve actuator]] as my reference.

If I need an outside opinion on equipment, [[Mastend Runpith]] is the other person I would contact. I still go to Drario for anything about the bees themselves.

Things to remember about the arrangement:

- It is informal and based on trust.
- Visits happen on weekends only.
- I confirm each visit by email beforehand.
- I return borrowed equipment cleaned and with a short note about any problems.
