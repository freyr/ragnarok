---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Muthdralpe scale."
---

# Muthdralpe scale handbook

## Supplies

This section lists what I keep on hand for the Muthdralpe scale. It is a grey battery-powered scale for beekeeping. I installed it in 2024 at the pond, where it weighs a hive platform through the season. Everything below is written for my own use, so it assumes I am standing at the pond with wet boots and one free hand.

### Core kit

- The Muthdralpe scale itself, grey, with its platform plate and the cable that runs from the plate to the display unit.
- A spare set of batteries. The scale runs on battery, and nothing else powers it. I keep the spares in a sealed tub, not in the shed, because the shed gets damp.
- A small dry bag for the display unit when rain is forecast.
- A flat, level paving slab as a base. The scale reads wrong if the ground under it rocks.
- A spirit level, the short kind that fits on the plate.
- A notebook with a pencil. A pen skips on damp paper.

### Cleaning and care

- A soft brush for wax crumbs and dead bees on the plate.
- A cloth, slightly damp, for the grey housing. I do not use solvent, because it dulls the finish and I think it can cloud the display window.
- A tube of plain grease for the battery cover seal.
- A few cable ties and a roll of tape for the cable run along the post.

### Reference weights

I use a known weight to check the scale after any change. A bag of sand, sealed and labelled, does the job. I weigh it on the kitchen scale first and write the figure on the bag. I do not trust a weight I have not checked at home.

### Related notes I keep nearby

- [[Nithden greenhouse]] covers the other site where I keep spare parts and where the tub of batteries sometimes lives over winter.
- [[Perkgon solar charger plan]] is my idea for moving away from disposable cells. It is only a plan. The scale is still on battery, and I have not changed that.
- [[Susrion level sensor]] and [[Laga level sensor notes]] are about the water level at the pond. The water level matters for this scale, since the ground near the pond gets soft after heavy rain.

### Things I do not need

I used to carry a full toolbox. In practice a small screwdriver and the supplies above are enough. The scale has no moving parts I can service myself, so I do not carry anything for that.

## Setup

This section is the order I follow when I set the scale up or reset it after moving it. The scale stands at the pond, and I installed it in 2024. The steps are written so that I can do them again after a flood or a clearing job without thinking.

### Choose and prepare the spot

1. Pick a place near the pond that stays dry underfoot. The bank is tempting because the bees fly over the water, but the soil there shifts. I stay back from the edge.
2. Clear the grass. Long stems touch the plate and add false weight when they are wet.
3. Lay the paving slab. Press it down with my boot and check that it does not rock on any corner.
4. Put the spirit level on the slab. If the bubble drifts, I lift the slab, add or remove a little sand underneath, and try again. I repeat until the bubble sits in the middle.

### Place the scale

1. Set the grey platform plate on the slab. The cable socket faces away from the pond, so water blowing off the surface does not hit it.
2. Check the level again, this time on the plate itself. A small tilt is acceptable, but a visible one is not.
3. Run the cable along the post and fix it with ties. I leave a loop of slack at the bottom so that rain runs off the loop and not into the socket.
4. Mount the display unit at a height where I can read it without bending. I keep it out of direct sun, since the display fades when it gets hot.

### Power

1. Open the battery cover and look at the seal. If it is dry or cracked, I add a thin smear of grease.
2. Insert fresh batteries. The scale is battery powered, so this is the only power step. I check the direction of each cell twice.
3. Close the cover and press it down all the way around until it sits flush.
4. Switch on and wait for the display to settle. If it flickers, I take the batteries out, wait a short while, and put them back.

### Zero and check

1. With the plate empty, set the zero on the display.
2. Place the sealed sand bag in the middle of the plate. Read the value and compare it with the figure written on the bag.
3. Move the bag to each corner in turn. The reading should stay close to the same. If one corner reads differently, the slab is not level or something is touching the plate.
4. Remove the bag and confirm the display returns to zero.
5. Write the date, the reading and the battery state in the notebook.

### Putting the hive on

1. Zero the scale again with the empty stand in place, if I use a stand on top of the plate.
2. Lift the hive on slowly and avoid knocking the plate sideways.
3. Wait a minute. The first reading often drifts as the bees settle, so I note the steadier value.
4. Record the reading in the notebook along with the weather.

### Notes from earlier work

I based some of this routine on earlier experiments with other controllers and sensors. [[Krioskus kiln controller notes 2019]] and [[Nevirkun kiln controller study]] taught me to log a baseline before changing anything, which is why I write down the empty reading and the sand bag reading every time. [[Kaesme Laerdond tests]] has my comparison method for repeated readings, and I use the same habit here: take three readings and trust the middle one.

### Routine checks

- After heavy rain, I go back to the pond and look at the slab and the cable.
- When the display dims, I swap the batteries and do not wait for it to die.
- At the end of the season, I take the batteries out and store them dry.

## Risks

This section covers what can go wrong with the Muthdralpe scale, and what I do about it. Most problems come from the location, because the scale stands at the pond and the pond brings damp, soft ground, animals and wind.

### Water and damp

- **Water in the socket.** This is the most likely failure. The cable socket on the grey plate is the weak point. I keep the slack loop in the cable and point the socket away from the water. If the display gives odd readings after rain, I assume damp first.
- **Condensation in the display unit.** Cold nights followed by warm mornings fog the window. I use the dry bag in wet weather and I do not open the unit outdoors when it is foggy.
- **Flooding.** If the pond rises, the slab can float or tilt. After a flood, I redo the whole setup instead of just checking the reading. The level notes in [[Susrion level sensor]] and [[Laga level sensor notes]] help me judge whether the bank is likely to flood.

### Power

- **Flat batteries.** The scale uses battery only, so a dead cell means no readings at all. The display usually dims before it stops. I treat a dim display as a sign to change the cells that day.
- **Leaking cells.** Old batteries can leak and ruin the contacts. I never leave a spent cell inside through winter.
- **Cold.** Batteries lose strength in cold weather, and the readings can drop out. I carry spares and keep them warm in a pocket.
- **Switching to another power source.** I have considered it in [[Perkgon solar charger plan]], but I have not done it. Until I do, I plan around battery limits only.

### Accuracy

- **Uneven ground.** If the slab sinks on one side, the reading shifts. I check the level at each visit.
- **Wind.** A strong gust against the hive pushes on the plate and gives false weight. I note windy days in the notebook and treat those readings with suspicion.
- **Wet vegetation and debris.** Grass, leaves and wax crumbs add weight. I brush the plate before every reading.
- **Sun heating.** A grey housing in full sun warms up, and the reading can wander. I take readings in the morning when I can.

### Bees and animals

- **Stings.** I do the setup and zeroing before opening anything, and I keep movements slow near the hive.
- **Animals.** Birds and small mammals near the pond may chew the cable. I tie it close to the post and check it for bites.
- **Lifting.** A full hive is heavy. I lift with a helper when I can, because dropping a hive on the plate would damage it and anger the colony.

### Personal safety

- The bank near the pond is slippery. I wear boots with grip and I do not carry the hive and the sand bag together.
- I do not work alone at the water when the ground is soft.
- I keep my phone in a pocket that closes.

### What I do when something looks wrong

1. Stop and write down the reading and the conditions.
2. Remove the load and check zero.
3. Check the level, the cable, the socket and the batteries, in that order.
4. Use the sand bag to test again.
5. If the reading is still wrong, I leave the scale off and compare with the notes in [[Kaesme Laerdond tests]] before changing anything.

## Safety

The Muthdralpe scale is a grey scale that runs on a battery. It was installed in 2024 beside the pond, and that location is the main source of risk. Most of what follows comes from working near the water with hives that are heavy and sometimes angry.

### Ground and water

The ground near the pond is soft in spring and after rain. The scale sits on a firm base, but the path to it does not. I wear boots with a proper grip, not trainers. If the bank is slick, I do not carry a full hive box to the scale. I wait, or I use a cart.

I never lean over the water to reach the scale or its cable. If something has slipped toward the edge, I walk around and pick it up from solid ground. A dropped tool is not worth a wet fall.

Wet hands and a wet scale are a bad mix for grip. Hive boxes are awkward enough dry. When the platform is damp I dry it with a cloth before I lift anything onto it.

### Lifting and loading

A hive full of honey is heavy, and the scale only helps me record weight. It does not make lifting safe. My rules:

- Lift with my legs, keep the box close to my body, and do not twist.
- Never lift a loaded box alone if I can avoid it. Take a second person, or take the supers off one at a time.
- Do not stand with my back to the pond while lifting. A stumble backward goes into the water.
- Set the box down gently. A hard drop can shake the platform and upset the reading, and it can hurt the sensors over time.

### Bees and the scale

Bees will be around the scale during a weighing. I wear a veil whenever a hive is in use, even if the colony is calm. A scale is a fixed spot, so bees learn it. On warm afternoons there is more traffic and more irritation. I try to weigh in the cooler, calmer hours of the day.

Smoke near the scale is fine, but I keep the smoker away from the battery compartment and any cable. I also never leave a lit smoker on the platform. It can scorch the surface and mark the grey casing.

### Battery

The energy source is a battery, so there is no mains cable to worry about. That removes most shock risk near the water, which is the main reason I like it. Still:

- Keep the battery compartment closed and sealed whenever I am not changing the battery.
- Never open it in the rain or with wet hands.
- Do not leave a spent battery lying around the pond. Take it home and dispose of it properly.
- If a battery looks swollen, leaks, or smells odd, stop using it. Do not charge it or force it. Put it somewhere safe and away from anything that burns.
- Keep spare batteries dry, indoors, and away from loose metal such as nails or keys.

### Animals and weather

The pond draws wildlife. Frogs, birds, and the occasional rat are all interested in a warm, quiet spot. I check under and around the scale before putting my hand anywhere I cannot see. Wasps sometimes nest in gaps nearby late in the season.

In a storm I do not visit the scale. The open ground by the water is exposed, and no honey reading is worth standing out there in thunder. In hard frost the platform can be icy, so I clear it and test my footing before loading a box.

### First aid

I keep a small kit in my bag, not left at the pond:

- Antiseptic and plasters for scratches from boxes and frames.
- Antihistamine for mild stings.
- A phone with a signal check done in advance, since the pond has a patchy spot.

Anyone with a known severe sting allergy should not do this work alone, and should carry the prescribed emergency medicine. If someone has trouble breathing, swelling of the face, or dizziness after a sting, call for emergency help at once.

## Checklist

I use this list for each visit. It is short on purpose, so I actually follow it. I go through it in order.

### Before leaving home

- Charged phone and a spare battery for the scale.
- Veil, gloves, hive tool, smoker, and fuel.
- Notebook or phone for recording weights.
- A dry cloth for the platform.
- Boots, and a waterproof layer if the sky looks doubtful.
- Tell someone where I am going if I am working alone.

### On arrival at the pond

- Look at the path and the bank. Is it slippery, flooded, or frozen?
- Check the scale for obvious damage, wet patches, or insects nesting under it.
- Wipe the platform dry.
- Look at the battery compartment. Is it closed and dry?
- Check that the scale stands level and has not shifted since the last visit.

### Before weighing

- Confirm the display wakes up and shows a sensible empty reading.
- Make sure nothing is resting on the platform, such as a stone, a leaf pile, or a tool.
- Check that the battery level is acceptable. If it is low, swap it now rather than mid-session.
- Light the smoker only once I am ready to work, and keep it clear of the scale.

### During weighing

- Put the box on gently and let the number settle before I write it down.
- Record the reading, the time, and a quick note on weather and wind. Wind can nudge the numbers.
- Note anything odd, such as a sudden jump, a drifting figure, or a reading that does not return to empty.
- Keep the lid or cover on the hive as much as possible so bees stay calm.
- Do not lean on the platform or the hive while reading the display.

### After weighing

- Take the box off and confirm the display returns to its empty value.
- Close the battery compartment properly.
- Wipe off wax, propolis, or honey drips. Sticky residue attracts bees and ants and can affect the reading.
- Put out the smoker fully and carry it away from the water.
- Pick up all tools and rubbish. Nothing should be left by the pond.

### Back home

- Copy the readings from my notebook to the main log the same day.
- Write down the battery change, if any, and when the next one is due.
- Dry and store gear. Check the spare batteries.
- Add any repair or follow-up to my to-do list.

### Seasonal extras

- Spring: check for damp, rust, and anything that moved over winter.
- Summer: watch for heat on the grey casing and for crowded bee traffic around the scale.
- Autumn: clear fallen leaves from around and under the platform.
- Winter: keep the battery in a warm place when the scale is not in use, because cold drains it faster than I expect.

## Lessons

These are things I learned the slow way. I write them down so I do not repeat them.

### The location is both the best and worst feature

Putting the scale at the pond gives me a stable, open site with good airflow, and the bees have water close by. The cost is dampness. Moisture gets into everything given enough time, so I treat the pond as a permanent threat to the scale and not an occasional one. Regular wiping and a sealed battery compartment have mattered more than any other habit.

### A battery needs a routine, not a hope

In the first months after the 2024 installation I swapped the battery only when the display faded. That led to missed readings, and the gaps in my data were annoying. Now I change the battery on a set schedule and write the date in the log. I would rather replace a battery slightly early than lose a week of weights during a nectar flow.

Cold weather also fooled me. A battery that seemed fine in autumn gave up quickly on the first hard frost. I now treat low temperatures as a reason to check the level sooner.

### Trust the trend, not a single number

One reading can be wrong. Wind, a damp platform, a box set down crookedly, or a hive tool left on the lid can all change the figure. What I care about is the shape over days and weeks. A steady climb means the flow is on. A sudden drop usually means a swarm, a robbed hive, or a super I removed and forgot to log. I now write a short note beside any reading that I know is odd, so the log explains itself months later.

### Keep the platform clean

Wax and honey drips build up quietly. At first I ignored a thin sticky film on the platform. It collected dust and dead bees and made the reading drift. A quick wipe every visit fixed it. The grey colour hides dirt well, which is nice for looks but means I have to check by touch and not just by eye.

### Do not rush at the water's edge

Almost every near miss I have had happened when I hurried. Once I stepped back while holding a super and felt the bank give way. I was fine, but it made the point. Now I place my feet first, then lift. If I feel pressed for time, I skip the weighing and come back, because the scale will still be there tomorrow.

### Write things down immediately

Memory fails faster than I expect. I used to carry numbers in my head until I got home. Now I record each reading on the spot, even if it is just a quick scrawl. A missing number is more irritating than a messy one.

### Keep the setup simple

Every extra gadget near the pond is something else to get damp, lost, or broken. The scale does one job, and I keep the routine around it small. The checklist stays short, the tools stay few, and the log stays plain. When I add a step, I ask whether I will still do it on a cold, wet morning. If not, it goes.

### What I would do again, and differently

I would pick the same kind of scale, the same grey finish, and the same battery power, since the lack of mains cable near water is a real advantage. I would, however, build a simple raised cover over the battery compartment from the start, and I would mark a clear path to the platform so I am not choosing my steps on slippery ground each time.

## Problems

These are the faults I have actually met with the Muthdralpe scale, a grey scale that runs on a battery and has stood by the pond since 2024. I list them in the order they tend to show up.

**Drifting zero after rain.** The most common problem is that the reading creeps upward after a wet night. The platform is outside, and water gets into the gap between the top plate and the frame. When the zero drifts, I do not trust any reading until the platform has dried. The fix is to lift the hive off, wipe the plate and frame, wait until the surface is dry, and set the zero again with nothing on the platform.

**Low battery gives odd readings.** The scale does not simply switch off when the battery gets weak. It keeps working and gives readings that jump around or sit too low. If a hive seems to lose a large amount of weight overnight with no reason, I check the battery before I worry about the bees. A fresh battery has fixed this every time.

**Cold mornings.** On very cold mornings the display is slow and the first reading is often wrong. I wait a few minutes and read again. If the second reading is stable, I use that one.

**Uneven ground at the pond.** The ground near the pond is soft. One corner of the base sinks after a lot of rain, and the scale then sits slightly tilted. A tilted scale gives a reading that is a little off and, worse, changes when the hive is nudged. I keep a flat paving slab under each foot and check the level whenever I visit.

**Insects and debris in the gap.** Ants, spiders and wet leaves collect under the platform. They add small weights or block the movement of the plate. A quick sweep underneath on each visit prevents most of it.

**Wind.** A strong gust pushes against the hive body and moves the reading up and down. Near the pond the wind is often stronger than in the rest of the yard. I avoid reading during gusts and wait for a calm moment.

**Hard to read in bright sun.** The display is difficult to see in direct sunlight. I shade it with my hand or write the number down after stepping to the side.

### Quick checklist when a reading looks wrong

- Is the platform dry and free of debris?
- Is the scale level on its slabs?
- Is the battery fresh?
- Is it windy or very cold?
- Was zero set with the platform empty?

If all five answers are fine and the reading is still odd, I compare with a previous visit and treat the number as doubtful rather than correct it by guesswork.

## Background

The Muthdralpe scale is a scale for beekeeping. It is grey, powered by a battery, and was installed in 2024 at the pond. I will write down why it ended up there, because I tend to forget the reasoning.

**Why a scale at all.** Weighing a hive tells me things that opening it does not. A steady rise during the main flow shows that nectar is coming in. A flat line in a good week tells me the weather or the forage has let me down. A slow fall in autumn shows how fast the colony is using its stores. Opening a hive disturbs the bees and loses heat, so a scale that I can read from outside is useful. It lets me leave the hive closed for longer.

**Why the pond.** The hives near the pond are the ones I watch most closely. The area has the most varied forage in the season, with plants along the water that flower at different times. It is also where the bees go for water, so activity there is easy to observe. Placing the scale at the pond gave me a reference hive that stands for the whole group. The trade-off is the damp and the soft ground, which cause several of the problems above.

**Why a battery.** There is no mains power at the pond. A battery meant I could install the scale without running any cable, which would have been awkward and a trip hazard around the water. The cost is that I have to remember to change the battery. I now do it at the start of the season and again at midsummer, whether it looks necessary or not.

**Why grey.** The colour is not something I chose for a reason, but it has helped. Grey blends in with the paving slabs and the shaded ground, so the scale is not conspicuous. It also does not seem to bother the bees, which sometimes react to bright objects near the entrance.

**How I use the readings.** I write down the weight at a regular time of day, ideally in the early morning before the foragers leave. This removes the effect of bees being out of the hive. I compare each reading with the last one and look at the trend over several weeks rather than any single number. A single reading can be wrong for any of the reasons in the Problems section. A trend is much harder to fake by accident.

**What it does not tell me.** The scale cannot tell me whether the queen is present, whether the brood is healthy, or whether disease is starting. It only measures total weight. I still need to open the hive to check those things. I treat the scale as a guide for when to look, not a replacement for looking.

## Observations

These are practical notes from watching the scale at the pond over time. They are what I would want to read before a new season.

**Daily pattern.** The weight is lowest in the middle of the day, when many foragers are away, and rises again toward evening as they return and the nectar is processed. The overnight reading is the most stable and the best one to record. In a strong flow I see a clear gain from one evening to the next morning even before the bees have finished drying the nectar, and the weight sometimes falls a little in the early hours as water evaporates.

**Seasonal pattern.** In spring the line is flat or slightly falling while the colony builds up and uses its stores. In the main flow it climbs steadily, with pauses on cold or wet days. Late in the year it drifts down slowly. A sudden drop at any time of year is worth a visit, since it can mean a swarm, a robbing event, or a fault in the scale.

**Weather effects.** Rain adds weight, mostly from wet wood and wet vegetation near the hive, and the reading settles back after it dries. Heavy dew can do the same on a smaller scale. I do not count these changes as real gains or losses. If I see a jump on a rainy day, I wait for dry weather before drawing any conclusion.

**Battery behaviour.** With a fresh battery the readings are steady and repeat well. As the battery weakens, the display becomes less steady first. Changing the battery on a schedule has been more reliable than waiting for trouble. In cold weather the battery seems to last less long, so I am more careful in the colder months.

**Placement.** The slabs under the feet make a clear difference. Since I added them, the level problem has become rare. I still check the level by eye each time. A scale that has settled to one side will often show a small step in the readings, which looks like a real change in weight but is not.

**Habits that help.**

- Read at the same time each visit.
- Set zero only with the platform empty and dry.
- Write down the reading with a short note on the weather.
- Sweep under the platform before reading.
- Change the battery on a fixed schedule.

**Things I would like to improve.** A small cover over the display would help in bright sun and rain. A raised, firmer base would protect against the soft ground near the water. A simple shield on the windward side might reduce the gust effect. None of these is urgent, and the scale is already useful in its present form.

**Overall impression.** The Muthdralpe scale is a plain, dependable tool when it is kept dry, level and powered. Most of the trouble comes from the pond setting rather than the scale itself. If I keep to the routine above, the readings give me a clear picture of how the hive is doing, and I can save my opening of the hive for the times that really need it.

## Overview

The Muthdralpe scale is a scale used for beekeeping. It is grey, runs on a battery, and was installed in 2024. It stands at the pond, on the side where the hives sit nearest the water. This part of the handbook covers how I look after it through the year and what I might do with it later.

Quick facts, copied here so I do not have to hunt for them:

- Kind: scale
- Area: beekeeping
- Color: grey
- Energy source: battery
- Year installed: 2024
- Location: pond

The scale tells me how heavy a hive is without opening it. A hive that gains weight in spring is bringing in nectar. A hive that loses weight in autumn is eating its stores. Opening a hive to find that out disturbs the colony and lets the warmth out, so I read the scale instead and open the hive only when the weight says something is wrong.

The pond location matters for upkeep. The ground there stays damp, and the air is humid in the early morning. The grey housing handles the weather well, but damp is still the main enemy of the battery contacts and the cable joints. Most of the routine below is about keeping moisture out and keeping the base level.

Because the Muthdralpe scale runs on a battery, there is no mains cable across the grass. That is good for safety and tidiness, but it means the battery is the one part I must never forget. A flat battery in the middle of a honey flow means a gap in my records, and I cannot fill that gap afterwards.

## Schedule

I split the work by how often it comes up. I do not tie tasks to calendar dates, because the bees and the weather decide the timing more than the calendar does. I tie them to the state of the season instead.

### Every visit

Each time I walk down to the pond, I do a short check. It takes a few minutes.

- Look at the display. If it is dim or blank, check the battery before anything else.
- Look at the platform. It should sit flat and should not rock when I press a corner.
- Check that nothing is touching the platform: no grass, no leaning branch, no stone wedged under an edge. Anything that rests on the platform adds false weight or hides a real change.
- Note the reading in my log with a short word on the weather. Wind and rain both change the reading a little, and the word helps me later.

### Weekly during the active season

When the colonies are busy, I add a few small jobs once a week.

- Wipe the top surface with a dry cloth to remove wax crumbs, dead bees and dirt.
- Check the cable joints and the battery cover for water drops.
- Compare this week's reading with last week's. A steady rise is good. A sudden drop with no obvious cause is a reason to open the hive and look, because it may mean a swarm has left.
- Make sure the hive is still in the centre of the platform. A hive pushed to one side can read wrong.

### Monthly

Once a month, I do a slower check.

- Press on each corner in turn and watch whether the reading moves in the way I expect.
- Put a known weight on the platform, such as a sealed bag of sugar I have weighed elsewhere, and see whether the scale agrees. If it is off, I write the difference in the log and correct for it until I can fix the cause.
- Clean the battery contacts with a dry cloth. If I see a white or green crust, I scrape it off gently and dry everything well.
- Check the level of the base with a small spirit level. The damp ground by the pond shifts slowly, and the platform can tilt without anyone noticing.

### Battery routine

The battery is the part with the most rules.

- Replace the battery before it dies, not after. I would rather waste a little charge than lose a week of readings.
- Replace it at the start of the main season and again partway through if the display looks weak.
- Always swap the battery on a dry day, and keep the cover open for as short a time as possible.
- Write down when the battery was changed. If I forget, I assume it is due.
- Take the old battery away with me. Never leave it by the pond.

### Seasonal tasks

Spring: Clean everything, check the level, test with the known weight, and fit a fresh battery. This is also the time to confirm that the platform is not sinking into the soft ground.

Summer: Keep up the weekly checks. Watch the readings closely during a honey flow, because the weight can change fast. Trim any grass or reeds that grow near the platform.

Autumn: Read the weight carefully to judge whether each colony has enough stores to get through winter. Record the final reading before the cold sets in.

Winter: Visit less often. Keep the display and the housing free of snow and ice, and do not chip at ice with anything hard. If the scale is not needed, I can remove the battery and keep it indoors, but I must remember to put it back. A note stuck on the platform helps.

### When something is wrong

- Reading jumps around: check for wind, a loose cable joint, or something touching the platform.
- Reading is steadily too high or too low: check the level, then redo the known-weight test.
- Display is blank: change the battery first, then look at the contacts for damp.
- Reading looks fine but the hive seems light: trust the hive, open it, and compare with the log.

## Ideas

These are things I might try. None of them is urgent, and none is a promise.

- **A rain cover.** A small sloped roof over the display would keep drops off and make morning readings easier to take. It must not touch the platform or the hive, or it will add weight.
- **A raised base.** A firm stand of flat stones or a paving slab under the scale would reduce tilting on the damp ground by the pond. I would level it once and check it each month.
- **A second scale.** With a second grey scale under another hive, I could compare two colonies side by side. That would show me whether a change is the whole apiary's response to the weather or just one colony's problem.
- **A written baseline.** Each spring I could record the empty weight of the hive body, boxes and stand, so that I can work out the honey weight by subtraction. At present I keep this in my head, which is not good enough.
- **A battery spare kit.** A small waterproof box kept in the shed with a spare battery, a dry cloth and a pencil. Then I would not need to walk back to the house when a battery fails.
- **A yearly summary.** At the end of each season, I could write a short summary of the weight curve: when the flow began, when it peaked, and when it ended. After a few years, I could compare seasons since 2024 and see what is normal for this site.
- **Better log habits.** Use the same format for every entry: reading, weather word, and any job done. A consistent log is easier to read months later.
- **Wind shelter.** A low screen on the windward side, kept clear of the platform, might steady the readings on gusty days.
- **A checklist card.** Put the every-visit checks on a laminated card kept in the hive tool bag, so that I do the short check the same way every time.

If I try any of these, I will record what I did and whether it made the readings more trustworthy. The goal is simple: a scale at the pond that I can trust without thinking about it.

## Costs

The Muthdralpe scale is a grey beekeeping scale that runs on a battery. It was installed at the pond in 2024. Because it has no mains connection and no subscription, its running costs are small and predictable. I keep my cost notes in three groups: what it cost to set up, what it costs to keep going, and what it costs when something goes wrong.

### Setup costs

The purchase price of the scale itself was the largest single item, and I am not repeating it here, because the receipt is in my paper folder. The extras around it were smaller but added up:

- A level base for the platform at the pond, made from paving slabs and a layer of packed sand.
- A weatherproof cover for the display, because the pond side gets damp mornings.
- A strap and a few ground pegs to keep the platform from shifting in wind.
- My own time. Placing the scale, levelling it and checking it against known weights took most of a weekend afternoon.

The base turned out to be the part worth spending on. A cheap, uneven base gave drifting readings in the first weeks, and I had to redo it.

### Running costs

The only regular consumable is the battery. The Muthdralpe scale uses very little power when it only wakes to take a reading, so a set of batteries lasts through a whole season. My yearly cost is one fresh set of good-quality cells, bought in spring. I do not buy the cheapest cells, because cold nights at the pond make weak ones fail early and the display goes blank.

Other small running costs:

- Cleaning cloths and mild soap, which I already have at home.
- A little wax or silicone grease for the battery contacts.
- Occasional replacement of the strap or pegs when they rot or rust.

### Hidden costs

Some costs are easy to overlook:

- **Lost data.** If the battery dies between visits, I have a gap in my weight record. That gap costs me a view of the nectar flow, which is the whole reason I own the scale.
- **Wrong decisions.** A scale that reads wrong because the platform is tilted can lead me to feed a colony that does not need feeding, or to leave one that does. Feeding costs sugar and time.
- **Damage from damp.** Water in the housing is the most likely cause of a real repair bill. The cover is cheap insurance against it.

### How I keep costs down

1. Buy batteries once a year, in spring, and write the date on the inside of the cover.
2. Keep the platform level so I never need to redo the base.
3. Wipe the scale after rain rather than waiting for corrosion to show.
4. Do the checks in the Maintenance section below and do not skip them. Each one takes a few minutes and avoids a much larger job later.

If the scale ever fails beyond what I can fix, I will weigh the cost of repair against the cost of replacement. The scale has been at the pond since 2024 and has been reliable, so I would repair first, as long as the fault is in a part I can reach.

## Maintenance

Maintenance on the Muthdralpe scale is mostly about three enemies: damp, a weak battery, and a tilted platform. The scale is grey, sits at the pond, and is exposed to weather all year, so I treat it like any outdoor instrument and follow a fixed routine.

### Every visit

These checks are quick and I do them whenever I am at the pond:

- Look at the display. If it is dim, faint or flickering, the battery is getting weak.
- Check that the platform is still level. A spirit level on top of the platform is enough.
- Look underneath for nesting insects, spiders or standing water. Wasps and ants like the gap under the platform.
- Make sure nothing is leaning on the scale, such as a branch, a hive strap or a tool.
- Read the weight with the hive on it and note the value in my log, with the date and the weather.

### Every month in season

- Wipe the platform and the housing with a damp cloth. Dry it afterwards.
- Remove any propolis, wax or dried honey from the top surface. These can add small amounts of weight that slowly build up and fool the readings.
- Open the battery compartment and look at the contacts. If there is any white or green deposit, clean it off and add a thin film of grease.
- Check the cover over the display for cracks or loose fixings.
- Take a reading with nothing on the platform and see whether it returns to zero. If it does not, I use the zero function and note the offset.

### Battery care

The battery is the energy source for the whole device, so it deserves its own routine.

1. Replace the cells every spring, before the season starts, even if they still seem to work.
2. Always replace all cells at once and use the same brand and type.
3. Take the old cells out of the compartment immediately, since leaking cells ruin contacts.
4. After fitting new cells, wait a few minutes and check that the reading is stable before putting the hive back.
5. Before winter, if the scale will not be used, remove the cells and store them dry and indoors.

### Accuracy checks

Twice a year, in spring and late summer, I do a proper check with known weights:

- Remove the hive and confirm that the empty platform reads zero.
- Place a known weight on the centre and note the reading.
- Place the same weight near each corner and compare. If the corners differ, the platform is probably not level or one foot is sinking.
- Write down any difference and what I did about it.

A small, steady difference is acceptable as long as it stays the same from one check to the next. A change over time is what worries me, because it means something is moving, wearing or getting wet.

### Seasonal care

- **Spring:** new battery, full accuracy check, clean the platform, inspect the base and pegs.
- **Summer:** watch for propolis build-up and keep vegetation trimmed away from the scale. Grass growing through the platform edge can add false weight.
- **Autumn:** final accuracy check, clean everything thoroughly, and decide whether to leave the scale out or bring it in.
- **Winter:** if it stays at the pond, cover it, take out the battery, and check it after storms.

### Troubleshooting

| Symptom | Likely cause | What I do |
|---|---|---|
| Display blank | Flat battery or bad contact | Replace cells, clean contacts |
| Readings drift upward | Damp, propolis, or debris | Clean and dry the platform |
| Readings jump | Loose cover, wind, or animal contact | Secure the strap, check the surroundings |
| Different readings at the corners | Uneven base | Re-level and re-pack the sand |
| Zero does not hold | Moisture inside or weak battery | Open, dry, fit new cells |

If none of these fixes the problem, I stop trusting the readings, write a note in the log that the data is doubtful, and look for the cause before the next nectar flow.

## Tools

I keep a small set of tools with the scale so I never need to go back to the house in the middle of a check. Most are ordinary items. Nothing here is special to the Muthdralpe scale.

### Carried to the pond

- **Spirit level.** The most used tool. A small one is fine, as long as it is accurate.
- **Spare batteries.** A full spare set in a sealed bag, in case the display fails during a visit.
- **Soft cloths.** One damp, one dry. I keep them in a plastic tub.
- **Small brush.** For sweeping out dried wax, leaves and insects from the edges of the platform.
- **Hive tool.** For scraping propolis off the platform and lifting the hive when needed.
- **Small screwdriver.** For the battery cover and any loose fixings.
- **Notebook and pencil.** A pencil still works when the page is damp. I log every reading with the date.

### Used for accuracy checks

- **Known weights.** A set of weights I trust, kept clean and dry. I keep them indoors between checks so they do not change from rust or dirt.
- **Flat board.** A board laid across the platform helps me spread a test weight evenly.
- **Packing material.** Sand and a small trowel, for fixing the base if one corner sinks.

### Kept at home

- **Battery grease.** A small tube for the contacts.
- **Spare strap and pegs.** So a worn one can be replaced the same day.
- **Cover material.** A spare weatherproof cover or plastic sheet for emergencies.
- **Log book.** My full record of readings, checks, battery changes and repairs since 2024.

### Tool habits

1. Put every tool back in the same tub after each visit, so I know what is missing.
2. Dry the metal tools before storing them, because the pond air is damp.
3. Check the spare batteries when I buy the yearly set, and replace them if they are old.
4. Keep the log up to date, because it is the most valuable tool I have. A scale is only useful if I can compare today's number with earlier ones.

### What I do not use

I do not use strong solvents or harsh cleaners on the grey housing, since they can mark or weaken the surface. I also avoid pressure washers and hosepipes, because water forced into the housing is the fastest way to damage the electronics. A damp cloth does the job.

I also avoid leaning on the platform or standing on it when I work, since that can shift the base and spoil the level I set. If I must climb up to lift a hive, I take the weight off and recheck the level afterwards.

With these tools and routines, the Muthdralpe scale at the pond stays dependable from one season to the next, and the notes stay useful for anyone, including me, who needs to look after it later.

## History

The Muthdralpe scale is a grey, battery-powered hive scale. It was installed in 2024 at the pond, and it has stayed there since. These notes are my own record of how it got there and what has changed since.

### Why a scale at the pond

The apiary by the pond is the one I check least often, because the path to it floods in wet weather. For years I judged the colonies there by lifting the back of each box and guessing. That works for a rough idea of stores, but it tells me nothing about the daily pattern of a flow. I wanted a number I could read without opening anything, and a scale that reports weight is the simplest way to get one.

I chose the Muthdralpe scale because it is a plain device. It does one job in beekeeping: it weighs a hive and reports the weight. It has no screen to fog up and no mains cable to run across a wet field. The battery is the only energy source, which settled the question for a site with no power.

### Installation in 2024

I installed the scale in 2024, in spring, before the main flow. The ground near the pond is soft, so the first job was a level base. I set a paving slab on compacted gravel and checked it with a spirit level in both directions. The scale sits on the slab and the hive sits on the scale. The grey casing blends into the stone, and that is a small advantage: it draws less attention from anyone walking past the pond.

Things I did on installation day, in order:

- Levelled the slab and let it settle for a few days before trusting it.
- Placed the scale and checked that all four corners carried load evenly.
- Put the empty hive stand on top and recorded the weight as the baseline.
- Added the colony and wrote down the weight again after the boxes were closed.
- Noted the battery state on a card kept in the shed.

The baseline matters more than anything else in the log. Every later reading is meaningful only relative to that empty-stand figure, so I keep it written in two places.

### The first season

The first season was mostly about learning what the readings meant. Weight rises through the day as foragers return, falls overnight as nectar is dried down and water leaves, and drops sharply when bees swarm. I saw all three. A sudden drop in the middle of a warm afternoon was the first swarm I ever caught by data rather than by sight, and it told me something useful about that colony's temperament.

The pond itself affected the readings. Morning dew and fog added a little weight to the lid and boxes, and rain added more. I learned to ignore small overnight changes after wet weather and to read trends over several days instead of single values.

### Problems and changes since

Over the seasons I have run into a few issues, all minor:

- **Settling base.** The slab sank slightly on one side after a wet winter. I lifted it, added gravel, and redid the levelling. Readings were slightly off until I did.
- **Wind.** A strong gust can push on a hive and produce a spike. I added a strap to the stand so the box cannot rock.
- **Condensation.** Damp air near the water got into the casing once. I dried it out, checked the seals, and now keep a small desiccant pack beside the unit in winter.
- **Battery behaviour.** Cold weather shortens battery life noticeably. I now change the battery before winter rather than waiting for it to fail.

None of these has changed my opinion of the scale. It has done what I wanted since 2024.

### How I use the history

When I look back through old logs, I read them in three layers. The first is the long trend: how much weight the colony gained over a season. The second is the daily rhythm during the main flow. The third is the events, meaning swarms, harvests, and feeding. Keeping those layers separate stops me from over-reading a single odd day.

I also keep a short written log next to the data: dates of inspections, when supers went on, and when honey came off. Without that log, a sudden change in weight is just a mystery. With it, almost every jump has an explanation.

## Software

The Muthdralpe scale runs on firmware version v9.38.651. That is the version currently on the unit at the pond, and I record it here so I can tell at a glance whether an update has happened.

### What the software does

The software is small and has a narrow job. It wakes the scale on a schedule, takes a weight reading, stores it, and goes back to sleep. Sleeping most of the time is what lets a battery-powered unit last through a season. Nothing else runs in the background, and I have never seen it do anything surprising.

The main functions are:

- Taking a reading at a regular interval.
- Smoothing the reading so that a gust or a passing animal does not produce a wild value.
- Storing readings until they can be collected.
- Tracking battery level and flagging when it is low.

### Reading interval

I leave the interval at a moderate setting. A shorter interval gives finer detail but drains the battery faster, and the extra detail is rarely useful for a hive. For tracking a nectar flow, a handful of readings across the day is plenty. In winter I would happily lengthen the interval, because the colony barely changes and the cold already hurts the battery.

### Zeroing and the baseline

The software lets me set a zero point. I do not use it on the hive itself. Instead I keep the true baseline, the weight of the empty stand, in my own notes and subtract it by hand when I want net colony weight. The reason is simple: if the zero is reset by accident, the history becomes hard to compare. A written baseline cannot be lost by a software setting.

If I ever do need to re-zero, for example after replacing the stand, I do it with the hive removed, wait until the reading settles, and then write down what happened and why in the log.

### Updating the firmware

I do not update casually. The scale works, and the pond site is awkward to reach. My routine is:

1. Check the current firmware version against what is written here.
2. Make sure the battery is fresh, because an update on a weak battery is a risk.
3. Copy the stored readings off the device first.
4. Apply the update on a dry, calm day.
5. Confirm the new version, update this note, and take a test reading against a known weight.

After any update I compare a reading with the baseline plus the known colony weight. If they disagree, I stop and investigate before trusting the data again.

### Data handling

Readings are kept on the device until I collect them. I copy them into my own notes and keep the original export untouched. Corrections, such as removing a spike caused by an inspection, go into a separate working copy. That way I can always go back to what the scale actually reported.

When I inspect a hive, the weight changes a lot while boxes are lifted. I mark those times in the log so I can discard them later. Without that mark, an inspection looks like a robbery or a swarm.

### Battery and the software

Because the energy source is a battery, the software's low-battery warning is the most important message it gives. I treat it as urgent but not as an emergency: the unit usually keeps working for a while after the warning, though cold nights shorten that margin. I change the battery on schedule so I rarely see the warning at all.

### Troubleshooting notes

- **Readings frozen at one value:** usually the device is asleep or the battery is low. Check the battery first.
- **Readings jumping about:** look for wind, an animal leaning on the hive, or a loose strap.
- **Slow drift over weeks:** suspect the base has settled or the casing has taken in damp. Re-check the levelling.
- **Reading wrong after update:** compare against the baseline and a known weight before trusting anything.

I keep these notes short on purpose. The software is simple, the scale is grey and unfussy, and most problems turn out to be about the ground, the weather, or the battery rather than the code.
