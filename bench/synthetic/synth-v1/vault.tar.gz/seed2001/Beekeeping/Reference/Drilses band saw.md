---
type: reference
status: active
project: reference
area: beekeeping
---

# Drilses band saw

## Problems

The Drilses band saw is a black band saw that I use for beekeeping work. It sits in the loft and runs on solar power. I installed it in 2022. Over the years a few problems have come up, and I list them here so I can recognise them quickly next time.

The most common problem is a weak motor on cloudy days. Because the saw runs on solar energy, the supply drops when the sky is grey. The blade then slows down in thick wood and the cut becomes rough. The fix is simple: wait for better light, or cut thinner pieces and take the work slowly.

The second problem is blade drift. When the blade wanders off the line, the cut is crooked, and a crooked cut makes frame parts and hive boxes fit badly. Drift nearly always comes from a dull blade, wrong tension, or a guide that has moved out of place. I check these three things in that order.

The third problem is dust and wax. Beekeeping wood often carries propolis and old wax. These gum up the wheels and the guides. Wax on the tyres makes the blade slip or track badly. I clean the wheels more often than the manual suggests.

The fourth problem is the loft itself. The loft gets hot in summer and cold in winter. Heat makes me work slowly and carelessly, and cold makes the blade brittle and the wood tougher to cut. Damp air can also rust the table and the blade. I keep a rag with a little oil nearby for this.

The fifth problem is noise and vibration. If the saw hums more than usual, something is loose. I stop, unplug the supply from the panel controller, and check the bolts, the table, and the wheel covers.

Short list of problems and first actions:

- Slow blade in thick wood: check the light, cut thinner stock.
- Crooked cut: check blade sharpness, tension, guides.
- Slipping blade: clean the wheels of wax and propolis.
- Rust: wipe and oil the table and blade.
- Strong vibration: stop and tighten loose parts.

## History

I installed the Drilses band saw in 2022. The idea was to have a dedicated saw for beekeeping work so I would stop borrowing tools or cutting by hand. Before the saw I made hive parts with a hand saw and a small bench saw. That was slow, and the results were uneven.

I chose a band saw because it makes narrow cuts, wastes little wood, and handles curves and thick pieces. For hive boxes, frames, bee feeders, and small stands, this was exactly what I needed. I picked a black model because it was the one available, and the colour has no practical meaning, but it does make the machine easy to spot in the dim loft.

I decided on solar energy because the loft roof gets strong sun and I did not want to run a long cable up the stairs. The solar setup was the biggest part of the installation. I had to find a good spot for the panel, run the wiring to the loft, and make sure the saw would get enough power in normal use.

In the first year I learned the limits of the solar supply. Long cutting sessions on dull days did not work well. I changed my habits: I plan heavy cutting for sunny periods and leave small jobs for the rest of the time.

In the second and third years I settled into a routine. I cut most of my wood in late winter, before the season starts, so that boxes and frames are ready when the bees need them. During summer I use the saw only for repairs and small jobs.

By now the saw has become a regular part of my beekeeping year. It has needed a few blades, some cleaning, and some small adjustments, but nothing major has failed.

## References

These are the things I look at when I need to check something about the saw or the work around it.

- The manufacturer's manual for the Drilses band saw, kept in a folder in the loft. It covers blade tension, guide settings, and the basic layout.
- My own notes on hive box dimensions, which tell me what sizes to cut.
- My notes on frame making, with the pieces I need for each hive.
- My notes on the solar setup, including where the panel is and how it connects to the loft.
- A notebook by the saw where I write down blade changes and odd behaviour.

I do not rely on the internet for the saw. The manual and my notebook are enough in most cases. If something unusual happens, I write it down so the next note is better.

Related topics I keep separate: hive building, wax handling, general workshop safety, and loft storage. Each has its own notes, and I only mention them here when they affect how the saw is used.

## Observations

Here is what I have seen after using the saw for several years.

The saw works best in bright, steady light. In midsummer, the loft is bright and the motor holds speed well, even in hardwood. In winter the supply is weaker, and I only cut thin softwood.

Blade life depends mostly on the wood. Clean, dry pine is easy on the blade. Old hive wood with wax, nails, or hidden grit wears it quickly. I now look over every old piece before cutting and remove nails and lumps of wax.

Cut quality depends on feed speed. If I push too fast, the blade bends and the cut curves. If I go slowly and let the blade do the work, the cut is straight and clean.

The black finish hides dust well, which is a problem, because I sometimes forget how dirty the saw is. Wax shows up as pale smears, so I use those as a sign that cleaning is due.

The loft is a good place for the saw in one way: it is dry most of the year and well away from the bees, so no insects are disturbed by the noise. It is a poor place in another way: carrying long boards up the stairs is awkward. I now cut long boards roughly to length downstairs before bringing them up.

The saw is fairly quiet compared with a circular saw. Still, I wear ear protection for longer jobs.

I have noticed that the blade tracks better after the saw has run for a few minutes. Cold rubber on the wheels is stiff at first. I let the saw run idle briefly before the first cut on cold days.

## Tools

These are the tools and small items I keep near the saw.

- Spare blades, in a few widths: narrow for curves, wider for straight cuts.
- A set of hex keys and a small spanner for the guides and table.
- A stiff brush and a plastic scraper for removing wax and propolis.
- A cloth and a small can of light oil for rust protection.
- A push stick for small pieces, so my fingers stay away from the blade.
- A steel rule and a square for marking.
- A pencil and a marking knife.
- A small hand-held vacuum or brush for dust.
- Ear protection and safety glasses.
- A head torch, because the loft light is poor in the evening.
- The notebook and a pen.

I keep the tools in a shallow box on a shelf next to the saw. Everything has a place, and I put it back after use. That habit saves me a lot of time searching.

A table of what each tool is for:

| Tool | Use | Where kept |
| --- | --- | --- |
| Spare blades | Replace dull or broken blade | Shelf box |
| Hex keys and spanner | Adjust guides and table | Shelf box |
| Brush and scraper | Clean wax and propolis | Shelf box |
| Oil and cloth | Prevent rust | Shelf box |
| Push stick | Feed small pieces safely | Hook by the saw |
| Ear protection and glasses | Protect hearing and eyes | Hook by the saw |

## Costs

I do not record exact prices in these notes, so I describe the costs in general terms.

The biggest cost was the saw itself together with the solar setup. The saw was a moderate purchase. The solar panel, wiring, and controller added a further noticeable amount. Together they were the main expense of the whole project, and I count them as a one-time investment made in 2022.

Running costs are low. Because the saw uses solar energy, there is no electricity bill for it. That was one of the reasons I chose this arrangement.

The recurring costs are small:

- Blades, which wear out and need replacing from time to time.
- Oil and cleaning supplies, which last a long time.
- Occasional replacement of wheel tyres or guide parts.
- Ear protection and other safety items, replaced when worn.

The biggest hidden cost is time. Cleaning and adjusting take a short while each session, but they add up. I count that as part of owning the saw.

Compared with buying finished hive boxes, the saw has paid for itself in usefulness. I can make exactly the sizes I want, repair old boxes, and use cheap rough timber. I do not need to track the savings closely to know it was worthwhile.

If the solar panel ever fails, that would be the largest repair cost. For that reason I keep the panel clean and check the wiring once a year.

## Maintenance

Regular maintenance keeps the saw cutting straight and safe. I follow a simple routine.

**After each use**

- Unplug or switch off the supply from the controller.
- Brush off dust and wood chips from the table and the wheel area.
- Remove any wax or propolis with the scraper.
- Release blade tension if I will not use the saw for a while.

**Every few sessions**

- Check blade sharpness and look for cracks or missing teeth.
- Check the guides and make sure they just clear the blade.
- Clean the wheel tyres with a dry cloth.
- Wipe the table and apply a thin film of oil.

**Once a year**

- Wipe the solar panel and check it for shade or damage.
- Inspect the wiring and connectors between the panel, controller, and saw.
- Check all bolts and the wheel covers.
- Replace worn tyres or guides if needed.
- Review the notebook for repeating problems.

**Changing the blade**

1. Switch off and disconnect the supply.
2. Open the wheel covers.
3. Release the tension.
4. Slip the old blade off the wheels and out through the table slot.
5. Fit the new blade with the teeth pointing down toward the table.
6. Apply tension as the manual says.
7. Turn the wheel by hand to check tracking.
8. Adjust the guides, close the covers, and make a test cut in scrap.

I never skip the test cut. It tells me at once if the blade tracks badly.

## Background

A band saw uses a long, thin, continuous blade that runs around two wheels. The blade passes through a slot in the table, and the wood is pushed against it. Because the blade is narrow, the saw can cut curves, and because it moves in one direction, it pulls the work down onto the table, which is steadier than some other saws.

For beekeeping, a band saw is useful. Hive boxes need accurate straight cuts. Frames need small parts of exact length. Feeders, stands, entrance reducers, and other small items often need curves or shaped edges. A band saw handles all of this, and it can also resaw thicker boards into thinner ones.

My saw is a Drilses band saw, black, installed in 2022 in the loft. The area of use is beekeeping. Its energy source is solar. These details matter because they shape how I use it. The solar power affects when I cut. The loft affects how I carry wood and how I deal with temperature. The beekeeping purpose affects what wood I cut and what dirt, like wax, gets onto the machine.

The solar arrangement works like this: a panel on the roof collects sunlight, a controller manages the power, and the saw draws from that supply. In strong light the saw has plenty of power. In weak light it has less. I treat the sun as part of the workshop schedule.

I keep this note as a personal reference, so that I remember how the saw works, how I look after it, and what I have learned.

## Parts

The main parts of the Drilses band saw are listed here with notes on what each one does.

The serial number of the Drilses band saw is SN-56937252. I keep it here in case I ever need to contact a supplier or look up a spare part.

| Part | Function | Notes |
| --- | --- | --- |
| Frame | Holds everything together | Black finish |
| Upper wheel | Carries and tensions the blade | Tension knob on top |
| Lower wheel | Drives the blade | Connected to the motor |
| Blade | Cuts the wood | Replaced from time to time |
| Table | Supports the work | Wipe and oil against rust |
| Upper guide | Keeps the blade straight above the work | Set just above the wood |
| Lower guide | Keeps the blade straight below the table | Check after blade changes |
| Wheel covers | Protect from the moving blade | Keep closed when running |
| Motor | Turns the lower wheel | Powered by the solar supply |
| Switch | Starts and stops the saw | Near the front |
| Solar panel | Collects sunlight | On the roof above the loft |
| Controller | Manages the solar power | Near the loft wall |

Wheel tyres are the soft rubber rings on the wheels. They grip the blade and protect its teeth. They wear slowly and get dirty with wax, so I check them often.

The tension knob and the tracking adjustment are the two controls I touch most. The tension sets how tight the blade is. The tracking sets where the blade sits on the wheel. Small changes make a big difference, so I move them a little at a time.

## Risks

A band saw is safer than some saws, but it is still dangerous. These are the risks I think about.

**Cuts and injury.** The blade is sharp and exposed at the cutting point. Fingers too close to the blade can be badly hurt. I use a push stick for small pieces and keep my hands well away from the line of the cut.

**Blade breakage.** A blade can snap if it is old, over-tightened, or twisted. A broken blade can whip about inside the covers. I keep the covers closed and stand slightly to the side when starting the saw.

**Kickback and grabbing.** Round pieces can roll, and thin pieces can be pulled up. I support the work flat on the table and never cut a round log without a stable cradle.

**Hidden metal.** Old hive wood sometimes has nails, staples, or wire. Hitting metal can break the blade or damage the teeth. I look over each piece and remove any metal first.

**Dust.** Fine dust is bad for lungs. In a small loft it stays in the air. I wear a mask during long jobs and open the roof window if possible.

**Wax and propolis.** These make surfaces slippery and gum up the machine. A dirty table can cause the wood to slide in an unexpected way.

**Electrical.** The solar supply and its wiring can be a risk if cables are damaged or wet. I check the wiring once a year and keep water away from the connectors.

**Fire.** Sawdust and wax burn. I sweep the loft regularly and keep dust away from the motor and the controller.

**Falls.** The stairs to the loft are steep, and carrying boards is awkward. I carry one board at a time and keep a hand free.

**Tiredness and heat.** Mistakes happen when I am hot or tired. I stop when I notice I am losing focus.

## Checklist

Before cutting:

- [ ] The loft is bright enough and the sun is strong enough for the job.
- [ ] The supply is on and the controller shows no problem.
- [ ] The wood is free of nails, staples, and lumps of wax.
- [ ] The blade is sharp and has no cracks.
- [ ] The blade tension feels right.
- [ ] The guides are set just above the wood.
- [ ] The wheel covers are closed.
- [ ] The table is clean and free of offcuts.
- [ ] Ear protection, glasses, and mask are on.
- [ ] The push stick is within reach.
- [ ] The floor around the saw is clear.

During cutting:

- [ ] Feed the wood slowly and steadily.
- [ ] Keep hands away from the line of the blade.
- [ ] Listen for changes in the sound.
- [ ] Stop at once if the blade slows or wanders.

After cutting:

- [ ] Switch off and wait for the blade to stop.
- [ ] Disconnect the supply if I am leaving the loft.
- [ ] Brush the table and the wheel area.
- [ ] Scrape off wax and propolis.
- [ ] Wipe and oil the table if the air is damp.
- [ ] Put the tools back in the box.
- [ ] Write any problem in the notebook.

## Safety

Safety rules for the Drilses band saw are simple, and I try to follow them every time.

1. Wear eye protection and ear protection. Add a mask when the job is dusty.
2. Never wear loose sleeves, gloves, or jewellery near the saw. They can be caught by the blade.
3. Keep the upper guide just above the wood. A guide set too high leaves too much blade exposed.
4. Use a push stick for small pieces. Never push a short piece with bare fingers near the blade.
5. Do not force the wood. Let the blade cut at its own speed.
6. Do not reach behind the blade while it runs.
7. Wait for the blade to stop before clearing offcuts.
8. Disconnect the supply before changing blades or cleaning the inside of the covers.
9. Do not cut round or uneven pieces without a stable support.
10. Never cut while tired, rushed, or distracted.

Some rules are special to my setup. Because the saw is solar powered, it may start unexpectedly when sunlight returns after a cloud, if the switch was left on. I always turn the switch off when I stop, even for a short break.

The loft has only one way out, so I keep the route to the stairs clear. I also keep a small first aid kit in the loft, and a phone nearby in case I need help.

Bees are not kept in the loft, but I still check that no insects have entered before I begin, as a sudden sting while cutting is a real hazard.

If anything seems wrong, such as a strange noise, smell, or vibration, I stop and fix it before I continue. No piece of wood is worth an injury.

## Overview

The Drilses band saw is a black band saw used for beekeeping. It was installed in 2022 and stands in the loft. Its energy source is solar.

I use it mainly to make and repair hive equipment: boxes, frames, feeders, stands, and small fittings. I cut most of the wood in late winter and spring, ahead of the season, and I use the saw less in summer.

What matters most about it:

- It is a band saw, so it cuts narrow lines and curves with little waste.
- It runs on solar energy, so it works best in bright light.
- It lives in the loft, which is dry but awkward to reach with long boards.
- Its black finish hides dust, so I must watch for wax and dirt.
- It needs simple, regular care: cleaning, oiling, and checking the blade and guides.

Summary of the properties in one table:

| Property | Value |
| --- | --- |
| Kind | band saw |
| Area | beekeeping |
| Color | black |
| Energy source | solar |
| Year installed | 2022 |
| Location | loft |

The note sections above cover problems, history, tools, costs, maintenance, background, parts, risks, a checklist, and safety rules. The schedule below shows how I fit the work into the year.

If I only remember a few things, they are these: cut in good light, keep the blade sharp, clean off the wax, use the push stick, and switch off the supply when I stop.

## Schedule

I plan the saw work around the beekeeping year and around the sun.

**Late winter.** This is the main time for cutting. I make new boxes, frames, and floors, and repair old ones. I choose bright days for thick wood and use dull days for small jobs, marking, and sanding. I also change the blade and clean the whole machine before the busy period.

**Spring.** I finish any missing parts, such as feeders and entrance reducers. The sun grows stronger, so the saw works well. I check the stock of spare blades.

**Summer.** I use the saw only for urgent repairs and small items. The loft is hot, so I work early in the day. I wipe off wax often, as it softens in the heat.

**Autumn.** I repair boxes after the season and cut wood for winter needs, such as mouse guards and insulation boards. I do a full clean and an oil of the table.

**Early winter.** I rest the saw. I release the blade tension, wipe and oil the table, cover the machine, and check the solar panel and wiring. I read my notebook and plan the next year's cutting.

Routine schedule in short:

| Period | Main task |
| --- | --- |
| After each use | Brush, scrape, switch off |
| Every few sessions | Check blade, guides, tyres |
| Once a year | Check panel, wiring, bolts |
| Late winter | Main cutting, blade change |
| Early winter | Rest, oil, cover |

Following this schedule keeps the saw ready when I need it and keeps the work spread out through the year.
