---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Gindrir level sensor."
---

# Gindrir level sensor handbook

## Overview

The Gindrir level sensor is a level sensor that I use for beekeeping. It sits in the cellar, where I keep the stored honey and the equipment that goes with it. The housing is black, and the whole unit runs on solar power. I installed it in 2020 and it has been working there ever since.

This note is my own reference for the device. I wrote it so that I do not have to remember small details every spring and autumn. If I need to know what the sensor is, where it is, or how to look after it, this is the place to check.

The basic properties are in the table below. I keep them in one place so I can compare them quickly against what I see in the cellar.

| Property | Value |
|---|---|
| Name | Gindrir level sensor |
| Kind | level sensor |
| Area | beekeeping |
| Color | black |
| Energy source | solar |
| Year installed | 2020 |
| Location | cellar |

### What it does

The sensor measures how full a container is. In my setup the container holds honey that is waiting to be settled and jarred. I do not need a precise reading. I need to know whether the tank is nearly empty, about half full, or close to the top, so that I do not overfill it and do not run out while I am bottling.

### Why solar in a cellar

A solar sensor in a cellar sounds odd, and it is. The small panel is not on the sensor body. It sits on a short lead that runs up to the window well, where it gets daylight. The cellar itself is dark most of the time, so the sensor depends on that panel and on its internal storage to keep going through the dull months.

Things I should remember about the setup:

- The sensor body is black and mounted close to the tank.
- The panel on the lead must stay clear of leaves and dirt.
- The lead should not be pinched by the window or the door.
- The sensor is not meant to be moved around. It stays in the cellar.

## History

I installed the sensor in 2020. At that time I had been filling the honey tank by guesswork. I would tip a bucket in, look through the side, and hope. Twice I made a sticky mess on the floor, and that was enough to push me to buy something that could watch the level for me.

### The first year

In 2020 I spent most of the time learning where the sensor should go. My first position was too low, and it kept reporting a full tank when the tank was only part full. I moved it up on the wall bracket and the readings became sensible. After that first adjustment I did not change the position again.

The panel lead was also a problem early on. I first ran it along the floor, and it was in the way of every trip with a bucket. I rerouted it along the ceiling beam up to the window well. That solved both the tripping and the shading, because the panel now sits higher and catches more light.

### The years since

Since 2020 the sensor has been quiet and reliable. I have not replaced it. The black housing has marked a little, mostly from damp, but it still looks and works as it should. The main changes over the years have been small ones:

- I cleaned the panel more often once I noticed dull weeks causing weak readings.
- I added a simple label on the wall so that anyone else entering the cellar knows not to knock the unit.
- I started noting down the first and last honey run of each season, so I can see whether the sensor behaved the same way from year to year.

### Lessons I took from it

The largest lesson is that placement matters more than anything else. A good sensor in a bad position gives bad answers. The second lesson is that solar power in a cellar works only when the panel has a decent place to live. Neither of these is complicated, but I learned both the slow way.

## Maintenance

The sensor needs very little, but it does need regular attention. Because it is solar powered and lives in a damp cellar, the two things I watch are the panel and the damp.

### Regular tasks

- Wipe the panel with a soft, dry cloth to remove dust and dirt.
- Look at the lead from the sensor to the window well and check that it is not frayed or squeezed.
- Wipe the black housing and check that no honey or condensation has collected on it.
- Look at the wall bracket and make sure the sensor has not slipped.
- Compare a reading with the real level in the tank, using a simple look through the side.

### Seasonal notes

In spring I do the full clean, because that is when the honey season begins and I need the sensor to be dependable. In summer I only glance at it. In autumn I clean the panel again before the dark months, since that is when it will struggle most. In winter I leave it alone unless a reading looks wrong.

### Damp and the cellar

The cellar is cool and damp, and that is the main long-term risk. I keep the area around the sensor as dry as I can, and I never spray water near it. If I see condensation on the housing, I wipe it off and check again a day later. If it keeps coming back, I look for the source of the damp rather than blaming the sensor.

### Signs of trouble

- The reading does not change when the tank level clearly changes.
- The reading jumps up and down with no reason.
- The sensor stops reporting after a run of grey, dull days.
- The lead feels loose where it joins the panel or the body.

When any of these happens, I start with the simplest cause. Usually the panel is dirty or shaded. Only after cleaning and waiting a day do I think about anything more serious.

## Checklist

I use this list each time I go down to the cellar for a honey run. It takes only a few minutes.

- [ ] The black sensor body is on its bracket and has not moved.
- [ ] The panel is clean and not covered by leaves or dirt.
- [ ] The lead to the window well is whole and not pinched.
- [ ] The housing is dry, with no honey on it.
- [ ] The reading matches what I can see in the tank.
- [ ] The label on the wall is still there.
- [ ] I have noted anything unusual in my beekeeping log.

### Before the season

- [ ] Do the full clean of panel and housing.
- [ ] Test the reading at a low level and at a high level.
- [ ] Check the bracket screws.

### Before winter

- [ ] Clean the panel one last time.
- [ ] Clear the window well of leaves.
- [ ] Make sure nothing is stored in front of the sensor.

## Costs

I did not keep every receipt, so I do not give exact figures here. What I can say is how the costs are shaped, which is more useful to me than a number I might misremember.

### Where the money goes

The largest cost was the purchase itself in 2020. After that the running cost is close to nothing, because the energy source is solar and there are no batteries I need to buy on a regular schedule. The remaining costs are small supplies and my own time.

| Cost type | How often | Notes |
|---|---|---|
| Purchase | Once, in 2020 | The biggest single cost |
| Energy | None | Solar, so no bills |
| Cleaning supplies | A few times a year | Soft cloth only |
| Bracket and fixings | Rare | Only if something rusts in the damp |
| Replacement lead | Only if damaged | Not needed so far |

### What I would spend on next

If the sensor ever fails, I would first replace the lead, because that is the cheapest part and the most likely to wear out. A full replacement of the sensor would be the last step. Given how well it has run since 2020, I do not expect to need one soon.

### Time as a cost

My time is the real running cost. A quick check takes a few minutes, and the full spring clean takes perhaps half an hour. That is a fair price for not spilling honey on the cellar floor again.

## Risks

The Gindrir level sensor is a black, solar-powered level sensor that I installed in the cellar in 2020. It is used in beekeeping, and most of the risks come from the place it sits and the way it gets its power.

The main risks I have noted over the years:

- **Low light.** The energy source is solar, and a cellar gets very little daylight. The panel only works because it is placed where light reaches it. If the panel is blocked or covered, the sensor slowly runs down and then stops reporting.
- **Damp.** Cellar air is humid for most of the year. Moisture can creep into the housing, corrode contacts and fog the panel.
- **Dust and wax debris.** Fine dust, propolis flakes and bits of wax settle on the black housing and on the panel. A dirty panel charges poorly.
- **False readings.** Condensation or sticky residue on the probe can make the level look higher or lower than it is. I treat a sudden jump as a possible fault, not as a real change.
- **Silent failure.** The sensor does not shout when it fails. A flat line on my records can mean "nothing changed" or "dead". I check by hand now and then to tell which.
- **Age.** It has been in place since 2020, so seals, cable jackets and the panel surface are all older than I would like.

### Risk summary

| Risk | Likelihood | Effect | What I do |
|---|---|---|---|
| Low light at the panel | Medium | Sensor stops reporting | Keep the panel clear and in the light |
| Damp in the cellar | High | Corrosion, fogging | Inspect the housing and seals |
| Dust and wax on the panel | Medium | Weak charging | Wipe the panel gently |
| Dirty probe | Medium | Wrong level reading | Clean the probe, then compare |
| Ageing parts | Rising | Sudden failure | Replace worn items early |

## Safety

Working in a cellar with a sensor is mostly ordinary care, but a few points are worth writing down because I tend to forget them when I am in a hurry.

- **Light and footing.** Take a proper lamp. Cellar steps and floors are often wet, and I do not want to climb with my hands full.
- **Air.** Keep the cellar ventilated while I work. If anything is fermenting or stored there, stale air can build up. If the air feels heavy, I leave and come back later.
- **Ladders and shelves.** If the sensor or its panel sits above head height, I use a stable ladder and have someone nearby. I do not stand on boxes or hive parts.
- **Electrical caution.** The power is solar and low in scale, but I still treat the wiring with respect. I do not open the housing with wet hands, and I keep water away from the contacts.
- **Stings and stored equipment.** Bees and wasps sometimes come into the cellar with frames. I keep my veil within reach if there are live insects about.
- **Hygiene.** Wax, honey and propolis residue should be cleaned from my hands and tools before I touch the housing, so I do not smear it on the panel.
- **Lifting.** The liquid containers the sensor measures can be heavy. I lift with my legs and do not twist.

If something looks wrong with the sensor, such as a swollen housing or a smell, I stop using it and leave it alone until I have checked it carefully.

## Supplies

These are the things I keep on hand so a visit to the sensor does not turn into a shopping trip.

- Soft, lint-free cloths for the panel and housing
- Clean water and a small bottle of mild soap solution
- Cotton swabs for the probe and the tight corners
- Silicone grease for seals and cable entries
- Spare cable ties to keep the cable tidy and off the damp floor
- Self-amalgamating tape for temporary cable repairs
- Desiccant sachets, to be placed near the sensor to take up moisture
- A notebook and pencil for writing down readings and what I did
- Gloves, so wax and honey do not get onto the sensor

I replace the desiccant and soap solution as soon as they look used up. The grease is something I use sparingly, because too much attracts dust.

## Tools

The tool list is short. Everything fits in one small box that I keep near the cellar door.

| Tool | Purpose |
|---|---|
| Torch or headlamp | Light for the cellar and for looking into the housing |
| Small screwdriver set | Opening covers and tightening fittings |
| Soft brush | Removing dust and wax flakes |
| Multimeter | Checking that the panel and wiring still deliver power |
| Step ladder | Reaching the panel if it is high |
| Tape measure or dip stick | Checking the real level by hand against the sensor |
| Scissors or snips | Trimming cable ties |
| Phone or camera | Taking a photo of the sensor before and after any change |

The most useful items are the dip stick and the multimeter. The first tells me whether the sensor is honest, and the second tells me whether the power side is healthy. A photo before I touch anything saves me from guessing how things were set up.

## References

These are the places I look when something about the sensor needs checking. All of them are my own notes or general knowledge, since this is an invented, personal setup.

- My installation notes from 2020, when I put the sensor in the cellar
- My maintenance log, where I record cleaning, readings and repairs
- The manual that came with the sensor, kept in the box with the tools
- My beekeeping notes, for the level readings and what they mean for the work
- Notes on solar panels, for charging problems and panel care

Summary of the sensor's properties, for quick reference:

| Property | Value |
|---|---|
| Name | Gindrir level sensor |
| Kind | level sensor |
| Area | beekeeping |
| Color | black |
| Energy source | solar |
| Year installed | 2020 |
| Location | cellar |

When I change anything about the setup, I add a line to the maintenance log so the next visit starts with the facts and not with my memory.

## Open questions

These are the things I still cannot answer about the Gindrir level sensor after several seasons of using it. I keep them here so I do not forget to test them.

- Does the black casing of the sensor warm up enough in the cellar to change the readings? The cellar is cool and dark, but the casing is black, and I have never checked whether it holds heat from the small lamp I use when I work down there.
- How long can the solar cell keep the sensor running if the cellar lamp is off for a whole winter? The sensor runs on solar energy, yet the only light it gets is the lamp and the light from the hatch.
- Is the drift I see in late winter caused by the sensor, or by the liquid in the tank thickening as it gets colder?
- Would a second sensor placed at the other end of the tank agree with the first one, or is the tank slightly tilted?
- Should I move the sensor closer to the hatch to give the solar cell more light, or is the current spot better for the readings?

I do not have a firm answer to any of these. When I do, I will move the answer to the Lessons section and delete the question here.

## Background

The Gindrir level sensor is a level sensor that I use in my beekeeping work. It is black, it is powered by solar energy, and I installed it in 2020. It sits in the cellar, where I keep the tanks and the buckets of honey and the settling vessels.

I bought it because I was tired of climbing down the cellar steps just to look at how full a tank was. Before 2020 I used a wooden stick with notches cut into it. The stick worked, but it was slow, it left honey on my hands, and I often forgot to check. A sensor that tells me the level without opening the lid seemed like a good idea.

The choice of a solar device for a cellar may look odd. I picked it because I did not want to change batteries in a damp place, and I did not want a cable running along the wall near the honey. The sensor has a small panel on top, and the panel is enough when there is a lamp nearby or when the hatch is open on a bright day.

Here is a short summary of the properties, so that I have them in one place:

| Property | Value |
|---|---|
| Kind | level sensor |
| Area | beekeeping |
| Color | black |
| Energy source | solar |
| Year installed | 2020 |
| Location | cellar |

I keep this table because I sometimes copy it into other notes, and I want the values to be the same everywhere.

## Lessons

Several things I learned the hard way, in no special order.

- **Light matters more than I expected.** A solar sensor in a cellar is only as good as the light it gets. In the first winter the readings stopped for a while, and the reason was simply that nobody had opened the hatch for weeks. Now I leave the lamp on a timer.
- **Clean the panel.** Dust and a thin film of wax settle on the black surface. A dry cloth every few weeks is enough. Never use water near the connections.
- **Black shows dirt and also hides it.** I cannot see the dust easily on the black casing, so I check the panel with a torch held at a low angle.
- **Do not trust one reading.** I take the value three times over a few minutes and use the middle one. A single reading can be off after I have moved a tank or stirred the contents.
- **Write the reading down.** The sensor does not keep my history for me. I note the level in my own log, with the day and what I did that day.
- **Keep the cellar tidy around it.** Boxes stacked in front of the sensor block the light and sometimes the signal.

The biggest lesson is that a device installed once and forgotten will not keep working. It needs a short look from time to time, like the hives do.

## Setup

This is how I set up the Gindrir level sensor in the cellar in 2020, written so that I can repeat it if I ever have to move it.

1. Choose a spot on the wall or the tank frame where the sensor faces the lamp or the hatch. The solar panel must see some light.
2. Wipe the surface where the sensor will sit. Honey residue stops any fixing from holding.
3. Fix the sensor firmly so that it cannot swing. A loose sensor gives jumping values.
4. Set the empty level first, with the tank empty and clean. Then set the full level after filling the tank once.
5. Leave the sensor alone for a day in the light, so that the cell can charge before the first real test.
6. Compare the first readings with the notched stick, to be sure that the two methods agree.

A few practical points. The cellar is humid, so I keep the connections dry and I do not place the sensor under the pipe that sometimes drips. I also keep a small label next to it with the date of installation, which is 2020, so that I can see at a glance how old it is.

If I move the sensor to another place in the cellar, I repeat the empty and full settings. Skipping this step gave me wrong values once, and I lost an afternoon looking for a leak that did not exist.

## Observations

These are my notes from using the sensor over the years, written as plain observations and not as conclusions.

The sensor has been working in the cellar since 2020. In the warm months the readings are steady and agree with the notched stick within a small margin. In winter the readings become slower and sometimes stop for a day or two, which I connect to the low light level for the solar cell.

I noticed that the readings move a little when the cellar door is opened and a draught goes through. I do not know the reason. It may be only the liquid moving in the tank.

Other points I wrote down:

- After filling a tank, the sensor needs some time to settle. I wait a few minutes before I trust the number.
- Thick honey gives a slower response than thin liquid. The difference is easy to see when I pour.
- The black casing stays clean for longer than I thought, as long as I keep the lid of the tank closed.
- During the honey harvest, when the lamp is on for many hours, the sensor is at its most reliable.
- I have not had to replace any part of the sensor since 2020.

Overall, I am satisfied with it as a simple helper. It does not replace my own eyes, but it saves me many trips down the steps, and it lets me plan the work in the cellar better. The remaining doubts are listed at the top of this part, in the open questions, and I will update them as I learn more.

## Schedule

This is the routine I follow for the Gindrir level sensor. It is a black, solar-powered level sensor that I installed in 2020 in the cellar, and it is part of my beekeeping setup. It watches the level of the honey in the settling tank, so most of the schedule is about keeping the panel clean, keeping the readings honest, and making sure nothing drifts without my noticing.

Because the sensor lives in the cellar and runs on solar energy, the schedule is built around two things: how much light the panel gets and how much the season changes the work in the cellar. In the busy honey months I check more often. In winter, when the cellar is mostly quiet, I check less.

### Reference of the device

The table below lists the fixed properties, so I do not have to look them up each time.

| Property | Value |
|---|---|
| Kind | level sensor |
| Area | beekeeping |
| Color | black |
| Energy source | solar |
| Year installed | 2020 |
| Location | cellar |

### Regular checks

I split the work by how often it comes round. The lists are in the order I do things, not in order of importance.

**Every week during the honey season**

- Look at the sensor body and the panel. Dust, wax flecks and a thin film of honey vapor all cut the light that reaches the panel.
- Wipe the panel with a dry soft cloth. If something is sticky, I use a cloth that is only slightly damp and then dry it straight away.
- Compare the reading with the sight mark on the tank. If the two disagree by more than I would expect, I write it down and look again the next day before touching anything.
- Check that the cable and the mounting bracket have not moved. In the cellar, a bump from a bucket is the most common cause of a sudden change.

**Every month all year**

- Check the light on the panel at the time of day when the cellar lamp is on. Since the panel is solar, I want to be sure the lamp and the small window give enough light for it to charge.
- Look for damp. The cellar is cool, and condensation on a black casing is easy to miss.
- Read the log of readings and look for flat stretches. A reading that never changes for days, while I know the level moved, usually means the sensor is stuck or low on power.
- Make sure the tank surface is clean around the sensing point, because crust or foam can give a false level.

**Every season**

- Do a full comparison against a physical measurement. I use a clean dipstick and take three readings, then average them by eye.
- Review the notes I wrote during the season and see if the same complaint repeats.
- Decide whether the sensor needs the adjustment described in the next section.

**Once a year**

- Take the sensor down, clean the whole body, and look at the seals and the mounting points.
- Check the panel surface for scratches or clouding. The sensor has been in place since 2020, so wear is expected and I watch for it.
- Move the schedule forward in my notes and record anything I changed.

### Seasonal adjustments to the routine

The honey season changes how I use the cellar, so the schedule changes with it.

- **Spring:** I check after the first cleaning of the tanks. The sensor is often bumped or moved while the cellar is being prepared.
- **Summer:** This is the main season. I check weekly and keep a cloth hanging near the sensor so the wiping does not get skipped.
- **Autumn:** I do the full comparison once the last extraction is done and the tank is at a known level.
- **Winter:** I reduce the checks to the monthly ones. If the cellar is very cold, I accept slower readings and do not treat them as a fault.

### What I write down

Each check gets a short line in my notes. I keep it plain: what I looked at, what I saw, and what I did. The most useful entries have turned out to be the ones that say "no change", because they show me later that a problem started at a particular time rather than slowly.

A good entry looks like this: the day, the word "panel wiped" or "panel clean", the sensor reading, the dipstick reading, and one word for the condition of the cellar, such as dry, damp or cold. That is enough to see a pattern after a few months.

### Signs that the schedule needs to change

- Readings keep drifting between weekly checks. In that case I check twice a week for a while and look for a cause.
- The panel is dirty again within a few days. That points to something in the air, often wax dust or a leak of vapor, and the cause must be fixed rather than the cleaning repeated.
- The sensor misses readings in the log. That is a sign of low power, and I look first at the light on the panel.
- I find I am skipping checks. If so, the schedule is too heavy, and I shorten it to what I will actually do.

## Adjustment

Adjustment is the step I take when the sensor and the dipstick disagree in the same direction every time. A random difference is not an adjustment problem; it is usually foam, a bump or a dirty panel. A steady difference is a sign that the zero point has moved.

The calibration offset of Gindrir level sensor is 2.500 mm. This is the value I have set to bring the sensor reading in line with the physical measurement, and it is the number I return to if the setting is lost or changed by accident. I never change it on the strength of a single reading.

### Before adjusting

Do these in order, and stop if a step shows the cause.

- Clean the panel and the sensing point, so that dirt is not the reason for the error.
- Make sure the sensor is firmly mounted and has not tilted. A small tilt looks exactly like an offset error.
- Let the sensor run for a full day in normal light, so that low power is not the reason.
- Take three dipstick readings of the tank at rest, with no foam on the surface, and write them down.
- Compare the average of those readings with the sensor reading. If the gap is small and not steady, leave everything as it is.

### Making the adjustment

1. Write down the current offset before touching it, so that I can go back.
2. Work out the gap between the sensor and the dipstick, and decide which direction it goes.
3. Apply the change to the offset in small steps rather than in one jump.
4. Wait for the sensor to update, and take the dipstick readings again.
5. Repeat until the two agree within what I can read on the dipstick.
6. Write the final offset in my notes with the day and the reason.

I treat the value of 2.500 mm as the reference. If I change it for a good reason, I note the new value next to it and the reason, so that the history stays readable.

### After adjusting

- Watch the readings for a week. A good adjustment shows steady agreement at different levels, not only at one level.
- Check the sensor at a high level and at a low level. If it agrees at one and not the other, the problem is not the offset, and I should look at the mounting or the sensing point.
- Return to the normal schedule once the readings have been steady.

### Common mistakes

- Adjusting while the tank is still settling after filling. The surface moves, and the reading follows it.
- Adjusting in a cold spell, when the readings are slow. I wait for the cellar to warm a little.
- Changing the offset to hide a dirty panel. This only moves the problem to a later date.
- Forgetting to record the change. A few months later I cannot tell whether the sensor drifted or I adjusted it.

### Quick reference

| Situation | What I do |
|---|---|
| Steady gap in one direction | Check mounting, then adjust the offset in small steps |
| Random gap that changes | Clean the panel and sensing point, then check again |
| Flat readings for days | Check light on the panel and the power |
| Agrees at one level only | Look at the mounting, not the offset |
| Setting lost | Restore the calibration offset of 2.500 mm and compare with the dipstick |

The aim is a sensor that agrees with the dipstick and that I do not have to think about. If I am adjusting often, something else is wrong, and the schedule above is where I look for it.
