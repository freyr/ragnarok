---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Viorktraen radio receiver."
---

# Viorktraen radio receiver

## Checklist

This is the routine I run through for the Viorktraen radio receiver. It is a red, battery-powered radio receiver that sits in the greenhouse. I installed it in 2020 and it has been part of the beekeeping setup ever since. I use it to catch weather and local broadcasts while I work with the hives and the seedlings nearby.

Before each season:

- Check that the receiver is still in the greenhouse, on its usual shelf, away from the wet bench and the watering line.
- Open the battery compartment and look for corrosion on the contacts. Wipe them dry if anything has formed.
- Replace the batteries at the start of spring, even if they still seem fine. The receiver is the only thing in that corner that runs on battery, so it is easy to forget.
- Extend the antenna fully and check that the joints are tight.
- Tune across the band slowly and note which stations come in clearly.
- Wipe the red casing with a dry cloth. Condensation builds up on it in the mornings.

Every month during the season:

- Listen for crackle or fading. Both usually mean the battery is getting weak or the antenna has shifted.
- Check that the volume knob does not scrape. Greenhouse dust gets into it.
- Look at the shelf for drips or moisture. If the air feels heavy, compare with what I wrote in [[Glurkolel dehumidifier study]].

Before winter:

- Take the batteries out if the greenhouse will be left alone for a long stretch.
- Store the receiver indoors if a hard frost is forecast.
- Note any repairs in [[Fenkraeth loft handbook]], where I keep the winter tasks.

## Measurements

I do not measure much on this device, because it is a simple receiver. Still, a few numbers are worth keeping, and I take them the same way each time so they can be compared.

- Device: Viorktraen radio receiver
- Kind: radio receiver
- Area: beekeeping
- Color: red
- Energy source: battery
- Year installed: 2020
- Location: greenhouse
- Flow rate: 115.45 l/h

The flow rate is the figure I recorded for the airflow around the receiver's shelf when I was checking ventilation in the greenhouse. I keep it here so I can see if the air movement around the device changes. If the vents are blocked or a fan is moved, I would expect this value to shift, and the receiver tends to get damp when the airflow drops.

Other things I check, without recording exact numbers:

- Battery life. I note roughly how many weeks one set lasts and compare it from year to year. Cold nights shorten it.
- Reception quality. I judge it by ear and write a short comment, for example clear, noisy, or weak in the afternoon.
- Interference. The compressor in the shed causes buzzing when it starts. I wrote about this in [[Lesglugen air compressor notes]].
- Interference from the saw. When I run the band saw, the signal gets noisy. See [[Tronas band saw]].

For comparing the ventilation readings with other spots in the greenhouse, I follow the method in [[Zaedith Gerknand tests]], so that the numbers are comparable.

## Lessons

Several things have become clear over the years since 2020.

1. Moisture is the main enemy. The greenhouse is humid, and a battery device lasts much longer when it is kept off the damp bench. The shelf position matters more than any other choice I made.
2. Fresh batteries each spring are cheaper than a failed receiver in the middle of the season. A leaking cell can ruin the contacts quickly.
3. Interference from workshop machines is predictable. If I want clean reception, I switch off the saw and the compressor first, or I just wait.
4. The red casing is easy to spot, which is useful. I rarely lose it among the pots and tools, and bees do not seem bothered by it.
5. Keeping the receiver near the hives' work area was a good decision, because I can hear the forecast while I prepare frames, and I can decide quickly whether to open a hive or wait for better weather.
6. Writing down small observations helps. When something goes wrong, I can look back and see whether it happened before, instead of guessing.

Things I would do differently:

- Put a small cover over the shelf to catch drips.
- Keep a spare set of batteries in a sealed box in the greenhouse.
- Mark the best tuning position on the dial with a bit of tape.

Related notes: [[Peboth Traerren plan]] covers the wider layout of the greenhouse and the apiary, and [[Raemaertur Truthkon notes]] has my remarks on the weather broadcasts I follow. I should read both again before I decide whether to move the receiver or install a second one.
