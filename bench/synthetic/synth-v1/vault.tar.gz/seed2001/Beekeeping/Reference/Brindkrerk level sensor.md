---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Brindkrerk level sensor."
---

# Brindkrerk level sensor

## Open questions

- How long will the black casing keep its finish before sun and pond spray start to wear it down? The Brindkrerk level sensor has been outside since 2017, and I have never recorded any change in the surface.
- Is the solar panel still giving enough charge in the short days of winter? The sensor is a solar-powered unit, and I only have a loose feeling that it dips, not a proper record.
- Should I replace it with something built to the design in [[Starklil level sensor plan]], or keep patching the old one?
- Would a different mounting spot at the pond give cleaner readings, with less glare and less debris floating around the probe?
- Can the charging side be improved using ideas from [[Tarkvaer solar charger plan]] and [[Giordin solar charger notes]]?

## Background

The Brindkrerk level sensor is a level sensor used in my beekeeping work. It was installed in 2017 and sits at the pond. The pond matters because the bees need a steady water source nearby, and I want to know when the level drops before the colonies start looking elsewhere for water, such as the neighbours' troughs.

Here is the full set of properties, for quick reference:

- Name: Brindkrerk level sensor
- Kind: level sensor
- Area: beekeeping
- Color: black
- Energy source: solar
- Year installed: 2017
- Location: pond

I chose a solar unit because running a cable to the pond would have meant digging across the field, and I did not want to do that. The black housing absorbs heat in summer, which is something I keep in mind when I read the numbers on hot afternoons. Nothing about the installation is complicated: the body is fixed near the water edge, the panel faces the open sky, and the probe reaches into the pond.

Related notes I go back to when I think about this device:

- [[Naetrior shed]] is where spare parts and cables are kept.
- [[Draensork shed]] is the other storage place, and I check there if something is missing from the first one.
- [[Nithden greenhouse 2023]] has notes on an earlier water and humidity setup that I learned from.
- [[Glurkolel dehumidifier study]] covers moisture problems in enclosed spaces, which is relevant to the sensor electronics.

## Risks

- **Water ingress.** The unit is at the pond, so splashes, rain and condensation are always possible. If moisture gets into the housing, the electronics will fail slowly and the readings will drift before they stop.
- **Low charge.** A solar device depends on light. A run of overcast days, leaves on the panel, or bird droppings can leave it short of power.
- **Heat.** The black colour warms the housing in direct sun. Hot electronics can give odd readings.
- **Age.** It has been in place since 2017, so seals, cable jackets and the panel surface are all old. I should assume some parts are near the end of their life.
- **Fouling of the probe.** Algae, mud or floating debris can make the level look wrong. A wrong reading is worse than no reading, because I might trust it.
- **Disturbance.** Animals, or me, can knock the unit while working near the pond.
- **Single point of knowledge.** If I forget how it was set up, repairs get slower. That is part of why this note exists.

## Measurements

The only figure I keep as a firm measurement is the power draw.

- Measured power draw of Brindkrerk level sensor: 390.36 W

I wrote this down as measured, and I treat it as the reference value when I compare later checks. If a future measurement is far from it, something has changed, either in the device or in the way I measured. Before I trust a new reading I repeat it under similar conditions: the same time of day, similar weather, and the same meter placed the same way.

Other things I note by eye, without numbers:

- Whether the panel surface is clean and undamaged.
- Whether the housing is dry inside when I open it.
- Whether the level reported matches what I see at the pond edge.
- Whether the readings look steady or jump about.

Test results from comparable gear are in [[Serktrio Zothken tests]], and I look there when I need to judge whether a result is plausible.

## Tools

What I bring when I go to the pond to check the sensor:

- A soft cloth and a bucket of clean water for the panel and the probe.
- A small brush for algae and mud.
- A multimeter, or the power meter I used for the draw figure above.
- Screwdrivers that fit the housing screws.
- Spare seals and a tube of sealant, kept in [[Naetrior shed]].
- Cable ties and tape for quick fixes.
- Waterproof boots, since the edge of the pond is soft.
- A notebook, or my phone, for writing down what I find.
- A dry bag for any part I remove, so it does not get wet or lost.

If something is not in the first shed, I look in [[Draensork shed]] before buying anything.

## Checklist

Use this when visiting the Brindkrerk level sensor:

- [ ] Look at the unit from a distance first and note anything out of place.
- [ ] Wipe the solar panel clean and clear leaves or droppings.
- [ ] Check that the black housing is firmly fixed and not cracked.
- [ ] Inspect the cable and its entry point for splits or wear.
- [ ] Clean the probe and remove debris around it.
- [ ] Compare the reported level with the actual level at the pond.
- [ ] Open the housing only in dry weather and check for moisture.
- [ ] Measure the power draw and compare it with the 390.36 W reference.
- [ ] Close and seal everything and make sure the screws are snug.
- [ ] Write down what was done and anything that needs follow-up.
- [ ] Update this note if anything about the setup changed.

## Safety

- Work near the pond with care. The bank can be slippery, so wear boots and do not lean over the water alone if the ground is wet.
- Treat the electrical side with respect. Even though it is a solar device, the panel produces power whenever there is light, so do not touch exposed contacts with wet hands.
- Disconnect the panel before opening the housing or changing any wiring, and cover the panel if that is the only way to stop it producing power.
- Do not open the unit in rain, and never put tools or meters into a wet housing.
- Be careful around the bees. Do the work when the colonies are calm, avoid standing in the flight path to the water, and keep protective clothing at hand.
- The black housing can get hot in the sun. Let it cool before handling it.
- Keep sealant, cleaning products and old parts out of the pond. Take away any waste you create.
- If I am unsure about a repair, I stop and look at [[Starklil level sensor plan]] or the charger notes before going further, rather than guessing.
