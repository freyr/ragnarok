---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Drithdas level sensor."
---

# Drithdas level sensor

## Safety

The Drithdas level sensor is a red level sensor used in beekeeping. It sits in the shed and runs on mains power, so I treat it as live equipment at all times. I installed it in 2025.

- Switch off the mains supply before opening the casing or touching the wiring.
- Keep the unit dry. The shed gets damp, and honey or syrup spills can creep into the connections.
- Do not leave the cable lying across the floor where I walk with buckets or boxes.
- Check the plug and cable for wear each season before I start extracting.
- Keep children and pets out of the shed when the sensor is exposed.

If the casing feels hot or I smell anything burning, I unplug it at the wall and leave it off until I have looked at it.

## Measurements

I checked the electrical load of the Drithdas level sensor with a plug-in meter in the shed. The measured power draw of Drithdas level sensor is 501.33 W.

- Subject: Drithdas level sensor
- Kind: level sensor
- Area: beekeeping
- Color: red
- Energy source: mains
- Year installed: 2025
- Location: shed

I should repeat the power reading if I change the wiring or move the unit, so I can compare it with this one.
