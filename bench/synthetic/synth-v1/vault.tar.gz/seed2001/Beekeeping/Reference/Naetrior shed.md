---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Naetrior shed."
---

# Naetrior shed

## Overview

Naetrior shed is a shed used for beekeeping. I keep it as my main place for storing and handling hive gear. It is a medium-sized building, and it was built in 2005. The entrance and the main side face east, so the morning sun reaches the door first and the shed warms up early in the day.

The floor is below ground. That choice keeps the inside cooler in summer and steadier in winter, which suits stored wax, frames and honey supers. The downside is that damp is the main thing to watch, so I check the air regularly and keep the door ventilated when the weather allows.

Properties at a glance:

- Kind: shed
- Area: beekeeping
- Orientation: east
- Size: medium
- Year built: 2005
- Floor: below ground

## Measurements

I take readings inside the shed to see whether the damp is under control. The most recent figure is the one I rely on when deciding whether to air the place out or move equipment.

- Measured humidity: 66.80 %
- Floor level: below ground, so the readings stay close to the ground temperature
- Orientation: east, which means the door side dries a little in the morning sun
- Size: medium, enough room for shelves and a work table without crowding

Practical notes for myself:

- Take the reading at the same spot each time, away from the door, so the numbers can be compared.
- Keep wooden frames off the floor and on shelves, since the below-ground floor is the dampest part.
- If the humidity climbs, open the door on a dry morning and let the east sun and the airflow help.
- Check stored boxes and wax for mould after any long wet spell.

The building has stood since 2005, and in that time the below-ground floor has stayed the main reason for these checks. A simple routine of regular readings and airing keeps the shed in good working order for the beekeeping season.
