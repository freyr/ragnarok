---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Riothsorfi scale."
---

# Riothsorfi scale handbook

## History

The Riothsorfi scale is a hive scale that I installed at the pond in 2022. It is grey, it runs on solar power, and it sits at the edge of the water where the apiary stands. I keep this handbook so that I do not have to rediscover the details every spring.

Before the scale, I judged my colonies by lifting the back of each hive and guessing. That works when you have one hive and a lot of experience. It stops working when you have several hives, a sore back, and a wish to compare one week with the next. I wanted a number I could trust, taken at the same spot, with the same method, without opening the box and disturbing the bees.

I chose a scale for the pond site for a practical reason. The pond is the best forage spot I have. There is water close by, there is shelter from the wind, and the flowering plants around it carry the bees from early spring until late in the year. Weight changes there tell me the most. A hive that gains steadily in a good flow is a different story from a hive that loses weight on a warm afternoon, and the scale shows the difference without any guessing.

The reason for solar power was simple. There is no mains socket near the pond, and I did not want to carry batteries back and forth every few weeks. A small panel keeps the unit alive through the day and charges it for the night. In the first season, I watched it closely for a few weeks to see whether a cloudy spell would run it flat. It did not, so I stopped worrying. Deep shade is the real danger, so I placed the panel with that in mind.

The first season, 2022, was mostly a learning year. I put the scale under one hive only and wrote down readings by hand. I learned several things:

- A scale that is not level gives readings that drift, so the base must be firm and flat.
- Wind pushes on the hive and moves the reading, so a sheltered site matters.
- Rain on top of the hive adds weight for a short while, and that has to be read as noise, not as nectar.
- Morning and evening readings differ because of foragers leaving and returning, so I compare like with like.

Over the following years, I settled into a routine. I read the scale at the same time of day, I write the figure in my log, and I look at the trend over days rather than at any single reading. That habit is the most useful result of the whole project. The scale does not make decisions for me. It gives me a clear record, and I make the decisions from it.

I also learned what the scale cannot do. It does not tell me whether the queen is laying, whether the colony is healthy, or whether mites are building up. It tells me weight and nothing else. For everything else I still open the hive on a calm day and look. The scale only helps me choose when that is worth doing.

## Supplies

This section lists what I keep on hand for the scale. Nothing in it is rare. Most of it lives in one box in the shed, so that a visit to the pond does not turn into a hunt for a missing tool.

### The unit itself

- The Riothsorfi scale, a grey scale with a solar panel built into its power supply.
- The platform that carries the hive, which must be wider than the hive floor so the whole box rests on it.
- The cable between the platform and the display or logger, with its weather cover.
- The solar panel and its short lead.

### For a stable base

The base decides whether the readings can be trusted, so I do not skimp on it. I use:

- Paving slabs or concrete blocks, enough to make a flat square under the platform.
- Coarse sand or fine gravel to bed the slabs in.
- A long spirit level, and a short one for checking the platform itself.
- A rubber mallet to settle each slab without cracking it.
- A few thin wooden or plastic shims for fine adjustment.

### For protecting the equipment

The pond is damp for much of the year, so water and condensation are the main enemies of the electronics.

- A small waterproof box for the logger or any connector that cannot be left open.
- Self-amalgamating tape for sealing joints in the cable.
- Cable ties, to keep the lead off the ground and out of the wet grass.
- A little silicone grease for plug contacts.
- A tarpaulin offcut or a spare hive roof, to cover the unit when I am working near it.

### For the hive on top

- A strap or two to hold the hive boxes together, so that wind does not move the stack.
- A stand or runners if the hive floor is not flat enough to sit directly on the platform.
- A spare floor and roof, so I can swap them without leaving the scale uncovered for long.

### For keeping records

- A weatherproof notebook and a pencil, because a pen fails in the damp.
- A phone with a camera, for photographing the display when the light is poor.
- A simple table in my notes, with a column for the date, the time, the reading, and a short remark about weather and forage.

### Cleaning and care

- A soft brush for dust and propolis crumbs on the platform.
- A damp cloth for the solar panel. A dirty panel makes less power, and bird droppings are common at the pond.
- A small pot of lubricant for any hinge or latch on the weather cover.
- A spare set of fixings, since the ones outdoors rust sooner than I expect.

### Things I keep in the car

- Gloves, a veil, and a smoker, since a visit to the scale is still a visit to the bees.
- A bucket for carrying the tools, which also serves as a seat.
- A bottle of drinking water, because the pond site has none.

## Setup

This is the order I follow when I put the scale in place, or when I move it after a wet winter has shifted the ground. I do the work on a calm day when the bees are flying, and I try to finish before the afternoon heat.

### 1. Choose the spot

The scale stands near the pond, on the side that gets sun for most of the day. I check three things before digging anything:

1. The panel will have clear sun, with no shadow from reeds, trees, or the hive itself.
2. The ground is firm and drains well, not soft mud at the water's edge.
3. The hive entrance faces away from the path, so that anyone walking past is not in the flight line.

If the ground is soft, I move the spot a little uphill instead of fighting the mud. A scale that sinks on one corner is no use.

### 2. Build the base

I mark out a square a little bigger than the platform and remove the turf. I dig down enough to bed a layer of sand, then lay the slabs and tap them down with the mallet. After that:

- I lay the long level across the slabs in both directions.
- I add or remove sand under any slab that rocks.
- I leave the base for a day if it has rained, then check it again, because wet sand settles.

The platform must be flat in every direction. I check it with the short level once the platform is on the slabs, and I use shims for any small error.

### 3. Place the platform and connect the unit

I set the platform on the base and make sure all its feet carry weight. Then I run the cable to the display or logger, keeping it off the ground and tying it up so it cannot swing in the wind. I seal every outdoor joint with tape and put the connectors that must stay dry in the waterproof box.

### 4. Fit the solar panel

The panel goes on its own post or on the sunny side of a fence, angled toward the midday sun. I keep its lead short and tie it down. I check that nothing grows up in front of it later, because pond plants grow fast in summer.

### 5. Zero the scale

With the platform empty, I switch the unit on and let it settle. I note the reading, then clear or zero it as the display allows. I press down on the platform with my hand and watch the figure respond, to prove that it is alive.

### 6. Set the hive on top

I lift the hive onto the platform carefully, preferably with a helper. I strap the boxes together and make sure the hive sits centered, since an off-center load can bias the reading. I wait a few minutes for the bees to settle, then I record the first weight in my notebook with the date and a remark on the weather.

### 7. Check the first days

For the first few days, I look at the readings more often than I will later. I am watching for three problems:

- A slow drift while nothing is changing, which usually means the base is moving.
- A jump after rain, which usually means water has collected on the roof.
- A dead display in the morning, which usually means the panel is shaded or dirty.

When all three are quiet, I switch to my normal routine and read the scale once a day at the same hour.

## Maintenance

The Riothsorfi scale is a grey beekeeping scale that sits by the pond. It runs on solar power and has been installed there since 2022. Most of its upkeep comes from the place it stands: damp air, pollen, bird droppings and the occasional spray of pond water. I keep the routine simple so I actually do it.

### Routine checks

On every visit to the hives I do a quick walk-around of the scale before I read any weights. This takes about a minute.

- Look at the platform. It should sit flat and level, with nothing wedged underneath.
- Wipe off dust, wax crumbs and bird mess from the grey top surface with a dry cloth.
- Check that the display shows a reading and that the reading is steady when nothing is moving near it.
- Look at the solar panel and brush off leaves or dirt.
- Glance at the cable and the connector for damp, cracks or chewing marks.

If any of these looks wrong, I fix it before I trust a weight. A reading taken on a dirty or tilted platform is worse than no reading, because I tend to believe numbers on a screen.

### Cleaning the solar panel

The energy source is solar, so a dirty panel is the most common cause of trouble. The scale sits close to the water, and in summer the panel gets a film of pollen and dust. In autumn it gets wet leaves. I wipe it with a soft damp cloth and then a dry one. I never use anything abrasive, because scratches cut the light it collects over the years. After a long grey, overcast spell I check the display more often, since the scale has less to live on.

### Keeping the platform level

The ground near the pond is soft, and after heavy rain one side can sink a little. A scale that is not level can drift or give weights that do not repeat. I keep a small flat level on a nail beside the hives. When the bubble is off, I lift the stand, repack the base with gravel and set it again. Then I run the zero check described below.

### Zero and repeat check

Once a month, and after any move or repair, I test the scale with the hive removed from the platform.

1. Clear the platform completely.
2. Let the display settle and note the empty reading.
3. Place a known object, such as a full water container I have weighed before, and note the reading.
4. Remove it and confirm the display returns to the empty reading.

If the empty reading has crept away from zero, I re-zero it using the method in the device's own settings. If the known object gives a different weight from last time, I look for a mechanical cause first: a stuck corner, a loose bolt, a bent plate. Only after that do I suspect the electronics.

### Weather and season

- **Spring:** Pollen coats everything. I clean more often, and I check the cable after the winter, because animals like to chew it.
- **Summer:** Heat and bright light are good for the panel, but the platform can warm up and give small drifts in the reading. I take comparison readings at the same time of day when I can.
- **Autumn:** Leaves collect on the panel and in the gaps around the platform. I clear them each visit.
- **Winter:** Frost and condensation near the pond are the main worries. I make sure no water can pool on the platform, and I accept that low sun means fewer readings. I do not lift the scale unless it is clearly faulty.

### Protecting against damp

The pond location means humidity is always high. I keep the connector wrapped and pointing downward so water runs off it instead of in. I check for a white or green crust on metal contacts, which is a sign that moisture got in. If I see it, I clean the contact gently, let it dry fully and seal it again. I never spray anything wet near the display.

### When something stops working

My order of checks, from most to least likely cause:

1. Dirty or shaded solar panel.
2. Loose or damp connector.
3. Platform out of level or touching something.
4. A corner or plate that is binding.
5. A fault in the electronics.

Nearly every problem I have had was in the first three. I write the cause in my hive log so I can spot patterns later.

## Costs

I do not record exact prices in this note, because they change and I would rather look at my receipts. What I can record is where the money goes and how large each part is compared with the others.

### Buying and setting up

The scale itself was the big one-off cost. Because it is solar, I did not need to run a power line to the pond, and that saved what would have been the most expensive and awkward part of the job. Digging a trench to a damp area by the water would have cost a lot more than the scale. Setting up in 2022 also needed a few cheap extras: gravel for the base, a flat paving slab under the stand, some cable protection and a few fixings.

### Running costs

The running cost is close to nothing. There is no electricity bill, since the energy source is solar. There are no batteries I need to buy on a regular schedule, as long as the panel stays clean and has light. The real running cost is my time: a minute at each visit and a longer check once a month.

### Occasional costs

- **Cable and connector protection:** I replace wrap or sleeves when they crack. This is small.
- **Gravel and levelling:** a small amount each year when the ground shifts.
- **Cleaning cloths:** negligible.
- **Replacement parts:** I have not needed major parts so far, but I set aside a little money each year in case a corner plate or the panel fails.

### Costs I avoided

Placing the scale by the pond kept the bees' weight data in the spot where the hives already stand, so I did not need to buy a second scale or move the hives. Choosing solar avoided mains work. Keeping the routine short avoided the cost of mistakes, such as buying a replacement when the real fault was a dirty panel.

### What I would watch

If I ever replace the panel or the main unit, that would be the largest cost since the first purchase. I would compare that against the value of the data. For a hobby apiary the weight records are useful but not essential, so I would only replace parts that are cheap relative to the benefit. A failed scale is not an emergency, because I can always lift a hive by hand and judge by feel, as I did before.

## Lessons

These are the things I learned from keeping this scale at the pond since 2022.

### Place matters more than the model

The pond is a good location for the hives, but it is a hard place for equipment. Damp, pollen and soft ground cause most of the trouble. Whatever scale I used there, I would have the same issues. If I set up another one, I would first prepare the ground properly with a firm, level base, and only then think about the device.

### Solar is a good fit if you keep it clean

I like that the scale needs no wiring and no battery swaps. The trade-off is that it depends on a clean, unshaded panel. I learned to check the panel first whenever the display looks weak. I also learned to keep reeds, branches and tall grass trimmed so they do not cast shade across the day.

### Do not trust a number you have not checked

At the start I read the display and accepted whatever it said. Several times a strange weight turned out to be a tilted platform or a leaf under one corner. Now I check that the scale is clean, level and stable before I look at the figure. The monthly zero and repeat check gives me confidence that the readings mean something.

### Compare like with like

A hive weight changes through the day as bees leave and return, as dew dries and as the sun warms the platform. To compare weeks, I try to read at the same time of day and in similar weather. Trends over many visits are far more useful than any single reading.

### Keep the routine short

A long checklist gets skipped. The one-minute walk-around is something I do every time, and the longer checks happen monthly. This has worked better than any careful plan I wrote in the first year.

### Write down faults and fixes

Keeping a short note in the hive log of each problem and its cause has saved me time. After a while I could see that most faults came from the same few things, which is why the troubleshooting order in the maintenance section puts the panel, connector and level first.

### Things I would do differently

- Build the base with drainage from the start, instead of fixing it after the first wet season.
- Fit cable protection on the first day, not after finding chew marks.
- Take a baseline reading with a known object right after installation, so I have a clean starting point to compare against.
- Keep a small kit by the hives: cloth, level, spare wrap and a few fixings.

### Final practical rule

If the scale gives a reading that surprises me, I stop and check the basics before I change anything about the hive. Most of the time the hive is fine and the scale just needs a wipe or a nudge back to level.

## Safety

The Riothsorfi scale is a grey scale for beekeeping, installed in 2022 at the pond and powered by solar energy. Most of the safety concerns come from where it sits, not from the device. The ground near the pond is soft, the hives are heavy, and the bees are always nearby.

### Working near the hives

- Wear the full veil and gloves whenever I am reading, cleaning or moving anything on the platform. A quick look at the display is the only job I do without protection, and only on a calm day.
- Approach the scale from the side, never through the flight path. Bees returning with nectar fly low and straight, and standing in front of the hive annoys them.
- Do not work on the scale in cold drizzle, in thunder weather, or late in the evening when the colony is defensive.
- Keep the smoker unlit and well away from the electronics. Sparks and the grey housing do not go together, and ash gets into the connectors.
- If I get stung more than a few times, I stop, walk away, and finish the job the next day.

### Weight and lifting

A loaded hive on the platform is a heavy thing to lift. When I need to take a hive off the scale, I do it with a second person or I split the stack and take the boxes off one at a time. I never lift a full brood box alone from a crouched position. The pond side of the platform is the one that sinks first, so I check that the platform is still level before putting any weight back on it.

### Electrical and solar notes

The scale runs on solar energy only. That makes it low voltage and fairly forgiving, but I still follow some basic rules:

- Cover the panel with a cloth or turn the unit off before opening the housing. A panel in full sun still delivers current.
- Never open the housing when it is wet. Wait for a dry day, and wipe the outside before I undo any latch.
- Keep the cable runs off the ground and away from the water's edge. Cables lying in the damp grass are the first thing to fail.
- Do not use the scale as a step or a bench. The sensors are not meant for point loads.

### Near the water

The pond is a hazard in its own right. The bank is slippery after rain, and the reeds hide the edge. I do not carry a hive box along the bank in the dark. If I have to work there at dusk, I take a headlamp and tell someone where I am. A dropped box or a slip into the pond with wet gloves is the realistic accident here, much more than anything involving the device.

### Cleaning

I clean the grey housing with a soft damp cloth and plain water. No solvents, because they cloud the panel cover and can attack the seals. Propolis and wax are removed by hand after they have gone cold and brittle. I wash my hands before touching the display, as sticky fingers leave marks that attract more bees.

## Open questions

These are the things about the Riothsorfi scale that I have not settled. I add to the list when something puzzles me and remove an item only when I have a note explaining the answer.

### Power

- The scale is solar, but I do not know how much reserve it keeps through a long run of dark winter days. Since 2022 I have not tracked how often it has gone silent in December, and I should start writing those gaps down.
- I am not sure whether the panel loses output because of the shade from the trees near the pond as they grow. The angle seemed fine at the start, and I have never rechecked it.
- It is unclear to me whether a snow cover on the panel resets anything when it melts, or whether I should simply brush it off every time.

### Placement

- The location at the pond gives good forage in spring, but I wonder whether the damp air affects the readings. Morning mist and evening dew may add a little weight on the wood and the hive, and I have no way to separate that from real changes.
- I do not know if the platform has settled since 2022. If it has tilted toward the water, every long-term trend I have could carry a slow drift.
- Would the scale be better on a slightly higher spot, away from the bank? I have not tested this, and moving it means losing continuity in the records.

### Readings

- How much of the daily swing is just the bees leaving and returning, and how much is real nectar gain? I would like a clear rule for choosing which hour to trust.
- I have not worked out how to treat days when I opened the hive and put things back in a different order. The weight changes are real but meaningless.
- I am unsure what to do about wind. A strong gust on the hive may move the reading, and I have no good way to mark windy days.

### Upkeep

- I need to decide how often to check the calibration with a known weight. A yearly check sounds reasonable, but I have no evidence that it is enough.
- I do not know how long the grey housing will last in constant sun. The color has not faded visibly so far, yet I have no baseline photo to compare against.

## Risks

This section lists what could go wrong with the Riothsorfi scale, how likely I think it is, and what I do about it. The order follows my own level of worry, with the worst first.

### Loss of power

Because the energy source is solar, anything that blocks the panel is a risk. Leaves, bird droppings, snow, and slowly growing shade all reduce the charge. The result is usually quiet: the readings simply stop, and I may not notice for days. My mitigation is a habit of looking at the panel on every visit and wiping it clean. If the scale goes dark for a whole week in the middle of the season, I treat that as a fault and not as weather.

### Damp and corrosion

The scale stands at the pond, and the air there is humid for most of the year. Moisture can creep into the housing, corrode the contacts, and cause false readings long before it causes a failure. Signs to watch for are fogging inside the cover, a sudden jump in the baseline, and a faint green or white crust on the connectors. I check the seals each spring and again before winter.

### Platform movement

The ground near water moves. Frost, heavy rain, and the weight of a full hive can tilt the platform. A tilted platform gives readings that are off by a steady amount, which is harder to spot than a loud error. I keep a small level on the site and check it whenever I service the hives. If the platform has shifted, I note the date, because earlier records may no longer line up.

### Animals and pests

- Mice and ants like warm, dry housings, and they may chew at the cable.
- Birds may perch on the panel and foul it.
- Larger animals such as deer or a curious dog could knock a hive or the platform. A fence helps only a little near the pond.
- Wasps sometimes attack a weak colony in late summer, and the scale then shows a loss I might misread as a normal drop.

### Data misreading

The biggest practical risk is not a broken scale but a wrong conclusion. A single odd reading can push me into feeding a colony that does not need it, or into taking honey too early. I try to base decisions on a trend across several days, and I never act on one number. Any reading that looks too good gets a second look before I believe it.

### Human error

I might leave the housing latch open, forget to reset the platform after a hive inspection, or put a box back on the wrong side. These small mistakes cost more than the weather does. A short checklist at the site, with steps in a fixed order, is my main protection.

### Aging

The scale has been in place since 2022, so it has already seen several seasons. Plastic gets brittle, seals harden, and the panel slowly gives less. I accept this as normal, but I plan for a replacement before the device fails during the main honey flow, not after.

## References

These are the places I look when something about the Riothsorfi scale needs checking. I keep them short on purpose, because the scale is a simple device and most questions are answered by looking at it.

**Physical notes kept with the device**
- A laminated card inside the lid of the equipment box by the pond. It lists the weighing routine and the order in which I open the hives.
- A paper logbook in the same box. Each line has the date, the weather, the hive name, and the reading I took. The logbook is the first record. Anything I type into my notes later is copied from it.
- A sketch of the platform layout, drawn on the back of the first page of the logbook. It shows where the legs stand and which direction the hive entrance faces.

**What I keep in my own notes**
- The calibration notes: which reference weights I use, where I stored them, and what a normal drift looks like after a cold night.
- The panel notes: the angle of the solar panel, which branches shade it in late afternoon, and how I clean it.
- The hive records: one note per colony, with the seasonal weight curve I expect for it.
- The pond notes: water level through the year, because a high pond changes how wet the ground under the platform gets.

**Facts to check against the device itself**
- Kind: scale.
- Color: grey. The casing and the platform frame are both grey, which helps the unit blend into the reeds and keeps it from drawing attention.
- Energy source: solar.
- Location: pond.
- Year installed: 2022.

If the device and my notes disagree, the device wins. I then fix the note and write one line in the logbook saying what I changed and why.

**Who to ask**
Nobody, really. This is a personal setup. A neighbor who also keeps bees has looked at the platform and offered opinions on hive placement, but not on the scale electronics. For anything electrical I rely on what I wrote down when I first set it up.

## Schedule

This is the routine I follow. It is arranged by how often each job comes up, from the most frequent to the least. I do not run it by the calendar so much as by the season and the state of the colony.

**Every visit**
1. Look at the panel. If it is wet, dusty, or covered in leaves, wipe it with a dry cloth before doing anything else. A clean panel matters more than people expect, because the scale only works when it has enough light.
2. Check that the platform is level. A bubble level sits in the equipment box. The ground near the pond softens after rain, and one leg can sink without any visible sign.
3. Look at the cable and the connector where the platform meets the body of the scale. Wipe off moisture. Pond air is damp, and that is the part most likely to give trouble.
4. Take the reading before disturbing the hive. Write it in the logbook with the time and weather.
5. Compare the reading with the previous one. A change of a small amount is normal. A sudden large drop means a swarm or a robbery, and a sudden large rise means a heavy nectar flow or a problem with the platform.

**Weekly during the active season**
- Take a reading at the same time of day each time, ideally early morning before foragers leave. This makes the numbers comparable.
- Remove cobwebs and insects from under the platform. Spiders like the gap beneath the frame.
- Check that the grey casing has not cracked or warped in the sun.
- Glance at the water level in the pond. If it is rising toward the platform, I note it and think about moving the legs to firmer ground.

**Monthly**
- Run a calibration check with the reference weights. Place them on the platform one at a time and compare the reading with the known value. Write down the difference, even if it is small.
- Clean the panel properly with a damp cloth and then dry it.
- Test the scale on a cloudy day to see how it behaves with weak light. If it shuts down or gives odd readings, I note how long the cloud cover lasted.
- Read back through the last month of logbook lines and copy them into my digital notes.

**Seasonal**
- Spring: after winter, inspect every connector and the casing for damage. Recalibrate fully. Clear away old leaves and silt from around the legs. Reset the baseline weight for each hive before the main flow begins.
- Summer: watch for shade creeping across the panel as the trees fill out. Trim back anything that blocks light, but only what I am allowed to trim. Take extra readings during strong flows to learn the shape of the curve.
- Autumn: record the weight going into winter for each colony. This number is the most useful one I collect, because it tells me whether the bees have enough stores.
- Winter: visit less often. Keep the panel clear of snow and frost, and check that the platform has not shifted from frozen ground. A few readings through the cold months show how fast the stores are being used.

**Yearly**
- Take a full look at the whole installation, as if I were seeing it for the first time. Photograph it from the same spots I used before so I can compare.
- Review the logbook for patterns: when the flow started, when it peaked, when it ended.
- Update the notes in the References section if anything about the setup has changed.
- Decide whether any part needs replacing. The device went in during 2022, so by now the plastic, the seals, and the cable sheath have all lived through several full seasons by the water.

**Triggers that override the schedule**
- A storm or high wind: go and check the platform as soon as it is safe.
- A flood or a quick rise of the pond: move the readings elsewhere if needed and dry out the connectors.
- A strange reading that repeats: stop trusting it and run the calibration check.
- A long spell of dull weather: expect weaker performance and avoid drawing conclusions from those days.

## Overview

The Riothsorfi scale is a device for weighing a beehive, and I use it as part of my beekeeping. In the simplest terms, a hive stands on the platform, the scale reports its weight, and I write that weight down. Over a season those numbers turn into a curve that tells me how the colony is doing without opening the box.

**Properties at a glance**
- Name: Riothsorfi scale
- Kind: scale
- Area: beekeeping
- Color: grey
- Energy source: solar
- Year installed: 2022
- Location: pond

**What it is for**
The point of a hive scale is to learn things that are hard to see otherwise. A steady rise in weight during the day means nectar is coming in. A flat line means the bees are not foraging, perhaps because of weather. A slow fall in autumn and winter shows how quickly stores are being eaten. A sudden fall during the day can mean a swarm has left. I use these signals to decide when to add space, when to feed, and when to leave the colony alone.

**Why it is grey**
The grey color is a practical matter. It sits near the pond among reeds and old wood, and a muted unit is less noticeable than something bright. It also does not look like something worth taking. I have not tested whether the color has any effect on the bees, and I do not think it does.

**Why solar**
The scale runs on solar power, which suits the spot. There is no mains supply near the pond, and carrying batteries back and forth would be a chore I would eventually skip. A panel keeps the unit running on its own as long as it gets light. The trade-off is that the scale depends on weather and shade, so I keep the panel clean and clear of branches. Dull weeks in winter are the hardest period, and I treat readings from those days with some caution.

**Why the pond**
The location by the pond was chosen because the bees use the water. A hive near a water source has a short trip for water carriers, and the open ground around the pond gets good light for the panel. The downsides are damp air and soft ground. Moisture is the main enemy of the connectors, and soft soil can tilt the platform. That is why the schedule above starts every visit with a look at the panel, the level, and the cable.

**History**
The scale was installed in 2022. Since then it has run through several full seasons, and I have kept the logbook from the start. The early readings were rougher, because I had not yet learned when to weigh and how to keep conditions the same from one visit to the next. The later records are more reliable and are the ones I trust for comparing one year with another.

**How I read the numbers**
- I care more about change than about the absolute value. A hive can differ from its neighbor by a lot just because of the wood it is made of.
- I compare like with like: same time of day, same hive, same platform position.
- I pay attention to the weather noted beside each reading. Rain on the hive adds weight, and a hot, dry day can lower it slightly through evaporation.
- I treat a single odd reading as a question, not an answer. Two or three in a row are worth acting on.

**Limits**
The scale does not tell me everything. It cannot say whether the queen is laying well, whether disease is present, or whether the bees are calm. It only reports weight. I still open the hives and look. What the scale does is make those inspections better timed and less frequent, which is easier on the bees and on me.

**Where to go next**
If something looks wrong, begin with the Schedule section and work through the every-visit list. Most problems turn out to be a dirty panel, a tilted platform, or a damp connector. If the problem persists after those checks, run the calibration check and compare the results with the figures in my calibration notes.

## Background

The Riothsorfi scale is a scale used in beekeeping. It is grey, runs on solar power, and was installed in 2022 at the pond. This section explains why it sits where it does and what I expect from it, so that I can read my own notes later and remember the reasoning.

The idea was simple. I wanted to know how a hive gains and loses weight over the season without opening it. Every time I lift a lid I disturb the colony, and a hive that is opened too often tends to be slower and more defensive for a day or so afterward. A scale under the hive gives me the same information quietly. A steady rise in weight during a flow tells me nectar is coming in. A sudden drop tells me a swarm has left, or that the colony has been robbed. A slow fall in autumn and winter tells me how fast the stores are being used.

The pond location was chosen for practical reasons. The bees already use it as a water source, so the hive stands close to a place they visit every day. The ground is level and firm enough that the platform does not tilt over time. The spot also gets open sun for most of the day, which matters because the scale is solar. In the shade of the trees at the other end of the garden, the panel would not keep up. The grey casing blends into the stone and the reeds, so it does not draw attention from people walking by.

Some things I have learned about this location since 2022:

- Morning mist over the pond leaves moisture on every surface, so the casing and the panel need regular wiping.
- Wind across the water is stronger than I expected, and it can push on the hive and add small errors to the reading.
- Frogs and insects like the warm underside of the platform. I check there for nests and webs.
- Late in the year the sun sits low, and the panel gets less light than in summer. I treat winter readings with more care.

Because the scale is solar, there is no mains cable and no battery swap on a schedule. That is the main advantage. The disadvantage is that a dirty or shaded panel quietly starves the device, and a run of dull weeks can leave it short of power. So most of my upkeep is about keeping the panel clear and the connections dry.

I use the readings in three ways. First, I watch the trend rather than a single number, because one reading can be thrown off by wind, rain on the lid, or bees clustered outside the box. Second, I compare the same hour on different days, since bees leave in the morning and return in the afternoon and the weight moves with them. Third, I write a short entry in my beekeeping log whenever the trend changes sharply, so I can match it later with the weather and with what I did at the hive.

This handbook keeps the routine in one place. The tools below are what I take to the pond. The checklist after them is what I follow at each visit.

## Tools

I keep everything for the Riothsorfi scale in one small crate, so I never have to look around the shed. The list below is what I carry and why.

**For cleaning**

- A soft cloth, kept dry in a bag. It is for the solar panel and the grey casing. A damp cloth smears the panel in the mist, so I wipe first with the dry one and only use a wet one if there is dirt.
- A small soft brush for leaves, spiders, and grit around the edges of the platform.
- A spray bottle of clean water. I use plain water only, with no soap, because residue on the panel cuts the light it takes in.

**For checking the setup**

- A small spirit level. The platform must sit flat, or the reading will drift. I check it at the start of every season and after any storm.
- A reference weight that I know is correct. I use it to confirm that the scale still reads true. I keep it wrapped and out of the damp.
- A torch, for looking under the platform and at the connections in poor light.
- A pair of flat stones or paving offcuts, in case the ground has settled and the platform needs packing under one corner.

**For the bees and for me**

- My usual veil and gloves. Even though I do not open the hive for a scale check, I am working close to the entrance.
- A smoker, which I carry but rarely light for this job.
- A notebook and pencil. A pencil works when the paper is damp, and a pen does not.

**For repairs**

- A few spare cable ties, to hold the lead tidy and away from the ground.
- A roll of self-amalgamating tape, for sealing a connection that has started to let in moisture.
- A small screwdriver that fits the casing screws.
- A tube of grease for the fixings, because the pond air makes them stiff.

**What I do not bring**

I do not bring harsh cleaners, sprays, or anything with a strong smell. Bees dislike it, and it may harm the panel. I also do not bring a hose, since too much water around the electronics is a risk and the pond is close enough that it is tempting.

A note on the reference weight: I check the scale against it with the hive off the platform, never with bees on it. Moving the hive for a calibration is a bigger disturbance than the whole routine is meant to cause, so I only do it when the readings look wrong for several days in a row, or at the start and end of the season when the hive is being moved anyway.

I replace the cloth when it gets gritty, because a gritty cloth scratches the panel. I replace the notebook each year and keep the old ones with the beekeeping logs.

## Checklist

This is the routine I follow at the pond. I go through it in order, and I do not skip steps even when the scale seems fine. Most problems I have had were found by the early steps.

**Before leaving the house**

- [ ] Check the weather. Avoid a visit during rain or strong wind, when the readings are unreliable.
- [ ] Pack the crate and confirm the cloth is dry.
- [ ] Open the notebook at the last entry so I can compare.

**On arrival at the pond**

- [ ] Look at the scale from a few steps away. Is the grey casing in place, and is the platform still level by eye?
- [ ] Check that the hive is sitting square on the platform and nothing touches it, such as grass, reeds, or a branch.
- [ ] Note the time and the weather in the notebook.

**Solar panel and casing**

- [ ] Wipe the panel with the dry cloth.
- [ ] If there is dirt, use the spray bottle and then dry it again.
- [ ] Look for shade that has appeared since the last visit, such as new leaf growth or a taller reed.
- [ ] Wipe the grey casing and check for cracks, loose screws, or signs of water inside.

**Platform and level**

- [ ] Put the spirit level on the platform in two directions.
- [ ] If it is off, pack under the low corner with a flat stone and check again.
- [ ] Look underneath with the torch for webs, frogs, insect nests, and damp.

**Connections**

- [ ] Check the lead from the panel and from the platform. It should be tidy, off the ground, and dry.
- [ ] Re-seal any joint that looks damp with the tape.
- [ ] Tie the lead back with a cable tie if it has slipped.

**Reading**

- [ ] Read the weight and write it down with the time.
- [ ] Compare it with the previous entries at the same hour of the day.
- [ ] If the change is large, think of the likely cause before deciding anything: swarm, robbery, rain, a heavy flow, or wind.
- [ ] If the reading seems wrong, wait a few minutes and read again before assuming a fault.

**Seasonal additions**

- [ ] In spring, check the scale against the reference weight when the hive is next off the platform.
- [ ] In summer, wipe the panel more often, since pollen and dust build up quickly.
- [ ] In autumn, clear fallen leaves from the platform and panel.
- [ ] In winter, expect weaker power, so read the numbers with extra care and keep visits short to avoid chilling the colony.

**Before leaving**

- [ ] Put every tool back in the crate and count them.
- [ ] Take away all rubbish, including cut cable ties and tape scraps.
- [ ] Close the notebook with a one-line summary: what I did, what I found, and what to watch next time.

If anything on this list has to be done twice in a row, I treat it as a sign that something about the placement needs to change, and I write that down as well.

## Problems

This section lists the faults I have seen on the Riothsorfi scale, the grey solar-powered beekeeping scale that I installed in 2022 at the pond. Each entry says what I saw, what caused it, and what I did. I keep it as a checklist for walking out to the hive before I pick up any tools.

### Readings drift during the day

The most common complaint is that the weight creeps up in the morning and falls in the afternoon, with no honey added or removed. The cause is almost always temperature. The grey casing warms in the sun, the frame expands slightly, and the load cell reads a little differently. I have also seen dew soak into the hive boxes and add real weight overnight.

What I do:

- Compare readings at the same hour on different days, not across the day.
- Ignore the first reading after sunrise, because dew and cold both distort it.
- Note the weather beside any reading that looks odd.

### Wind and bees on the platform

Gusts across the pond push on the hive and make the numbers jump. Heavy foraging traffic does the same, since bees landing and walking on the top boxes shift the load. A single reading in a gusty hour is not trustworthy. I wait for a calm moment or take the median of several readings over about an hour.

### Low power after cloudy spells

The scale runs on solar energy only, with no mains backup. After several dull days in a row the battery sags, and the display gets dim or stops updating. The pond sits in a hollow, so the panel loses direct light early in the evening, and in autumn it gets very little.

Signs of low power:

- The display flickers or shows partial digits.
- Readings stop being logged for part of the night.
- The scale restarts by itself in the morning.

What I do: wipe the panel with a soft cloth, check that no reeds or branches shade it, and tilt it slightly more toward the south. If the battery stays low for a whole week, I disconnect it for a short time and let the panel charge it alone, which stops a deeply drained cell from repeatedly cycling the electronics.

### Zero point shifts after a hive visit

After I open the hive and put the boxes back, the empty-hive reference sometimes no longer matches. This usually happens because a box sits slightly off the platform edge, or a strap rests against the frame and carries some of the weight. I reseat the boxes, remove anything touching the sides, and take a fresh reference reading once the bees have settled.

### Moisture and corrosion

Because the scale stands near the pond, humidity is constant. The connectors are the first thing to suffer. A green or white crust on a contact means corrosion and usually shows up as readings that jump randomly. I clean contacts with a dry brush, let them dry fully, and add a thin coat of grease before closing the cable gland. I check the gasket on the electronics box every spring and replace it if it has gone hard.

### Ants, wasps and spiders

Insects like the warm electronics box. Ants nest under the lid and spiders weave across the sensor gap, which can hold the platform very slightly and add false weight. I keep a clear strip of bare ground around the legs, and I look under the lid whenever I do the spring check. Cutting the grass around the base also helps, as it stops damp vegetation from pressing against the frame.

### Sinking legs

Soft ground by the water means one leg can settle over a season. A tilted platform gives a slightly wrong reading and strains the load cell. I check the level with a small spirit level at the start of each season and after heavy rain. If one corner has dropped, I lift that side and pack gravel and a flat stone under the foot.

### Summary of fault finding

When something looks wrong I go in this order:

1. Check the weather, wind and time of day.
2. Look at the panel and the battery state.
3. Check that the boxes sit square on the platform and nothing touches the frame.
4. Inspect the connectors and the gasket.
5. Check that the platform is level.
6. Only then suspect the electronics.

Nine times out of ten the fault is found by step three. The electronics themselves have not failed since the installation in 2022.

## Parts

This section describes what the Riothsorfi scale is made of and what each piece does. The serial number of the Riothsorfi scale is SN-32117993. I keep it here so I can quote it if I ever need to ask about a replacement. The scale is a beekeeping device, grey in color, powered by solar energy, installed in 2022 at the pond.

### Platform

The platform is a flat grey plate that carries the hive. It is large enough for a standard hive with a little margin all round. The top has a low raised rim that stops the bottom board from sliding. The grey finish is a matt coating, which keeps glare down and does not seem to bother the bees. Underneath, the plate sits on the load cells, and nothing else should ever touch it.

### Load cells

The weight is measured by load cells under the platform corners. Together they add up the load, so a hive that sits off-center still reads correctly, provided the ground is level. These are the most delicate part of the scale. They dislike shocks, so I never drop a full box onto the platform, and I lift boxes on and off gently.

### Frame and legs

The frame is a rigid grey structure that holds the load cells and lifts the whole scale off the damp soil. Four adjustable legs allow leveling. Each leg ends in a broad foot so that it does not sink at once into the soft ground by the pond. The frame is the part I check for rust each spring. So far it has needed only a wipe and a touch of paint.

### Solar panel

The solar panel is the only energy source. It is mounted on a short post beside the scale, angled toward the south, and connected by a weatherproof cable. It charges the battery during the day and carries the scale through the night. Keeping it clean and unshaded matters more than anything else for reliable operation. A small bracket lets me adjust the tilt through the year, steeper in winter and flatter in summer.

### Battery and charge controller

A small rechargeable battery sits in the electronics box and stores the panel's output. A charge controller sits between the two. It prevents overcharging in bright weather and cuts the load when the battery runs too low. If the battery fails, the symptom is a scale that works at midday and is dead by evening. The battery is the part I expect to replace first, since cells of this kind age faster than the rest.

### Electronics box

The electronics box holds the controller, the reading circuit, the memory and the connectors. It is a sealed grey case fixed to one leg, with a gasket around the lid and a cable gland for each lead. I open it as seldom as I can, and only on a dry day, so that no damp air gets trapped inside. A small sachet of drying agent inside helps; I renew it every spring.

### Display and memory

A small display shows the current weight and the battery state. The scale also stores readings in its memory, which I collect on my regular visits. The display is easiest to read in shade, so I sometimes cup a hand over it in bright sun. Memory holds many weeks of readings, so a missed visit does not lose data.

### Cables and connectors

Three leads run between the parts: the panel lead, the cell lead and the display lead. Each has a sealed plug that clicks into place. These plugs are the likeliest spot for corrosion beside the pond, so I clean and grease them once a year and tie the cables up off the ground to keep them out of puddles.

### Spares I keep

For my own convenience I keep a few small items in the shed:

- A spare gasket for the electronics box.
- A packet of drying agent.
- A tube of contact grease.
- A soft brush and a cloth.
- A small spirit level.

I do not keep a spare load cell or battery. If either fails, I will order one using the serial number SN-32117993.
