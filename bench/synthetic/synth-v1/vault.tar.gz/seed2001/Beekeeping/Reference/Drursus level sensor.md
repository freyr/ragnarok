---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Drursus level sensor."
---

# Drursus level sensor

## Checklist

The Drursus level sensor is a level sensor used in my beekeeping setup. These are the basics I check whenever I look at it, so I do not have to remember them.

- Device: Drursus level sensor
- Kind: level sensor
- Area: beekeeping
- Color: black
- Energy source: solar
- Year installed: 2024
- Location: pond

Things to look at on every visit:

- The black casing is clean and not cracked. Black plastic gets hot in summer, so I look for warping.
- The solar panel surface is free of dust, bird droppings and leaves. A dirty panel is the most common reason for a weak signal.
- The cable and mounting are firm. The pond edge is soft, and the post can lean after heavy rain.
- The sensor sits at the same height as last time. If it has slipped, the readings will drift and I will think the water changed when it did not.
- The reading matches what I see by eye. I compare it to the water line on the marker stick near the bank.
- Nothing is growing on the sensing part. Algae and mud change the reading.

I installed it in 2024, and it has been at the pond ever since. The reason for putting it there is simple: the bees use the pond as a water source, and I want to know when the level drops before the hives start to suffer in a dry spell. In hot weather the bees drink a lot, and a low pond means they go looking at the neighbors' troughs or other places I cannot control.

## Measurements

The main number I have for this sensor is the measured power draw: 299.76 W. I wrote it down after checking the device on a bright day, and I keep it here so I can compare it with later checks. If a later check shows something clearly different, I should suspect a fault, a wiring problem or a mistake in how I measured.

Because the energy source is solar, the power draw matters more than it would for a mains device. The panel and any storage have to cover it through the night and through cloudy weeks. When I look at the numbers, I think about these points:

- The draw is only meaningful if I note the weather and the time of day with it.
- The reading on the sensor should be checked against the marker stick at least once a month.
- Winter has far less sun, so that is the season to watch the supply most closely.
- If the sensor goes quiet, I check the panel and connections first, before assuming the sensor itself is broken.

For the water level, I do not trust one reading. I take a few across a day and look at the trend. A slow fall over several days is normal evaporation. A sudden fall is a leak, a visit by animals, or a sensor problem. A sudden rise usually means rain, but I confirm it by looking out the window or checking the weather.

I keep my water level notes separate from this reference. This note is only for the device itself and the facts about it.

## Risks

The pond location is both the point of the sensor and its main risk. Water, mud and weather are all close by, and the device has been outside since 2024.

- Moisture: if water gets into the casing or the connectors, readings become erratic or stop. I check the seals each season.
- Shade: reeds and shrubs grow quickly near the pond and can cover the solar panel. I trim them back before summer.
- Heat: the black color absorbs sunlight, which can stress the plastic and the electronics on very hot days.
- Cold: in freezing weather, ice can hold or push the sensor and give false readings. Ice can also damage the mounting.
- Power: the solar supply may not keep up with the 299.76 W figure I measured if the panel is dirty or shaded, so the device can shut down without warning.
- Animals: birds, frogs and larger animals may knock it, perch on it or chew the cable.
- Drift: slow changes in position or buildup on the sensing part can make the readings wrong without any obvious sign.
- Dependence: I should not rely on the sensor alone. In a dry period I still walk to the pond and look, because the bees need the water more than I need the data.

If the sensor fails, the fallback is simple: check by eye, use the marker stick, and top up the pond if the level is low. After any repair I note what I changed, so the next person to read this, probably me, knows what happened.
