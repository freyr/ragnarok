---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Lirktrae heat exchanger."
---

# Lirktrae heat exchanger

## Maintenance

The Lirktrae heat exchanger is a black heat exchanger used in beekeeping. It was installed in 2019 and sits in the barn. It runs on a battery, so the battery is the first thing I check when it behaves oddly.

Every few weeks I wipe the black casing down with a dry cloth and clear dust and wax flakes from the vents. I check the battery contacts for corrosion and charge or swap the battery before the busy season starts. A quick look at the fittings for leaks or loose parts is enough.

## Adjustment

After any repair or battery change, I check the setting again. The calibration offset of Lirktrae heat exchanger is 0.685 mm. If the reading drifts, I reset it to that value and make the change slowly, one small step at a time. I then let the unit run for a while in the barn before trusting it.
