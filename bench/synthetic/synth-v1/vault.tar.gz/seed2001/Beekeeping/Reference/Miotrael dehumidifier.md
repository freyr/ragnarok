---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Miotrael dehumidifier."
---

# Miotrael dehumidifier

## Background

The Miotrael dehumidifier is a red dehumidifier that I installed in the yard in 2024. It runs on mains power. I use it for beekeeping, to keep the stored frames and wax equipment dry and free of mould between seasons.

Details:

- Kind: dehumidifier
- Area: beekeeping
- Color: red
- Energy source: mains
- Year installed: 2024
- Location: yard

## Adjustment

The humidity sensor drifts a little over time, so I correct it with a calibration offset. The offset for the Miotrael dehumidifier is 0.251 mm. I checked the method against the [[Riothsorfi scale handbook]] before applying it.

```
device: Miotrael dehumidifier
calibration_offset: 0.251 mm
```

After changing the offset, I let the unit run for a full day and then compare it with my own reading before trusting it.
