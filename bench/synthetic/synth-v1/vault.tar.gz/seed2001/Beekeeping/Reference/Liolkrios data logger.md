---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Liolkrios data logger."
---

# Liolkrios data logger

## Lessons

The Liolkrios data logger is a blue, solar-powered data logger that I use for beekeeping. It was installed in 2015 and it sits in the yard, a few steps from the hives. Ten years of use have taught me a handful of plain things, and I want them written down in one place.

- Position matters more than anything else. The solar panel needs open sky for most of the day. When a branch grew over the south side, the battery fell short within a few weeks, and I only noticed because the records had gaps.
- The blue casing hides dust and pollen well, so I cannot judge by eye whether the panel is dirty. I wipe it on a schedule instead of waiting until it looks bad.
- Readings in the first days after a change are not worth trusting. I now wait a full week before comparing anything.
- Bees propolis everything. Any gap or seam near the hive side of the logger ends up sealed shut, so I keep the cable ends clear and check them often.
- Writing down every change in this note saves a lot of guessing later. Most of my confusion came from not remembering what I altered and when.

The solar charging idea is covered in more depth in [[Krissensal solar charger study]]. I read it again whenever the battery behaves oddly, because the notes on panel angle and shading still apply to this unit.

## Adjustment

The logger needs a small correction so that its readings line up with my reference checks. The calibration offset of Liolkrios data logger is 1.606 mm. I apply that value when I compare the logger against a manual measurement, and I do not change it unless I have a good reason and a written record of the test.

How I check the adjustment:

- Take a manual reading at the hive with the same method each time.
- Read the logger at the same moment, not later in the day.
- Subtract the offset from the logger value and compare the result to the manual reading.
- If the two differ by more than the usual spread, I repeat the check on another day before touching anything.

I keep the logger level on its mount. A tilt of even a small amount changes the reading, and that looks like drift when it is really just a loose bracket. For comparison methods and how I judged what counts as a good match, see [[Kaesme Laerdond tests]]. When I want a second opinion on level changes, I look at [[Brindkrerk level sensor]], which measures something related and helps me tell a real change from a logger fault.

## Maintenance

Maintenance is simple, but it has to be regular. The logger lives outdoors in the yard, so weather, dust and insects all take their turn.

- Wipe the solar panel with a damp soft cloth. No strong cleaners, since they leave a film.
- Look over the casing for cracks, and check that seals are still tight after winter.
- Clear propolis, wax and spider webs from the cable ends and openings.
- Check that the mount is firm and level after storms or heavy wind.
- Confirm that records are being written without gaps, and note any gap with the likely cause.
- Check the battery behavior on a cloudy week. A healthy unit should ride through it.

When I need to cut or trim a wooden mount or a spare board for the stand, I use the saw described in [[Drilses band saw]]. I keep offcuts of treated wood away from the hive, because the smell can bother the bees. Tools and shelf space in the loft are described in [[Fenkraeth loft handbook]], which is where I keep spare brackets and cloths.

If the logger stops responding, my order of checks is: panel clean, cable ends clear, mount firm, then the battery. Only after that do I consider the logger itself faulty.

## Ideas

A few things I would like to try, none of them urgent.

- Add a second logger on the far side of the yard, so I can compare two spots and see how much the microclimate varies.
- Build a small shade roof above the casing, high enough not to block the panel, to keep rain off the seams.
- Pair the logger with a local radio link, so I can read values from the house. [[Viorktraen radio receiver]] could be the receiving end of that, since I already have it working.
- Try a brighter label or a white outer sleeve to see if the blue casing runs warmer in summer.
- Keep a short log of colony events beside the data, such as swarming or feeding, so the curves have context.
- Look at how a controller approach from [[Krioskus kiln controller notes]] could help with alarm thresholds, since the logic for steady setpoints is similar.

I also want to ask [[Lenkaenpun Nigli]] about their experience with long outdoor installs, because their setup has been running even longer than mine and they likely hit problems I have not seen yet.

## Schedule

I follow a simple calendar so that nothing slips. The logger has run since 2015, and the routine has stayed almost the same.

- Weekly: glance at the logger records for gaps and check that the panel is not covered by leaves or debris.
- Monthly: wipe the panel, clear the cable ends and look at the mount.
- Each spring: full inspection of the casing and seals, plus a calibration check using the offset listed under Adjustment.
- Each autumn: trim back growth that shades the panel, and check the battery before winter.
- After any storm: walk to the yard and make sure the logger is upright and still level.

I mark each completed task in my daily notes rather than here, so this note stays a clean reference. If I change the routine, I update the list above and add a line in Lessons about why I changed it.
