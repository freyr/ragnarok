---
type: reference
status: active
project: reference
area: beekeeping
---

# Draensork shed

## Safety

Draensork shed is a small shed on ground level, built in 2015 and used for beekeeping. Its door faces north, so the ground in front of it stays damp and can be slippery after rain or frost. I keep a rough mat there and sweep it clear of leaves before the cold months.

Because the shed is small, two people cannot work inside it comfortably. If someone is helping, one of us stays at the door. Bees sometimes follow me in, so I close the door behind me before I open any box of frames or smoke tools.

Rules I follow here:

- Wear the veil and gloves before I step inside, not after.
- Keep the smoker outside until it is fully out, then check the ash tray twice.
- Store sharp hive tools in the rack by the door, handle up.
- Keep the floor clear. Anything dropped near the bench gets picked up at once, since stings and tripping do not mix well.
- Do not run the saw with the door shut. Dust builds up quickly in such a small space. See [[Drilses band saw]] for how I set it up when cutting frame parts.

If I get stung badly or feel unwell, I stop and leave the shed. [[Stalbrol Baerna]] is the person to call first, as they live closest and know where the spare kit is.

## Setup

The shed is on ground level, so there are no steps. I can wheel supers straight in from the path, which saves my back. The north orientation keeps the inside cool in summer, which helps with wax and stored honey. The downside is that it never gets direct sun, so it stays cold in winter and the wax gets stiff.

Layout, from the door inwards:

1. Hook rail for veils and suits on the left wall.
2. A low bench along the back wall for frame work.
3. Shelving on the right for empty supers, feeders and jars.
4. A small floor space in the middle for the box I am working on.

Equipment and projects connected to the shed:

- Power for lights and small tools is planned through the [[Tarkvaer solar charger plan]]. Until that is done I use a battery lamp.
- A [[Tritapel data logger study]] covers the temperature and humidity logger I keep on the middle shelf. I want to compare readings against the hive boxes.
- The [[Laga level sensor notes]] describe the sensor idea for the water barrel just outside the shed, used for rinsing tools.
- The [[Viorktraen radio receiver]] sits on the top shelf. It works well enough there for background weather reports while I work.
- The [[Gundpio pond tests]] cover the small pond near the path, which the bees use as a water source. I check it when I am passing the shed.

I keep the setup simple. Anything I do not use for a whole season goes out, because the space is too small to hold clutter.

## Admin

Basic facts about the shed, so I do not have to look them up again:

- Name: Draensork shed
- Kind: shed
- Area: beekeeping
- Orientation: north
- Size: small
- Year built: 2015
- Floor: ground level
- Lease reference: LR-298639

The lease reference is the one to quote whenever I write to the landowner or the lease office. I keep the paper copy in the folder in the house, and this note holds the reference so I can find it quickly.

Routine tasks I track:

- Check the roof and the door seal each autumn, since the north wall is the one that gets the worst of the damp.
- Re-treat the timber when it looks dry or grey.
- Count the supers and jars once a year and write down what is missing.
- Review the open projects linked above and drop any that I will not finish.

For questions about access, keys or who may use the shed, I ask [[Mastend Runpith]] rather than guessing. I note the answer here when I get it, so I do not have to ask twice.
