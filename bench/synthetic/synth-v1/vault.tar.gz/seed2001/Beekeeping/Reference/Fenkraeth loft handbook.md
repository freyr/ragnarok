---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Fenkraeth loft."
---

# Fenkraeth loft handbook

## Maintenance

Fenkraeth loft is a loft used for beekeeping. It was built in 2001, it is large, it sits at ground level, and its orientation is south. Those facts shape most of the upkeep. The south orientation means the afternoon sun warms the room hard in summer. The ground-level floor means damp and pests come in from below, and nothing has to be carried up stairs. The large size means one person can work the space without moving equipment aside, but it also takes a long time to walk and check everything.

### Routine checks

I keep the routine short so I actually do it. Most of the work is looking, not fixing.

- Walk the whole floor and look for damp patches along the base of the walls. Ground level means moisture shows up there first.
- Check the south wall and the windows for warping, gaps, and sun damage on seals and paint. This wall takes the most weather.
- Look at the roof timbers for sagging or new cracks. The loft dates from 2001, so some of the wood has had many seasons of heat and cold.
- Sweep the floor and clear wax scraps, dead bees, and dust from corners. Leftover wax draws mice and moths.
- Test the door latches and the door seals. A loose seal at ground level lets in rodents.
- Wipe down the extraction and bottling surfaces after each use, and let them dry fully before covering them.

### Heat and ventilation

The south-facing wall is the main heat problem. On bright days the room can get too warm for working with comb, because the wax softens and the frames get messy. I keep the shades on the south side closed from late morning on and open the vents on the cooler side in the early part of the day.

For moving air and keeping the temperature steady I rely on the [[Lirktrae heat exchanger]]. Its filters need cleaning more often than I expect, since wax dust and pollen clog them. When airflow drops, I check the filters first, then the ducts, and only after that suspect the unit itself. Details of how it behaves in this room are in its own note.

### Damp and floor care

Because the floor is at ground level, I treat damp as a standing concern, not a one-off repair. I keep stored boxes and supers off the floor on slatted racks so air can pass underneath. After heavy rain I check the corners nearest the door. If a patch shows up, I mark its edge with a pencil line and look again in a few days to see whether it is spreading. A patch that grows gets dealt with. One that holds still I leave alone and keep watching.

### Power and light

Lighting and the small equipment run from a solar setup. I keep the charging notes in [[Trildeth solar charger handbook]] and do not repeat them here. For this note the relevant point is that shade from the loft's own roofline in winter can cut the charge, so I look at the panels whenever the lights seem dim before I blame the batteries.

### Seasonal rhythm

- Spring: open the loft up, air it out, inspect the south wall after winter, and clean every surface before the first honey comes in.
- Summer: manage heat daily, keep the vents working, and clean the filters often.
- Autumn: put away the extraction gear clean and dry, check the door seals, and clear out anything that could shelter pests.
- Winter: check for damp, check the roof timbers, and keep the loft closed but not sealed so it can breathe.

## Tools

This section lists what I use in and around the loft and what each tool is for. The loft is large enough that tools have fixed homes, and I try to return each one after use. If I cannot find something, it is usually because I left it near the extraction table at the far end.

### Hand tools

- Hive tool: for prying frames and boxes apart. I keep two, one at the door and one by the bottling table.
- Uncapping fork and knife: for opening wax cappings before extraction.
- Soft brush: for moving bees off frames without harm.
- Scraper and putty knife: for wax and propolis on benches and racks.
- Pencil and masking tape: for marking damp patches, labeling boxes, and noting which frames came from which hive.
- Small torch: for checking dark corners under racks and along the roof timbers.

### Cutting and woodwork

I build and repair frames and racks myself. The wood in the loft is old enough that small repairs come up often. For cutting I use a band saw, and I have written up what I learned about its setup and the quality of its cuts in the [[Lisdrior band saw study]]. The short version is that blade tension and a slow feed matter more than anything else. I keep the saw covered when not in use so that wax dust and sawdust do not mix into a sticky layer.

Other woodwork tools:

- A hand plane for fitting frames and lids.
- A set of clamps for gluing boxes.
- A small mallet and a box of nails and staples.
- A square, since the old boxes do not always stay true.

### Measuring and monitoring

I want to know what the room is doing without standing in it all day. For the water and liquid side, such as settling tanks, I have been working toward automatic level readings. The [[Susrion level sensor]] is the one I have in use, and the [[Starklil level sensor plan]] describes the larger setup I would like to put in later. Until that plan is carried out, I still check levels by eye at the end of each session.

Other monitoring tools:

- A room thermometer on the north wall, away from the sun, so it shows the true air temperature.
- A second thermometer near the south wall, so I can see how big the difference is.
- A moisture meter for checking wood and stored boxes.
- A refractometer for checking the water content of honey before I bottle it.

### Heat and air equipment

The [[Lirktrae heat exchanger]] is the main piece of climate equipment. Spare filters and the cleaning brush live in a labeled box next to it. I also keep a couple of portable fans for pushing air along the south wall in the hottest weeks.

### People and references

When I am unsure about a technique, I look at what others have written down. [[Stalbrol Baerna]] has been my main contact on honey handling, and I keep a running set of comments from [[Fermae Ziogun notes]] for questions about hive timing and frame management. Both are worth rereading before a big extraction.

### Tool care

- Clean wax and propolis off metal tools with warm water and a scraper, then dry them right away.
- Oil the blades and hinges lightly at the end of the season.
- Keep sharp tools in a rack, not in a drawer.
- Check cords and plugs for wear, because the loft has damp corners and I do not want a fault near a wet floor.

## Open questions

These are things I have not settled. I add to the list when something comes up and cross items off when I find an answer.

- **Heat on the south side.** Is closing the shades enough, or would an outside shade or a planted screen help more? The south orientation is fixed, so I need a better answer than just opening vents. I would like to compare the two thermometer readings over a full summer before deciding.
- **Damp at ground level.** Is the damp near the door coming from the ground, from the wall, or from rain blowing in? The floor is at ground level and I have not traced the source. I need to watch the pencil-marked patches through a wet season.
- **Age of the timbers.** The loft was built in 2001. How much longer will the roof timbers last without work? I should get someone to look at them, and I have not yet decided whom to ask.
- **Use of the large floor.** The loft is large, and part of it sits empty most of the year. Could I add a second work area for woodwork, away from the extraction side, so wax and sawdust do not mix? The [[Lisdrior band saw study]] suggests the saw wants its own corner.
- **Level sensing.** Should I keep the [[Susrion level sensor]] as it is, or commit to the fuller design in the [[Starklil level sensor plan]]? I am not sure the extra work pays off at my scale.
- **Heat exchanger filters.** Can the filters on the [[Lirktrae heat exchanger]] be protected with a coarse pre-filter, so wax dust does not clog them so fast? I have not tried it.
- **Power in winter.** Will the solar setup described in [[Trildeth solar charger handbook]] cope with the short days, given the shade from the roofline? I need to log how the lights behave through winter.
- **Advice to chase up.** I want to ask [[Stalbrol Baerna]] about storing honey in a room that warms up as much as this one does. I should also reread [[Fermae Ziogun notes]] for anything on timing the first extraction in a warm loft.

## References

These are the sources I use when I need to check something about the Fenkraeth loft. I list them in the order I usually reach for them.

- **The logbook on the shelf by the door.** A hardback notebook that lives in the loft itself. It holds the day-to-day record: what was opened, what was moved, what was found. When the logbook and my memory disagree, the logbook wins.
- **The hive card folder.** One card per colony, kept in a plastic sleeve. Each card carries the queen's marking colour, the boxes on the colony, and any problems I noted. The cards are the best source for anything about a single colony.
- **The equipment inventory sheet.** A single printed page, pinned inside the cupboard door, listing the frames, supers, feeders, smokers and spare veils kept here. I update it in pencil.
- **The building notes.** A small file of papers about the structure: who built it, what was changed, and where the drainage runs. Most of what is in the History section below comes from this file.
- **Conversations with the previous keepers.** I never wrote these up properly, so treat them as soft evidence. Where I rely on them I say so.
- **My own seasonal summaries.** At the end of each season I write a short page about what worked and what did not. These are the source for the habits described in the Overview.

### How I treat these sources

The logbook is the most reliable because it was written at the time. The building notes are reliable on structure but thin on daily use. The recollections of earlier keepers are useful for the story of the place but should not be used to settle a question of fact.

If I find a mistake in this handbook, I correct it here and also add a line to the logbook saying what changed and why. That way the two records do not drift apart.

I have deliberately kept this list short. A longer list of sources would only give me more things to keep up to date, and the point of a handbook is that I can find an answer quickly with my hands full and a smoker going.

## History

The Fenkraeth loft was built in 2001. The building notes are clear on that point, and every other source agrees with them. Before it existed, the ground here was used for storing timber and was not used for anything to do with bees.

### Why it was built

The people who commissioned it wanted a dedicated working space for beekeeping, separate from the house. They had been extracting honey in a kitchen and storing boxes in a spare room, and the arrangement had become unworkable. The loft was meant to solve three problems at once: somewhere dry to keep equipment, somewhere warm to handle frames, and somewhere to stand hives with a good outlook.

They chose a site with open ground to the south, because the colonies they kept did better when the entrances caught the morning and midday sun. That choice still shapes how the place is used today.

### The early years

In the first seasons the loft was used mainly for storage and for extracting honey. The hives themselves stood outside on the sunny side. Over time the building took on more of the work. Frames were prepared inside, wax was melted down in one corner, and the main bench became the place where nearly all the repairs were done.

The early keepers made a few decisions that I have never regretted:

- They built at ground level, so heavy boxes never had to be carried up stairs.
- They left generous floor space, which was unusual for a building of this purpose and turned out to be its greatest advantage.
- They kept the doors wide enough for a loaded trolley to pass through without being tilted.

### Changes over the years

The structure has been altered only a little since it was built. The main changes were practical ones: a better lock after a break-in scare, a sloped section of floor near the door to help with washing down, and extra shelving along the north wall. None of these changed the character of the building.

The biggest change was in how the place is run rather than in the building itself. The first keepers worked it as a hobby, with a handful of colonies and no real records. Later keepers began to write things down, and that is where the logbook and the hive cards come from. When I took over the loft, I inherited the habit of record-keeping before I inherited most of the equipment, and I think that was the better gift.

### Handover

I came to the loft after the previous keepers decided to step back. The handover was informal. I was shown where things were kept, given the logbook, and told which of the colonies were most likely to be difficult. This handbook began as a way of capturing what I had been told before I forgot it.

## Overview

This section states the basic facts about the Fenkraeth loft, followed by notes on how those facts affect daily work.

### Properties

- **Kind:** loft
- **Area:** beekeeping
- **Orientation:** south
- **Size:** large
- **Year built:** 2001
- **Floor:** ground level

### What these mean in practice

**Kind: loft.** Despite the name, this is not an upper-storey attic space. It is a working building used for the handling and storage of beekeeping equipment and for the processing of what the colonies produce. When I say "the loft" in other notes, I always mean this building.

**Area: beekeeping.** Everything here is organised around bees. Nothing else is stored in it on purpose, and I try to keep it that way. Mixing in unrelated items makes it harder to find equipment in a hurry, and strong smells from other materials can bother the colonies.

**Orientation: south.** The main openings face south. This gives good light through the working day, and the area in front of the building warms early in the morning. It also means the loft can become too warm in high summer, so I open the doors early and avoid heavy work in the middle of the afternoon. In winter the same orientation is a real benefit, because the sun reaches well into the building and takes the edge off the cold.

**Size: large.** The loft is large, and I have never run out of room for equipment. The extra space lets me keep stacks of supers separate from frames and keep clean items away from used ones. It also means there is space to work on several boxes at the same time without anyone having to stand in a doorway. The cost of a large building is that it collects clutter if I let it, so I do a tidy at the end of every season.

**Year built: 2001.** The building is old enough to have settled and young enough to need little structural attention. Wear shows mostly on the floor and on the bench top, and I treat both as normal.

**Floor: ground level.** Everything is at ground level. There are no stairs between the door and the work areas, which makes it easy to move full boxes, and it makes the loft practical for anyone who cannot lift things above waist height. The downside is damp. Ground-level floors hold moisture in wet spells, so I keep wooden items off the floor on pallets or shelves.

### How I use the place

My routine follows the year. In the colder months the loft is mainly for repairs, cleaning and planning. In spring it becomes a staging area, with boxes and frames prepared and sorted before they go out. In summer it is busiest, and most of the handling and processing happens here. In autumn I clean, inspect and put things away in an order that will make sense next spring.

I keep the layout simple. Clean equipment is on the left as you enter, used equipment on the right, and the bench in the middle. If I ever change that, I will note it here first.

## Lessons

These are the things I have learned from working at the Fenkraeth loft since it became part of my routine. The loft is a large, ground-level building used for beekeeping, built in 2001, with its main openings facing south. Most of what follows comes from that combination of features, so I keep it in mind whenever something goes wrong.

**The south orientation is both a gift and a problem.** The loft gets sun for most of the day. In early spring this is wonderful, because the bees start flying sooner and the stored frames dry out quickly. In high summer the same sun makes the inside too warm by early afternoon. I learned to open the vents in the morning, before the heat builds, rather than waiting until the room already feels stuffy. Once the air inside is hot, it takes a long time to bring it down again.

**Ground level makes everything easier to carry, and easier to invade.** Because there are no stairs, I can move full supers on a trolley without lifting them. That alone has saved my back more than once. The downside is that mice, wasps and the occasional curious neighbour's dog can reach the door with no effort. I keep the door latched even when I am only gone for a few minutes, and I keep the mouse guards fitted on the hive entrances that are stored inside.

**Large size means clutter if I am not strict.** The space is big enough that I can always find somewhere to put one more box. Over time that turned into piles I could not get through. My rule now is that every item has one home, and anything that has no home leaves the building.

**The age of the building shows.** It was built in 2001, and the timber and the roof have had years of weather. Small gaps open up around the frames and under the eaves. I check these each season, because a gap that is too small for me to notice is quite big enough for a wasp.

Other lessons, kept short:

- Do not extract honey on a humid day. It takes more time and the result is thinner.
- Keep a clean, dry spare set of gloves by the door. Wet gloves are miserable and make me clumsy.
- Never leave wax scraps or sticky frames lying about uncovered. They bring robbing bees faster than anything else.
- Write down what I did after each visit, even if it was small. I always believe I will remember, and I never do.
- Light a smoker before I need it, not after the bees are already upset.
- If I am annoyed or in a hurry, I leave the work for another day. The bees notice, and I make mistakes.

**Labelling pays off.** Early on I stored equipment without labels and wasted a lot of time looking for things. Now every shelf and every crate has a plain label in thick marker. A new helper can find what they need without asking me, and that is the real test.

**Light matters.** The south windows give plenty of daylight, but the back of the room stays dim. I added a lamp there, and it made inspection of frames and sorting of tools far less tiring.

## Schedule

This is the rhythm I follow through the year. It is not strict, and the weather can move any of it by a week or two, but having a default stops me from forgetting things.

**Weekly during the active season**

- Walk through the loft and look for signs of pests, damp or damage.
- Check the vents and the door latch.
- Sweep the floor and wipe the work surfaces.
- Look at the water supply and refill it if needed.
- Check the stock of clean frames and make sure there are enough for the next round of inspections.

**Monthly**

- Go through the stored equipment and take out anything that needs repair.
- Check the mouse guards, the netting and any screens over the openings.
- Wash the tools I have used most: the hive tool, the brush and the uncapping fork.
- Review my notes and write down what needs doing next.

**Spring**

Spring is for waking the place up. I open the loft fully on a dry day, let the air move through, and take everything out that has been sitting over winter. I inspect the frames for mould and for wax moth damage. I replace the frames that look bad and clean the ones I keep. The southern sun helps here, since I can leave things on the ground outside for a few hours to dry and air.

**Summer**

Summer is the busy time. Vents open early, and I try to do the heavy work in the morning before the room warms up. Extraction takes place when the supers are properly capped and the weather is dry. I give myself a whole day for it and do not plan other jobs around it. The ground-level floor is helpful, because I can roll the supers straight in without lifting them.

**Autumn**

Autumn is for putting things away properly. I clean every piece of equipment that touched honey, let it dry fully, and store it in labelled crates. I look over the roof and the eaves for any gaps that need patching before the cold arrives. This is also when I check whether the door seals well, since mice start looking for shelter as the nights cool.

**Winter**

Winter is quiet. I visit the loft less often, but I do not stop altogether. A short visit every couple of weeks is enough to see if anything has moved, leaked or been chewed. I use the slow weeks for repairs, painting and making new frames, which I can do indoors without hurry.

**A simple yearly cycle**

- Early in the year: open up, air out, inspect and repair.
- Mid-year: work, extract and keep things tidy.
- Late in the year: clean, dry, store and seal.
- Deep winter: check lightly and build or fix equipment.

When I fall behind, I do not try to catch up on everything at once. I do the safety jobs first, then the ones that protect the equipment, and only after that the nice-to-have jobs.

## Safety

Safety at the loft comes down to a handful of habits. I keep them simple because I do not want to rely on remembering a long list when I am tired or in the middle of a job.

**Stings and allergies**

Anyone who works in the loft should know whether they react badly to stings. I never assume. If a helper is not sure, they stay out of the working area until we have talked about it. I keep a first-aid kit by the door, and it is checked at the start of each season. Anyone who has a known allergy should carry their own medication, and I make sure at least one other person knows where it is.

**Protective clothing**

- Wear a veil and a suit whenever bees are present in the room.
- Tuck the trouser legs into boots or tape them closed.
- Wear gloves, and replace them if they have holes.
- Avoid dark, fuzzy clothing, because bees react to it.

**Fire and smoke**

I use a smoker inside and near the loft, so fire is the risk I take most seriously. The smoker is lit outside, near the door, never in the middle of the room. Once I finish, I put it out fully and leave it on a bare, non-flammable surface until it is cold. I do not store smoker fuel near the south wall, where the sun warms the timber and the air can become hot. A fire extinguisher is kept near the door, and I check that I can reach it without moving anything.

**Heat**

Because the loft faces south, it can get very hot in summer. I do not work in the afternoon heat if I can avoid it. I drink water often and take breaks outside. If I start to feel dizzy or unwell, I stop and leave at once. It is never worth finishing a job in that state.

**Lifting and moving**

A full super is heavy. Even with ground-level access, I use the trolley instead of carrying whenever I can. I do not stack boxes higher than I can reach comfortably. Heavy crates stay on low shelves, and the lighter ones go higher up.

**Floors and walkways**

- Keep the floor clear of boxes, cables and hoses.
- Wipe up honey and water at once, because both make the floor slippery.
- Leave a clear path from the door to the work area and keep the door itself free of obstacles.

**Building condition**

The loft dates from 2001, so I look at the structure at least once a season. I check the roof, the beams and the window frames for rot, loose fittings or damage. If something looks unsafe, I stop using that part of the building until it is fixed. Electrical items are checked for worn cables, and I switch off anything I am not using.

**Working alone**

I try not to handle heavy or risky jobs on my own. When I must work alone, I tell someone when I will be there and when I expect to finish. I keep my phone within reach, not left in a bag across the room.

**Visitors and children**

Visitors are welcome, but they stay near the door unless I have given them proper protective gear and explained what to do. Children are never left unsupervised in the loft. Chemicals, sharp tools and hot equipment are kept out of reach.

**If something goes wrong**

If a swarm or a very agitated colony becomes a problem, I leave the room calmly, close the door, and wait. I do not swat or run. If someone has trouble breathing, swelling of the face or throat, or feels faint after a sting, I call emergency services immediately and do not wait to see if it passes.

## Supplies

Fenkraeth loft is a large loft on the ground level, built in 2001 and facing south. I use it for beekeeping, and everything below is stocked with that in mind. The south orientation gives plenty of light and warmth through the day, so supplies that dislike heat need to be kept toward the back wall, away from the glazing.

Because the loft is on the ground level, I can bring heavy items in without carrying them up stairs. That changes how I buy: I can order bulky things such as boxes of frames or sugar sacks in larger lots, and I do not need to worry about hauling them. The size of the space means I can keep spare equipment laid out instead of stacked in a corner, which makes it easier to see what is missing.

### Core stock

- **Hive bodies and supers.** Spare boxes stored flat on the lowest racks, stacked no higher than I can lift comfortably. Keep a few more than I think I need, because a good season fills them fast.
- **Frames and foundation.** Kept in closed crates so wax moths and dust stay out. Foundation sheets lie flat between sheets of card, never leaning, or they warp in the warm south light.
- **Smoker fuel.** Dry burlap, pine needles and untreated wood shavings, in a lidded metal bin close to the door. Never store fuel next to the window side.
- **Protective clothing.** Veils, jackets and gloves hang on the hooks by the entrance. Gloves are checked for holes at the start of each season and replaced when leather gets stiff.
- **Hive tools.** A small set kept in a tray on the workbench. I always want a spare in the loft and another in the field bag.
- **Feeding supplies.** Sugar, clean buckets, feeders and a long spoon. Syrup is mixed fresh and not stored for long.
- **Extraction equipment.** Uncapping knife, uncapping tray, extractor, strainers and settling buckets. All of it is washed and dried before going back on the shelf.
- **Jars and lids.** Clean jars in their original cartons, lids in a separate box so they stay dry.
- **Labels and notebook.** Blank labels, a marker and the paper log for each hive.

### Consumables that run out

Some items vanish faster than others. I keep a running tally on the inside of the cupboard door of what is low:

- smoker fuel
- sugar for feeding
- jar lids
- labels
- disposable gloves for cleaning work
- cleaning cloths and soda for washing equipment

### Treatments and medicines

Anything used for hive health lives in a closed cabinet on the cool side of the loft, well away from the south wall. I check the packaging for storage guidance each year and discard anything past its use date. I keep the notes about what was applied, and when, in the hive log rather than on the packaging.

### Storage rules

- Heavy items on low shelves, light items higher up.
- Wax and combs in sealed containers.
- Nothing sweet left open; it draws ants and wasps, and robbing bees if a door stays ajar.
- Metal tools wiped dry and lightly oiled before winter.
- Keep walkways clear. The loft is large, but a tripped step with a full super in my arms is the sort of accident I want to avoid.

## Checklist

I run through these lists at set points in the year. They are short on purpose so I actually use them. Because the loft faces south and sits at ground level, the most common problems are heat in summer, damp from the floor in winter, and pests coming in through the entrance.

### Before each work session

- Check the weather. I avoid opening hives in wind or rain.
- Fill the smoker fuel bin and make sure the smoker works.
- Put on protective clothing and check for gaps at the wrists and ankles.
- Lay out the hive tool, spare frames and a clean box.
- Have the notebook and pen ready to record what I see.
- Make sure the door can be closed behind me quickly.

### After each work session

- Clean and dry the hive tool.
- Empty the smoker and let it cool fully before storing it.
- Return frames and boxes to their racks.
- Write the notes in the log while I still remember the details.
- Sweep up wax scraps and crumbs so nothing attracts pests.
- Hang clothing so it can air out.

### Spring

- Sweep the floor and wipe down the shelves.
- Inspect every spare box and frame for mould, wax moth damage and mice.
- Replace worn frames and damaged boxes.
- Check the smoker bellows and the gloves.
- Restock sugar and fuel.
- Open the windows on a mild day to air the space before the busy season begins.

### Summer

- Watch the temperature near the south-facing windows. If the light is strong, shade the glass or move sensitive items back.
- Keep extraction gear washed and ready, because a honey flow can arrive quickly.
- Check the door seals so bees from outside do not follow the scent in.
- Keep water available for cleaning and a clean towel by the sink.
- Check the stored wax for any signs of pests every couple of weeks.

### Autumn

- Finish extraction and clean all equipment thoroughly.
- Store supers dry and sealed.
- Prepare feeding supplies for any colony that needs them.
- Reduce entrances and check for gaps where mice might enter the loft.
- Oil metal tools.
- Review the log and note what needs replacing before the next season.

### Winter

- Visit the loft on a regular basis to check for damp, especially along the ground-level floor.
- Make sure nothing stored directly on the floor is picking up moisture. Raise it on pallets or racks.
- Look for signs of mice or insects in stored equipment.
- Repair and paint boxes while the weather keeps me indoors.
- Build new frames and sort through the stock.
- Plan next season's purchases.

### Yearly review

Once a year I read through the whole list and ask a few plain questions:

- Is there anything in the loft I did not use this year?
- Is anything damaged beyond repair?
- Did any shelf or rack cause trouble?
- Was the space the right size for my work, or did it feel crowded or empty?
- What would make the work faster or safer next year?

## Costs

I do not record exact prices here, since they change and I keep receipts separately. This section is about where the money goes and how I think about it, so I can plan ahead and avoid surprises.

### Where the money goes

- **Equipment replacement.** Boxes, frames and protective clothing wear out. Wood suffers from damp and the sun. I budget for a share of the stock to be replaced each year rather than all at once.
- **Consumables.** Sugar, fuel, jars, lids and labels are the regular, small purchases. Individually they cost little, but across a season they add up.
- **Treatments.** Medicines and hive health products are a fixed part of the yearly spend. I buy only what the season needs and do not stockpile.
- **Maintenance of the loft itself.** The loft was built in 2001, so it has some age. Seals, hinges, paint and floor protection need attention from time to time.
- **Utilities.** Light, water for cleaning and some heating for winter work. The south orientation helps keep heating costs low, though it can mean extra effort to keep the space cool in hot weather.
- **Tools and machinery.** The extractor and uncapping equipment were the largest single purchases. They last for years if cleaned well, so I treat them as long-term investments.

### What keeps costs down

- Buying consumables in larger lots, which the large size of the loft makes easy to store.
- Keeping everything dry and clean so wood and wax last longer.
- Repairing frames and boxes before they fail completely.
- Using the ground-level floor to receive deliveries directly, avoiding any need for extra help with carrying.
- Noting in the log what I actually used, so I stop buying things that sit on the shelf.

### What tends to cost more than expected

- Damp damage to stored boxes in winter if they are left on the floor.
- Heat damage to foundation and wax near the south windows in summer.
- Replacing gloves and veils that I put off checking.
- Rushed purchases in the middle of a honey flow, when I realise I have run out of jars or lids.
- Pest damage from stored combs left unsealed.

### Budget approach

I split the yearly spending into three groups so I can see at a glance where the balance sits:

- **Fixed:** treatments, utilities and basic upkeep of the loft.
- **Variable:** sugar, fuel, jars, lids and labels, which rise and fall with the size of the season.
- **Occasional:** large equipment, major repairs and any change to the layout of the space.

At the end of each year I compare what I expected to spend with what I actually spent, and write a short note of the differences. If one group keeps going over, I look for the cause rather than just raising the budget. Often the answer is a simple fix, such as a better shelf, a sealed container or a more careful look at the checklist above.

### Notes for the future

The loft is large enough that I could expand my beekeeping without needing another building. Before I do, I want to be sure that storage, extraction capacity and the checklist routines can handle more work. Any growth should be matched by a rise in the supplies stock and a realistic look at the costs above, so the loft stays practical and does not become a place where equipment simply piles up.

## Ideas

These are things I want to try at Fenkraeth loft, a large ground level loft built in 2001 and facing south. None of them are urgent. I keep them here so I can pick one up when the season allows.

- **Split the floor into zones.** The loft is large, and right now the work areas run into each other. A clear line between the extraction zone, the storage zone and the equipment zone would cut down on carrying things back and forth. Floor tape or a low painted strip would do for a start.
- **Use the south light on purpose.** Because the loft faces south, the wall opposite the main opening gets steady light for most of the day. A bench along the brightest stretch would be good for frame inspection, wax work and label writing. The darker back area is better for storing finished jars.
- **Add a washable surface near the door.** Being at ground level means I can roll things straight in, so the entrance gets the most traffic. A wipe-clean mat or sheet of sealed board there would save time on cleanup.
- **Build a simple frame rack.** Spare frames and supers currently lean against whatever is near. A rack with open sides, built to a fixed height, would keep them off the floor and let air move around them.
- **Keep a paper logbook by the entrance.** A clipboard on a hook for date, task and anything odd. It is quicker than finding my phone with sticky hands, and I can copy entries into notes later.
- **Try a tidy-up routine at season end.** Twenty minutes of sorting, a quick sweep, and a look at the roof line before winter. I could write it as a short checklist and pin it up.

A few longer thoughts:

The size of the loft is both its best and worst feature. There is room for everything, which means things drift and pile up. If I commit to the zone idea, I should also commit to giving each zone a clear label, otherwise it will go back to being a general heap within a month.

I also want to think about whether the floor should stay as it is. Ground level is convenient, but it also means any damp from the ground is my problem. A raised pallet deck in the storage zone is cheap and can be removed if it does not work out.

## Observations

What follows is what I have actually noticed while working in the loft, not what I expect or hope for.

**Light and warmth.** The south orientation is the most obvious thing about the place. In the morning the light comes in low and stays on one side. By midday most of the loft is bright. The warmth follows the light, so the sunny side is noticeably more comfortable in cool months. In summer the same effect makes the front part stuffy by afternoon, and I tend to do heavy tasks early.

**Space.** The large size shows when more than one job is going on. Two people can work without bumping into each other, and I can leave a job half done in one corner and start another elsewhere. The downside is distance. A walk from the door to the far end adds up over a long day, and I forget tools at the wrong end more often than I would like.

**Access.** Ground level makes everything easier to move. Heavy boxes, full supers and equipment come in without lifting up steps. I notice this most at the end of a long day, when I would otherwise be tempted to leave things outside. It also means the loft is easy for visitors and for anyone with limited mobility to enter, which is not true of many places I have kept notes about.

**Age of the building.** Built in 2001, the loft is old enough to show wear but not so old that it feels fragile. Door edges, thresholds and the lower part of the walls show the most use. Nothing has failed, but I keep finding small things that need a touch of attention: a loose hinge, a worn seal, a patch of flaking paint.

**Smell and air.** On a warm day the loft smells of wax and honey, which is pleasant and mostly useful, since a change in smell tells me something has been left open or has spilled. After a damp spell the smell changes to something flatter, and that is my cue to open it up and let it breathe.

**Noise and activity.** When the door is open on a sunny day, the area outside gets busy. I try not to schedule noisy work, such as moving heavy gear, for the hours when activity is highest.

**Patterns I keep noticing:**

- Things left on the floor near the door are the first to get damp or dusty.
- The brightest bench area gets cluttered fastest because it is the most pleasant place to work.
- The far end of the loft is the least visited, so problems there are found last.
- Tasks go faster in the morning, when the light is good and the air is cooler.

I should check the far end more often. It is easy to assume it is fine because I do not see it every day, and that assumption has been wrong before.

## Risks

This section is a plain list of what could go wrong at Fenkraeth loft and what I would do about each. I am not trying to be gloomy. Writing it down makes it easier to spot trouble early.

**Damp from the ground.** The loft sits at ground level, so moisture can come up through the floor or in along the base of the walls. Stored items on the floor are most at risk. Keeping things on pallets or shelves, and checking the lower walls after wet weather, is the simplest defence. If I see staining, a musty smell or warped boards, I treat it as a warning, not a cosmetic issue.

**Overheating.** The south-facing opening means strong sun for much of the day. In hot weather the front of the loft can get too warm for wax, stored combs or finished jars. Shade, ventilation and moving sensitive items toward the back are the main answers. I should not leave wax work or full boxes in direct sun.

**Age and wear.** The loft was built in 2001, so seals, hinges, roof fittings and door frames are all past their first years. Wear tends to build quietly. A small gap can let in water, pests or draughts long before I would call it a problem.

**Pests.** Any place with honey, wax and frames attracts wasps, ants, mice and moths. The large size gives them more places to hide. Gaps around the door and the base of the walls are the usual entry points.

**Clutter and falls.** A big open floor invites piles. Piles block paths, hide spills and make it easy to trip with a heavy load in my arms. Sticky floors make it worse.

**Fire and heat sources.** Wax is flammable, and the loft has plenty of dry wood and paper. Any heater, lamp or melting equipment needs space around it and should never be left running unattended.

**Isolation.** Because the far end is the least visited, a problem there could go unnoticed for a long time. If I am working alone, someone should know where I am.

Things I would check regularly:

- The lower walls and floor edge after rain.
- The door seals and hinges at the start and end of each season.
- The roof line and any visible gaps, before winter.
- The far end of the loft, even when nothing seems wrong.
- Any equipment that produces heat, before and after use.

None of these risks is severe on its own. The real danger is that several small things go unchecked at once, and what would have been a quick fix becomes a larger repair. A short regular walk-through, done with attention, is the best protection I have.

## Problems

These are the problems I have run into at Fenkraeth loft, a large, south-facing, ground-level loft built in 2001 and used for beekeeping. I keep them here so I can check the list before each season instead of rediscovering them the hard way.

### Heat from the south wall

Because the loft faces south, the long wall takes the sun for most of the day. In midsummer the air near that wall gets uncomfortably warm, and the effects are easy to see:

- Wax in stored frames softens and sags if they sit near the wall.
- Capped honey in supers waiting for extraction becomes runnier, which is fine for extracting but makes the boxes messy to move.
- Any comb with old brood in it attracts wax moth faster when it is warm.
- Working in there in the afternoon is tiring, and I make mistakes when I am hot.

What I do about it: I keep frames and supers on the shaded side, as far from the south wall as the room allows. I do the heavy handling in the morning. I hang a light sheet over the windows on the hottest days. It is not elegant, but it lowers the temperature enough to matter.

### Damp at floor level

Since the loft is on the ground floor, damp is a real nuisance. In wet autumns the floor near the door feels cool and slightly clammy, and I have seen the following:

- Cardboard boxes left directly on the floor go soft at the bottom within a few weeks.
- Metal tools, especially the hive tools and uncapping knives, get light rust spots if they are not wiped and dried.
- Stored drawn comb can pick up mould if the boxes are closed tight and left on the floor.

What I do about it: nothing goes directly on the floor any more. Everything sits on pallets or on shelves at least a hand's width above the ground. I use plastic crates instead of cardboard for anything that stays more than a month. I check the corners near the door once a month during autumn and winter.

### Pests

The loft is large, and a large room gives pests plenty of places to hide. The usual visitors are:

- **Wax moth.** The main enemy of stored comb. Larvae tunnel through the wax and leave webbing. Warm weather makes it worse, so it connects to the heat problem above.
- **Mice.** They get in during autumn looking for shelter, and they chew drawn comb and nest in empty boxes. They squeeze through very small gaps.
- **Ants.** They come in when honey is spilled, and a single drip is enough to start a trail.
- **Wasps.** Late in summer they enter through any open window or door when I am extracting, and they are drawn to the smell of honey.

What I do about it: I keep stored comb in stacks sealed with a tight lid and a strip of tape at the joint. I check stacks every few weeks in warm months. I keep the door closed while extracting and wipe up spills straight away. For mice, I walk the walls each October and block any gap I find, and I keep the entrance threshold in good repair.

### Ventilation

The room needs air to move, but I also need to keep bees and wasps out. That is a balance I have not fully solved. If the windows are open, robbing insects come in. If they are shut, the room gets stuffy and humid, especially after extraction when wet equipment is drying.

What I do about it: I fitted fine mesh over the window openings so I can leave them open for part of the day. The mesh needs cleaning, since dust and wax bits clog it and reduce airflow. I check it at the start of each season.

### Light and glare

South-facing windows bring a lot of light, and that is mostly good, but low winter sun can cause glare across the work table. It makes it hard to see into cells when I am checking comb for damage or disease. A simple fabric shade over the table helps, and I move the table slightly when the angle of the sun changes.

### Sticky floors and cleaning

Honey and propolis get everywhere. A sticky floor is not only unpleasant, it traps dirt and draws ants. The floor needs a wipe with warm water after every extraction session. Cold water does not shift wax or propolis, so I keep a kettle in the loft for this reason. I also keep a scraper by the door for the worst patches.

### Things I keep forgetting

- Check the door seal before the first cold nights.
- Wipe and dry the tools before putting them away.
- Replace any cardboard with crates before winter.
- Look behind the shelves at the back wall, because that is where mice and moth start.
- Clean the window mesh before the season starts, not halfway through it.

### Priorities if time is short

If I only have an hour, I do these in order: first, check stored comb for moth; second, look for mouse gaps and damp near the door; third, wipe the floor and tools. Everything else can wait for the next visit.

## Dimensions

Fenkraeth loft is a large loft, and the size matters for how I use it. The main facts are in the list below.

- Kind: loft
- Area of use: beekeeping
- Orientation: south
- Size: large
- Year built: 2001
- Floor: ground level
- Floor area of Fenkraeth loft: 26.32 m²

### What the floor area means in practice

The floor area of 26.32 m² is enough to hold everything I need for a normal season without it feeling cramped, but it fills up quickly in late summer. Extraction brings in full supers, the extractor, buckets, a settling tank and jars, and at that point I have to plan where each thing goes before I start.

I think of the space in zones, roughly like this:

- **Door end:** the working area, with the uncapping table and extractor, because it is easiest to carry boxes in and honey out from here.
- **Middle:** pallets with stacked supers and empty boxes, with a walking path kept clear on one side.
- **Back wall:** shelves for frames, tools and spare parts, which I use less often, and where I check for pests.
- **Shaded side:** stored comb and anything sensitive to heat, kept away from the south wall.

### Moving around

Even in a large room, a path is easy to block. I keep a clear route from the door to the extractor and another from the extractor to the storage end. When carrying a full super, I need enough space to turn without hitting anything, so I do not leave boxes in the walkway, even for a few minutes. A dropped super of honey is a long cleanup.

### Ground level and access

Since the loft is at ground level, there are no stairs. This makes it far easier to bring in heavy boxes, hive parts and sacks of sugar, and I can use a trolley for most loads. The trade-off is the damp described earlier, but for heavy work I would not swap the access for a drier upper floor.

### Fitting in new equipment

Before buying anything large, I measure the space it would take and think about where it would stand and where I would stand to use it. A bigger extractor, for instance, needs room all around for the lid, for the person using it, and for buckets underneath. If it does not fit without blocking the main path, I either rearrange or do not buy it.

### Notes for the future

- Keep at least one clear walking route at all times.
- Leave a gap between stacks and the south wall.
- Leave a gap between stacks and the back wall so I can look behind them.
- Keep the door end free of storage in extraction season.
- Review the layout each winter, when the loft is quiet and rearranging is easy.

The building dates from 2001, and while it has stood up well, I treat its age as a reason to inspect rather than assume. A walk around the walls, the floor and the roof line each year is part of how I look after the place, and it fits easily into the checks I already make for pests and damp.
