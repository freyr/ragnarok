---
type: reference
status: active
project: reference
area: beekeeping
description: "Reference about Saerkol shed."
---

# Saerkol shed

## Costs

The Saerkol shed is a small shed used for beekeeping. It is a below-ground shed with a south orientation, and it was built in 2015. Because it is small and dug into the ground, the costs are mostly about keeping it dry and usable, not about its size. I keep this section as a plain list of the kinds of money I spend on it, without exact prices, since prices change and I do not want stale numbers in my notes.

The main cost groups are these:

- Drainage materials: gravel, pipe and membrane for the ditch around the entrance. This is the largest ongoing cost because water is the main enemy of a shed below ground.
- Timber and treatment: boards for shelving, the door frame and the steps. Timber in a damp place rots, so I replace pieces from time to time and treat the new ones.
- Lighting and power: a small lamp and a battery pack. I do not run mains power into the shed.
- Storage containers: lidded tubs and food-grade buckets for honey, wax and spare frames. Sealed containers are cheaper than losing stock to damp or mice.
- Tools and consumables: smoker fuel, gloves, hive tools, cleaning supplies and a few spare veils.
- Lease costs: the yearly payment for the ground the shed sits on. See the Admin section for the reference.

Costs I try to avoid:

- Buying large equipment that will not fit through the door.
- Buying cheap metal fittings that rust in a few months in the damp air.
- Emergency repairs after heavy rain, which cost more than regular small fixes.

A rule I follow: when I think about spending money on the shed, I ask whether it keeps the space dry, safe or tidy. If it does none of those, it can wait.

## Problems

The problems with this shed come mainly from its position under the ground. The floor is below ground, so everything that goes wrong tends to involve water, air or access.

Known problems:

- Damp. The walls and floor hold moisture, especially after a long wet spell. Cardboard, paper labels and untreated wood suffer first.
- Poor air movement. The shed is small and sunk into the ground, so stale air sits there. It smells of wax and earth, which I like, but it also means mould can start.
- Steps. The way down is steep and can be slippery when wet or covered with leaves.
- Light. Even with the south orientation, the inside is dim. I need a lamp for most jobs.
- Pests. Mice and spiders like the shed. Wax moth is a worry for stored combs.
- Limited space. A small shed fills quickly. In the busy season I have trouble moving around with a full box of frames.
- Carrying. Lifting heavy supers up the steps is hard on the back.

None of these has ever been bad enough to make me abandon the shed, but each one needs attention. I handle most of them by regular checks, covered in the Checklist and Maintenance sections.

## Observations

These are things I have noticed over the years of using the shed.

- The south orientation helps with the entrance. The door area gets sun for much of the day, so the top of the steps dries faster than the rest of the site. The warmth does not go far down, though.
- Inside, the temperature stays steadier than in any shed above ground. It is cooler in summer and does not freeze as hard in winter. This is good for storing wax and drawn comb.
- Humidity is the opposite: it is higher than I would like all year, and it rises after rain.
- The floor is the coolest and dampest part. Anything stored directly on it picks up moisture, so I keep everything on pallets or shelves.
- The upper shelves, nearest the door, are the driest. I keep the most sensitive things there.
- Sound is muffled. It is a quiet place to work, and bees do not seem to follow me in much.
- Condensation forms on metal tools if I leave them out overnight.
- After a heavy storm, the first sign of trouble is a dark line low on the wall near the entrance.
- Wax moth shows up in warmer months if combs are left uncovered.
- Cobwebs in the corners return quickly, but they seem harmless.

I record these in my own words so I can compare one season with another. If something changes, I want to notice it.

## Risks

The risks are not dramatic, but they are real, and I list them so I do not forget them.

- Flooding. A below-ground floor means that heavy rain or a blocked drain can bring water in. This is the biggest risk to stored equipment.
- Structural movement. Soil around a buried structure can shift. I watch for new cracks, bowing walls or a door that starts to stick.
- Rot. Wooden parts in damp soil weaken over time. The shed was built in 2015, so some parts are now old.
- Mould. Damp stored boxes can grow mould, which spoils frames and can make the air unpleasant.
- Pest damage. Wax moth and mice can ruin stored combs and boxes in a single season.
- Falls. The steps and the low light make falls more likely than in an ordinary shed.
- Lost stock. Honey or wax stored in a damp or warm place can spoil.
- Lease problems. If the lease is not renewed or its terms change, I could lose access to the shed. The reference is in the Admin section.
- Theft or vandalism. The shed is small and hidden, which helps, but a lock is still needed.

For each risk, my main protection is regular inspection. Most of these can be handled cheaply if I catch them early and become expensive if I do not.

## Safety

Safety in this shed is mostly about the steps, the air and the stored items.

Getting in and out:

- Go down the steps slowly, facing forward in dry weather and with a hand on the rail when wet.
- Clear leaves and mud from the steps before using them.
- Never carry a load that blocks my view of my feet.
- Keep the doorway clear so I can leave quickly.

Working inside:

- Always bring a light. Do not rely on daylight.
- Open the door and let the air change before staying for a long job.
- Do not light a smoker inside the shed. Smoke in a small enclosed space is dangerous and the fuel can smoulder unnoticed.
- Store smoker fuel in a metal tin, away from the door and any heat.
- Keep a first-aid kit and a bee-sting kit where I can reach them. Anyone who is allergic to stings should not work alone.
- Wear gloves when handling damp or rotted wood.

Stored items:

- Keep chemicals, cleaners and any treatments in labelled, closed containers on a high shelf.
- Keep heavy boxes low on the shelves, but off the wet floor.
- Do not stack supers higher than I can safely lift down.

Before leaving:

- Check that no smoker, lamp or battery is left on.
- Lock the door.
- Tell someone if I will be working there for a long time, especially in bad weather.

## Background

The Saerkol shed is a small shed built in 2015 for beekeeping. It is a below-ground shed, which means its floor sits under the level of the surrounding soil. Its orientation is south, so the entrance faces that way.

I chose a below-ground shed for several reasons. A buried space keeps a steadier temperature, which suits stored wax and comb. It is also discreet in the landscape and protected from wind. The south-facing entrance was meant to give some light and warmth at the doorway and help the steps dry.

Here is a short summary of the properties of the shed, written out so I can find them quickly:

- Name: Saerkol shed
- Kind: shed
- Area: beekeeping
- Orientation: south
- Size: small
- Year built: 2015
- Floor: below ground

The shed holds the equipment I need around the hives: spare boxes, frames, feeders, tools, protective clothing and containers for honey and wax. It is not a place for processing honey on a big scale. I do the messy work elsewhere and use the shed as a store and a quiet workspace.

The small size has shaped how I work. I cannot keep much, so I plan the year around what I will need and bring in only that. The below-ground floor has shaped how I look after the building: water control comes first, then ventilation, then everything else.

## Ideas

These are things I might try, in no particular order. None is promised.

- Add a small passive vent, with a screen against insects and mice, to improve air movement.
- Install a simple moisture meter and write down readings each month, so I can see patterns instead of guessing.
- Build a raised slatted floor over the existing floor, so boxes never touch the damp surface.
- Add a second rail on the steps, and non-slip strips on each tread.
- Put a small gutter or a shallow channel above the entrance to direct rainwater away.
- Paint the inner walls with a breathable mineral coating instead of ordinary paint.
- Set up a hanging system for frames so they are off the shelves and have air around them.
- Fit a better lock and a simple latch that can be used with gloves.
- Use a solar-charged lamp to avoid replacing batteries.
- Make a labelled map of the shelves, so I know where everything is without moving things.
- Keep a small tub of dry silica-type absorber for the most sensitive items.
- Make a folding trolley or sling that helps move heavy supers up the steps.

I will choose among these based on what the observations tell me. Drainage and air come first, comfort last.

## Open questions

There are a few things I still do not know about the shed.

- How high does the water table rise in the wettest season, and does it ever get close to the floor?
- Is the damp mainly coming through the walls, up through the floor, or in through the door?
- Would a vent really help, or would it only bring in more humid air in summer?
- How long will the oldest timber last? It has been in the ground since 2015.
- Is the drainage around the entrance still working as well as when it was built?
- Does the south orientation make any real difference to how fast the steps dry, or is it only my impression?
- Would a dehumidifier be worth the power it uses, given that I have no mains supply?
- Are the wax moth problems linked to the humidity, the warmth, or just how I store the combs?
- If the lease changes, what are my options for moving the shed or its contents?
- Should I keep a written record of every repair, so I can see which parts fail first?

I will update this section when I find answers, and move the answers to Observations or Lessons.

## Admin

This section holds the paperwork side of the shed.

- Lease reference of Saerkol shed: LR-285740

Notes on the lease and other admin:

- The lease covers the ground that the shed occupies. I keep the paper copy with my beekeeping records, and a photo of it on my phone.
- I need to check the renewal period well before it ends, so I am not caught out.
- Any change to the shed, such as digging, new drainage or a larger entrance, should be checked against the lease terms first.
- I keep receipts for materials and repairs in one folder, so I can see what the shed has cost over time.
- Insurance for the equipment stored inside should be reviewed each year. Damp and flooding may not be covered in the same way as theft or fire, so I need to read the details.
- Beekeeping registration and any local requirements are kept separately in my main beekeeping notes, not here.
- Contact details for the landowner or the lease holder are kept in my address book.

When I speak to anyone about the lease, I give the reference exactly as written above, so there is no confusion.

## History

The shed was built in 2015. It was planned as a small, practical store for beekeeping equipment, and the decision to put the floor below ground was made early.

A rough timeline, without exact dates:

- 2015: The shed was built. The pit was dug, the walls were made, the entrance was set facing south and the first shelves went in.
- The first seasons: I learned how much water the site could take. I made small changes to the entrance and the drainage.
- Later years: I added better shelving, moved the most sensitive items to the upper shelves and began using pallets for anything on the floor.
- Some years after the build: I replaced some of the older timber near the steps, where rot had started.
- Recent years: I began keeping regular notes on damp, pests and repairs, which is how this note came about.

Over the years, the shed has gone from a rough store to a tidier and better-organised working space. It has never been large, and I do not plan to enlarge it. The design has proven sensible, though it needs more care than a shed above ground.

I plan to keep adding to this section when something important changes, such as a major repair, a flood, or a change in how I use the space.

## Lessons

These are the lessons I have learned from using the shed.

- Water control is the first job. Everything else depends on it.
- Never store anything directly on the floor. Use pallets, shelves or racks.
- Sealed containers are worth the cost. Open boxes pick up damp and smells very quickly.
- Check after every heavy rain. A quick look at the low part of the wall can save a lot of trouble.
- Keep the steps clear. Most of the danger in this shed is on the way in and out.
- Do not bring in more than I need. A small shed works best when it is not crowded.
- Treat new timber before it goes in. Untreated wood does not last in a damp place.
- Cover combs. Wax moth finds uncovered combs very fast in the warm months.
- Write things down. My memory of what happened last season is never as good as a short note.
- Choose plain materials. Simple, replaceable parts work better than clever ones.
- Ventilate before working. A few minutes of open door makes the air better and the work more pleasant.
- Small regular jobs beat big repairs. A monthly tidy costs less than a yearly rescue.

## References

These are the sources I use when I think about the shed. They are my own notes and general knowledge, not outside links.

- My main beekeeping notes, which cover hive management, the seasonal calendar and equipment lists.
- My own repair log for the shed, where I note each fix and the reason for it.
- The lease paperwork, kept with my records. The reference is in the Admin section.
- My photographs of the walls, the steps and the drainage, taken at different times of year so I can compare them.
- Conversations with other beekeepers about storing equipment in damp places.
- General guidance on building and maintaining below-ground structures, especially on drainage, ventilation and damp control.
- General beekeeping guidance on storing comb and preventing wax moth.
- My own seasonal observations, written in the Observations section above.

If I find a useful book, article or advice from someone I trust, I will add a short description here so I can find it again.

## Checklist

I use this checklist when I visit the shed. It does not take long once it becomes a habit.

On arrival:

- [ ] Look at the steps for leaves, mud, ice or loose boards.
- [ ] Check the drain around the entrance for blockage.
- [ ] Open the door and let the air change.
- [ ] Look for any sign of water on the floor or low on the walls.

Inside:

- [ ] Check the shelves and pallets for damp or mould.
- [ ] Look for droppings or chewed material.
- [ ] Look at stored combs for signs of wax moth.
- [ ] Make sure containers are closed and labelled.
- [ ] Check that the lamp and batteries work.
- [ ] Check that the first-aid and sting kits are in place.

Before leaving:

- [ ] Put tools back in their places.
- [ ] Remove rubbish and old wax.
- [ ] Make sure no smoker or flame is left.
- [ ] Close and lock the door.
- [ ] Write any notes in the repair log.

Each season:

- [ ] Review the lease paperwork and renewal timing.
- [ ] Inspect timber for rot.
- [ ] Re-treat any exposed wood.
- [ ] Clean the walls and corners.

## Maintenance

Maintenance of a small below-ground shed is mostly about keeping it dry, clean and safe. I split the jobs by how often they come up.

Monthly:

- Clear the steps and entrance of leaves and debris.
- Check the drain and the ditch around the entrance.
- Wipe down shelves and look for mould.
- Rotate stored items so nothing sits unnoticed in a corner.
- Check the lamp and replace or recharge batteries.

After heavy rain:

- Look at the low part of the wall near the entrance for dark lines.
- Check the floor for standing water.
- Move any damp items to a drier place and let the air in.

Each season:

- Inspect the timber, the door and the frame for rot or movement.
- Re-treat exposed wood where needed.
- Clean out cobwebs, dust and old wax.
- Check the lock and hinges, and oil them if they are stiff.
- Look at the walls for new cracks.
- Check the steps and rail for looseness.

Each year:

- Review the lease and insurance.
- Replace worn shelving boards.
- Refresh the gravel or membrane in the drainage if it has settled or clogged.
- Go through all stored equipment and discard anything damaged beyond use.
- Update this note with anything I have learned.

Principles I follow:

- Fix small problems early.
- Use durable, simple materials.
- Keep the shed uncluttered, so that damp and pests have fewer places to hide.
- Record each repair, so I can see which parts fail first.

A well-kept shed of this kind, built in 2015, can last for many more years, provided the water is kept out and the timber stays sound.
