---
type: plan
status: active
project: zulvae-repair
area: beekeeping
description: "Plan about Perkgon solar charger."
---

# Perkgon solar charger plan

## Maintenance

The Perkgon solar charger is a grey solar charger used for beekeeping. It sits in the shed and has been there since 2015. Despite the name, its energy source is mains, so it does not depend on sun on the roof. That makes it easier to plan around, but I still treat it like the rest of the shed gear.

Plan for upkeep:

- Wipe the grey casing down at the start of each season. Dust and wax bits collect fast in the shed.
- Check the mains lead and plug for cracks or heat marks. After this many years, the cable is the first thing I would expect to fail.
- Look at the connections for corrosion, especially after damp weeks.
- Keep the shelf around it clear. When I redo the layout, I will follow the notes in [[Solsas shed plan]].
- Write down anything odd in the same place as my other sensor notes, such as [[Brindkrerk level sensor]], [[Susrion level sensor]] and [[Drithdas level sensor]].

If the charger needs replacing, I will ask [[Lenkaenpun Nigli]] for advice before buying anything. The logging side could be compared with [[Tritapel data logger study]], and I can reuse the checklist style from [[Krioskus kiln controller notes 2019]]. The tool-care habits in [[Lisdrior band saw study]] are also a good model for a short, regular routine.

## Measurements

I want a simple record of how the charger behaves, so I can spot changes over time.

- Measured power draw of Perkgon solar charger: 140.21 W

Plan for measuring:

1. Take the reading with the same meter each time.
2. Measure with the same load connected.
3. Note the room conditions and the season beside the reading.
4. Compare the new figure with the one above before deciding on any repair.

If the draw rises clearly above the value, I will inspect the charger before the next beekeeping season.
