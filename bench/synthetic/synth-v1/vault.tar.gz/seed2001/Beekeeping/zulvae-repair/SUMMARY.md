---
type: summary
status: active
project: zulvae-repair
area: beekeeping
description: "Summary about Zulvae repair."
---

# Summary of Zulvae repair

## Schedule

Zulvae repair is a repair project in the beekeeping area. It started in 2024, in the winter season, and the carpenter leads it. The work sits in the winter slot because the hives are quiet then and nothing has to be moved while the bees are active.

Current stage: the work is under way, past planning but not finished. The frame of the old stand has been taken apart and checked, and the damaged boards are sorted from the sound ones. The sound boards are kept for reuse.

Done so far:

- Stand dismantled and every part checked for rot
- Damaged boards set aside and measured
- Workshop space cleared for the repair
- Tools and glue gathered

Still open:

- Replacement timber has not been chosen
- Roof joint needs a closer look
- Reassembly day has not been fixed

A short working log I keep next to the project:

```text
project: Zulvae repair
goal: repair
area: beekeeping
season: winter
lead: carpenter
stage: in progress
```

## Decisions

The go decision for Zulvae repair was made on 2018-02-21. That is the date I treat as the formal green light, even though the hands-on work only began in 2024. I keep the date here so I remember the repair was approved well before the carpenter picked it up.

Choices made so far:

- Repair the existing stand instead of building a new one
- Reuse every board that passes the rot check
- Keep the carpenter as the single lead, so there is one person to ask
- Do the work in winter, while the colonies are at rest

Choices still pending are the timber for the replacement boards and the way the roof joint will be fixed. I will write those down here as soon as the carpenter gives an answer, so this note stays the one place where the reasons are kept.

## Next action

The next action of Zulvae repair is NX-0515.

Before I start it, I want the carpenter to confirm the timber choice, because the rest depends on it. Once that is settled, I can fix a reassembly day and finish the roof joint check. After that this summary should be updated with the new stage and any closed open points.
