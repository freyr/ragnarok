---
type: plan
status: active
project: zulvae-repair
area: beekeeping
---

# Starklil level sensor plan

## Background

The Starklil level sensor is a black level sensor that I installed at the pond in 2021. It belongs to my beekeeping notes because the pond is the water source for the apiary, and I want to know when the level drops before the bees start looking elsewhere. It runs on solar power, so there is no cable back to the house and no battery swap on a schedule.

This plan covers how I look after the sensor, what I have learned from it, what I measure, what I keep in stock, and what I still need to settle. It is a working plan, not a manual. I add to it when something changes.

The basic properties, so I do not have to look them up again:

- Kind: level sensor
- Area: beekeeping
- Color: black
- Energy source: solar
- Year installed: 2021
- Location: pond

I picked black partly because it blends in with the reeds and partly because I did not want it to catch the eye of anyone walking past. The black housing does get warm in summer, which I come back to under Lessons.

The idea for the sensor came from reading [[Laga level sensor notes]], where I wrote down how a similar unit behaved on a different water body. I borrowed the mounting idea from there and changed the height of the arm to suit the shallow edge of the pond.

## Maintenance

I keep maintenance light, because anything that needs weekly attention will not get it in the busy season. The plan is a short routine at fixed points in the year.

**Spring**

- Wipe the solar panel with a soft damp cloth to remove winter film and pollen.
- Check the mounting arm for loosening after frost.
- Look at the cable gland and the seal for cracks.
- Read the level against a ruler stick at the edge and compare it with what the sensor reports.

**Summer**

- Check the panel for algae splash, bird droppings and shade from new growth.
- Trim reeds that have grown in front of the panel.
- Look inside the housing for condensation after a hot spell.

**Autumn**

- Clear fallen leaves from the panel and the base.
- Do a last comparison against the ruler stick before the first frost.
- Note the level in the log so I have a baseline for winter.

**Winter**

- Leave the sensor alone unless the ice is thick enough to push on the arm.
- If the pond freezes hard, check in the thaw that the arm has not shifted.

When I need to carry the sensor back to the workshop, I keep the spare brackets and tools in the [[Brethgleth loft]]. Cutting any new bracket stock is done on the saw I described in [[Tronas band saw 2020]], and I try to do all cutting in one session so I do not keep setting it up.

## Lessons

Several things have become clear since 2021.

1. **Solar was the right choice.** The sensor has never been dead for long. The only gaps came from shade, not from the panel failing.
2. **Black gets hot.** In midsummer the housing is uncomfortable to touch. So far it has not caused trouble, but I watch the readings in the afternoon for odd jumps.
3. **Reeds are the real enemy.** They shade the panel and also disturb the reading near the edge. Trimming matters more than any other task.
4. **Compare by hand now and then.** A ruler stick costs almost nothing and tells me whether the sensor drifted.
5. **Write down what I changed.** Twice I moved the arm and then could not remember by how much. Now every change goes in the log.

I also learned from [[Zaedith Gerknand tests]] that readings taken right after rain are noisy, because ripples and runoff stir the surface. I wait a while after a downpour before I trust a number.

From [[Raemaertur Truthkon notes]] I took the habit of keeping a short checklist at the site itself, so I do not have to remember the routine. The checklist is laminated and tied to the fence post.

## Measurements

The numbers I track are listed below. I keep them short so I will actually record them.

| Item | What I record | How often |
| --- | --- | --- |
| Pond level | Sensor reading and ruler stick reading | Each season |
| Panel condition | Clean, dusty or shaded | Each visit |
| Housing | Dry or condensation | Summer visits |
| Power draw | Measured at the bench | When I test |
| Arm position | Height mark on the post | After any change |

The measured power draw of the Starklil level sensor is 849.88 W. I wrote that down from a bench test, and it looks very high for a small sensor, so I treat it as a figure to double check rather than a number to rely on. Before I plan any change to the panel size around it, I want to repeat the test and see whether the meter or the setup was at fault.

Other notes on measuring:

- Take the sensor reading and the ruler reading at the same time of day.
- Avoid readings right after rain or strong wind.
- Record the weather in a few words next to each entry.

## Supplies

I keep a small stock so a failed part does not leave the pond unwatched for weeks.

- Soft cloths and a small bottle of clean water for the panel
- Spare stainless screws and washers for the arm
- A tube of sealant for the cable gland
- Cable ties in black, to match the housing
- A spare mounting bracket, stored in the [[Brethgleth loft]]
- A waterproof notebook and pencil for the site log
- A ruler stick marked at fixed intervals

For anything I cannot make myself, I have had good dealings with [[Miokulgae Garko]], who knows the local stockists and has pointed me to the right fittings more than once. I also keep a note on [[Zaenpapath Kolbuth]] for the few jobs where I wanted a second opinion on mounting.

## Open questions

- Is the high power draw figure real, or was it a bad test setup? I need to repeat the bench test.
- Should I add a small shade over the housing to take the edge off summer heat, or would that reduce the sunlight the panel gets?
- Would a second sensor at the deeper end of the pond give a more useful picture than one at the shallow edge?
- Is the ruler stick comparison enough, or should I add a proper fixed gauge post?
- How long will the seal last? It has held since 2021, but I do not know its real lifespan.
- Should I move the arm slightly higher so that reeds are less of a problem?

## History

- **2021:** Installed the Starklil level sensor at the pond. Mounted on an arm at the shallow edge, with the panel facing the open side.
- **After the first season:** Added the laminated checklist at the fence post after I forgot a step in spring.
- **Later seasons:** Started the ruler stick comparison after noticing a few readings that did not match what I saw.
- **Some time after:** Moved the arm once and failed to record the change, which led to the rule of logging every adjustment.
- **Recent:** Began a more careful look at power draw, which produced the high figure that I now need to verify.

The next step is to repeat the bench test, trim the reeds before the next summer, and decide on the shade question. Once those are done I will update this plan and close off the matching open questions.
