---
type: drivers
status: active
project: zulvae-repair
area: beekeeping
description: "Drivers about Zulvae repair."
---

# Drivers of Zulvae repair

## Supplies

Zulvae repair is a project in the beekeeping area. The goal is repair, the start year is 2024, the season is winter, and the lead is the carpenter. These are the drivers I keep in mind when I decide what to buy.

The supplies follow from the goal. Since the goal is repair and not a new build, I buy as little new material as I can and reuse what is sound. Anything that can be planed, glued, re-screwed or patched comes first. New timber is bought only when a part is cracked through or rotten.

What I keep on the list:

- Dry timber offcuts for patching frames and boxes.
- Wood glue suited to damp conditions, plus clamps of several lengths.
- Stainless screws and a few hinges, so nothing rusts into the wood again.
- Sandpaper in coarse and fine grades, and a scraper for old propolis.
- Linseed-based paint or oil for the outside surfaces, never anything with a strong smell on the inside.
- Clean cloths, a wire brush and a bucket for washing parts before they go back.

The carpenter leads, so the carpenter decides what counts as sound. If the carpenter says a part is finished, it goes on the replacement list, and I do not argue about it. I write down what I used so that next winter I can tell what was bought and what was already in the shed.

Because the season is winter, the supplies have to be on hand before the cold sets in. Glue and paint behave badly in a cold workshop, so I only buy what I can store indoors and use in a heated space. Shopping trips in midwinter are slow and I want to avoid them.

## Schedule

The project began in 2024 and it is a winter project. That fixes the shape of the schedule: the bees are clustered and quiet, the boxes are empty or nearly so, and the apiary work is at its lowest. This is the only time equipment can be taken out of use without harming a colony.

The order of work, as I plan it each winter:

- Sort the equipment into three piles: fine, repairable, and beyond repair.
- Clean everything in the repairable pile and let it dry fully.
- Do the carpentry: joints, frames, floors, lids.
- Paint or oil the outer surfaces and let them cure.
- Store the finished parts, labelled, ready for the spring.

The schedule is driven by drying and curing, not by my own energy. Wet wood cannot be glued well, and fresh finish needs days before it can be stacked. So I leave gaps between steps and I do not try to compress them. If I rush, the repair fails by midsummer and I do the same work twice.

The carpenter is the lead, so the carpenter's availability sets the pace of the carpentry step. I do the cleaning and sorting before the carpenter starts, so no workshop time is wasted on dirty parts. When the carpenter is not available, I do the sanding, scraping and painting preparation myself.

A rough rule: the sorting is finished early in the season, the carpentry fills the middle, and the finishing and storing close it out. Anything not finished by the end of winter is moved to the next one only if it is not needed for the spring inspection. Anything needed in spring gets priority over everything else.

## Risks

The main risks to Zulvae repair are these.

- Damp. Wood that is not dry enough will not hold glue, and it will warp after the repair. This is the most common cause of a failed job.
- Disease carried in old equipment. Old comb and propolis can hold spores. Repairing a part and putting it back without cleaning it defeats the point of the project.
- Disturbing the colonies. Winter work should stay away from occupied hives. Moving or knocking a box with a cluster inside can cost the colony.
- Cold workshop. Glue and finish cure poorly in the cold. A bad cure looks fine for a month and then fails.
- Over-repair. Spending effort on a part that is nearly finished is a waste. The carpenter's judgement is the guard against this.
- Budget drift. Small purchases add up. Without a running tally, the total ends up well above the plan.
- Time. If the repairs run past the end of winter, spring work collides with them.

For each risk I try to have a simple habit. I check moisture by feel and by weight before gluing. I wash and scrape every part. I keep the workshop warm enough for the glue. I let the carpenter decide on condemned parts. I keep a list of every purchase and add it up every week.

The risk I take most seriously is the disease one, because it is invisible. A part that looks perfect can still hurt the apiary. So cleaning is not optional, and it is never skipped to save time.

## Observations

Some things I have noticed over the winters since 2024.

Repairs on joints last longer than repairs on flat surfaces. A cracked board that is patched often cracks again next to the patch, while a re-glued and re-screwed joint is usually fine for years.

Parts that were stored dry and off the floor need much less work than parts stored in a damp corner. The cost of poor storage appears the following winter, as extra repair work.

Propolis is much easier to scrape off when it is cold. In winter it becomes brittle and comes off in flakes, which saves time and sandpaper. This is a small advantage of doing the work in the winter season.

The carpenter notices things I miss: slight twisting, hidden rot under paint, a joint that looks fine but moves under pressure. Having the carpenter as lead has improved the quality of the repairs more than any tool I bought.

Outside surfaces take finish better when they are sanded lightly and wiped clean first. Skipping the wipe leaves dust under the paint, and the paint then peels at the edges.

Labelling matters. Parts that are not labelled get mixed up, and then I cannot remember which were repaired and which were not. A simple mark in pencil on an inner face is enough.

Finally, the work always takes longer than expected. Each year I think the pile is small, and each year it fills most of the season. I now plan for that and do not feel behind.

## Open questions

These are questions I have not settled.

- How much of the equipment should I replace outright, and how much is worth repairing? The carpenter's view helps, but I have no firm rule for where the line sits.
- Is there a better finish for the outside surfaces, one that lasts longer without being harmful to the bees?
- Should the repair work be spread across two winters, so that half of the equipment is always in good shape, or is it better to do everything in one season?
- What is the best way to measure whether a repair has worked? So far I just see if the part is still in use after a year, which is slow.
- Can I buy timber in a larger lot to lower the cost, or would it only sit in the shed and take up space?
- Who should handle the work if the carpenter is unavailable for a whole season? I could do simple repairs, but joints need skill.
- How should I record the history of each part? A notebook is simple, but it is easy to lose track of it.

I will return to these at the end of each winter and see which have answers. Some, like the finish question, may only be answered by trying something on a few parts and waiting.

## Problems

Problems I have actually met, as opposed to the risks I expect.

Glue failed on a few joints in a cold room. The joints looked fine and then came apart when the box was lifted. The fix was to redo them in a warmer place and to leave them clamped for longer than the instructions said.

Some screws stripped the old wood. When the wood around a screw hole is soft, a longer screw does not help. The better answer is to fill the hole with a glued dowel and drill again.

Paint blistered on a part that was still damp inside. The surface felt dry, but the core was not. I now wait longer than seems necessary, and I weigh a test piece to see when it stops losing moisture.

Some parts turned out to be beyond repair after I had already cleaned them. That is wasted effort. Now I ask the carpenter to look at each part before I wash it, not after.

I once lost track of which boxes had been treated. Since then everything is labelled.

Another continuing problem is space. Parts in several stages of repair fill the workshop, and I have to move them to reach the ones I need. A simple shelf plan would help, but I have not built it yet.

The last problem is time at the end of the season. The final steps are rushed, and rushed steps are where the mistakes appear. I try to start the sorting earlier each year.

## Safety

Safety matters because the work involves tools, dust and old material.

- Wear a dust mask when sanding. Old wood and propolis dust is unpleasant to breathe, and old paint on some equipment may be a problem.
- Wear eye protection for any cutting, drilling or scraping.
- Wear gloves when handling old comb and when washing parts, and wash hands after.
- Keep the workshop ventilated when using paint, oil or glue, even in winter. A heater in a closed room makes fumes worse.
- Keep oily cloths away from heat. Cloths soaked in linseed oil can warm up and ignite on their own. I spread them flat to dry outdoors or keep them in a closed metal tin of water.
- Clamp work down before cutting. A part that moves while being cut is the easiest way to get hurt.
- Let the carpenter handle the power tools I am not trained on.
- Keep a first aid kit in the workshop and know where it is.

For the bees, the safety rule is simple: do not open or move occupied hives in winter. Repair work is done on empty equipment only. If a box still holds a colony, it waits until the weather and the bees allow it.

I also keep sharp tools stored away from the floor and from where I step. Winter light is poor, so I add a lamp over the bench instead of working in the dim.

## Ideas

Ideas I may try, not yet decided.

- Make a simple jig for cutting patches to the same size, so that repairs are faster and look consistent.
- Build a drying rack for finished parts, so they do not touch while the finish cures.
- Keep a small box of standard spare parts, such as frames and hinges, to swap in quickly during the season. This reduces the time hives stay open.
- Try a different joint type on one box and compare it against the usual one after a few years.
- Write a one-page checklist for each type of part, to use during sorting.
- Ask the carpenter to teach me one skill each winter, such as cutting a good joint by hand.
- Take a photo of each part before and after repair, to build a record I can look back at.
- Plan a small test area outside, where a few painted samples stay through the weather, to compare finishes.
- Buy fewer but better tools. A good plane and a good clamp set may save more than many cheap ones.

Most of these are small. The ones I like best are the spare parts box and the photos, because they cost little and help the most. The test samples would answer one of my open questions, so they are worth doing too.

## References

These are the sources I rely on, kept as plain descriptions and not links.

- My own notes from earlier winters of Zulvae repair, starting in 2024.
- The carpenter's advice, given in person and written down by me afterward.
- A beekeeping handbook I keep on the workshop shelf, used for dimensions and hygiene practice.
- The instructions printed on the glue and finish containers, which I read before each new batch.
- Notes from the local beekeepers' meetings, where others talk about the same repairs and what worked for them.
- Photos of equipment before repair, kept in my phone and sorted by season.

I treat the carpenter's advice as the main source on woodwork and the handbook as the main source on bees. When they differ, I ask the carpenter how the advice applies to my equipment, since the carpenter has seen it.

The references are not exhaustive. I add to them when I learn something useful, and I remove advice that proved wrong.

## Lessons

What I have learned so far.

Dry wood and a warm room matter more than any tool. Most of the failures I have had came from skipping one of them.

Clean first, repair second. Cleaning shows the real condition of the part, and it removes the disease risk. Starting with the glue wastes effort.

Let the lead decide. The carpenter's eye is better than mine, and arguing about a condemned part costs time.

Label everything. A pencil mark takes seconds and saves hours.

Plan for the work to take longer than it seems. Underestimating is the most reliable thing I do, so I now add a margin to everything.

Keep a running tally of spending. It is easy to tell myself that small purchases do not count, and the total shows otherwise.

Do not repair what is nearly finished. A new part is sometimes the cheaper and better answer.

Finish winter work in winter. Carrying it into spring makes both seasons worse.

The goal is repair, and it helps to keep that word in mind. Each decision is tested against it: does this extend the life of the equipment I already own? If yes, I do it. If not, I question it.

## Checklist

Use this list at the start and end of each winter.

- Equipment sorted into fine, repairable and beyond repair.
- Carpenter has looked at the repairable pile and confirmed the list.
- All parts cleaned, scraped and fully dry.
- Workshop warm enough for glue and finish.
- Supplies on hand before the cold sets in.
- Purchases written down and totalled.
- Joints repaired, clamped and left to cure.
- Outside surfaces sanded, wiped, painted or oiled.
- Oily cloths dealt with safely.
- Every part labelled.
- Finished parts stored dry and off the floor.
- Photos taken of the repaired parts.
- Notes updated with what worked and what did not.
- Spare parts box checked and refilled.
- Open questions reviewed.

If an item cannot be ticked, I write down why next to it. That reason often becomes the first task for the following winter.

## Maintenance

Repair only lasts if the equipment is looked after once it is back in use.

During the season I check the repaired parts whenever I open a hive. I look for new cracks, loose screws, peeling paint and signs of damp. Small faults are fixed on the spot or noted for the next winter.

After the season, I clean the equipment before storing it. Propolis and wax are scraped off while still manageable, and anything damp is dried before it is stacked. Storage is dry, ventilated and off the floor.

Every year I re-oil or repaint the outside surfaces that show wear. A thin coat each year is far less work than a full repair later. I do not wait until the finish has failed.

Tools need care as well. Blades are sharpened, clamps are wiped, and screws and hinges are sorted so I can find them. A tool that is ready makes the winter shorter.

I keep the notes for this project up to date. Each winter I add the date of the work as a year only, what was done, and what the carpenter said. After a few years this gives me a record of which repairs lasted and which did not.

The carpenter, as lead, reviews the state of the equipment at least once a year. Their view is the base for the next winter's plan, and the project continues in that cycle.

## Budget

The budget of Zulvae repair is 33471.10 EUR.

This is the ceiling for the project, and it covers supplies, tools I must buy for the job, and any fee for the carpenter's work. It is the financial driver that sits next to the goal of repair and the winter season.

I treat the figure as a limit and not a target. The aim is to spend less by reusing sound parts and by repairing instead of replacing. Money not spent is kept for the following winter.

Success is measured in three ways. First, the repaired equipment is back in use by spring. Second, the repaired parts are still sound a year later. Third, the total spent stays within the budget. If the first two hold and the third does too, the winter counts as a success.

To keep to the limit, I write down every purchase with its category and add the totals each week. If spending runs ahead of the work done, I stop buying and review the list with the carpenter. Large purchases, such as a batch of timber or a set of clamps, are discussed before I make them.

Where the budget is under pressure, the order of priority is clear. Parts needed for the spring inspection come first, then parts that protect the colonies from disease, then the surface finishing, and last the improvements from the ideas list.
