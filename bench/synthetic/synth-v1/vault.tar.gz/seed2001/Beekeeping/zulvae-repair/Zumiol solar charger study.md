---
type: research
status: active
project: zulvae-repair
area: beekeeping
---

# Zumiol solar charger study

## Risks

The Zumiol solar charger is a yellow unit that sits in the barn, and it has been there since 2016. It is a solar charger by kind, but the energy source recorded for it is mains. I keep that fact at the top of the risk list, because the name suggests sunlight and the wiring says otherwise. Anyone who assumes it runs on its panel alone will misjudge what happens when the barn supply is cut.

The first risk is the mains feed. The barn circuit is old and shared with other things, and the charger depends on it completely. If the supply drops during a storm, the charger stops, and the beekeeping gear that relies on it goes flat without warning. I have not seen this cause a real loss yet, but the chance is there every winter, when I use the equipment least and check it least.

The second risk is damp. The barn is dry for most of the year, but the walls sweat in autumn. The case is yellow plastic and looks sealed, yet I do not trust the seams. Moisture inside a mains-fed device is a safety problem as well as a reliability one. I want to inspect the inside at least once a season and note any film or corrosion on the terminals.

The third risk is dust and wax. Beekeeping work in the barn leaves fine debris in the air: propolis flakes, wax shavings, and sawdust from frame building. The charger sits low enough to collect it. A layer of this on the vents could trap heat. I wrote about a similar problem in [[Fermae Ziogun notes]], where fine dust clogged a fan and shortened the life of a device. The same logic applies here.

The fourth risk is age. Installed in 2016, the unit is now well past the point where I would expect trouble-free service. Plastic goes brittle, cable insulation hardens, and connectors loosen. None of these failures announce themselves. I would rather replace a part early than find out the hard way.

The fifth risk is my own habits. I tend to plug extra things into the same socket when I am busy, and I leave the charger running when I should switch it off. A tidy routine matters more than any clever fix. The practical rules I have settled on are these:

- Keep the socket for the charger only, with nothing else added to it.
- Look at the cable and the case every time I enter the barn for other work.
- Keep the vents clear and brush them out regularly.
- Never leave anything charging unattended during a storm warning.
- Write down anything odd straight away, even if it seems small.

A last, smaller risk is confusion over the label. Because the device is called a solar charger, a helper might try to move it outside to "get sun". That would expose a mains-powered unit to rain. I should put a plain note on the case saying it runs from the barn mains and must stay indoors.

## Schedule

This schedule is how I plan to check the charger over a year. It is not a formal maintenance contract, only a list I can realistically keep to. I tie each check to a job I already do in beekeeping, so I am less likely to forget it.

**Spring, at the first hive inspection.** This is the main check of the year. I switch the charger off at the wall, unplug it, and look it over. I check the cable for cracks, the plug for heat marks, and the case for warping. I open it only if the seams show signs of moisture. I brush out the vents and wipe the yellow casing so that any new marks are easy to see. I then plug it back in and watch it for a while to confirm it behaves as it did the year before.

**Early summer, during swarm season.** This is the busiest time for the bees and the barn, so the check is short. I only confirm that the charger still works and that nothing has been stacked against it. Boxes and frames tend to pile up in the barn at this time of year, and that blocks airflow. I clear the space around the unit and leave it clear.

**Late summer, after the honey harvest.** The harvest creates the most wax and sticky residue in the barn. Once the extraction is done and the room is cleaned, I do a second dust check on the vents and the surface. This is the point where I look for any sweet or sticky film on the case, because it attracts dust and holds it.

**Autumn, before the damp.** I do a careful look at the walls near the charger and at the socket. If the wall is wet or the paint is lifting, I move the unit to a drier spot on a shelf. I also run it for a full working cycle to see whether it still delivers what it should. If the result is worse than before, I write it down and compare it with earlier entries.

**Winter, once a month.** I do a quick look only. I check that the unit is dry, that the cable has not been chewed by mice, and that the socket is not warm. Mice are a real nuisance in the barn after the first frost, and cables are a favorite target.

**Every few years.** I want to decide whether the 2016 unit should be replaced. The decision should not wait for a failure. I will compare how it performs with what I recorded in [[Nithden greenhouse 2023]], where I tested a newer arrangement and kept better notes on output and running costs. If the old charger clearly lags behind, I will replace it. If it holds up, I will keep it and carry on with the same routine.

I also keep a few standing habits that are not tied to a season:

- After any power cut, I check that the charger came back on correctly.
- After any storm, I look at the cable and the plug.
- If I smell anything hot or burnt, I unplug the unit at once and do not use it until I understand why.

## Observations

These are the plain facts I have recorded about the Zumiol solar charger, followed by what I have noticed in use.

The device is a solar charger. Its area of use is beekeeping. The color is yellow, which makes it easy to spot on the barn shelf and also easy to see dirt on. Its energy source is mains. It was installed in 2016, and its location is the barn. I list these in one place so that I can find them quickly without searching the rest of my notes.

The main thing I notice is the mismatch between the name and the supply. A solar charger that runs from mains is odd, and I keep wondering whether the solar part is only a secondary feature or whether the label simply describes the design. I have not settled this. For my purposes it does not matter much, because what I rely on is the mains behavior, and that is what I test and note down. I treat the unit as a mains device and apply the safety habits that go with that.

In everyday use the charger has been steady. It does its job without fuss, and I rarely think about it, which is both good and bad. Good, because nothing has gone wrong that I can point to. Bad, because a device I never think about is one I might fail to check. The schedule above is meant to counter that habit.

The yellow case has faded slightly where light reaches it from the barn window. The part facing the wall is still a deeper shade. That tells me the plastic does get some light exposure, and I should keep in mind that sunlight can age the case over many years. It is a small point, but it ties in with the age risk I listed earlier.

I have seen dust gather on the top and around the vents, mostly after I have been working with frames. It wipes off easily when dry. When the air is damp, it clings, and that is when I worry most. I have not found any corrosion so far, but I have not opened the unit very often, so I cannot claim much from that.

The barn temperature swings are noticeable. It is cool in winter and warm under the roof in summer. The charger seems to cope, and I have not noticed any odd smells or heat marks on the plug. I still feel the plug with the back of my hand during the summer check, and I intend to keep doing that.

Compared with the notes in [[Fermae Ziogun notes]], this device has had an easier life, partly because it is indoors and partly because I have kept the area around it fairly clear. Compared with the setup in [[Nithden greenhouse 2023]], it is simpler but also less well documented, which is why I am writing this study now rather than leaving it to memory.

Open questions I want to answer in later entries:

- Does the solar part contribute anything at all, or is it purely a name?
- How does the charger behave right after a power cut?
- Is the case still properly sealed after all these years in the barn?
- Would a different shelf position reduce dust and damp?
- At what point is replacement cheaper than continued care?

For now, my working view is that the charger is reliable enough to keep, provided I stay disciplined about the checks and keep the barn socket dedicated to it.

## History

The Zumiol solar charger went into the barn in 2016. I keep it in my notes as a solar charger, which is its kind, and it is used for beekeeping. The name causes confusion, because its energy source is mains. It does not draw anything from the sun in my setup. It plugs into the barn socket and is built around the same box and charging logic that the solar versions use. When I first wrote it down I put "solar" in the title and then spent a while wondering why the panel input was never used. The answer is simple: this unit was bought and wired for mains from the start.

The color is yellow, and that mattered more than I expected. The barn is dim and cluttered, with frames, supers, smokers, spare lids and rolled wire all around. A yellow case is easy to spot on the shelf above the workbench. I have never lost it under a pile of veils or gloves, which cannot be said for the grey chargers I used before.

The reason for buying it in 2016 was practical. I had a growing number of battery-powered items around the apiary: a small head torch, a handheld light for evening inspections, a radio, and a battery pack for the electric fence that keeps the bears and the badgers away from the hives. All of them ran down at inconvenient times. I wanted one place in the barn where everything was charged, and I wanted it to be the same place every time.

The first season was mostly trial and error. I mounted the unit on a wooden board near the socket and left a short cable hanging so I could reach it from the bench. I put the board on the wall beside the door, which turned out to be a poor spot. Dust from the grain store drifted over it, and in damp weeks the case felt cold and slightly clammy. Later I moved it higher and further from the door. That helped, and I have not touched the position since.

Over the following seasons the routine settled down:

- In spring, I check the cable and the plug before the first inspections.
- In summer, I charge the fence pack and the lights on a regular rhythm, usually after the evening round.
- In autumn, I charge everything fully before the hives are closed up for winter.
- In winter, I leave the unit mostly idle, and I top up the fence pack only when I need it.

There was one rough patch. A storm cut the barn power for a long stretch, and during that time I had nothing to charge with. That was when I first considered a true solar input. I did not follow through, because the mains version does what I need nearly all the time, and a panel on the barn roof would have meant more cabling and more things to go wrong. I wrote the idea down and left it.

## Tools

This section lists what I use with the charger and around it. The unit itself is simple, so the surrounding tools matter more than the charger.

**The charger itself.** It is yellow, mains powered, and sits in the barn. It has a few status lights and a set of output leads. I have never needed to open it. I treat it as a sealed box and keep it that way.

**A mains socket with a switch.** The charger plugs into a switched socket. I can cut the power to the charger without pulling the plug. That is useful when I leave the barn for a long time, and it avoids wear on the plug.

**A timer plug.** For a while I used a timer between the socket and the charger, so the charging would stop on its own after some hours. It worked well for the small batteries. I stopped using it for the fence pack, because that one needs longer and a timer cut it short. Now I use the timer only for the torch and the radio.

**Labeled leads.** Each lead has a strip of tape with a short word on it: fence, torch, radio, spare. Without labels I mixed them up more than once. The tape is cheap, and it prevents mistakes with the wrong lead on the wrong battery.

**A small multimeter.** I use it to check the fence pack before and after charging. I do not trust the status light alone. The light says charging or done, but it says nothing about how healthy the battery is. A quick reading tells me whether the pack is holding its charge or fading.

**A notebook by the bench.** I write down when I put the fence pack on charge and when I take it off. It sounds fussy, but it caught a failing battery early. The pack began to need more time for the same result, and the notes showed the change.

**A metal tin for spares.** It holds fuses, spare leads, and a few adapters. It is kept next to the charger so a replacement is never far away. The tin is also yellow, by coincidence, which I find mildly amusing.

**A dry cloth.** The barn is dusty. A cloth wipe now and then keeps the vents and the lights clear. I do not use water or sprays on the unit.

I considered other tools and did not keep them. A wall clock with a charging reminder was ignored within a week. A second charger as a backup took up shelf space and stayed unused. A cable reel was too bulky for the spot I have.

## Lessons

The first lesson is about names. A device called a solar charger can still run on mains. My Zumiol solar charger, installed in 2016 in the barn, is mains powered. Writing the energy source down plainly saves me from repeating the same confusion each time I come back to these notes. I now record the properties first: kind, area, color, energy source, year installed, location. Then I describe the story around them.

The second lesson is about placement. The barn is useful for a charger because it is close to the hives and the bench, but it is also dusty, cold, and damp at times. The unit does best when it is mounted high, away from the door, and wiped regularly. My first position was wrong, and it took a season to see why.

The third lesson is about habit. A charger is only useful if the routine around it is dependable. Charging after the evening round, writing down the fence pack times, and checking with the meter all take little effort, and together they stop surprises. Most of my problems in the apiary with batteries came from skipped habits, not from broken equipment.

The fourth lesson is about color. Yellow is a small detail, but it saves time. In a cluttered barn, I find the charger at once. If I buy another unit for beekeeping, I will again look for something bright.

The fifth lesson is to resist upgrades without a clear reason. After the storm, I wanted a solar panel. Looking back, the outage was rare, and the simple mains setup has worked for years since 2016. A change should answer a real, repeated problem. One bad week was not enough.

Some things I would still do differently:

- Mount the unit higher from the first day.
- Label every lead at once, not after the first mix-up.
- Keep the multimeter right beside the charger, not in a drawer across the barn.
- Write the charging notes from the start, so I would have a longer record of how the batteries age.

Some open questions remain for later study. I want to know how many seasons the fence pack will last at the current rhythm. I want to see whether a cooler or warmer spot in the barn changes how long a full charge takes. And I may eventually test a true solar input alongside the mains one, as a backup for outages, without replacing what already works.

For now, the summary is short. The charger is yellow, mains powered, installed in the barn in 2016, and used for beekeeping. It is plain, dependable, and slightly misnamed, and the care I put around it matters more than the box itself.

## Problems

The first problem is the name. The Zumiol solar charger is called solar, and its kind is solar charger, but its energy source is mains. It has no working panel feeding it. I keep having to remind myself of this when I read old notes, because I tend to assume it runs off daylight. It does not. It draws from the mains socket in the barn, and that is the only supply I have ever used with it.

The second problem is that the mains supply in the barn is not reliable. The barn is at the far end of the yard, and the cable that feeds it has been patched more than once. When the supply drops, the charger stops, and nothing tells me. The yellow case has a small indicator, but I cannot see it from the door. I only learn about an outage when I walk in and the battery for the hive equipment is flat.

The third problem is damp. The charger was installed in 2016 and the barn wall behind it sweats in autumn. I have seen a faint film of moisture on the case more than once. So far the electronics have survived, but the terminals have gone dull and I have had to clean them. I should not leave this unchecked through another wet season.

The fourth problem is dust and wax. Working with bees in a barn means propolis, wax flakes and fine wood dust. All of it settles on the case and into the vents. A charger that cannot shed heat will run hotter than it should. I have wiped it down in the past, but I have no routine for it, and that is the real fault.

The fifth problem is my own record keeping. I do not have a log of when the charger was last checked, when the leads were last replaced, or how long a full charge takes now compared with when it was new. Without that, I cannot say whether it is slowly getting worse or whether I am imagining it. This study is partly an attempt to fix that.

Smaller annoyances:

- The leads are short, so the battery has to sit right next to the charger on the shelf, which is not where I would put it.
- The bright yellow colour makes it easy to find, but it also makes it look like a toy, and visitors have picked it up without asking.
- The mounting is rough. It sits on a shelf and is not fixed to anything, so a knock could send it to the floor.
- The cable from the wall socket runs across a walkway, and I have tripped on it carrying frames.

## Overview

This section records what the device is, using the exact properties I have noted for it.

The subject is the Zumiol solar charger. Its kind is solar charger. Its area of use is beekeeping, and it supports the small amount of electrical kit I use around the hives and in the extraction work. The colour of the case is yellow. Its energy source is mains. It was installed in 2016, and its location is the barn.

What it does in practice: it keeps a battery topped up so that the equipment I use for beekeeping is ready when I need it. That includes a lamp for working in the dim barn, a small fan used when drying frames, and a few other low-power items. The charger does not do anything clever. I connect a battery, the charger fills it, and I disconnect it when it is done. There is no remote monitoring and no display beyond the small indicator.

How it fits into the beekeeping year:

- In spring I use it more, because I prepare frames and boxes in the barn and need the lamp and fan.
- In summer the extraction work leans on it most, since that is when I spend long hours inside.
- In autumn it matters for preparing the colonies for winter, but the damp makes it harder to trust.
- In winter it mostly sits idle. I leave it plugged in at times, which I now think is a mistake, because the barn is at its dampest then.

Why I am studying it: it has run for years with almost no attention, and I want to know whether it is still worth keeping or whether I should replace it. The study is not about the beekeeping itself. It is only about this one device and the conditions around it.

What I already know:

- It works. Every battery I have connected has charged.
- It is old by the standards of this kind of equipment, since it dates from 2016.
- Its position in the barn is not ideal, because of the damp and the dust.
- Its mains supply is the weak point, more than the charger itself.

What I do not know yet:

- Whether the charger stops properly when a battery is full, or keeps pushing current.
- Whether the case gets warm enough to worry about.
- Whether the terminals are corroding faster than I can clean them.
- Whether the name means there was ever a panel option that I never fitted.

The plan for the remaining parts of this study is to watch the charger over several full cycles, write down what I see, and then decide. For now this overview is the baseline: a yellow solar charger, used for beekeeping, running on mains, installed in 2016, standing in the barn.

## Supplies

These are the things I need on hand to look after the charger and to carry out the checks in this study. I have most of them already.

Cleaning:

- A soft dry brush for dust in the vents.
- Clean cloths, kept only for this job.
- A small tub of warm water with a drop of mild soap, for the case only, never near the vents or terminals.
- A wooden skewer or similar, for picking wax and propolis out of the gaps.
- A small can of compressed air, if I can find one, to clear the vents without pushing dirt in.

Terminals and leads:

- Fine abrasive paper for dull terminals.
- A small wire brush for the battery clamps.
- A thin protective grease to smear on terminals after cleaning.
- Spare leads, longer than the present ones, so the battery does not have to sit beside the charger.
- A few cable ties and clips to hold the mains lead along the wall and off the walkway.

Damp protection:

- A packet of moisture absorber to keep on the shelf near the charger.
- A small plastic cover or box that keeps drips off but still lets air through.
- A strip of wood or a bracket to lift the charger off the shelf and away from the wall.
- Screws and plugs to fix that bracket to the barn wall.

Checking and recording:

- A basic multimeter to read the battery voltage before and after charging.
- A notebook kept in the barn, so I write the date, the battery condition and how long it took.
- A pencil, because pens fail in the cold.
- A cheap thermometer and humidity gauge for the shelf, so I can compare the barn air with what I feel.
- A torch, since the barn is dim at the back.

Power supply:

- A mains socket tester, to check the barn socket before I blame the charger.
- A surge-protected extension block, if the wiring turns out to be the cause.
- A small timer plug, to stop the charger from staying connected all winter.
- A word with an electrician, if the barn wiring keeps failing. That is a job for someone qualified, not for me.

Safety:

- Gloves, because the battery terminals can leave residue on the hands.
- Eye protection when cleaning near batteries.
- A dry floor mat in front of the shelf.
- A small extinguisher kept by the barn door, which I should have anyway.

I will tick these off as I gather them, and add anything missing when the checks show a gap.

## Checklist

This is the list I run through when I check the Zumiol solar charger in the barn. The unit is a solar charger, it is yellow, it has been in place since 2016, and its energy source is recorded as mains. It serves the beekeeping work. I keep the checklist short enough to finish in one visit.

**Before I go into the barn**

- Bring a dry cloth, a small brush, and a torch, because the corner where the charger sits is dim even at midday.
- Bring the notebook and write the visit down, even if nothing changed.
- Put on the usual beekeeping gloves only if I will also be near the hive stores. Otherwise bare hands are better for feeling connectors.

**Looking at the unit**

- Confirm that the yellow casing is still intact. The colour is how I spot it from the door, so fading is worth noting. Cracks matter more.
- Check that the charger is still mounted where I put it in 2016, in the barn, and has not been knocked or shifted by stored equipment.
- Look for dust, cobwebs, wax flakes and propolis smears on the casing and on the vents. Wax dust gets everywhere in the barn.
- Look for droppings or nesting material. Mice like warm electrical boxes.
- Check for damp marks on the wall behind the unit.

**Looking at power**

- The energy source is listed as mains, so I check the mains lead first: the plug, the socket, and the whole length of the cable for nicks or crushed spots.
- Make sure the socket is not shared with something heavy, such as the extractor motor or a heater.
- Check that the indicator on the unit shows power present. Note what it shows, in words, in the notebook.
- If the indicator is dark, test the socket with another small device before blaming the charger.

**Looking at the output side**

- Check the leads that go from the charger to whatever it charges. Look at the clips and the ends for green or white corrosion.
- Wipe the contacts with the dry cloth. Do not use any liquid on them.
- Confirm that the charged item feels no more than slightly warm after it has been on charge for a while.
- Make sure nothing is draped over the charger while it works.

**After the check**

- Put the cloth and brush away so they do not end up in the honey room.
- Write the visit in the notebook: what I saw, what I cleaned, and anything I want to look at next time.
- If I changed anything, add a line to the setup notes below so the next version of me knows.

I do this at the start and the end of the beekeeping season, and once more whenever the barn has been through a bad storm or a long wet spell.

## Open questions

These are the things I do not yet know, or have not checked properly. Some of them bother me more than others.

**Why is a solar charger running from mains?**
The device is a solar charger, but its recorded energy source is mains. Those two facts sit awkwardly together. Possible explanations:

- It was bought as a solar model, but in the barn there was never enough light, so I wired it to mains from the start in 2016.
- It has a mains input as a backup, and I simply never set up the panel.
- The label on the casing says one thing and my notes say another, and I recorded the energy source from memory.

I want to open the notes from the original installation and look at the casing label side by side. Until then I treat mains as the working answer, because that is what it is plugged into.

**Is the solar panel still connected at all?**
If there ever was a panel, I do not remember where it went. The barn has a roof that faces the right way, but I have not looked for a cable running outside. A walk around the outside wall and under the eaves would answer this.

**Does the charger still do useful work?**
It has been in the barn since 2016, which is a long time for a small electrical unit in a dusty, damp, temperature-swinging building. I do not have a measured record of how well it charges now compared with the first years. What I would need:

- a note of how long the charged item takes to reach full now
- a note of how long it lasts afterwards
- a comparison with a fresh unit, if I ever buy one

**What exactly is being charged, and is it all still needed?**
The area is beekeeping, and over the years the list of small things I keep powered in the barn has changed. I should write down which items really depend on this charger and which have moved to other arrangements. If only one thing depends on it, a simpler setup might do.

**Is the barn location a problem?**
The barn is convenient, but it is not ideal for electronics. Questions to settle:

- Does the temperature in winter drop low enough to matter?
- Does summer heat build up near the yellow casing?
- Is the damp in the corner getting worse?
- Would a shelf higher up, away from the wall, be safer?

**Is the mains supply safe and sensible?**
I never recorded who did the wiring for the socket, and whether the circuit has proper protection. I would like an electrician to look at the barn circuit once, and I should write the result here.

**Should the charger be replaced?**
This depends on the answers above. If the charger still works and the checklist keeps coming back clean, there is no reason to replace it. If I find the casing cracked, the leads brittle, or the performance clearly worse, I will start thinking about a replacement and write a comparison note.

## Setup

This section describes the arrangement as I understand it now. Where I am not sure, I say so.

**The device**

- Name: Zumiol solar charger
- Kind: solar charger
- Colour: yellow
- Energy source: mains
- Year installed: 2016
- Location: barn
- Area of use: beekeeping

**Where it sits**

The charger is in the barn, on the wall near the corner where I keep the smaller beekeeping tools. It is easy to find because of the yellow casing. It is close enough to a socket that the mains lead reaches without being stretched, which was the main reason I chose that spot in 2016. The leads to the charged equipment are short, and I keep the working area in front of it clear.

**How it is powered**

The energy source is mains. The charger plugs into a socket in the barn, and I leave it connected through the season. In the quiet months I sometimes unplug it, though I have not been consistent about that, and I should decide on a rule and write it here. Despite the name, I do not currently rely on sunlight for it.

**How I use it**

In practice the routine is simple. I connect the item that needs charging, leave it for a while, and take it off when it is done. I do not leave the equipment on charge for days if I can avoid it. During the busy part of the beekeeping year the charger is used often. In winter it is mostly idle.

**What I keep nearby**

- A dry cloth and a small brush on a hook beside it
- The notebook with visit entries, kept in the barn office drawer
- A spare lead, in case the main one is damaged

**Things I have changed**

- The position of the unit has stayed the same since 2016.
- I have cleaned the contacts several times, but I did not keep a count.
- I have not modified the casing.

**What to record next**

When I next visit, I will add the label details from the casing in words, check whether there is any trace of a panel connection, and note the state of the mains lead. I will also write down what is plugged into the charger on that day, so the setup description matches reality and not just my memory.

**Short summary of the setup**

A yellow solar charger, installed in 2016, in the barn, running from mains, used for beekeeping work. It is simple, old, and mostly reliable, and the main thing I do not understand is why a solar device depends on mains at all.

## Ideas

These are the things I want to try or look into with the Zumiol solar charger. It is a yellow solar charger that sits in the barn, installed in 2016, and I use it for beekeeping work. One odd detail I keep coming back to: its energy source is listed as mains, even though it is sold as a solar charger. So the ideas below are partly about understanding what that means in practice.

**1. Work out what the mains feed really does.**
The device has a mains connection, and I want to know whether the mains side is the main supply, a backup, or only a way to top up when the light is poor. A simple test would be to unplug the mains feed for a full week in summer and watch what the charger does. If it keeps charging from light alone, then the mains connection is a safety net. If it stops, then the "solar" part is more of a name than a function. I should write down what I see each day so I do not rely on memory.

**2. Move or tilt the panel.**
The barn is not an ideal place for anything that needs sun. If the panel is behind a wall or under the eaves, it gets very little direct light. I could test a few positions near the barn door or on the south side of the roof and compare how quickly the charger fills a battery. Even a small change in angle might help during autumn and winter, when the sun sits low.

**3. Keep a charging log.**
I do not have a proper record of how long the charger takes to fill a battery. A plain table in this note would be enough: date, weather, which battery, how long it took, and whether it filled completely. After a season I could see patterns, such as which weeks are weak and whether the mains feed makes up the gap.

**4. Match the charger to the beekeeping jobs.**
The reason I keep this charger in the barn is the beekeeping equipment. I want to list what actually needs power during the year:

- the lamp I use when I inspect hives late in the day
- the small fan I use to cool the work area in summer
- the radio that I keep running while I extract honey
- any small tool that needs a battery in spring when I prepare frames

With that list I can decide whether the charger is big enough, or whether I am asking too much of a device that has been in place since 2016.

**5. Think about a second unit.**
If the test in the first idea shows that the charger depends on the mains feed, I might add a second, genuinely solar-powered unit near the hives instead of carrying batteries back to the barn. It would save walking and would also let me charge in the place where I use the power. This is only an idea for now, and I would want to see the log from idea three before spending anything.

**6. Protect it from dust and moisture.**
A barn has dust from hay, frames, and wax. Honey work adds sticky residue in the air. I could build a simple cover or shelf so the yellow case stays cleaner and the vents do not clog. This overlaps with the maintenance section below, but it is a design question as well as a cleaning one.

**7. Label the cables.**
Over the years I have swapped cables around. A tag on each lead, saying what it is for, would remove guesswork. It is a tiny job, and it would help if someone else needed to use the charger while I am away.

**8. Compare with how I used it earlier.**
Because it was installed in 2016, I have close to a decade of use behind it. I would like to go through old notes, photos, and any receipts to see whether the way I use it has changed. If I used to charge more in summer and less now, that could explain why it feels slower than it used to.

## Maintenance

This section is the routine I want to follow so the charger keeps working. Most of it is common sense, but I tend to forget, so I am writing it down.

**Regular checks**

- Look at the case every month. The yellow housing should be free of cracks, and the corners should not be loose. A crack lets in dust and damp.
- Wipe the panel surface with a soft, slightly damp cloth. Do not use anything rough, because scratches reduce how much light gets through. In the barn the dust builds up faster than I expect.
- Check the mains lead and plug. Since the energy source is mains, this cable matters. I look for nicks, kinks, and any warm spot near the plug. If the cable looks worn, I stop using it until it is replaced.
- Check that the vents are clear. Cobwebs and wax flakes are the usual problem.

**Seasonal tasks**

*Spring.* Before the first inspections, I run a full charge cycle and note how long it takes. This gives a baseline for the rest of the year. I also clean the panel thoroughly after winter.

*Summer.* This is the busiest time for beekeeping, so the charger gets the most use. I check it every couple of weeks. If the barn gets very hot, I make sure the charger is not sitting in a direct hot spot or under a pile of covers.

*Autumn.* I clear leaves, cobwebs, and mouse nests from around the unit. Mice like the barn, and they chew cables. I look for gnaw marks at the same time as I check the lead.

*Winter.* Light is weak, so I rely more on the mains feed. I keep batteries stored indoors when it is very cold, and I bring them to the charger only when needed. Cold reduces how well batteries hold a charge, so this is a good habit anyway.

**Safety habits**

- Unplug from the mains before cleaning anything near the connections.
- Do not use the charger if it is wet. Dry it, let it sit, and then test it.
- Keep it away from smoke from the bee smoker. Embers and fuel are a bad mix with any electrical equipment.
- Keep a small note near the charger with the date of the last check, so I can see at a glance how long it has been.

**Signs that something is wrong**

- The charger takes much longer than the baseline from spring.
- The case feels hot when it should be cool.
- There is a smell of burning or melted plastic.
- The indicator behaves strangely, for example flashing without a reason I can explain.
- A battery that used to fill now never reaches full.

If any of these appear, I stop using the charger, unplug it, and look at the cable first, then the connections, then the panel. If I cannot find the cause, it is better to have it looked at than to keep running it.

**Simple record**

I want to keep a short maintenance log, either here or in a separate note. Each entry needs a date, what I did, and what I noticed. Over time this will show whether problems come back at the same time each year. It will also help me decide when the charger is reaching the end of its useful life, given that it has been in the barn since 2016.

**Things I still do not know**

- Whether the panel is meant to be cleaned with any special product, or only with water.
- How long the internal parts are expected to last.
- Whether the mains connection has any fuse or protection that I should check.

I should look for the original paperwork and see whether it answers these questions.

## References

These are the sources I rely on or still need to find. Nothing here is a formal publication; it is mostly my own material and things I have observed.

**My own notes and records**

- Earlier notes about the barn and the beekeeping equipment kept there.
- Photos of the yellow charger taken over the years, which show how the case and the surroundings have changed since 2016.
- The charging log described in the Ideas section, once I have started it.
- The maintenance log described above.

**Documents to look for**

- The original paperwork that came with the Zumiol solar charger, including any instructions for cleaning and for the mains connection.
- Any receipt or record of the installation in 2016, which would confirm the year and who did the work.
- Notes from anyone who helped set it up in the barn.

**People to ask**

- A neighbour who also keeps bees and uses a charger in a similar way. They may know about problems I have not seen.
- Someone who understands mains wiring, to check the connection in the barn and to explain why the energy source is mains for a device called a solar charger.

**Summary of the subject**

For quick reference, these are the properties of the device as I record them:

- Name: Zumiol solar charger
- Kind: solar charger
- Area: beekeeping
- Color: yellow
- Energy source: mains
- Year installed: 2016
- Location: barn

**Open questions for later**

- Is the mains feed the real supply, a backup, or just a top-up?
- Would a different position for the panel make a difference in the barn?
- Is one charger enough for a full beekeeping season?
- Should a second unit be added near the hives?

I will update this list as I find answers, and I will move any answered question into the Ideas or Maintenance sections so that the information is kept in one place.

## Safety

The Zumiol solar charger is a yellow unit that has stood in the barn since 2016. It is used for beekeeping work, and its energy source is mains. That last point matters most for safety. The name suggests a panel and a battery, but this unit is fed from the mains socket in the barn. I treat it as a mains appliance and never as a harmless low-voltage gadget.

### Electrical risks

The barn is not a friendly place for electricity. It is dusty, the floor is sometimes damp, and the roof lets in condensation on cold mornings. Because of this I follow a short set of habits.

- I unplug the charger from the mains before I touch the housing, the leads or any connector.
- I never handle it with wet hands or while standing on a wet floor.
- I check the mains cable for cuts, kinks and chewed spots before each season. Mice live in the barn, and they like cable insulation.
- I keep the plug and socket dry. If the socket looks damp or smells scorched, I leave it off and dry the area first.
- I make sure the socket is protected by a residual current device. I press its test button every few months.
- I do not open the casing. If something inside is wrong, the unit goes to someone qualified, or it gets replaced.

### Fire risk

Barns hold straw, wood shavings, spare frames, wax and cardboard. All of it burns easily. The yellow housing is easy to spot, which is useful, but I still keep a clear space around it. Nothing is stacked on top of it, and nothing leans against it. Wax blocks and smoker fuel are stored well away from it. I keep a small extinguisher by the barn door, and I know how it works before I need it.

Dust builds up on the vents. I brush it off with a dry brush while the charger is unplugged. I do not use water or a damp cloth near the vents.

### Working around the bees

Beekeeping adds its own hazards to the barn. Some of these have nothing to do with the charger but affect how I work near it.

- Bees are drawn to light and warmth. If a few come into the barn, I do not swat them near the charger. I let them find the open door.
- I wear gloves and a veil when I handle hives, but I take the gloves off before I touch the plug. Thick gloves make it easy to pull a cable by accident.
- Smoker embers are a fire hazard. I never light or empty the smoker near the charger.
- Sticky honey and propolis on my hands can foul the connectors. I clean my hands before I plug anything in.

### Handling and storage

The charger is not heavy, but it should sit on a stable, dry shelf. I do not leave it on the floor, where it could meet water, and I do not hang it by its cable. Leads are coiled loosely without tight bends. When the season ends, I switch it off at the socket, unplug it and cover it with a clean cloth. I do not use plastic sheeting because it traps damp.

### What I do if something goes wrong

1. Switch off the power at the mains and unplug the unit, if it is safe to reach.
2. If there is smoke or a smell of burning, leave the barn and call for help. I do not fight a spreading fire.
3. If someone gets a shock, I cut the power first and only then touch the person.
4. After any incident I do not use the charger again until it has been checked.

### Notes on the setup

The unit has worked without trouble for years, but age is a factor. A device installed in 2016 has had a long time to collect dust, heat cycles and damp. I treat that as a reason to inspect it more often, not less. If the housing cracks, the colour fades unevenly or the cable stiffens, those are signs to replace it.

## Measurements

These are my own working figures from watching the Zumiol solar charger in use. They are not laboratory results. I took them with ordinary tools in the barn and I write them down so I can compare later.

### Subject summary

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | beekeeping |
| Color | yellow |
| Energy source | mains |
| Year installed | 2016 |
| Location | barn |

### Flow rate

The main figure I recorded is the flow rate of the Zumiol solar charger: 419.02 l/h. I use this as my reference value. When I check the unit again, I compare what I see with this figure. If it drifts far from it, I take that as a sign that something has changed, such as a blocked passage, dirt in a connector or a worn part.

I want to be honest about what this number is. It comes from one set of readings under the barn conditions I had on the day, with the unit on mains power. I did not repeat it enough times to give a proper range. It is good for comparing the unit with itself, but I would not treat it as a promise from the maker.

### How I measured

My method is simple, and I keep it the same each time so the results can be compared.

1. Let the unit settle in the barn so it is at the same temperature as the air around it.
2. Check the mains supply, the cable and the socket, following the safety notes above.
3. Run the unit for a short warm-up period before taking any reading.
4. Collect the output over a timed interval in a clean container.
5. Scale the collected amount up to an hourly figure.
6. Write the result down straight away with a short note on the weather and the state of the barn.

I use a kitchen timer and a marked jug. Neither is precise, so I round my own working and only trust the final figure to the extent that the method was repeatable.

### Conditions that change the readings

Several things in the barn can push a reading up or down, and I try to note them.

- **Temperature.** Cold mornings give lower and less steady results than warm afternoons.
- **Dust and dirt.** A dusty unit seems to behave worse. I clean it before measuring.
- **Mains supply.** The barn socket shares a circuit with other tools. If a heavy tool is running, I wait and measure later.
- **Damp.** A damp day affects the connectors and makes me less sure about the reading.
- **My own timing.** Starting and stopping the timer by hand adds error. I try to do it the same way each time.

### Reading the result

The 419.02 l/h figure is the baseline. I think about results in three bands.

- Close to the baseline: normal, nothing to do.
- Moderately off: clean the unit, check the cable and measure again on another day.
- Far off: stop, unplug, and look for a fault before using it further.

I do not set exact limits, because my method is not that precise. The bands are a guide for my own decisions.

### Observations over time

The charger has been in the barn since 2016, and in that time it has been steady. I have not kept regular logs for every season, which I regret. From now on I plan to measure once at the start of each beekeeping season and once at the end, and to keep the results next to this note.

The yellow housing has stayed easy to see, which helps when I am working in the dim barn. I have noticed that the surface gets a film of dust faster than I expected, and that is why I clean it before every measurement.

### Limits of these figures

- One baseline, no spread. I need repeat readings to know how much the number varies.
- Home tools. My timer and jug are good enough for trends but not for exact values.
- No comparison unit. I have nothing else to compare it against, so I cannot say whether it is good or poor for its kind.
- Mains-fed behaviour. Because the energy source is mains, the figure says nothing about how it would perform on sunlight alone.

### Next steps

- Repeat the flow measurement several times on different days and record the spread.
- Log the barn conditions with each reading.
- Re-check after any cleaning or repair, so I can see what changed.
- Keep the 419.02 l/h reference until I have enough repeat data to replace it with a range.
