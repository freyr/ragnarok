---
type: research
status: active
project: brunglond-repair
area: beekeeping
---

# Zaedith Gerknand tests

## Problems

The main problem with these notes is that I keep mixing up what Zaedith Gerknand told me with what I worked out myself. Zaedith is my mentor in beekeeping, and I have known Zaedith since 2012. After so many years, advice that began as a conversation has turned into habits, and I no longer remember where some of my rules came from. This note is an attempt to separate the two.

The second problem is timing. Zaedith is available on weekdays, which sounds generous, but my own work often fills those days. In the busy part of the season I tend to wait until a problem is urgent before I write to ask. That is the wrong order. A question that could have been settled in a short email turns into a rushed request, and the answer I get is shorter because the question was vague.

The third problem is that my hive records are uneven. Some weeks I write down everything: brood pattern, stores, temper of the colony, the state of the entrance. Other weeks I write one line. When I bring a question to Zaedith, I cannot always say what I saw two weeks earlier, and that makes advice less precise.

The fourth problem is that I sometimes ask the wrong kind of question. "Is this normal?" is not useful. "The brood frame had patchy capping on both sides, and the colony was calm, is that worth worrying about?" is much better. Writing the question down first, in this note, forces me to be specific.

A smaller problem is that I forget to say what I did after the advice. Zaedith gives guidance, I act on it, and then I do not report back. A mentor who never hears the result cannot correct the advice. I want to close that loop every time.

## Costs

The costs of this mentoring relationship are mostly not money. Zaedith has never asked for payment for advice, and I do not want to turn it into a transaction. The real costs are time, attention and small courtesies.

Time first. Each exchange by email takes me some minutes to prepare properly, and a proper preparation is the point. Contact is by email, so I can write at any hour, but I should send things on weekdays so the answer arrives while Zaedith is available. Sending on a Friday evening and expecting an answer is unrealistic.

Attention second. When Zaedith answers, I need to read it carefully, not skim it. A short reply often contains one important condition, such as "only if the weather holds" or "only after the flow ends". I have missed those before and paid for it with a weaker colony.

Courtesies third. I try to bring something back: a jar of honey after harvest, a clean report of how the advice worked, or help carrying equipment when there is heavy work. These are small, but they keep the relationship fair.

There are also the ordinary costs of doing what is advised. Following a suggestion may mean new frames, extra feed, a replacement queen, or a day of lost work. I should decide ahead of time how much I am willing to spend on a given problem, so that advice does not become an open-ended expense. Before I act, I write the likely cost in my own notes and compare it with the likely loss if I do nothing.

Finally, there is the cost of not asking. A lost colony costs far more than a short email. When in doubt, I ask.

## Risks

The first risk is dependence. After more than a decade, it is easy to lean on one person for every decision. Zaedith is one source, and one person cannot see my apiary. I should treat advice as informed guidance and check it against what I observe in the hives.

The second risk is outdated advice, either from Zaedith or from me remembering it wrongly. Beekeeping practice changes slowly, but pests, weather and local forage do change. Something that worked well years ago may fit badly now. I should ask whether a method still holds before I rely on it.

The third risk is miscommunication by email. Without seeing the colony, Zaedith works only from my description. If my description is poor, the advice is built on a poor picture. Photos help, but they must be clear, and I should say what I want to be looked at.

The fourth risk is availability. Zaedith is reachable on weekdays only. A problem that appears on a weekend, such as a swarm or a sudden robbing event, has to be handled by me, and I should have a plan for those cases ahead of time. I should write down the steps I am confident of, and the point at which I stop and wait for Monday.

The fifth risk is that I make a change in the hive at a bad time, because I was in a hurry to follow advice. Advice is not an order to act immediately. I should check weather, the state of the colony and my own readiness first.

The last risk is the formal side. Any written agreement should be clear, so that neither of us has a wrong idea of what was promised. That brings me to contracts.

## Contracts

There is a small written arrangement between Zaedith and me, and its date is 2024-11-04. It is not a commercial contract in a heavy sense. It is a record of what we agreed regarding the mentoring: that I can ask questions, that I will report back, and that I will be careful with any shared equipment or materials.

I keep this note simple on purpose. The date of the contract of Zaedith Gerknand is 2024-11-04, and I should use that date whenever I refer to the arrangement, so that I do not rely on memory.

What I want the arrangement to cover, in plain terms:

- Contact is by email, and weekdays are the normal time for answers.
- Advice is guidance, and the decisions in my apiary stay mine.
- If I borrow tools or materials, I return them clean and in working order.
- If something goes wrong after following advice, we talk about it openly and learn from it, without blame.
- Either of us can end the arrangement without drama.

I should read the agreement again at least once a year. It was written when my needs were different, and some parts may no longer fit. If a change is needed, I should propose it by email and get a clear answer, then update this note.

I should also keep a copy of the agreement together with my other apiary papers, not only in this knowledge base. A note is a summary, and the actual document is the reference.

## Open questions

These are the questions I want to put to Zaedith, or to settle on my own, in roughly the order of importance.

1. How should I split my time between inspecting colonies and leaving them alone? I tend to open hives too often, and I suspect this slows them down.
2. What are the clearest early signs of a colony that will not overwinter well? I want a short list I can check in autumn, while there is still time to act.
3. Which of my habits came from Zaedith, and which are only mine? Going through my records with that question could be useful.
4. What is a sensible way to prepare for a weekend emergency, given that Zaedith is available on weekdays? I want a written checklist.
5. How do I judge when a colony is strong enough to divide? I sometimes divide too early because I am eager to have more hives.
6. How much record keeping is enough? I do not want to write so much that I stop doing it, but a single line a week is too little.
7. What should I do differently in a poor forage year? I have only a loose idea and no firm plan.
8. Is there anything in the arrangement from 2024-11-04 that should be changed now that I have more hives?

For each question I should write down what I currently think before asking, so the answer can correct a specific belief and not just add more information.

## History

I have known Zaedith Gerknand since 2012. At that time I had one hive and very little idea what I was doing. The first contact was a practical one: I had a question about a colony that seemed restless, and Zaedith answered in a way that was patient and direct, without making me feel foolish.

Over the next few years the relationship settled into a pattern. I would ask about something I had seen, Zaedith would suggest what to look for, and I would go back to the hive and check. That habit of looking before acting is probably the most valuable thing I learned.

Some stages I remember:

- The early years, when I asked about almost everything and made the usual beginner mistakes, such as too much smoke, too many inspections and slow reactions to pests.
- A middle period when I had more hives and began to form my own opinions. Zaedith did not insist on being right, and often asked what I had seen before giving a view.
- A later period when I needed help with more difficult decisions, such as how to manage colonies through a hard winter and how to deal with weak colonies in spring.
- The written arrangement of 2024-11-04, which put the mentoring on a clearer footing after many years of informal contact.

The role has stayed the same throughout: mentor. The area has always been beekeeping. Contact has stayed by email, and availability on weekdays has been consistent, which has made planning easier.

Looking back, the most useful periods were those when I kept good records. The least useful were when I asked questions with no notes behind them. This is why I am trying to keep a better history of the advice I receive, and of what happened after I followed it.

## Tools

The tools I use for this relationship are simple, and I want to keep them that way.

**Email.** This is the agreed way to contact Zaedith. I write a clear subject line, then a short description of the situation, then the specific question. I attach photos only when they are sharp and show what I am asking about. I avoid sending long, rambling messages.

**Hive record sheets.** For each hive I keep a short record of the date, weather, strength of the colony, brood pattern, stores and anything unusual. Before writing to Zaedith, I read the last few entries so I can describe the trend, not only the moment.

**This knowledge base.** I use notes like this one to hold the questions, the advice and the results together. A good entry has three parts: what I asked, what I was told, and what happened.

**A calendar.** Since Zaedith is available on weekdays, I plan questions for the start of the week where I can. That leaves time for a reply and for acting on it before the weekend.

**A small notebook for the apiary.** I carry it to the hives. Writing on the spot is better than trying to remember later. I copy the important points here afterwards.

**Basic hive tools.** The hive tool, smoker, veil, gloves and a brush are the working basics. They are not part of the mentoring as such, but a lot of the advice I get is about how to use them better, so I think of them as part of the toolkit.

I try not to add new tools unless an old one has clearly failed. More tools means more to maintain and more places for records to get lost.

## Safety

Safety comes first, for me, for the bees and for anyone nearby.

**Personal safety.** I wear a veil and gloves whenever I open a hive, even for a quick look. I know from experience that a quick look is when I am most careless. I also keep in mind that some people develop a strong reaction to stings over time, so I should never work alone without telling someone where I am, especially during long inspections or heavy lifting.

**Lifting.** Full boxes are heavy. I should not lift more than I can handle safely, and I should ask for help when moving them. Zaedith has pointed out more than once that a hurt back ends a season faster than any pest.

**Smoke.** The smoker needs care. I keep it on bare ground or in a safe container, check that it is fully out before leaving, and avoid using it near dry grass.

**Other people.** The apiary should be placed and managed so that neighbours and passers-by are not put at risk. I should avoid opening hives when many people are nearby, and avoid working in poor weather when the bees are defensive.

**Weekends.** Because Zaedith is available on weekdays, I should not wait for a reply if a situation is dangerous. If there is a safety issue, I act on my own judgement or call for local help, then report afterwards.

**Advice and safety.** If a piece of advice seems to put me or others at risk, I stop and ask again. It is better to send one more email than to carry out something I do not understand.

## Overview

Zaedith Gerknand is a person in my network and my mentor in beekeeping. Here are the properties, stated as I record them:

- Name: Zaedith Gerknand
- Role: mentor
- Area: beekeeping
- Contact: email
- Availability: weekdays
- Known since: 2012

The relationship is practical. I ask specific questions, receive guidance, act on it in my own apiary, and report the result. The decisions stay with me, and the advice is one of several inputs.

The written arrangement is dated 2024-11-04. It records the basics: email contact, weekday availability, careful handling of anything borrowed, and open discussion if something goes wrong.

The reason I keep this note is to make the relationship more useful and less dependent on my memory. It collects the problems I face, the costs, the risks, the open questions, the history and the habits I want to improve. It is a working note and I expect to revise it as things change.

The main points in short:

- Ask earlier, and ask better questions.
- Keep good records so that advice can be precise.
- Report back after acting.
- Plan for weekends and emergencies without relying on a reply.
- Check the arrangement once a year.

## Lessons

Several lessons have come out of the years since 2012.

**Look before acting.** The best advice from Zaedith has usually been to observe more closely first. Many problems look worse than they are, and some that look minor are serious. A calm, careful look at the frames, the entrance and the behaviour of the colony usually tells me more than any rule.

**Write it down.** Whenever I have kept good notes, the advice I received was more useful and my own decisions were better. When I have not, I have repeated mistakes without noticing.

**Ask early.** A short question sent in good time is better than an urgent one sent late. Since availability is on weekdays, planning ahead matters.

**Be specific.** Vague questions get vague answers. I should state what I saw, when, and what I have already tried.

**Report back.** Advice is a conversation, not a delivery. Telling Zaedith what happened makes the next piece of advice better, and it is simply fair.

**Keep the decision.** I may ask, and I may listen carefully, but the colonies are mine. If I follow advice, I should understand why. If I do not follow it, I should have a reason and say so.

**Expect to be wrong sometimes.** Beekeeping has a lot of variation. Even good advice does not always work. When it fails, the useful response is to find out why, not to blame anyone.

**Keep it fair.** Small returns, such as honey, help with work and prompt replies, keep a long relationship healthy.

## Observations

These are the things I have noticed about how the mentoring works in practice.

Replies from Zaedith tend to be short and carefully chosen. There is usually one main point, and sometimes one condition attached to it. I have learned to read the whole message twice before acting.

Questions that include a concrete description get better answers than questions that ask for general opinion. When I have attached a clear photo and a few lines of context, the answer has usually been more definite.

Weekday availability shapes the rhythm. Messages sent early in the week are answered while I still have time to act. Messages sent late in the week sometimes have to wait, and that can mean a delay at a bad moment.

Email suits this relationship. It leaves a written record, lets me think before I write, and lets Zaedith answer when there is time. The cost is that tone and detail can be lost, so I try to be clear.

Over the years I have noticed that Zaedith asks more questions than I expected. Often the first reply is a question about what I saw, and this has made me a better observer.

I have also noticed that my own confidence has grown. In the early years I asked about everything. Now I ask about the harder cases, and I often arrive with my own opinion already formed. That seems to be what a mentoring relationship should produce.

Finally, the arrangement dated 2024-11-04 has made things clearer without making them stiff. Having the basics written down means I do not need to wonder what is expected. I plan to review it once a year and keep this note up to date.
