---
type: research
status: archived
project: brunglond-repair
area: beekeeping
description: "Research about Krioskus kiln controller."
---

# Krioskus kiln controller notes 2019

## Ideas

This note records what I knew about the Krioskus kiln controller in 2019. Later notes replace these values, so treat it as a snapshot and not as the current state.

The basic facts, as I wrote them down: the Krioskus kiln controller is a kiln controller. Its area is beekeeping. Its color is green. Its energy source is battery. The year installed is 2025. Its location is the yard.

The idea behind the device is simple. I want a small, self-contained controller that holds a kiln at a steady temperature for wax work and for drying frames and hive parts. It should not depend on a wall socket, because the yard has no convenient mains supply near the work table. A battery-powered unit lets me put the kiln wherever the light and shelter are best.

Ideas I want to keep in mind:

- Keep the controller body separate from the kiln itself, so I can replace either one without redoing the wiring.
- Use the green housing as a visual marker. Green is the color I use for everything that lives outside, so I can find it quickly in the yard shed.
- Pair the battery with a small solar top-up. I have not decided how. The [[Krissensal solar charger study]] covers the general approach, and the [[Trildeth solar charger handbook]] has the wiring details I would need.
- Borrow the thinking from the [[Lirktrae heat exchanger]] notes for moving heat out of the kiln shell and into the drying space, instead of letting it escape into the yard air.
- Add a liquid level reading for the wax melter. The [[Drursus level sensor]] looks like a candidate, and the [[Laga level sensor notes]] explain how it behaved in a similar setup.

The workshop tools matter too. If I build a wooden frame for the controller box, the cuts will come from the same saw I plan to review in [[Tronas band saw 2020]]. That note does not exist in full yet, so I should not rely on it.

## Costs

I have not fixed any prices, and I will not guess at them here. This section lists the cost categories only, so I can fill in figures in later notes.

Cost categories:

- The controller board and its housing in green.
- The battery, which is the largest ongoing cost, since it will need replacing sooner or later.
- A solar charger, if I decide to add one. The two solar notes above both suggest this part is cheap compared with the battery, but I have not verified that.
- A level sensor for the wax melter, either the [[Drursus level sensor]] or something similar.
- Wiring, connectors and weatherproofing for the yard location.
- My own time. Past projects took longer than I expected, mostly because of weatherproofing and testing outside.

A cost I tend to forget is the loss from failures. A kiln that overheats can ruin a batch of wax or scorch wooden parts. That is a real cost even though it never appears on a receipt.

Another hidden cost is battery management. If the energy source is a battery, I need a routine for checking it. A checklist on the shed wall would be cheap and would probably save more than any hardware upgrade.

## Measurements

The one measurement I have for the Krioskus kiln controller is its power draw. The measured power draw of Krioskus kiln controller: 313.49 W.

That figure matters because the energy source is a battery. A draw of that size means the battery cannot run the kiln for a long stretch without topping up. Any plan for the yard has to take this into account, either with a larger battery or with the solar option from the [[Krissensal solar charger study]].

What I have measured so far:

- Power draw: 313.49 W, as above.
- Color: green, confirmed by looking at the housing.
- Location: the yard, near the work table.

What I have not measured yet:

- How the draw changes between warm-up and holding temperature. I suspect warm-up is much higher than hold, but I only have the single reading above.
- Battery runtime under real conditions in the yard.
- Temperature stability at the kiln shelf compared with the controller's own reading.
- How cold weather affects the battery.

When I measure again, I will write down the conditions beside the number: the weather, the starting charge of the battery, and what was inside the kiln. A bare number without that context is hard to use later, and it makes comparing notes across years almost useless.

## Open questions

- The year installed is 2025, while this note describes the state in 2019. I should check whether the 2019 picture was a plan, a prototype or an earlier unit, and make that clear in later notes.
- Is a battery the right energy source for the long run, or will I end up wiring the yard for mains anyway? The measured draw suggests it is a stretch for a battery alone.
- Does the solar route actually work for this load? The [[Trildeth solar charger handbook]] may answer this, but I have not read it with this draw in mind.
- Which level sensor suits the wax melter better, the [[Drursus level sensor]] or the one described in the [[Laga level sensor notes]]? I need to compare how each handles wax residue and heat.
- Can heat recovery in the style of the [[Lirktrae heat exchanger]] be added without making the kiln harder to clean?
- Where exactly in the yard should the unit sit? The location is the yard, but the yard is large, and wind, shade and rain differ a lot from one corner to another.
- Should the green color be kept? It is easy to spot, but a dark green housing may absorb heat in summer.
- Who else will use it? If I share the yard work, I need to write simple operating instructions.

## Risks

- Battery depletion during a run. With a draw of 313.49 W, a battery that is not fully charged could fail partway through a batch, leaving the contents half dried or half melted.
- Overheating. If the controller loses its sensor reading, it may hold the heating on. I want a hard cutoff that does not depend on the main control logic.
- Weather exposure. The yard location means rain, dew, dust and temperature swings. Any joint that is not sealed will eventually fail.
- Fire risk near dry grass, wooden hive parts and wax. The kiln should sit on a non-flammable base with clear space around it.
- Battery safety. Charging outdoors, especially with a solar top-up, needs proper protection against overcharge and short circuits.
- Sensor drift. A level sensor in a wax melter can foul over time, giving false readings. This is a concern for both the [[Drursus level sensor]] and any alternative.
- Documentation drift. Because this note is archived and later notes replace its values, I may mistake old numbers for current ones. I should always check the newest note before acting on anything here.
- Workshop dependencies. If I rely on a new tool for the housing, such as the saw in [[Tronas band saw 2020]], delays there will delay the whole build.
