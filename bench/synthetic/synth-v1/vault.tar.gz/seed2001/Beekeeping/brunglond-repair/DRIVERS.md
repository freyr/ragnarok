---
type: drivers
status: active
project: brunglond-repair
area: beekeeping
description: "Drivers about Brunglond repair."
---

# Drivers of Brunglond repair

## Ideas

Brunglond repair is a project with the goal of repair, in the area of beekeeping. It started in 2025, runs in the winter season, and the lead is my neighbor. This note covers the drivers: why the project exists, what limits it, what it costs, and how I will decide whether it worked.

The main idea is simple. Something in the beekeeping setup, the Brunglond, has stopped doing its job properly, and I would rather fix it than replace it. Fixing it keeps the money in the hives and keeps the knowledge in my own hands. Winter is the right season because the bees are clustered and I am not disturbing any colony while I work.

Other ideas I have kept on the list:

- Repair in the workshop, not at the apiary, so nothing wet or cold gets in the way.
- Let the neighbor lead, since the neighbor has done this kind of repair before and I have not.
- Take notes and photographs at every step, so the next repair is quicker.
- Replace only the parts that are truly worn, and keep the sound ones.
- Use the repair to review the whole setup while it is apart.
- Think about whether a small change during the repair could stop the same fault returning.

I considered replacing the whole thing. I dropped that idea because it costs more, wastes good material, and teaches me nothing. I may reconsider if the repair turns out to be larger than expected.

## History

Brunglond came into my beekeeping work before 2025, and it has been used through several seasons. It has had small fixes before, mostly quick patches done in the middle of the working year. Those patches held for a while, but they were never a proper repair, and each one was done in a hurry.

By 2025 the fault was clear enough that I could not keep ignoring it. I talked to my neighbor, who keeps bees as well and has a good eye for this sort of problem. The neighbor offered to lead the work. We agreed to start in the winter, when there is time, and when a failed attempt would not cost me a colony.

So the project began in 2025 as a winter repair job with the neighbor in charge. The goal has not changed since then: repair, not replace, and not upgrade.

## Setup

The project properties, stated plainly:

- Name: Brunglond repair
- Type: project
- Goal: repair
- Area: beekeeping
- Start year: 2025
- Season: winter
- Lead: neighbor

The work happens indoors in a cold but dry workshop. I keep a bench cleared, a tray for small parts, and a box for anything removed. The neighbor brings their own tools for the tricky steps, and I bring the basic ones. We work in short sessions, because the workshop is cold and fingers get slow.

Before touching anything, we photograph the Brunglond from every side. We then take it apart in order, labelling each piece with masking tape and a pencil mark. This is the most useful habit I have, and it is the driver behind a lot of the other decisions in this note.

## References

I do not have a manual for the Brunglond, so my references are mostly people and my own notes.

- The neighbor, who leads the project and knows the usual failure points.
- My own earlier notes on the quick patches, which show what was tried and what failed.
- Photographs taken at the start of the project.
- Two beekeeping books on my shelf that cover equipment care in general terms.
- A few friends in the local beekeeping circle, who I can ask if we get stuck.

None of these is complete. Together they are enough to plan the work and to judge whether a part is worth keeping.

## Lessons

Lessons from the earlier patches, which now drive how this repair is run:

- A rushed fix in the working season is usually a bad fix. Winter gives time.
- Labelling parts during disassembly saves hours later.
- Writing down what failed matters as much as writing down what worked.
- Asking the neighbor early is cheaper than undoing a mistake.
- Do not mix worn and sound parts back together without a clear reason.
- Check the whole piece, not only the part that visibly broke. The visible fault is often a symptom.

These lessons set the constraints. We will not hurry, we will not skip the checking, and we will not start work without a clear plan for putting things back.

## Schedule

The project runs in the winter season, and I keep the schedule loose on purpose. The fixed point is that the work must be finished before the bees need the equipment again in spring. Inside that window, the plan has four stages:

- Inspection and photographs, first, in one short session.
- Disassembly and sorting of parts into worn and sound.
- Repair or replacement of the worn parts.
- Reassembly, testing, and a final check by the neighbor.

I leave a gap between stages so that I can order anything missing without pressure. Cold weather can stop work for a few days, and I accept that. If a stage slips, the later ones slide with it, but the spring deadline does not move.

## Safety

Safety matters even though the bees are dormant. The main concerns are tools, cold, and materials.

- Wear gloves and eye protection when cutting, sanding, or scraping.
- Keep the workshop ventilated if using glue, sealant, or finish.
- Do not work when too cold to feel my hands properly.
- Keep sharp tools away from the edge of the bench and put them back after use.
- Make sure no old propolis dust or wax residue is breathed in; wear a mask when scraping.
- Keep a first aid kit in the workshop and know where the phone is.

If the neighbor and I disagree about whether a step is safe, we stop and talk before continuing. That rule is simple and I want to keep it.

## Maintenance

The repair is only worth doing if it lasts. After it is finished, I want to keep the Brunglond in good condition with regular, light care.

- Inspect it at the start and end of each season.
- Clean it after use and let it dry fully before storing.
- Store it somewhere dry, off the floor, and away from pests.
- Keep a short log of any new wear or small fix.
- Reapply protective treatment on the schedule that the neighbor recommends.

Maintenance is part of how I judge success. A repair that needs redoing every season has not really solved the problem.

## Costs

The costs of the project fall into a few groups. Parts and materials are the biggest. Then come consumables such as glue, fasteners, sandpaper, and finish. Small tool purchases are possible if a job needs something I do not own. There is also the time cost, which I do not put a price on, but I do track in rough hours.

The neighbor is not charging for leading the work. I plan to repay the favor with honey in the summer, which is not part of the budget but is part of the deal.

I keep receipts in an envelope and record every purchase in my notes, with the date and what it was for. At the end of the project I compare the total against the budget figure given below.

## Problems

Problems I already expect, or have already met:

- Some parts may be hard to find, since the Brunglond is not a common item.
- Old fasteners may be seized or damaged and need careful removal.
- Hidden damage may appear once the piece is apart.
- Cold weather can slow glue and finish from setting properly.
- The neighbor and I both have other work, so sessions may be hard to schedule.
- My own skill is limited, so some steps may need to be done by the neighbor.

When a problem appears, I write it down, note what we tried, and decide with the neighbor whether to continue, adapt, or stop the step.

## Risks

The larger risks to the project:

- The damage is bigger than expected and the repair turns out to cost more than a replacement.
- A replacement part cannot be found and the repair stalls.
- The repair is finished but fails again soon, which wastes the whole effort.
- The work runs past winter and the equipment is not ready in spring.
- The neighbor becomes unavailable and I have to continue alone.

To manage these, I check the extent of damage early, before spending money. I set a rule that if the repair looks to cost more than replacing, we stop and reconsider. I also keep the spring deadline in view from the start.

Success is measured simply: the Brunglond works as it should, it is ready before spring, the spend stays within the budget, and it survives the first working season without the same fault returning.

## Budget

The budget of Brunglond repair is 9480.99 EUR.

This is the ceiling for the whole project, covering parts, materials, consumables, and any small tools. I treat it as a limit, not a target, and I do not plan to use all of it unless the repair really needs it. If spending approaches the limit before the work is done, I stop and review with the neighbor before buying anything more.
