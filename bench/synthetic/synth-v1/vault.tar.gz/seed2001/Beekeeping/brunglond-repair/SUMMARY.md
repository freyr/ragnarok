---
type: summary
status: active
project: brunglond-repair
area: beekeeping
description: "Summary about Brunglond repair."
---

# Summary of Brunglond repair

## Supplies

The repair is a beekeeping job, so the supplies are mostly simple things I already keep in the shed. I have written them down here so I do not buy the same item twice.

- Spare frames, already assembled, for swapping out the damaged ones.
- Wood glue and a few small nails for the box joints.
- A hive tool and a stiff scraper for cleaning old propolis off the edges.
- Sheets of coarse sandpaper, plus one fine sheet for the final pass.
- Linseed oil for sealing the outside of the repaired boxes.
- Clamps, at least four, to hold the joints while the glue sets.
- A smoker and a bag of dry fuel, in case the cluster needs checking while the lid is off.
- Gloves and a veil, even though it is winter and the bees are quiet.

Nothing here has to be ordered. If the neighbor needs something I do not have, he will say so and I will note it in the open points.

## Next action

The next action of Brunglond repair is NX-4670. This is the single thing to do before anything else moves forward. I keep it here at the top of my attention so that when I open this note I know right away where to start. Everything below is context for that step: why the project exists, how the workspace is set up, and what has already been decided.

Once NX-4670 is finished, I will update this section with whatever comes after it. Until then there is nothing else to schedule.

## Setup

The project is a repair, and it sits in the beekeeping area of my notes. It started in 2025, and the season is winter, which is the sensible time for this kind of work because the colonies are clustered and I do not need to open the hive for anything. The lead is my neighbor, who has more experience with woodwork than I do. I am helping and keeping the notes.

Practical arrangement:

- Work happens in the unheated workshop, with the damaged equipment brought in from the apiary.
- The neighbor decides the order of the jobs. I handle the cleaning, the sanding and the record keeping.
- Anything that has to be done near the bees waits for a warm, calm day, even in winter.
- I take a photo of each part before I touch it, so I can compare afterwards.

The workshop is cold, so glue takes longer to set than the label suggests. We leave clamped joints overnight rather than trusting a short wait.

## Decisions

The decisions so far are few, and I want to keep them in one place.

- **Go decision:** the go decision date of Brunglond repair is 2021-04-04. That is the date recorded for the decision to go ahead with the repair rather than replace the equipment. I keep the date as it was written down, even though the project itself started in 2025.
- **Lead:** the neighbor leads. I follow his order of work unless something looks unsafe for the bees.
- **Repair, not replace:** the goal stays at repair. We only replace a part if it cannot hold a joint any more.
- **Season:** the work is kept to winter, so nothing disturbs the colonies during the active months.
- **Finish:** the outside gets linseed oil, nothing with a strong smell, so the bees are not bothered when the equipment goes back.

If any of these changes, I will add a line here with the reason, not just overwrite the old one.

## Overview

Brunglond repair is a project in the beekeeping area. Its goal is repair. It started in 2025, the season is winter, and the lead is the neighbor.

**Stage:** the project is in the middle. The decision has been made, the workspace is set up, and the supplies are on hand. The actual repairs are only partly finished.

**What is done:**

- The damaged pieces have been looked at and sorted into those that can be saved and those that cannot.
- The workshop is ready and the tools are laid out.
- The old propolis and wax have been scraped from the worst joints.
- Photos of the starting condition are saved.

**Open points:**

- Some joints are loose enough that I am not sure glue alone will hold them. The neighbor will judge these one by one.
- I have not decided how many spare frames to keep in reserve after the repair.
- The oil needs a dry, warmer day to cure properly, so the finishing step may have to wait.
- I still need to write down the final condition of each repaired piece.

**Next action:** NX-4670, as stated above.

I review this summary whenever something changes. The aim is to be able to read it in a minute and know the state of things.

## Background

The equipment came through several seasons of heavy use and some rough weather. By the end of the last season, a number of joints had opened up, some edges were soft, and a few frames no longer sat straight. It was still usable, but I did not want to put it back into service in spring in that state.

Replacing everything would have been the easy route, but it costs more and wastes wood that is mostly sound. The neighbor has repaired this kind of equipment before and offered to lead the work. He prefers to do it in winter, when the hives are closed up and there is time. That fit my own schedule, so we agreed.

I started keeping notes on the project in 2025. Since then the notes have grown into this summary and a few smaller pages for individual jobs. This note is the one I look at first. It tells me the stage, what has been done, what is still open, and what comes next.

A few lessons I want to keep from the work so far:

- Clean the joints thoroughly before gluing. Old propolis ruins a glue line.
- Clamp more than seems necessary, and leave the joints longer in the cold.
- Photograph before and after. It helps when I try to remember what was wrong with a piece.
- Do not rush the finish. Oil that has not cured has a smell, and bees notice.

When the repair is finished, I will move the equipment back to the apiary on a mild day and write a short closing note on how it went.
