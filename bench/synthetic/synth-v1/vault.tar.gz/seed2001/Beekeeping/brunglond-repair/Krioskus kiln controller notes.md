---
type: note
status: active
project: brunglond-repair
area: beekeeping
description: "Note about Krioskus kiln controller."
---

# Krioskus kiln controller notes

## Safety

The Krioskus kiln controller is a green kiln controller that sits in the yard, and it runs on a battery. I installed it in 2025. It is used for beekeeping work, mainly melting and holding wax at a steady temperature. The battery supply is the first thing I think about when I work near it, because a battery does not switch off when I unplug the mains.

Rules I follow every time:

- Disconnect the battery lead before opening the case, even for a quick look.
- Keep the controller off the wet grass. It stands on a flat paving slab, and I cover it when rain is likely.
- Never leave molten wax unattended while the controller is the only thing watching the temperature.
- Keep a metal lid and a bucket of dry sand within arm's reach. Water on burning wax makes it worse.
- Wear gloves and sleeves. Hot wax splashes further than I expect.
- Do not charge the battery inside the shed with the wax pots. Charge it on the bench in the workshop.

If the controller ever smells of hot plastic, I pull the battery lead first and ask questions afterwards. The yard location helps here, since there is airflow and nothing flammable nearby except the pallet stack, which I should still move further away.

## Maintenance

Maintenance is mostly about the battery, the probe lead and the case seals. The yard is damp in autumn and dusty in summer, and both show up on the contacts.

Routine checks:

- Wipe the green case with a dry cloth and check that the lid gasket is still soft and not cracked.
- Look at the battery terminals for white or green crust. Clean with a stiff brush and dry them fully.
- Flex the probe cable gently along its length and look for stiff or cracked sections.
- Check the relay clicks cleanly when I run a short test.
- Re-tighten the terminal screws, because heat cycles loosen them over time.

Once a season I take the controller down to the workshop, open it and blow out dust and any insect debris. Bees and wasps like to investigate warm boxes, and a small nest in the vent is a real risk. I also compare its temperature reading against a known-good probe. If it has drifted, I note the offset and correct it in the configuration instead of trusting memory.

The level sensing on the wax tank is handled separately, and my notes on that are in [[Taelluseth level sensor notes]]. Anything about wiring the controller into a recording setup goes in [[Liolkrios data logger]].

## Costs

I am not writing exact prices here, because I would only get them wrong later. What matters is where the money goes.

The biggest ongoing cost is the battery. It is the part that wears out first, and since the controller runs on battery alone, I cannot cheat with a cheap mains adapter. A cycle-rated battery costs more at the start but lasts more seasons, so it has been the better buy.

Smaller recurring costs:

- Replacement probe leads, which suffer from heat and from being stepped on.
- Gasket material and a little silicone grease for the case seal.
- Terminal cleaner and spare fuses.
- Charging time, which is almost free but takes bench space.

One-off costs were the controller itself in 2025 and a basic weatherproof cover that I built from offcuts. The cover cost nearly nothing, and I used the [[Drilses band saw]] to cut the timber frame, which saved hiring anyone.

The thing I want to track better is cost per batch of wax melted. At the moment I only have a feeling that it is cheap, and a feeling is not a number.

## Ideas

Several improvements are on my list, roughly in order of usefulness.

- Add a small solar panel to top up the battery during the day. The yard gets good sun for most of the afternoon, so this should work on a modest panel.
- Fit a low-battery cutoff that stops the heater and sounds a buzzer before the battery sags too far.
- Build a proper hinged hood so that I do not have to balance a board on top.
- Add a second probe for the water jacket, so I can see the gap between the jacket and the wax.
- Connect the controller to the [[Liolkrios data logger]] so each melt leaves a record without me writing it by hand.
- Paint a small label on the case with the safe operating range, so a helper does not need to ask me.

A less practical idea is a color-coded status lamp. The case is green already, so a lamp would need to be amber or red to stand out. A single bright LED that turns red when the temperature passes the limit is probably enough.

I would also like to compare the controller's behavior with the results in [[Serktrio Zothken tests]], since that test series covered how quickly wax holds temperature in different containers.

## Schedule

My working pattern for the Krioskus kiln controller follows the beekeeping year, not the calendar.

- Late winter: take the controller to the workshop, do the full seasonal clean, test the relay and recalibrate the probe.
- Early spring: charge the battery fully, fit it, and run an empty test heat in the yard.
- Summer: use it for wax rendering after honey harvests. Check the battery state before each session.
- Autumn: final melts for candle and balm making, then a thorough wipe-down before it goes away.
- Winter: store the controller indoors and keep the battery on a slow charge, topped up once a month.

Each week in season I do a short check: terminals, cable, case seal. Each session starts with a ten minute warm-up test and ends with the battery lead disconnected. It is a small habit, but it has prevented a few mistakes, including one time when I left the heater armed overnight.

If the weather turns wet I postpone the session instead of improvising a cover. There is always another dry afternoon within a week or so.

## Observations

Things I have noticed since installing it in 2025:

- The controller holds temperature steadily once the wax has fully melted. The first heat-up is where it overshoots a little.
- Cold mornings in the yard make the battery noticeably weaker. Running a session in the warm part of the day gives much more runtime.
- The green case warms in direct sun, so the reading near the case can be higher than the air temperature. I keep it in partial shade now.
- Condensation forms inside the lid if I close it while the unit is still warm and then the evening turns cool. A pinch of desiccant has helped.
- The relay click is audible from a few steps away, which is handy because I can tell the cycle is working without looking.
- Insects are attracted to the warm vent. I fitted a small mesh screen to stop them.
- The probe reads slightly slow when it is buried in thick wax, so I place it closer to the middle of the pot.

The overall impression is that the controller is reliable and simple, and most problems come from the environment around it rather than from the controller itself.

## Measurements

I measured the power draw of the Krioskus kiln controller with an inline meter while the heater was running at full output. The reading was 887.52 W. That is the figure I use when I plan battery capacity for a session.

Other properties I keep on record for reference:

- Kind: kiln controller
- Area: beekeeping
- Color: green
- Energy source: battery
- Year installed: 2025
- Location: yard

A typical configuration extract from the unit looks like this:

```
[controller]
mode = hold
probe = primary
heater = enabled
low_battery_cutoff = enabled
alarm = buzzer
log_output = off
```

The log output is switched off for now. When I connect it to the data logger I will turn that on and begin collecting proper temperature traces, so that future measurements are not limited to a single power reading. The next set of measurements I want are the runtime on a full battery and the temperature drift over a long hold.

## Supplies

What I keep on hand for the controller:

- A spare battery, charged and labeled, kept in the workshop.
- A spare probe lead.
- A small set of fuses suited to the circuit.
- Silicone grease and a spare lid gasket.
- Terminal brush, dry cloths and contact cleaner.
- Mesh offcuts for the vent screen.
- Desiccant sachets for the case.
- Heat-proof gloves and a metal lid for emergencies.
- A bucket of dry sand near the work area.
- Wax pots and a filter cloth, which are really part of the melting setup but belong in the same box.

The supplies live in a plastic crate next to the [[Drilses band saw]] in the workshop, since that is where I do the repairs and cut the odd bit of timber for the cover. I check the crate at the start of each season and replace anything missing. The spare battery is the item I most often forget to recharge, so I put a reminder in the seasonal checklist.

## Open questions

Some things I still do not know or have not tested properly:

- How many full sessions can the battery run before its capacity visibly falls? I have a rough sense but no records.
- Is a solar top-up enough to sustain the controller during a long rendering day, or would it only slow the drain?
- Should the controller sit in a vented box, or does that just invite insects and moisture?
- How much of the probe lag is the probe and how much is the wax? A comparison against the findings in [[Serktrio Zothken tests]] might answer this.
- Can [[Taelluseth level sensor notes]] be combined with the controller so that heating stops automatically when the wax level is too low?
- Would the logger setup in [[Liolkrios data logger]] cope with the electrical noise near the heater relay?
- Is there a safer way to mount the controller above the ground, away from puddles?

I will add answers here as I test each one, and move the settled ones into the other sections.
