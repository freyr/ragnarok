---
type: plan
status: active
project: brunglond-repair
area: beekeeping
description: "Plan about Tarkvaer solar charger."
---

# Tarkvaer solar charger plan

## Background

The Tarkvaer solar charger is a solar charger that I use in my beekeeping work. It is grey, and it sits in the shed. I installed it in 2023. One detail of it is odd and worth writing down at the start: its energy source is listed as mains. It is called a solar charger, but the unit in the shed is fed from the mains supply, so in practice it works as a plain charger for the batteries and small devices I use around the hives. This plan is my own record of how I intend to keep it running, what I want to check, and what I want to change.

Here are the properties of the device, stated once so that I do not have to hunt for them later:

- Name: Tarkvaer solar charger
- Kind: solar charger
- Area: beekeeping
- Color: grey
- Energy source: mains
- Year installed: 2023
- Location: shed

I keep the charger in the shed because that is where the beekeeping gear lives. The shed is dry most of the year, though it gets cold in winter and warm in high summer. Both extremes matter for a charger and for the batteries attached to it. The idea of this plan is to make the care of the unit routine instead of something I remember only when a battery is flat on the day I need it.

The things I charge with it are modest. There is a lamp for working in the shed in the evening, a small battery pack for the hive scale display, a set of rechargeable cells for a torch, and now and then a phone when I am out at the hives and want a call to be possible. None of these is heavy, but together they add up across a season, and the charger is the one point they all depend on.

Why a plan at all? Over the years since 2023 I have had small annoyances. A cable that went stiff. A battery that was left on charge much longer than needed. A day when I could not tell whether the unit was working because the indicator is hard to read in bright light from the shed door. None of these was serious. All of them were avoidable with a little regular attention. So this note collects the work into one place.

The main goals are:

- Keep the charger reliable through the whole beekeeping season.
- Reduce wasted electricity from leaving things plugged in.
- Make it easy to see at a glance whether the unit is healthy.
- Keep a short written record of what I did and when, so that next year I am not guessing.

I do not intend to rebuild anything. The plan is about care, small improvements and tidy records.

## Tools

I do not need much to look after the charger. Most of the tools are already in the shed, and I want them stored together so that a check takes minutes and not an hour.

Basic tools:

- A small screwdriver set, both flat and cross heads, for opening the cover if I ever need to look inside the case.
- A soft brush, the kind used for cleaning frames, kept for dust only.
- A dry cloth and a slightly damp cloth, one for each job.
- A torch with fresh cells, because the shed light is poor in the corners.
- A multimeter, for checking battery voltage and for confirming the output of the charger.
- A plug-in power meter, which sits between the wall socket and the charger to show how much energy it takes.
- Cable ties and a few short pieces of tape for tidying leads.
- A notebook and pencil, kept on a hook beside the charger, for quick entries before I copy them into the notes.

Notes on how I use them:

The multimeter is the most important tool here. When a battery seems weak, I measure it before blaming the charger. Half the time the battery is simply old. I try to measure at rest, after the battery has sat unplugged for a while, because a reading taken straight off the charger is too high and gives a false sense of health.

The power meter stays with the charger only during checks. I do not leave it plugged in all year, because it is also borrowed for other jobs around the house. When I use it, I let it run through a full charge cycle, not just a few minutes, since the draw changes as a battery fills.

The brush and cloth matter more than they sound. Dust in a shed is fine and persistent, and beekeeping adds wax flakes and propolis residue to it. A grey case hides dirt well, which is a mild disadvantage, because I do not notice buildup until I touch it. So I wipe it on schedule and not by eye.

I keep the tools in a small box on the shelf under the charger. If something is missing when I open the box, I write it on the supplies list further down in this note.

## Checklist

This is the routine I want to follow. I have split it by how often I do each part. I tick items off in the notebook and then add anything unusual to the history section.

Before each use:

- Look at the cable for cracks, kinks or stiffness.
- Check that the plug sits firmly in the wall socket and does not feel warm.
- Make sure nothing is stacked on top of the charger, since it needs air around it.
- Confirm the indicator shows what I expect after connecting a battery.

After each use:

- Unplug the battery or device once it is full.
- Coil the cable loosely, not tight, so it does not get stiff.
- Put the charger back in its usual place on the shelf.

Monthly during the season:

- Wipe the case with a dry cloth, then a slightly damp one, and let it dry.
- Brush dust from the vents and the socket area.
- Measure the voltage of each battery I use at rest and write it down.
- Check the shed for damp, mouse activity and wax moths near the cables.

Once a year, in early spring before the first hive inspection:

- Open the cover only if there is a reason, and look for dust, corrosion or insects.
- Run the power meter through a full cycle and compare with last year.
- Replace any cable that has gone stiff or cracked.
- Review this plan and update the open questions.

Once a year, in late autumn:

- Charge all batteries to a sensible level, not to the very top, before storing them.
- Clean the unit thoroughly and cover it against dust.
- Note anything that needs buying over winter.

The checklist is deliberately plain. If a routine is too long, I skip it. If I skip it, it is useless. So I keep each list short enough to do while the kettle boils.

## Lessons

Several things have become clear since I installed the charger in 2023.

First, the name misleads me. It is a solar charger by kind, but its energy source is mains. I need to remember that when I plan around power cuts or when I think about taking it out to the apiary. It does not give me free energy from the sun. It gives me charging from the wall socket in the shed, and that is all. If I ever want real solar charging, it needs a different setup, and I have written that down under ideas.

Second, leaving things on charge for days is wasteful and probably bad for the batteries. A habit of unplugging when full has saved effort and a little electricity. The habit is easy to forget on a busy day, so a note on the shelf helps.

Third, cold matters. In winter the shed is cold enough that batteries charge slowly and sometimes poorly. Bringing a battery indoors for a few hours before charging gives better results than charging it straight from the cold shed.

Fourth, tidy cables are not a luxury. A loose lead on the floor gets stepped on, caught on a hive tool or chewed by a mouse. Tying the leads along the shelf edge solved most of that.

Fifth, a record beats memory. When I could not recall when a battery was bought, I could not judge whether it was simply worn out. Now I write the purchase year on the battery itself with a marker, and the same information goes in the history.

Sixth, I should test before I blame. Several times I thought the charger had failed and then found a flat or old battery, or a loose plug. The multimeter and a calm check of the socket would have saved me worry.

Finally, the grey color of the case is practical but dull, and it blends into the shelf. I now keep a small bright tag on the plug end of the cable so that I can find it quickly in a dim shed.

## Costs

I have no firm figures that I trust, so I do not list exact prices here. What I can do is record the kinds of cost and how they feel in practice.

Running cost: The charger uses mains electricity, so each charge has a small cost. Because my loads are small, the yearly amount is low compared with other things in the household. The main way to keep it low is to avoid leaving things plugged in and to avoid charging when nothing needs it.

Replacement parts: Cables are the part most likely to need replacing. They are cheap, but they are easy to forget until one fails. Batteries are the bigger expense. Rechargeable cells wear out over a few years, and the pack for the hive scale display is the most costly one to replace.

Tools: I already own the main tools. The only item I borrow is the power meter. Buying my own would be a modest cost, and it would let me keep it connected for longer tests. I am undecided.

Time: Time is a cost too. The routine in the checklist takes a few minutes each time, and a longer session in spring and autumn. That is acceptable. If it grew longer, I would cut steps.

Possible upgrades: A timer plug, a better indicator light, or a true solar panel setup would each cost something. I list them under ideas and will only buy one after I decide that the benefit is real.

My approach to spending is simple. Fix the cheap, likely failures first, such as cables and tidy storage. Hold off on larger purchases until I have a season of measurements to justify them.

## History

This is a short log of what I remember and what I have written down.

- 2023: Installed the charger in the shed. I placed it on a shelf near the socket, which keeps cables short. I chose a spot away from the door to limit damp and dust.
- 2023, first season: Used it mostly for the shed lamp and the torch cells. No problems, though I noticed the indicator was hard to read in bright light.
- 2024: Added the hive scale display battery pack to the things I charge. Started to notice that leaving batteries on charge for long periods was a habit worth breaking.
- 2024, winter: Found that cold batteries charged poorly. Began bringing them indoors first.
- 2025: Replaced one stiff cable. Tied the leads along the shelf edge after one got caught on a tool. Began writing purchase years on batteries.
- 2026: Wrote this plan to turn scattered habits into a routine, and started the measurements section so that I have something to compare against.

The history is thin because I did not keep notes in the early years. From now on, each check gets a line here with the year and a few words about what I found. I do not need dates down to the day. The year and the season are enough.

## Open questions

These are things I have not settled.

- Is the charger really suited to the shed through a cold winter, or should it be moved indoors for the cold months?
- Why is the energy source mains if the unit is called a solar charger? Is there a solar input I have never used? I should check the case and the paperwork, if I can find it.
- Would a timer plug help, so that charging stops by itself?
- Is the power draw I measure normal for this kind of unit, or high? I have nothing to compare it with.
- Should I buy my own power meter?
- How much does cold reduce the charging performance of my batteries, and is it worth insulating a small box for them?
- Would a real solar panel in the apiary be useful for the scale display, so that it never depends on the shed?
- Where is the best place to keep a written copy of this plan, on paper in the shed or only here?

I will try to answer one or two of these each season and move the answers into the lessons.

## References

I keep references simple, since this is a personal note and the world around it is small.

- The printed leaflet that came with the charger, if I can find it. I believe it is in a folder in the house, not in the shed.
- My own notebook on the hook beside the charger, which holds quick entries.
- My notes on beekeeping routines, where I record the seasonal calendar that this plan follows.
- The handbook of the multimeter, for reminders on how to measure battery voltage safely.
- The instructions of the plug-in power meter, for running a long test.
- Conversations with other beekeepers in the local club, who have given me tips about storing batteries over winter.

None of these is a formal source. They are the places I go when I forget something. If I find a good article or a manual page that explains the solar input question, I will add it here with a short note about what it said.

## Problems

Here are the problems I have actually run into, and a few I expect.

Real problems so far:

- The indicator is hard to read in bright light from the shed door. Workaround: look at it from the side, or shade it with a hand, or read it in the evening.
- Stiff cables after a cold winter. Workaround: coil loosely and replace when cracked.
- Batteries left on charge for too long. Workaround: a note on the shelf and a habit of unplugging.
- Poor charging in the cold. Workaround: bring batteries indoors first.
- Dust, wax flakes and propolis on the case. Workaround: scheduled wiping.

Problems I expect or worry about:

- Damp getting into the case in a wet spell. I watch for condensation and keep the unit off the floor.
- Mice chewing a cable. I keep leads tied up and the shed tidy, and I check for droppings.
- A power cut at the time I most need a charge. Since the energy source is mains, the unit cannot help me when the supply is out. I should keep one battery fully charged as a reserve.
- Plug wear from many insertions. I will replace a loose socket plug or lead if it feels warm.

How I diagnose a problem: I start with the socket and the plug, then the cable, then the battery, and only then the charger itself. This order has proven more useful than starting with the charger. I write what I found in the history so that a repeat problem is easy to spot.

## Setup

The charger is in the shed, on a shelf near the wall socket. It is grey, which makes it look much like the rest of the shelf contents. The energy source is mains, so the plug goes directly into the shed socket. The year of installation was 2023.

Layout on the shelf:

- The charger sits at the front edge of the middle shelf so the indicator can be seen from the door.
- The tool box is on the shelf below it.
- The notebook hangs on a hook at the side.
- Cables are tied along the shelf edge with a loop left free for each device.
- Batteries wait in a small crate at the end of the shelf, with the purchase year marked on each.

Rules for the setup:

- Keep a clear gap around the charger for air.
- Nothing flammable or dusty sits directly on or against it. Spare frames and wax stay on the other side of the shed.
- The socket stays dry, and I check the socket cover each spring.
- The brightly tagged plug end shows which lead belongs to the charger.

If I rearrange the shed, I will keep the charger near the socket and at a height where I can read it. I will not use a long extension lead as a permanent solution, since it adds a fault point.

When I charge, I follow a simple order: plug the charger into the wall, connect the battery, check the indicator, and note the time. At the end I disconnect the battery first, then unplug the charger from the wall. This keeps the contacts from sparking and has become habit.

## Supplies

A short list of things to keep in stock so that routine care does not stall.

- A spare charging cable of the right type.
- A spare set of rechargeable cells for the torch.
- Cable ties and a small roll of tape.
- A marker pen for writing years on batteries.
- Soft cloths, a few clean ones, kept in a bag.
- A small tub with a lid for storing screws if I open the case.
- A bright tag or a bit of colored tape for marking the plug.
- Pencils for the notebook, since pens fail in the cold.
- A spare fuse or plug for the shed socket lead, if the type is known.
- Silica gel packets for the crate of batteries, to help against damp.

I check the supplies in early spring and again in autumn. Anything missing goes on a shopping list. I try not to buy more than I need, since a shed fills up quickly and old spares become clutter.

An important point is that the spare cable should be of exactly the same type as the one in use. If I buy a replacement, I will test it with the multimeter before relying on it, and I will mark it with the year.

## Ideas

Some thoughts for improvement, none of them urgent.

- Fit a timer plug so that charging stops after a set number of hours.
- Add a small panel of real solar cells outdoors, to give the apiary its own supply for the hive scale display. This would make the name of the device honest.
- Use a better indicator, such as a small light that I can read in daylight.
- Build a small insulated box for batteries in winter, so that they charge better in the cold.
- Put a laminated copy of the short checklist on the wall next to the charger.
- Add a hook for the cable so that it never lies on the floor.
- Keep a simple chart of battery voltages across the season, to see which batteries are fading.
- Move the notes to a yearly template so each season has a similar page.
- Label every device that connects to the charger with its purchase year.

I will go through these at the end of each season and decide whether any one is worth doing. The cheapest and simplest, such as the laminated checklist and the cable hook, come first.

## Measurements

I want a fixed place for numbers so that next year I can compare. I measure with the plug-in power meter and the multimeter.

Measured power draw of Tarkvaer solar charger: 51.12 W

Notes on how that reading was taken:

- The meter sat between the wall socket and the charger.
- The reading was taken while a battery was charging, not while the unit was idle.
- I let the charge run for a while before reading, since the draw changes as the battery fills.
- The shed was at a normal temperature, not in the cold of winter.

How I will use it: next spring I will repeat the test under the same conditions and compare. If the draw is far higher, I will suspect a failing battery or a fault in the charger. If it is far lower, I will check that the battery is actually accepting charge.

Other things I want to measure over the season:

- The voltage of each battery at rest, once a month.
- The time it takes for the main batteries to reach full.
- The idle draw of the charger when nothing is connected, which I have not yet measured.
- The temperature of the case after a long charge, by touch or with a thermometer.

I will write each result with the year and the season, and I will keep the units clear. A number without conditions is hard to use later, so every entry gets a short note about what was connected and what the shed was like.

## Schedule

This is the calendar I will follow. It matches the beekeeping year, since that is what drives how much I use the charger.

Early spring:

- Full check of the unit, cables and socket.
- Run the power meter through a full cycle and record the result in the measurements section.
- Review supplies and replace worn cables.
- Read through the open questions and pick one to work on.

Late spring and early summer:

- Monthly wipe and brush.
- Monthly battery voltage readings.
- Keep one battery fully charged as a reserve against a power cut.

Midsummer:

- Check the shed for heat. A very hot shed is bad for batteries, so I will keep them in the shade and not on the top shelf.
- Look for wax moth or mouse signs near the cables.

Late summer:

- Repeat the voltage readings and compare with spring.
- Plan any purchases for the autumn, such as new cells or cables.

Autumn:

- Thorough clean of the charger and shelf.
- Charge batteries to a sensible level and store them in the crate with silica gel.
- Cover the charger against dust.
- Add a summary line to the history.

Winter:

- Bring batteries indoors before charging.
- Check the shed once a month for damp.
- Think about the ideas list and decide what to do next year.

If a task slips, I do it at the next opportunity and do not try to catch up on everything at once. The aim is a steady habit. Each year I will update this schedule with what worked and what did not, and keep it short enough that I will actually use it.
