---
type: log
status: active
project: gogend-retrofit
area: beekeeping
description: "Log about Gioltrar solar charger."
---

# Gioltrar solar charger log

## Checklist

Things I run through when I visit the Gioltrar solar charger in the shed. It is a grey solar charger, installed in 2024, and it runs from mains power even though the name suggests sunshine. It supports the beekeeping work, so I check it before each stretch of busy hive days.

- Look at the charger from the door and confirm it is still sitting where I left it on the shelf.
- Check that the grey casing is clean and not coated in dust or wax flakes.
- Confirm the mains plug is seated firmly in the socket.
- Check the cable for kinks, chew marks or damp.
- Look at the indicator light and note its state in the log.
- Feel the casing. It should be warm, never hot.
- Check that nothing is stacked on top of the vents.
- Connect the battery pack I plan to use and watch that charging starts.
- Write down anything odd under Observations before leaving the shed.
- Switch off at the wall if I will be away for a long stretch.

I tick these off in my head and only write down the exceptions. If everything is normal, a short line in the History section is enough.

## Supplies

What I keep in the shed so the charger can be used and maintained without a trip to the house.

- A dry microfibre cloth for wiping the grey casing.
- A small soft brush for the vents.
- A spare mains extension lead, rated for outdoor use, in case the wall socket fails.
- Cable ties and a few reusable hook-and-loop straps.
- A roll of electrical tape for temporary fixes only.
- A small plastic box with spare fuses for the extension lead.
- The battery packs that the charger feeds, kept on the lower shelf.
- A notebook and pencil, because the shed is a poor place for a phone when my hands are sticky.
- A torch with a head strap for the dark corner behind the shelf.
- A bag of silica gel sachets to put in the storage box during damp months.

The charger itself gets no consumables. The only things that wear out are the cable and the extension lead, so I keep spares of those. Anything that smells of smoke or burnt plastic gets thrown away immediately, not repaired.

## Safety

The charger is mains powered, so the basic rules for mains equipment apply, even though it is marketed as a solar device. The shed is a working space where I handle honey, wax, smoker fuel and sometimes damp equipment, which makes a few extra rules sensible.

- Never handle the charger with wet or sticky hands. Honey conducts well enough to worry me, and it leaves a film on everything.
- Keep the smoker and its fuel away from the shelf where the charger sits. Hot embers and a warm charger do not belong together.
- Unplug before cleaning anything, including the vents.
- Do not run the charger under a heap of bee suits or blankets. It needs airflow.
- Do not use a damaged cable, even for a quick top-up.
- Keep the plug and socket off the floor, away from spilled water or syrup.
- If the casing smells of hot plastic, unplug and leave it for a while before looking at it.
- Keep a dry powder extinguisher near the shed door, and check the gauge during each season change.

I also keep the battery packs on a non-flammable surface while charging. Beekeeping gear tends to be cardboard, wood and cloth, which all burn well. The charger is grey and easy to overlook in the clutter, so I keep a clear space around it.

## Measurements

I measured the charger with a plug-in power meter while it was charging a battery pack at the busiest part of the cycle. The reading settled and stayed steady.

- Measured power draw of Gioltrar solar charger: 560.30 W

That is higher than I first expected for a charger of this size. It matters because the shed circuit is shared with the lighting and the honey extractor motor. I do not run the extractor and the charger together.

Other things I noted while measuring:

- The casing warmed up gradually and then levelled off.
- The draw dropped as the battery pack filled, so the figure above is the peak I saw, not an average over a whole charge.
- When idle with nothing connected, the draw was tiny, and the meter barely moved.
- The mains socket and plug stayed cool throughout.

I have not measured the output side. A proper test would need a meter on the battery side too, and I may do that later. For now the mains draw is the number I care about, since it affects the circuit load and the running cost.

A small log extract from the measurement session, kept as written in my notebook:

```
session: shed measurement
source: mains socket by the door
load: battery pack, partly drained
meter reading: 560.30 W (peak, steady)
casing: warm, not hot
plug: cool
verdict: ok, do not run with the extractor
```

## Background

The Gioltrar solar charger is a grey solar charger that I installed in the shed in 2024. The area it serves is beekeeping. It was meant to keep the battery packs topped up for the small electric gear I use around the hives, such as the lights for evening inspections, a small fan for the bee brush station, and a few other bits I rely on during the season.

The odd part is the energy source. Although it is a solar charger by type, mine runs from mains. In the early plan I wanted to feed it from a panel on the shed roof, but the roof faces the wrong way and a tall tree shades it for much of the day. Rather than leave the charger unused, I wired it to the mains socket in the shed. That decision made the device dependable but a bit unusual, and I keep this note partly to remind myself why it is set up that way.

The shed is the right place for it. It is dry most of the year, close to the hives, and has a socket already. The charger sits on a shelf near the door so I can reach it with a bee suit on. The grey casing blends into the shed, which is why I sometimes lose track of it among the boxes.

I am not an electrician. I keep to simple, cautious practice and write down what I observe, so that later me does not have to guess.

## Open questions

Things I still do not know, listed so I can check them when I have a free afternoon.

- Why is the measured power draw so high compared with what I expected from a charger of this size?
- Does the draw change much as the battery pack nears full, and by how much?
- Would a roof panel ever be worthwhile if I cut back the tree, or is the shed roof simply a poor location?
- Is the shed circuit properly protected for this load alongside the extractor and the lighting?
- Does the charger behave differently in the cold months, when the shed is much colder?
- How long does the grey casing keep its finish in a shed full of wax dust and smoke?
- Should the charger sit higher on the wall, away from any spilled syrup or water?
- Is there a sensible way to log the charging time without standing in the shed?

I will move each of these into Observations or History once I have an answer. Some may stay open for a long time, and that is fine.

## History

A running record of what has happened with the charger, in rough order and without exact dates, since I tend to remember the sequence better than the calendar.

- **Installation, 2024:** I put the charger on the shelf in the shed and ran it from the mains socket. The first charge worked without trouble.
- **Early use:** I used it mostly before the main inspection days, charging the packs the evening before.
- **First cable fix:** The cable rubbed on the edge of the shelf, so I added a strap and rerouted it to hang free.
- **Vent cleaning:** After the first busy season, I found a layer of fine dust in the vents and cleaned it with the brush.
- **Measurement session:** I measured the power draw and wrote it up under Measurements.
- **Extension lead swap:** I replaced a worn extension lead with a better outdoor-rated one.
- **Shelf move:** I shifted the charger a little way along the shelf, away from the smoker fuel.

Nothing has failed outright. The charger has done its job each season, and the changes so far have all been small tidying jobs. I add a line here whenever I do something that changes how the charger is used or arranged.

## Risks

The main risks are ordinary ones, but the shed setting makes some of them more likely than in a house.

- **Overloaded circuit:** With a measured draw of 560.30 W at peak, running the charger alongside the extractor motor could overload the shed circuit. I handle this by keeping the two apart in time.
- **Fire:** Wax, cardboard, wood shavings and smoker fuel are all flammable. A warm charger buried in clutter is a hazard.
- **Damp:** The shed is dry for most of the year, but a wet spell or a roof leak could reach the socket or cable.
- **Sticky contamination:** Honey and syrup on the plug or casing can attract dirt and, in the worst case, create a path for current.
- **Pests:** Mice like cables. A chewed cable is a real possibility in a shed.
- **Forgetting it is on:** Because it is mains powered, it keeps drawing power if left plugged in. I could leave it running for days without noticing.
- **Dust in the vents:** Poor airflow raises the temperature and shortens the life of the device.

I reduce most of these with the checklist and with tidy habits. The biggest uncertainty is the circuit load, which is why it also appears under Open questions.

## Observations

Things I have noticed while using the charger over time.

- The grey casing is easy to miss on the shelf, and it hides dust well, so I have to wipe it deliberately rather than waiting for it to look dirty.
- The casing warms up during charging, then levels off. It has never felt too hot to hold.
- The indicator light changes state clearly, so I can tell at a glance whether charging is in progress.
- The charger is quiet. Any new noise would stand out, so I treat a hum or buzz as a warning sign.
- It works the same whether the shed is warm or cool, as far as I can tell, though I have not tested hard frost.
- The solar part of the name is mostly decoration in my case, since the mains supply does all the work.
- The cable stays tidy once strapped. When I leave it loose it ends up on the floor.
- Battery packs charge reliably overnight, which fits the way I work.

A short extract from my notebook of one evening visit:

```
visit: evening check
indicator: charging
casing: warm
vents: clear
cable: hanging free, no damage
action: none needed
```

## Ideas

Possible improvements. None are urgent, and I add to this list as they occur to me.

- Fit a simple timer on the mains socket so the charger switches off after a set number of hours.
- Mount a small shelf or bracket higher on the wall, out of reach of spills and mice.
- Cut back the shading tree and test whether a small roof panel could supply some of the energy after all.
- Add a basic plug-in energy meter permanently, so I can see the draw each time I visit.
- Make a clear plastic cover for the plug and socket to keep out sticky splashes.
- Label the battery packs so that I charge them in a sensible order.
- Put a printed card beside the charger with the short checklist, so I do not rely on memory.
- Measure the output side to learn how efficient the charger really is.
- Use a metal tray under the charger as an extra fire precaution.

I will try the timer first. It is cheap, simple and tackles the problem of forgetting it is on.

## Setup

The charger lives on a shelf in the shed, near the door. It is a grey solar charger, installed in 2024, and its energy source is mains. This is how it is arranged now.

- **Position:** On the middle shelf, with clear space on both sides and above, so air can move around the vents.
- **Power:** A single cable runs from the charger to the wall socket nearest the door. I use the extension lead only when the socket is occupied.
- **Cable handling:** The cable is strapped along the shelf edge and hangs free of the floor.
- **Battery packs:** The packs sit on the lower shelf, close enough to connect without stretching the lead.
- **Surroundings:** The smoker, fuel and cardboard boxes are kept on the opposite wall.
- **Safety gear:** The extinguisher hangs by the door.
- **Switching:** I switch off at the wall when I am finished for the day.

To use it, I plug in the pack, check the indicator, and leave it to charge. When the pack is full, I unplug it and switch off at the wall. The routine takes a minute or two and has not changed much since the first season.

## Overview

The Gioltrar solar charger is a grey solar charger used in beekeeping. I installed it in 2024, and it lives in the shed. Despite being a solar charger by kind, its energy source is mains, because the shed roof is badly placed for a panel.

It does its job well. It charges the battery packs for my hive gear, runs quietly, and has needed only small bits of care: cable tidying, vent cleaning and an extension lead swap. The measured power draw is 560.30 W, which is the number to keep in mind when I think about the shed circuit and about what else I run at the same time.

The main points to remember:

- Keep it clear of flammable clutter and sticky hands.
- Do not run it together with the extractor motor.
- Clean the vents and check the cable regularly.
- Switch it off at the wall when it is not needed.

The open questions are mostly about efficiency and the circuit, and the ideas list covers the likeliest upgrades. This note is the place where I keep the whole picture in one spot, so I can pick it up again after a winter away from the hives.

## Costs

I deliberately do not keep exact prices here, since I do not trust my memory for them and receipts are in a different place. What I do track is the kind of cost involved.

- **Purchase:** A one-off cost when I bought the charger in 2024. It was a moderate outlay, in line with other chargers of this type.
- **Running cost:** Because it is mains powered, it adds to the electricity bill. With a measured draw of 560.30 W at peak, the cost depends on how many hours I leave it connected. A timer would help me control that.
- **Maintenance:** Very low. A cloth, a brush and the occasional strap or cable tie.
- **Replacements:** The extension lead and cable are the likeliest items to need replacing, and they are cheap compared with the charger.
- **Opportunity cost:** The shelf space and the socket are used for it, and the socket cannot serve the extractor at the same time.
- **Possible upgrades:** A timer, a permanent meter and a bracket are all small costs. A roof panel would be a larger one, and probably not worth it with the shading.

I think the charger has been good value for the work it does. The biggest saving I can make is simply not leaving it on when it is not charging.

## References

Sources and related notes I rely on for this device. These are plain-text pointers, not links.

- The manual that came with the charger, kept in the plastic box in the shed.
- My general notes on shed electrical safety.
- My notes on the honey extractor, for its power use and when it runs.
- My seasonal beekeeping calendar, which tells me when the busy periods begin and when I need charged packs.
- My notes on battery pack care and storage.
- The measurement session recorded under Measurements in this note.
- The household circuit notes, covering what is protected and what is not in the shed.
- A general guide to safe use of mains equipment in outbuildings, which I reread each winter.

If I add a roof panel or change the circuit, I will update these references and the History section together, so that the two stay consistent.
