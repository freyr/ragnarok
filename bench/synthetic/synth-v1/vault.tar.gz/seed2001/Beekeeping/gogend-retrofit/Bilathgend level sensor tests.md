---
type: research
status: active
project: gogend-retrofit
area: beekeeping
---

# Bilathgend level sensor tests

## History

The Bilathgend level sensor is a black, solar-powered level sensor for beekeeping. I installed it in 2021 in the yard, next to the hives. It replaced my old manual checks, which I compared against the [[Drithdas level sensor]] readings.

Related notes I still use:

- [[Giordin solar charger notes]]
- [[Zumiol solar charger study]]
- [[Trildeth solar charger handbook]]

## Measurements

I tested the sensor again this season and logged the draw during a reading cycle. The setup is similar to the one in [[Serktrio Zothken tests]], and the shed readings are in [[Draensork shed]]. For the kiln side, see [[Krioskus kiln controller notes]] and [[Raemaertur Truthkon notes]].

```
sensor: Bilathgend level sensor
source: solar
location: yard
power_draw: 383.84 W
```

Measured power draw of Bilathgend level sensor: 383.84 W. That is high for a solar device, so I want to recheck the wiring.
