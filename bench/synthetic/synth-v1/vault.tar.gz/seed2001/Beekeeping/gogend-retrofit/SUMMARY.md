---
type: summary
status: active
project: gogend-retrofit
area: beekeeping
description: "Summary about Gogend retrofit."
---

# Summary of Gogend retrofit

## Background

The Gogend retrofit is a beekeeping project. Its goal is a retrofit of the existing setup, and it started in 2020 during the summer season. The lead is the supplier contact, who handles most of the outside parts and answers my questions about what can be fitted to what. I keep this note as the one-page summary of where the project stands, so I can pick it up after a break without reading everything else.

The basic idea was to take the old honey house equipment and bring it up to a level where it works through the whole season without constant babysitting. The old layout grew piece by piece over many years. Nothing was planned as a whole, and several parts were never meant to work together. Heating, moisture control, logging and power all came from different places and were added at different times.

Here are the properties of the project, stated plainly so I do not have to look them up:

- Subject: Gogend retrofit
- Type: project
- Goal: retrofit
- Area: beekeeping
- Start year: 2020
- Season: summer
- Lead: supplier contact

The project began in summer 2020 with a walk through the honey house and a list of what failed most often. The worst offenders were uneven drying temperatures, no record of what happened overnight, and a power supply that depended on the mains being stable. Those three problems shaped almost everything that came after.

Current stage: the work is past the planning and decision phase and is in the middle of fitting and testing. Most of the large pieces are chosen. A few small items are still open, and these are listed under Problems. The project is not finished, but it is no longer at risk of stalling for lack of a plan.

Related notes I keep alongside this one are [[Krioskus kiln controller notes]] for the controller side, [[Liolkrios data logger]] for recording, and [[Tothbi solar charger plan]] for power. The person I turn to when I need a second opinion on hive-side questions is [[Miokulgae Garko]].

## Decisions

The main decision was to go ahead with the retrofit rather than replace the whole honey house setup. Replacing everything would have cost far more and would have thrown away equipment that still works well. The go decision date of Gogend retrofit is 2021-08-19. Everything before that date was survey, comparison and waiting for quotes. Everything after it has been ordering, fitting and testing.

Other decisions, in the order I made them:

- Keep the existing frame and casing, and change only the parts that cause the problems.
- Use the heat exchanger described in [[Lirktrae heat exchanger]] for the warm air side, because it fits the existing duct without cutting new openings.
- Control the kiln side through the approach written up in [[Krioskus kiln controller notes]], so that one controller handles temperature and the fan together.
- Fit the logger from [[Liolkrios data logger]] so that overnight readings are saved and I can review them in the morning.
- Plan the power side around the charger idea in [[Tothbi solar charger plan]], so the system is not tied to the mains alone.
- Use the level readings approach in [[Gindrir level sensor handbook]] for the moisture and tank checks.

I also decided not to automate everything. A few tasks stay manual on purpose, such as checking the frames by eye and deciding when a batch is dry enough. Automation is there to cover the dull and repetitive parts, not to replace judgment. That choice kept the scope smaller and the budget under control.

One more decision worth noting: I let the supplier contact lead the project instead of leading it myself. That means orders and compatibility questions go through one person, and I do not have to chase three different shops. It slowed some early steps, but it avoided a lot of mismatched parts.

## References

These are the notes I use most for this project:

- [[Lirktrae heat exchanger]] for the warm air side and how it connects to the duct.
- [[Krioskus kiln controller notes]] for settings, wiring habits and the logic I chose.
- [[Liolkrios data logger]] for what is recorded, how often, and how I read it back.
- [[Tothbi solar charger plan]] for the power side and the backup idea.
- [[Gindrir level sensor handbook]] for the level and moisture readings.
- [[Miokulgae Garko]] for advice on the practical hive-side questions.

When I need to settle a doubt, I check the controller notes first, because most of the confusing behaviour in this project came from controller settings rather than hardware. The logger note is second, because the recorded readings usually show what really happened. The other notes are more specialised and I open them only when the question is about their topic.

I do not copy details from those notes into this summary. This note only says where things stand. If a detail changes, I update the specific note and leave this one alone unless the stage or the next action changes.

## Problems

Open points at the moment:

- The warm air flow is still slightly uneven at the far end of the room. The heat exchanger works, but the duct run is long, and the last section gets less air than the first. I need to test whether a small change to the duct helps or whether a second outlet is needed.
- The logger sometimes misses a reading when the power dips. This is a small gap, but it makes the overnight record less trustworthy than I want. The charger plan should fix it once it is in place.
- The level sensor needs a calibration pass. The first readings were reasonable but drifted a little over a few days, which is normal for a new fit, but I want to confirm that it settles.
- The controller has a few settings I have not yet tuned for the cooler weeks at the end of the season. It behaved well in warm weather, and I have not seen it under colder conditions for long enough.

Problems already solved, kept here so I do not repeat them:

- The first duct connection leaked air at the joint. A better seal and a firmer clamp solved it.
- An early wiring layout put the logger too close to the fan motor, which added noise to the readings. Moving it solved the problem.
- One delivery arrived with the wrong fitting. The supplier contact sorted it out without a long delay.

None of these problems block the project. They are tuning tasks and small checks. The biggest risk is not a technical one but a seasonal one: if the work slips too far, I will not be able to test under real summer load until next year.

## Supplies

Supplies are handled mainly through the supplier contact, who is also the project lead. I keep a short mental list of what is on hand and what is still needed, and I check it against the plan before each work session.

On hand and fitted:

- The heat exchanger and its duct connection.
- The kiln controller and its wiring.
- The data logger and its mounting.
- The level sensor and its cable.

Still needed or worth having:

- A spare set of clamps and seals for the duct, since those wear out first.
- A small amount of cable and connectors for tidying the wiring.
- The parts for the solar charger side, once the plan in [[Tothbi solar charger plan]] is final.
- A spare sensor lead, because a failure in the middle of the season would be annoying.

I prefer to buy small spare parts in one order rather than one at a time. It saves on delivery and keeps the supplier contact from having to answer the same sort of question repeatedly. Before ordering anything, I check the relevant reference note, so I do not buy a part that does not match what I already fitted.

Storage matters too. The spare parts live in one labelled box in the honey house, away from damp and away from the extraction area. When something is used, I note it down the same day, so the box and the list do not drift apart.

## Next action

The next action of Gogend retrofit is NX-2964.

Before I start it, I want the honey house to be clear and the controller notes open beside me, so I can record any changes straight away. I will also check that the logger is running, since the readings from that session will be the best proof of whether the change worked.

After that action is done, I will update this summary: first the stage, then the open points under Problems, and last the supplies list. If the action shows that the duct needs more work, I will add that as a new open point rather than rewriting the old ones.

## Maintenance

Once the retrofit is complete, the system should need only light, regular care. My plan is simple and based on the season.

Before each summer season:

- Check the duct joints, clamps and seals, and replace any that look worn.
- Clean the heat exchanger surfaces and make sure air passes freely.
- Review the controller settings against [[Krioskus kiln controller notes]] and confirm nothing has drifted.
- Check that the logger saves readings and that its storage is not full.
- Test the level sensor against a manual check and recalibrate if the two disagree.

During the season:

- Look at the logged readings once a week and watch for gaps or strange swings.
- Listen to the fan for changes in noise, which usually come before a failure.
- Keep the area around the equipment free of dust and wax residue.

After the season:

- Switch the system off properly and cover exposed parts.
- Write down anything that went wrong, while I still remember it.
- Update the reference notes and this summary so next year's start is easy.

The aim is that maintenance takes a short, predictable amount of time and never turns into a surprise project. If a task starts to take longer than expected, I take that as a sign that something in the design needs another look.

## Costs

I do not track exact prices in this note. The money side is kept in a separate sheet, and I only record the shape of it here.

The biggest cost items were the heat exchanger and the controller. The logger, the level sensor and the duct fittings were smaller. The power side, once added, will be a medium-sized item, depending on how much capacity I decide to put in.

Overall, the retrofit is much cheaper than replacing the whole setup, which was the reason for choosing it on the go decision. The main risks to the budget are small: spare parts, extra cable, and the chance that the duct needs a second outlet. None of these would change the overall picture.

If the project runs over, the most likely reason is not one large purchase but many small ones. To control that, I group small orders together, check compatibility before buying, and ask the supplier contact before ordering anything that is not on the list. When the project is finished, I will compare the real spending with my first estimate and write one short line about it here, so the next project can use that lesson.
