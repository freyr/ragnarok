---
type: drivers
status: active
project: gogend-retrofit
area: beekeeping
description: "Drivers about Gogend retrofit."
---

# Drivers of Gogend retrofit

## Problems

The Gogend retrofit is a summer project in the beekeeping area. It started in 2020, and the goal is a retrofit of the existing apiary equipment. The lead is the supplier contact, which means I do not run the work day to day. I order, check and record. The supplier contact decides how the work is scheduled and delivered.

The main problems that drive this project are practical ones.

- The old hive bodies and frames do not fit together any more. Some boxes were built by hand, some were bought, and the sizes drifted over the years. Swapping a frame between two hives often needs a chisel or a plane.
- Bottom boards and floors have rotted at the edges. Water stays in the corners after rain, and the wood stays damp well into the season.
- Moving hives is awkward. There are no common lifting points, so every move is a two-person job with straps and a lot of guessing.
- Inspections take too long. Because nothing is standard, I have to think about each hive before I open it, and that slows me down and disturbs the colony longer than needed.
- Spare parts are hard to match. When something breaks in midsummer, I cannot just swap it for a spare.

The goal is to bring the equipment to one standard so that parts are interchangeable, the boxes are dry and sound, and handling is simpler. The retrofit is not about adding new colonies. It is about making what already exists work better.

## History

The idea came up in 2020, after a summer in which three boxes failed within a few weeks of each other. I wrote down what had gone wrong and saw that most of it came from mixed sizes and old wood, not from bad luck.

The first step was a rough survey. I measured every box, floor and lid, and made a simple table of what was standard, what was close, and what was far off. About half of the equipment was close enough to adapt. The rest would have to be replaced.

I then talked to the supplier contact, who had supplied some of the older parts and knew which versions were still made. That conversation settled two things: the supplier contact would lead the project, and the work would be done in summer, when colonies are strong and need the least disturbance from major changes in the brood area. Summer is also dry enough for glue and paint to cure properly.

Since then the project has moved in small stages rather than one big push. Each stage covers a few hives, is done on a dry day, and is followed by a check a week later. Notes from each stage go into my working log.

## References

These are the sources I use when I have a question about the project.

- My own survey table of box, frame and floor sizes, kept with the project files.
- The working log, with one entry per stage and a short list of what was done, what failed and what was left over.
- The supplier contact's delivery notes and parts lists, which I compare against my survey before accepting anything.
- Photos taken before and after each stage, mainly of joints, corners and floors.
- A short checklist for inspections, which I updated after the retrofit changed how I open hives.
- General beekeeping handbooks on my shelf, used only for basic dimensions and for the timing of work in summer.

When two sources disagree, I trust the measurements I took myself over any printed figure, and then I ask the supplier contact.

## Observations

A few things have become clear while the work has been going on.

- Standardizing the frames gave the biggest gain for the least money. Once frames fit every box, inspections became faster and the colonies seemed calmer, because I spent less time prying and shifting.
- Floors made from sealed and sloped boards stay drier. Water runs out instead of pooling, and I see less mould at the entrances.
- Adding simple handles or cleats to every box made lifting safer, and one person can now shift an empty box without help.
- The supplier contact is reliable when a request is specific. Vague requests lead to delays or to parts that are almost right. Requests with measurements and a sketch arrive correct.
- Doing only a few hives at a time keeps the risk low. If something is wrong with a part, I find it on two hives, not twenty.
- Summer weather matters more than I expected. A damp week delays paint and glue, so the schedule needs slack.

I also noticed that old habits die slowly. I sometimes reach for the old way of doing a task, and the new layout needs a few weeks before it feels natural.

## Risks

- **Supply delay.** The supplier contact leads the work, so a late delivery stops everything. Mitigation: order early in the season and keep a small buffer of common parts.
- **Wrong sizes.** A part that is a few millimetres off ruins the idea of a common standard. Mitigation: check every delivery against my survey table before using it.
- **Disturbing colonies.** Work in summer, in the middle of the active season, can stress bees. Mitigation: work in calm weather, keep each job short, and avoid the brood nest where I can.
- **Weather.** Rain or humidity can spoil glue and paint. Mitigation: only treat parts on dry days and let them cure fully before use.
- **Budget overrun.** Replacing more equipment than planned would raise the cost quickly. Mitigation: repair what can be repaired and replace only what fails the survey.
- **Single point of dependence.** If the supplier contact becomes unavailable, I lose both the schedule and the knowledge of which parts are made. Mitigation: keep copies of all parts lists and write down every agreement.
- **Mixed equipment during the transition.** For a while, old and new parts will be in use together, which may cause mistakes. Mitigation: mark retrofitted boxes clearly.

## Lessons

- Measure first, order second. The survey table saved more money than any negotiation.
- Be specific with the supplier contact. A sketch with dimensions is worth more than a long message.
- Retrofit in small stages and check each one after a week. Problems show up quickly and are cheap to fix at that point.
- Standard frames come first. They give the clearest benefit and make everything else easier.
- Keep the log current. I forget details within a few weeks, and the log has answered many later questions.
- Leave slack in the summer schedule for weather.
- Accept that some old equipment is simply not worth saving. Repairing a worn box that will fail again next year costs more in time than replacing it.

## Budget

The budget of Gogend retrofit is 5583.57 EUR. It covers the replacement parts, sealing and paint, handles and cleats, fixings, and the delivery charges from the supplier contact. My own labour is not counted.

Constraints that shape how the money is spent:

- Repair before replacing, and replace only what fails the survey.
- Spend first on frames and floors, because they give the biggest return.
- Keep a small reserve inside the total for parts that turn out to be wrong or damaged.
- Record every purchase in the working log with the stage it belongs to.

Success is measured in plain terms rather than in a single figure:

- Every hive in the apiary uses the same frame and box standard.
- No floor holds standing water after rain.
- Any box can be lifted safely, and one person can move an empty one.
- A routine inspection takes noticeably less time than before the retrofit.
- The total spent stays within the budget, and the work is finished within the summer season.

If spending approaches the budget before all hives are done, I stop, review the log and the survey table, and decide with the supplier contact which hives wait until the next summer.
