---
type: drivers
status: active
project: fita-retrofit
area: beekeeping
description: "Drivers about Fita retrofit."
---

# Drivers of Fita retrofit

## References

These are the notes and sources I keep next to this project. The Fita retrofit is a project with the goal retrofit, in the area of beekeeping. It started in 2020, runs in the summer season, and is led by the accountant.

- The hive inspection log from the last several seasons, kept in a paper notebook and copied into a spreadsheet each winter.
- My sketch of the apiary layout, with the stand positions and the path from the shed to the yard.
- The supplier price lists I saved when I was comparing frames, boxes and floors.
- The notes on how the old hives were built, including which boxes share the same dimensions and which do not.
- The beekeeping club handout on wintering and ventilation, which I used when deciding what to change.
- The spreadsheet of costs, which the lead keeps up to date and which is the source of the budget figure below.

I do not copy the content of those documents here. This note is only about the drivers: why the project exists, what limits it, what it may cost and how I decide it worked.

## Background

The Fita retrofit is about taking the existing hive stock and bringing it up to a common standard instead of replacing it. Over the years the apiary grew in an untidy way. Boxes were bought secondhand, some were built at home, and a few were given to me. The result is a mix of sizes, floors and lids that do not swap between colonies. That makes every inspection slower and every repair a small custom job.

The goal is plain: retrofit. I want the existing equipment to share the same fittings, so that a box, a floor or a lid from one stand fits on any other stand. I do not want to start over with new hives, because most of the wood is still sound.

The project started in 2020. It is a summer project because that is when the colonies are strong, the weather is dry enough for painting and gluing, and I can do the work without leaving bees exposed in the cold. The lead is the accountant. That choice was deliberate. The project is mostly about spending money in a controlled way over several seasons, and I wanted someone who watches the numbers to hold the pen, not someone who would buy one more nice tool every time.

The main drivers, in order of weight:

1. Interchangeability. Parts should fit anywhere in the apiary.
2. Colony health. Better floors and ventilation should help the bees get through winter.
3. Time saved. Fewer special cases means shorter visits.
4. Cost control. The work should be done within the budget, in stages, without borrowing.
5. Safety. Nobody should get hurt while cutting, lifting or working near the colonies.

## Lessons

Some things I learned in the early seasons that still drive the decisions today.

- Measure first, then buy. In the first summer I ordered parts based on what I thought the boxes measured. Several did not fit. Now every box is measured and written down before any order.
- Do not retrofit a colony in the middle of a strong flow. The bees are busy and defensive, and the disruption costs honey. Quieter weeks are better.
- One stand at a time. Trying to rebuild three stands at once left me with open boxes and no spare parts. Finishing one stand fully before starting the next is slower on paper and faster in practice.
- Keep a spare set. A few ready boxes and floors let me swap a colony quickly instead of working on it in the open.
- Paint needs time. Rushing the drying meant sticky lids and bees stuck to the finish. I now leave extra days.
- Write down every change. When I did not, I could not later say which colony had which floor, and the winter results were useless for comparison.
- Let the accountant say no. Several times the lead stopped a purchase that sounded useful but did not serve the goal. Each time it was the right call.

## Safety

Safety is a constraint on the project, not an afterthought.

- Wear a full veil and gloves whenever a colony is open, even for a short job. Retrofit work involves more banging and shifting than a normal inspection, and the bees notice.
- Lift with a second person when a box is full. A full box is heavy enough to hurt a back, and a dropped box is a risk to the bees and the person.
- Use eye protection and hearing protection when cutting or sanding wood. Dust from old timber can also contain old paint, so I wear a mask.
- Keep a smoker lit and safe, on bare ground, away from dry grass and stacked wood. Summer is dry and a stray spark is a real danger.
- Keep a first aid kit at the shed, and know who is allergic. Anyone helping must tell me before they come into the yard.
- Do not work alone with power tools. Someone should at least know where I am.
- Keep children and pets away from the work area while boxes are open or tools are out.
- Store paint, glue and solvents closed and away from the colonies. Ventilate the shed when using them.

## Budget

The budget of Fita retrofit: 29734.14 EUR

This is the ceiling for the whole project, not a target to reach. The lead tracks it in the cost spreadsheet and reports to me before each purchase round. Rules we follow:

- Spend in stages, tied to the summer work plan, so that money is not sitting in unused parts.
- Compare at least two suppliers for anything bulky.
- Record every receipt against a stand, so the cost of each part of the work is visible.
- Keep a small reserve inside the ceiling for repairs that turn up when old boxes are opened. Rotten wood is always found after the plan is made.
- Do not use the budget for general apiary upkeep. If it is not part of the retrofit, it is paid for elsewhere.

If a purchase would push the total over the ceiling, the work is reduced or delayed to another season. The ceiling is not raised.

## Schedule

The schedule follows the summer season, because that is when the work is practical.

- Early summer: measuring, checking the stock and ordering parts that are needed.
- Midsummer: the main retrofit work, one stand at a time, during quiet weeks.
- Late summer: painting touch-ups, tidying, and recording what changed.
- After the season: review of costs and results, and planning the next summer.

The project started in 2020 and is meant to be spread over several seasons, not squeezed into one. Each summer has a limited scope, so that the apiary is never left half done going into winter. The rule is simple: whatever is opened in a season must be closed and working before the season ends.

## Observations

What I have noticed that affects the drivers.

- The colonies that moved to the common fittings first were easier to inspect, mostly because I no longer had to look for the right lid.
- Old floors were the most common weak point. Moisture and rot were more frequent there than anywhere else.
- Mixed equipment caused most of the wasted time. A job that should take a few minutes took much longer when parts did not fit.
- The summer weather decides the pace more than the budget does. A wet spell can stop painting for a week.
- Helpers are most useful for lifting and holding, not for fine fitting. I keep the fitting for myself.
- The accountant's records have made it much easier to say what a given stand cost, which was never possible before.

## Tools

The tools that matter for this project:

- Tape measure, square and a marking pencil for the measuring stage.
- Hand saw and a small power saw for trimming.
- Drill and driver with a set of bits.
- Sanding block and a power sander for old finishes.
- Wood glue, clamps and screws for repairs.
- Paint brushes, scrapers and a covered work table.
- Hive tool, smoker, veil, gloves and a soft brush.
- A notebook and the cost spreadsheet, which are as important as anything made of steel.
- A trolley for moving boxes between the shed and the yard.

I try not to buy a new tool unless it is needed for more than one job. The lead reviews tool purchases like any other cost.

## Ideas

Things I might do, not yet decided.

- Mark every box with a short label burned or painted on the side, so it is clear which stand it belongs to.
- Build a small jig for cutting parts to the same size every time.
- Set up a simple rotation so each stand gets one upgrade per summer in a fixed order.
- Ask the beekeeping club whether other members want to share bulk orders to lower the cost.
- Make a one-page checklist for the retrofit of a single colony, to carry in the yard.
- Keep a shelf in the shed for spare parts, sorted by type.
- Test one different kind of floor on a single colony and compare it before changing the others.

## Problems

Problems that threaten the drivers.

- Hidden damage. Old boxes often turn out worse than they looked, which eats into the reserve in the budget.
- Dimension drift. Home-built boxes are not exactly the same, even when they were meant to be, so some parts need trimming.
- Weather. Rain and humidity delay painting and gluing, and the summer window is short.
- Time. I do this next to other work, so a busy month can stall everything.
- Supplier delays. Parts that arrive late can leave a stand open longer than I want.
- Scope creep. It is tempting to improve things that are not part of the goal. The lead and this note are there to push back.
- Unclear success. Without clear measures it is hard to say whether the retrofit helped the bees or only made the boxes look tidier.

How I measure success:

- Every box, floor and lid in a finished stand fits any other finished stand.
- Total spending stays within the budget.
- The time spent on a routine inspection goes down compared with the early seasons.
- Winter losses in retrofitted colonies are no worse than in the others, and ideally better.
- No injuries and no lost colonies caused by the work itself.

## History

- 2020: The project started. The first summer was mostly measuring and mistakes with parts that did not fit.
- The following summers: the work moved forward one stand at a time, with the accountant keeping the costs and approving each round of purchases.
- Over time the method settled into the pattern described above: measure first, work in quiet weeks, finish each stand before starting the next.
- Each year ends with a short review of what was spent, what was finished and what was learned, and those lessons feed back into the drivers in this note.
- The current state is a mix of finished stands and stands still waiting for their turn, and the project continues in the summer season.
