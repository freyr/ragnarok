---
type: research
status: active
project: fita-retrofit
area: beekeeping
description: "Research about Krissensal solar charger."
---

# Krissensal solar charger study

## Setup

The Krissensal solar charger is a black, mains-fed unit that sits in the loft above the workshop. I installed it in 2019. It is a solar charger by kind, and I use it for beekeeping work: keeping the batteries topped up for the small gear I carry out to the apiary. The properties are easy to mix up, so here they are in one table.

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | beekeeping |
| Color | black |
| Energy source | mains |
| Year installed | 2019 |
| Location | loft |

The "solar charger" label and the "mains" energy source look odd side by side. I record both as they are. The device is a solar charger by kind, but in my loft it runs from mains. I do not treat that as a contradiction to solve in this note. It is simply how the unit is set up, and the rest of the study describes it that way.

The unit is black, a matte case with no visible branding on the front. In the loft that is a small advantage, because it does not catch the eye when I climb up with a torch. It sits on a shelf near the rafters, away from the roof edge, where the air stays dry for most of the year.

The setup, in the order I did it in 2019:

- Fixed a shelf bracket to a rafter, well clear of the roof slope.
- Ran a mains lead from the existing loft socket, tied up so nobody trips on it.
- Placed the charger on the shelf with the vents facing open space.
- Labelled the lead at both ends so I know what to unplug first.
- Added an entry for it in [[Zothvun loft log]].

I picked the loft because it is quiet and out of the way of the hive tools. It is also close to the place where I keep the frames and feeders. Carrying a charged battery down one flight of stairs is easier than hauling the whole unit out to the apiary.

## References

These are the notes and sources I keep next to this study. They are all my own files, so they are as reliable as my handwriting.

- [[Raemaertur Truthkon notes]]: my general notes on the charging habits I settled on. They cover what to plug in first and what to leave alone overnight.
- [[Liolkrios data logger]]: the logger I use to see how the loft temperature behaves. It matters here because the charger shares the loft with it.
- [[Zothvun loft log]]: the running log of everything that happens up there, including each time I touched the charger.
- [[Mastend Runpith]]: the person whose advice I leaned on when I first chose where to put the unit. I wrote down his comments about airflow and kept them.
- [[Nevirkun kiln controller study]]: a sister study on another piece of kit that also runs from mains. I compare the two when I wonder whether a habit is specific to this charger or just general good practice.

The first thing I look up when something seems off is the loft log, because it tells me what changed. The second is the logger data, because loft heat explains many small problems. The notes on charging habits come last, since they describe how I normally work rather than what went wrong.

I also keep the paper that came with the charger in a folder in the workshop. I do not copy any identifying numbers from it here. If I need them, I go to the folder. This note is for the behavior of the unit in my loft, not for catalog data.

## Maintenance

Maintenance on this charger is light. Because it takes mains power and lives in a dry loft, the main enemies are dust, heat and clutter. I do not do anything clever. I do a few plain checks and write them down.

What I check each time I go up:

- The case: is it still black and clean, or is it covered in grey dust? Dust on a black case shows up quickly, which is useful.
- The vents: nothing leaning against them, nothing stored in front of them.
- The mains lead: no kinks, no chew marks, no tight bends against the rafter.
- The connection point: the plug sits firmly and does not feel warm.
- The surroundings: no loose cardboard, no spare foundation sheets, nothing that can burn lying close by.

I wipe the case with a dry cloth. I do not use water or spray in the loft, even a little, because the whole point of the location is that it stays dry. If something sticky has landed on the case, usually propolis or wax from my gloves, I let it harden and flake it off rather than smear it.

Heat is the thing I watch most. The loft can be warm in the summer months, and the [[Liolkrios data logger]] shows me when it has been unusually hot. On those days I avoid leaving the charger working hard. I just let it rest and come back to it in the evening.

Over the years I have learned a few habits that I now follow without thinking:

1. Never stack anything on the charger, even for a minute.
2. Never leave a battery connected through a long absence without noting it in the log.
3. Always unplug at the wall before touching the lead.

When I do any of these things, I add a line to [[Zothvun loft log]]. The line is short: what I did, and whether anything looked different. Over time these lines have shown me that nothing about the unit changes very much, which is exactly what I want from a device that sits in a loft.

## Schedule

I keep the schedule loose because the unit does not demand much. It follows the beekeeping year more than the calendar. The busy season for gear is spring through late summer, and the quiet season is winter, when the hives are closed up and I only visit now and then.

The routine looks like this:

| When | What I do |
|---|---|
| Start of the season | Climb up, clean the case, check the lead and the vents, test the charger with one battery |
| During the active season | Look in every time I fetch or return a battery, and run a quick visual check |
| After a hot spell | Compare the loft readings from the logger with my notes and check that nothing looks warped or discolored |
| End of the season | Charge everything fully, then switch off at the wall and leave the unit idle |
| Winter | One short visit to make sure the loft is still dry |

The seasonal start is the most important visit. I do not rely on memory, so I read the last entries in [[Zothvun loft log]] before I go up. That tells me where I left things in autumn. If there was a worry at the end of the previous season, it is there in my own words.

During the season I do not follow a fixed day. I tie the check to a task: whenever I take a battery out for the apiary, I glance at the charger. That keeps the habit natural and costs me nothing. If I forget for a few weeks, nothing bad has happened so far, but I try not to leave a long gap.

At the end of the season I follow the same logic as for other mains gear. I compare notes with the [[Nevirkun kiln controller study]], because that device has a similar rest period, and I use the same simple shut-down sequence. Unplug, wipe, cover nothing, and leave the area tidy.

## Background

I bought the Krissensal solar charger because I wanted one reliable place to keep my apiary batteries charged without carrying them into the house. Beekeeping is the area where it earns its keep. Torches, a small smoker fan, a handheld light for dusk inspections and a few other bits all depend on power, and a flat battery on a day when the weather finally allows an inspection is annoying.

The year I installed it was 2019. Before that, I charged things on the kitchen counter, which meant cables everywhere and a constant argument about space. Moving the process to the loft solved that. The loft was already where I stored supers and spare frames, so it fit the way I work: everything for the bees lives in one place.

Mastend Runpith gave me the advice that shaped the decision, which I recorded as [[Mastend Runpith]]. His main point was simple: put power equipment where air can move and where you will notice a problem early. The loft meets the first condition, and the second I handle with regular visits and a log. I did not follow every suggestion he made, but I kept the core of it.

The odd detail, and the reason I started this study at all, is that a device sold as a solar charger runs from mains in my setup. I have not tried to turn it into something else. I decided it was more useful to describe how it behaves in this configuration than to wonder whether it should be different. That attitude carries through the whole note: record what is true, and avoid guessing about what is not.

I also wanted the study to be useful when I forget details. In a few years I will not remember why the shelf is where it is, or why the lead is tied up the way it is. Writing it out now means I can read it later and understand my own reasoning. The earlier notes in [[Raemaertur Truthkon notes]] helped here, since they already explain the habits I fall back on.

## Tools

I use very few tools for this charger, and most of them are already in the workshop. Keeping the list short means I can carry everything up to the loft in one trip.

- A dry cloth for wiping the black case.
- A small soft brush for dust around the vents.
- A torch, because the loft light is poor at the far end.
- A plastic scraper for propolis or wax that has hardened on the case.
- Cable ties for keeping the mains lead tidy against the rafter.
- A notebook, or my phone, to add an entry to [[Zothvun loft log]] before I come down.

I also rely on the [[Liolkrios data logger]] as a tool of sorts. It is not part of the charger, but it gives me the loft conditions behind a problem. When the charger case feels warmer than I expect, I do not guess. I look at what the loft has been doing and then decide whether to leave the unit idle for a while.

For comparison, the [[Nevirkun kiln controller study]] uses a similar kit list, with the same cloth, the same torch and the same notebook habit. That overlap is useful, because it means one small bag covers both jobs. I keep the bag by the loft hatch so it is always where I expect it.

A few things I deliberately leave out of the tool list. I do not bring a ladder-mounted work light, since the torch is enough. I do not bring cleaning sprays, because I want the loft to stay dry. I do not bring any test gear unless I have a specific reason, and if I do, I note the reason in the log so I remember why.

## Ideas

The Krissensal solar charger is a solar charger in the beekeeping area of my notes. It is black, it has been installed in the loft since 2019, and its energy source is mains. That last property looks odd for a solar charger, and most of my ideas come from it. The unit is built as a solar charger, but in my setup it is fed from mains, so I treat it as a charging station for beekeeping gear and not as a panel-fed system.

Ideas I want to try or keep in mind:

- Use the loft as a single charging point for everything electric in the apiary: the fence energizer battery, the head torch, the hive scale display, and the small handheld radio I carry on long inspection days.
- Add a simple wall label with a list of what is allowed to charge on the unit, so nobody plugs in something that does not belong.
- Put a plain mechanical timer between the wall socket and the charger, so it does not sit powered through the whole winter when there is nothing to charge.
- Test whether a real solar panel could ever feed it. The kind of device says solar, the loft has a roof window, and a proper trial would show whether the mains feed is truly needed.
- Keep a small tray under the charger for cables and adapters, in the same black as the unit, so the loft shelf stays tidy.
- Write a one-page routine for the end of the season so the batteries go into storage at a sensible charge level.

One idea I dropped: moving the charger down to the shed. The shed is damp and the loft stays dry, which is the main reason the unit has worked so long in the loft. I would rather keep the dry spot and fix the other problems.

A second idea I am still thinking about is a rotation system. I own more batteries than the charger can handle at once, so a rotation sheet taped near the unit would tell me which battery is next. Nothing fancy: a column for the battery name, a column for the last charge, and a column for where it was used.

## Checklist

I use this list before the main season and again after it. It is short on purpose, because a long list gets ignored.

Before the season:

- Check that the unit is still in the loft, on its shelf, and not blocked by boxes.
- Look at the mains cable along its whole length for cuts, chewing marks, or a flattened bend.
- Confirm the unit's color and markings are still readable. It is black, so the small labels fade into the case; I redo them with a white paint pen when needed.
- Plug in and watch the indicator for a few minutes before trusting it with a real battery.
- Charge each battery once and note how long it takes compared with last year.
- Wipe dust off the vents with a dry brush.
- Make sure the loft is dry: no drips under the roof window and no damp smell.

After the season:

- Unplug the unit and leave it dry.
- Store the batteries partly charged, not empty and not full.
- Write one line in the notebook about anything that behaved oddly.
- Cover the unit with a cloth so loft dust stays off it.

A quick summary of the subject properties so I do not have to search for them elsewhere:

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | beekeeping |
| Color | black |
| Energy source | mains |
| Year installed | 2019 |
| Location | loft |

## Lessons

The first lesson is about the energy source. I assumed for a while that a solar charger would run on light and cost me nothing. In my case the unit takes its power from mains, so it does cost something, and I should treat it like any other plug-in appliance. Once I accepted that, I stopped being surprised by the loft's electricity use and started using the timer idea.

The second lesson is that black is a poor choice for a unit in a loft. The case collects heat in summer, and the loft already gets warm under the roof. I noticed the case was hot to the touch after a long charge on a sunny afternoon. A pale cover or a bit of space around the unit helps. I now leave a hand's width of clear space on every side.

The third lesson is about location. The loft has worked well since 2019 for three reasons:

1. It is dry, which protects the electronics and the batteries.
2. It is out of the way of children and pets.
3. It is close to the hive equipment I store there, so I charge things while I sort frames.

The fourth lesson is that beekeeping charging needs are bursty. Nothing is needed in winter, a lot is needed in spring, and in high summer I need steady top-ups. A charger that is simple and always ready beats a clever one that needs setup each time.

The fifth lesson is about writing things down. Whenever the unit has misbehaved, I only managed to work out why because I had a note of what was plugged in and when. The notebook next to the charger has paid for itself many times over.

A smaller lesson: do not leave a battery on the charger for days "just in case". It does not help, and the battery gets warm. I now charge, then unplug.

## Open questions

- Could a real solar panel supply this unit, given that its kind is solar charger but its energy source is mains? I have not tested it and do not know whether the unit accepts any other input.
- How much does the unit actually draw from the wall over a season? I have never measured it. A plug-in energy meter would answer this.
- Is the heat from the black case a real risk to the battery or only an annoyance? So far nothing has failed, but I have no proof it is safe.
- Would the unit do better in a different spot in the loft, away from the roof window and the afternoon sun?
- How long can I expect it to keep working after the years it has already done since 2019?
- Should I replace it with a unit meant for mains from the start, and keep this one only as a backup?
- Is the loft wiring good enough for a permanent charging point, or should someone look at the socket? I would rather ask a qualified electrician than guess.
- Do the other beekeepers I know keep their chargers in the loft or in a heated room, and have they seen any winter trouble?

## Problems

The problems I have met so far are mostly small, but they repeat.

- **Heat.** In summer the loft is hot, and the black case adds to it. I have taken to unplugging the unit on the hottest days.
- **Dust.** The loft is dusty from stored boxes and old frames. Dust gets into the vents and onto the plug. I clean it before each season.
- **Cable wear.** The mains cable runs along a beam and gets pulled when I move boxes. I have rerouted it once and want to fix it to the beam with clips.
- **Forgotten batteries.** Batteries left on the unit for too long, because I forgot them during a busy week in the apiary.
- **Hard-to-read labels.** The unit is black and the markings are faint, so I sometimes plug a lead into the wrong place before checking.
- **Confusing name for the kind.** The unit is a solar charger, yet it runs on mains. Anyone borrowing it, or reading my notes later, may expect it to work in the sun. I now keep a label on the shelf saying that it needs a wall socket.
- **Poor light.** The loft light is weak, and reading the indicator in the evening is awkward. A small clip lamp would help.

None of these has stopped me from working, but together they explain why I want a firmer routine and a tidier shelf.

## History

The unit was installed in the loft in 2019. At the time I wanted a fixed place to charge beekeeping equipment and was tired of carrying batteries into the kitchen. The loft was already my storage place for hive parts, so it made sense to put the charger there.

In the first years I used it only for the fence energizer battery. As the apiary grew, I added the head torch, the radio, and the scale display. The unit has taken that extra load without complaint, though it runs hotter than I would like.

Over the years the main changes have been to the surroundings and not to the unit itself:

- The mains cable was rerouted along the beam after it got caught.
- A shelf was added so the charger no longer stands on the floor.
- A cloth cover became part of the end-of-season routine.
- The checklist above grew out of a few forgotten batteries and one dusty season.

The unit is still black, still in the loft, and still fed from mains, exactly as it was when it went in during 2019. Looking back, the main thing I would change is the early assumption that it would run on sunlight. Knowing from the start that it needs a wall socket would have saved me a lot of guessing, and it is the reason this study exists. My next steps are to measure the real use of power, tidy the cable, and decide whether this unit stays or gets a mains-only successor.

## Costs

The Krissensal solar charger was installed in 2019 in the loft. It is black, it is a solar charger used for beekeeping, and its energy source is mains. That last point still strikes me as odd for a device with "solar" in the description, and it affects how I think about the running costs.

Because it runs from mains, the cost is not zero. The charger does not live off the roof, so every hour it is on shows up on the electricity bill. I did not have a good feel for how much until I measured it (see Measurements below). The figure is higher than I expected for a small beekeeping accessory.

Here is how I break the costs down for my own records. I have deliberately left out exact prices, because I no longer trust my memory of what I paid in 2019 and I do not want invented numbers in my notes.

| Cost item | Type | Notes |
|---|---|---|
| Purchase | One-off | Paid in 2019, receipt not found |
| Installation in the loft | One-off | Done by me, only my time and a few fixings |
| Mains electricity | Running | Depends on how many hours it is switched on |
| Replacement cables | Occasional | Loft temperature swings are hard on insulation |
| Cleaning and checks | Time only | Done a few times a year |

The main thing I take from this table is that the running cost matters more than the purchase cost over the years. After several seasons of use, electricity is probably the biggest part of the total. If I ever replace the unit, I should compare the mains draw first and the sticker price second.

A few practical ways to keep costs down:

- Switch the charger off completely during the winter months when the hives are quiet.
- Put it on a timer so it only runs when I actually need the battery packs topped up.
- Check the cables each spring so I do not pay for a failure later.
- Avoid leaving it on standby overnight without a reason.

## Observations

These are the things I have noticed over the years since 2019. They are informal and based on what I saw while working in the loft.

The first observation is about the location. The loft is dry most of the year, which suits a black device with vents. In midsummer, though, the loft gets very hot. The black casing absorbs heat, and on warm afternoons the unit feels noticeably warm to the touch even when it is idle. I try not to leave anything flammable or dusty next to it.

The second observation is about dust. A loft collects dust, and wax flakes and propolis bits come up from the beekeeping tools I store nearby. A thin layer settles on the casing and around the vents. I wipe it off during each check. When I skipped a check one season, the fan noise seemed louder, which I take as a sign of clogged vents.

The third observation concerns the name and the behaviour. The word "solar" in the description made me expect it to work from daylight. It does not, in my setup. The energy source is mains, and I have never seen it do anything useful from light alone. I now treat it as a mains charger that happens to be part of my beekeeping kit.

Other things I noted:

- The unit starts reliably, even after a long idle period in cold weather.
- The indicator light is easy to see in the dark loft, which helps when I check it by torch.
- The casing has not faded, since black hides sun and age well.
- The cable run to the wall socket is the weakest part, so I keep it clear of the floor.
- Nothing about it has needed repair so far.

I also watched how it behaves when several things are connected. When I charge more than one pack at once, it warms up faster and the fan runs longer. For that reason I now stagger the charging instead of connecting everything together.

## Overview

The Krissensal solar charger is a device of the kind "solar charger", and I use it in the area of beekeeping. It is black. Its energy source is mains. I installed it in 2019, and it sits in the loft.

I wrote this study to pull together what I know about the unit in one place. Before this, my knowledge was scattered across a few scribbled lines and some memory. The aim is practical: understand what it costs to run, what I need to keep it working, and what it really draws from the wall.

Summary of the properties:

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | beekeeping |
| Color | black |
| Energy source | mains |
| Year installed | 2019 |
| Location | loft |

The role of the charger in my beekeeping is support work. It keeps battery packs ready for the small tools and lights I use around the hives, and for equipment I keep in the loft. It is not part of the hive itself and it does not touch the bees. It is simply infrastructure that makes the season easier.

What I like about it: it has lasted since 2019 without trouble, and it is simple. What I dislike: the name suggests solar operation that I have not seen, and the mains draw is bigger than I would like. Both points are covered in the sections around this one.

## Supplies

This section lists what I keep on hand so the charger stays usable. None of it is expensive, and most of it is ordinary household stock.

Supplies for maintenance:

- A soft dry brush for dust on the casing and vents.
- A few lint-free cloths for wiping the black surface.
- A small vacuum or a hand blower for the vent openings.
- Spare mains cable of a suitable rating, in case the original wears out.
- Cable ties and clips to keep the lead off the loft floor.
- A torch, because the loft lighting is poor.
- A timer plug so that mains use can be limited.

Supplies for the beekeeping side:

- Battery packs that the charger serves.
- Labels so I know which pack was charged when.
- A small box to keep the packs together and away from loose wax and dust.

I keep these in one crate near the loft hatch so I do not have to search. I check the crate at the start of each season and replace anything worn. The one item I have had to replace more than once is the cloth, since propolis ruins it. The brush lasts for years.

One rule I follow: never use water or a damp cloth while the unit is plugged in. I switch off at the wall and unplug first, then clean, then let it dry before plugging back in. It is a simple habit, but it matters because the energy source is mains.

## Measurements

I measured the electricity use of the Krissensal solar charger with a plug-in power meter between the wall socket and the unit. I did this in the loft, with the charger running its normal load.

The measured power draw of Krissensal solar charger: 878.38 W.

That is a lot more than I had assumed. I had guessed something small, like a standard phone charger, but the reading shows a device that behaves more like a heater or a power tool. This confirms my concern from the Costs section: the running cost is real, and it depends mostly on how long I leave the unit switched on.

How I took the reading:

- I plugged the meter into the wall socket and the charger into the meter.
- I connected the battery packs the way I normally do.
- I waited until the fan had settled into steady running.
- I read the display several times and noted the value that it showed most of the time.

Things to keep in mind when reading this figure:

- It is a single measurement under one load, so it is not a full profile.
- The draw will probably be lower when the packs are nearly full.
- Idle draw is a separate question, and I have not recorded it yet.
- The loft is hot in summer, and heat may change the fan behaviour and the reading slightly.

What I plan to do next: repeat the test in winter, measure the idle draw with nothing connected, and test with only one pack attached. Then I can compare the numbers and decide whether a timer or a replacement is the better answer. For now, the value to remember is 878.38 W, and the practical lesson is to switch the charger off when it is not doing useful work.
