---
type: summary
status: active
project: fita-retrofit
area: beekeeping
description: "Summary about Fita retrofit."
---

# Summary of Fita retrofit

## Observations

Fita retrofit is a project in the beekeeping area. Its goal is a retrofit: we are not building a new apiary setup, we are fitting new parts to an existing one. The project started in 2020 and its season is summer, so almost all the real work happens when the hives are busiest. The lead is the accountant, which explains why the notes lean toward costs, records and sign-off rather than hardware detail.

What I see when I read the whole project file back:

- The project has moved from planning into a cautious build stage. The go decision has been made and logged, and the first practical step is now waiting.
- Most of the hard thinking was done early, in the first summers. Since then the work has been slow upkeep of the plan, not new design.
- The accountant lead keeps the paperwork tidy. Every purchase and every change has a line in the record, and that has saved me from arguing with myself about what was agreed.
- Water handling is the part that keeps coming back. Several notes touch on levels, valves and air supply, because the retrofit relies on those parts behaving well in summer heat.
- The bees themselves do not care about any of this. The work has to fit around their calendar, not the other way round.

A short stage statement, so I can find it quickly later: the project is past the decision point, the plan is stable, and the work is waiting on one concrete next action, listed further down.

Earlier trials gave me the base of what I know. The notes in [[Gundpio pond tests]] are still the best record of how the water side behaves outdoors, and I keep going back to them when something looks odd on site.

## Checklist

This is the running list of what is done and what is not. I keep it short on purpose.

Done:

- Goal fixed as a retrofit, not a rebuild.
- Area confirmed as beekeeping, so all rules of thumb come from that side of my notes and not from general workshop habits.
- Summer chosen as the working season, and the plan trimmed to fit it.
- Lead assigned to the accountant, with a clear understanding that the lead signs off on spending and keeps the log.
- Early water trials written up and filed.
- Level sensing options compared and narrowed down.
- Go decision recorded (see Decisions).

Not done yet:

- The first hands-on step of the retrofit itself.
- A full dry run of the air and valve side with everything connected.
- A final tidy of the tool list so nothing is borrowed and forgotten.
- A written handover so that someone else could repeat the work from my notes alone.

Small habits that belong on every pass of the checklist:

- Read the last entry in the log before starting anything.
- Take the tools listed in the Tools section and check each one is on the bench.
- Write down what changed, even if it feels minor.
- Close the lid on the day by noting what is left half-finished.

## Open questions

These are the things I still cannot answer from my notes. Each one needs either a test or a conversation.

1. Which level sensor will be the main one? I have notes on three candidates: [[Drursus level sensor]], [[Susrion level sensor]] and the approach in [[Tithbun level sensor plan]]. Each has strengths. One reads well but is fussy about mounting. One is simple but I have little field history with it. The plan note is a method more than a product, and I am not sure it fits a retrofit without more cutting than I want.
2. Will the valve actuator hold up through a long hot spell? My notes on [[Murfes valve actuator]] are positive, but they come from mild days, not the hottest part of summer.
3. Is the air supply strong enough without being noisy near the hives? The material in [[Lesglugen air compressor notes]] covers the basics, yet I never wrote down how the compressor behaves with a long hose run in this layout.
4. Who else needs to see the plan before work begins? The accountant lead has the budget view, but I have not checked whether anyone else, such as a neighbour or a fellow keeper, should be told about noise or access.
5. How much of the existing setup can stay untouched? The retrofit idea only works if I leave most of the current arrangement alone, and I have not walked the whole site with that question in mind.

Each of these should end as either a decision entry or a lesson. Until then they stay here.

## Risks

Risks are listed roughly in the order I worry about them.

- **Heat.** Summer is the season, and summer is hard on plastics, seals and electronics. Anything that works in spring may behave differently in the afternoon sun. Mitigation: shade where possible, and run tests at the hottest time of day, not only in the morning.
- **Disturbing the colonies.** Any work near the hives can upset the bees. Vibration, noise and smell all count. Mitigation: work early or late, keep movements slow, and never run the compressor close to the entrances.
- **Scope creep.** A retrofit invites "while we are here" additions. The accountant lead is useful against this, since every addition has to be justified in the log. Mitigation: new ideas go into the Ideas section, not into the plan.
- **Sensor mismatch.** Choosing the wrong level sensor means doing part of the work twice. Mitigation: do not commit to one until a short trial has been done on site.
- **Single point of failure.** If the valve actuator or the air supply fails, the whole arrangement stalls. Mitigation: keep a manual fallback and note how to switch to it.
- **Lost knowledge.** The project spans years, and I forget details. Mitigation: keep this summary current and link to the detail notes, such as [[Zaenpapath Kolbuth]], instead of copying their content here.
- **Budget drift.** Small purchases add up. Mitigation: the lead reviews the log before any new spending.

## Next action

The next action of Fita retrofit is NX-6783.

I keep this section to a single item on purpose. Everything else in the note is context for it. When that action is finished I will replace the entry here with the next one, and move the finished item into the Checklist as done. If the action turns out to be blocked, I will write the reason in Problems and not leave it sitting here unexplained.

Before starting, I will:

- Re-read the Safety section.
- Check the weather, because summer storms can change the plan within an hour.
- Confirm with the lead that the budget line for this step is still open.

## Safety

Safety notes are kept plain because I read them in a hurry before starting work.

- Bees first. Wear full protective clothing for any work within sight of the hives, even if the job seems unrelated to the colonies.
- Pressure. The air side stores energy. Release pressure fully before opening any line or fitting. The notes in [[Lesglugen air compressor notes]] describe how I do this on that unit.
- Water and electricity. Keep every electrical connection off the ground and away from standing water. Sensor wiring gets a drip loop wherever it enters a box.
- Heat and sun. Drink water, take breaks in shade, and stop when concentration slips. Mistakes with tools happen when tired.
- Ladders and lofts. Where work involves the loft or upper storage, follow the habits in [[Fenkraeth loft handbook]]: three points of contact, clear floor, and no working alone with heavy items.
- Lifting. Hive boxes and full water containers are heavy. Ask for help rather than twisting.
- Tell someone. If I am working alone on site, someone knows where I am and roughly how long I will be.
- First aid. A kit and a plan for stings stay near the work area, including what to do if someone reacts badly.

## Lessons

These are lessons learned so far, from this project and the work around it.

- Trial before commitment. The early pond work in [[Gundpio pond tests]] showed that bench results mean little outdoors. Anything meant for outside needs an outside trial.
- Write the decision when it is made. The go decision is easy to find only because I logged it immediately. Earlier decisions that I did not log took far too long to reconstruct.
- Keep the detail in its own note. This summary stays useful because it links out. When I copied detail into it in the past, it went stale.
- Let the lead lead. Having the accountant in charge feels odd for a beekeeping project, but the discipline about records and spending has been the most reliable part of the whole effort.
- Small steps in summer. Long, ambitious days in the heat produce errors. Short, focused sessions give better results and fewer repairs.
- Respect the calendar of the bees. Work that can wait should wait until the colonies are calm.
- Keep a manual fallback. Every automated part should have a documented way to run by hand.

## Tools

Tools and references I rely on for this project.

Physical tools:

- Protective clothing, smoker and hive tool for any work near the colonies.
- Basic hand tools: spanners, screwdrivers, pliers, a small saw and a drill.
- Pipe and hose cutters, plus clips and spare fittings for the air and water lines.
- A multimeter for checking sensor wiring and supply.
- Torch or head lamp for dim corners and the loft.
- A notebook and pen, even though the real log is digital, because wet or sticky hands are bad for screens.

Equipment covered by their own notes:

- The air supply, described in [[Lesglugen air compressor notes]].
- The valve actuator, described in [[Murfes valve actuator]].
- Level sensing, with [[Drursus level sensor]], [[Susrion level sensor]] and [[Tithbun level sensor plan]] as the options.

Reference notes:

- [[Fenkraeth loft handbook]] for working in and around the loft.
- [[Zaenpapath Kolbuth]] for background material I return to when a design choice needs checking.
- [[Gundpio pond tests]] for the water trial history.

## Ideas

Ideas are parked here and not acted on until the plan allows. None of them is approved.

- A simple shade cover over the control parts, to reduce heat stress on seals and electronics.
- A second, cheaper level sensor used only as a cross-check, so one faulty reading cannot cause a wrong action.
- A labelled quick-reference card fixed near the equipment, showing how to shut everything down and how to switch to manual.
- A short yearly review each autumn, when the bees are quiet, to update this summary and the checklist in one sitting.
- A small log sheet kept on site for recording readings, so the data does not depend on my memory.
- Using the loft for dry storage of spare parts, with a tidy shelf arrangement following the [[Fenkraeth loft handbook]].
- A trial of quieter air supply options, if the noise turns out to bother the colonies.
- A handover document written as if for a stranger, because that is the best test of whether my notes make sense.

## Problems

Problems are things that have actually gone wrong or are blocking, not just worries.

- Evidence is thin on heat performance. I have good mild-weather results but not enough from the hottest days. This is the biggest gap and ties directly to the question about the valve actuator.
- The level sensor choice is unresolved. Without it, I cannot finish the wiring plan, and the next action stays narrower than I would like.
- Notes were sometimes scattered. Early records were spread across several places. I have been merging them, but a few details are probably still missing.
- Noise near the hives has not been properly measured. I only have an impression, not a reliable observation. It needs a proper check before I commit to a compressor location.
- Time. Summer is short and the weather interrupts. Several planned sessions have been lost to rain or to colony needs taking priority.
- Access. Some parts of the site are awkward to reach with equipment. This makes even simple jobs slower and increases the safety risk.

When any of these is solved, I will move a one-line version into Lessons and delete it from here.

## Setup

The setup is a retrofit on an existing beekeeping arrangement, so the description below is about what gets added, not what already exists.

- **Existing base.** The current hives and site layout stay as they are. The retrofit has to fit around them.
- **Water side.** Level sensing and valve control are the heart of the retrofit. The valve is driven by the actuator described in [[Murfes valve actuator]], and the level reading comes from one of the sensors under consideration.
- **Air side.** Compressed air provides the force for part of the system. The unit and its habits are in [[Lesglugen air compressor notes]]. The air equipment sits away from the colonies.
- **Control and records.** The accountant lead holds the log and the spending record. The technical notes live in separate pages and are linked from this summary.
- **Working pattern.** Short summer sessions, early or late in the day, with the Safety list read first.
- **Fallback.** Everything can be run by hand if the automated parts fail. The fallback procedure is to be written on the quick-reference card from the Ideas section.

The aim of the setup is modest: it should make routine water handling less fiddly, not turn the apiary into a machine.

## Decisions

Decisions are recorded with their date where one exists, so I can see the order in which they were made.

- **Go decision.** The go decision date of Fita retrofit is 2026-10-21. From that date the project counts as approved to proceed, and the plan moved from preparation to action. The lead agreed to it, and the budget line was opened at the same time.
- **Retrofit, not rebuild.** The goal stays a retrofit. A full rebuild was considered early on and rejected because it would disturb the colonies too much.
- **Summer working season.** Work is planned around the summer season, with the understanding that some steps may slip to the following summer if the weather or the bees demand it.
- **Lead role.** The accountant leads. Spending and scope changes go through the lead.
- **Sensors undecided.** No final sensor choice has been made. This is deliberately left open until a short on-site trial can be done.
- **Detail kept elsewhere.** Technical detail stays in the linked notes, and this summary only points to it.

Any new decision gets a line here as soon as it is made, with its reason in a few words.

## Schedule

The schedule is loose, because it depends on weather and on the bees. I describe it by order and season, not by fixed dates.

1. **Now.** The go decision is made. The next action is waiting and is listed under Next action. Before it begins, a quick check of Safety and budget.
2. **Next summer sessions.** Short on-site trials for the level sensor options, with the heat question in mind. Compare readings from the candidates side by side.
3. **After the trials.** Make the sensor decision and log it. Then connect the valve side and test it with the air supply running.
4. **Dry run.** A full run of the whole arrangement, including the manual fallback, before anything is relied upon.
5. **Handover and tidy.** Update this summary, finish the tool list, and write the handover note.
6. **Autumn review.** When the colonies are quiet, a review of what worked, what failed and what to change before the following summer.

If a step slips, it slips to the next suitable window, not into a rushed session. Rushing near the hives has never paid off.

## Overview

Fita retrofit is a beekeeping project whose goal is a retrofit. It began in 2020, its season is summer, and the accountant leads it. Those five properties describe the project completely: the retrofit goal, the beekeeping area, the 2020 start, the summer season and the accountant as lead.

The current stage is early action. The go decision was made on 2026-10-21, the plan is stable, and the checklist shows that planning work is complete while hands-on work has barely started. The next action is NX-6783.

What is done: the goal, area, season and lead are settled; early water trials are written up in [[Gundpio pond tests]]; level sensing options have been narrowed to [[Drursus level sensor]], [[Susrion level sensor]] and the method in [[Tithbun level sensor plan]]; the valve and air notes exist in [[Murfes valve actuator]] and [[Lesglugen air compressor notes]]; and safety habits are written down, with loft work covered by the [[Fenkraeth loft handbook]]. Background reading is gathered in [[Zaenpapath Kolbuth]].

What is open: the final sensor choice, the behaviour of the equipment in the hottest weather, the noise question and the final handover. The biggest risks are heat, disturbance to the colonies and scope creep, and each has a stated way of handling it.

If I only have a minute, I read this: the project is approved, the plan is steady, one concrete action is waiting, and the main unknown is how the equipment behaves in real summer heat. The rest of the note is there to back that up and to keep me honest when I come back after a long break.
