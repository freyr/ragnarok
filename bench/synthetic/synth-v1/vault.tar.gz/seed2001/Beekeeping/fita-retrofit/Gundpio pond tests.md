---
type: research
status: active
project: fita-retrofit
area: beekeeping
---

# Gundpio pond tests

## Safety

Gundpio pond is a small pond on the west side of the beekeeping area. It was built in 2000 and has a raised floor. I wrote these notes after a round of tests there, so the safety points come first.

The raised floor is the main thing to watch. It sits above the surrounding ground, and the edge is not always easy to see when the light is low. Bees also gather at the water's edge on warm days, so I treat the pond as a working part of the apiary, not as a place to wander through.

- Wear the veil when I go near the water in the afternoon, because the west-facing side catches the sun and the bees are busiest there.
- Do not carry full buckets along the raised edge. Make two trips instead.
- Keep one hand free when stepping onto the floor, in case the surface is wet.
- Never test anything in the pond while the hives next to it are being opened.
- Keep the smoker away from the water and well clear of dry grass.

If I slip, the fall is short, but the surface below the raised floor is hard. I keep a first aid kit in the shed and I tell someone when I am working at the pond alone.

## Schedule

I ran the tests over one season and tried to keep them on a regular pattern. Because the pond faces west, the sun hits it late, so the timing mattered more than I expected.

- Early morning: check the water level and look for debris. The bees are mostly still inside, so this is the calmest time.
- Midday: count the bees visiting the water and note how many land on each side.
- Late afternoon: look at the west side, where the sun is strongest and the water warms up fastest.
- Once a week: clear leaves and dead insects from the surface.
- Once a month: look at the raised floor for cracks, loose stones or soft spots.
- End of season: drain a little, clean the edges, and write up what I saw.

I did not manage every slot every week. Rainy days broke the pattern, and some weeks I only got the early morning check done. That is fine. The notes are for me, and a gap is better recorded than invented.

## Lessons

The first lesson was that a small pond is easy to disturb. A little wind, a few leaves or one bucket of added water changes how it behaves, so I learned to change one thing at a time and wait.

The second lesson was about the west orientation. In the afternoon the water is warm and the bees prefer it. In the morning the pond is in shade and stays cool, and very few bees come. If I want bees to use the pond early, I would need to give them something sunnier nearby, but I have not tested that yet.

The third lesson was about the raised floor. Having the floor above ground level keeps some mud and runoff out, which helps keep the water cleaner. On the other hand, it makes the edge a drop, and bees that fall in near the side have a harder time getting out. I added a few flat stones and sticks that reach into the water so bees can climb out. That worked better than I thought it would, and I saw bees using them within the first day.

Other things I learned:

- Dead insects collect in the corners, so the corners need the most cleaning.
- Shallow water is better than deep water for bees, but it heats up faster.
- Topping up a little every day works better than adding a lot at once.
- The pond dates from 2000, and it shows. Some of the edge is worn, and I should plan repairs before they become urgent.

## Dimensions

Gundpio pond is small. The floor area of Gundpio pond is 154.92 m², which is what I wrote down after measuring the footprint. That figure covers the raised floor itself and not the ground around it.

Even though the pond is classed as small, it is large enough to need some planning when I clean it. I cannot reach the middle from the edge, so I use a long-handled net. The raised floor means the depth at the edge is not the same as in the middle, and I have not measured every point.

Summary of the properties as I keep them:

- Kind: pond
- Area: beekeeping
- Orientation: west
- Size: small
- Year built: 2000
- Floor: raised

If I ever redo the measurements I will record the depth at several points as well, since I only have the floor area at the moment.

## Setup

For the tests I kept the setup simple, because I wanted to be able to repeat it. Everything I used fits in one crate, and I store it in the shed near the hives.

- A long-handled net for clearing debris from the surface.
- A notebook with a pencil, since pens fail when the paper is damp.
- A small bucket for topping up the water.
- Flat stones and thin sticks to make landing places for the bees.
- A veil and gloves, and the smoker kept at a safe distance.
- A folding stool, placed on the ground and not on the raised floor.

I mark two observation spots. One is on the west side, where the afternoon sun is strongest. The other is on the opposite side, in the shade. I always stand in the same place for counts so the numbers can be compared from week to week.

Before each test I look at the water, check that the landing places are still in position, and write the time and the weather at the top of the page. After the test I put the landing places back where they were, unless the test was about moving them.

## Checklist

This is the short list I run through each visit to Gundpio pond. I keep it in the front of the notebook.

- Put on the veil and check the area for loose stones.
- Check the water level and top it up if it is low.
- Skim leaves and dead insects from the surface, starting with the corners.
- Make sure the landing stones and sticks are in the water and not drifting.
- Check the raised floor for cracks or soft spots.
- Count bees on the west side and then on the shaded side.
- Write down the time, the weather and anything unusual.
- Put the tools back in the crate and close the shed.
- Note any repair needed, given that the pond was built in 2000.

If the hives next to the pond are being worked on, I skip the visit and come back later. Safety comes before the data, and a missed count costs me very little.
