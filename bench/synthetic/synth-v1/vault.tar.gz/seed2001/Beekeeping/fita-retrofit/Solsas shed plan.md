---
type: plan
status: active
project: fita-retrofit
area: beekeeping
description: "Plan about Solsas shed."
---

# Solsas shed plan

## Schedule

This plan covers the work on Solsas shed, a small shed used for beekeeping. It is a ground level building built in 2015, and its door and main wall face south. The south orientation matters for most of the timing below, because the sun reaches the front early and the shed warms quickly in spring.

Early spring: open the shed after the last hard frost, sweep out the floor, and check the roof and door seals before the first hive inspection. Clear the path to the south door so I can carry boxes in without stepping on damp ground.

Late spring: move the spare boxes and frames in, ready for swarm season. Check that the shelves are dry and that the frames are stacked off the floor. Put the smoker fuel and the hive tools in the same place every year so I can find them quickly.

Summer: use the shed as the base for honey work. Keep the door shaded in the afternoon with the old canvas sheet, since the south side gets very hot. Do a short tidy once a month.

Autumn: take stock of the equipment, wash and dry the boxes, and store the empty frames. Block any gaps that mice could use. Do this before the first cold nights.

Winter: visit only for a quick look after storms. Check the roof, the door, and the ground around the base. No other work is planned unless something is damaged.

## Costs

I have no firm quotes, so these are rough categories rather than exact figures. The aim is to keep the yearly spend small, because the shed is small and simple.

- Roofing felt and nails: the biggest likely repair, needed every few years on a building from 2015.
- Wood preservative for the outside boards: a yearly or every second year job, mostly on the south wall, which weathers fastest.
- Door seals and hinges: cheap, but worth replacing before they fail.
- Mouse proofing: mesh and filler for gaps, bought once and topped up.
- Shelving timber: only if the current shelves sag.
- Lease payment: paid separately and tracked under Admin.

Rule of thumb: spend first on anything that keeps water out, then on anything that keeps pests out, and last on anything that only makes the shed look better. If a repair can wait until the next dry spell without risking the stored equipment, it waits.

I should keep receipts in one folder and note what each one was for, so that next year I can see what the shed really costs.

## Observations

Things I have noticed about Solsas shed over the years:

- Because it faces south, the front wall dries fast after rain, but the paint and wood there fade and crack sooner than on the other sides.
- The inside gets warm by late morning on sunny days. In midsummer it can be too hot for wax and comb to sit for long, so I keep them on the lowest shelf away from the wall.
- Being on ground level is convenient for heavy boxes, but the floor edge picks up damp after long wet spells. I keep timber under anything that must stay dry.
- The shed is small, so there is room for the essentials only. Extra equipment makes it hard to turn around, and I have learned to store bulky items elsewhere.
- Mice show up first near the back corner. Signs are droppings on the lower shelf and nibbled frame ends.
- Light through the door gap is a useful check: if I can see daylight at the bottom edge, the seal needs attention.

The shed has done its job well as a beekeeping store since 2015, and most problems have been small and slow, which makes them easy to catch with regular checks.

## History

Solsas shed was built in 2015 as a small ground level shed for the beekeeping area. It was placed with the door facing south so that the entrance would get sun and the approach would stay clear and dry for most of the year.

In the early years the shed held little more than a few boxes, a smoker, and basic tools. As the number of hives grew, the shelves were added and the layout changed so that the most used items sit near the door.

Over time the main wear has shown up on the south side. The boards there have needed more treatment than the rest, and the door has been adjusted a few times as the frame settled.

The roof has held up reasonably, though it is the part I watch most closely. The floor, being at ground level, has never been raised, and I have dealt with damp by using timber supports under stored items instead.

There have been no major rebuilds. The history of the shed is mostly a list of small fixes, and this plan is meant to keep it that way by making the checks regular rather than reactive.

## Admin

Key facts for the paperwork on Solsas shed:

- Lease reference: LR-187675
- Kind: shed
- Area: beekeeping
- Orientation: south
- Size: small
- Year built: 2015
- Floor: ground level

Keep the lease papers with the other beekeeping records, and write the lease reference on anything I send about the shed. If the terms or the payment arrangements change, I should note it here straight away so that the plan stays accurate.

Jobs to remember each year: confirm that the lease is still in force, check that any rules about the use of the beekeeping area have not changed, and keep a copy of any message exchanged with the landlord. If I want to make a bigger change to the building, such as raising the floor or changing the roof, I should check the lease first and ask before starting.

## Maintenance

Routine checks for Solsas shed, in rough order of importance:

1. Roof: look for lifted felt, gaps at the edges, and any sign of water inside after heavy rain. Fix small problems at once.
2. South wall and door: look for cracked paint, split boards, and a door that no longer closes cleanly. Treat the wood before it dries out too far.
3. Floor and base: because the shed is on ground level, check for damp, rot at the bottom boards, and soil piled against the wall. Keep the ground sloping away.
4. Pests: check the back corner and the lower shelves for mouse signs. Fill gaps and clear any old nesting material.
5. Shelves: make sure they are level and not overloaded. Keep frames and boxes off the floor.
6. Inside: sweep, remove wax scraps and spilled honey, and air the shed on a dry day.

Longer jobs: treat the outside boards every year or two, replace the door seals when they go hard, and renew the roofing felt when patching no longer works.

Keep a short log after each visit with the date written in plain words and what I did. A few lines are enough. The log is what turns these checks into a real plan, because it shows which parts of the shed need work most often and which can be left alone.
