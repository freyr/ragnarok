---
type: research
status: active
project: giolve-rebuild
area: beekeeping
---

# Giorkvurk circulation pump study

## Lessons

The first thing I learned from the Giorkvurk circulation pump is that a pump you stop thinking about is a pump that is working. It is a black circulation pump that runs on mains power. I installed it in 2019 in the barn, and for most of that time it just sat in the corner doing its job. The study notes below exist because I finally started paying attention to it, and a few habits turned out to matter more than I expected.

**Listen before you measure.** Most of what I know about the pump's health came from sound. A steady, low hum means the water is moving the way it should. A thin rattle means air has gotten into the housing. A deeper grinding note means something is wrong with the bearing or the impeller. I now walk into the barn once a week, stand next to the pump for a minute with the doors closed, and just listen. It costs nothing and it has caught two problems early.

**Bleed the air first, always.** Every time I suspected a fault, the cause was trapped air. I wasted a whole afternoon once checking the wiring when all I needed was to open the vent screw and let the bubble out. The rule I wrote on the wall is: air first, wiring second, replacement last.

**Keep the barn dry.** The barn is not a kind place for electrical equipment. Damp air gets in during the cold months, and the black casing hides condensation well. The pump looks fine until you wipe it down and find a film of moisture on the underside. This is the reason I later started comparing notes with my [[Miotrael dehumidifier]] records. The two devices share the same room, and the pump behaves better when the air is drier.

**Do not trust the casing colour.** The black finish looks tidy, but it hides dust, wax flecks and drips. I now wipe the casing with a damp cloth on every visit so that a leak has nowhere to hide. A dark surface with a wet patch is hard to spot by eye, so I check with my fingertips.

**Write down what you changed.** Whenever I touched the pump, I wrote one line in the log. Later, when behaviour shifted, the log told me whether I had caused it. Without those lines I would have blamed the pump for things that were really my own adjustments.

**Plan for mains failure.** Because the pump takes its energy from the mains, a power cut stops everything. I learned to keep a short written routine for what to do when the power returns: check for air, check the casing, listen, and only then trust the flow. Bringing it back too quickly after a cut once left me with a noisy first hour.

## Supplies

This section lists what I keep close to the pump so that a check or a small repair does not turn into a trip to find tools. Nothing here is exotic. I keep it all in one lidded box on the shelf nearest the pump.

**Cleaning and drying**
- A few soft cloths that I use only for the pump
- A small brush for dust around the vent and the motor fins
- A roll of absorbent paper for drips
- A tub of silica pouches that I swap into the box when they feel heavy

**Basic tools**
- A flat screwdriver that fits the vent screw
- A small adjustable spanner for the unions on either side
- A torch with a narrow beam, because the barn corner is dim
- A pair of thin gloves, since the pipework is sometimes unpleasantly cold

**Sealing and spare bits**
- Sealing tape for threaded joints
- A couple of spare rubber washers for the unions
- A short length of spare hose with matching clips
- Cable ties for keeping the mains lead off the floor

**Records**
- A pencil and a pocket notebook that stay in the box
- A printed copy of the wiring layout I drew myself
- A page of my own start-up routine for after a power cut

**Related reading I keep nearby**
- The [[Trildeth solar charger handbook]], which I consult when I think about backup power for the barn
- My notes on the [[Murfes valve actuator]], because valve behaviour and pump behaviour affect each other
- The [[Tithbun level sensor plan]], which describes how I intend to watch the water level in future

I try not to let the box grow. If something stays untouched for a full season, it comes out. A smaller box is easier to trust and easier to restock.

## Overview

The Giorkvurk circulation pump is a black circulation pump powered from the mains. I installed it in 2019 and it lives in the barn. Its work is to keep water moving through the loop that serves my beekeeping setup, so that the warmth and flow stay even instead of pooling at one end. Beekeeping is the whole reason it exists. Nothing else in the barn depends on it as much.

In plain terms, the pump pulls water from one side of the loop and pushes it onward. It does not heat anything on its own and it does not store anything. It only moves. That is why the surrounding parts matter so much. The pump is only as useful as the pipes, valves and exchanger around it. The [[Lirktrae heat exchanger]] sits downstream and does the actual transfer of warmth, while the pump keeps the water travelling through it at a steady pace.

I placed it in the barn because the loop begins there and because the mains socket was already close. Looking back, the location has pros and cons:

- The barn is near the start of the loop, so the pipe runs are short.
- The mains supply is easy to reach, so the lead is short and tidy.
- The room is cold and damp for part of the year, which is hard on the casing and the connections.
- It is out of the way, so I can forget about it, which is both convenient and a risk.

The black casing is plain and sturdy. It has no markings I rely on, so I identify it by its place on the shelf and by my own notes rather than by anything printed on it. I did not want to depend on labels that might fade in the damp.

Over the years I have thought of the pump as a quiet worker. The study I am writing up here is partly an attempt to describe what normal looks like, so that I can recognise abnormal. That is also the reason I compared my findings with the earlier work in [[Kaesme Laerdond tests]], which gave me a method for noting small changes without fooling myself. The idea of a baseline came from there, and I borrowed it directly.

One more point belongs in the overview. The pump is not alone in its building. A greenhouse project, the [[Nithden greenhouse]], draws on some of the same thinking about circulation, even though it is a separate site. I sometimes compare how water behaves there and in the barn, and the differences have taught me what is particular to this pump and what is general.

## Observations

These are the things I have actually noticed, written in the order I noticed them rather than the order of importance.

**Sound.** In normal running the pump produces a low, even hum. After a long idle spell, the first minute is a little louder and then settles. When air is trapped, the hum gains a faint rattle that comes and goes. I have never heard anything alarming, but I know the rattle well now, and it always goes away after bleeding.

**Surface and casing.** The black casing collects dust quickly and shows wax flecks as pale specks. After damp weeks I find a faint film of moisture along the underside. It has never reached the electrical parts, but it tells me the barn air is working against me. Wiping the casing is now routine.

**Flow behaviour.** The flow feels steady when I rest a hand on the outgoing pipe. If the pipe feels uneven, with a pulsing quality, I suspect air. If it feels cooler than usual at the far end of the loop, I look at the valves before I blame the pump. Several times the true cause was a valve that had not fully opened, which is why my notes on the [[Murfes valve actuator]] are so closely tied to this study.

**Power.** On the mains, the pump starts without fuss. After a power cut it sometimes needs a minute or two to find its rhythm. I do not hurry it. I follow my start-up routine and listen. No lasting harm has come from outages so far, but I treat each one as a small test.

**Seasonal pattern.** In the cold months the barn is damp and the pump hums slightly lower. In the warm months the room dries and the sound is crisper. I cannot say whether this is real or whether my ears change with the season, so I only record it as a pattern worth watching.

**Age.** Installed in 2019, the pump has now run through many seasons. I see no obvious wear on the outside. What I cannot see is the inside, and I accept that I may only learn about the bearing when it starts to complain. For that reason I keep the listening habit even when everything seems perfect.

**Open questions.**
- Does a drier barn really lengthen the life of the pump, or is that wishful thinking?
- Would a level sensor catch air problems sooner than my ears do?
- How much of the flow variation comes from the pump, and how much from the valves?

I plan to address the second question through the [[Tithbun level sensor plan]]. For the third, I will keep logging both the pump and the valves side by side. A friend with a similar loop, [[Mastend Runpith]], has offered to compare notes, and I expect that outside view to help me separate what is specific to my setup from what is true of circulation pumps in general.

## Open questions

These are the things I still cannot answer about the Giorkvurk circulation pump after the time I have spent with it. It is a circulation pump used for beekeeping work. It is black, runs on mains power, has been in the barn since 2019, and I want to understand it better before I make any changes.

**How much of its run time is actually needed?** The pump runs on mains, and I have never measured how many hours a day it really works. In winter I suspect it runs far longer than the hive-warming and honey-room loop needs. I would like to log the run time for one full season and compare it with the outdoor temperature in the barn.

**Is the barn the right place for it?** The pump has stood in the barn since 2019. The barn is dusty in summer, damp in autumn and cold in winter. The black casing looks fine, but I do not know whether the motor inside copes well with the swings. I want to check whether a spot higher on the wall, away from the floor, would make a difference.

**Does the black casing matter for heat?** The pump is black, and the barn gets warm in the afternoon when the sun hits the south wall. A dark casing absorbs more heat. I do not know if this affects the motor temperature in a measurable way. A simple test would be to touch-check the casing at the same hour on a hot day and on a cool day, and then try shading it for a week.

**What is the real flow compared with what I assume?** I have always assumed the flow is steady. I never put a proper measurement on it. I would like to time how long it takes to fill a known container from the outlet, and repeat it a few times across the year, to see whether the flow drops as the system ages.

**Is the noise getting worse?** In my memory the pump was nearly silent in 2019. Now there is a low hum, and sometimes a faint rattle at start-up. I cannot tell whether this is the bearings, air in the line, or just my ears. I need a way to compare, such as recording a short clip at the same distance each season.

**How does it behave after a power cut?** Mains power in the barn is not perfectly reliable. I do not know whether the pump restarts cleanly every time or whether it sometimes starts with air trapped inside. I have seen it take longer to settle after an outage, but I never wrote down how many times it happened.

**Would a second pump make the system safer?** If the Giorkvurk fails during a cold spell, the loop stops. I do not know if keeping a spare on the shelf is sensible, or whether the system should be changed so that a simple backup could be switched in by hand.

**What is the right service routine?** I have no schedule. I clean the outside when I remember and I check for drips now and then. I would like to settle on a short list of checks that I can do in a few minutes at the start and end of each season.

## References

I keep this list short because most of what I know about the pump comes from my own handling of it, not from published sources. The items below are the ones I go back to.

**The maker's booklet.** A printed booklet came with the pump. It explains the connections, the supply requirements and the basic cautions. It says very little about long-term wear. I keep it in the folder with the barn papers. It is useful for the wiring notes and for the warning about running the pump dry.

**My own logbook.** I started a paper logbook after the pump went in during 2019. It has short entries about when I bled the line, when I cleaned the intake, and when I noticed anything odd. The entries are uneven, with long gaps, but they are still the best record I have of how the pump has behaved.

**Photographs of the installation.** I took a few photos of the pump and its pipework in the barn right after it was installed. They show the black casing, the mains connection and the way the pipes leave the unit. I use them to check whether anything has been moved or has sagged over the years.

**Notes from other beekeepers.** Over the years I have talked with other keepers who use circulation pumps in their sheds and workrooms. Their advice has been consistent on a few points: keep the pump dry, keep it accessible, and never run it without liquid in it. I treat these as hints, not as facts, since their setups are different from mine.

**General guides on small circulation pumps.** I have read a handful of general guides on how circulation pumps work. They explain impellers, bearings and air locks well enough. None of them is about this particular pump, so I use them only to understand the principles and to make sense of the symptoms I see.

**My earlier notes on the barn.** I have older notes about the barn itself: the damp, the draughts, the mains supply and the layout of the benches. They help me think about the environment the pump lives in, which I suspect matters as much as the pump.

## Problems

This section lists the real problems I have run into with the Giorkvurk circulation pump, in the order of how much they bother me.

**Air in the line.** The most common trouble is air trapped in the loop. After any work on the pipes, or after a power cut, the pump can sound strained until the air is cleared. Bleeding the line fixes it, but it is easy to forget, and I have sometimes left the pump running with air in it for a day or more.

**Dust and grime.** The barn is a dusty place, and the black casing shows every layer of it. Dust collects on the housing and around the mains connection. I do not think the dust has done harm yet, but it makes it hard to see small drips or stains, which is a real problem when I want to catch a leak early.

**Damp in autumn.** In the wet months the barn air is heavy. I have seen light condensation on the casing and on the pipes near it. Since the pump runs on mains, damp near the electrical connection is the thing I like least. I have lifted the cable off the floor and added a loose cover, but I am not fully satisfied with the arrangement.

**Growing hum.** The low hum I mentioned above has become more obvious. It is not alarming, but it is different from how the pump sounded when it was new. I worry that it is an early sign of bearing wear. Since I cannot compare it to a recording from the early years, I cannot say how fast it is changing.

**Uneven warm-up.** On cold mornings the loop takes a long time to carry heat to the far end. It is hard to tell whether the pump has weakened or whether the pipes have simply lost more heat than before. Without a flow measurement I am guessing.

**Awkward access.** The pump sits where it is easy to reach for a quick look but hard to reach for real work. Taking it off the pipes would need me to move a shelf first. That makes me put off maintenance, which is a problem in itself.

**No spare and no plan.** If it stops in the middle of winter, I have no replacement and no tested workaround. So far I have been lucky, and I know that is not a plan.

**Thin records.** My logbook has long gaps. Because of that, when something changes I often cannot say when it began. This is partly a problem with the pump and partly a problem with me.

## Costs

I am not recording exact amounts here. I only want to describe what the pump has cost me in terms of money, time and effort, and where I expect costs to come from next.

**Purchase and installation.** The pump was bought and installed in 2019. The main costs at the time were the unit itself, the pipe fittings and a little electrical work to bring mains power to the spot in the barn. I did most of the fitting myself, which kept the labour cost low but took a weekend.

**Running cost.** Because it runs on mains, the pump adds to the electricity bill. It is a small load, but it runs for many hours. The real running cost depends on how long it works each day, which I still need to measure. I suspect that trimming unnecessary run time is the cheapest saving available.

**Maintenance cost.** So far maintenance has cost very little: cloths, a small brush, some sealing material and my time. The cost that matters is time, since each check means a trip to the barn and moving a shelf out of the way.

**Likely repair cost.** If the hum turns out to be a bearing problem, I will probably have to choose between a repair and a replacement. A repair would need parts that may be hard to find for this model. A replacement would cost more up front but would reset the clock. I would rather decide this before a failure forces the choice.

**Cost of a spare.** Keeping a second pump on the shelf would cost money that would sit idle. Against that, a failure in a cold spell could cost me much more in lost work and stress. I have not decided, but I lean toward a cheap, simple backup that I can switch in by hand.

**Cost of damp protection.** A better cover for the mains connection and a higher mounting spot would cost a little in materials. I think this is the most sensible spending, because it protects both the pump and my safety.

**Cost of my own time.** The largest cost is my attention. Keeping a better logbook, taking measurements and doing seasonal checks will take time, but I expect it to save money by catching problems early.

## Risks

The Giorkvurk circulation pump is a black circulation pump that runs on mains power. It has sat in the barn since 2019, and it serves the beekeeping work I do there. Because it is wired to the mains and sits in a building where I handle water, wax and sugar syrup, most of the risks come from that combination.

The first risk is moisture. A barn is never fully dry. In winter there is condensation on cold surfaces, and in summer the extraction and washing work throws a lot of damp air around. The pump housing is black and tends to hide a thin film of water or residue, so I can miss it at a glance. Any water that reaches the terminal area or the plug is a real hazard.

The second risk is sticky contamination. Honey, syrup and wax residue can get into the area around the pump. Sugar dries into a hard crust. If that crust forms around the shaft or the seal, the pump may stall or run hot. A stalled pump on mains power can overheat the motor, and I would rather not find that out by smell.

The third risk is dust and debris. The barn holds straw, hive parts, old frames and dust. Fine dust settles on the motor and blocks cooling. Loose material near the pump can also be drawn toward the inlet side if I leave a hose or line open.

The fourth risk is dry running. If the line is empty or an air lock forms, the pump runs without liquid. That wears the seal quickly. I have to check that the system is primed before I switch it on, every time, not just after a repair.

The fifth risk is ageing. The pump has been installed since 2019, so it has several seasons of use behind it. Rubber seals, the power cable and the plug all harden over time. A cable that was fine in the first year may now have small cracks, especially where it bends near the wall.

The sixth risk is human error. I use the pump only part of the year, and between uses I forget small details: which valve must be open, which way the flow runs, where the switch is. Forgetting a valve can cause a pressure rise in the line.

Lastly, there is the risk of dependence. If the pump fails in the middle of a busy period, the work stops. I have no spare unit in the barn, and I should decide whether that is acceptable.

## Safety

These are the rules I follow when working with the pump. I wrote them so I do not have to rethink them each time.

**Before use**
- Look at the cable along its whole length. If the insulation is cracked, flattened or discoloured, do not use the pump until it is replaced.
- Check that the plug and socket are dry and clean.
- Confirm that the line is filled and that no valve is closed that should be open.
- Make sure nothing is stacked against the pump, and that air can move around the motor.

**During use**
- Stay within reach of the switch. I do not leave the barn while the pump runs.
- Listen for changes. A grinding, rattling or high whine means stop immediately.
- Touch the housing carefully after a while. It will be warm, but if it is too hot to keep my hand on, switch it off.
- Keep wet hands away from the plug and the switch. If my hands are sticky from honey or syrup, I wash and dry them first, because sticky hands also tend to be damp.

**After use**
- Switch off at the socket, then pull the plug. I do not pull on the cable itself.
- Wipe the housing and the area under it. Sugar left on the floor attracts wasps and mice, and mice chew cables.
- Drain the line if frost is expected. Water that freezes in the pump body can crack it.

**Electrical points**
- The pump is mains powered, so the supply should go through a residual current device. I should test that device regularly with its test button.
- No extension cable lying on the floor. If I must use one, it has to be rated for damp places and kept off the ground.
- Nobody opens the motor casing except to follow a clear plan, and only with the plug out of the socket.

**Handling food-related liquids**
Because the work is in beekeeping, some of what passes through the system ends up in or near honey. I keep cleaning products away from the pump during operation, and I rinse the line well with clean water after any cleaning, so no residue ends up in anything I later eat or sell.

**If something goes wrong**
- Pull the plug first, if it is safe to reach it. If water is near the plug, switch off at the main board instead.
- Do not restart until I know the cause.
- Write the problem down in this note so I can see patterns.

## Maintenance

I keep maintenance simple so that I actually do it. The pump is in the barn, which is not a gentle place, so a short routine done often works better than a big overhaul done rarely.

**After each session**
- Wipe the black housing with a damp cloth, then dry it.
- Check the floor beneath for drips. A drip is the earliest sign of a failing seal.
- Flush the line with clean water if sugar or syrup was moved through it.

**Monthly during the season**
- Inspect the cable and plug again, more closely than before use.
- Brush dust off the motor and the cooling openings with a soft brush.
- Run the pump briefly and listen. I compare the sound with what I remember as normal.
- Check the mounting. Vibration loosens bolts and feet over time, and a loose pump makes more noise and wears faster.

**Once a year, at the end of the season**
- Drain the pump and line completely.
- Clean around the shaft and the seal area. Dissolve any sugar crust with warm water, never with force.
- Check the flexible hoses for hardening or cracks, and replace them if needed.
- Test the residual current device.
- Cover the pump loosely, so dust stays off but air can still move. A sealed plastic bag would trap moisture.

**Signs that need attention**
- Slower flow than before, which may mean a partial blockage or a worn impeller.
- A new vibration or noise.
- Warm smell from the motor.
- Damp marks around the connections.

**Records**
The pump was installed in 2019, and I want a short log that shows when I cleaned it and what I found. I note only the date, the work done and any oddities. After a few seasons the log will show whether wear is speeding up.

**Spare items**
I should keep a few things on the shelf: spare hose clamps, a length of suitable hose, a replacement plug and a seal if one is available for this model. If the seal cannot be sourced, I should find out now rather than in the middle of the season.

## Ideas

These are things I may try later. None of them is urgent.

1. **Fit a drip tray.** A shallow tray under the black housing would catch leaks and make them visible. It should be easy to remove and wash.

2. **Raise the pump off the floor.** A small shelf or block would keep it clear of washing water and spilled syrup. It would also help in the barn when the floor gets damp.

3. **Add a dedicated switch with a visible indicator.** A switch at a comfortable height, with a light that shows when the mains supply is on, would make it harder to leave the pump running by mistake.

4. **Add a timer or cut-off.** A simple timer could stop the pump after a set period, which reduces the harm of dry running if I get distracted.

5. **Label the valves.** Small tags that say open or closed for each step would cut down the human errors I listed under risks. A one-page diagram pinned to the wall next to the pump would do the same.

6. **Install a simple flow check.** A clear section of hose would let me see at once whether liquid is moving. That would warn me early about air locks.

7. **Build a cover.** A light cover that shields the pump from splashes and dust, but leaves room for ventilation, would reduce cleaning time.

8. **Buy or reserve a spare.** If the pump is important to the work, a spare unit or at least a spare set of wear parts would protect me against a failure at a bad moment.

9. **Review the position.** The barn is its location, but I could check whether another spot inside it is drier and cooler, and easier to reach.

10. **Compare notes over the years.** Since the pump has run since 2019, I could go back through my old notes, look for repeated faults and decide whether replacement is cheaper than continued repair.

11. **Check the electrical supply.** I could ask a qualified electrician to review the socket, the wiring and the protection in the barn. I would rather pay for that once than guess.

The order I would do these in is: labels, drip tray, raised position, switch, then the rest. The cheap and quick items come first, and the larger changes wait until I see how the cheap ones help.

## Background

The Giorkvurk circulation pump is a black circulation pump that runs on mains power. It was installed in 2019 and sits in the barn. I keep it for beekeeping work, and this study is my attempt to write down what I actually know about it instead of relying on memory each autumn.

The reason I care is simple. The barn is where I process honey, warm the supers before extraction, and keep the wax melter and the warming loop running through the cold months. The pump moves warm water around that loop. If it stalls, the loop cools unevenly, the honey in the far supers stays stiff, and I lose half a day. So the pump is not a glamorous part of the bee year, but a lot depends on it.

What I want from this study:

- A clear picture of how the pump behaves when it is working normally, so I can spot drift early.
- A repeatable way to check it without guessing.
- A short list of the conditions in the barn that make it better or worse, such as dust, damp and cold spells.

The pump has been in place since 2019, and in that time it has been quiet and fairly forgiving. Still, a device that has worked for years invites neglect, and neglect is the usual cause of a sudden failure. The black casing hides dust well, which means I tend to forget to wipe it. That is a small thing, but it is the kind of small thing I want on the checklist.

Some practical context about the barn. It is not heated in the ordinary sense. Temperature swings are real, and humidity rises when I am working with warm water and open containers. Mains power comes from a single outlet run, shared with a couple of other tools, so I have to be careful not to overload it when the extractor motor and the pump are both on. I treat the electrical side as part of the pump's environment, not as a separate topic.

I am not trying to write a manual. The maker's instructions exist, and I keep them in a folder in the barn. This note is about my own use: what I do, what I see, what I changed, and what I would do differently. Where I am unsure, I say so instead of filling the gap with a confident guess.

## Tools

I keep the tool list short on purpose. If a check needs a special instrument I will not own or find, I will not do the check. Everything below lives on one shelf near the pump.

**Basic hand tools**

- A set of flat and cross-head screwdrivers, mostly for the cover and the terminal box.
- An adjustable spanner and a pair of pliers for the fittings on either side of the pump.
- A soft brush and a dry cloth for dust. I avoid water near the motor housing.
- A small torch, because the corner of the barn where the pump sits is dim even in daytime.

**Measuring and checking**

- A plug-in mains meter, which shows how much power the pump draws while running. I compare what I see now against what I noted earlier, and a clear rise tells me something is dragging.
- A basic multimeter for continuity and for confirming that the outlet is live before I touch anything.
- A surface thermometer, the clip-on kind, to compare the pipe temperature before and after the pump. A healthy loop shows a steady, modest difference.
- A notebook, paper rather than digital, kept in a zip bag. Barn hands are sticky, and a phone does not survive honey well.

**Consumables and spares**

- Spare sealing washers for the pipe fittings. These are the part most likely to leak first.
- Pipe tape and a small tube of food-safe lubricant for threads that touch the water side.
- Cable ties and a few lengths of spare hose.
- Clean rags and a bucket, since there is always a little water to catch when I open a fitting.

**Safety items**

- A residual current device on the outlet. This matters more than anything else on the list, because water, honey and mains power share the same room.
- Dry gloves for electrical checks, and rubber gloves when I handle hot water fittings.
- A clear rule: unplug first, then work. I never rely on a switch alone.

I considered buying a flow meter. It would give a direct reading, but the price is more than the pump deserves in my setup, and the temperature difference across the pump already tells me most of what I need. If the loop ever becomes more complicated, I may revisit that.

## Schedule

I do the checks in a rhythm tied to the bee year, not to the calendar. That keeps the habit attached to jobs I already do and makes it hard to forget.

**Before the honey season**

This is the main inspection. I unplug the pump, brush the dust off the black casing and the vents, and look at the cable for wear, especially where it passes close to the wall. I check the fittings for dried residue, which is the first sign of a slow leak. Then I plug it back in, run it for a while, and watch the mains meter and listen. A healthy pump hums evenly. A rattle or a changing pitch goes into the notebook right away.

**During extraction days**

On the days I am extracting, I do a quick glance only. I confirm the pump is running, the pipes are warm to the touch, and nothing is dripping. I also check that the outlet is not carrying too much, because the extractor motor and the pump together can warm the plug. If the plug is hot, I stop and move something to another outlet.

**After the season**

When the last supers are cleaned and put away, I flush the loop with clean water so no sugary residue sits in the pump over the quiet months. Then I wipe the casing, check the fittings again, and decide whether the pump needs to stay powered or can be switched off at the outlet. In my barn I switch it off and unplug it, so there is no chance of it running dry.

**Cold spells**

Whenever a hard frost is forecast, I look at the pump and the pipes. Standing water can freeze and crack a fitting or damage the pump housing. If there is any doubt, I drain the loop. This check is not scheduled, because it depends on the weather, but it is the one with the highest cost if I skip it.

**A simple habit**

Once in a while, with no reason at all, I walk into the barn and listen for a minute. Most of the problems I have ever found began as a sound I noticed in passing. The notebook then gets a short line: what I heard, what I did, what happened.

## Setup

The pump is installed in the barn, on the wall side away from the door, where the pipes run shortest to the warming loop. It has been there since 2019. I chose the spot because it keeps the pump out of draughts and away from the floor, where wash water collects.

**Mounting and position**

The pump is fixed to a wooden board that is screwed to the wall, so it does not hang from the pipes. This takes the strain off the fittings and cuts down on vibration noise. I keep the motor axis level, as the maker recommends, and leave enough space around it to reach both fittings with a spanner. The black casing absorbs a little heat, so I keep it clear of the wax melter, which radiates more than I expected.

**Power**

The pump runs on mains power from a single outlet on a circuit protected by a residual current device. The outlet is above the level of any spill. The cable is clipped along the wall with a small loop of slack hanging below the plug, a drip loop, so water running down the cable cannot reach the socket. I do not use an extension lead for this pump. When I need the extractor on the same wall, I use the other outlet.

**Plumbing**

Water enters on one side and leaves on the other, and I marked the flow direction with tape so I do not reverse it after maintenance. Each side has a shut-off valve, so I can isolate the pump without draining the whole loop. The fittings use sealing washers rather than tape on the main joints, and I keep the spares close by. A short length of flexible hose joins the pump to the rigid pipe on the outgoing side, which helps with alignment and vibration.

**Operation**

I leave the pump to run continuously while the loop is in use and switch it off at the outlet when I am done for the day. I do not rely on any speed setting to fix a problem. If the loop is slow to warm, I look for air in the line first, bleed it, and only then think about the pump itself.

**What I would change**

If I were setting it up again, I would put a small drip tray under the pump and add a clearly labelled isolating switch at eye height. I would also pick a lighter colour for the board behind it, because the black pump on a dark board is hard to see when I check for leaks with the torch. None of these is urgent. They are the sort of improvements that make the next check easier, and easier checks are the ones I actually do.

## Measurements

These are the readings I took on the Giorkvurk circulation pump, the black mains-powered unit that has sat in the barn since 2019. It serves the beekeeping side of the barn, so every figure here is read against that job: keeping warm water moving through the loop that I use for the honey room and the wax tank. I wrote the numbers down on paper at the time and copied them here later, so where I rounded, I say so.

### Setup for the readings

I measured with the pump running on the normal mains socket in the barn, with the loop closed and the valves in their usual working positions. The pump was warm, not cold, because a cold start gives odd numbers for the first few minutes. I let it run for about twenty minutes before I began writing anything down.

For flow I used a bucket and a kitchen timer. I diverted the return line into a marked bucket, ran it for a fixed time, and scaled the volume up to one hour. It is not a lab method. It is good enough to compare one day with another, which is all I need.

Things I kept the same each time:

- the same bucket, with the same fill mark
- the same hose length on the return side
- the same valve positions
- the same water, topped up from the same tap
- the same socket, with nothing else heavy on that circuit

### Main result

The flow rate of the Giorkvurk circulation pump is 986.03 l/h. That is the figure I trust most, because it came from the repeated bucket runs after the pump had warmed up and settled. Individual runs wandered a little around it, but not by enough to change how I use the pump.

To put it in practical terms: that flow moves the whole content of the loop through the pump many times an hour. For the small volume I keep in the honey room circuit, this is plenty. I do not need more flow, and I would not want much more, because a faster loop makes the pipes noisier and the water cools less evenly at the far end.

### Repeat runs

I did several runs on different days to see whether the result held. The pattern was the same each time: the first run after a long rest was a little low, and the later runs sat close together. I put the early low run down to air in the line and a slightly stiff start, not to any change in the pump itself.

What I noticed across the runs:

- After a long rest, the first few minutes were below the settled figure.
- Once the pump had been on for about twenty minutes, the runs agreed closely.
- Topping up the loop right before a run added air, and the reading dipped until I bled the line.
- Changing valve positions moved the result more than anything else I tried.

Because of the last point, I now mark the working valve positions with a strip of tape so that I do not guess.

### Effect of valve position

The valves matter more than the pump. With the main valve fully open the flow was at its best. Closing it halfway cut the flow clearly, and the pump sounded a bit more strained. Closing the branch to the wax tank sent more water through the honey room line, which is what I expected.

I did not record exact numbers for each partial setting, since I had no good way to hold the valve at an exact angle. What I can say is the order of effect: main valve first, branch valves second, hose length third. Air in the line sits somewhere near the top of the list, but it is easy to fix, so I treat it as a nuisance rather than a setting.

### Noise and vibration

The Giorkvurk is not loud. In the barn, with the doors shut, I can hear a steady low hum when I stand next to it, and almost nothing from the doorway. When air is in the line I hear a gurgle that goes away after bleeding.

Vibration is small. I checked by resting a hand on the casing and then on the bracket. The casing buzzes slightly; the bracket carries almost none of it. The black housing gets warm after a long session but never too hot to touch, which I count as a good sign for something that has run since 2019.

### Power and running behaviour

The pump runs from mains, and I have never needed anything other than the barn socket. It starts the same way each time and does not trip the circuit. I did not put a meter on it for this study, so I make no claim about its draw beyond saying that nothing in the barn has ever reacted to it starting up.

Running behaviour that I have seen over the years:

- It starts without a delay when the water is warm.
- It starts with a short stutter if it has been off for weeks.
- It runs steadily for hours without drifting.
- It does not need priming if the loop is full and bled.

### Seasonal notes

The barn gets cold in winter, and the pump location matters then. In cold spells the water in the loop is slower to warm, and the first readings of the day are lower. This is mostly the water and the pipes, not the pump. In summer the barn is warm enough that the pump settles very quickly, and the numbers are the steadiest.

For this reason I take my reference readings in mild weather. Winter readings are useful only for comparing winter with winter.

### How I use the figure

I keep the main flow figure on the note as a baseline. If a later reading falls well below it, I go through a fixed list before blaming the pump:

1. Check for air in the line and bleed it.
2. Check the valve positions against the tape marks.
3. Check the return hose for kinks.
4. Check the strainer for wax or debris.
5. Only then look at the pump itself.

Most of the time the problem is one of the first four. In beekeeping, wax bits are the usual culprit, and a blocked strainer can look exactly like a weak pump.

### Limits of these measurements

I want to be honest about how far these numbers go. The bucket method has its own error, mostly from the timing and from where I judge the fill mark. I did not measure pressure, and I did not measure power draw. I did not test with a different fluid, so everything here is about plain warm water.

Even so, the readings are consistent from day to day, and the main figure is stable enough to use as a reference. If I ever add a proper flow meter to the loop, I will repeat the study and compare against this baseline.

### Summary of properties checked

For the record, this is the unit these measurements apply to:

- Device: Giorkvurk circulation pump
- Kind: circulation pump
- Colour: black
- Energy source: mains
- Year installed: 2019
- Location: barn
- Area: beekeeping
- Measured flow rate: 986.03 l/h

### Next steps

When I next service the pump I will repeat the bucket runs on a mild day, with the valves taped at their working positions, and write the result under this section. I also want to try a simple clamp-on meter for power, so that the gap in these notes can be filled in. Until then, the flow figure above is the one I work from.
