---
type: research
status: active
project: giolve-rebuild
area: beekeeping
description: "Research about Nevirkun kiln controller."
---

# Nevirkun kiln controller study

## Tools

This part of the study covers the Nevirkun kiln controller, a kiln controller used in my beekeeping work. It is grey, runs on mains power, and was installed in 2022. It sits at the pond, in the small shed on the bank. I keep these facts at the top because I keep forgetting which of my controllers is which, and the pond one is the only one wired straight to the mains.

The controller is used to run a small kiln for drying and firing. In the beekeeping setup that mostly means baking clay smoker liners and drying wax moulds. It also gets used now and then for heat-treating small metal frame parts. Below is what I keep on the bench when I work on it.

| Tool | What I use it for | Where it lives |
|---|---|---|
| Insulated screwdriver set | Opening the terminal cover and tightening the screw terminals | Shed drawer |
| Clamp meter | Checking current draw on the heater leads | Shed shelf |
| Non-contact voltage tester | Confirming the supply is dead before I touch anything | Hook by the door |
| Digital multimeter | Continuity on the probe and relay wiring | Shed shelf |
| Spare thermocouple probe | Swapping in when readings look wrong | Labelled box |
| Heat-proof gloves | Handling the lid and the hot probe | Hook by the door |
| Notebook and pencil | Logging each firing and any odd behaviour | On the controller shelf |

### Notes on the main tools

The non-contact voltage tester is the most important item on the list. I test it on a known live socket first, then test the controller feed, then work. I never skip the first step, because a flat battery in the tester gives the same silent result as a dead circuit.

The clamp meter tells me more than the controller display does. If the displayed temperature looks fine but the current draw is low, one of the heater elements has usually failed. I noted this the first time it happened and it has been right every time since.

For cutting spare wooden mounting boards and trimming the shelf the controller sits on, I use the [[Tronas band saw]]. It is in a different building, so I cut everything to size before I carry it down to the pond. Cutting in the shed makes dust, and dust and a mains-powered controller do not belong together.

When I need to move air through the kiln chamber for faster cooling, I borrow the setup described in [[Lesglugen air compressor notes]]. That page has the hose fittings and the pressure I settled on. I do not repeat them here. The short version is that I only blow air through the chamber once the heater is off and the mains isolator is open.

### Things I do not use

I do not use a plug-in timer between the wall and the controller. I tried one early on and it hid problems, because the controller would lose its settings every time the timer cut power. The controller needs to see the mains continuously, and it handles its own schedule.

I also do not use extension leads. The pond shed has a fixed spur, and the controller is wired to it through a proper isolator. A lead lying near the water is a bad idea at any time.

## Safety

The controller is mains powered, it controls a heater, and it sits near a pond. Those three facts drive everything in this section. I treat the place as a wet location even though the shed itself is usually dry.

### Before any work

1. Turn the kiln off at the controller and wait for the chamber to cool.
2. Open the isolator and put a tag on it so nobody closes it while I am inside the cover.
3. Test the feed with the voltage tester, after checking the tester on a live source.
4. Only then take off the terminal cover.

I write these steps in the notebook at the start of each season. Reading them out loud is slower, but it stops me hurrying when a firing has gone wrong and I want to fix it quickly.

### Heat

The grey case of the controller stays reasonably cool in normal use, but the probe lead and the lid get very hot. I wear the heat-proof gloves for the lid and never for the electrics, because the gloves are not rated as electrical protection. I keep a separate pair of dry insulating gloves for the rare live check, and I try to avoid live checks entirely.

The kiln must stand on a non-flammable base. The board under it is cement sheet, not wood. The wooden shelf I cut on the [[Tronas band saw]] holds only the controller, well to the side, and it is lined with the same sheet on the kiln-facing edge.

### Water and damp

The pond is close enough that damp air is a real problem in autumn. I check the inside of the terminal cover for condensation each time I open it. If there is any, I leave the cover off with the isolator open until it dries, and I do not run a firing on a damp controller.

The mains supply to the shed goes through a residual current device. I press its test button before the first firing of each season and write the result down. If it does not trip, nothing gets switched on until it is replaced.

### Ventilation and fumes

Clay and wax mould work both give off smoke or fumes at some stage. I keep the shed door open during firing and I do not stay inside. Wax residue burning off a mould smells bad and can irritate the throat. The bees are kept well away from the shed while this is going on, since smoke and fumes near hives upset them.

### Other equipment nearby

Other devices in the area have their own notes. The level sensor in the pond is covered in [[Brindkrerk level sensor]], and its cable runs near the shed wall. I keep that cable away from the controller feed and I do not bundle them together. The valve that drains the settling tank is described in [[Murfes valve actuator]]. Both are low-voltage, and I do not want mains leads running alongside them.

### If something goes wrong

If the controller smells of burning, I open the isolator first and ask questions afterwards. I do not throw water on anything. I keep a dry powder extinguisher by the door, on the outside of the shed, so I can reach it without going past the kiln.

After any fault, the controller stays switched off and tagged until I have found the cause and written it down. I would rather lose a firing than guess.

## History

The Nevirkun kiln controller was installed in 2022, at the pond. Before that I fired things in a bare kiln with a manual energy regulator and a lot of guessing. The results were uneven, and I ruined more liners than I want to admit. Buying a proper controller was the first thing I did when I decided to make the shed a working space for beekeeping equipment.

The first season I only used it for drying wax moulds, because I did not trust it for higher temperatures. The grey case was fine in the damp, and the display stayed readable. Nothing in the first months failed, so by the end of that year I was firing clay liners as well.

The pond location was chosen because the shed already had a mains spur, and because the kiln needed to be away from the hives and the house. In hindsight the damp has been the main cost of that choice. I have had to add the isolator, the residual current device and the habit of checking for condensation, all of which are in the Safety section above.

Some of my thinking about power at the pond came from earlier work on other devices. The way I log runs comes from the [[Gioltrar solar charger log]], which taught me to write down every session, even boring ones. The comparison between mains and solar for the shed is in the [[Zumiol solar charger study]], where I concluded that a heater load is too large for a small solar setup. That is why the Nevirkun stays on mains.

Earlier still, the field trip recorded in [[Miokulgae Garko 2018]] showed me how other beekeepers handled wax and clay work, and several of them used controlled kilns. That was what pushed me towards getting one. I copied the habit of keeping a notebook right next to the equipment from that trip, and I have kept it ever since.

Over the years since 2022 I have swapped the thermocouple probe a few times, tightened the terminals after each winter, and replaced the shelf under the controller once. The controller itself has not been replaced. Each of these jobs is in the notebook, and later parts of this study will go through the records in more detail.

## Checklist

This is the routine I run on the Nevirkun kiln controller. It is a grey kiln controller that runs on mains power. I installed it in 2022 at the pond, and I use it for my beekeeping work, mostly wax and hive-tool firing jobs. The checklist is short on purpose. If it gets long, I skip it.

### Before each firing

- Look at the grey case for damp, dust or wax splashes. The pond air makes everything slightly wet, so I wipe the case before I open it.
- Check that the mains cable is dry along its whole run from the socket to the controller. Where it crosses the path by the pond, I look for chafing.
- Confirm the plug sits firmly in the socket and the socket cover closes.
- Read the display with nothing loaded in the kiln. It should show a sensible room temperature, not a blank or a wild number.
- Make sure the kiln lid closes cleanly and nothing flammable is within reach. Bee boxes, frames and smoker fuel stay well away.

### During a firing

- Stay within sight of the kiln. The pond is close, but I still do not walk off to the hives.
- Check the display at the start, in the middle and near the end of the run.
- Listen for the relay clicking. A steady, regular click means the controller is working. Rapid chattering means something is wrong.
- Keep a pen and paper near the kiln. I write down what I loaded and anything odd.

### After each firing

- Let the kiln cool fully before I touch the case or lid.
- Switch off at the wall, then unplug the controller if I will not use it for several days.
- Wipe the grey case again and note any marks or heat discoloration.
- Record the result in my log: what went in, how it came out, and whether the controller behaved.

### Checklist summary table

| Item | What I check | Why it matters |
|---|---|---|
| Case | Dry, clean, no wax splashes | Damp and wax shorten its life |
| Mains cable | No chafing along the pond path | Mains power is the main hazard |
| Plug and socket | Firm fit, cover closes | Loose contacts overheat |
| Display | Sensible reading when empty | Shows a faulty sensor early |
| Relay sound | Steady click, no chatter | Early sign of a worn relay |
| Surroundings | No flammable beekeeping gear nearby | Smoker fuel and frames burn |
| Cooling | Fully cool before handling | Avoids burns and case damage |

## Lessons

Most of what I know about this controller came from small mistakes. I have kept them here so I do not repeat them.

### The pond location is a mixed blessing

I put the controller at the pond because the ground is flat and the hives are not far off. The downside is moisture. In the first year after the 2022 installation, I found condensation inside the case after a cold night. Nothing broke, but the display flickered the next morning. Since then I keep a small bag of desiccant inside the case and I never leave the controller switched on overnight.

The pond also brings insects. Wasps and ants like the warm case. I now check the vents for nests before every run, which takes a few seconds.

### Mains power needs respect

Because the energy source is mains, I treat the controller like any other mains appliance outdoors. The cable is the weak point, not the controller. Twice I found the cable lying in a puddle after rain. I now lift it onto a dry support and I keep the socket under a cover. If the weather is bad, I do not fire at all. A wasted afternoon is cheaper than a repair.

I also learned not to share the socket with other tools. A drill or a pump on the same line can cause the controller to reset in the middle of a run. A reset during firing is the worst case, because the program has to be started again and the kiln may already be hot.

### Grey is hard to see

The grey case blends into the stones and the shaded corner by the pond. More than once I walked past it or put a bag down on it. I added a strip of bright tape to the support post, not to the controller itself, so I can see where it is from across the garden. It is a small thing, but it stopped me from knocking it.

### Trust the log, not memory

My memory about what temperature worked for which job was unreliable. After a few months of writing notes after each firing, I could see patterns I would never have remembered. For example, wax jobs came out better when I started with a gentle ramp. Without the log, I would still be guessing.

The log also helps me spot slow changes. If the same job starts taking longer than it used to, something is changing, usually the kiln elements, a sensor or a loose connection. I would rather find that early.

### Do not rush the cooling

I once opened the lid too early because I wanted to move on to the next job. The sudden change in temperature cracked a piece and warmed the case more than it should have been warmed. Now the rule is simple: if I am tempted to open the lid, I make tea first.

### Keep beekeeping and firing separate

Beekeeping gear carries wax, propolis and bits of fuel. All of these burn or smoke. I keep a clear zone around the kiln, and I change out of my hive gloves before I touch the controller. Propolis on the buttons is annoying, and it can hide a worn key.

### Small habits that paid off

- Photograph the display settings before changing them, so I can go back.
- Keep a dry cloth in a sealed tub near the controller.
- Look at the cable and plug at the start of every season, not only when something fails.
- Cover the controller when it is not in use, even for a short break.
- Write one line in the log even if nothing went wrong.

## Supplies

These are the things I keep near the pond so the kiln controller stays usable. I list them by purpose rather than by brand, since I do not need any particular maker.

### Protection and upkeep

- A weatherproof cover for the grey case, big enough to cover the cable entry as well.
- Desiccant bags for inside the case, replaced each season.
- Soft dry cloths and a small brush for dust and wax crumbs.
- Mild cleaner that does not leave a film on the display.
- Cable supports or a small plank to lift the mains lead off wet ground.
- A weatherproof socket cover.

### Safety

- Heat-proof gloves, kept separate from my hive gloves.
- A fire blanket and a small extinguisher within reach of the kiln.
- A bucket of dry sand, for the odd wax flare-up.
- A plug-in residual current device on the mains line, since the controller is outdoors.
- Eye protection for opening the lid after a hot run.

### Records

- A waterproof notebook and a pencil, kept in a sealed tub.
- A phone for photographing the display settings.
- Tape and a marker to label shelves and tools.

### Supplies table

| Supply | Purpose | Where it lives |
|---|---|---|
| Weatherproof cover | Shields the grey case from rain | On the support post |
| Desiccant bags | Keep the case interior dry | Inside the case |
| Cable supports | Keep the mains lead out of puddles | By the pond path |
| Heat-proof gloves | Handling hot kiln parts | Hook beside the kiln |
| Sand bucket | Smothers wax flare-ups | Under the bench |
| Notebook and pencil | Firing log | Sealed tub |
| Cloths and brush | Cleaning after each run | Sealed tub |

### Restocking rhythm

I check supplies at the start of each season, when I also inspect the cable and the plug. Desiccant is the item that runs out first, followed by cloths. The gloves and the extinguisher get a visual check only. If anything is missing, I replace it before the next firing, not after.

The point of this list is that the controller, which has been at the pond since 2022, keeps working without drama. It is a simple grey box on mains power doing a job for my beekeeping, and the supplies are mostly there to keep water, wax and careless habits away from it.

## Ideas

These are the questions I want to chase next with the Nevirkun kiln controller. It is a grey kiln controller, powered from mains, installed in 2022 at the pond. I use it in beekeeping work, mostly to keep wax and small metal parts at a steady heat. Nothing here is settled. These are leads.

**Ideas to test**

- Log the temperature at the pond over a full season and see how the controller behaves when the air is damp, cold or windy. The pond sits close to the unit, so moisture is the first thing I suspect.
- Compare the set temperature with a second, independent probe. I have never checked whether the display tells the truth, and the whole study depends on that.
- Time how long the controller takes to climb from cold to working heat on a mains supply that is steady, and then again when other tools are running on the same line.
- Write down every time the controller trips or resets. If it happens in the same weather or at the same hour, that is a clue.
- Try a simple cover or box to keep spray and condensation off the grey casing, and see if the readings become steadier.
- Check whether the beekeeping jobs differ in what they need. Melting wax wants gentle, even heat. Drying frames or tools may want something different.

**Things I would like to understand**

- Why the controller has held up since 2022 without a rebuild. Good luck, good design, or light use?
- Whether mains power at the pond is clean enough, or whether a surge guard would help.
- Whether the location is a good one at all. The pond is handy for water, but it may not be the best place for electrical gear.

**A rough plan**

1. Set up the second probe and compare readings for a week.
2. Start the log and keep it going through autumn and winter.
3. Add the cover and repeat the same checks.
4. Review the notes and decide whether to move the device or keep it where it is.

I should keep each test small. If a test needs more than an afternoon to set up, I will probably never do it.

## Overview

This section gathers the plain facts about the device so I do not need to look them up again. The note is a study of one object, so I list each property with its exact value.

| Property | Value |
| --- | --- |
| Name | Nevirkun kiln controller |
| Kind | kiln controller |
| Area | beekeeping |
| Color | grey |
| Energy source | mains |
| Year installed | 2022 |
| Location | pond |

**What the table means in practice**

The device is a kiln controller. Its job is to hold a heated space at a chosen temperature, switching the heat on and off as needed. In my case the heated space is used for beekeeping tasks, so the controller sits between the power supply and the heating element and decides when current flows.

It is grey. That sounds trivial, but color matters when I need to find it quickly in a shed or beside the water, and grey blends in with stone and weathered wood. I have put a bright strip of tape nearby so I do not walk past it.

Its energy source is mains. That means it needs a fixed connection to the wall supply and cannot be carried off to a field apiary. It also means I depend on the cable run to the pond, which is a point I want to check for damage and for wet joints.

It was installed in 2022, so at the time of writing it has been in place for several seasons. That is long enough to have a real history, and I want to reconstruct it from memory and any scraps of paper I still have.

Its location is the pond. Everything I learn about reliability has to be read with that in mind. Humidity, temperature swings, and the chance of splashes all come with the spot.

**How I use this overview**

When I am working on another part of the study, I come back to this table to confirm the basics. If I ever move the device or replace it, I will update the table first, so the facts here stay true to the real setup.

**Short summary of the state of things**

- The controller works and has been running since 2022.
- It is plugged into mains and fixed at the pond.
- Its main job is steady heat for beekeeping tasks.
- I have no measured proof yet of how accurate it is.

## Background

The reason for this study is simple. I keep bees, and a good part of the work around the hives needs controlled heat. Wax has to be melted without scorching. Small metal tools sometimes need warming or drying. A reliable controller makes all of that calmer and safer, and a poor one makes it a gamble.

**Why a kiln controller for beekeeping**

A kiln controller is built to hold a target temperature in an enclosed space. That is more than I strictly need for wax, but the idea suits me. I want a device that does one thing, does it the same way each time, and does not need constant watching. Beekeeping already asks for plenty of attention in the season, so any equipment that can look after itself is welcome.

**How it came to be at the pond**

I installed the Nevirkun kiln controller in 2022 and put it at the pond. The choice of place was practical. Water was close, which matters for cleaning and for safety if something heats up too far. The ground was flat and the work area was already there. I did not think much about damp air at the time, and that is the part I now question.

**What I knew then and what I know now**

When I installed it, I knew only the basics: it is grey, it runs from mains, and it controls a kiln. I did not keep a proper record of settings or of problems. Over the years I have noticed small things, such as how the unit feels after a long run and how it behaves on cold mornings, but these are impressions and not data.

That gap is the main reason for this note. I would rather have a short, honest record than rely on a vague feeling that the device is fine.

**Constraints I work within**

- The controller needs mains power, so it must stay near a safe supply.
- The pond location limits where I can place covers and cable.
- I use the device only part of the year, so long gaps in use are normal.
- I want any improvement to be cheap and easy to undo.

**What a good outcome looks like**

A good outcome is a clear picture of how the controller performs where it sits, backed by a few readings I trust. From that I can decide whether to leave it, protect it better, or move it. I also want a short checklist I can follow at the start of each season, so I do not have to rediscover the same points every year.

**Open worries**

- Moisture getting into the casing over time.
- A slow drift in the temperature reading that I would never notice by eye.
- Wear on the cable and plug from sun, frost and damp.
- The risk of working near water with mains equipment, which deserves care whatever the results of the study.

For that last point, I will treat safety as a first rule. If a test seems to raise the risk near the water, I will stop, switch off at the supply and rethink it before going further.

**Notes for later parts**

The later parts of this note will build on these basics. They will rely on the facts in the overview: grey, mains, installed in 2022, kept at the pond, used in beekeeping. If any of those change, the rest of the study should be read again with the new facts in mind.

## Open questions

These are the things I still cannot answer about the Nevirkun kiln controller after watching it for a while. It is a kiln controller, used in the beekeeping area, and it is grey. It runs on mains power. It was installed in 2022 and sits at the pond. Everything below comes from those facts and from my own notes, not from a manual.

**Why is it at the pond?** The location is the oddest property. A kiln controller normally sits next to the kiln. Here the controller is at the pond, and the work it supports is beekeeping. My working guess is that the pond gives a flat, damp-free-enough spot with a mains run already in place, and that the wax and hive-part work happens close by. I have not confirmed this. I need to ask whoever installed it in 2022 why the pond was chosen over a spot nearer the hives.

**What does it actually control in a beekeeping setting?** I can think of a few uses: drying and conditioning wooden frames, melting and clarifying wax, and baking small clay or ceramic pieces used around the apiary. I have only watched it in use for one of these. I want to write down which job each setting was meant for, because the same controller would need different temperature profiles for each.

**How does the mains supply behave at the pond?** The energy source is mains, which is good for steady heat. But the pond is far from the house. I do not know whether the supply sags when other equipment starts. If it does, the controller may misread its own readings or reset mid-cycle. A simple test would be to log the behaviour during a long run and note any restarts.

**What happens in a power cut?** I do not know whether it resumes where it stopped, restarts from the beginning, or stays off. This matters most for a long drying cycle. I should cut the power on purpose during a harmless test run and watch what it does when power returns.

**How has the grey housing aged?** The color is grey, and that is all I recorded at first. What I want to know now is whether the casing has faded, chalked, or cracked after the years outdoors near water. A pale or chalky surface would tell me the sun and damp are doing damage even if the electronics still work.

**Is anything sealed against moisture?** Being at the pond means humidity, spray, and cold mornings. I have not opened the unit to look for gaskets, a drip loop on the cable, or any sign of condensation inside. That is the first thing to check before I trust it through another winter.

**Who can service it?** Because this is an invented, unlabeled unit in my notes, I do not have a clear service contact. I should write down who installed it and whether they would still repair it.

Short list of what to do next:

- Ask about the reason for the pond location.
- Record every job it is used for.
- Run a deliberate power-cut test.
- Open the housing and photograph the inside.
- Log a full cycle and compare set temperature with a separate thermometer.

## Costs

I am keeping costs in plain terms here, not exact amounts, because I have not kept clean records and I do not want to invent figures. What matters for planning is where the money and effort go over time, and which items are one-off versus repeating.

**Buying and installing.** The unit was installed in 2022. That one-off cost covered the controller itself, the mains run out to the pond, and the labour to fix it in place. The mains run is probably the largest part, since the pond is a distance from the house. If I ever move the controller, I should expect to pay for that cable work again, so moving it is not a casual decision.

**Running cost.** The controller uses mains electricity. Heating work is the expensive part of any kiln job, and the controller itself draws very little compared with the heating element it switches. The real running cost depends on how often I fire up and how long each cycle lasts. In beekeeping the use is seasonal: more in the months of preparing frames and processing wax, almost nothing in deep winter. So the yearly cost is lumpy, not steady.

**Maintenance.** Maintenance is mostly time. Wiping the housing, checking the cable, and testing the sensor against a second thermometer cost little in money. Replacement parts are the unknown. If the sensor drifts or the housing seals fail, I will need parts, and I do not know how easy they are to get.

**Hidden costs.** These are the ones I tend to forget:

- Time walking to the pond for every check.
- Lost batches if a cycle fails and wax or frames are ruined.
- Electrician time if the supply needs improving.
- A weatherproof cover or box if the housing proves not tight enough.

Here is how I rank each cost type for planning:

| Cost item | One-off or repeating | Size, as I judge it | Notes |
|---|---|---|---|
| Controller and install (2022) | One-off | Large | Already paid; cable run was the bulk |
| Mains electricity | Repeating | Medium | Follows seasonal use |
| Sensor check and replacement | Occasional | Small | Depends on drift over time |
| Weather protection | One-off, maybe | Small to medium | Only if housing fails |
| Lost batches from failure | Occasional | Variable | Hardest to predict |
| Walking and checking time | Repeating | Small but constant | Because of the pond location |

The takeaway is that the biggest cost is already behind me. What is ahead is mostly small and recurring, with one wildcard: a failure that spoils a batch. That is why the open questions about power cuts and moisture matter financially, not only technically.

## Risks

The risks follow from the properties. A grey kiln controller on mains power, installed in 2022 at the pond, in a beekeeping area, has a clear set of weak points.

**Water and damp.** This is the top risk. The pond brings humidity, splashes, and condensation. Mains electricity near water is a safety issue, not just a reliability one. If the casing lets moisture in, the unit could fail or, worse, create a shock hazard. I should confirm the supply has proper protection and that the cable entry is sealed.

**Mains faults.** Because the unit runs on mains, a sag, spike, or cut can disrupt a cycle. A spike could damage the electronics. A cut could ruin a batch if the controller does not recover well. A surge protector or a dedicated circuit would reduce this, but I have not checked what is already there.

**Heat and fire.** Any kiln work carries fire risk. In a beekeeping area there is extra fuel nearby: wax, dry wood frames, and dry grass. A controller that misreads temperature could let things overheat. I must keep the surroundings clear and never leave a long cycle unattended until I trust its readings.

**Wax specifically.** Melted wax is flammable. If the controller is used for wax work and fails to cut power, the result could be a serious fire. This is the use case where I want a second, independent safeguard.

**Sensor drift.** Over the years since 2022 the sensor may have drifted. A small error is tolerable for drying but not for firing or wax work. A comparison with a separate thermometer is cheap and should be done regularly.

**Weathering of the housing.** The grey casing is exposed. Sun and cold can make plastic brittle. A cracked housing is both a moisture path and a safety problem.

**Access and distance.** The pond is far from where I usually am. That makes it easy to forget checks and slow to react if something goes wrong. A fault could run for a long time before anyone notices.

| Risk | Likelihood | Impact | First response |
|---|---|---|---|
| Moisture ingress at the pond | Medium | High | Inspect seals, add cover |
| Mains sag or cut | Medium | Medium | Test power-cut behaviour |
| Overheating near wax or wood | Low | Very high | Clear area, add backup cut-off |
| Sensor drift | Medium | Medium | Compare with second thermometer |
| Cracked grey housing | Medium | Medium | Inspect and replace if needed |
| Unnoticed fault from distance | Medium | High | Set a regular check routine |

My priority order is simple. First deal with moisture and electrical safety, since those can hurt a person. Second, add an independent safeguard for any wax work. Third, tidy up the routine checks so the distance to the pond stops hiding problems.

## Observations

These notes come from watching the Nevirkun kiln controller over several seasons. It is a kiln controller used in the beekeeping area, and I keep it in the study because it behaves differently from what I expected when I first set it up. The unit is grey, runs from mains power, and was installed in 2022. It sits at the pond, in a small shed on the bank, where the air is damp for most of the year.

The table below gathers the basic properties in one place, so I do not have to hunt through other parts of the note.

| Property | Value |
| --- | --- |
| Name | Nevirkun kiln controller |
| Kind | kiln controller |
| Area | beekeeping |
| Color | grey |
| Energy source | mains |
| Year installed | 2022 |
| Location | pond |

### How it is used

In the beekeeping work, the kiln is used for drying and softening materials rather than for firing pottery. I use it for warming wax blocks gently, drying small clay smoke-pot liners, and baking the hardening coat I put on a few wooden frame parts. The controller sets how much heat the kiln gets and for how long. I do not need fine control. What I need is a steady, repeatable warm-up, and a reliable cut-off at the end.

### Daily behaviour

The controller starts without fuss when mains power is on. The grey casing stays cool to the touch during normal runs, which is useful because the shed is cramped and I often brush against it. The panel is readable in daylight, but in the late afternoon, when sun comes low across the pond, the glare makes the display hard to read. I now tilt my head or shade it with a hand.

A few patterns I have seen repeatedly:

- Warm-up is smooth on dry days and a little slower on humid mornings.
- The controller holds the target heat well once the kiln is up to temperature.
- Cooling after a run is slow, and the controller does not seem to mind being left on during this stage.
- After a power cut, it does not resume the run by itself. It waits for me to start it again, which I count as a good safety habit.

### Effect of the pond location

The pond is the most interesting part of the setting. Being near water means the shed gets morning mist, and on cold nights there is condensation on the metal parts. The controller has come through four years of this without a failure of the core function, but I have noticed small signs of wear around the edges of the casing. The grey paint has dulled slightly on the side that faces the water.

I also pay attention to the mains supply. The shed gets its power through a long run from the main building, and the voltage seems to dip a little when other tools are used at the same time. The controller copes, but I try not to run the kiln while using a heavy saw or pump nearby.

### What I have learned about routines

Over time I have settled into a routine that suits the device:

1. Check the casing and cable for damp before switching on.
2. Wipe the display with a dry cloth.
3. Start the run only when I can stay nearby for the first part.
4. Note the start in the notebook, so I know how long it has been running.
5. After the run, switch off at the wall, not only at the controller.

This routine adds a minute or two but has saved me from several small surprises. I used to skip the damp check, and twice I found moisture inside the cable socket. Since I began checking, I have not had a repeat.

### Fit with beekeeping work

The kiln is not busy all year. Most use falls in late winter, when I prepare equipment, and again in autumn, when I clean up and store things. In summer it is mostly idle, because the bees need my attention and the shed is hot anyway. The controller does not mind long idle periods, but I have learned to run it empty once before the first real job of the season, just to see that it still behaves. That empty run has shown me early on when something is off.

### Comparison with what I expected

When I installed it in 2022, I assumed a kiln controller would need frequent adjustment. In practice, I set it, leave it, and come back. The simple behaviour fits the beekeeping jobs well. If I used it for ceramics with detailed firing schedules, I might find it limited, but that is not my use, so I have no complaint.

## Problems

None of the problems below is severe, but together they explain why I keep a close eye on the controller. I list them in the order I noticed them.

### Moisture and condensation

The biggest recurring issue is damp. The pond location means the air is wet, and the shed is not sealed. On cold mornings I sometimes find beads of water on the casing. The controller still works, but I do not like to switch it on in that state. I wait until the surface is dry. This delays work, and in a busy week it is annoying.

Things I have tried:

- Placing a small cloth bag of dry material near the unit. It helped a little, but it needs changing often.
- Moving the unit a short distance from the wall. This reduced condensation on the back, but not on the front.
- Covering the controller with a loose sheet when idle. This works, but I forget to remove it, and once I nearly started a run with the sheet in place.

### Display glare

The display is hard to read when low sun hits it. This is a small matter, but I have misread the setting once and started a run at the wrong level. Nothing was damaged, but it was a warning. I now double-check the setting by a second method, such as feeling the heat after a short time, before I walk away.

### Power supply dips

Because the supply is mains over a long cable, other tools in the shed can cause the voltage to drop. The controller has never failed during a dip, but I have seen the kiln heat more slowly when a pump was running. This affects timing rather than safety, though it can spoil a run if I rely on a fixed duration.

### Casing wear

The grey finish has dulled on the side facing the pond. There is no rust yet, but I treat it as an early sign. If the finish breaks, damp could reach bare metal. I plan to touch up the casing with a suitable coating during the quiet summer months.

### No automatic resume

I listed this as good behaviour above, but it is also a problem in practice. If the power cuts out while I am away, the run is lost, and I only find out when I return. For wax and clay, that usually means starting over. A simple way to notice a power cut remotely would help, but I have not set one up.

### Open questions

Several things remain unclear, and I want to keep testing:

- Whether the damp has any effect on the accuracy of the heat control, or only on the look of the casing.
- Whether a separate power line for the kiln would remove the dips.
- Whether a small hood over the controller would cut glare and moisture together.
- How much longer the unit will last in this location, given that it has now been in place since 2022.

### Next steps

For now, my plan is modest. I will keep the dry-cloth routine, add a shade over the display, and repair the casing finish. If the damp worsens, I will move the controller to a drier spot in the main building and run a cable to the kiln, even though that is less convenient. I will also write down each run in the notebook, so I can see whether the dips and the damp line up with any odd results.

## References

These are my own sources, listed in plain text. They are not links, and they all belong to this personal knowledge base or to my physical notebook.

- Shed notebook, entries on kiln runs at the pond since the installation in 2022. This is the main source of the observations above.
- My own notes on the kiln in the beekeeping area, covering wax warming, smoke-pot liners and frame coatings.
- A short sketch I drew of the shed layout, showing the position of the controller, the pump and the cable run from the main building.
- Notes on mains supply in outbuildings, written for myself after the first voltage dips.
- A checklist for seasonal equipment preparation, which includes the empty test run before the first real job.
- Photographs I took of the grey casing, used to compare the finish on the side facing the pond with the side facing the wall.
- The paper instruction sheet that came with the Nevirkun kiln controller, kept in the shed drawer. I consult it only for basic operation, since it says little about damp locations.

## Setup

This section records how the Nevirkun kiln controller is installed and what I checked on site. The device is a kiln controller used in beekeeping. I use it to run a small kiln for melting and drying beeswax, and the notes below are only about that use.

The basic facts are in the table. I copied them from my own records, so this is the reference I come back to when something looks wrong.

| Property | Value |
|---|---|
| Kind | kiln controller |
| Area | beekeeping |
| Color | grey |
| Energy source | mains |
| Year installed | 2022 |
| Location | pond |

### Where it sits

The controller is at the pond. It is a grey box, and the colour matters more than I expected. Against the wet stone and the dark reeds it is easy to miss, which is good for tidiness but bad when I come back in the evening and want to find it quickly. I now keep a strip of pale tape on the post next to it as a marker. The tape is not part of the device.

I installed it in 2022. Since then the position has not changed. The box is on a post above the damp ground, with the cable entry on the underside so water does not run in along the cable. After the first wet autumn I added a small drip loop in the cable, and I have not seen condensation inside the housing since.

### Power

The energy source is mains. There is no battery and no solar input, so if the supply drops, the controller stops and the kiln goes cold. I accepted that when I chose it. A wax kiln that fails off is safer than one that fails on, and a cold kiln only costs me time.

The mains run reaches the pond through a protected outdoor circuit. I do not touch the wiring myself beyond plugging in and unplugging at the outlet. Anything fixed in the wall or in the buried run was done by a qualified electrician, and I keep it that way. My own checks are limited to these:

- Look at the plug and the cable for cracks or chewing damage.
- Press the test button on the protective device at the start of each season.
- Check that the outlet cover closes fully.
- Wipe the housing and look for insects nesting in the vents.

### Physical check routine

I do a short walk-through each time I come to the pond to use the kiln. It takes a few minutes and has caught problems early more than once.

1. Look at the housing for cracks, swelling, or discolouration, which would suggest heat is building up inside.
2. Check that the cable entry is still sealed and the drip loop is still there.
3. Confirm the sensor lead is seated and has not been pulled by an animal or by the wind.
4. Make sure nothing is stacked against the box. Frames, boxes and wax blocks tend to migrate toward it.
5. Power it up and watch the display come to life before I load the kiln.

If any of these fail, I do not run a batch. I fix the problem first, even if the weather is perfect for working outside.

### Sensor and kiln layout

The sensor lead runs from the controller to the kiln chamber. I keep it short and out of the walking path. The kiln itself is a modest insulated box, and the controller only switches its heat source. It does not do anything clever about airflow. That limitation shapes how I use it. I load small batches, I leave the lid shut during a run, and I do not try to hurry a cycle by opening the door.

Because the pond is damp, the air near the kiln carries a lot of moisture on cool mornings. I have learned to let the kiln stand powered for a short while before loading it, so the chamber is dry before any wax goes in. Wet wax blocks and a damp chamber together give uneven results, and I would rather lose a few minutes than ruin a batch.

### Seasonal notes

In spring and summer the location is easy. The pond keeps the air a bit cooler, and the kiln does not fight the weather. In autumn the damp is the main enemy, and I check the cable entry and the vents more often. In winter I rarely use it, and when I do I bring the sensor lead indoors between sessions so the connector does not freeze wet.

When I put the device away for the cold months, I leave it installed but switched off at the outlet, with the kiln lid propped slightly so air can move. I have considered removing the controller entirely for winter, but the post mount makes reinstalling a nuisance, and so far it has been fine left in place.

### Things I would change

If I redid the installation, I would move the post slightly further from the water's edge. In a heavy rain the splash zone reaches closer than I would like. I would also add a small hood over the box. The housing is rated for outdoor use, but a hood is cheap and keeps the display readable in bright sun, since glare on a grey case and a dim screen is a poor combination.

## Software

The controller runs a single firmware image, and I treat it as something to leave alone unless there is a clear reason to change it. The firmware version of the Nevirkun kiln controller is v3.18.823. I wrote it on the inside of my notebook cover as well, because the display only shows it briefly at startup and I do not always catch it.

### What the firmware does

The firmware handles a small set of jobs, and the interface is deliberately plain. As far as I can tell from using it, it covers the following:

- Reading the sensor in the chamber and comparing it with the target.
- Switching the heat source on and off to hold that target.
- Running a timed cycle and stopping at the end.
- Showing the current reading and the state on the display.
- Refusing to start if the sensor is missing or reads nonsense.

That last behaviour is the one I trust most. If the lead is loose, the controller will not start a cycle, and it tells me so on the screen. I tested this on purpose by unplugging the sensor before powering up, and it behaved as I hoped.

### How I use the settings

I keep the settings minimal. I set the target and the duration, start the cycle, and walk away only after I have watched the first stretch of heating. Once the reading approaches the target and then settles, I know the control loop is behaving. If the reading overshoots badly or swings back and forth, I stop, let the kiln cool, and check the sensor placement before blaming the software.

For repeat jobs I write the settings in my notebook rather than relying on the device to remember them. That way, if the controller is reset or replaced, I lose nothing. A typical entry has the material, the target, the duration, and any remark about how the batch came out.

### Updating policy

My rule is simple: do not update the firmware in the middle of the season. The installed version works for my purposes, and a failed update on a unit at the pond, with the kiln half loaded, would be a headache. If I ever do update, I will do it indoors, on a day when I have no wax to process, with a stable mains supply and plenty of time.

Before any change I would do these things:

1. Write down the current firmware version and the settings I use.
2. Confirm the supply is steady and I will not be interrupted.
3. Run the unit empty after the change and watch it through a full cycle.
4. Compare the behaviour with my notes before trusting it with a real batch.

If the new version behaved worse, I would want a way back. I have not yet confirmed whether this device supports going back to an earlier image, so I treat any update as a one-way step until I know more. That uncertainty is the main reason I have not touched it.

### Known quirks

A few behaviours are worth recording, since they cost me time before I understood them.

- The startup screen is short. If I want to read the firmware version, I have to be looking at the display at the right moment, or power-cycle and try again.
- After a power cut, the controller does not resume the cycle. It comes back idle, and I have to start again. I consider this correct, but it means a batch interrupted by a cut must be judged by eye.
- Very damp mornings sometimes make the display slow to respond for the first moments. It clears once the housing warms slightly.
- The controller does not keep a log that I can read back. Anything I want to remember about a run, I write down myself.

### Troubleshooting order

When something is off, I follow the same order every time, from the cheapest check to the most involved.

1. Is the mains outlet live, and is the protective device not tripped?
2. Is the plug seated and the cable undamaged?
3. Is the sensor lead firmly connected and in the right place in the chamber?
4. Does the display show the firmware version at startup, confirming the unit boots?
5. Does the unit hold a low target without swinging?
6. If all of that is fine, run an empty cycle and watch the reading closely.

Nearly every problem I have had was in the first three steps. The software itself has been dull and stable, which is exactly what I want from a device sitting outside by the pond.

### Notes for later

I would like to find out whether the firmware has any hidden diagnostic screen, since the display seems capable of showing more than it does. I have not found one by pressing buttons, and I am wary of trying combinations on a device that controls a heat source. If I try, I will do it with the kiln empty and cold, and I will write down every step so I can undo it.

I also want to compare how the controller behaves across a full year, since so far I have only noted the damp-weather quirks in autumn. A tidy set of notes by season would help me decide whether a hood, a different mounting spot, or simply more careful habits is the right fix.
