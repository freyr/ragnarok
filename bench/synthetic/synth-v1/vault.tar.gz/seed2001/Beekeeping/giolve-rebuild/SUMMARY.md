---
type: summary
status: active
project: giolve-rebuild
area: beekeeping
description: "Summary about Giolve rebuild."
---

# Summary of Giolve rebuild

## Costs

The Giolve rebuild is a beekeeping project with the goal of rebuild. It started in 2025 and is a winter job, because the bees are clustered and the equipment is not in use. I keep the money side simple in this note. I do not track every small purchase here, only the groups of spending and how they feel against what I expected.

- Timber and boards for the new boxes are the largest group, and they are the one I watch most closely.
- Fixings, glue, and wax coating are small items, but they add up over a long winter.
- Replacement frames and foundation are the second largest group.
- Tools are mostly borrowed, so they cost very little. My neighbor, who leads the project, owns most of what we need.
- Transport of materials is covered by the neighbor's vehicle, and I pay for fuel when I remember.

So far the spending is in line with the plan. I have not had to cut anything. If timber prices move, I will note it here and decide whether to hold off buying the rest.

## Decisions

The go decision for the Giolve rebuild was made on 2024-12-20. That was the point where we agreed the old setup was not worth patching any further and that a proper rebuild was the better use of the winter.

Other decisions that came out of that talk and the weeks after:

- The neighbor leads. I help with the work and keep the notes, but the neighbor decides on the build order and on any design change.
- We rebuild during winter only. Nothing is opened, moved, or disturbed while the colonies are clustered, so the work stays on empty equipment and on the workshop side.
- We reuse sound parts. Boxes and frames in good condition stay, and only the failed or rotten pieces are replaced.
- We keep one standard size across everything, so parts can swap between boxes later without trimming.
- We use simple joints that we can cut with the tools we already have, instead of buying a special jig.

Decisions I have not made yet are in the open questions section, not here.

## History

The idea came from a poor result in the previous season. Several boxes had warped, the floors had started to rot, and some frames no longer sat true. Nothing was dramatic, but each inspection took longer than it should because of fighting with stuck parts. After the last inspection of that season, I wrote down that the setup was costing time and risking the colonies.

I talked it over with my neighbor, who has kept bees for much longer than I have. The neighbor offered to lead the rebuild and to lend the workshop space. We agreed on the rough scope, and the go decision followed, as recorded above.

Work in the winter of 2025 went in stages:

- First we sorted all the equipment into three piles: keep, repair, and scrap.
- Then we cleaned the keep pile, scraped off old propolis, and checked each piece for rot and loose joints.
- After that we started on repairs, beginning with the frames, since they are quick and show progress early.
- The new boxes were cut and assembled after the repairs, once we knew how many we really needed.

The project has since carried on into the later work. At the time of writing, the stage is mid-build: sorting and cleaning are finished, repairs are mostly done, and the new boxes are partly assembled.

## Open questions

Some points are still not settled, and I would rather list them than pretend they are decided.

- Should the floors be solid or screened? The neighbor prefers screened, and I lean the same way, but we have not tested it against our local damp.
- Which finish should go on the outside of the boxes? Paint lasts well but needs upkeep, and wax is gentler but wears faster.
- How many spare boxes should we build beyond what the colonies need? Spares are useful for splits, but they take storage space.
- Do we replace all old frames, or only the ones that fail a simple test? I want a clear rule so we do not argue over each one.
- When exactly does the work have to stop so everything is dry and ready before the bees become active? We need a firm last-day for the build.

I will move each of these to the decisions section when it is closed.

## Next action

The next action is NX-1662.

I keep it as a single item so I know what to do when I next sit down with the project. Everything else waits behind it. When it is finished, I will update this note, pick the next step from the open questions, and write a new next action.

## Checklist

A short list of the state of the work, as I see it now.

- [x] Go decision recorded
- [x] Neighbor confirmed as lead
- [x] Equipment sorted into keep, repair, and scrap
- [x] Keep pile cleaned and checked
- [x] Frame repairs mostly done
- [ ] New boxes fully assembled
- [ ] Floor type chosen
- [ ] Outside finish chosen
- [ ] Spare box count agreed
- [ ] Final check before the season changes
- [ ] Notes cleaned up and this summary closed

## Observations

Some things I have noticed while doing the work, mostly for my own memory.

Old propolis is much harder to remove when it is cold. We got better results by working in the warmest part of the day and by keeping the scraper sharp. A cheap hive tool does the job, but it needs regular filing.

Rot hides on the underside. Boxes that looked fine from above were soft at the bottom edge. I now check every piece from below before I decide to keep it, and I press a screwdriver tip into the wood to test it.

Working with a partner is much faster than working alone, mostly because of the lifting and holding. It is also useful because the neighbor often spots a problem I would have missed, such as a slightly twisted frame rail.

Keeping every part labelled saves time. A marker note on each piece, saying keep, repair, or scrap, stopped us from re-checking things twice.

Lastly, winter is the right season for this. There is no pressure from the colonies, the workshop is quiet, and mistakes cost only wood. I would plan the same way next time.

## Setup

This section records how the project is arranged, so I can pick it up after a break.

- Name: Giolve rebuild
- Goal: rebuild
- Area: beekeeping
- Start year: 2025
- Season: winter
- Lead: neighbor

The work happens in the neighbor's workshop, which has a long bench, good light, and room to stack boxes while they dry. Materials are stored along one wall, sorted by type, and finished parts are kept off the floor on spare boards to avoid damp.

Tools are shared. The neighbor supplies the larger ones, and I bring the hand tools, the marker, and a notebook. I take photographs of anything unusual, such as an odd joint or a repair that worked well, and I add short remarks to this note when something matters for later.

This summary is the main page for the project. It gives the stage, what is finished, the open points, and the next action. I update it after each work session, and I try to keep it short enough to read in a couple of minutes.
