---
type: drivers
status: active
project: giolve-rebuild
area: beekeeping
---

# Drivers of Giolve rebuild

## Setup

Giolve rebuild is a project in the beekeeping area. The goal is a rebuild. It started in 2025, in the winter season, and the lead is my neighbor. This note holds the drivers of the project: why we are doing it, what limits us, what it costs and how I will know it worked.

The short version: the Giolve apiary setup had worn down to the point where repairing it piece by piece no longer made sense. We decided to rebuild it properly, using the quiet winter months when the bees need little from us and the work does not disturb them.

## Background

The Giolve apiary grew without a plan. Hives were added whenever a colony needed a home, stands were made from whatever material was at hand, and the working area around them was never laid out. Over several seasons this caused real problems:

- Stands that sagged or tilted, so hives sat unevenly.
- Boxes that no longer matched each other, which made swapping frames between hives awkward.
- A wet, muddy path to the hives in early spring.
- Storage for equipment spread across three places, so something was always missing when needed.
- No sheltered spot for inspecting or for processing honey.

My neighbor offered to lead the work in 2025. They have built more outdoor structures than I have and are willing to give up winter weekends. I agreed that they decide the order of work and I handle purchasing and record keeping. That split matters, because the lead sets the pace and the pace is a major driver.

The main drivers, as I understand them:

- Colony health: dry, level, well-ventilated hives overwinter better.
- Safety: a solid path and stable stands reduce the risk of dropping a heavy box.
- Time: fewer wasted trips and less searching for tools.
- Standardization: one box size and one frame type throughout.

## Lessons

Some things from earlier work on the apiary shaped how we plan this rebuild.

- Do not move colonies in a rush. Past moves done in a hurry meant lost foragers and cross, unsettled bees. This time the stands are built and checked before any hive is touched.
- Cheap timber rotted fast in the damp corner. We pay more for treated material where it touches the ground.
- Write down every measurement. Twice I rebuilt something because I trusted memory over a note.
- Keep one person in charge of decisions. When two of us changed the plan midway, we wasted both material and a weekend.
- Leave a buffer. Weather in winter cancels more days than expected, so the plan assumes some days are lost.

Constraints that follow from these lessons:

- Work with the bees only on mild, calm days, and keep it brief.
- No heavy digging near the hives during the coldest weeks, when the colonies are clustered.
- Stay within the budget below and do not borrow against next season's equipment money.
- Keep access for the neighbor's tools and a safe place to store them.

## Schedule

The project runs through the winter season of 2025. I keep the schedule loose on purpose, but the order matters.

1. Clear and level the ground, and lay the path base first, since everything else depends on dry footing.
2. Build and set the new stands, checking each for level before use.
3. Put up the storage and the sheltered work spot.
4. Move the colonies last, on a calm mild day, one at a time, and only once everything else is finished.
5. Walk through the whole site, list what is still unfinished and fix it before spring buildup starts.

Success is measured simply, and I will check each point at the end of winter and again after the first full season:

- Every hive sits on a level stand and all boxes are a matching size.
- The path stays usable after rain without mud over the boot.
- All equipment lives in one place and can be found quickly.
- Winter losses are no worse than before, and ideally better.
- The work is done before the spring inspections begin.
- Spending stays inside the budget.

If most of these hold, the rebuild counts as a success. If the schedule slips, the colonies are the priority and the extras can wait.

## Budget

The budget of Giolve rebuild is 5315.24 EUR.

That figure covers materials for the stands, path base, storage and work shelter, plus the few new boxes needed to standardize. It does not pay for my neighbor's time, which is given freely, and I will return the favor in honey and help with their own projects.

I split the spending by priority. Stands and ground work come first because they affect the bees most. Storage comes second. The shelter comes last and is the first thing I cut if costs rise. I keep a running list of receipts in my notes so I can compare actual spending against the budget at each stage, and I will stop and review before buying anything that would push the total over.
