---
type: note
status: active
project: giolve-rebuild
area: beekeeping
description: "Note about Raemaertur Truthkon."
---

# Raemaertur Truthkon notes

## Schedule

Raemaertur Truthkon is my supplier contact for beekeeping. I have known him since 2025. The contact method is phone, and the time that works is evenings. That one fact shapes the whole schedule, so I plan my ordering around it rather than around my own daytime habits.

The practical rule: I do not try to reach Raemaertur during working hours. A missed call in the afternoon is not a problem, but it wastes the attempt and leaves me waiting. I prepare my list during the day and make the call in the evening.

Rough yearly rhythm of calls and orders:

- Late winter: first call of the year. I review what I used last season, what broke, and what I will need before the first inspections. This is the most important call because stock runs short once everyone starts ordering.
- Early spring: a follow-up call to confirm what is ready and arrange pickup or delivery.
- Late spring: a short call if I am expanding the number of colonies and need extra boxes, frames or feeders.
- Midsummer: a call about extraction supplies, jars, and anything to do with the honey harvest.
- Late summer: a call about autumn feeding and treatment supplies.
- Autumn: a check on winter preparations, such as entrance reducers and insulation material.
- Early winter: a quiet call to settle the account and talk about next year.

Weekly pattern when I am in an active ordering period:

| Day | What I do | Notes |
|---|---|---|
| Monday | Check stock in the shed | Write the shortfall list |
| Tuesday | Finalize the list | Remove anything I can make myself |
| Wednesday | Evening call to Raemaertur | Main attempt |
| Thursday | Evening call, only if Wednesday failed | Second attempt |
| Friday | Confirm pickup arrangements | Write down what was agreed |
| Weekend | Collect or receive goods | Check against the list |

I keep the call short and organized. Evenings are his own time, so I try not to drag the conversation out, and I never call late. If I get no answer, I leave a brief message with my name and a one-line reason, then try again the next evening.

## Problems

The recurring problems with this arrangement are mostly about timing and communication, not about the quality of what he supplies.

1. Phone only. Because the contact method is phone, I have no written record of what was agreed unless I write it down myself. In the past I misremembered a quantity. Since then I write a summary immediately after each call.
2. Evenings only. When I need something urgently during the day, such as during a swarm or a sudden shortage, I cannot get an answer quickly. I have to solve the problem some other way or wait.
3. Busy season overlap. In spring his evenings are probably full of calls from other beekeepers. Getting through can take two or three attempts.
4. Unclear lead times. He does not always say how long an item will take. I now ask directly at the end of every call.
5. Pickup coordination. Arranging a pickup by phone in the evening for the next day leaves little margin if something changes.
6. Mixed-up orders. Twice I got an item slightly different from what I intended because I described it loosely over the phone. I should describe items by their purpose and size, and repeat the order back to him.

Problems I have not seen so far, but keep in mind: sudden price changes without notice, long unexplained silence, and unreliable stock in peak weeks.

## Ideas

- Keep a standard call sheet template: date of call, items, quantities, agreed pickup, and anything he promised. Fill it in during the call.
- Ask whether a text message is acceptable for confirmations only, even if the main contact stays by phone.
- Order in two batches each year, one large in late winter and one smaller in midsummer, to reduce the number of calls.
- Build up a small private reserve of consumables so that a missed evening does not stop work in the apiary.
- Ask him which items he can reliably stock and which he orders in on request, and write that into the supplier list.
- Suggest a fixed evening slot, for example the same evening every month during the active season, so we both know when to expect the call.
- Learn which tasks I can do myself, such as assembling frames, so I order only the parts I truly need.
- Pool an order with another beekeeper I know to share delivery effort, if he agrees.
- Keep a short notebook near the phone dedicated to supplier calls.

## Costs

I do not record exact prices in this note, because they change and I would rather check the current figure at the time of ordering. What matters here is the structure of the costs.

Main cost categories in dealing with Raemaertur:

- Equipment: boxes, frames, foundation, feeders, and similar items.
- Consumables: feed, treatment supplies, and small items that get used up each season.
- Harvest items: jars, lids, filters, and labels.
- Transport: fuel for pickup, or delivery charges if he delivers.
- Time: evening calls and the trip to collect, which cost me personal time too.

Ways I keep costs under control:

- Compare what I intend to buy with what I already have before each call.
- Avoid last-minute orders, which usually mean paying more or accepting a substitute.
- Buy common consumables in larger amounts if storage is dry and cool.
- Ask for a clear total before agreeing to an order, and write it down.
- Keep receipts together in one folder for the year.

At the end of each year I add up what I spent with him and compare it with what the colonies produced, so I know whether the arrangement still makes sense.

## Risks

- Single supplier dependence. If Raemaertur is unavailable, I have no immediate alternative. I should identify at least one backup source.
- Availability window. Evenings are the only reliable time, so a busy week for me can mean a skipped order.
- No written trail. Phone-only contact raises the chance of disputes about what was agreed.
- Seasonal stock shortage. If I call late in spring, popular items may be gone.
- Quality variation. Equipment that does not fit my existing hives causes delays and extra cost.
- Relationship risk. I have known him only since 2025, so trust is still being built. Being late with payment or changing orders repeatedly could harm it.
- Health and colony risk. If treatment supplies arrive late, colonies may suffer. I should order these well ahead.

Mitigation in one line: order early, write everything down, keep a small reserve, and know a second supplier.

## Checklist

Before the call:

- [ ] Check it is evening and not too late
- [ ] Review stock in the shed
- [ ] Write the shortfall list with sizes and purposes
- [ ] Have the call sheet and a pen ready
- [ ] Note any questions about lead time and price

During the call:

- [ ] Greet and state what I need
- [ ] Go through items one by one
- [ ] Repeat the order back
- [ ] Ask about lead time
- [ ] Ask for the total
- [ ] Agree on pickup or delivery

After the call:

- [ ] Write the summary immediately
- [ ] Put pickup in the calendar
- [ ] Set a reminder to check in if nothing arrives
- [ ] File the call sheet

On receiving goods:

- [ ] Count everything against the list
- [ ] Check sizes and condition
- [ ] Pay as agreed and keep the receipt
- [ ] Store items properly

## Safety

Most safety concerns are about the goods and the handling of them, not about the contact itself.

- Treatment products must be stored away from food, children and pets, and in their original containers with labels intact.
- Always read the instructions that come with any treatment and follow them. If I am not sure, I ask Raemaertur or another experienced beekeeper before using it.
- Wear gloves and eye protection when handling treatment substances.
- Heavy boxes full of frames can hurt your back. Carry them with a second person or use a trolley.
- When collecting goods, secure them in the vehicle so they do not shift.
- Sugar feed and sticky items attract pests, so store them sealed.
- If I meet him in person for a pickup in the evening, I make sure it is in a well-lit place and that someone knows where I am going.
- Used equipment from any source should be checked for signs of colony disease before it goes near my hives.

## Open questions

- Does he have a preferred latest hour for calls in the evening?
- Would he accept a text message for confirmations?
- Which items does he always keep in stock, and which does he order on request?
- Does he deliver, and if so, to what distance?
- What are his payment preferences?
- Does he offer any discount for larger or early orders?
- How does he handle returns or faulty items?
- Is there a second supplier he would recommend if he cannot help?
- Will he be available throughout the winter, or does he reduce his activity?
- How does he prefer to handle orders from several beekeepers combined?

## Contracts

The contract date of Raemaertur Truthkon is 2018-06-18.

That is the date recorded for the agreement. It is earlier than the year I first met him, 2025, so I treat it as the date of the contract itself and not as the start of our personal contact. I know him since 2025, and the contact is by phone in the evenings.

Things I want to keep in mind about the contract:

- Keep a copy of the paperwork in the folder with supplier documents.
- Note what the contract covers, such as which goods, which obligations, and how disputes are handled.
- Check whether there is any term about renewal or notice.
- If any change to the arrangement is agreed by phone, write it down and, where it matters, confirm it in writing.

I do not rely on memory for terms. When in doubt, I read the document before the next call.

## Tools

Tools that help me manage this relationship:

- A phone with the contact saved under his full name and a note about evenings.
- A paper notebook for call sheets, kept near the phone.
- A calendar with reminders for the yearly call rhythm.
- A simple spreadsheet listing items, usual quantities, and when I last ordered them.
- A folder, physical and digital, for receipts and delivery notes.
- A tape measure and a notepad for checking sizes before ordering.
- A trolley or sack barrow for moving heavy boxes.
- A marker and labels for marking new items as they arrive.

Optionally, a recording of key details by voice memo straight after the call, if writing is not possible at that moment.

## Supplies

What I typically get through this supplier contact, grouped by area:

Hive equipment:
- Hive boxes and lids
- Frames and foundation
- Floors and entrance reducers
- Queen excluders

Feeding:
- Sugar and feed
- Feeders of different kinds

Health and treatment:
- Seasonal treatment products
- Cleaning materials for equipment

Harvest:
- Jars and lids
- Strainers and filters
- Labels
- Buckets with taps

Protective gear:
- Gloves
- Veils
- Suits

Small items:
- Smoker fuel
- Hive tools
- Marking pens for queens

I keep a minimum stock for the cheap and frequently used items so I am not forced into an emergency call.

## Background

Raemaertur Truthkon is a supplier contact in the area of beekeeping. I have known him since 2025. We deal with each other by phone, and the time he is available is evenings.

He is not a close friend. The relationship is practical and polite. I met him through my beekeeping activity, when I needed a reliable source of equipment and supplies and was told he was someone to call. Since then, I have built up a pattern of calling him a few times per season.

What I value about him: he answers questions plainly, he knows the local conditions for keeping bees, and he is willing to explain how to use a product when I am unsure. What I find less convenient: the narrow availability window and the lack of written communication.

Summary of the properties for quick reference:

| Property | Value |
|---|---|
| Name | Raemaertur Truthkon |
| Type | Person |
| Role | Supplier contact |
| Area | Beekeeping |
| Contact | Phone |
| Availability | Evenings |
| Known since | 2025 |

## References

- My own call sheets, kept in the notebook by the phone.
- The supplier folder with receipts and delivery notes.
- The contract document mentioned in the Contracts section.
- My yearly beekeeping calendar, which lists when to order.
- My spreadsheet of items and quantities.
- Notes from other beekeepers about alternative suppliers, which I should collect over time.
- The instruction leaflets that come with treatment products.

When I add a new reference, I write down where it is kept so I can find it quickly.

## History

- Before 2025: I did not know him. I sourced supplies from elsewhere or made do with what I had.
- 2025: I was introduced to Raemaertur Truthkon and began dealing with him as my supplier contact. The first calls were short and about basic equipment.
- 2025, first season: I learned that evenings are the only reliable time to reach him, and that phone is the way he prefers to be contacted. I started writing summaries after each call after one quantity was misunderstood.
- 2025, later in the year: I placed orders for harvest and winter supplies and began to see which items he stocks reliably.
- 2026: I settled into a routine of a late winter call, a spring follow-up, and a midsummer call. I started the call sheet system and began thinking about a backup supplier.

The note will grow as more happens. When something changes in the arrangement, such as a new contact method, a different availability, or a change in what he supplies, I add it here with the year.
