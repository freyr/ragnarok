---
type: summary
status: active
project: saekrus-survey
area: beekeeping
---

# Summary of Saekrus survey

## Costs

The Saekrus survey has been a cheap project so far. Most of the cost is my own time and a bit of fuel for driving to the apiary sites. I have not bought any special equipment for it. The lead, a plumber, has used his own tools and a few spare fittings from other jobs, so nothing has been billed to the project.

What I do track:

- Fuel for site visits, which is small and spread over the spring visits.
- Paper notebooks and pens for field notes.
- A small amount of food and drink on long survey days.
- Nothing for software, since I keep everything in the vault.

I have not set a hard budget. The survey goal is simple enough that I do not expect costs to grow. If the work expands into a second season, I will write down a proper budget before I spend anything new. For now this section is more a reminder that the project is meant to stay low cost.

## Decisions

The project went through a short decision stage before it started. The go decision date of Saekrus survey is 2020-06-19. I made that call after talking through the scope with the lead and agreeing that a survey was the right goal, rather than a full management plan or a build project.

The main decisions so far:

- The goal is a survey. I want to know what is there before I change anything.
- The area is beekeeping, and I keep all notes about this project inside that area.
- The season is spring, because that is when the colonies are most active and easiest to compare.
- The lead is a plumber. He knows the sites well and has access to most of them, so he leads the fieldwork.
- The project start year is 2021, even though the go decision came earlier. The gap was used to wait for the right season.

I decided against widening the scope. Early on there was an idea to add water supply checks for each site, since the lead is a plumber and would be good at it. I parked that, because it would blur the goal. If it still looks useful after the survey, it can become a separate project.

## Next action

The next action of Saekrus survey is NX-2233.

This is the one thing I should do next, and I should not start anything else in the project until it is done or clearly blocked. When it is finished, I will update this note, replace the next action with the following step, and add a line to the history.

## Setup

The setup is plain on purpose. The project is called Saekrus survey. It is a project note with the goal set to survey. The area is beekeeping. It started in 2021, in spring. The lead is the plumber.

How the work is organised:

- One note for this summary, which holds the stage, the open points and the next action.
- Field notes written on paper during visits and typed up afterwards.
- A simple list of sites, each with a short description and the date of the visit written in plain words.
- A habit of writing up the notes the same day, while I still remember details.

The lead and I agreed on a few working rules. We visit in good weather only. We do not open hives more than we need. We note what we see rather than what we think should be there. If something looks wrong, we write it down and leave it, and I decide later what to do about it.

I keep the survey method the same at every site, so results can be compared. That means the same order of checks, the same kind of notes, and the same level of detail. If we change the method halfway, I will say so here, and mark which sites used which version of it.

## Overview

Saekrus survey is a spring project in the beekeeping area. Its goal is to survey the sites and colonies, to get a clear picture of the current state before any changes. It began in 2021 and is led by the plumber.

Stage: the project is in the middle of fieldwork. The planning is finished, the method is settled, and a good part of the sites have been looked at. The write-up has started but is not complete.

What is done:

- The scope was agreed and the go decision was made.
- The method for visits was worked out and tested on the first site.
- Most of the planned site visits have been done, and the notes from them are typed up.
- The costs have been kept near zero.

What is not done:

- A few sites are still waiting for a visit.
- The notes have not been compared across sites yet.
- There is no final summary of findings.

My overall feeling is that the project is healthy. It is small, it has a clear goal, and the lead is reliable. The main risk is that the spring window is short, so any delay in visits pushes the work into the next season. That is why the next action matters and why I keep this note short and current.

When the visits are complete, I plan to read through all the notes in one sitting and pull out a short list of findings. I would like that list to be practical: which sites are in good shape, which need attention, and what a follow-up project might look at.

## Open questions

There are a few points I have not settled yet.

- How many sites are enough? I have a rough list, but I do not know if some can be skipped without losing the picture.
- Should the survey cover only the colonies, or also the surroundings, such as water and forage nearby? The surroundings matter, but I do not want the scope to grow.
- What is the best way to compare sites? I might use a short table with the same columns for each, but I have not decided on the columns.
- Who reads the results besides me? If the lead wants a copy, I need to write it in a way that is useful to him, not only to me.
- Is one spring enough, or will I need to repeat parts of the survey next year to see change over time?
- Where will the final findings live? A new note in the beekeeping area seems right, but I have not created it.

I will move each of these either to Decisions or to Ideas once I have an answer. If an item stays open for too long, I will make a call anyway so that it does not block the write-up.

## History

A short log of how the project got here.

- Before 2021: the idea of a survey came up, and the scope was discussed with the lead.
- The go decision was made on 2020-06-19, after the scope was agreed.
- 2021, spring: the project started, with the plumber as lead. The method was tested on the first site and then used on the others.
- Through the spring: site visits were done in good weather, and the field notes were typed up soon after each one.
- Later: I wrote this summary to pull everything into one place and to set the next action.

Nothing major has gone wrong. A few visits were moved because of weather, and one site took longer than expected because access was awkward. These were small delays and did not change the plan.

I will keep adding to this list whenever something worth remembering happens, such as a change of method, a new decision, or a change of lead.

## Ideas

These are things I might do, but none are committed.

- Make a one-page checklist for visits, so the method is easy to repeat and easy to hand to someone else.
- Take simple photos at each site, always from the same angle, to help compare later.
- Ask the lead to look at the water setup at each site as a separate small project, since that is his trade.
- Create a short table of findings, with one row per site and a few plain columns.
- Repeat the survey in a later spring, to see what has changed.
- Write a short note on lessons learned, covering what worked in the method and what I would change next time.

If any of these turns into real work, I will give it its own note and link it from the project through plain text rather than clutter this summary. For now, the focus stays on finishing the survey and writing up the findings.
