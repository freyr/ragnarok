---
type: note
status: active
project: saekrus-survey
area: beekeeping
description: "Note about Laga level sensor."
---

# Laga level sensor notes

## Background

The Laga level sensor is a green level sensor used in my beekeeping setup. It runs on mains power and has been installed in the cellar since 2015. I use it to keep an eye on the liquid level in the cellar during the season, so I do not have to go down and check by hand.

Main points about the device:

- Kind: level sensor
- Area: beekeeping
- Color: green
- Energy source: mains
- Year installed: 2015
- Location: cellar

The cellar can get damp, so I compared it with the setup described in [[Glurkolel dehumidifier study]]. For the logging side I used ideas from [[Tritapel data logger study]]. The honey and equipment routine in [[Saerkol shed]] is separate, but I follow the same checking habit there.

## Measurements

I measured the power draw of the Laga level sensor with a plug-in meter while it was running normally.

- Measured power draw: 161.55 W
- Power source: mains, so no batteries to replace
- Placement: cellar, away from the wall where water collects

That is higher than I expected for a sensor, so I want to check it again. Earlier notes in [[Miokulgae Garko 2018]] and [[Lenkaenpun Nigli 2021]] are the ones to compare against when I look at how the readings have changed over the years.
