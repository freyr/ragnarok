---
type: plan
status: active
project: saekrus-survey
area: beekeeping
description: "Plan about Peboth Traerren."
---

# Peboth Traerren plan

## Maintenance

This plan covers how I keep the working relationship with Peboth Traerren in good shape. Peboth is my mentor in beekeeping. I have known Peboth since 2012, and contact has always been in person. There is no phone routine and no message routine, so the plan has to work around that. Availability is weekends only, which means anything I want to ask has to wait until a weekend or be written down and saved for the next visit.

Maintenance here means three habits.

- Keep a running list of questions during the week. I write each one in the apiary notebook at the moment it comes up, not later from memory.
- Turn up when I said I would. Weekends are the only time Peboth is free, so a missed visit costs me a whole week at least.
- Report back. After I try something Peboth suggested, I say what happened at the next visit. A mentor who never hears the result stops giving good advice.

I also keep the equipment side tidy so that visits are spent on learning rather than on fixing my mess. Hive tools get scraped and cleaned after each visit. The smoker is emptied and checked. Veils and gloves are washed on a regular schedule, and any torn seam gets repaired before the next weekend, not after a sting.

Beyond the gear, I look after the notes themselves. Each visit gets a short entry under Observations, and anything that changes my plan moves into Lessons. Once a season I reread the whole set and prune what is no longer true.

## Costs

I am not recording any prices in this note. The costs that matter are mostly not money, so I list them by kind.

**Time.** The largest cost is weekend time. Peboth is only available on weekends, so each visit takes a good part of a Saturday or Sunday. That time competes with the garden, the workshop and family. I treat it as the main budget.

**Travel.** Contact is in person, so I have to go to Peboth, or Peboth comes to my hives. Fuel and the wear on the cart are the practical costs. Where possible I combine a visit with other errands.

**Goodwill.** A mentor gives time freely, and I want to give something back. I bring honey, help with heavy lifting at the other apiary, and do the dull jobs such as scraping frames and washing boxes. These are small things, but they keep the exchange fair.

**Materials.** Frames, foundation, feed and treatments are bought as needed. I will keep exact figures in a separate ledger rather than here, because prices change and the note should stay stable.

**Equipment loans.** Sometimes I borrow tools. The [[Tronas band saw]] in my workshop is useful for cutting hive parts, and I have offered Peboth the use of it in return for borrowed extraction gear. A loan is a cost if something breaks, so I check the item before and after.

## Open questions

These are things I still want to ask Peboth, or work out myself and then check with Peboth.

- How should I judge when a colony is strong enough to split, and how much of the decision is timing versus colony size?
- What is the best way to handle a hive that turns defensive late in the season? I want to know whether to requeen or just wait it out.
- How much ventilation is too much in winter? I have read conflicting advice, and Peboth has a view that I want to hear in full.
- Can I rely on sensors to tell me about hive moisture, or is it better to open the hive and look? The [[Glurkolel dehumidifier study]] raised this for me, since moisture control in a closed space has similar problems.
- Is it worth setting up a data logger at the hives at all? I have the [[Liolkrios data logger]] and I am not sure what to record.
- What should I do about the long gap between early spring checks, when Peboth is busy with their own bees?
- How do I know when I have learned enough to stop asking about a particular topic?

I will cross out each question once it has an answer and move the answer to Lessons.

## Supplies

Here is what I keep ready for visits and for general work with Peboth. The table sets out each item, what it is for, and where it is kept.

| Item | Purpose | Where kept |
| --- | --- | --- |
| Hive tool | Prying boxes and scraping propolis | Coat pocket and shed |
| Smoker and fuel | Calming the colony | Shed shelf |
| Veil and gloves | Protection during inspections | Back porch |
| Notebook and pencil | Recording questions and answers | Always in the bag |
| Spare frames | Replacing damaged comb | Workshop |
| Feeder | Autumn and early spring feeding | Shed |
| Jars and lids | Gifts of honey for Peboth | Kitchen cupboard |
| First aid kit | Stings and small cuts | Bag and shed |

Beyond the table, a few things deserve a note.

The [[Brindkrerk level sensor]] is something I may fit to a feeder or a water container, so I do not have to open things just to check a level. It is not yet part of the routine. The [[Liolkrios data logger]] is the likely partner for it, since a level reading is only useful if I can see it over time.

For the [[Lioder greenhouse notes]], I keep a short list of plants that bees favor, since the greenhouse and the apiary share the same small plot. Peboth has given me opinions on what flowers early and what flowers late, and I keep those in the greenhouse notes rather than repeating them here.

## Lessons

Most of what I know about bees came from Peboth, so this section is the center of the note. I record each lesson in a single plain sentence and add a short reason.

- Look before you open. Watch the entrance for a minute first. Traffic, pollen color and behavior at the landing board tell a lot before any box is lifted.
- Move slowly and smoke lightly. Too much smoke agitates a colony as much as none at all.
- Do less than you think you need to. Peboth tends to say that every inspection is a disturbance, and the colony pays for it.
- Write it down immediately. Memory lies about which hive had which problem.
- Keep strong colonies strong. Splitting too early weakens both halves.
- Ask the same question at different times of year. The answer often changes with the season.
- Weekends are for learning, weekdays are for preparation. If I show up with the gear ready and the questions written, the visit goes far better.

One more lesson is about the relationship. A mentor is not a service. Peboth chooses to spend time with me, and the best way to honor that is to act on the advice and report back honestly, including when I got it wrong.

## Overview

Peboth Traerren is my mentor in beekeeping. The subject properties are simple and I keep them together here for quick reference.

- Role: mentor
- Area: beekeeping
- Contact: in person
- Availability: weekends
- Known since: 2012

I have known Peboth since 2012, and in that time the relationship has moved from occasional advice to regular guidance. I do not call or write to arrange things in the middle of the week. Arrangements are made face to face, usually at the end of one visit for the next.

The purpose of this plan is to make that arrangement dependable. Because contact is in person and availability is limited to weekends, I cannot easily get a quick answer in an emergency. So the plan has three parts: prepare well for each visit, keep a record of what I learn, and build enough knowledge of my own that I need Peboth less for routine matters and more for the hard judgments.

Related notes that touch this plan include the [[Staeraerk Piostrond plan]], which covers another long project that I keep in parallel, and the [[Lioder greenhouse notes]], which cover the shared plot. I also keep the [[Stalbrol Baerna]] note nearby for the same reason: it holds material that I sometimes need to consult during a beekeeping visit.

## Schedule

The schedule follows the seasons and Peboth's weekend availability. I do not put exact dates here, because they shift with the weather and with Peboth's own work.

**Early spring.** First weekend visits after the cold breaks. Goals are to check stores, confirm each colony is alive and queenright, and plan the first full inspection. I bring questions about feeding and about whether any colony needs combining.

**Mid spring.** Weekly or near-weekly weekend contact where possible. This is the busiest learning period. Topics include comb building, swarm signs and the timing of splits.

**Early summer.** Visits focus on swarm control and on adding space as the colonies grow. I also ask Peboth to look over my records and tell me what I am missing.

**Late summer.** Honey harvest and the start of treatment decisions. This is the time I most want Peboth present, since mistakes here carry into winter.

**Autumn.** Feeding, reducing entrances and checking for strong stores. I decide with Peboth which colonies go into winter as they are and which should be merged.

**Winter.** Few visits. Mostly conversation and planning. I use this time to repair gear, cut hive parts on the [[Tronas band saw]], and write up the lessons from the year.

Each visit is arranged at the end of the previous one, in person, for a weekend. If a weekend falls through, I move to the next one and do not try to reach Peboth by other means.

## Contracts

There is no formal contract in the usual business sense. The relationship is a mentoring arrangement between two people who have known each other for a long time. Even so, I once wrote down a simple agreement so that expectations were clear on both sides, and I keep the date of it here.

- Contract date of Peboth Traerren: 2022-10-24

The agreement was short and practical. It covered how often we meet, which is on weekends, what I would do in return, and how we handle disagreements about methods. It did not involve payment. It was about respect for time and about being honest regarding what I would and would not do with the advice.

Key points as I remember them:

- Meetings are in person, on weekends, by arrangement at the previous meeting.
- I take responsibility for my own hives and decisions. Peboth advises but does not take over.
- If a colony is in real trouble, I may ask for an extra visit, and Peboth will say whether that is possible.
- Equipment borrowed from either side is returned clean and in working order.
- Either of us can end or change the arrangement without any hard feelings.

I review these points once a year, usually in winter, and note whether any should change.

## Setup

Setup describes how I arrange the apiary and my notes so that a weekend visit with Peboth is efficient.

**At the hives.** Each hive has a clear working space around it, with a flat spot for setting down boxes and a bucket for burr comb. I keep the stands level and the grass cut. A cluttered site slows everything and is unsafe when bees are flying.

**Tools laid out.** Before Peboth arrives, I put the hive tool, smoker, fuel, spare frames and notebook on a table near the apiary. That way nobody hunts for gear mid-inspection.

**Notes.** Each hive has a line in the notebook and a matching entry in my digital notes. Before each visit I reread the last entry so I can pick up where we stopped.

**Monitoring.** I am considering sensors. The [[Brindkrerk level sensor]] could watch a water or feed level, and the [[Liolkrios data logger]] could record readings over time. The idea is to cut down on unnecessary hive opening. I will not fit anything without talking it over with Peboth first, because Peboth may well think it is more trouble than it is worth.

**Moisture.** The [[Glurkolel dehumidifier study]] gave me ideas about controlling damp in enclosed spaces. A beehive is not a sealed room, so I will use those ideas carefully, mainly for the storage shed where supers and frames are kept.

**Workshop.** Hive parts are cut and repaired in the workshop, using the [[Tronas band saw]] for boxes and frames. I keep a clear bench so that repairs get done in the week and are ready by the weekend.

## Safety

Safety matters on two levels: personal safety around the bees, and sensible care in how I use other people's time and equipment.

**Stings.** I wear a veil and gloves on every inspection. I know that some people develop a serious allergy over time, so I keep a first aid kit in the bag and in the shed, and I make sure someone knows when I am at the hives. Peboth has taught me to stay calm after a sting, to scrape the stinger out sideways, and to move away from the spot because the alarm scent attracts others.

**Smoke.** The smoker is a fire risk. I use it on bare ground or a stand, never near dry grass, and I make sure it is fully out before it goes back in the shed.

**Lifting.** Full boxes are heavy. I lift with my legs, ask for help when a box is full, and do not lift alone when tired. Peboth is strict about this one.

**Tools.** Hive tools and knives are sharp. The [[Tronas band saw]] needs full attention, guards in place and no loose sleeves. I never use it when I am rushed or distracted.

**Heat and kiln work.** If I ever dry wood or wax with heat, I will first consult the [[Nevirkun kiln controller study]] and treat the process with caution. Wax is flammable and must not be left unattended.

**Visitors.** Anyone who comes to the apiary is told where to stand and what to do if bees become agitated. Children and pets are kept away from the hives.

## Problems

These are the difficulties I have run into, or expect to, in working with Peboth and with the bees.

**Limited access.** Availability is weekends only and contact is in person. If a problem arises on a Tuesday, I cannot just ask. I have to decide myself, write the situation down, and bring it to the next weekend. This has sometimes led to bad guesses on my part.

**Weather clashes.** A weekend of heavy rain or wind can cancel a visit. If this happens at a critical time, such as swarm season, the delay can matter. I handle it by using the days before to prepare options, so that a short visit can still cover the main points.

**Different methods.** Peboth has habits built over many years, and I sometimes read different advice elsewhere. I have learned to bring the conflict up openly instead of quietly doing my own thing. Usually there is a reason behind the method that I had not understood.

**Overreliance.** It is easy to defer every decision to Peboth. That is not fair to either of us. I try to make a call first, then ask whether it was sound.

**Record gaps.** When I forget to write something down, I lose the lesson. The fix is to carry the notebook everywhere and to write before leaving the apiary.

**Data without meaning.** The [[Liolkrios data logger]] can collect more numbers than I can interpret. Without a clear question, the data is just noise. I want a specific purpose before I set it up.

## Risks

Risks are the larger things that could go wrong over the longer term.

**Losing the mentor's time.** Peboth is a volunteer in this role. Life changes, health changes, and availability might shrink further. To manage this, I am building my own knowledge steadily and keeping clear notes so I can carry on if visits become rare.

**Colony loss.** Colonies can fail from disease, starvation, queen problems or a hard winter. Peboth has taught me early signs, and I check stores and brood pattern regularly. A loss is not a failure of the relationship, but it should be discussed honestly so I learn from it.

**Disease and pests.** Mites and other problems can spread between apiaries. I follow Peboth's guidance on monitoring and treatment, and I tell Peboth quickly if I see anything unusual, since it may affect Peboth's bees too.

**Equipment failure.** A broken tool at a bad moment can derail a visit. I keep spares of the cheap essentials and inspect the larger items before the season starts.

**Misapplied advice.** Advice that suits Peboth's location and bees may not suit mine. I note local differences, such as forage and exposure, and adjust.

**Over-instrumenting.** Adding sensors, such as the [[Brindkrerk level sensor]], could tempt me to trust readings over direct observation. I will treat sensors as a supplement, not a replacement for looking.

**Time pressure.** If I take on too many projects, including the [[Staeraerk Piostrond plan]], beekeeping visits might get squeezed. I will protect weekend time for Peboth first.

## History

I have known Peboth Traerren since 2012. At first the contact was casual, mostly conversation and the occasional piece of advice when I was just starting with bees. Over the following years the relationship became more structured, and Peboth became my mentor in beekeeping in every practical sense.

Some stages stand out in my memory.

- The early years were about the basics: what the equipment is for, how to read a colony, and how not to panic. Many of my first mistakes were corrected on the spot by Peboth.
- In the middle years I took on more of my own hives. Peboth shifted from showing me things to watching me do them and commenting afterward.
- In 2022 I wrote down our arrangement in simple form, which gave the mentoring a clear shape without making it formal. The date is recorded under Contracts.
- More recently, my questions have become more specific and more difficult. They are less about what to do and more about when and why.

Throughout, contact has remained in person and limited to weekends. That limit has shaped how I work. It forced me to prepare, to keep records and to think before asking. I now see it as a feature rather than a nuisance.

## Observations

These are the general things I have noticed about working with Peboth and about how I learn best.

I learn most when I have a specific task in my hands. Standing and listening is useful, but the lessons that stick are the ones where I did the work and Peboth corrected me. So I try to arrange visits around real jobs, not around talk.

Peboth tends to answer a question with another question. At first this irritated me, but it usually leads me to the answer myself, and then I remember it. I now prepare for this by thinking through what I have seen before asking.

The best visits follow a rhythm. We talk briefly, work at the hives, then sit and go over what happened. The last part is where most of my notes get written.

I notice that my own records are better when I record both what I saw and what I decided. Later, I can compare the decision with the outcome, and that is how I improve.

I have also seen that small gestures matter. A jar of honey, a tidy site and a punctual arrival all signal respect, and Peboth responds to that with more patience and more detail.

Finally, I observe that the equipment and the notes in this plan connect to my other projects. The [[Stalbrol Baerna]] note, the [[Lioder greenhouse notes]], the [[Glurkolel dehumidifier study]] and the [[Nevirkun kiln controller study]] each overlap with beekeeping in small ways, whether through shared space, moisture, or heat. Keeping them linked helps me see those overlaps and avoid repeating work.
