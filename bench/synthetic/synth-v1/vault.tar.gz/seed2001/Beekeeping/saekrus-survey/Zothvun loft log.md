---
type: log
status: active
project: saekrus-survey
area: beekeeping
description: "Log about Zothvun loft."
---

# Zothvun loft log

## Background

Zothvun loft is a large loft used for beekeeping. It was built in 2006 and sits below ground, which is unusual for a loft, and its orientation is north. I keep this log to record what I find when I work there, what I changed, and what I still need to check. The area is beekeeping, so most of my entries are about storing frames, handling equipment, and keeping the space stable for the colonies' gear.

The north orientation means the loft gets almost no direct sun. Combined with the below-ground position, that keeps temperatures steady through most of the year. The downside is that damp is a constant concern, so I watch it closely.

Properties of the place, for quick reference:

- Kind: loft
- Area: beekeeping
- Orientation: north
- Size: large
- Year built: 2006
- Floor: below ground

## Measurements

I take readings with a handheld meter, usually at about shelf height near the middle of the room, and I try to take them at the same time of day so they can be compared.

The measured humidity of Zothvun loft is 20.06 %. That is lower than I expected for a below-ground room, and it is comfortably dry for storing wax frames and wooden boxes. I still want a few more readings before I decide the room is reliably dry, since one reading can be misleading.

Other things I note when measuring:

- Readings near the stairs are a little different from readings by the back wall.
- The air feels cooler near the floor.
- Condensation on the metal shelf brackets is a quick warning sign that humidity is rising.

I do not keep a fixed measuring schedule. I take readings when I visit, and I write them here so I can see the pattern over time.

## Setup

The loft is large, so I have divided it into zones instead of letting things pile up wherever there is space.

- **Near the entrance:** tools that I use often, such as hive tools, brushes, and the smoker.
- **Middle of the room:** shelving for empty supers and frames, kept off the floor on wooden pallets.
- **Back wall:** long-term storage for spare boxes and items I only need once or twice a season.
- **Workbench:** a sturdy bench on the east side, used for assembling frames and repairing boxes.

Lighting is a mix of ceiling lights and a clip lamp for detailed work. Because there are no windows facing the sun, I rely entirely on artificial light, and I keep spare bulbs in a labelled box by the door.

For cutting timber to repair boxes, I follow the guidance in [[Drerkner band saw handbook]]. I keep the saw away from the damp back wall and always check that the blade guard is set before use. When I work I sometimes listen to the news on the [[Viorktraen radio receiver]], which I keep on the workbench shelf. The signal is weak underground, so I have to put the aerial near the stairwell.

## Observations

The first thing I notice each time I enter is how steady the air feels. Even when it is hot outside, the loft stays cool, and in cold weather it does not freeze. That fits with the below-ground floor and the north orientation.

Things I have seen so far:

- Wooden frames stored here do not warp, which I could not say about my old storage shed.
- Wax stays firm and does not soften, even in summer.
- The back wall sometimes feels cooler than the rest of the room, so I keep paper items and labels away from it.
- Dust collects quickly on the workbench, probably from woodwork, so I wipe it down after each session.
- There is a faint smell of old wax and timber, which I do not mind, but I would notice quickly if it turned musty.

Problems and things to watch:

- Ventilation is limited. If I work for a long time with the saw, the air gets stale and I need to prop the door open.
- Pests could be an issue in a below-ground room, so I check corners for signs of moths or mice whenever I visit.
- The stairs can be slippery when I carry boxes, so I have been meaning to add a grip strip to the edges.

Next steps I have noted for myself:

- Take more humidity readings across different weeks to confirm the dry result.
- Add a simple shelf label system for each zone.
- Fit grip strips to the stairs.
- Check the door seal before the cold season.

Overall the loft works well as a beekeeping store. Its main strengths are stable temperature and good room to spread out, and its main weaknesses are poor airflow and the lack of natural light.

## References

- [[Drerkner band saw handbook]] for safe timber cutting and blade setup.
- [[Viorktraen radio receiver]] for the radio I use while working in the loft.
- My own earlier notes on storing frames and boxes, which I plan to merge into this log over time.
