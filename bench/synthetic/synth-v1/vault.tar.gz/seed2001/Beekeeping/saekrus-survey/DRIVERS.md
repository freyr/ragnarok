---
type: drivers
status: active
project: saekrus-survey
area: beekeeping
---

# Drivers of Saekrus survey

## Costs

The Saekrus survey is a spring project that started in 2021. Its goal is a survey, and it sits in the beekeeping area. The lead is the plumber. Most of the spending goes to three things: time in the field, basic equipment, and the small repairs that come up along the way.

Field time is the biggest cost, and it is mostly my own hours plus the plumber's. The plumber charges for the days on site, so I try to bunch visits together instead of making many short trips. Equipment costs are lower. I already own most of what I need, and I borrow the rest where I can. The air compressor is one example. I wrote down how it behaves in [[Lesglugen air compressor notes]], and it is good enough for the cleaning jobs without buying a new one.

Repairs are the item I underestimate every time. Hive parts crack, fittings leak, and a day's work turns into two. I keep a rough allowance for this and I do not touch the main budget to cover it unless it clearly runs out.

Things I do not pay for if I can avoid it: new storage, new tools that are used once, and anything that only saves a little time. Storage is covered by the plan in [[Solsas shed plan]], so I only count the work needed to make room there.

## Lessons

The first lesson is that spring leaves little room. Colonies are building up, the weather swings, and the survey window is short. Anything that slips by a week matters more than I expect. In 2021 I treated the start date as flexible and paid for it later.

The second lesson is to write down the counting method before the first visit. If two visits use different methods, the numbers cannot be compared, and then the work is wasted. I now keep one short procedure page and follow it each time.

The third lesson is about weighing and measuring. Scale errors look small on a single reading but add up across a whole survey. The checks in [[Laemakath scale tests]] showed that I should calibrate at the start of each day and again after moving the scale. That costs ten minutes and saves arguments with myself later.

The fourth lesson is to let the plumber lead where the work is about pipes, water, or fixed fittings, and to lead myself where it is about the bees. Splitting it this way kept us from doing the same job twice. The plumber is the project lead, but on bee matters I make the call and tell them afterward.

Last, keep the notes short and dated by season, not by exact day. Long entries do not get read again.

## Background

The Saekrus survey grew out of a plain need: I wanted a clear picture of what is in the beekeeping area before making further plans. I did not have one. Decisions were being made from memory, and memory is unreliable after a winter.

The project is classed as a survey. It is not a build and not an experiment. It collects information, records it in one place, and stops. That is why the goal stays narrow. If a task does not produce information, it does not belong here.

It started in 2021, in spring. The season is part of the definition, since the survey describes the state of things as the year begins. Repeating it in another season would give a different result, and I would not compare the two directly.

The plumber is the lead. That may look odd for a beekeeping survey, but a large part of the site depends on water, drainage, and fixed pipework. Someone who understands those things had to coordinate access and timing, and the plumber was the obvious choice.

Earlier reference work is in [[Miokulgae Garko 2018]]. I use it as a baseline for what I expected to find and as a check on my own method. Where my findings differ from it, I note the difference but do not assume either side is wrong.

For questions about the people involved and who to ask, see [[Drario Gurkvi]].

## Safety

Most risks here are ordinary. Stings are the obvious one. Anyone on site wears a veil and gloves, and anyone with a known allergy stays out of the hive area entirely. I keep a short list of who has which allergy and check it before every visit.

Water and pipework are the second risk. When the plumber opens or closes anything, I stay clear until told it is safe. Wet ground near hives is slippery, and I do not carry boxes across it in a rush.

The compressor needs care. It should be drained, used at a sensible pressure, and never pointed at a person. If it sounds wrong, I stop and look at it. My notes in [[Lesglugen air compressor notes]] list the signs I watch for.

Lifting is the third risk. Full boxes are heavy, and a survey tempts me to lift more than I should because I am curious about what is inside. I lift with a second person, or I do not lift.

Basic rules I follow every time:

- Tell someone when I am on site and when I leave.
- Keep a first aid kit in the vehicle, not in the shed.
- Do not work alone near the hives when the weather is turning.
- Stop when tired. Mistakes cluster late in the day.

## Open questions

- Should the survey be repeated in a later spring, and if so, with the same method or an improved one? Repeating exactly gives comparable data, but improving the method may give better data.
- Is the plumber still the right lead for the next phase, or should the lead change once the work moves from site access to analysis?
- How much of the equipment should be bought rather than borrowed? So far borrowing has worked, but it creates scheduling problems in the busiest weeks.
- Can the storage in [[Solsas shed plan]] be finished before the next field season, or will the survey gear stay scattered?
- How closely should I tie results to [[Miokulgae Garko 2018]]? The conditions may be too different for a fair comparison.
- Do I need a second person for weighing, or is calibration alone enough to trust a single operator?
- What is the right stopping point? A survey can grow without end, and I have not yet written down a clear finish line.

I want to settle the last of these first, since it affects everything else.

## Budget

The budget of Saekrus survey is 33702.55 EUR.

This is the figure for the whole project, and I treat it as a ceiling, not a target. The aim is to finish under it, not to spend it.

How I think about it:

- The largest share is field time, including the plumber's days on site.
- A smaller share covers equipment, repairs, and consumables.
- A small reserve is held back for surprises, mostly repairs.

Success is measured in three ways. First, the survey covers the whole area and not just the convenient parts. Second, the records are consistent enough that two visits can be compared. Third, the project finishes within the budget above and within the spring window. If any one of these fails, I count the project as only partly successful, even if the other two go well.

I review spending after each field visit, not at the end. A short line in the log is enough: what was spent, on what, and whether it was planned.

## Setup

The setup is simple on purpose. The project has one working page, one procedure page, and one log. This note holds the drivers, meaning the goal, the limits, the money, and how I judge the result.

Subject summary, for quick reference:

- Name: Saekrus survey
- Type: project
- Goal: survey
- Area: beekeeping
- Start year: 2021
- Season: spring
- Lead: plumber

On site, I bring the scale, the veil and gloves, the first aid kit, the notebook, and the compressor if cleaning is planned. Calibration comes first, as described in [[Laemakath scale tests]]. Then I follow the procedure page in order, without skipping steps even when the day feels easy.

Storage and transport follow the plan in [[Solsas shed plan]]. Gear goes back in the same place every time, so I can see at a glance what is missing.

After each visit I write up the log the same day, while it is fresh. I record what was counted, what was not, and anything that looked wrong. If a number looks odd, I mark it and move on instead of arguing with it on site.

When the survey is done, I archive the working page, keep the log, and link the results from this note so the drivers and the findings stay connected.
