---
type: note
status: active
project: lustund-trial
area: beekeeping
---

# Fermae Ziogun notes

## Background

Fermae Ziogun is my mentor in beekeeping. I have known Fermae since 2013, when I first asked for help with a hive that kept swarming. The first conversation was short, but it turned into a long working relationship. Contact is by email, and Fermae is available on weekdays. I keep those facts at the top of my mind because they decide how I plan questions.

- Role: mentor
- Area: beekeeping
- Contact: email
- Availability: weekdays
- Known since: 2013

Fermae teaches by asking me what I saw before telling me what to do. At first that annoyed me. Now I think it is the main reason I can read a colony on my own. I write these notes to keep the lessons in one place, since I tend to remember the advice but forget the reasoning behind it.

Most of what I know about swarm control, requeening and winter preparation came from Fermae. Some of it I have tested in my own yard, and some I only trust because Fermae said it. I try to mark which is which in the notes below.

## Costs

Fermae has never charged me for advice. The costs come from the things the advice makes me do: equipment, materials, and my time on weekdays when Fermae is free and I have to be too.

The biggest recurring cost is gear. Fermae pushes me to buy fewer, better things. A good smoker and a solid hive tool last for years, while cheap ones get replaced. I have learned to ask "what will I use every week?" before buying anything.

Some costs are in time rather than money. A weekday visit means arranging my work around it. I plan these visits a week ahead by email so neither of us is rushed. Fermae answers best when the question is short and specific, so writing a clear email is itself a small cost, but a worthwhile one.

Workshop costs also matter. I build my own frames and boxes, which means timber and blade wear. I did some of that cutting on the machine I describe in [[Tronas band saw 2020]]. Making my own parts saves money over the long run, but only if I am honest about how many hours it takes.

I do not record exact spending here. The one price I track from Fermae's circle is in the Quotes section.

## Open questions

These are things I have not settled yet, and I want to bring them to Fermae.

- How early should I split a strong colony in a cool spring? Fermae has given me a rule of thumb, but I want to understand what it depends on.
- Is it worth moving hives to a second site for the late flow, or does the transport stress cancel the gain?
- How much should I trust weight changes alone as a signal of colony health?
- When is it better to combine a weak colony with a strong one rather than try to build it up?
- What is the best way to record inspections so I can compare years? My current notes are inconsistent.

I also want to ask Fermae how they decide when to stop intervening. My habit is to open the hive too often. Fermae seems to leave colonies alone far more than I do, and I would like to learn the signs that justify leaving them closed.

Another question is about mentoring itself. After so many years, should I be asking different kinds of questions? I suspect I still ask beginner questions out of habit, and Fermae is too polite to say so.

## Overview

Fermae Ziogun is the person I go to for beekeeping. The relationship is simple: Fermae is the mentor, I am the student, and we talk by email on weekdays. It has run since 2013, which makes it one of my longest steady contacts.

What makes Fermae a good mentor is consistency. The advice does not change with mood. When I describe a problem, I get the same method each time: observe, think about what the bees are doing, and act only if needed. Fermae also admits when something is a matter of opinion, which helps me separate firm rules from personal preference.

I use these notes in three ways. First, as a record of advice, so I do not ask the same thing twice. Second, as a checklist before each season. Third, as a place to link to my other projects, because beekeeping spills into the workshop and the loft more than I expected.

The sections below follow the order of the template I use for all my notes. Some sections are short because there is little to say. Others, like Observations and Safety, are where most of the useful material sits. If I only have a minute, I read Safety and Maintenance first.

## Observations

Over the years I have noticed patterns in how Fermae works, and in how I learn from the work.

Fermae watches the entrance of a hive before opening it. Traffic, pollen colour, guard behaviour and the general sound all say something. I used to skip this step and go straight to the frames. Now I spend several minutes standing back, and I catch problems earlier.

Fermae also keeps equipment simple and clean. Boxes are labelled, tools sit in the same place, and nothing is left open longer than necessary. That calm order seems to reduce stress on both the bees and the beekeeper.

Another observation: Fermae answers questions in layers. The first reply is short and practical. If I write back with more detail, the second reply explains the reason. I now write my first email with all the facts in it, so I can get to the useful layer faster.

I have also noticed that my best seasons followed winters when I took more notes. Records matter more than memory. The loft where I store spare boxes and supers is described in [[Zothvun loft log]], and I use that log to check what I own before I plan any new build.

Finally, I notice that advice works better when I test it on one hive first. Fermae encourages this and never asks me to change everything at once.

## Maintenance

Maintenance is where Fermae is strictest. A hive is a long-term project, and small neglected jobs add up.

My routine, based on Fermae's advice, is as follows.

- Scrape and clean the hive tool after each visit.
- Check the smoker fuel and keep it dry.
- Replace old frames on a rotation so that no comb stays in use too long.
- Inspect boxes for rot, gaps and warped edges before each season.
- Keep a written list of what needs repair, and fix it in the quiet months.

Wax and woodwork need regular attention. I scrape propolis from edges so boxes still fit together. I repaint exteriors when the finish starts to wear. Fermae says that a dry, sound box is a cheap form of disease prevention, and I have found that to be true.

I also maintain my own records. After each inspection I write down what I did, the state of the brood, and what I plan to do next. This takes only a few minutes, but it has saved me from repeating mistakes.

For measuring hive weight and similar checks, I borrowed ideas from my sensor projects. The notes in [[Laga level sensor notes]] and [[Bilathgend level sensor tests]] helped me think about how to measure something steadily without disturbing it. I have not fully adapted them to hives, but the thinking carried over.

## Ideas

I keep a list of ideas that came from conversations with Fermae or from my own tinkering. Most are unproven.

One idea is a simple weekly checklist that I can print and carry to the yard. It would have only a few boxes to tick, so I never skip the basics. Fermae liked this idea, but warned me not to make it so rigid that I stop looking at the bees themselves.

Another idea is a small heated tool for melting wax in a controlled way, so I can clean and recast scraps without burning them. I have been thinking about the control approach from [[Krioskus kiln controller notes 2019]], since the problem of holding a steady temperature is similar. I would need to ask Fermae about wax safety before trying it.

A third idea is a better storage system in the loft, with labelled shelves for frames, supers and spare parts, so I can see at a glance what I have. I would update [[Zothvun loft log]] as I go.

I also want to build a few nucleus boxes with cleaner joints. That depends on how well I can cut stock, so it connects back to the saw work in [[Tronas band saw 2020]].

Finally, I would like to write a short beginner guide from my notes, partly for others and partly to check whether I really understand the material. Fermae might be willing to read it and correct me.

## Problems

Not everything has gone well, and I should record the problems honestly.

My most common problem is impatience. I open hives too often, or I act before I have enough information. Fermae has pointed this out more than once, always gently. The fix is simple in theory: watch longer, act less. In practice I still slip.

A second problem is poor record keeping in busy weeks. When I skip notes, I lose the thread of what happened, and then I cannot give Fermae a clear account. A vague email gets a vague answer, so I only hurt myself.

A third problem is scheduling. Fermae is available on weekdays, and my own schedule is tight then. Several times I have had a question that could not wait, and the reply came only after the moment had passed. I now try to ask early and keep a short list of questions so I can use each exchange fully.

There have also been equipment problems: warped boxes, badly fitted frames, and a smoker that kept going out. Most of these came from rushing a build or buying something cheap. Fermae's advice on this has been consistent: slow down, measure twice, and do not skimp on the basics.

Lastly, I sometimes lean on Fermae too much. A mentor should help me think, not think for me. I try to arrive with my own guess before I ask.

## Setup

My working setup around the mentoring is simple and I keep it that way.

Communication is by email. I write one message per topic, with the facts first and the question last. I include what I saw, what I did, and what I think is happening. I send these on weekdays, because that is when Fermae is available, and I try not to expect an instant reply.

For the yard itself, I keep a fixed kit in one box: smoker, hive tool, brush, spare frames, a notebook and a pencil. The notebook matters most. I record each visit before I leave the yard, while the details are fresh, and then copy the key points into this note system later.

In the workshop I have a bench for frames and boxes, and I cut timber with the band saw covered in [[Tronas band saw 2020]]. Spare equipment lives in the loft, and I track it in [[Zothvun loft log]]. That way I know what is available before I plan a build.

For any measuring projects, I reuse methods from [[Laga level sensor notes]]. I have not made them standard practice, but they give me a starting point.

The overall aim of the setup is to reduce friction. If it is easy to take notes, easy to write to Fermae, and easy to find my tools, I am far more likely to do all three.

## Safety

Safety is the section I take most seriously, and most of it comes straight from Fermae.

Protect yourself first. Wear a veil and gloves, and keep clothing closed at the wrists and ankles. Do not work bees in a hurry or in a bad mood, because agitation shows in how you move, and the colony responds to it. If a colony is clearly defensive, close it up and come back another day.

Use smoke carefully. Keep the smoker fuel safe, never leave a lit smoker unattended, and make sure it is fully out before storing it. Keep a bucket of water or sand nearby when working in dry conditions.

Know about allergies. Anyone who works near hives should know how they react to stings, and a helper should know what to do in an emergency. Fermae insists on this and I agree. I keep a phone with me in the yard and tell someone when I will be there.

Workshop safety matters too. When cutting frames and boxes, I use the guards, keep fingers clear, and wear eye and ear protection. The saw notes in [[Tronas band saw 2020]] include reminders about blade tension and feed speed, and I follow them.

If I ever melt wax, I treat it as a fire risk. Wax must never be heated over open flame without close attention, and it should never be left alone. Fermae has told me this directly, and I take it as a firm rule rather than a suggestion.

Finally, handle hive tools with care, lift boxes with a straight back, and ask for help with heavy loads.

## Quotes

The only price I have recorded from Fermae's circle is a quoted price of Fermae Ziogun: 6355.78 EUR. I keep it here so I know the figure if the topic comes up again.

Beyond that, I keep a few remarks from Fermae in my own words, since I did not write them down verbatim.

- Watch the entrance before you open the box.
- Leave the colony alone unless you have a reason.
- Clean tools and sound boxes are cheap insurance.
- A short, clear question gets a better answer.
- Do not change everything at once; test on one hive first.

These sayings come up again and again, and they summarise a lot of what I have learned since 2013. When I feel unsure, I read this list before I do anything else. It reminds me that most good beekeeping is patient observation, not constant action. As a mentor, Fermae has taught me more through restraint than through any detailed instruction, and I try to keep that in mind each season.
