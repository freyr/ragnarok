---
type: research
status: active
project: lustund-trial
area: beekeeping
---

# Laemakath scale tests

## Observations

The Laemakath scale is a black battery-powered scale that sits in the cellar. I use it for beekeeping, mainly to weigh hive boxes, frames and full supers before and after the honey harvest. It was installed in 2017, so it has now been in the same spot for a long time.

The cellar is a good place for it in some ways. The temperature stays fairly steady through the year, and the floor is flat and hard, which matters a lot for any scale. It is a bad place in other ways: the air is damp, and in late summer the room smells of wax and honey, which draws ants and the occasional wasp.

What I have noticed over the years of using it:

- The readings are steady once the platform has been loaded for a few seconds. If I read it too early the number drifts upward a little.
- A cold start in winter gives slightly slow readings, but they settle.
- The display is easy to read in the dim cellar light, since the black housing has no glare.
- The scale holds its zero well if I keep the platform clean. Dried honey under the platform is the main cause of a wrong zero.
- Side loading is the worst case. If I set a box down off-center, the reading is lower than the true weight. Placing the load in the middle fixes it.

My routine test is simple. I weigh a known object, a bag of sugar or a brick I have weighed many times, then compare. I also weigh the same hive box twice, with a pause between, to check that the numbers repeat. If the two readings are far apart, I check the batteries first and the platform second.

## History

I put the scale in during 2017, when I decided to stop guessing how heavy my honey supers were. Before that I lifted boxes by hand and judged from feel, which worked badly. A battery-powered scale in the cellar meant I did not need to run a cable down the stairs, and the cellar was where I extracted and stored honey anyway.

The first two seasons were a learning period. I found out that the scale reads differently on the uneven part of the floor, so I moved it a short distance to a flatter spot and have left it there since. After that I started keeping a paper log of weights, which later became these notes.

Over the years I have gone through several sets of batteries and cleaned the platform many times. Nothing has broken. The black casing has picked up scuffs and a few sticky marks, but the structure is sound. I have not moved it since the early seasons, and I intend to leave it where it is.

Some practical lessons from the history of use:

- Always test after a long gap, such as after winter.
- Do not trust one reading of a heavy super; take two.
- Keep the log, because trends matter more than single values.
- Write down the date of each battery change.

## Safety

The main risk is not the scale but what is put on it. A full honey super is heavy and awkward, and the cellar stairs make carrying worse. I never carry a loaded box up or down the stairs alone if I can avoid it.

Other points I keep in mind:

- The floor can be damp or sticky with honey. I wipe up spills right away, because a slip while holding a heavy box is the real danger.
- Do not overload the platform. If a stack of boxes feels too heavy, weigh them one at a time.
- Keep the area around the scale clear so I do not trip over it in the low light.
- Because it runs on batteries, there is no mains cable to trip over or to get wet. That was one reason to choose it for a damp room.
- Old batteries can leak. I check the compartment during each service, and I do not leave dead batteries inside over winter.
- Keep wasps and ants away. Do not weigh open, dripping frames while insects are active; close the cellar door and window first.
- Wear gloves when handling propolis-covered boxes, since they are slippery.

If the display behaves oddly while I am holding a load, I put the load down first and look at the problem afterward.

## Ideas

Some things I would like to try, none urgent:

- Build a low wooden ramp or guide rails so I can slide boxes onto the platform instead of lifting them. This would cut the lifting risk.
- Paint a small mark on the floor showing where the scale sits, so it always returns to the same flat place after cleaning.
- Make a reference weight set from a few bricks or sealed sand bags, each labeled with its weight, so testing is quicker and always uses the same objects.
- Add a shallow tray or cover under the platform edge to catch drips of honey.
- Keep a small waterproof notebook hanging next to it, so I write down the weights on the spot instead of remembering them.
- Compare the cellar scale with a second scale once a year to see if it has drifted.
- Put a silica gel pack nearby to see whether the damp air matters for the electronics.

I should also think about whether a lid for the battery compartment with a better seal is worth making, since the cellar air is damp.

## Maintenance

Maintenance is mostly about batteries and cleanliness.

**Batteries.** The scale runs on batteries, and I change them at the start of every beekeeping season, in spring, even if they still seem fine. I note the date in the log. If the display dims or the readings jump, I change them at once. I use the same type each time and never mix old and new cells.

**Cleaning.**
1. Take off any load and switch the scale off.
2. Wipe the platform with a damp cloth. Warm water is enough for honey.
3. Dry it fully, because the cellar is damp.
4. Check under the platform edge for wax or dead insects.
5. Wipe the black housing and the display.

**Checking the zero.** With an empty platform, the scale should show zero. If it does not, I clean under the platform and try again.

**Checking accuracy.** Once a year I weigh my known objects and compare with the numbers in the log. If the difference is bigger than I can accept, I clean again, change batteries, and test once more.

**Storage over winter.** The scale stays in the cellar. I cover it with a clean cloth, not plastic, so moisture does not collect. I do not leave it loaded.

**Yearly checklist.**
- New batteries in spring
- Clean platform
- Check zero
- Test with known weights
- Look for rust or damp marks on the housing
- Update the log

## Software

The scale has a small amount of built-in software that controls the display, the zero function and the weight readings. The firmware version of the Laemakath scale is v7.12.708.

I have never updated it, and I do not plan to unless something goes wrong. The scale works well as it is. I wrote the version in my notes so that, if I ever see odd behavior, I can tell whether anything changed.

Things I have learned about how it behaves:

- After a battery change, the scale restarts and sets its zero. I make sure the platform is empty at that moment.
- If it is switched on with a load already on the platform, the zero will be wrong. Switch off, remove the load, and start again.
- The display settles after a few seconds, and I wait for it before writing a number down.
- There is no network feature that I use, so I do not worry about security of the device.

My weight log is kept by hand and typed into my notes later. A future idea would be a simple spreadsheet to track trends across seasons, but the scale itself does not need to connect to anything.

## Costs

I do not remember the exact purchase price, and I will not guess here. What I can describe are the kinds of costs.

- **Purchase.** A one-time cost in 2017. Since then the scale has paid for itself by saving me from poor judgments about honey yield and hive weight.
- **Batteries.** The main running cost, once per season. It is small compared with how much use I get.
- **Cleaning supplies.** Cloths and warm water, so almost nothing.
- **Possible additions.** A ramp, a reference weight set and a drip tray would be cheap to make from scrap wood and bricks.
- **Time.** A few minutes each spring for service, and a bit more for the yearly accuracy test.

In total the cost over the years has been low. The most expensive mistake would be dropping a heavy box on the platform, so the best way to save money is to handle loads carefully and place them gently. If the scale ever fails, I would weigh whether to repair it or replace it, and I would want to keep the same placement in the cellar and the same battery-powered design.
