---
type: drivers
status: active
project: lustund-trial
area: beekeeping
description: "Drivers about Lustund trial."
---

# Drivers of Lustund trial

## Problems

The Lustund trial is a beekeeping project with one stated goal: to run a trial. It started in 2026, in the autumn season, and the lead is the accountant. The trouble is that "trial" is a loose word, and I keep having to remind myself what exactly is being tested. The aim is to see whether the whole setup works well enough to repeat, not to produce a big harvest.

The first problem is timing. Autumn is a poor season to begin anything with bees. The colonies are getting ready for winter, the nectar flow is over, and there is little room for mistakes. Any change made now cannot be judged properly until the following spring, so the trial results will arrive late.

The second problem is that the lead is the accountant, not a hands-on beekeeper. This has an upside: records are kept tidily and every cost is written down. The downside is that practical decisions about the hives sometimes wait for someone else to look at them. I need to make sure a person with field experience is named for each hands-on task.

The third problem is measurement. Success has to be judged by something I can check without arguing about it. I have settled on these measures:

- Colonies that are still alive and active at the end of winter.
- Spending that stays inside the agreed budget.
- A complete written record of every inspection and every purchase.
- A short list of things I would change for the next attempt.

The fourth problem is that the constraints are tight. The budget is fixed, the season is short, and the working hours of the lead are limited because the accountant has other duties, especially around the end of the year. I should not plan any heavy work for those weeks.

## Risks

The biggest risk is winter loss. If the colonies are weak going into the cold months, the trial can fail through no fault of the method. I cannot fully control this, so I should treat a loss as information rather than as a disaster, as long as the cause is recorded.

The second risk is disease and pests, which are most dangerous in autumn when colonies are already stressed. A late problem with mites, for example, can undo months of care. Regular checks and an early decision on treatment are the best defence I have.

The third risk is cost creep. Small purchases add up, and a trial invites the thought that "one more item" is harmless. With an accountant leading, this risk is lower than usual, but it still needs a rule: nothing is bought unless it is written down first with a reason.

The fourth risk is unclear ownership. If the lead only handles the money and nobody owns the bees day to day, inspections will slip. I should write a simple schedule and put a name against each visit.

The fifth risk is weather. A wet or cold autumn limits the days when hives can be opened safely. I should keep a few spare days in the plan instead of packing every visit tightly.

The last risk is drawing the wrong conclusion. One season is a small sample. If the result is good, it may be luck; if it is bad, it may be bad weather. I should write this caution into the final summary so I do not overstate anything.

## Budget

The budget of Lustund trial is 19235.30 EUR. This is the whole amount for the project and I treat it as a ceiling, not a target. Spending it all is not a sign of success.

I keep the money in four rough groups so the accountant can follow it easily:

- Equipment and hive materials.
- Feed and winter preparation.
- Health care for the colonies, including treatments and checks.
- A reserve for things nobody predicted.

The reserve matters most. A trial in autumn will almost certainly produce a surprise, and it is better to have money set aside than to cut something important halfway through. If the reserve is untouched at the end, that is a good result and the leftover should be noted clearly rather than moved quietly into another project.

Every payment gets a short line in the ledger: date, what it was, which group it belongs to, and why it was needed. At the end of each month the lead compares the ledger with the plan and writes one sentence on whether we are ahead or behind.

## Lessons

These are the lessons so far, written for my future self.

- Start dates matter. Beginning in autumn made everything harder, and if I do this again I would rather begin earlier in the year, so there is time to see results before winter.
- A clear success measure saves arguments. Having a short list of checks, such as surviving colonies, spending within the limit and complete records, makes the final review much simpler.
- A lead who is good with numbers is an asset for a project like this, but the practical side needs its own owner. Splitting the two roles clearly works better than hoping one person covers both.
- Writing down the reason for each purchase slows spending in a useful way. Several items I first thought were necessary turned out not to be after I had to explain them.
- A trial should have a defined end. Without one it quietly turns into a permanent project with no review.

## Maintenance

This note should be reviewed at the end of each season, and whenever the plan changes in a meaningful way. The first review is due after the winter, when I can see how the colonies came through.

At each review I check the following:

- Whether the goal is still described correctly as a trial.
- Whether the budget figure is still the agreed one, and whether the ledger matches it.
- Whether the lead is still the accountant, and whether someone is named for the hands-on work.
- Whether the success measures are still the right ones.
- Whether the risks listed here have changed, and whether any new ones have appeared.

If the trial is repeated or extended, I will not overwrite this note. I will add a short dated remark at the bottom of the relevant section and start a fresh drivers note for the next phase. When the trial is closed, I will record the final outcome against each success measure, move the lessons into my general beekeeping notes, and mark this project as finished.
