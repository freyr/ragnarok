---
type: summary
status: active
project: lustund-trial
area: beekeeping
description: "Summary about Lustund trial."
---

# Summary of Lustund trial

## Supplies

The Lustund trial is a beekeeping project with the goal of a trial. It started in 2026, in the autumn season, and the lead is the accountant. This summary covers where the project stands, what is finished, what is still unclear and what comes next.

The supplies for this trial were kept small on purpose. Since it is an autumn project, I did not want to buy a lot of equipment that would sit unused over winter. The point was to learn whether the approach works, not to build a full setup.

- Spare hive boxes taken from the existing stock, so nothing new was bought for housing.
- Feeding containers and a supply of syrup for the autumn feeding round.
- Entrance reducers to keep robbing and wasps under control.
- Notebook and pencils kept in a dry box next to the hives, because pens fail in the damp.
- Gloves, smoker and fuel, which are shared with the other beekeeping work.
- A few spare frames in case a colony needed to be tidied up or reduced.

The accountant, as lead, keeps a simple list of what was used and what is left. This suits the project well, because every item is counted and nothing is bought twice. The shared items are not charged to the trial, which keeps the numbers honest and easy to read. I still need to check the stock of syrup before anything more is ordered, since it was used faster than I expected.

## Decisions

The main decision of the trial is made. The go decision date of Lustund trial is 2026-09-27. On that day I agreed with the lead that the conditions were good enough to go ahead and begin the trial properly, rather than wait for another season.

The reasoning behind the go decision was practical. The colonies were calm, the weather was still mild enough for work at the hives, and the supplies were on hand. Waiting would have pushed the whole trial into the following year, and the lead preferred to have some real results sooner, even if they were limited.

Other smaller decisions followed from that one:

- Keep the trial to a small number of colonies, so that it can be followed closely.
- Record every visit in the same format, so that entries can be compared later.
- Do not change the method partway through, even when a small tweak looks tempting. Changes would make the results hard to interpret.
- Treat the autumn period as the first stage only, with the review left until the colonies are through the cold months.

I wrote the decisions down at the time so that I do not have to reconstruct them from memory. If I am ever unsure why something was done, this section is the place to look first.

## Observations

Since the go decision, the visits have followed a steady rhythm. The colonies took the feed well in the first weeks, and activity at the entrances stayed good while the days were warm. As the weather cooled, flying slowed down, which is normal for the season and not a worry on its own.

What I noted most often:

- The colonies were calm when opened, with little defensive behavior.
- Stores built up steadily and the frames became heavier.
- Wasp pressure was present but manageable once the entrances were reduced.
- Brood area shrank gradually, as expected for this time of year.
- There were no clear signs of disease at any visit, though I am not an expert and the checks were visual only.

One thing worth remembering is that the weather affected the notes more than the bees did. A cold morning gave a very different picture from a warm afternoon, so I now write down the time of day and the conditions with every entry. Without that, comparing two visits is almost meaningless.

The trial is at an early stage. It is past the start and the first round of work, but the real answer will only come after the colonies have wintered and been checked in spring. For now, the observations are encouraging but not conclusive, and I try not to read too much into them.

## Maintenance

Maintenance in this project is light but regular. The main jobs are keeping the hives dry, keeping entrances protected and making sure the feed is used up and not left to ferment or attract pests.

Jobs that are done or ongoing:

- Cleaning and refilling the feeders until the colonies stopped taking syrup.
- Checking that the hive boxes sit level and that the roofs are secure against wind.
- Keeping the grass short around the entrances so that air can move and the bees are not blocked.
- Looking over the entrance reducers after storms.
- Tidying the notebook entries after each visit, so that the record stays readable.

The accountant lead also asked for a short monthly check of the supply list against what is actually in the store. This is dull but useful, and it has already caught one mismatch where an item was counted twice. I plan to keep doing it until the trial closes.

Before deep winter I want to do one last round: confirm that the roofs are weighted, that the entrances are narrow enough for the cold, and that nothing loose can blow over. After that, the hives should be left alone as much as possible, with only occasional outside checks so as not to disturb the colonies.

## Next action

The next action of Lustund trial is NX-0749. I want this done before anything else is added to the project, because the rest of the plan depends on it.

In practice, the next action is a small, concrete piece of work and not a big planning step. I will do it at the next suitable weather window, record the result in the notebook straight away, and then update this summary so that the stage and the open points match reality.

Once that action is complete, I will choose the one after it and write it down here, replacing the current one. Keeping only a single next action in this note stops the page from turning into a long to-do list that I never read.

## Open questions

Several points are still open, and I would rather list them plainly than pretend they are settled.

- How well will the colonies come through the winter? This is the main question of the whole trial and cannot be answered yet.
- Is the amount of feed given in autumn right, or was it too much or too little? The syrup ran down faster than planned, so I cannot tell yet.
- Should the number of colonies be increased in a later season, or is a small number the better size for this kind of trial?
- What is the best moment for the first spring check, given that the weather decides it more than the calendar?
- How should the results be judged? I have notes, but I have not fixed a clear measure of success, and the lead and I need to agree one before spring.
- Who handles the winter checks if the lead is busy with year-end accounting work? This is a real risk, because that period is the busiest for an accountant.

I will return to this list after the next action is finished, remove anything that has been answered, and add whatever new questions appear. The project is at its early stage, with the go decision made and the first round of work done, and the open questions are mostly about waiting for the season to show what happens.
