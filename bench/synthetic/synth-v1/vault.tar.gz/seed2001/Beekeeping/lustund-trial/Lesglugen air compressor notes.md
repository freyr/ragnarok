---
type: note
status: active
project: lustund-trial
area: beekeeping
description: "Note about Lesglugen air compressor."
---

# Lesglugen air compressor notes

## Setup

The Lesglugen is a black air compressor that I installed in 2022 in the greenhouse. It belongs to my beekeeping setup, and I use it for small jobs around the hives and the honey work: blowing dust and wax crumbs off frames, clearing debris from tools, and drying equipment after washing.

It runs on solar energy. A panel on the greenhouse roof feeds it through a small controller, so I don't need a long cable from the house. The compressor sits on a low shelf near the greenhouse door, off the floor so damp doesn't reach it. I keep the area around it clear because the vents on the side need space.

Things I did when installing it:

- Fixed the shelf to the wooden frame so it doesn't walk when the motor starts.
- Ran the cable along the roof beam, away from the watering lines.
- Added a short hose with a quick coupling so I can swap the nozzle without fuss.
- Left a small gap behind the unit for airflow.

## Observations

In day-to-day use the compressor does what I need. It is louder than I expected for such a small unit, but the greenhouse is far enough from the neighbours that it doesn't matter. On bright days it fills the tank without any trouble. On overcast days it takes noticeably longer, and in deep winter I only use it for short jobs.

Heat is the main thing to watch. In midsummer the greenhouse gets very hot, and the motor housing feels warm well after it stops. I now avoid running it in the afternoon and do the air work in the morning instead. I also open the roof vent before starting it.

Moisture is the second issue. Condensation collects in the tank, especially after cool nights, so I drain it regularly. If I forget, a little water comes out of the hose with the first burst of air, which is bad news for clean frames.

Other notes from use:

- The black casing fades a little at the top, but only cosmetically.
- The coupling needs a drop of oil once in a while.
- The controller connections should be checked each spring, since vibration can loosen them.
- Spiders like the vents, so I brush them out now and then.

Overall it has been reliable over the years since 2022, and I haven't needed any repairs beyond tightening fittings.

## Measurements

I checked the power draw with a plug-in meter placed between the controller output and the compressor, during a run on a clear morning with the tank partly filled.

- Measured power draw: 522.17 W

That reading is the figure I use when sizing the solar side. It means the panel and controller must supply enough for the motor while it runs, and clouds can slow the refill. I have not logged readings across different seasons, so this single value is only a guide for a sunny day with a half-empty tank.

Next time I would like to note the run time per refill and how the draw changes as the tank pressure climbs, since the motor probably works harder near the top. For now, the one measurement is enough to tell me the setup is adequate for light beekeeping use in the greenhouse.
