---
type: research
status: active
project: rendkas-automation
area: beekeeping
description: "Research about Lisdrior band saw."
---

# Lisdrior band saw study

## Risks

The Lisdrior band saw is a black band saw that runs on mains power. It has stood in the workshop since it was installed in 2023. It is the main tool I use for cutting hive parts, so I use it often and I need to stay careful with it.

The first risk is the blade. A band saw blade is a thin loop of toothed steel under tension. If it snaps, it can whip out of the housing. I always check the guard door latch before switching on, and I never open the door until the wheels have stopped turning.

The second risk is the mains supply. The workshop has a damp corner, and the saw sits close to it. I keep the cable off the floor and run it along the wall. I do not use the saw if the cable has been rubbed or pinched. A residual current breaker should be on this circuit, and I want to confirm that it is. The note [[Raemaertur Truthkon notes]] has the general electrical rules I follow for the workshop.

The third risk is dust. Cutting old frames and boxes produces fine dust, and some of the wood carries wax, propolis and glue residue. I wear a mask, and I do not sweep the dust dry. I use a vacuum.

The fourth risk is cutting small pieces. Short strips of wood are hard to hold, and my fingers end up close to the blade. I use a push stick and a simple jig. I do not freehand anything small.

Last, I should not use the saw when I am tired or in a hurry. Most of my close calls in the workshop happened at the end of a long day in the apiary.

## History

I installed the saw in the workshop in 2023. Before that I cut everything with a hand saw and a borrowed jigsaw. The cuts were rough, and I wasted a lot of timber. After a season of repairing supers and making new frames, I decided a proper band saw was worth the floor space.

The first job was finding a spot. The corner I first picked was too close to the door, and the long offcuts hit the frame whenever I fed a board through. I moved the saw to the wall side of the workshop, where there is room for a long board to pass through on both sides. It has stayed there since.

The black housing was the first thing I noticed. It shows sawdust badly, and I wipe it down often. That is a small thing, but it means I notice when something has leaked or rusted.

In the first season I used it mostly for cutting hive bodies to size and for trimming frame parts. In the next season I started using it for small repairs and for making feeder parts. Notes on the loft side of the work are in [[Zothvun loft log]] and [[Fenkraeth loft handbook]]. Both mention parts I cut on this saw.

I have kept a loose habit of writing down what I do with the saw after each session. Most of that went into this note rather than a separate log. When the older notes in [[Draensork shed]] are sorted, I may move the early saw entries into one place.

## Ideas

A few ideas have collected over the seasons.

- Build a proper fence and a stop block for repeat cuts. Frame parts all need the same length, and a stop block would save me measuring each one. I could make it from scrap and clamp it to the table.
- Add dust collection. A simple hose from the lower housing to a small vacuum would take most of the dust. If I add the compressor from [[Mepiostre air compressor plan]], I could also use short air bursts to clean the table, though I would not blow dust around the room.
- Put a small light over the table. The workshop is dim in winter, and a clear view of the line matters more than I expected.
- Make a dedicated push stick set, in several sizes. I keep reaching for the same awkward one.
- Power the workshop lights and a small charger from solar, so the saw is not competing with other loads on the same circuit. The idea is worked out partly in [[Perkgon solar charger plan]]. The saw itself would stay on mains, because it needs the steady power.
- Paint or label the table edge with a bright mark so that I can see the blade path at a glance. Black on black is hard to read.
- Keep a small box of spare blades and a note about which blade I use for which job, so I stop guessing.

## Open questions

Several things are still unclear to me.

- How much time should I leave between cuts to let the blade cool? I have no good rule. I stop when the cut starts to burn, but that is probably late.
- Is the blade tension I use right? I set it by feel, and I would like a method I can repeat. Perhaps [[Zaenpapath Kolbuth]] knows a better way. He has used band saws for much longer than I have.
- Is the circuit in the workshop really protected by a residual current breaker? I believe so, but I have not tested it.
- Can I cut frames that still have wax on them without gumming up the blade? So far I scrape first, but that adds time.
- Would a second, smaller saw be better for fine work? The Lisdrior is fine for boards, but small pieces are awkward.
- What is the best way to store the saw during the cold months, when the workshop is not heated? Moisture on the table has caused light rust before.
- Does the noise carry to the neighbours? I have not asked.

## Problems

The problems below are the ones I have actually met, as opposed to the risks I only worry about.

The blade drifts. On long cuts the line wanders to one side, and I end up with a slightly angled edge. I think the guides need adjusting, or the blade is dull. I have not yet separated those two causes.

The table collects rust spots. The workshop air is damp for part of the year, and the black housing hides the first signs. I wipe the table with oil now and then, but I forget.

Dust gets into the switch area. After a heavy session I find fine powder around the controls. It has not caused a fault so far, but I do not like it.

Wax-coated wood clogs the teeth. When I cut old hive parts without scraping them first, the blade gets sticky and the cut slows down. I have to stop and clean it.

The cable reaches the socket only just. When I move the saw to clear the floor, the cable pulls tight. I should either move the socket or use a short, properly rated lead.

I also lose small offcuts under the table. They pile up and become a tripping hazard. A simple tray would solve that.

Finally, the light is poor. Several bad cuts happened in the evening, when I could not see my pencil line clearly.

## Observations

Over the seasons I have noticed some patterns.

The saw works best when I take my time. A slow, steady feed gives a cleaner edge than pushing hard, and it is also safer. When I hear the motor strain, I am almost always going too fast.

The black finish is practical but dusty. Light-coloured sawdust stands out on it, which makes it easy to see when the machine needs cleaning. I treat that as a useful side effect.

The workshop location suits the saw. It is close to the timber rack and to the bench where I assemble frames, so the work flows in one direction. The radio on the shelf, described in [[Viorktraen radio receiver]], is far enough away that I can hear it over the motor only when I turn it up, which I do not do while cutting.

Cuts made in the morning are better than cuts made late in the day. I think that is about my own attention rather than the machine.

The saw has been reliable since 2023. It has never failed to start, and the mains supply has not tripped while I used it. The most common faults come from the blade and the guides, not from the motor or the wiring.

I also see that I use the saw more in the quiet months, when I repair and build equipment. In the busy season I have little time for the workshop, so work piles up and I run long sessions in winter. That is another reason to improve the light and the dust control before the next cold period.

## Background

The Lisdrior band saw is a black band saw that runs on mains power. I installed it in 2023 and it stands in the workshop. I use it for beekeeping work: cutting hive parts, trimming frame stock, and the odd repair job on boxes that have warped or rotted at the corners. The area of the note is beekeeping, and that is the lens for everything below.

Before I bought it, I did most of my cutting with a hand saw and a borrowed table saw. The hand saw was slow and left wavy edges. The table saw was fine for long straight cuts but clumsy for narrow strips and for curved cut-outs such as entrance reducers and feeder holes. A band saw seemed the right middle ground: a thin blade, a small kerf, little waste, and good control on small pieces. I wanted something I could leave set up in the workshop and use for ten minutes between other jobs.

This study is my own record of how the saw has performed since it went in. It is not a review for anyone else. I wrote down what I cut, what went wrong, what I changed, and what I would do differently. The questions I started with were these:

- Does a mains-powered black band saw of this kind cut hive timber cleanly enough that I can skip a lot of sanding?
- Is it safe to use for the narrow pieces that beekeeping needs, such as frame parts and wedges?
- How much looking after does it need, and can I do that myself?
- Is it worth keeping in the workshop, or would the space be better used for something else?

Short answers, after a few seasons: yes on clean cuts, with some care about blade choice; reasonably safe when I use push sticks and a proper guide; modest upkeep that I can handle alone; and yes, it earns its place.

## Tools

The saw is only one part of the setup. This section lists what I use around it, since the results depend as much on the support kit as on the machine.

**The saw itself.** Kind: band saw. Colour: black. Energy source: mains. Installed in 2023. Location: workshop. It sits on a solid bench at a height where my elbows are slightly bent when I hold a workpiece on the table. Getting that height right mattered more than I expected. When it was too low my back ached after short sessions, and I started rushing cuts.

**Blades.** I keep a few blades on hand. A narrow blade with fine teeth is for curves and small pieces. A wider blade with coarser teeth is for straight cuts through thicker timber, such as the side walls of a hive body. I label each coil with a strip of tape so I do not have to guess. Pine and cedar, which are the woods I use most, are soft but resinous, and the resin gums up fine teeth quickly. I wipe the blade with a rag and solvent when the cut starts to burn.

**Guides and fences.** I made a simple fence from a straight offcut clamped to the table. For repeated narrow strips, such as frame spacing wedges, I made a small jig with a stop block. The jig keeps my fingers well away from the blade and gives me matching pieces without measuring each time.

**Push sticks and safety kit.** I keep several push sticks hanging on a hook beside the saw. I also wear eye protection and a dust mask. Cutting treated or old hive wood throws off fine dust, and old boxes can carry wax and propolis residue that clogs the table and the guides.

**Measuring and marking.** A steel rule, a small square, and a soft pencil. For hive parts I mark the cut line and then cut just on the waste side, leaving the line visible. Any final fit I do with a plane or a sanding block.

**Dust handling.** The saw has a port for a dust hose. I connect it to a small shop vacuum when I remember, and I sweep under the bench after every session. Propolis dust is sticky, so it needs more cleaning than ordinary sawdust.

**Lighting.** A clip-on lamp aimed at the table. The workshop ceiling light casts the shadow of my hand across the cut line, which was a real nuisance until I added the lamp.

## References

These are the sources I rely on. None of them is a formal publication; they are the things I have in my own workshop and notes.

- **The maker's leaflet** that came in the box. It covers assembly, the basic electrical connection, and the first blade fitting. It is short and not very detailed about tension, so I treated it as a starting point only.
- **My own workshop notebook**, where I log blade changes, cuts that went wrong, and adjustments to the guide. Many of the lessons below come straight from there.
- **Notes from a local beekeeping group.** A few members who build their own hives gave me advice on timber choice and on which cuts are worth doing on a band saw versus a hand saw. I have not written down their names here because I only have a loose memory of who said what.
- **General woodworking habits** that I picked up over the years: let the blade reach full speed before cutting, feed slowly, keep the guide close to the workpiece, and never reach behind the blade.
- **My hive plans.** These are sketches I drew for the boxes, feeders, and frames I build. They give the dimensions I cut to, and I keep them pinned above the bench.

If I find a better source later, I will add it here. For now, the practical record in the notebook is the most useful one, because it describes this exact saw in this exact workshop.

## Lessons

**Blade tension and tracking matter more than speed.** In the first weeks I fought wandering cuts. The blade drifted to one side and I blamed my hands. In the end the problem was tracking: the blade sat slightly off the centre of the wheel. Once I adjusted it and checked it again after the blade had warmed up, the cuts went straight.

**Let the saw do the work.** Pushing hard makes the blade bow and the cut curve. A slow, even feed gives a smoother edge and saves the blade. With resinous pine, a slow feed also avoids scorch marks.

**Use the right blade for the job.** A coarse blade tears thin frame stock. A fine blade clogs in thick pine. Changing blades takes a few minutes and is always worth it.

**Support long pieces.** Hive bodies and long boards tip off the table at the end of a cut. I added a roller stand on the outfeed side. Since then I have not had any sudden jerks or dropped boards.

**Small parts need a jig.** I once tried to cut a short wedge freehand and the blade grabbed it. Nothing was hurt, but it was a clear warning. Anything small now goes through a jig or is held with a push stick.

**Old hive wood hides surprises.** Nails, staples, and hardened propolis can ruin a blade. I now check old boxes with a magnet and a scraper before they reach the saw. I also scrape off excess wax, because it smears onto the table and the blade.

**Keep the table clean.** Propolis residue makes the table sticky and the wood drags. A quick wipe with solvent and a dry rag before a session saves frustration.

**Plan the session.** The saw is quick, but setting up blade, fence, and jig takes time. I now group all my band saw cuts into one session, instead of switching on the saw for a single piece.

**The saw is not for everything.** Long rips of full-width boards are still better on the table saw, and fine trimming of joints is better with a plane. The band saw is best for curves, narrow strips, and resawing small stock.

## Costs

I am keeping costs qualitative here, because I would rather not record exact figures that will go out of date. The way I think about the cost of the saw is in four parts.

**Purchase.** The saw was a moderate outlay for a hobby workshop, more than a basic hand tool and less than a full professional machine. I saved for it over a season and bought it in 2023, the year it was installed. I consider it fair value for the work I do, particularly because it replaced the need for a second, larger machine.

**Running cost.** Because the energy source is mains, running cost is just electricity. The motor draws little for the short sessions I run. Over a year I do not notice any change in the bill, so I do not track it.

**Consumables.** Blades are the main recurring expense. I buy them a few at a time and try to match them to the kind of cutting I do. A blade that is kept clean and used for the right job lasts a good while. A blade used on old, dirty hive wood does not. That is why the magnet and scraper check is, in effect, a cost-saving habit.

**Time and space.** The saw takes up bench space in the workshop and a little time for set-up and cleaning. I count this as a real cost. The bench would otherwise hold my frame-assembly jig, and I have to move things around when I want to use both.

Overall, the saw has paid for itself in avoided waste. I now cut hive parts from offcuts that I would previously have thrown out, and I rarely have to buy a new board to fix a small mistake.

## Maintenance

My maintenance routine is simple and mostly done by hand. I keep it in the notebook so that I do not skip steps.

**After every session.**
- Switch off at the mains and wait for the blade to stop completely.
- Brush off the table, wheels, and guides.
- Vacuum the dust port and the area under the table.
- Wipe resin or propolis from the blade and table with solvent on a rag.

**Every few sessions.**
- Check the blade for cracks, missing teeth, or a dull edge. A dull blade burns the wood and makes me push harder, which is a warning sign.
- Check the tracking and the guide position. Even a small shift shows up as a wandering cut.
- Look at the wheel tyres for debris. Hardened gum under the blade can push it off line.

**Release tension when idle.** If I am not going to use the saw for a while, I release the blade tension. Leaving a blade under full tension for weeks can stress the blade and the wheels.

**Seasonal checks.**
- Inspect the power cable and plug for damage. This matters more in a workshop where the cable gets moved around and dust builds up.
- Check the bolts and fixings, since vibration loosens them over time.
- Look at the bearings in the guides and clean them. If they stick, I replace them.
- Touch up any bare metal on the black finish with a thin film of oil to keep rust away. The workshop gets damp in winter and I have seen rust start on the table.

**Storage.** I keep spare blades coiled and labelled in a dry drawer. I keep the push sticks and jigs next to the saw so they are always within reach.

**When to call for help.** I do the routine work myself. If the motor sounds rough, the saw trips the mains, or there is a burning smell, I stop using it right away and have it checked. I do not open the electrical parts.

Keeping to this routine has kept the saw reliable since 2023, and I expect it to continue as long as I keep up the habits above.

## Supplies

This section lists what I keep near the Lisdrior band saw so that a session in the workshop does not stop halfway. The saw is a black band saw that runs on mains power. I installed it in 2023, and it is used for beekeeping work, mostly cutting hive parts from timber.

What I keep on the shelf beside it:

- Spare blades in two widths: a narrow one for curves and a wider one for straight ripping of boards.
- A small tin of dry lubricant wax for the blade guides.
- A soft brush and a plastic scraper for clearing resin and sawdust from the tyres and the table.
- Clean rags, a small bottle of solvent for sticky propolis and resin, and a pair of cotton gloves for handling new blades.
- A steel rule, a small engineer's square and a marker pen for setting up cuts.
- Push sticks, at least three, in different lengths. I make new ones from offcuts when the old ones get chewed up.
- Hearing protection, safety glasses and a dust mask.
- A notebook that stays clipped to the wall. I write down blade changes, odd noises and anything I adjusted.

Timber I usually cut on this saw is pine and cedar for hive boxes, frames, bottom boards and feeder parts. I try to keep the offcut bin emptied, because small pieces near the table are a nuisance and a hazard.

Things I should buy before they run out: blades, wax, filters for the dust extractor, and the sandpaper I use on cut edges. Blades go dull faster when I cut boards that carry old wax or glue, so I keep reclaimed timber away from the saw unless I have cleaned it first.

## Schedule

The saw does not run all year. Most of the cutting happens in the quiet months, when the hives are closed and I am building and repairing equipment. In summer I only use it for urgent repairs or a spare box.

My routine, kept simple so that I actually follow it:

**Before every session**
- Look over the blade for cracks, missing teeth or a visible bend.
- Spin the wheel by hand once with the power off and watch the blade track.
- Brush off the table and check that the dust extractor bag is not full.

**After every session**
- Switch off at the wall and unplug if I am leaving the workshop for a few days.
- Release a little blade tension if the saw will sit unused for more than a week.
- Brush the tyres and table, and wipe the guides.

**Monthly, when in regular use**
- Clean both wheel tyres properly with the scraper and brush.
- Check the guide blocks for wear and the thrust bearing for free rotation.
- Wax the guides lightly.
- Check the table is still square to the blade.

**Once a year, in autumn before the building season**
- Look at the power cable and plug for damage.
- Check the belt or drive and the wheel bearings for noise.
- Replace the blade even if it still looks fine, and test the saw with scrap timber.
- Re-check the calibration described in the Adjustment section.

I write the date of each yearly check in the notebook rather than trusting memory.

## Setup

This is the order I follow when I set the saw up for a job, or after I have changed the blade.

1. **Unplug the saw.** Always. I do not rely on the switch alone when my hands are going near the blade.
2. **Fit the blade.** Wear gloves, loop the blade over both wheels with the teeth pointing down toward the table at the front, and seat it on the middle of the tyres.
3. **Apply tension.** I bring the tension up until the blade barely flexes when I press it sideways with a finger in the middle of the span. A wide blade needs more tension than a narrow one.
4. **Set the tracking.** Turn the upper wheel by hand and tilt it slightly until the blade stays in the centre of the tyre without wandering.
5. **Set the guides.** The side guides should sit just behind the gullets, with a gap about the thickness of a sheet of paper. The thrust bearing sits a hair behind the back of the blade, so it only touches during a cut.
6. **Set the guide post height.** About a finger's width above the timber, and no more. A high guard is the most common thing I get wrong when I am in a hurry.
7. **Check the table.** Put the square on the table beside the blade and look for gaps. If there is one, adjust the table trunnion.
8. **Close the covers**, plug in, switch the dust extractor on and run the saw for a short time without cutting, listening for rattles.
9. **Make a test cut** in scrap pine and compare it with a line drawn with the square.

For hive parts I mark all the cuts on the timber first and cut the long, straight pieces before the small ones. Small pieces are held with a push stick or a jig, never with bare fingers close to the blade.

## Checklist

A short list I can read at the saw without searching through the notes.

**Safety**
- [ ] Power off and plug out when changing blades or adjusting guides
- [ ] Safety glasses, hearing protection and dust mask on
- [ ] No loose sleeves, no gloves while cutting, hair tied back
- [ ] Floor around the saw clear of offcuts and cables
- [ ] Push stick within reach

**Machine**
- [ ] Blade has no cracks and teeth are all present
- [ ] Blade tension feels right for its width
- [ ] Tracking is centred on the tyre
- [ ] Guides and thrust bearing set with the small gap
- [ ] Guide post lowered to just above the timber
- [ ] Table square to the blade
- [ ] Dust extractor connected and bag not full
- [ ] Covers closed

**Work**
- [ ] Timber is clean, dry and free of nails, staples and old wax
- [ ] Cut lines are marked
- [ ] Test cut done if the setup was changed
- [ ] Notebook updated if I changed or noticed anything

**Finishing**
- [ ] Saw switched off and unplugged if leaving
- [ ] Tension eased for long storage
- [ ] Table and tyres brushed
- [ ] Offcuts collected, floor swept

If I tick fewer than most of the machine items, I do not start the saw. It is better to lose ten minutes than to ruin a board or hurt myself.

## Adjustment

Over time the saw drifts. The blade starts to lead to one side, the table moves slightly out of square, or the cut line no longer matches the mark. This section describes how I bring it back in line.

**The calibration offset.** After setting up the saw in 2023, I measured how far the cut sits from the line when the fence and the table are in their nominal positions. The calibration offset of the Lisdrior band saw is 2.249 mm. I apply this when I set the fence by the scale: the scale reading is not exact, so I shift the fence by this amount to match the real cut. If I find the offset has changed during a check, I write down the new figure in the notebook and update this note.

**Checking the drift.**
1. Take a straight piece of scrap pine and mark a line along it.
2. Feed it slowly along the line without forcing it.
3. If the blade pulls to one side, stop and look at the tracking and the guides before touching anything else.
4. Measure the finished cut with the steel rule at both ends of the piece.

**Common fixes.**
- *Cut leans to one side:* the blade is dull, the tension is too low, or the table is not square. I fix these in that order.
- *Blade wanders in the cut:* tighten the guides slightly, or change to a wider blade for straight work.
- *Rough edges and burning:* the blade is dull or has resin on it. Clean it with solvent first, then replace it if cleaning does not help.
- *Vibration or noise:* check the tyres for built-up dust and the wheel bearings for roughness.
- *Cut line off compared with the fence scale:* re-measure the offset and apply it again.

After any adjustment I make one more test cut, compare it with the square, and write what I changed in the notebook. I change only one thing at a time, so that I know which change solved the problem.
