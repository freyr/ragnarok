---
type: note
status: active
project: rendkas-automation
area: beekeeping
description: "Note about Lioder greenhouse."
---

# Lioder greenhouse notes

## References

These are my own notes on the Lioder greenhouse. It is a greenhouse, and it belongs to my beekeeping work. The area in my frontmatter is beekeeping, so I file everything about it with the hive notes.

Basic facts about the place, written here so I do not have to look them up again:

- Kind: greenhouse
- Area: beekeeping
- Orientation: south
- Size: large
- Year built: 1993
- Floor: below ground

The odd part is the floor. The Lioder greenhouse sits below ground, yet it faces south. The sun comes in through the south side, and the earth around the rest keeps the temperature steadier than in a normal glasshouse. It is large, so there is room for benches, a small workshop corner, and a place to stage frames and nucs before they go out to the apiary.

I built none of it myself. It dates from 1993, and the age shows in the wood, the seals, and the drainage. I keep these notes so I remember how it behaves in each season and what I changed.

## Admin

The paperwork for the Lioder greenhouse is short, but I need it when I talk to the landowner or when something has to be repaired.

- Lease reference of Lioder greenhouse: LR-633818
- The lease covers the structure and the strip of ground in front of the south glass.
- Repairs to the roof and the glazing go through the landowner. Small fixes inside, like shelves, lights and benches, are mine.
- I keep a paper copy of the lease in the blue folder in the workshop, and a photo of it on my phone.

When I write to the landowner I always quote the lease reference first. It saves a round of questions. I also write down what I asked and what they answered, in a plain list in my notebook, so I can check later who promised what.

Insurance for the contents is handled separately from the lease. I check that the stored equipment is covered, especially the extractor and the spare hive bodies, because they are the most valuable things down there.

## Lessons

Things I learned the hard way in this greenhouse, in rough order of importance.

1. Because the floor is below ground, water is the first enemy. After heavy rain the lowest corner takes water. I now keep everything off the floor, on pallets or shelves, and nothing made of cardboard stays down there.
2. The south orientation gives strong light even in winter. That is good for starting plants that bees like, but it also warms the glass on a sunny day while the ground stays cold. The air near the roof can be far warmer than the air at the floor.
3. Because the place is large, it is easy to lose small things. I assign a spot to every tool and put it back. A tool without a spot disappears.
4. Wax and honey smells attract wasps and robbing bees. Any frame I bring in must be covered right away, and doors must not stay open while I work.
5. A stored frame can mould in damp air. Moving frames to the upper shelves and giving them airflow fixed most of it.
6. The 1993 build means the door frame has moved a little. The door sticks in wet weather, so I leave a small wedge by it.

One more lesson: write things down on the day. If I wait a week I forget which change made the difference.

## Schedule

The rhythm of work here follows the beekeeping year. I do not use exact dates, only seasons.

**Early spring**
- Clear out winter dust and check for water marks on the walls.
- Inspect the glazing on the south side and clean it, since light matters most now.
- Prepare spare frames and check which ones need new wax foundation.

**Late spring**
- Stage nucs and equipment before the first swarm period.
- Ventilate during the day, because the glass heats quickly.
- Check the drain every week.

**Summer**
- Use the space for processing frames when the weather allows, with doors closed.
- Keep the place tidy so no sweet residue draws wasps.
- Shade the south glass if the heat builds up.

**Autumn**
- Move stored frames to the upper shelves.
- Clean and put away the equipment I used for honey.
- Look at the roof and door seals before the rains.

**Winter**
- Visit every couple of weeks to check for damp, pests, and leaks.
- Do repair work and build new frames inside, which is a good use of the cold months.

## Tools

Tools I keep in the Lioder greenhouse, and where they live.

- Hive tool and smoker: on the hook by the door.
- Frame rack and spare hive bodies: on the pallets along the north wall, the dry side.
- Uncapping knife and honey buckets: on the second shelf, in a lidded box.
- Extractor: in the centre of the floor area when in use, otherwise on a raised stand.
- Hygrometer: on the middle shelf, so I can see the dampness at a glance.
- Small pump and hose: kept near the low corner for removing water.
- Torch and spare batteries: in the drawer under the bench.
- Wedge for the sticking door: on the floor beside the frame.

I check the list at the end of each season. If something is missing or broken, I write it at the top of my shopping list. I do not keep duplicates of everything, only of items that stop work when they fail, such as the torch and the pump.

Cleaning supplies sit apart from the food-handling tools, so nothing picks up a chemical smell. Honey equipment is washed in warm water only.

## Problems

Known problems, with what I do about each one.

- **Water in the low corner.** Being below ground, the place collects water after heavy rain. I run the pump, keep items raised, and watch the drain. A permanent fix is a job for the landowner.
- **Damp and mould.** Stored frames and wooden parts can go mouldy. Airflow and the upper shelves help. The hygrometer tells me when to act.
- **Overheating at the glass.** The south side is bright and warm. In summer the upper air gets hot. Shade and ventilation are my answer.
- **Cold floor in winter.** The ground keeps the floor cold, so I do not leave anything sensitive on it.
- **Sticking door.** Old frame, 1993 build. The wedge is a temporary solution only.
- **Pests.** Wax moths and mice are possible in stored comb. I keep comb in sealed boxes and check them often.
- **Wasps and robbing.** Any sweet smell draws them. I work with doors shut and clean spills at once.

If a problem repeats three times, I move it from my own repairs to a message for the landowner, with the lease reference included.

## Setup

The layout is simple and I try not to change it without a reason.

The glass is on the south side, so the bright working zone is there. Benches and the frame-building table are placed close to the glass, where I get the best light. The middle of the floor is kept free for the extractor and for moving boxes around. The north side, the darkest and driest part, is for storage on pallets.

Because the greenhouse is large, I divided it into three zones:

1. **Light zone**, near the south glass: building frames, starting plants, and inspecting equipment.
2. **Work zone**, the middle: honey processing and cleaning.
3. **Store zone**, the north wall: spare hive bodies, frames, and sealed boxes.

Lighting inside is a few lamps for the dark winter days. Power sockets are placed high, away from the floor, since the place is below ground and water can collect. The pump has its own extension lead that stays off the wet area.

I keep the walkway clear all the time. A large space tempts me to leave things in the middle, and then I trip on them.

## Checklist

What I check on each visit, short version:

- [ ] Floor dry, no standing water in the low corner
- [ ] Drain clear and the pump in its place
- [ ] Door closes and the wedge is ready
- [ ] South glass clean and not cracked
- [ ] Hygrometer reading looks sensible
- [ ] Stored frames covered or boxed
- [ ] No sweet spills, no wasps inside
- [ ] Tools back on their hooks and shelves
- [ ] Sockets and lamps working
- [ ] Walkway clear

Once a season I add these:

- [ ] Check the roof and seals
- [ ] Count spare frames and hive bodies
- [ ] Re-read the lease details and confirm the lease reference LR-633818 is still on the paper copy
- [ ] Note any new problems in the section above

If everything passes, I just log the visit in one line. If something fails, I fix it if it is mine, and if not, I write to the landowner the same day.
