---
type: research
status: active
project: rendkas-automation
area: beekeeping
description: "Research about Glurkolel dehumidifier."
---

# Glurkolel dehumidifier study

## References

These are the sources I rely on for this study. All of them are my own records or things I can check by walking out to the greenhouse.

- My greenhouse logbook, where I write down damp readings, battery swaps and anything odd about the unit.
- The short paper leaflet that came in the box with the Glurkolel dehumidifier. It is thin, but it explains the basic controls.
- Photos I took when I set the device up in 2022, showing where it sits on the shelf and how the cable and battery pack are arranged.
- Notes from a chat with a neighbour who also keeps bees and fights damp in his storage shed. He has no Glurkolel, but his advice on drying frames and wax was useful.
- My own beekeeping notes on stored comb, spare supers and feed, which explain why I care about dry air in the first place.

I have not found any outside test of this model, so most of what follows is first-hand experience. Where I am guessing, I say so.

## Background

The Glurkolel dehumidifier is a dehumidifier, meaning its only job is to pull moisture out of the air and collect it. Mine is red, which makes it easy to spot among the pots, trays and gray plastic bins in the greenhouse. That sounds like a trivial detail, but I have stepped around it in the dark many times and never knocked it over, so the color does earn its keep.

It runs on a battery. This was the main reason I chose it. The greenhouse has no reliable mains socket, and running a cable out there across the garden was something I wanted to avoid. A battery-powered unit can sit wherever the air is dampest, and I can move it if I change the layout. The trade-off is that I have to keep an eye on the battery and cannot simply forget about the device.

I installed it in 2022, and it has stayed in the greenhouse ever since. The location matters. A greenhouse is warm in the day, cool at night, and often wet from watering, so the air swings between humid and merely damp. That is hard on anything stored there. My connection to beekeeping is practical: I keep part of my equipment in the greenhouse during the off-season and the early spring, including empty frames, a few boxes, and some wax-covered tools. Damp air in that space encourages mold on comb and wood, and it makes metal parts rust. The dehumidifier is there to protect that stock.

Summary of the subject, as I record it in my own system:

- Name: Glurkolel dehumidifier
- Kind: dehumidifier
- Color: red
- Energy source: battery
- Year installed: 2022
- Location: greenhouse
- Area: beekeeping (see frontmatter)

What I want to learn from this study is simple. Does the unit really keep the stored beekeeping equipment dry enough, how much effort does it take, and what could go wrong over several seasons?

## Risks

I try to be honest about what could go wrong with this setup. Some of these risks I have already met, and others I only expect.

**Battery running flat.** This is the biggest practical risk. If the battery dies and I do not notice, the greenhouse goes back to being damp, and the stored frames pay for it. Because the unit is not plugged in, there is no steady supply to fall back on. A flat battery during a wet week is the worst case.

**Cold nights.** Batteries tend to lose strength in the cold, and a greenhouse can get cold on clear nights even when the day was warm. I have seen the unit seem weaker after a frosty stretch. I treat that as a warning to check the battery sooner than usual.

**Water collecting and overflowing.** A dehumidifier is only useful while its collection space has room. If it fills and I am away, it either stops or, in the worst case, spills near the stored equipment. I do not want standing water next to wooden frames.

**Placement mistakes.** If I put the unit too close to a wall, a bench or a pile of boxes, air cannot move freely around it and it works poorly. If I put it where water splashes from watering, I risk damaging it. I have to keep both in mind whenever I rearrange the greenhouse.

**False sense of safety.** The device does not make the greenhouse dry by itself. Leaks, wet soil, open water trays and heavy watering all push moisture back into the air. If I rely on the dehumidifier and ignore these sources, I may think the stock is safe when it is not.

**Dust, pollen and plant debris.** A greenhouse is not clean. Leaves, soil dust and bits of plant material can clog the intake. A blocked intake means weaker drying and extra strain on the unit.

**Pests.** Wax moths and mice like stored comb. The dehumidifier does nothing against them, and a dry shelf could even look safe while a pest problem grows. I keep the two issues separate in my mind.

## History

I bought and installed the Glurkolel dehumidifier in 2022. At that time I had lost some stored frames to mold the winter before, and I decided I needed something more reliable than propping the greenhouse door open and hoping for wind.

The first season was a period of learning. I put the unit on a low shelf near the stored boxes, and it seemed to work, but I was not sure where it should really go. After a few weeks I noticed that the air near the floor stayed heavy while the shelf area felt drier, so I moved it down closer to the damp spot. That small change made a clear difference to how the greenhouse felt and smelled.

In the first year I also learned how often the battery needed attention. At the start I checked it only when I remembered, and twice I found it flat. After that I began writing each swap in the logbook, which gave me a rough rhythm. The rhythm shifts with the weather: wet weeks drain the battery faster than dry ones, since the unit works harder.

Over the following seasons, the device became a normal part of the greenhouse routine. I switch it on in autumn when the stored equipment goes in, and I keep it running through the wet months until spring, when the bees and the frames need to come out again. In summer I use it less, because the greenhouse is warm and dry enough and the stored items are mostly out in the hives.

Nothing dramatic has happened to it. It has not broken down, and I have not replaced it. The main changes over time have been in how I look after it, not in the device itself. That steadiness is part of why I decided to write this study: after several seasons, I finally have enough experience to say something useful about it.

## Ideas

These are things I want to try or think about. None are done yet.

- **Simple damp log.** Keep a small, regular record of how damp the greenhouse feels, with a few notes on the weather. Over a full season this would show whether the dehumidifier really changes anything or whether I only imagine it.
- **Battery spare and rotation.** Keep a second battery charged and ready, so a swap takes a minute and the unit is never off for long. I could mark the batteries so I know which one is fresh.
- **Visible reminder.** Tie a bright tag or tape to the unit that I move each time I change the battery. Since the device is red already, a contrasting mark would stand out well.
- **Better shelf position.** Test two or three locations for a week each and compare how the stored frames feel afterward. I suspect the best spot is not the most convenient one.
- **Raising the stock.** Put the frames and boxes on pallets or racks so air can move under them. This should help the dehumidifier do its job with less effort.
- **Seal the worst leaks.** Fix the places where rain gets in, which would reduce the work the device has to do.
- **Pest check on the same visit.** Whenever I check the battery, glance over the comb for moths and signs of mice, so one visit covers both problems.
- **Compare with a desiccant box.** For the most delicate items, a small sealed container with a drying agent might be a good backup in case the battery dies.

## Maintenance

Looking after the Glurkolel dehumidifier is not hard, but it works best as a habit. This is the routine I follow and the one I intend to keep.

**Battery.** Check the battery on every greenhouse visit during the wet season. If it seems weak, swap it right away rather than waiting. After swapping, write it in the logbook. In cold spells, check more often, since the battery drains faster.

**Water.** Empty the collection space regularly. In damp weeks I do it at every visit. I pour the water away from the stored equipment, usually onto the soil outside, never near the wooden frames.

**Cleaning.** Wipe the outside with a dry cloth and clear dust or leaves from the intake. I do this gently, because I do not want to push debris deeper into the unit. A soft brush works well for the small gaps.

**Placement check.** Make sure the unit stands level, has free space around it, and is out of reach of water from watering. After any rearranging of the greenhouse, look at it again.

**Seasonal start and stop.** At the start of the wet season, I test it before loading in the stored items. At the end, I remove the battery, clean the unit, dry it well, and store it where it will not get damp. A dehumidifier that sits in a wet corner all summer defeats its own purpose.

**Signs of trouble.** If it runs but collects almost no water in a clearly damp week, or if it feels unusually warm or makes a strange noise, I stop and look for blockages first. If cleaning does not help, I will treat it as a fault and consider a replacement rather than trusting it with the stored beekeeping equipment.

## Setup

The Glurkolel is a red dehumidifier that runs on battery power. I installed it in 2022 in the greenhouse, where it supports my beekeeping work. The greenhouse is the place where I dry frames, store a few supers between seasons, and keep sugar and pollen supplements for the colonies. Damp air there causes mold on comb and clumps in the supplements, so I wanted something that could work without a mains cable.

I put the unit on a low shelf near the middle of the greenhouse, about knee height. It sits away from the door so that cold, wet air from outside does not hit it directly. I left a clear gap of about a hand's width on every side so the intake and outlet are not blocked. The drain hose runs to a bucket on the floor, and I check the bucket every time I visit.

The battery sits in a small plastic tray under the unit. I made the tray after the first month, when a splash of condensation reached the terminals. Since then the connection has stayed dry. The red housing is easy to spot among the green and brown clutter, which helps when I come in with my hands full and need to find the switch fast.

Things I did on the first day:

- Cleaned the shelf and leveled it with a folded piece of wood.
- Placed the unit and tested the drain hose with a jug of water.
- Set the humidity target and watched the unit for an hour.
- Wrote down the starting readings from my hygrometer so I could compare later.

## Lessons

The first lesson was about placement. In the early weeks I had the unit too close to the hive boxes I was drying. The air around it became very dry but the far corner stayed damp. Moving it toward the center evened things out much better. A dehumidifier does not pull moisture across a whole room evenly, so position matters more than I expected.

The second lesson was about the battery. Because the energy source is a battery, the unit is only as reliable as my charging routine. In humid autumn weeks it works harder and drains faster. I learned to swap or recharge the battery on a fixed day each week instead of waiting for the unit to stop. A dead battery in a wet week lets mold start within days, and that is harder to fix than to prevent.

The third lesson was about the bucket. On busy weeks I forgot to empty it, and the unit stopped when it was full. Now I empty it first, before I do anything else in the greenhouse. A small float mark that I drew on the bucket with a marker reminds me when it is near the limit.

Other things I noticed over the years:

- Winter use is weaker. In cold air the unit collects much less water, so I rely more on ventilation then.
- Sunny days heat the greenhouse and raise humidity from the plants, so I check the readings in the evening, not the morning.
- Dust from wax and wood shavings clogs the filter faster than normal household dust.
- Bees sometimes wander in. I keep the door closed when I am working near the unit.
- The red color fades slightly where sun hits the housing, but this has no effect on how it works.

## Supplies

These are the things I keep close to the unit so that maintenance is quick.

- A spare battery, charged and labeled, kept in the house and not in the damp greenhouse.
- A battery charger with a clear indicator light.
- A bucket for the drain hose, plus a spare in case one cracks.
- Spare drain hose and a couple of clips.
- A soft brush and a damp cloth for the filter and the housing.
- A hygrometer, with a second one for a cross-check.
- A plastic tray and some foam pads for under the battery.
- A notebook and pencil that stay in a zip bag on the shelf.
- Silica packs for the sugar and pollen containers, as a backup when the unit is off.

I buy the small items in batches so I am not short during a damp spell. The most important item is the spare battery. Everything else can be improvised, but a flat battery cannot.

## Checklist

I run through this list each week, and once more at the start of autumn and spring.

1. Check the battery level and swap it if it is low.
2. Empty the bucket and look at the hose for kinks or leaks.
3. Wipe the red housing and check that the intake and outlet are clear.
4. Brush the filter and wash it if it looks gray.
5. Read the hygrometer and write the value in the notebook.
6. Look at the stored frames and supers for any sign of mold or musty smell.
7. Check the supplements for lumps or a damp feel.
8. Make sure the tray under the battery is dry.
9. Confirm the shelf is still level and the unit has space around it.
10. Close the door properly when leaving.

Once a season I also do a longer check. I take the unit off the shelf, look for corrosion on the battery contacts, clean the inside of the water collection area, and test the unit with a fully charged battery for a few hours while I watch the readings.

## Overview

The Glurkolel dehumidifier study is my record of how a small battery unit performs in a working beekeeping greenhouse. Here is a summary of its properties.

- Kind: dehumidifier
- Area: beekeeping
- Color: red
- Energy source: battery
- Year installed: 2022
- Location: greenhouse

After several seasons, my view is that the unit does a useful job when it is placed well and the battery is managed. It keeps the stored equipment and supplements in good shape through damp months. It does not replace good ventilation, and it is weak in cold weather. The biggest risks are a flat battery and a full bucket, and both are solved by routine, not by changing the device.

What works well:

- No mains cable in a damp building, which feels safer to me.
- Simple controls that I can use with gloves on.
- A bright color that is easy to find.
- Steady results when the routine is followed.

What could be better:

- Battery life in wet weeks is shorter than I would like.
- The bucket needs frequent attention.
- Cold air reduces its output a lot.

If I were to set up a second unit, I would put it in the far corner from the start and use a larger bucket or a longer drain hose to a spot outside.

## Costs

I do not keep exact accounting for this study, so I describe the costs in general terms instead of making up figures.

The main cost was buying the unit in 2022. After that, the running costs are small because it uses a battery and not mains power. The battery is the ongoing expense. Batteries lose capacity over time, and I expect to replace them from time to time. The charger uses a little electricity, which I consider minor.

Other costs are small items: filter cleaning supplies, hose and clips, the plastic tray, silica packs, and the occasional replacement bucket. These are cheap and I buy them when I notice they are running low.

The hidden cost is my time. The weekly checklist takes about as long as a cup of tea, and it is worth it. Against that, the cost of losing a season of comb or a batch of supplements to mold would be much larger. For that reason I count the dehumidifier as good value for a beekeeping greenhouse, as long as I keep up the routine.

## Schedule

The Glurkolel dehumidifier is the red, battery-powered unit I installed in the greenhouse in 2022. It sits near the hive-frame drying racks, and the whole routine around it is built on the beekeeping calendar, because the humidity problem it solves changes with the season.

**Daily (in season)**
- Morning check of the display when I open the greenhouse. I want to see that the unit is running and that the battery indicator is not in the low band.
- Empty the water tank if it is more than half full. In wet weeks this means every day; in dry weeks I can skip several days.
- Quick look at the intake grille for dust, wax flakes or bits of dried propolis.

**Weekly**
- Wipe down the outer housing. The red paint shows dust and sticky residue very clearly, which is actually useful, since I notice a dirty unit right away.
- Swap the battery pack for the charged spare, and put the used one on the charger overnight. I do this on the same day each week so I do not forget.
- Check the drain tube for kinks.

**Monthly**
- Rinse the water tank with warm water and a little mild soap. Dry it fully before putting it back.
- Clean the filter, and check the seals around the tank.
- Test the battery under load: run the unit for a full day and note how long the charge lasts. I keep these numbers in my own log so I can see the trend.

**Seasonal**
- Spring: full service before the first supers go into the greenhouse for conditioning. Check the casing, fasteners and the cable to the battery pack.
- Summer: run it mostly on demand, since the greenhouse gets hot and the air can hold more moisture without trouble during the day.
- Autumn: this is the busiest period. Extracted frames and wet equipment come in, and the unit runs almost continuously.
- Winter: remove the battery, charge it to about half, and store it indoors. The unit itself stays in the greenhouse under a cover, with the tank emptied and dried.

## Tools

The maintenance of this device needs very little. I keep everything in one plastic box on the shelf next to the unit.

- **Soft brush**: for the intake grille and the filter. A stiff brush damages the mesh.
- **Microfiber cloths**: two of them, one for the housing and one for the tank. I do not mix them.
- **Small screwdriver set**: for the access panel over the battery compartment. Only a small cross-head and a small flat-head are needed.
- **Mild soap and warm water**: the only cleaning agents I use. Strong solvents can cloud the tank and leave a smell that might transfer to the frames.
- **Multimeter**: to check the battery pack voltage before and after a day of use. A battery that drops quickly is a sign it needs replacing.
- **Hygrometer**: a separate one, placed at the height of the racks. I do not trust the built-in humidity reading alone, so I compare the two. They disagree slightly, and I have learned how much.
- **Notebook and pencil**: for the log of tank volume, battery life and humidity readings. Paper works better in a damp greenhouse than a phone.
- **Spare battery pack and charger**: the single most important accessory, since the whole device depends on the battery.
- **Rubber gloves**: for handling the tank when it contains dirty water from wax-contaminated air.
- **Cable ties and tape**: for keeping the drain tube in place and the charging cable out of puddles.

Things I tried and no longer use: a vacuum cleaner on the grille (it pulled the filter out of position) and a hair dryer for drying the tank (it warped the plastic seal a little).

## Safety

Because this is a battery-powered unit in a damp greenhouse, the risks are mostly about moisture, charging and the battery itself.

**Electrical and battery**
- Never charge the battery in the greenhouse. I charge it indoors, on a hard surface, away from anything that burns.
- Do not leave the battery on the charger for days. I take it off the morning after charging.
- If the battery pack swells, gets hot during use, or smells odd, stop using it immediately and take it out of the unit. Do not keep it in the greenhouse.
- Dry my hands before touching the connectors. The air is humid, and condensation on terminals is common in the cold months.
- Keep the charging cable and any spare cells off the floor, where water from the drain can reach them.

**Moisture and water**
- The unit must stand on a level, dry board, not directly on soil or wet concrete.
- Water in the tank can contain wax and propolis residue. I treat it as dirty and pour it away from the plants and from the bees' water source.
- Wipe up spills right away. A wet floor in a greenhouse is a slip risk, especially on the smooth path between the racks.

**Bees and equipment**
- Keep the unit away from open hive boxes so that the airflow and the noise do not disturb the colony during inspections.
- Make sure no bees are trapped near the intake grille. A few wandering bees do enter the greenhouse, and the grille should stay clear.
- Do not place stored honey supers directly in front of the exhaust, because the drying air can pull moisture out too quickly and I have seen comb surfaces crystallise from this.

**General**
- Keep a small fire extinguisher near the greenhouse door, since lithium-type batteries are the main hazard I can think of.
- Do not cover the unit while it is running. The cover is for winter storage only.

## Observations

These are my own notes from use since 2022, written as I noticed them rather than as measurements from a controlled test.

- **Humidity control**: In a closed greenhouse with wet equipment, the unit brings the air down to a comfortable level within a few hours. With the door open, it struggles, so I keep the door shut while it runs.
- **Battery life**: A fresh charge lasts roughly a full working day in autumn, when the demand is highest. In summer it lasts noticeably longer, because it cycles on and off. After a couple of seasons the capacity dropped a little, which is why I now keep a spare.
- **Noise**: The fan is quiet enough that I can work next to it. The bees do not seem bothered, but I still keep it away from the hives.
- **Tank fill rate**: The tank fills fastest in the first days after I bring in freshly extracted frames. After that, the rate falls off and the tank may stay half empty for days.
- **Frames and wax**: Frames that were dried with the unit running had less mould than frames I left to dry in the open. I did not test this carefully, but the difference was clear enough over two autumns.
- **Colour**: The red housing fades a bit where the sun hits it through the greenhouse glass. I moved the unit to a shadier spot, and the fading slowed.
- **Condensation**: On cold mornings the outside of the unit gets damp. This is harmless, but it reminds me to dry my hands before handling the battery.
- **Filter**: It clogs faster than the manual suggests, because of wax dust. Monthly cleaning is the right interval for me, and in autumn I do it every two weeks.
- **Reliability**: In all this time, the unit has not failed outright. The only problems were a loose battery contact once, which I fixed by cleaning it, and a kinked drain tube.

Ideas for later:
- Log humidity at fixed times for a whole season and compare it with the tank volume.
- Try a small solar panel to top up the spare battery without carrying it indoors.
- Test whether a shelf above the unit helps airflow around the racks.

## Parts

The Glurkolel dehumidifier is a compact red unit, and most of its parts are simple to replace. Below is what I track for my own use.

- **Part number of the device**: HQ-6103-E. I write this on the inside of the tool box lid so that I have it when I need to order anything.
- **Battery pack**: the energy source for the whole unit. I have the original and one spare. They are interchangeable and fit the same compartment.
- **Water tank**: removable, with a handle and a sealing lip. The lip is the part most likely to wear out.
- **Filter**: a washable mesh filter behind the intake grille. It lasts for years if cleaned regularly.
- **Drain tube**: a flexible tube that lets me run the unit without emptying the tank by hand. It can kink, so I fix it with cable ties.
- **Fan and housing**: the fan has never needed work. The red housing is plastic, and I only wipe it.
- **Access panel**: covers the battery compartment and is held with small screws. I keep the screws in a labelled jar in case one gets lost.
- **Charging cable**: it connects the battery pack to the charger. I replaced one cable after the insulation cracked from the cold.

Basic facts for quick reference: the device is a dehumidifier, used for beekeeping, red in colour, powered by battery, installed in 2022, and located in the greenhouse.

If I ever need a replacement, I will check the part number first and then compare the battery connector, because the battery is the part most likely to change over time.
