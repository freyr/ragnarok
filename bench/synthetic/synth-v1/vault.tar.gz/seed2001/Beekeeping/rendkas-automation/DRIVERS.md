---
type: drivers
status: active
project: rendkas-automation
area: beekeeping
---

# Drivers of Rendkas automation

## Background

Rendkas automation is a project in the beekeeping area. Its goal is automation. It started in 2020 and it runs in spring, which is the season when the work happens each year. The lead is the inspector. This note is the drivers note of the project: it records why the project exists, what limits it, what money is set aside, and how I decide whether it worked.

The idea behind Rendkas is simple. Keeping bees involves a lot of small, repeated jobs that depend on the calendar and on the weather. In spring the colonies grow fast, and the window for doing things at the right moment is short. I want to take the repeated, boring parts of those jobs and make them happen without me having to remember them. The inspector leads the work because the inspector is the person who walks the apiary, sees the state of the colonies, and knows which jobs are worth automating and which are better left to a human eye.

The main drivers, in the order I care about them:

- Fewer missed tasks in spring. A forgotten check or a late feeding costs more than the time it would have taken.
- Less time spent on routine records. I want the numbers written down once, not copied three times.
- Earlier warning when a colony is falling behind. This is the part with the most value.
- Calm. If the routine runs on its own, inspection days become about looking at bees and not about juggling lists.

What the project is not: it is not a way to remove the inspector from the hives. Automation here supports the inspection. It never replaces the decision to open a hive, treat a colony, or move a box.

### Goal in plain terms

The goal is automation. In practice that means three things I can check:

1. The recurring spring jobs are triggered by the system, not by my memory.
2. Records are collected with as little typing as possible.
3. The inspector gets a short summary before each visit to the apiary.

### Constraints

The constraints shape almost every decision, so I list them here and refer back to them in the other sections.

- Season. The project is tied to spring. Anything that is not working by the time the colonies start to build up will have to wait a whole year. That makes the spring start date a hard edge.
- Lead. The inspector leads and has the final say on what goes into the field. If the inspector does not trust a step, it does not go in.
- Money. The budget is fixed and small. See the Budget section.
- Weather and exposure. Anything outdoors must survive rain, cold nights, damp, and the occasional knock from a hive tool.
- Bees come first. Nothing may disturb the colonies, change the entrance, add noise next to a hive, or make an inspection slower or more dangerous.
- Simplicity. I keep these notes for myself. Whatever I build, I must be able to repair it alone, with parts I can get easily.
- Power. Most of the apiary has no mains supply, so everything has to run on batteries or small panels, or be simple enough not to need power at all.

### How success is measured

I measure success with a short list of checks, not with one number. At the end of each spring I go through them:

- Did every planned recurring task get triggered on time? I count the misses. The target is no misses that were caused by forgetting.
- How long did the record keeping take compared with the year before? It should be clearly shorter.
- Did the early warnings catch a weak colony before I would have noticed it by eye? Even one good catch counts as a win.
- Did any part of the setup disturb the bees or fail in the weather? Any such event counts against the project.
- Would the inspector keep using it next year? This is the final test. If the answer is no, the project failed whatever the other checks say.

## Budget

The budget of Rendkas automation: 2389.01 EUR

This is the whole amount I allow for the project. It has to cover equipment, spare parts, weatherproofing, and the small things I always forget to count, such as cable ties, seals and extra batteries. It does not include my own time, which I do not price.

How I think about the money:

- A part of the budget is held back as a reserve. Outdoor equipment fails, and I would rather have money for a replacement than stop in the middle of spring.
- I spend first on what supports the main drivers: reminders, records, and early warning.
- I do not buy anything just because it is clever. Each purchase must point back to one of the drivers in the Background section.
- Cheap and repairable beats expensive and sealed. A part I can replace myself for a small sum is better than a module I would have to send away.

I review the spending at the end of each month during the build and again at the end of spring. If spending runs ahead of progress, I stop buying and look at what is already on the shelf first.

## Schedule

The project belongs to spring, and the work is planned around that.

| Phase | Timing | Main aim | Who decides |
|---|---|---|---|
| Planning | Late winter | Decide which tasks to automate | Inspector |
| Build | Early spring | Assemble and test the pieces | Inspector |
| Field trial | Spring buildup | Run the system beside normal inspections | Inspector |
| Review | End of spring | Go through the success checks | Inspector |
| Adjustment | After the review | Fix, remove or extend steps | Inspector |

Some notes on the plan:

- The project started in 2020, and each spring is a new round of the same cycle: plan, build, trial, review.
- Late winter is for thinking and for ordering parts that take time to arrive.
- Early spring is for bench testing. Nothing goes to the apiary until it has worked on the bench for a good stretch without me touching it.
- The field trial always runs alongside the normal manual routine. I do not drop the old way until the new way has proven itself.
- If a phase slips, I shorten the trial, not the bench testing. A rushed bench test means failures in the field, and those are harder to fix.

## Checklist

Before each spring round I go through this list.

- Confirm with the inspector which tasks are in scope this year.
- Read last year's lessons and open questions.
- Check the budget and the reserve.
- Inspect all outdoor equipment for damage, damp and wear.
- Replace batteries and check the charging arrangement.
- Test every reminder and every record-keeping step on the bench.
- Make sure the inspector's pre-visit summary is readable on a phone in bright light.
- Confirm that no device touches the hive entrance or sits where it could be knocked during an inspection.
- Prepare a plain paper fallback for every automated step.
- Agree who does what if something stops working on a visit day.

After each round:

- Count missed tasks and note why.
- Compare the time spent on records with the previous year.
- Write down any disturbance to the bees, however small.
- Update this note if a driver or a constraint has changed.

## Costs

The Budget section gives the total. Here I describe where costs tend to fall, without pretending to know exact amounts before I have them.

Main cost groups:

- Sensing and recording equipment. This is the largest group, and it is where I am most tempted to overspend.
- Power. Batteries, small panels, and the means of keeping them charged in cold, damp weather.
- Weatherproofing. Enclosures, seals, mounting parts, and anything that keeps water out.
- Spares. A few of the parts that fail most often, kept in the apiary shed.
- Consumables. Cable ties, tape, labels, and similar small items.

Hidden costs I try to remember:

- Time spent walking to the apiary to fix something that should have been automatic.
- Replacement of items damaged by weather in the first season.
- The cost of redoing a build that failed because I rushed the bench test.
- The cost of not having a fallback on paper when the system fails during a busy day.

A useful rule: if a cost does not make one of the success checks better, it is a candidate for cutting.

## Problems

These are the problems I expect, or have met, in this kind of project.

- Damp and condensation. Electronics in a hive yard get wet from the inside as well as the outside. Enclosures must be sealed well, and I must check them often.
- Cold nights in early spring. Batteries lose capacity in the cold, and a system that works in the afternoon can be dead by morning.
- False alarms. If the early warning cries wolf, the inspector will stop trusting it. I would rather miss a minor signal than send many false ones.
- Missed alarms. The reverse problem. A warning that never comes when it should is worse than none, because it gives false comfort.
- Disturbing the colonies. Any new object near a hive can change how the bees behave. I introduce equipment slowly and watch.
- Over-reliance. When a system works well for a few weeks, it is easy to stop looking. The inspector must still go and look.
- Complexity creep. Every extra feature adds one more thing that can break. I try to keep the scope small.
- Records that do not match. When automatic records and handwritten ones disagree, I need a rule for which one wins. At the moment the inspector's handwritten note wins.
- Dependence on one person. The inspector leads, and if the inspector is away, the work stalls. I keep the notes clear enough for someone else to follow.

## Tools

The tools are listed by purpose, not by brand.

For the work itself:

- A small notebook computer for configuration and for reading the records.
- A phone for the pre-visit summary and for quick entries in the field.
- Simple sensors and data collection units chosen to survive outdoor conditions.
- Battery packs and small solar panels for power.
- Sealed enclosures with cable glands.

For building and repair:

- Screwdrivers, a small knife, pliers and cutters.
- A soldering iron and a few spare leads.
- A multimeter for checking batteries and connections.
- Tape, ties, and spare seals.

For keeping notes:

- This Obsidian vault, where each project has its own set of notes: drivers, lessons, and open questions.
- A paper logbook that stays in the apiary shed as a fallback.

I prefer tools I already know. Learning a new tool during spring is a cost I try to avoid.

## Setup

The setup follows a simple order, so that each step can be checked before the next one begins.

1. Choose the tasks. With the inspector, I pick a small number of recurring spring jobs where a reminder or an automatic record would help.
2. Define the records. For each task I decide what is written down, in which form, and where it ends up.
3. Build on the bench. I assemble the equipment indoors and let it run for a good while. I look for resets, drift, and anything that needs me to touch it.
4. Weatherproof. Enclosures, seals and mounting are done before anything goes outside.
5. Place in the apiary. I put each unit where it will not touch the hive entrance and where a hive tool will not hit it. The inspector approves each position.
6. Watch. For the first days I check each unit often and look at how the bees react.
7. Run beside the manual routine. The paper logbook continues in parallel.
8. Review. At the end of spring I go through the success checks.

Some rules for placement:

- Keep equipment off the front of the hive.
- Keep cables short, tied down, and out of the way of walking paths.
- Make every unit easy to remove in one minute.
- Label every unit so that anyone can tell what it is for.

## Overview

Rendkas automation is a project with the goal of automation, in the beekeeping area, started in 2020 and run in spring under the lead of the inspector. The project is a way to make the repeated spring jobs happen reliably, to cut down the time spent on records, and to give the inspector an early sign when a colony is weak.

The shape of the project, summarised:

| Property | Value |
|---|---|
| Type of project | Project |
| Goal | automation |
| Area | beekeeping |
| Start year | 2020 |
| Season | spring |
| Lead | inspector |
| Budget | 2389.01 EUR |

The main idea is that the system supports the inspector and does not replace the inspector. The money is limited, so purchases are measured against the drivers. The calendar is tight, so bench testing happens early. The bees are not to be disturbed, so placement is cautious. Success is judged by a short list of checks at the end of each spring, and the last of those checks is whether the inspector wants to keep using the result.

If I have to describe the project in one sentence: it is a careful, small-budget effort to let routine spring beekeeping jobs take care of themselves, so that inspection days can be spent looking at the bees.

## Lessons

These are lessons I keep in mind, written as plain rules.

- Start with the smallest useful piece. A single working reminder is worth more than a large system that is nearly finished.
- Bench testing saves springs. Every time I have been tempted to skip it, I have regretted it.
- Keep the paper fallback. It is cheap, it works in the rain, and it makes it safe to try new things.
- Let the inspector decide. The person who walks the apiary sees things that I do not, and a step the inspector does not trust is not worth keeping.
- Prefer boring parts. Common, repairable, replaceable parts beat clever ones.
- Check the enclosures more often than seems necessary. Damp is the usual cause of failure.
- Treat false alarms as a serious fault. Trust is hard to rebuild.
- Write things down on the day. The reasons for a decision are forgotten within weeks.
- Do not add features during the trial. Add them after the review.
- Review honestly. If a step did not help, remove it, even if it took a lot of work.

## References

These are the sources I use, described in general terms since this is a personal vault.

- My own earlier notes on this project, especially the lessons and open questions from previous springs.
- The paper logbook kept in the apiary shed.
- The inspector's own notes and verbal comments after each visit.
- Manufacturer instructions that came with each piece of equipment, kept in a folder next to the logbook.
- General beekeeping handbooks that cover the spring buildup, for understanding which signs matter in a colony.
- Other notes in this vault about the beekeeping area, for shared terms and the apiary layout.

## Open questions

- Which of the spring tasks gives the best return if automated first, and which should stay manual for good?
- How much reserve in the budget is enough, given how often outdoor equipment fails in the first season?
- What is the best rule for deciding between automatic and handwritten records when they disagree?
- Can the early warning be tuned to give few false alarms without missing real problems?
- Is there a simpler way to power the units through cold spring nights?
- Who could take over the lead if the inspector is not available for a season?
- Should the project be extended to other seasons, or does it stay tied to spring?
- How will I know if the equipment is changing how the bees behave, rather than merely not harming them in an obvious way?

## Safety

Safety covers the people and the bees.

For people:

- Wear protective clothing whenever a hive is opened, including when only a unit is being checked nearby.
- Do not work on electrical equipment with wet hands or in rain. Bring it back to the shed.
- Keep batteries away from heat and do not leave damaged ones lying around. Store them safely and dispose of them properly.
- Avoid ladders and uneven ground when carrying equipment. Make two trips rather than one risky one.
- Tell someone when I go to a remote apiary, and carry a charged phone.
- Be careful with the soldering iron and keep it out of the apiary unless it is really needed.

For the bees:

- Never place equipment where it blocks the entrance or the flight path.
- Avoid anything that makes noise, vibration, or strong light near a hive.
- Introduce new items slowly, and check the colony afterward.
- Keep cables out of reach of animals, and keep sharp edges covered.
- If a colony shows unusual behaviour after equipment is placed, remove the equipment first and ask questions later.

The inspector has the final word on any safety matter.

## Observations

These are the observations I record each spring, to feed into the review.

- Number of tasks triggered on time and the number missed, with the reason for each miss.
- Rough time spent on records compared with the previous year.
- Each early warning, whether it was right, and whether it came before I would have noticed by eye.
- Each false alarm and what caused it.
- Every equipment failure, with the weather at the time.
- Any change in how the bees behaved near equipment.
- Comments from the inspector about what helped and what got in the way.
- Spending against the budget, noted at the end of each month.

A general impression after the work done so far: the biggest gains come from the simplest steps, such as reminders and a shared record, and the biggest risks come from damp, cold and over-confidence. The project is still tied to spring, led by the inspector, and bound by its budget of 2389.01 EUR. I will keep checking each of these facts against the drivers at the start of every new round.
