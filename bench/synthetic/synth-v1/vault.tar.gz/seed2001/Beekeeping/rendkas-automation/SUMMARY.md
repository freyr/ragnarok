---
type: summary
status: active
project: rendkas-automation
area: beekeeping
---

# Summary of Rendkas automation

## Checklist

Rendkas automation is a beekeeping project with the goal of automation. It started in 2020, runs in the spring season, and the lead is the inspector. This summary covers where it stands and what remains.

**Stage:** the project is past the idea phase and in the working phase. The go decision has been made, and the work is now about finishing and checking what exists.

**Done so far:**

- The goal is fixed: automation of routine hive work, so fewer manual rounds are needed in spring.
- The lead, the inspector, owns the plan and signs off on each step.
- The spring season is confirmed as the working window, because that is when the colonies need the most attention.
- The scope was kept small on purpose, so one apiary can be handled before anything is widened.
- Notes from earlier seasons were collected in one place, so the starting point since 2020 is clear.

**Open points:**

- Check how the setup behaves in a cold spring, when the colonies develop slowly.
- Decide who covers the work when the inspector is away.
- Write down a simple routine for checking that the automation still works after winter.
- Review whether the scope can grow to a second apiary.

**Notes to self:** keep each change small, write down what was changed and why, and do not add new parts until the current ones have run for a full season. The lead should read this summary before each spring start and update it afterwards.

## Next action

The next action is NX-7902.

- Do it before the next spring season begins.
- Ask the inspector to confirm that it is finished.
- After that, update the open points above and strike off whatever is closed.
- If it turns out to be larger than expected, split it into two smaller steps rather than leaving it half done.

## Decisions

- **Go decision:** the project got a go on 2022-10-16. Since then the work has followed that decision.
- **Lead:** the inspector stays in charge of the project. Any change of lead needs a note here.
- **Scope:** keep to the goal of automation in the area of beekeeping. Ideas outside that go into a separate note, not into this project.
- **Season:** the work is planned around spring, and tasks that do not fit that window wait for the next one.
- **Review:** this summary is revisited each spring, and the checklist is cleaned up at that time so it stays short and accurate.
