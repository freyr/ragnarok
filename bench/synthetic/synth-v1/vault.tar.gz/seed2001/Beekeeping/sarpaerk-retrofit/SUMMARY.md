---
type: summary
status: active
project: sarpaerk-retrofit
area: beekeeping
description: "Summary about Sarpaerk retrofit."
---

# Summary of Sarpaerk retrofit

## Observations

This is the summary note for the Sarpaerk retrofit. It is a project with the goal retrofit, in the area of beekeeping. It started in 2023, in the autumn season, and the lead is my neighbor. I keep this page as the one place to look when I want to know where things stand without opening every working note.

The project is about taking the existing beekeeping setup and bringing it up to a better standard without rebuilding everything from scratch. That is what retrofit means here: keep the good bones, replace or adjust the parts that cause trouble. Most of the work so far has been looking, measuring and talking, with a smaller share of actual cutting and fitting.

Things I have noticed so far:

- The old equipment is mostly sound. The weak points are in a few specific places, not spread evenly.
- Autumn is a good time to do this work, because the colonies are settling and there is less pressure from the honey flow. Work in the yard goes quietly.
- My neighbor leads, and that works well. They have more hands-on experience with the equipment, and I handle the notes, the planning and the shop work.
- Every time we thought a job would take an afternoon, it took a weekend. I now plan with that in mind.
- Weather decides more than the plan does. Dry days are rare in late autumn, and anything that needs glue or paint waits for them.

The current stage is mid-project. The planning and the decision to go are finished, the main preparation is done, and the remaining work is a mix of small finishing jobs and a few unanswered questions. The next action is recorded further down, in its own section.

## Background

The reason for the retrofit is simple. The setup grew piece by piece over several seasons, and nothing in it was ever designed as a whole. Some parts came second-hand, some were built in the workshop, and some were borrowed and never returned. It worked, but it was awkward, and each season exposed another weak point.

My neighbor kept bees long before I started paying attention. When we first talked about the setup, they pointed out that most of the awkwardness came from a handful of mismatches: parts that nearly fit but not quite, fittings from different makers, and work surfaces at the wrong height. Fixing each mismatch separately would cost less than replacing the whole arrangement, and that is how the idea of a retrofit took shape.

The goal is retrofit, and I try to keep that word in mind when scope creeps. Whenever someone suggests building something new, the question is whether the old part can be adapted. Often it can.

Some of the thinking came from earlier work in the workshop. The notes in [[Krioskus kiln controller notes 2019]] cover an earlier project where I learned how much a careful controller and steady, slow drying matter for timber. That lesson carried over: wood for hive parts should be properly dried before it is cut to final size, or the joints open up later. I reread those notes at the start of this project and used them to set the drying plan for the new timber.

For the cutting, I rely on the [[Tronas band saw]]. It handles most of the timber work here, from rough breakdown to the curved and angled cuts that the old parts need. Knowing its limits, such as the maximum cut height and how the blade drifts when it gets dull, shaped how I planned the individual jobs.

## History

The project has a longer history than its start year suggests. The idea was discussed informally well before any work began, and the formal go decision sits in the Decisions section below. The actual start of work was in 2023, in the autumn season, which is the date I use as the project start year.

A rough timeline, without exact dates:

1. **Early talk.** My neighbor and I compared notes on what was wrong with the setup. We walked the yard, looked at each piece, and listed problems on paper.
2. **Decision.** After some back and forth we agreed the retrofit was worth doing and made a formal go decision.
3. **Waiting.** Other commitments came first. The idea stayed in a drawer for a while, and I kept adding notes to it.
4. **Start in 2023.** In the autumn of 2023 we began work in earnest. The first step was an inventory of what we had and what condition it was in.
5. **Preparation.** Timber was bought and set aside to dry. The saw was checked and tuned. Templates were made from the best of the old parts so new pieces would match.
6. **First fittings.** A few pieces were cut and test-fitted. Some worked on the first try, others needed adjustment.
7. **Current stage.** Most of the preparation is finished and we are in the middle of the fitting and finishing work.

Looking back, the slow beginning was not wasted. The waiting period gave me time to think through the plan, and the inventory turned up several parts I would otherwise have bought again.

## Open questions

These are the points I have not resolved. I list them so I do not forget them, and so I can see at a glance what is blocking progress.

- **Finish for the outdoor parts.** We have not agreed on what to use to protect the timber. My neighbor prefers a traditional approach, and I would like something that needs less upkeep. We should decide before the next round of finishing.
- **Handling the oldest parts.** Some of the oldest pieces are worn enough that adapting them may cost more effort than making new ones. I need to go through them one by one and decide which to keep.
- **Order of work.** It is not clear whether to finish one section completely before starting the next, or to work across all sections at once. Finishing one at a time is tidier, but doing it in parallel makes better use of dry days.
- **Storage during the winter.** Where do the finished parts wait until they are needed? The workshop is crowded, and the shed is damp.
- **Who does the final check.** My neighbor leads, but I would like a second opinion from someone who has done a similar retrofit.
- **Spare parts.** How many spare pieces should we cut while the saw is set up? Extra pieces cost little now and save a lot later, but they also take space.

I will move each of these into the Decisions section once it is settled, and strike it here.

## Next action

The next action for the Sarpaerk retrofit is NX-0345.

I keep only one next action on this page, so that when I open the note I know exactly what to do. When it is done, I replace it with the one that follows and note the change in the History section.

## Maintenance

Once the retrofit is complete, the setup needs regular care, and it is better to plan that now than to discover it later.

- **Seasonal inspection.** Each autumn, walk through the setup with my neighbor and check every joint, fitting and surface. Anything loose or soft gets noted and fixed before winter.
- **Finish upkeep.** Whatever finish we choose will need renewing from time to time. The interval depends on the finish, which is why the open question about it matters.
- **Saw care.** The [[Tronas band saw]] needs a sharp blade and correct tension for clean work. I check the blade before each large job and keep a spare on the shelf.
- **Timber stock.** Keep any leftover timber stacked flat with spacers so it stays straight. Check it now and then for moisture and insects.
- **Records.** After each inspection, add a short entry to this note or a linked note. A line or two about what was found and fixed is enough.

The aim is for maintenance to be dull and predictable. If it turns into a regular emergency, the retrofit has not done its job.

## Checklist

A working list of what is done and what remains. I tick items off in my own copy; here I describe the state in words.

**Done**
- Inventory of existing equipment and its condition.
- Decision to go ahead, agreed with my neighbor.
- Timber bought and set aside to dry.
- Saw checked and tuned for the work.
- Templates made from the best old parts.
- First test fittings completed.

**In progress**
- Cutting and fitting of the main replacement parts.
- Sorting of old parts into keep, adapt and discard.

**Still to do**
- Choose and apply the finish.
- Final fitting and check with my neighbor.
- Arrange winter storage for finished parts.
- Write up the maintenance routine in its final form.
- Close the project and move lasting lessons into permanent notes.

## Ideas

Some thoughts that came up along the way. None of them is committed to, and none is part of the plan yet.

- Make a simple jig for repeated cuts on the saw, so that matching parts come out identical without remeasuring each time.
- Mark each finished part discreetly with its position in the setup, so reassembly after winter storage is quick.
- Keep a small box of tested fittings and fasteners next to the work area, sorted by size, so searching does not eat the dry hours.
- Ask my neighbor to record a few short notes on their own methods. Much of what they know is not written anywhere.
- Photograph each stage of the retrofit from the same spot. It would make a useful record and help me judge progress.
- Consider a small improvement to the work surface height, since back strain was a recurring complaint during the inventory.
- Revisit the drying approach from [[Krioskus kiln controller notes 2019]] if a larger batch of timber is needed later.

## Tools

The tools that matter for this project:

- **[[Tronas band saw]].** The main machine. Used for breaking down timber, cutting curves and making template-matched parts. The blade condition decides how clean the work comes out.
- **Hand planes and chisels.** For the final fit of joints. Machine cuts get close, but the last bit is done by hand.
- **Measuring and marking tools.** Rule, square, marking gauge and pencil. I check every measurement twice, and measure from the same reference edge.
- **Clamps.** Never enough. I borrow from my neighbor whenever a glue-up needs more.
- **Templates.** Made from good old parts. They are the real reference for the whole project, and I store them flat and labeled.
- **Moisture meter.** Used to check that the timber is dry enough before cutting to final size.
- **Finishing supplies.** Brushes, rags and containers, to be chosen once the finish question is settled.

I keep the tool notes short here. Detailed settings and tips belong in the notes for each tool.

## Overview

A quick summary of the project in one place.

| Property | Value |
| --- | --- |
| Project | Sarpaerk retrofit |
| Goal | retrofit |
| Area | beekeeping |
| Start year | 2023 |
| Season | autumn |
| Lead | neighbor |

The retrofit improves the existing beekeeping setup rather than replacing it. It began in the autumn of 2023 and is led by my neighbor, with me handling planning, notes and the shop work. The preparation stage is finished, the fitting and finishing stage is under way, and a handful of open questions remain. The next action is listed in its own section above.

What matters most right now is momentum. The project is at the point where small jobs can pile up and stall, so I try to keep each work session focused on one clear task and finish it.

## Decisions

Decisions made so far, with the reasoning behind each.

- **Go decision.** The go decision date of the Sarpaerk retrofit is 2020-04-19. That is when my neighbor and I agreed the retrofit was worth doing and committed to it in principle. The work itself began later, in 2023.
- **Retrofit, not rebuild.** We decided to adapt existing parts wherever they are sound. This keeps cost and effort down and preserves the good parts of the setup.
- **My neighbor leads.** Because they have the most practical experience, they make the final call on method. I keep the notes and handle the workshop side.
- **Timber is dried first.** Following the lessons in [[Krioskus kiln controller notes 2019]], no timber is cut to final size until it has dried properly.
- **Templates from good old parts.** New pieces are matched to templates, not to measurements alone. This avoids drift between parts.
- **Do the cutting on the [[Tronas band saw]].** It is the main machine for the timber work, and jobs are planned around what it can do well.
- **Work in autumn.** Autumn is the working season for this project because the yard is quieter.

Decisions still pending are in the Open questions section.

## Setup

The working arrangement for the project.

The workshop is the main base. The [[Tronas band saw]] sits near the door so long timber can be fed through without bending around corners. A bench along one wall holds the templates, measuring tools and the parts in progress. Drying timber is stacked flat at the back with spacers between the layers, off the floor and away from the wall.

The yard is the second base. Test fittings happen there, because that is where the real conditions are. We bring parts out, try them in place, and bring them back for adjustment. This back and forth is slow but catches errors early.

Roles are straightforward. My neighbor leads on method and decides how each job is done. I prepare the timber, run the saw, and keep the notes. When a job needs two people, such as a heavy fitting or a long glue-up, we do it together and agree on the order beforehand.

A few habits help:

- Label every part as soon as it is cut.
- Keep the templates in one place and never lend them out.
- Write down any change of plan the same day, in this note or a linked one.
- Clear the bench at the end of each session so the next one starts clean.

## Problems

The problems met so far, and what I did about them.

- **Mismatched parts.** The original setup used fittings that nearly fit but not quite. This is the main reason for the project. The templates help us avoid repeating it.
- **Slow dry days.** Late autumn weather limits glue and finish work. We now batch such jobs and keep indoor tasks ready for wet days.
- **Blade drift on the saw.** When the blade dulled, cuts began to wander. The fix was a fresh blade and a check of the tension and guides before each large job. Notes on this are linked from [[Tronas band saw]].
- **Underestimated time.** Nearly every job took longer than expected. I have added a margin to every estimate.
- **Worn old parts.** Some pieces were more worn than they looked at first. Inspecting them closely before deciding to adapt them saves wasted effort.
- **Crowded workshop.** Drying timber, finished parts and tools compete for space. This links to the open question about winter storage.
- **Gaps in my own notes.** Early on I did not record small adjustments, and later could not remember why a part had been altered. Now I write every change down.

None of these has stopped the project. They have mostly slowed it, and each one taught something useful for the next job.

## Costs

I keep the cost notes in plain words and avoid exact figures here, because prices change and I track amounts elsewhere.

The biggest cost is timber. Buying good wood and letting it dry takes both money and time, and it is not a place to economize. Poorly dried or cheap timber costs more in the end through warped parts and redone work.

The second cost is consumables for the saw and for finishing: blades, abrasives, glue and the finish itself. These are small individually but add up over the length of a project. A spare blade is cheap insurance.

Some costs are in time rather than money. The inventory, the template making and the repeated test fittings all took many hours. I count these as a real part of the budget, because they are the work most likely to be skipped when a project runs late.

The retrofit approach saves money overall. Every old part we adapt is a part we did not buy or build again. The cost I most want to avoid is a mid-project change of mind that leaves finished parts unused, which is why the open questions need answers soon.

Costs I will watch from here on:

- Extra timber if the oldest parts turn out to be beyond saving.
- The finish, once chosen, and how often it needs renewing.
- Replacement blades and other saw supplies.
- Any tools that we end up borrowing too often and should simply buy.

When the project closes, I will compare what was spent with what I expected and record the lesson in a permanent note.
