---
type: research
status: active
project: sarpaerk-retrofit
area: beekeeping
description: "Research about Serktrio Zothken."
---

# Serktrio Zothken tests

## Schedule

Serktrio Zothken is my mentor in beekeeping. I have known him since 2012, and most of what I know about hives I learned by asking him questions and then watching what he did instead of what he said. This note collects the tests I have run with his guidance and the practical details of working with him.

He is available on weekdays. Weekends are not an option, so anything that needs his eyes on a hive has to be planned for a weekday. His preferred contact is by phone. He does not answer messages reliably, and a call usually gets a result the same day.

My working routine for scheduling a test:

- Decide what I want to check and write it as a single question.
- Call him on a weekday and describe the question in a few sentences.
- Let him choose the day. He knows the weather in this valley better than any forecast.
- Keep the afternoon free, because a short visit can easily turn into a long one.
- Write up the result the same evening, while I still remember his wording.

Tests that depend on the season go in the spring and summer. Tests that only involve equipment can be done in the quiet months. I try not to ask him for field time during a nectar flow, since that is when his own hives need the most attention.

## Safety

Safety is the first thing Serktrio talks about, and he repeats it at the start of every visit. I have written his rules down in my own words so I stop skipping them when I am in a hurry.

- Wear the full veil and gloves for any test that involves opening a hive, even if the colony is calm. A calm colony can change its mind quickly.
- Light the smoker before approaching, not after the first sting.
- Keep a clear exit path behind me. No tools, crates, or loose cables on the ground near the hive stand.
- Never test electronics near the hive entrance while the bees are flying heavily. Cables and small boxes attract attention, and a dropped device is a bad reason to get stung.
- If anyone present has a known reaction to stings, they stay well back and have their medication within reach.
- Do not work in damp, windy, or thundery conditions. Defensive behavior goes up and so do mistakes.

For tests that involve water, such as sensors placed in a pond or a trough, I add the usual wet-ground care: stable footing, no working alone at the edge, and a phone kept in a sealed pouch. The pond work is described more fully in [[Gundpio pond tests]].

Serktrio also insists that I tell somebody where I am going when I visit remote hives. That habit has stuck with me.

## Open questions

These are the things I have not settled with him or by my own testing. I keep the list short so it stays useful.

- How much of his judgment about hive condition can actually be replaced by a sensor reading, and how much is only the feel of the frame in his hands? He says very little of it, and I am not sure I agree.
- What is the best placement for a level sensor in a water source used by bees? Too close and the bees crowd it, too far and the reading does not reflect what they use. Compare [[Starklil level sensor plan]] and [[Gindrir level sensor handbook]].
- Will a small solar charger keep a field device alive through a cloudy stretch in autumn? The thinking so far is in [[Tarkvaer solar charger plan]].
- Does the greenhouse offer a useful sheltered place for early-season colony tests? I have notes in [[Lioder greenhouse notes]] but no conclusion.
- How should I record his advice so that the reasoning is kept, not only the instruction?
- Is phone contact enough, or should I set up a standing weekday call during the busiest part of the year?

I will move items out of this list as they are answered, and put the answer under Lessons.

## Tools

The tools for these tests are modest. Serktrio distrusts anything complicated, and he has a point: a tool I cannot repair in the field is a liability.

Hive tools and handling:

- A standard hive tool and a frame grip, both kept clean between visits.
- A smoker with dry fuel stored in a sealed tin.
- A soft brush for moving bees off frames.
- A notebook with a pencil. Pens fail in damp air.

Measurement and monitoring:

- A basic scale platform under one hive for weight tracking.
- A simple water level sensor, with the design choices explained in [[Starklil level sensor plan]] and the reference material in [[Gindrir level sensor handbook]].
- A small solar charger setup to keep the sensor powered, planned in [[Tarkvaer solar charger plan]].
- A waterproof pouch for the phone and a spare battery pack.

Serktrio's own tools are older than my gear and better kept. He has a favorite hive tool he has used for many years, and he sharpens it by hand. When I asked where he bought it, he said he could not remember, which I take to mean it was a long time ago.

## Maintenance

Maintenance matters more to him than any new device, and most of his advice in this area is about habit, not equipment.

For hives and stands:

- Check that each stand is level and stable at the start of every season.
- Scrape and inspect the boxes for rot and cracks, and repair them before they become gaps.
- Keep the grass cut around the entrance so bees do not have to climb through it.
- Replace worn frames on a rolling basis instead of all at once.

For my test equipment:

- Rinse sensors after any contact with pond water and let them dry fully before storage.
- Inspect cable insulation for chewing or sun damage.
- Wipe solar panels clean, since dust and pollen reduce output more than I expected.
- Charge and cycle the battery packs through the winter so they do not sit empty.
- Label every cable and box, because I will not remember what each one does after a few months.

Serktrio's rule is that anything left outdoors will be tested by weather, so assume it will fail and plan for it. I have started writing a short maintenance entry after each visit, noting what I touched and what I intend to check next time.

## Contracts

The formal arrangement with Serktrio Zothken is light, but I record it so that expectations stay clear on both sides. The contract date of Serktrio Zothken is 2024-12-23.

What the arrangement covers, as I understand it:

- He acts as my mentor in beekeeping and gives guidance on hive management and seasonal work.
- Contact is by phone, and visits are arranged for weekdays.
- I handle my own equipment and supplies, and I take responsibility for my own hives.
- Neither of us is obliged to a fixed number of visits. We agree on them as the season requires.
- Anything I build or test using his advice stays my own work, but I credit him in my notes.

The relationship started well before the contract. We have known each other since 2012, and the written arrangement mostly confirmed what we were already doing. I treat it as a reminder of respect for his time, not as a rigid set of terms.

If the arrangement changes, I will add the new details here and keep the old ones in History, so the sequence stays readable.

## Supplies

Supplies for the testing work fall into three groups: bee-related, power-related, and general field items.

Bee-related:

- Spare frames and foundation, stored dry and away from pests.
- Feeding equipment for lean periods, used only when Serktrio agrees it is needed.
- Replacement veils and gloves. These wear out faster than I expect.
- Clean cloths and containers for handling any samples.

Power and sensing:

- Spare cables and waterproof connectors for the level sensor work.
- Backup batteries to pair with the solar charger from [[Tarkvaer solar charger plan]].
- Mounting hardware that will not corrode near water.

General field items:

- A first aid kit, with antihistamines and a clear note of who is allergic to what.
- Drinking water, because these visits last longer than planned.
- A folding stool and a small tarp for wet ground.
- A flask of something hot in cold months.

Serktrio always brings a small bag of his own, and it always contains a few items I forgot. I now keep a checklist on the inside of my toolbox lid so I stop depending on his bag.

## Lessons

Lessons are the practical conclusions I have taken from working with him.

- Observe before acting. He will stand at a hive entrance for a good while before opening anything, and the traffic tells him a great deal.
- Keep the question small. Each test should answer one thing. When I tried to test several variables together, the results were useless.
- Simple tools win. A weight scale and a notebook told me more about colony strength than my early attempts at complicated monitoring.
- Do not rush the bees. Rushed movements cause stings and bad data.
- Write things down the same day. Memory edits advice into something more convenient.
- Ask for the reason, not only the rule. When he explains why, I can apply the idea in situations he never mentioned.
- Respect his time. A short, well-prepared phone call on a weekday gets better advice than a rambling one.
- Test equipment in a calm setting first. Learning the sensor setup near the pond, as in [[Gundpio pond tests]], was easier than learning it beside a busy hive.

## Observations

These are observations from the tests so far, written as plain statements of what I saw.

Colony behavior:

- Bees visit a water source more heavily on warm, dry days, and the traffic drops sharply when the weather turns cool.
- They tend to settle on one watering spot and ignore alternatives, so moving a source mid-season causes confusion for a while.
- Anything new near the entrance gets inspected closely, then largely ignored after a short period.

Equipment behavior:

- The level sensor readings were steady in calm water but jumped when bees landed on or near the housing. The design notes in [[Starklil level sensor plan]] should account for that.
- Solar output dropped noticeably when the panel collected dust and pollen. Cleaning restored it.
- Cables left loose were moved or chewed by wildlife more than once.
- Condensation inside enclosures was a recurring problem, and sealing alone did not solve it.

Serktrio's own observation, which I wrote down because it stuck with me, is that bees tell you what they need if you are patient enough to watch. Most of my early failures came from watching too briefly.

## History

I met Serktrio in 2012, when I was a beginner with a borrowed hive and more enthusiasm than knowledge. He was already an experienced keeper, and he agreed to answer my questions after I turned up with a poorly planned list of them. He was patient about it.

Over the following years our contact settled into a pattern: phone calls on weekdays, visits when something needed hands-on explanation, and occasional help during the busiest parts of the season. He never presented himself as a teacher in any formal sense, but he became my mentor in practice well before either of us used the word.

The written arrangement came later, with the contract date of 2024-12-23 recorded under Contracts. By then I had begun more technical side projects around the hives, such as water level monitoring and solar power, and I wanted a clearer understanding of how much of his time those projects could reasonably claim.

The testing described in this note comes from that later period. The earlier years were more informal, and most of what I remember from them is practical: how to light a smoker properly, how to read a frame, how to leave a hive without upsetting it.

## Background

Beekeeping in this region follows a fairly predictable year. Spring is about building up colonies, summer is about the nectar flow and managing space, and autumn is about preparing for winter. Serktrio plans around that rhythm, and he expects me to do the same.

His approach is conservative. He prefers small, reversible changes, and he is skeptical of anything marketed as a shortcut. He has seen many trends come and go, and his view is that colonies reward consistency more than cleverness.

My interest in adding sensors and small electronics is a bit at odds with his habits, but he has been open-minded about it, within limits. His condition is that any device must tell him something he could not easily learn by looking, and must not disturb the bees. That is a fair test and I have adopted it.

Related projects that feed into this work include the sensor planning in [[Starklil level sensor plan]], the reference in [[Gindrir level sensor handbook]], the water-side trials in [[Gundpio pond tests]], the power thinking in [[Tarkvaer solar charger plan]], and the sheltered-space notes in [[Lioder greenhouse notes]].

## Risks

The risks fall into several categories, and I try to keep each in view.

Personal risks:

- Stings, including the chance of a stronger reaction than expected. Preparation and a clear plan for emergencies matter more than confidence.
- Working near water with equipment in my hands.
- Fatigue during long visits, which leads to carelessness.

Colony risks:

- Disturbing a hive at the wrong moment, especially during a poor weather spell or a dearth.
- Introducing disease through unclean tools or shared equipment.
- Altering a water source so that bees abandon it or crowd somewhere unsafe.

Project risks:

- Electronics failing outdoors from moisture, heat, or wildlife.
- Power running out during a cloudy period, leaving gaps in data.
- Over-relying on readings and ignoring what the hive itself is showing.

Relationship risks:

- Taking too much of Serktrio's time, especially since he is available only on weekdays and has his own work.
- Treating his advice as automatic permission instead of one input to my own decision.

The best mitigation for most of these is the same: go slowly, keep notes, and ask him before I do something I have not done before.

## References

Linked notes in this knowledge base:

- [[Starklil level sensor plan]]: the design plan for the water level sensor used in some tests.
- [[Gindrir level sensor handbook]]: reference material on sensor behavior and installation.
- [[Gundpio pond tests]]: results from the trials near the pond.
- [[Tarkvaer solar charger plan]]: the plan for powering field devices.
- [[Lioder greenhouse notes]]: notes on using the greenhouse as a sheltered space.

Facts about the person, for quick lookup:

- Name: Serktrio Zothken
- Role: mentor
- Area: beekeeping
- Contact: phone
- Availability: weekdays
- Known since: 2012

Most of the real reference material is in Serktrio's head, and what I have is what I managed to write down. This note is my best attempt to make that knowledge available to my future self.

## Ideas

A few ideas I want to raise with him, in rough order of how likely I think they are to be worth the effort.

- Keep a shared seasonal calendar, so a weekday visit can be planned against the real state of the hives and not against my guesses.
- Run a simple side-by-side test of a sensor reading against his judgment of the same hive, and record where they agree and where they do not.
- Test a shaded, sheltered mounting position for the sensor near the water source, using what I learned in [[Gundpio pond tests]].
- Try the solar charger setup in the greenhouse first, as described in [[Lioder greenhouse notes]], to see how it behaves before putting it outdoors.
- Write a one-page checklist for visits, covering safety, tools, and questions, so each phone call is shorter and more focused.
- Ask him to talk through one full season out loud while I record notes, so the reasoning behind his decisions is preserved.
- Consider a small training session for another beginner, with Serktrio supervising, so that his knowledge is passed on more widely.

None of these need to happen soon. I will pick one at a time and see what he thinks.
