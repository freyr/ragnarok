---
type: plan
status: active
project: sarpaerk-retrofit
area: beekeeping
---

# Tothbi solar charger plan

## Problems

The Tothbi solar charger is a black solar charger that I installed in the shed in 2023. It is used for beekeeping, mainly to keep the batteries charged for the electric fence, the hive scale and the small lamp I use during evening inspections. Despite the name, its energy source is mains, so it does not depend on sun at all. That is the first oddity I want to sort out, because I originally bought it believing it would run from a panel on the roof.

The problems I have noticed so far:

- The charger sits in the shed, where it gets damp in autumn. The case is fine, but the plug and the extension lead show some corrosion on the contacts.
- It runs warm even when the batteries are full. I suspect it never drops to a proper float mode.
- The cable to the shed is long, and I lose some power on the way. I want to check whether the voltage at the charger is stable.
- Because the energy source is mains, any outage in the village leaves the fence batteries without charge. I have no backup for this.
- The black casing absorbs heat when the shed door is open in summer, which probably makes the warmth issue worse.

The plan is to deal with the damp first, then the heat, then decide whether to add a real solar panel as a second source.

## Costs

I want to keep this cheap, since the charger itself already works. The expected spending is small and I will write down real receipts when I buy things.

- A sealed weatherproof socket box for the shed wall: low cost, a few coins from the hardware shop.
- A timer plug so the charger only runs for part of the day: low cost.
- A small solar panel with a charge controller, as a backup source: this is the big item, and I will only buy it if the measurements show the mains draw is worth reducing.
- Silicone grease for the contacts: almost nothing.

Running cost is the other part. If the charger really draws all day, then over a year it adds up to more than I expected for such a small job. Once I have the measurements I will multiply the draw by the hours per day and compare it with the cost of the panel. If the payback is longer than a few seasons, I will skip the panel and just use the timer.

## Measurements

I plugged the charger into a plug-in energy meter in the shed and left it running with the batteries full. The measured power draw of Tothbi solar charger: 152.56 W.

That is much higher than I expected for a charger that should be idling, and it supports my suspicion that it does not go into float mode. It also explains the warmth.

Here is the log format I use for my notes when I read the meter. I copy the readings by hand into a text file in the shed:

```
# shed meter log
device: Tothbi solar charger
location: shed
source: mains
state: batteries full
reading_power: 152.56 W
check_next: contacts, socket box, timer plug
```

Next measurements to take:

1. Draw with the batteries nearly empty, to see the peak.
2. Draw with the batteries full after the timer plug is fitted.
3. Voltage at the charger end of the long cable, compared with the voltage at the house.
4. Surface temperature of the black case on a warm afternoon.

When I have these, I will update this plan and decide about the panel.
