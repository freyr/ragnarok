---
type: drivers
status: active
project: kriovos-upgrade
area: beekeeping
description: "Drivers about Kriovos upgrade."
---

# Drivers of Kriovos upgrade

## Setup

Kriovos upgrade is a project in the beekeeping area. Its goal is upgrade. It started in 2019, in spring, and the carpenter leads it. This note covers the drivers: why the work exists, what limits it, what it costs and how I decide it worked.

The goal is simple. The apiary equipment I built over the first years was made quickly, and it has worn out unevenly. The upgrade replaces the weakest parts with sturdier ones, so that the yard needs less repair each season and I spend less time fixing things in the middle of the work.

Spring is the season for this project, and that is a hard constraint. The colonies are small and the weather is mild, so I can open and move things without much risk. If the work slips past spring, it waits for the next year. Because the carpenter leads, most of the work is woodwork: new frames, stands and a few boxes. I cut most of the timber on the [[Tronas band saw]], so its availability and condition set the pace.

Power in the yard comes from solar. I keep notes on the charging side in [[Giordin solar charger notes]] and [[Gioltrar solar charger log]]. Before I start cutting, I check both to see whether the battery will carry the tools for a full day.

How I measure success:

- Fewer repairs during the season than in the year before.
- Every stand sits level and takes the full weight of a hive without rocking.
- Colony weights can be read reliably. I follow the method in [[Muthdralpe scale handbook]] and the readings from the [[Brindkrerk level sensor]].
- The work is finished within spring, with no hive left half-moved.

## Budget

The budget of Kriovos upgrade is 6462.01 EUR. That figure covers timber, hardware, finishes, replacement parts for the scales and a reserve for mistakes. I do not count my own labor in it.

I split the money by priority, not by exact amounts:

- Timber and hardware come first, because most of the project is carpentry and these cannot be skipped.
- Weighing and sensing equipment comes second. It is the part that tells me whether the upgrade pays off.
- Power and tool upkeep is third. The saw blades and the charger cabling are small costs, but a failure there stops everything.
- A reserve is kept for bad cuts, warped boards and anything I did not foresee.

I compare the shape of this spending with an earlier build, [[Nithden greenhouse 2023]], where I underestimated the cost of fasteners and finishes. This time I price those items first, not last. If the total passes the budget, I cut scope on the boxes before touching stands or the weighing parts, since those affect the measurements.

I also keep contact notes for a supplier of seasoned timber in [[Raemaertur Truthkon notes]]. Buying dry wood early is the best way I know to avoid paying twice.

## Safety

Most of the risk comes from the saw and from the bees. I treat them separately.

For the saw, I follow these habits every time:

- Guard in place, blade sharp, and the table clear before any cut.
- Eye and ear protection, and no loose sleeves.
- Never cut alone when the pieces are long. A second person supports the offcut.
- Unplug or disconnect the battery before changing a blade.

For the bees:

- Work in spring on calm, warm days, and not when colonies are defensive.
- Wear the full suit and gloves when moving or lifting hives.
- Move heavy boxes with two people, or lighten them first, so nobody strains a back while holding a loaded stand.
- Keep a smoker lit and a first aid kit nearby, with an allergy plan written down.

Solar power adds a smaller risk. I check cable insulation, keep connections dry and never leave the charger exposed in rain. Any damaged cable is replaced, not taped.

If conditions are unsafe, such as wind, wet ground or tiredness, the work stops. A late finish within the season costs less than an injury.
