---
type: note
status: active
project: kriovos-upgrade
area: beekeeping
description: "Note about Taelluseth level sensor."
---

# Taelluseth level sensor notes

## Safety

The Taelluseth level sensor is a green level sensor used in my beekeeping work. It has been installed in the cellar since 2015, and it runs on a battery. The cellar is where I keep the heavy honey buckets and the settling tanks, so most of the safety points are about the room itself rather than the device.

- The cellar floor is damp in wet months. I step carefully near the sensor, because it sits low on the wall beside the settling tank.
- Battery chemistry matters. I never leave a tired battery inside the housing over winter, because a leaking cell would damage the contacts and could irritate skin.
- I keep the sensor away from open flame and from the smoker fuel. The smoker is stored upstairs, not in the cellar.
- When I open the housing I wear gloves and do it on the workbench, never over the tank. A dropped part falling into honey is a waste and a mess.
- Ventilation: I open the cellar hatch before working down there for a long time, especially after the fermenting buckets have been standing.

If anything smells sharp or sweet-sour near the battery, I stop, take the battery out, and leave the housing open to air out.

## History

I installed the Taelluseth level sensor in 2015. At that time I wanted a way to know how full the settling tank was without climbing down every evening during the harvest weeks. The device is a level sensor, green in color, and the green housing has turned slightly paler over the years because of the cellar damp.

The first season went fine. The second season, the reading drifted, and I found the cause was honey residue on the probe end. After that I started a simple cleaning routine, described under Maintenance.

Some of the early comparison work was recorded in [[Bilathgend level sensor tests]], where I put the Taelluseth next to another unit and noted how each one behaved when the tank was nearly full. The result was that the Taelluseth was slower to react but steadier, which suited the cellar, where nothing changes quickly.

Later I thought about moving the whole monitoring setup into a wider plan, which I sketched in [[Staeraerk Piostrond plan]]. That plan is still only a sketch. The sensor stays where it is for now.

## Maintenance

Maintenance is mostly cleaning and battery care. The energy source is a battery, so the battery is the part that needs the most attention.

1. Wipe the probe end with a cloth dampened in warm water. Honey dissolves easily, and soap is not needed.
2. Dry the probe fully before it goes back. A wet probe gives false high readings.
3. Check the battery contacts for green or white crust. If I see any, I scrape it off gently with a wooden stick, never metal.
4. Replace the battery at the start of the season, not when it fails. A failure in the middle of harvest is the worst timing.
5. Look at the cable entry and the seal. The cellar damp finds any gap.

I keep a small cloth and a spare battery in a labeled box on the shelf next to the sensor. Anything I learn about cleaning goes into this note so I do not have to rediscover it.

Once a year I compare the sensor reading against a plain dipstick in the tank. If the two disagree by more than I can accept, I clean again and recheck before blaming the device.

## Background

The area is beekeeping, and that shapes how I use the sensor. Honey is thick, and tank levels move slowly. What I need is a steady reading, not a fast one. A level sensor suits this because it tells me when to start bottling and when to stop topping up.

The cellar location was chosen because it stays cool and fairly constant in temperature. That helps the battery last, since cold and heat both shorten battery life, and a stable room avoids the worst of it.

I have kept other equipment notes alongside this one. The [[Riothsorfi scale handbook]] covers the hive scale I use for weighing, which gives a different kind of information: weight over time rather than fill level. I read the two together at harvest.

For radio signals from outdoor gear, I rely on the [[Viorktraen radio receiver]]. The Taelluseth does not use it, since the cellar walls block most signals, but I keep that receiver in mind in case I ever want remote readings.

Some of the early idea of watching things by instrument rather than by habit came from [[Mastend Runpith]], whose methods I borrowed in a simplified form.

## Measurements

The main number I recorded is power draw. The measured power draw of Taelluseth level sensor: 114.83 W. That seems high for a battery device, so I treat it as a figure to recheck, possibly with a different meter, before I rely on it. I wrote down exactly what the meter showed.

Here is a summary of the fixed properties and what I measured, kept together for quick reference.

| Property | Value |
|---|---|
| Kind | level sensor |
| Area | beekeeping |
| Color | green |
| Energy source | battery |
| Year installed | 2015 |
| Location | cellar |
| Measured power draw | 114.83 W |

Other readings I take are informal. I note the tank level at the start and end of each bottling day, and I compare that with the sensor. The sensor tends to read a little low when the honey is cold and a little high just after the tank has been stirred, because of bubbles near the probe.

I do not trust any single reading. I trust the pattern across a few days.

## Schedule

My routine follows the beekeeping year. The cellar is quiet in winter and busy from late summer.

- Early spring: replace the battery, clean the probe, and check the seal.
- Early summer: test the reading against the dipstick before the first extraction.
- Harvest weeks: glance at the sensor each evening. Clean the probe after any overflow or spill.
- Autumn: after the last bottling, clean the probe thoroughly and check the contacts.
- Winter: remove the battery if the sensor will sit unused for a long stretch, and store it somewhere dry.

I also set aside a short slot once each season to read through my notes on related equipment. For heating and drying tasks I sometimes consult [[Krioskus kiln controller notes]] and [[Nevirkun kiln controller study]], since the thinking about thresholds and alarms carries over even though the equipment is different.

The loft is where I dry frames and store spare gear, and I log that in [[Brethgleth loft]]. I check the spare batteries there against the cellar box at the start of every season, so I always know how many I have.

## Problems

Problems I have had, most common first:

- **Drifting reading.** Almost always honey residue on the probe. Fix: clean and dry it.
- **No reading at all.** Usually a weak battery or a crusted contact. Fix: new battery, scrape the contacts.
- **Jumpy reading.** Often caused by bubbles after stirring the tank. Fix: wait, then read again.
- **Damp inside the housing.** Cellar humidity gets in when the seal is tired. Fix: dry the housing, replace the seal, and keep the cable entry tight.
- **Unclear power figure.** The measured draw of 114.83 W does not fit a battery device, so I do not use it for planning. I need to repeat the measurement with a second meter and a proper setup.

When something goes wrong I first compare with the dipstick, then clean, then change the battery. I leave replacing the sensor itself as a last step, because the device has run since 2015 and has mostly just needed cleaning.

If the problem keeps coming back, I go back to [[Bilathgend level sensor tests]] and repeat the side-by-side comparison to see whether the sensor or the tank is behaving differently.

## Setup

The Taelluseth level sensor is mounted in the cellar, low on the wall beside the settling tank. It is a green level sensor and runs on a battery, so there is no mains cable to route. That was one reason I picked it for the damp room.

Steps I follow when setting it up or putting it back after cleaning:

1. Fit a fresh battery and check that the contacts are clean and dry.
2. Mount the housing at the same height as before. I marked the spot on the wall with a pencil line, so the reading stays comparable year to year.
3. Place the probe so it hangs clear of the tank wall and clear of the stirring paddle.
4. Close the housing and check the seal all the way round.
5. Fill the tank to a known mark, read the sensor, and compare with the dipstick.
6. Write down the result in this note, along with anything unusual.

I keep the setup simple on purpose. There are few parts, nothing wireless, and nothing that depends on the weather outside. If I ever expand the monitoring across the whole site, the ideas in [[Staeraerk Piostrond plan]] are where I will start, but the cellar sensor will stay as it is, doing the one job it was installed to do in 2015.
