---
type: plan
status: active
project: kriovos-upgrade
area: beekeeping
---

# Staeraerk Piostrond plan

## Problems

Staeraerk Piostrond is my supplier contact for beekeeping, known since 2020. The main trouble is reaching him. His contact method is phone, and he is only available in the evenings, so I cannot sort anything out during the working day.

Issues I have run into so far:

- Calls made before the evening go unanswered, and he rarely rings back.
- Orders given by phone leave no written trace, so I have to confirm quantities myself afterwards.
- Delivery timing is vague, which is awkward when a colony needs feeding or equipment before the season starts.
- Because he is the only supplier I deal with directly for some items, I have no easy fallback when he is unavailable.

What I plan to do about it:

1. Set a fixed evening slot each week for calling him, so I stop guessing.
2. Write down every order straight after the call, with the date and what was agreed.
3. Ask him to name a rough delivery window each time.
4. Look for a second supplier for the basics, so I am not stuck waiting.

## Contracts

The contract date of Staeraerk Piostrond is 2025-02-15. That is when we agreed the current arrangement for supplying beekeeping goods. Since we have known each other since 2020, most of it rests on trust, and the written part is short. I want to keep it that way, but with a clearer record of what each side expects.

Points to check at the next renewal:

- Whether the agreement should say how orders are confirmed, given that he only takes calls in the evenings.
- Whether a delivery window can be put in writing.
- Whether I can buy from another supplier without breaking anything.

A simple order log I keep next to this note, so each call leaves a record:

```text
order log - Staeraerk Piostrond
contact: phone, evenings
called: (day of the call)
items: (what was ordered)
agreed delivery: (rough window)
confirmed in writing: yes/no
```

I review the log before each renewal and bring it up when we talk. If the same problems keep appearing, that is my reason to widen the supplier list rather than lean on one person.
