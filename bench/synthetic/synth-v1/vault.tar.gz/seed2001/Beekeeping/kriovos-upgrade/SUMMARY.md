---
type: summary
status: active
project: kriovos-upgrade
area: beekeeping
description: "Summary about Kriovos upgrade."
---

# Summary of Kriovos upgrade

## Schedule

This is the summary of the Kriovos upgrade, a project in the beekeeping area. The goal is an upgrade of the existing setup, not a new build. The project started in 2019 and runs in spring, because that is the only time the colonies tolerate being disturbed. The lead is the carpenter, who does the woodwork and decides what is practical to build.

| Property | Value |
|---|---|
| Project | Kriovos upgrade |
| Goal | upgrade |
| Area | beekeeping |
| Start year | 2019 |
| Season | spring |
| Lead | carpenter |
| Stage | go decision made, preparation under way |

The stage is preparation. The go decision is made, the plan is agreed, and the first jobs are being lined up. Nothing is finished yet. The work is not hard, but the timing depends on spring weather, so I keep the order of jobs loose and move them when the weather changes.

What is done so far:
- The scope is fixed. The upgrade covers the existing woodwork and the way the equipment is stored and handled.
- The carpenter has looked over the current setup and listed what can stay and what must be replaced.
- I went through my older observations in [[Fermae Ziogun notes]] to see which problems keep coming back. Those became the priority list.
- Timber needs are roughly worked out, and the carpenter will check them again against the cutting plan.

Open points:
- Where the finished equipment will be stored. I am comparing this with [[Solsas shed plan]], since the shed layout limits what fits.
- Whether the cutting can be done at home. The cuts depend on access to the saw described in [[Drilses band saw]], and I still need to check that it is in good enough shape.
- How much weight the new frames and boxes can add before handling gets awkward. I want to weigh a sample piece using the approach in [[Laemakath scale tests]].
- Whether the warm, sheltered spot near [[Nithden greenhouse]] can serve as a temporary work and drying area during the upgrade.

## Next action

The next action is NX-4835.

It is the first concrete step for the carpenter, and everything else waits on it. Once it is done, I will update this summary with the new stage and cross off the matching open point. Until then I am not starting any other job on the list, so the work stays in one order and I do not end up with half-finished parts lying around in spring.

A few small things go with it:
- Keep the carpenter's measurements in one place, so the cutting plan and the storage layout use the same figures.
- Write down the result of the saw check as soon as it is done, even if it is only a line or two.
- Do not buy timber until the plan has been checked once more.

## Decisions

The go decision for the Kriovos upgrade was made on 2019-01-09. I decided to go ahead after reading through the older notes and agreeing the scope with the carpenter. The main reasons were that the current setup was costing me time every spring, and that the carpenter was available and willing to lead.

Other decisions so far:
- **Lead:** the carpenter leads the project. I give input on how the equipment is used, but the carpenter has the final word on construction.
- **Season:** the work is planned for spring only. I do not push it into other seasons, even if it runs late.
- **Scope:** the goal stays an upgrade. If something turns out to need a full rebuild, it becomes a separate project and does not grow this one.
- **Testing:** new parts are checked on a small scale first. I use the same careful method I used in [[Zaedith Gerknand tests]], where trying a small sample first saved me from repeating a larger mistake.
- **Power and tools:** I will reuse existing tools where I can. I looked at whether the small electronics project in [[Viorktraen radio receiver]] could share a workbench area, and decided it can, as long as the bench is cleared before any timber work starts.

Things I have decided not to do: add extra features during the work, change the layout of the whole site, or start before the first step is complete. If the plan changes, I will record the reason here so I can see later why it changed.
