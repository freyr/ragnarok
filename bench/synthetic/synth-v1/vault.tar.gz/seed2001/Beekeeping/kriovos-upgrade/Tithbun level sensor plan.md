---
type: plan
status: active
project: kriovos-upgrade
area: beekeeping
description: "Plan about Tithbun level sensor."
---

# Tithbun level sensor plan

## Supplies

The Tithbun level sensor is a red level sensor for beekeeping. It runs on mains power and was installed in 2025 in the cellar. Before I work on it again, I want these things ready:

- A spare mains cable that is long enough to reach the cellar socket
- Insulating tape and a few cable ties
- A small screwdriver for the terminal cover
- A power meter to plug in between the socket and the sensor
- A notebook and pen to write the readings down

## Measurements

The plan is to check the sensor in the cellar once the supplies are ready. I will plug the power meter in first and let the sensor run until the reading stops changing. Then I will write down the number and compare it with my earlier notes.

- Measured power draw of Tithbun level sensor: 812.28 W
- Check the cable for heat after an hour of running
- Note whether the cellar damp affects the readings
