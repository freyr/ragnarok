---
type: drivers
status: active
project: sami-retrofit
area: ceramics
description: "Drivers about Sami retrofit."
---

# Drivers of Sami retrofit

## Tools

These are the things I use to keep the Sami retrofit on track. Nothing fancy, mostly paper and a few shared files.

- A paper notebook that lives in the workshop. Every measurement goes in there first, then gets copied into the vault.
- A pipe gauge and a basic pressure test kit for checking joints before anything is closed up.
- A spreadsheet for the budget, with one line per purchase and a running total.
- The kiln log sheets, so I can compare firing behaviour before and after the work.
- A phone camera for photos of every pipe run before it disappears behind a panel.

For the heat side of the job I lean on two earlier notes: [[Zendgla heat exchanger study]] and [[Kesdridaer heat exchanger study]]. Both are worth rereading before any decision on the exchanger. The workshop machinery notes are in [[Glivalsark band saw log]], which I check only to see how much dust and vibration the area has to put up with.

## Open questions

- Is the existing supply line big enough for the new layout, or does part of it have to be replaced?
- Can the drain be rerouted without opening the floor in the glaze room?
- Will the new heat recovery loop make the room too warm in the middle of summer?
- Who signs off on the gas side, and how much lead time does that need?
- Do I keep the old kiln controller wired in as a fallback? The notes in [[Burstimu kiln controller 2019]] say it still works, but it is old.
- How much of the work can the plumber do alone, and where do I need a second person?

## Overview

Sami retrofit is a project with the goal of retrofit. It belongs to the area ceramics. It started in 2025 and runs through the summer season. The lead is the plumber.

This note is the drivers note. It covers why the project exists, what limits it, what it may cost and how I decide whether it worked.

The short version: the ceramics workspace has water, drainage and heat arrangements that grew piece by piece over the years. The retrofit is meant to bring them into one sensible layout, so that firing, glazing and cleaning up all work without the constant small workarounds I put up with today. The plumber leads because most of the work is pipes, drains and heat transfer. The ceramics side supplies the requirements and the plumber decides how to meet them.

### Goal

The goal is retrofit, meaning the existing setup is improved in place, not replaced with a new building or a new workshop. I want:

- Reliable water supply to the glaze and clay areas.
- Drainage that does not push clay slurry into the pipes.
- Waste heat from firing used where it helps instead of being vented.
- Work that can be done in stages, so the workspace is never fully closed.

### Constraints

- The work happens in summer, when the workspace is quieter and doors can stay open.
- The plumber is the lead, so the order of work follows what the plumber can safely do first.
- The building stays as it is. No structural changes.
- Firing schedules for existing commitments cannot be dropped.
- Everything must be documented so that later repairs are not guesswork.

### Success measures

I will call it a success if:

1. All planned lines are in and pass pressure testing without leaks.
2. The drain handles a full cleanup session without clogging.
3. The room is usable during a firing day in summer without being unbearably hot.
4. The final cost stays within the budget below.
5. I can find every pipe run again from my photos and notes.

## Checklist

- [ ] Survey existing pipes and drains and photograph them
- [ ] Reread the two heat exchanger studies and decide on an approach
- [ ] Agree the scope with the plumber in writing
- [ ] Order materials in one batch where possible
- [ ] Protect kilns, shelves and finished work before starting
- [ ] Rough in supply lines
- [ ] Rough in drain with a slurry trap
- [ ] Install heat recovery piece
- [ ] Pressure test everything before closing up
- [ ] Restore the room and clean thoroughly
- [ ] Do a test firing and watch the room temperature
- [ ] Update the notes with what was actually built

## Maintenance

Once the retrofit is done, the upkeep should be simple, but only if I actually do it.

- Empty the slurry trap on a regular schedule, and after any large glazing session.
- Check visible joints for drips each season, especially near the heat recovery piece.
- Flush the drain with plenty of water after cleanup.
- Keep access panels free so nobody has to cut into a wall for a simple check.
- Keep a short log of every repair, with a photo, in the vault.
- Look at the heat loop for scale or sediment once a year.

If the kiln controller is kept as a fallback, test it now and then so it is not a surprise in an emergency. See [[Burstimu kiln controller 2019]].

## Problems

Problems I already know about or have run into while planning:

- The old drain has a shallow fall in one stretch, so slurry settles there.
- Some pipes are hidden and I only have a rough idea of their route.
- Material from earlier fixes is a mix of different types, so connecting old to new may need adapters.
- The room gets hot already on firing days, which is the main reason for looking at heat recovery.
- Dust from the workshop side gets everywhere, which is an issue for open pipework during the job.

## Budget

The budget of Sami retrofit is 32084.89 EUR.

That figure covers materials, the plumber's work and a reserve for surprises. I track it in the spreadsheet with one line per purchase. Rules I set for myself:

- Anything that would push the total over the budget gets discussed with the plumber before it is bought.
- The reserve is only for hidden problems found while opening things up, not for upgrades I decide on a whim.
- Receipts are photographed and filed the same day.
- If the heat recovery part turns out to cost more than expected, I drop optional extras before touching the core supply and drain work.

## Setup

The working setup for the project is straightforward.

- The plumber leads and sets the sequence of work.
- I handle the ceramics side: moving equipment, protecting work, and testing at the end.
- Materials are stored in one corner of the workspace, away from the kilns.
- Work is done in stages by zone, so one part of the room can stay in use while another is open.
- A shared list of tasks is kept next to the notebook so both of us see the same status.

Temporary arrangements: a basin and a bucket system for water during the days the main supply is off, and a plastic sheet barrier against dust.

## Risks

- **Hidden pipework.** Opening a wall or floor may reveal something unexpected. Mitigation: photograph and probe before cutting, and keep the reserve.
- **Cost overrun.** The budget is fixed, so overruns eat into extras. Mitigation: order in batches and review the total weekly.
- **Heat build-up.** If the heat recovery makes the room warmer, working there in summer becomes unpleasant. Mitigation: test on a small firing first.
- **Slurry in drains.** If the trap is badly placed, the new drain clogs like the old one.
- **Schedule slip.** Summer is short and the plumber may be on other jobs. Mitigation: agree dates early.
- **Dust and damage to ceramics.** Cover everything and keep finished work out of the room.
- **Reliance on an old controller.** If the old kiln controller fails during the works, firings stop. See [[Burstimu kiln controller 2019]].

## Background

The workspace in ceramics has been in use for years and was never planned as a whole. Water came first, then a sink, then a drain extension, then a kiln. Each step was reasonable at the time, but the sum is awkward.

The idea of a retrofit came from the repeated trouble with the drain and the heat in the firing room. I read about heat recovery and wrote up what I found in [[Zendgla heat exchanger study]] and [[Kesdridaer heat exchanger study]]. Those notes compare approaches and are the basis for the plan here.

The project is set for 2025, in the summer season, and the plumber is the lead because the central work is plumbing. The area is ceramics, and the goal is retrofit, meaning improvement of what is there.

I also looked at how the workshop equipment behaves, using [[Glivalsark band saw log]], mainly for dust and vibration. It is a side concern, but it affects how I protect the pipework during the job.

## Schedule

The project is planned for the summer of 2025. Rough order:

1. **Early summer:** survey, scope agreement, ordering materials.
2. **Early to mid summer:** supply and drain rough-in, zone by zone.
3. **Mid summer:** heat recovery installation and pressure tests.
4. **Late summer:** closing up, cleaning, test firing, final notes.

I keep the plan loose on purpose. The plumber's availability and the delivery of materials decide the real dates, and I would rather move a stage than rush it. Stages that depend on a passed pressure test are never started before the test.

## Observations

Notes so far, from walking the space and from past use:

- Water pressure seems fine at the main sink but weaker at the far end of the room.
- Slurry builds up fastest after glazing days and after cleaning of large buckets.
- The firing room is noticeably warmer than the rest of the workspace for hours after a firing ends.
- The dust from the saw area drifts further than I expected.
- The plumber prefers fewer, larger decisions to many small ones, so I bring a short list to each visit.
- Photos taken before work are far more useful than my memory of where things ran.

## References

- [[Zendgla heat exchanger study]]
- [[Kesdridaer heat exchanger study]]
- [[Burstimu kiln controller 2019]]
- [[Glivalsark band saw log]]
