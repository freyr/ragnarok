---
type: plan
status: active
project: sami-retrofit
area: ceramics
---

# Krespa shed plan

## Background

Krespa shed is a shed that I use for ceramics work. It was built in 2021, and it is a large building. The floor is below ground, so the whole space sits lower than the yard around it. The orientation is north, which means the main wall faces north and the room stays cool through most of the year.

The cool, steady temperature is the main reason I chose this place for clay work. Wet pieces dry slowly and evenly, and I see fewer cracks than I did when I worked in a warmer room. The downside is damp. A below-ground floor holds moisture, so I need to watch the air and keep tools off the floor.

This plan covers what I want to keep in order and what I want to check each season.

- Kind: shed
- Area: ceramics
- Orientation: north
- Size: large
- Year built: 2021
- Floor: below ground

## Equipment

The one device I track here is the Triondfis kiln controller. It is the installed device of Krespa shed, and it runs the firing cycles for the kiln. I treat it as the most important piece of equipment in the room, because a bad firing wastes a lot of work and time.

Things I plan to do:

- Check the controller wiring and the display before each firing season.
- Keep the controller dry, since the floor is below ground and damp air can reach it.
- Write down each firing program in my notebook, so I can repeat a good result.
- Leave clear space around the kiln for air and for safe walking.
- Keep a small fan and a dehumidifier ready for damp weeks.

If the controller ever acts strangely, I will stop the firing, let the kiln cool, and look at the connections before trying again.
