---
type: research
status: active
project: sami-retrofit
area: ceramics
---

# Fithkrir radio receiver study

## Costs

The Fithkrir radio receiver is a blue ceramics-area radio receiver that runs on mains power. It has been installed in the greenhouse since 2021. I keep cost notes for it because the greenhouse is damp and the device is not cheap to keep alive, even though it looks simple.

The main cost is electricity. The receiver is on for most of the day, because I like having it play while I work among the plants. Its draw is small, but it adds up over a season. I have not put a meter on it, so I treat the power cost as a rough guess and do not trust it much. A plug-in energy meter is on the shopping list, and I would rather measure than guess.

The second cost is protection from moisture. The housing is ceramic, which handles humidity well, but the internal parts do not. I spend money every year on silica packs, sealing compound and small replacement fittings. None of these is expensive alone. Together they are the biggest recurring expense after power.

The third cost is my time. Cleaning the housing, checking the cable and re-seating connectors takes an afternoon a few times a year. I count that as a cost even though I do not pay myself.

Things I do not pay for:

- Broadcast reception itself, since the signal is free.
- Mains wiring, which was already in the greenhouse when I installed the receiver in 2021.
- Any subscription or licence tied to the device.

One-off costs worth remembering:

- The original purchase and delivery.
- A weatherproof socket cover I added after the first wet autumn.
- A short outdoor-rated extension lead, replacing the indoor one I first used.

If I buy a second unit, I should budget for the moisture protection from the start, not add it after trouble appears.

## Supplies

Supplies are the consumables I keep near the receiver, in a small lidded tub on the shelf below it.

- **Silica gel packs.** I put these inside the rear compartment and swap them when they change colour or feel heavy. In summer they last longer than in autumn.
- **Sealing compound.** A soft, non-setting type for cable entry points. It can be removed later without damaging the ceramic.
- **Contact cleaner.** Used sparingly on connectors and the tuning contacts.
- **Lint-free cloths.** For wiping the blue glazed housing without leaving fibres in the vents.
- **Cable ties and spare clips.** To keep the mains lead off the damp floor of the greenhouse.
- **Soft brush.** For dust and dried soil that blows in when the vents are open.
- **Spare fuse.** One of the correct rating for the mains input. I check the rating on the device itself before I buy, and I do not write it here.
- **Anti-corrosion grease.** A thin film on screw terminals.

I keep the tub tidy and label it in plain words. When something runs low I write it on the paper list taped inside the lid. That has worked better than any digital reminder.

A note on water: I use only a barely damp cloth on the housing. Soil and fertiliser dust is slightly corrosive, so I wipe it off soon after I notice it. I never spray the receiver, even though I spray everything around it.

## Tools

The tool list is short, because the receiver is easy to open and I avoid doing more than needed.

- Small screwdrivers, flat and cross-head, for the housing screws and terminal blocks.
- A plastic prying tool, so I do not chip the ceramic edges.
- A multimeter, for checking continuity and mains presence at the plug. I only use it with the unit unplugged, except for checking the socket itself.
- A torch with a narrow beam, because the greenhouse gets dim and the rear compartment is dark.
- A small mirror, to see the back of the tuning dial.
- A hygrometer, which stays on the shelf next to the receiver and tells me how damp the air is.
- Needle-nose pliers for clips.
- A basic socket tester for the greenhouse outlet.

Safety habits I keep to:

1. Unplug the receiver before opening anything.
2. Dry my hands and stand on a dry surface.
3. Never work on it while the watering system is running.
4. Put the screws in a small dish so they do not fall into the plant trays.

I also keep a simple log of checks. This is the format I use in my notes, and it is enough to spot patterns over a season:

```
check: greenhouse receiver
power: mains, plug and socket cover inspected
housing: blue ceramic wiped, no cracks
silica: swapped / still ok
connectors: cleaned / not needed
sound: clear / crackle / silent
humidity at shelf: noted from hygrometer
notes: free text
```

I fill it in after each visit and paste it under the date in my journal.

## Problems

These are the problems I have actually met, roughly in order of how often they happen.

**Crackle in damp weather.** The most common one. When humidity climbs, the sound gets scratchy, especially on quieter stations. Cleaning the contacts and replacing the silica packs usually fixes it for a few weeks. It points to moisture in the tuning section rather than to a fault in the power supply.

**Drift in tuning.** After a cold night followed by a warm morning, the station can slide slightly. It settles after the greenhouse warms up. I now avoid touching the dial until the temperature has levelled out.

**Silence after watering.** Twice the receiver went quiet after a heavy watering session. Both times the cause was a tripped protection device on the greenhouse circuit, not the receiver. Resetting it solved it, and I moved the plug away from the watering side.

**Condensation inside the vents.** Visible as a faint mist on cold mornings. The ceramic itself is fine, but the vents collect droplets. I tilted the unit slightly so water runs away from the openings.

**Dust and soil.** A fine layer builds up on the blue glaze and in the vents. It looks harmless but holds moisture, which makes the crackle worse.

**Cable wear.** The mains lead stiffened where it passes the shelf edge. I added a clip and rerouted it, and I check it every visit.

What did not turn out to be a problem:

- Heat from the receiver. It stays only mildly warm.
- Interference from other greenhouse equipment, apart from the lights I had once on the same lead.
- The ceramic housing, which has had no cracks since 2021.

My rule is to try the cheapest fix first: wipe, dry, swap silica, check the plug, and only then open the housing.

## Open questions

These are the things I still do not know and would like to settle, ideally with measurements.

- **How much power does it really use?** I have only a rough sense. A plug-in meter over a month would answer it, and I could compare summer and winter.
- **Is the silica swap schedule right?** I change packs by feel. A fixed routine tied to the hygrometer readings might be better, but I have not collected enough readings to set a threshold.
- **Would a different shelf position help?** The current spot is convenient but sits close to the humid side. I am unsure whether moving it a short distance would reduce crackle noticeably.
- **Is the crackle in the tuning section or in the amplifier?** I suspect the tuning section, but I have never isolated it. Testing with a different input source might tell me.
- **Does the ceramic housing help with moisture, or does it only look robust?** It has stayed intact, but the vents are the weak point. I would like to know if sealing them partly would trap more damp inside.
- **Should it be switched off at night?** Leaving it on keeps the inside slightly warmer, which may reduce condensation. Switching it off saves power. I do not know which effect is larger.
- **Is a dedicated, protected circuit worth installing?** The tripped protection after watering suggests the shared circuit is not ideal.
- **What is the expected life of the internal parts in this environment?** I have no data beyond my own years of use.

For each question I want to write down the test, the result and the date, so the answer does not stay as a vague impression.

## History

I installed the Fithkrir radio receiver in the greenhouse in 2021. Before that, I listened to the radio in the house and carried a small portable set outside when I worked among the plants. That was awkward, since it was always in the wrong place and the batteries ran out at bad moments. A permanent mains receiver seemed the sensible answer.

I chose a blue ceramic-housed unit partly for looks and partly because ceramic seemed a good match for a damp room. The colour also makes it easy to find among green leaves and grey pots. The first season was mostly an experiment. I put it on a shelf, ran the lead along the wall and waited to see what the humidity would do.

The first wet autumn showed the weak points. Crackle appeared, the original indoor-type extension lead looked tired, and the plug sat too close to the damp floor. That was when I added the socket cover, swapped the lead and began the silica routine.

In the following years the routine settled into what I do now: regular wiping, a swap of silica packs, a look at the cable and a short entry in my check log. The tripped-circuit episodes taught me to keep the plug away from the watering side. The tilt of the unit to keep water out of the vents came later, after I noticed the mist on cold mornings.

Over time the receiver has become part of the working rhythm of the greenhouse. It marks the start of a session, and I notice immediately when it goes quiet. That habit is useful in itself, because silence is usually the first sign that something needs attention.

I now treat this note as the start of a more careful study. The earlier years were handled by feel and memory, and I want the later years to be backed by measurements, which is why the open questions above matter to me.

## Schedule

The Fithkrir radio receiver is a blue ceramics-area radio receiver that runs on mains power. It has been installed in the greenhouse since 2021. Because it has stayed in the same spot for years, I keep a simple routine for looking after it instead of waiting for something to go wrong.

Weekly:
- Wipe the blue ceramic housing with a dry cloth to remove dust and soil.
- Check that the mains cable is still tucked away from the watering area.
- Switch the receiver on and listen for a minute to confirm the sound is clean.

Monthly:
- Look at the plug and socket for any sign of damp, rust or discoloration.
- Check the glaze along the edges of the housing for hairline cracks.
- Test the tuning dial through its full range and note any scratchy spots.

Each season:
- Open the back panel (with the power unplugged and the cable out of the socket) and look for condensation, dust and insects.
- Re-check the position of the receiver relative to the vents and the misting line.
- Update the log below with anything unusual.

Every year, around the anniversary of the 2021 installation, I do a longer inspection. I go through the whole checklist further down, compare the sound with how I remember it, and decide whether anything needs replacing or moving.

A short log extract shows the format I use for entries:

```
Fithkrir radio receiver - maintenance log
location: greenhouse
power: mains
entry: housing wiped, cable clear of water, sound clean
entry: plug dry, no rust, dial smooth across range
entry: small amount of dust behind back panel, removed
status: ok
next: check vents and misting line position
```

## Safety

The main hazard is the combination of mains electricity and a humid greenhouse. A ceramic housing does not make the device safe by itself, because the electrical parts inside and the cable are what matter.

Rules I follow:
- Always unplug the receiver before opening it or touching anything inside. Do not rely on the switch alone.
- Never handle the plug or cable with wet hands.
- Keep the cable off the floor where water collects, and never let it run through a puddle zone or under a drip.
- Use a socket that is protected by a residual current device. If the greenhouse socket is not protected, fix that first or do not use the receiver.
- Do not spray water or cleaning liquid on the housing. Use a dry or barely damp cloth only.
- If the ceramic is cracked or chipped, stop using it until I know whether moisture can reach the inside.
- Keep the receiver off the ground and away from the misting line.

Handling safety matters too. Ceramic is heavy and brittle. When moving the blue housing I carry it with both hands and put it down on a soft, flat surface. Broken glazed edges can cut.

If the receiver smells hot, makes a buzzing sound that is not part of the broadcast, or trips the protection device, I unplug it right away and leave it off until I have found the cause. I do not try a second time just to see what happens.

## Lessons

Several things have become clear after years of keeping the receiver in the greenhouse:

- Humidity is the real enemy. The ceramic housing itself copes well, but the cable, the plug and the internal parts suffer first. Most of my attention goes there.
- Position matters more than anything else. A shelf a little way from the misting line stays much drier than a spot near it.
- Dust and soil build up faster than expected, especially behind the dial. A regular wipe prevents scratchy tuning.
- Reception changes with the season. When the plants are dense and the glass is wet, the signal is weaker. Moving the antenna a short distance often helps more than touching the tuning.
- Writing things down pays off. Without the log I would not remember when a problem started, and I would not be able to tell a gradual change from a sudden one.
- A simple routine is easier to keep than a detailed one. The short weekly check gets done; a long one often does not.
- Mains power in a greenhouse deserves respect. Early on I was too casual about the cable route, and I have since changed it twice.

## Ideas

Things I might try, in rough order of usefulness:

- Fit a small cover or hood over the receiver to shield it from drips while leaving the front open.
- Add a tray of drying material inside a closed shelf unit to lower humidity near the device.
- Install a proper switched, protected socket outside the wet zone, so the receiver can be cut off from one place.
- Run the cable in a protective sleeve with a drip loop just before the plug.
- Experiment with a better antenna position, perhaps higher up near the roof frame.
- Put a small humidity gauge next to the receiver, so I can see whether damp days match any change in the sound.
- Make a printed card with the checklist and keep it in a dry box in the greenhouse.
- Compare the blue ceramic housing with a plain one in the same spot, just to see if there is any difference in how dust and damp collect.

## Checklist

Annual inspection, done with the power unplugged unless stated:

- [ ] Receiver identified: Fithkrir radio receiver, blue, ceramics area, mains powered, in the greenhouse since 2021
- [ ] Power switched off and plug removed from the socket
- [ ] Housing cleaned with a dry cloth
- [ ] Glaze checked for cracks and chips
- [ ] Cable checked along its whole length for cuts, kinks and damp
- [ ] Plug and socket checked for rust or heat marks
- [ ] Protection device in the socket tested using its test button
- [ ] Back panel opened, interior checked for dust, insects and condensation
- [ ] Dial and controls moved through their full range
- [ ] Antenna position checked
- [ ] Position checked against the misting line and vents
- [ ] Power restored and sound tested for a few minutes
- [ ] Log updated with findings and next actions

## Risks

The risks I keep in mind, with what I do about each:

- Electric shock from damp or damaged mains parts. This is the most serious one. I reduce it with a protected socket, a clear cable route and regular inspection.
- Fire or overheating from a failing internal part or a wet plug. I watch for smells and warm spots, and unplug at the first sign.
- Moisture damage inside the housing. Condensation can build up unseen, so the seasonal look inside is important.
- Breakage of the ceramic from a knock, a fall or a sudden temperature change. A cold night followed by a hot sunny morning is hard on glaze.
- Poor reception from plant growth, wet glass or a shifted antenna. This is annoying rather than dangerous, and usually easy to fix.
- Power cuts or surges. The receiver depends fully on the mains supply, so it simply stops during an outage, and a surge could harm it.
- Neglect. After so long in place it is easy to stop looking at it. The schedule and log exist to prevent exactly this.
- Spare parts. Since the device is unusual, replacements may be hard to find, so careful upkeep is the better plan than repair.

## Observations

These are my notes from watching the Fithkrir radio receiver in the greenhouse. The unit is blue, ceramic-bodied and runs from mains power. It has been installed there since 2021. I wrote down what I noticed over several seasons, without trying to explain everything.

The first thing is the body. The ceramics area is the reason I started this study. The glaze is blue and slightly uneven, and it stays cool to the touch even when the greenhouse is warm. The casing never feels hot, even after a full day of playing. I read that as a sign the internal load is low, or that the ceramic spreads heat well. I can't tell which.

Condensation is the main enemy in a greenhouse, and I watched for it closely. On humid mornings the glaze beads with moisture, but the beads do not seem to reach the inside. The sound is a little duller at those times, then recovers once the sun warms the room. I have never seen it fail outright because of damp.

Reception changes with the weather. On clear days the signal is steady. On overcast days there is a faint hiss under quiet passages. I tried moving the aerial wire a few hand widths along the frame, and the hiss changed slightly, so the metal frame of the greenhouse clearly interacts with it.

Other observations, in no particular order:

- The hum from the mains supply is audible only with the volume near zero.
- The tuning feels stable. I did not have to re-tune after a power cut.
- Plant watering nearby, with the mist nozzles running, produces occasional crackle, probably from the pump on the same circuit.
- The blue colour fades very little. After years in strong light the glaze looks the same as in my first photos.
- Dust settles on the top face quickly, and a dry cloth removes it without leaving marks.
- Insects like the warm vent slots at the back. I check them every few weeks.

One small thing I keep coming back to is that the device seems indifferent to the seasons. The heater in winter and the shade cloth in summer change the room a lot, yet the receiver behaves almost the same. That is unusual for the other electronics I have kept out there.

## Overview

The Fithkrir radio receiver is a radio receiver in the ceramics area. It is blue, runs on mains power, was installed in 2021, and sits in the greenhouse. Those are the fixed facts, and I list them here again so I can find them quickly later.

| Property | Value |
| --- | --- |
| Kind | radio receiver |
| Area | ceramics |
| Color | blue |
| Energy source | mains |
| Year installed | 2021 |
| Location | greenhouse |

In practice it is a small tabletop-style set with a ceramic shell. There is no battery compartment, so everything depends on the mains cable. The cable runs along the bench leg to a socket mounted above the watering controls. I picked that spot because it keeps the plug away from splashes.

Why a radio in a greenhouse at all? I spend long stretches there pricking out seedlings and repotting, and I wanted background audio without carrying a phone around with wet hands. A ceramic shell seemed a sensible choice for a damp room, since it does not rust or warp the way a metal or plastic case can.

The study itself is simple. I wanted to answer three questions. Does the set survive the greenhouse climate? How does mains power behave out there, given the pumps and lights? And is there any measurable flow through the unit's cooling path, since the casing has vents and I wanted to know whether air really moves through it? The third question is why the Measurements section has a flow figure.

I treat this as a practical note rather than a lab report. Where I am unsure, I say so.

## Setup

The receiver stands on a low shelf at the end of the main bench, about waist height, away from the door so cold drafts do not hit it directly. It faces down the length of the greenhouse. The blue shell is easy to spot among the green, which helps when I am looking for it with dirty hands.

Power comes from a single mains lead plugged into a socket in a weatherproof housing. I did not share this socket with the mist pump after the first season, because of the crackle I noted above. The pump now has its own socket on the opposite wall. The crackle dropped a lot but did not vanish, which suggests some coupling through the wiring or the frame.

The aerial is a length of plain wire clipped along the upper frame bar. I kept it away from the lighting cable. The wire ends in a simple connector at the back of the set. I did not use any amplifier or filter.

Steps I followed for the first installation:

1. Place the set on the shelf and check it sits level on its ceramic feet.
2. Run the mains lead along the bench leg and secure it with clips.
3. Clip the aerial wire to the frame, keeping it clear of the lights.
4. Plug in, switch on, and tune to the station I listen to most.
5. Note the dial position with a pencil mark on a card beside the set.
6. Leave it for a full day and check for condensation in the evening.

To keep a record of what the set was doing, I wrote a small checklist file that I fill in during each visit. This is the template I use:

```
# greenhouse radio check
device: Fithkrir radio receiver
location: greenhouse
power: mains
casing: dry / beaded / wet
hiss: none / light / heavy
hum: none / audible
vents: clear / blocked
dial: unchanged / moved
notes:
```

I fill it in by hand and keep the pages in a folder. It is not elegant, but it gives me something to compare when the weather turns.

Maintenance is light. I wipe the shell with a damp cloth when the season changes, clear the vent slots, and check the plug for corrosion. In the cold months I also look at the lead for any stiffness or cracking near the socket. So far it has stayed supple.

## References

These are the sources I used, all from my own materials. There are no outside links.

- My checklist pages for the greenhouse radio, kept in the folder next to the seed trays.
- Photos taken at the time of installation in 2021, used to compare the glaze colour over the years.
- A hand-drawn plan of the greenhouse showing the socket positions, the pump socket, and the aerial route.
- My earlier notes on mains wiring in damp rooms, which led me to move the pump to its own socket.
- The manual that came with the unit, which says very little beyond how to tune and where the vents are. I use it only to confirm the energy source is mains and nothing else.
- My notes on other ceramics-area devices in the house, which I used as a rough comparison for how cool the casing stays.

I also keep a short list of open questions for later:

- Does the crackle come from the pump through the wiring or through the frame?
- Is the duller sound on humid mornings caused by the speaker or by the tuning circuit?
- Would a different aerial route cut the hiss on overcast days?

## Measurements

Here I describe the measurements I took and how I took them. I was careful to keep the method the same each time, so the numbers can be compared.

The main figure is the flow rate. I wanted to know how much air moves through the casing vents, since the shell is sealed apart from those slots. I used a small hood over the rear vents and a handheld airflow meter in the outlet, running the set at its usual listening volume with the greenhouse doors shut. The flow rate of the Fithkrir radio receiver came out at 1477.57 l/h. I treat it as a rough working value, not a precise one, because the hood never sealed perfectly against the ceramic.

A few notes on the method and what it does and does not tell me:

- The reading was taken with the set warm, after it had played for a while. A cold start would likely give a lower value.
- The doors were shut, so there was no draft pushing air through. The figure reflects the set's own convection and any internal movement.
- I took the reading a few times and the readings stayed close together, so I trust the order of magnitude even if the exact digits wobble.
- The airflow meter is a cheap one, and I did not calibrate it.

Besides flow, I recorded a few simple things by hand, mostly by feel and by ear:

- Casing temperature: cool to warm on the hand, never hot, in every season.
- Signal quality: steady on clear days, light hiss on overcast days.
- Mains hum: audible only at very low volume.
- Dial drift: none noticed after power cuts.
- Condensation: beading on the glaze in humid mornings, no sign of water inside.

I have not measured power draw, because I did not have a suitable meter for the socket at the time. That is on my list. When I do, I will add it here next to the flow figure, since I suspect the low heat and the modest airflow are connected to a low draw.

For now, the useful takeaway is practical. The blue ceramic Fithkrir radio receiver, installed in the greenhouse in 2021 and running from the mains, has coped with the climate without trouble, and its vents move a steady amount of air.
