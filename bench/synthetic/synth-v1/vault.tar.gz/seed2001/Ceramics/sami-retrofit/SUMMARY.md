---
type: summary
status: active
project: sami-retrofit
area: ceramics
description: "Summary about Sami retrofit."
---

# Summary of Sami retrofit

## Maintenance

Sami retrofit is a project with the goal of a retrofit, in the ceramics area. It started in 2025, in the summer season, and the lead is the plumber. This summary note tracks where the project stands, what is finished, what is still open and what comes next.

The stage right now is the middle of the work. The planning is done and the main decisions are made. The physical work has started, and the plumber is running it. I keep this note short on purpose, so I can read it in a minute and know what to do.

What is done so far:

- The old layout was surveyed and written up.
- The plan for the new pipe runs was agreed with the plumber.
- The first round of checks on the kiln-side equipment was completed.
- The notes from [[Koguni Vopa]] were read and folded into the plan.

What keeps the project in good shape from week to week:

- Keep the work area clear so the plumber can get to the pipes without moving ceramics stock.
- Check the open points list at the end of every working session.
- Write down any change to the plan the same day, so the note does not drift from reality.
- Keep the [[Saenber band saw handbook]] nearby, since the cutting of boards and supports follows it.

Open points are mostly about timing and about checking the equipment after it is installed. None of them blocks the next step. I review them whenever I update this note, and I drop an item only when I have seen it finished with my own eyes.

## Next action

The next action of Sami retrofit is NX-6196.

I want to do this before anything else, because the later steps depend on it. It is small enough to finish in one session. Before I start, I will talk to the plumber, confirm the access to the work area and make sure the tools are ready. When it is done I will update the checklist below and write one line about how it went.

If something blocks it, I will not skip ahead. I will note the problem here, tell the plumber, and pick the next smallest thing that does not depend on it.

## Costs

I do not keep exact prices in this note. The detailed figures live in my own accounts, and this section only describes how the costs are organised and what I watch.

The main cost groups are:

- The plumber's time, which is the largest part, since the plumber leads the project.
- Pipes, fittings and valves for the new runs.
- Materials for supports and boards.
- Small consumables such as sealant, tape and cleaning supplies.
- A reserve for surprises, because an old ceramics workshop always hides some.

The costs that worry me most are the ones that grow when work is delayed. A longer job means more of the plumber's time and more days with the workshop partly out of use. For that reason I prefer to finish each step fully rather than leave several steps half done.

The pump choice is also a cost question. The reading in [[Tangio circulation pump study]] helps me compare running cost against purchase cost, and I lean toward the option that wastes less energy over the years, as long as it fits the budget I set at the start.

I review the cost picture once per stage, not every day. If a group clearly goes over what I expected, I write it here and decide whether another group can give something back.

## Decisions

The go decision date of Sami retrofit is 2026-09-10. That is the day I confirmed the project would go ahead in the form described here, with the plumber as lead.

Other decisions that shape the work:

- The plumber leads the project, and I act as the person who keeps the notes and supplies access.
- The retrofit stays within the ceramics area and does not expand into other parts of the building.
- The schedule follows the plan in [[Gaerkbaend Baengal plan]], and I only change it when there is a clear reason.
- Test results from [[Genketh Vorkdios tests]] decide whether a part of the system is accepted or reworked.
- Questions about suppliers and contacts go through [[Serpi Muntran]] first, so there is one place for that thread.

When I make a new decision, I write what I decided, why, and what I gave up by choosing it. That helps later when I forget the reason and wonder whether to change course.

I try not to reopen a decision unless something material has changed, such as a failed test or a supplier problem. Doubts alone are not enough. I write them down and look at them again after the next step is finished.

## Checklist

Use this list at the start and end of each session.

- [x] Project goal, area, season and lead are written down.
- [x] Go decision recorded.
- [x] Plan for the pipe runs agreed with the plumber.
- [x] Early reading and notes folded into the plan.
- [ ] Next action carried out and noted.
- [ ] Equipment tests run and results compared with the plan.
- [ ] Pump choice confirmed.
- [ ] Work area cleaned and ceramics stock moved back.
- [ ] Final walk-through with the plumber.
- [ ] Project note closed and lessons written down.

After each tick, I add a short line in the project log with what happened, so the summary stays honest. If more than two items stay open for a long time, I treat that as a sign that the plan needs a look, and I go back to the decisions section to see what has changed.
