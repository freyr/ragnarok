---
type: note
status: active
project: sami-retrofit
area: ceramics
description: "Note about Glaendfior solar charger."
---

# Glaendfior solar charger notes

## Background

These are my own notes on the Glaendfior solar charger. It is a solar charger, and I file it under the ceramics area because I bought it while I was setting up the kiln corner and the small studio around it. It is grey. It runs from a battery as its energy source, which means the panel feeds a battery and the battery feeds whatever I plug in. I installed it in 2016 and it lives in the loft, where the roof gets the most light.

I keep this note so that I do not have to rediscover the same things every few months. The charger is not complicated, but it has habits. I wrote down what I learned, what went wrong, and what I would do differently. Nothing here is official. It is just what I have seen over the years in my own loft.

Quick facts, so they are in one place:

- Kind: solar charger
- Area: ceramics
- Color: grey
- Energy source: battery
- Year installed: 2016
- Location: loft

The reason I wanted a solar charger in the loft at all was simple. The loft has no convenient socket near the work table, and I did not want a cable running down the stairs. I use the loft for drying small pieces, sorting glazes, and storing tools. A few small things there need power: a work light, a small radio, a handheld scale with a display, and sometimes a phone. The charger handles all of that.

The grey casing has held up well. It is a dull, matte grey, and dust does not show on it much, which is useful in a room where clay dust is everywhere. The colour has not faded noticeably since 2016, though the side facing the skylight is slightly chalkier than the other side.

## Checklist

This is the list I run through when I check the charger. I do it at the start of each season and after any long spell of bad weather.

- Look at the casing for cracks, swelling, or any warm spots.
- Wipe the panel surface with a damp cloth, then dry it.
- Check that the cable connections are snug and not green or white at the contacts.
- Press the status button and see that the indicator comes on.
- Plug in the work light and see that it runs for a few minutes without flicker.
- Check that nothing is stacked against the charger, especially boxes of glaze powder.
- Look at the floor around it for dust, water marks, or drips from the roof.
- Make sure the vents, if any, are clear.
- Note the date and anything odd in the observations section below.

If any of these fails, I stop and fix it before using the charger for anything else. A flickering light is usually a loose connection, not a dead battery.

## Measurements

I do not have lab equipment. My measurements come from a basic meter, a kitchen timer, and some patience. The one figure I recorded that is worth keeping is the flow rate.

- Flow rate of Glaendfior solar charger: 1227.94 l/h

I know a flow rate is an odd thing to quote for a charger. I recorded it in connection with the small cooling fan that I run from it when the kiln corner gets warm, and I keep the figure for comparison. If the fan seems weak, I compare it against this number by eye and by feel, since I cannot measure it exactly again without borrowing equipment.

Other things I measure in a rough way:

- Running time of the work light on a full battery: usually a long evening, and I stop well before it runs flat.
- Time for the battery to recover on a clear day: most of a day, so I plan for that.
- Time for the battery to recover on a dull day: it barely gains, so I do not count on it.
- Temperature in the loft: it swings a lot, from cold mornings in winter to very warm afternoons in summer.

I write these as habits rather than precise numbers. What matters to me is the pattern: how the charger behaves across a week, not one exact reading.

## Setup

The charger sits on a low wooden shelf under the skylight. I picked the spot for three reasons: it gets direct light for the longest part of the day, it is away from the kiln corner so heat does not reach it, and I can reach it without moving anything.

How it is arranged:

1. The grey unit stands on the shelf, with the panel angled toward the skylight.
2. A short cable runs from the unit to a small power strip hooked to the shelf edge.
3. The work light, radio, and scale plug into that strip as needed.
4. A cloth sits under the unit to catch dust and stop it sliding.
5. A label on the shelf says what is plugged in by default, so I do not guess.

I installed it in 2016 and have changed very little since. The shelf was replaced once because the old one warped in the heat. The cable was replaced once because the sheath cracked near the plug. Everything else is original.

If I had to set it up again from nothing, I would:

- Pick the spot first, with the light in mind, before buying a shelf.
- Keep cables as short as possible.
- Leave a gap behind the unit for air.
- Keep a spare cable in the drawer nearby.
- Take a photograph of the finished arrangement so I can restore it after cleaning.

## Ideas

Some things I might try, none urgent.

- Add a small mirror or a sheet of pale board near the panel to bounce extra light onto it in the afternoon.
- Build a simple cover that I can flip down over the panel in the dustiest weeks when I am sanding or mixing dry glaze.
- Put a small hook beside the shelf for the cable so it does not hang loose.
- Use a plain notebook next to the charger, so I can log checks without coming back to the computer.
- Mark the shelf with tape where the unit should sit, so I can put it back in exactly the same place.
- Try a small timer on the fan so it only runs when the loft is warm.
- Look into a second battery of the same kind, to give a longer evening of work in summer.
- Move the radio to a different socket so the light always has priority.

Of these, the cover and the tape marks are the most likely to happen, because they cost almost nothing.

## Observations

Things I have noticed over the years, in no special order.

- The charger works best on clear, cold days. Very hot days seem to make it sluggish, which is the opposite of what I expected.
- The indicator takes a moment to come on after pressing the button. I used to think it was broken. It is just slow.
- Dust builds up on the panel faster in autumn, when I am doing more glaze work.
- A faint smell of warm plastic appears if I leave it plugged into too many things at once. I now keep the load small.
- The grey casing is warm to the touch after a sunny afternoon but never hot.
- The battery holds charge well overnight if I do not leave the light on.
- Rain on the skylight makes the loft dim enough that the charger does very little.
- Birds sometimes sit on the roof above, and their shadows cause small flickers in the panel output. It is harmless.
- After a long winter, the first sunny week brings it back to normal quickly.
- The work light is the biggest drain. The radio and the scale hardly matter.

One pattern is worth stating plainly: the charger does what I need as long as I treat it as a small, slow, dependable thing rather than a power source for anything heavy.

## Risks

The main risks I have thought about:

- **Heat.** The loft gets hot in summer. A battery in a hot space ages faster, and in the worst case it could swell. I keep the unit out of direct kiln heat and check the casing for any bulging.
- **Fire.** Dry glaze powder, paper, and wooden shelving are all in the loft. A faulty battery near those is a real concern. I keep the area around the charger clear.
- **Dust.** Fine clay and glaze dust can get into connectors and cause poor contact.
- **Moisture.** A leak in the roof could drip onto the unit. I check the ceiling above the shelf every season.
- **Overloading.** Plugging in too many items makes the unit warm and shortens its life.
- **Age.** It has been in place since 2016. Any battery that old is on borrowed time, and I should plan for replacement rather than wait for it to fail.
- **Trips and snags.** Cables across the floor can catch a foot, and the stairs are right there.

None of these has caused trouble so far, but the age of the battery is the one I think about most.

## Overview

The Glaendfior solar charger is a grey, battery-based solar charger that I installed in the loft in 2016. It belongs to my ceramics area because it supports the small studio work I do up there: light, a little sound, a scale, and the occasional phone top-up.

In short:

- It is simple to use and has needed very little attention.
- It does best with light loads and clear weather.
- It needs a regular wipe and a regular look.
- Its age is the main long-term concern.
- The spot under the skylight remains the right place for it.

If someone asked me whether it was worth it, I would say yes, with the condition that expectations stay modest. It was never going to run a kiln or a heater, and I never asked it to. For the small jobs in the loft, it has done the work for many years without fuss.

## Problems

Problems I have actually had, and what I did about them.

1. **Flickering light.** The work light flickered one winter. The cause was a loose plug in the power strip. I pushed it in fully and added a bit of tape to hold the strip against the shelf.
2. **Cracked cable.** The sheath near the plug split. I replaced the cable and now check that spot each season.
3. **Warped shelf.** The original shelf bent in the summer heat and the unit tilted. I replaced it with a thicker board.
4. **Weak output after a dusty month.** The panel was coated in fine glaze dust. A damp cloth fixed it at once.
5. **Slow indicator.** I assumed a fault, but it was just slow. No action needed.
6. **Warm casing with too many devices.** I reduced the load and the warmth went away.
7. **Drip from the roof.** One wet autumn a drip landed near the shelf. I moved the unit slightly and had the roof patched.

Unsolved: I do not know how much capacity the battery has left. I can only judge by how long the light runs in the evening, and that has slowly become shorter.

## References

Nothing formal. I do not have a manual that I trust, so my references are mostly my own records.

- My own checklist above.
- The label on the shelf listing what is plugged in.
- The photograph of the finished arrangement, kept in the ceramics folder.
- Notes in this knowledge base about the loft and the kiln corner.
- The receipt and the installation record from 2016, kept in the studio paperwork box.
- Advice from a neighbour who also keeps a small solar setup in a shed. He suggested keeping loads small and cleaning the panel often, which matches what I found.

If I ever find a trustworthy guide, I will add it here. Until then, my own observations are the best source I have.

## Lessons

What I would tell myself if I were starting again.

- Choose the position for the light, not for convenience.
- Keep the loads small. The charger is happiest when it is not pushed.
- Clean the panel more often than feels necessary.
- Keep flammable material away from any battery, always.
- Replace cables when they first show wear, not when they fail.
- Do not trust the indicator speed. Give it a moment.
- Write things down. I would have saved myself several confused afternoons if I had logged every odd behaviour from the start.
- Treat a long-lived device as ageing, and plan its replacement before it surprises me.
- A simple label saves a lot of guessing.
- Small improvements, like a thicker shelf or a better cable, matter more than expensive additions.

## Tools

The tools I use for looking after the charger are all ordinary.

- A soft cloth, damp and dry, for the panel and casing.
- A small brush for dust around the connectors.
- A basic meter for checking the output.
- A kitchen timer for running tests.
- A small screwdriver for the strip and the shelf fittings.
- A torch, because the loft corner is dim.
- A notebook and pencil for logging checks.
- Tape for holding cables in place.
- A phone for taking photographs of the arrangement before and after any change.

I keep these together in a small tin on the shelf below the charger, so they are never far away when I need them.

## Supplies

Things I like to have in stock for the charger.

- A spare cable of the right length.
- A few cable ties and some tape.
- Soft cloths, kept clean and dry in a bag.
- A spare power strip.
- A pack of labels for marking plugs and shelves.
- A small board in case the shelf needs replacing again.
- A spare bulb for the work light, since that is the thing I use most.
- Gloves for handling anything dusty.

I do not stock a spare battery, because I am not sure which kind to buy and prices change. That is a gap I should fix. When the evening running time drops further, I will research a replacement properly and note the choice here.

## Safety

Safety matters more than convenience in the loft, so these are firm rules.

- Never leave the charger running with a device that feels hot.
- Keep the area around the unit clear of paper, powder, and cloth.
- Do not cover the unit while it is working.
- Disconnect before cleaning anything near the connectors.
- If the casing swells, smells sharp, or feels very hot, unplug everything, move away, and do not use it again.
- Keep water away. Do not wipe with a soaking cloth.
- Do not charge or use the unit in a damp loft after a roof leak until everything has dried.
- Wear a mask when sweeping or sanding in the loft, since dust is the real enemy up there.
- Keep a small fire extinguisher accessible near the stairs, not near the shelf.
- Make sure someone knows I am in the loft when I am working there alone.
- Do not let children play near the shelf or the cables.

The charger is a modest device and has been safe for me since 2016, but a battery in a loft full of dust and dry material deserves respect. I would rather replace it early than find out why I should have.
