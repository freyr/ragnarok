---
type: research
status: active
project: piothlaeth-rebuild
area: ceramics
description: "Research about Tangio circulation pump."
---

# Tangio circulation pump study

## Lessons

The Tangio circulation pump is a green, battery-powered circulation pump that I installed in the loft in 2025. It serves the ceramics area, which is the reason I keep this study at all. The main lessons are practical, and most of them came from getting small things wrong the first time.

**Placement matters more than I expected.** The loft is a awkward place for any pump. It is hot in summer and cold in winter, and the air up there is dry and dusty from the kiln work below. I first set the unit on a loose shelf board. The vibration made a low hum travel through the rafters, and I heard it in the room underneath. Moving it onto a folded rubber mat on a solid beam cut the noise almost completely. The lesson is to treat the mounting surface as part of the pump.

**A battery-powered pump needs a battery routine.** Because the energy source is battery, there is no mains cable to forget about, but there is also no automatic recovery after a power cut. The pump simply runs until the cells are empty and then stops. In a loft that is a quiet failure, since I do not walk up there daily. I now check the pump on a fixed day each week and write the result in a short log. Without that routine I would have found out only when the ceramics line went cold.

**Green paint is not a feature, but it helps.** The body of the pump is green. In a dim loft full of grey insulation and brown timber, the green colour makes it easy to find with a torch. I also use it as a visual marker: if the green casing looks dusty or stained, I know it is time for a wipe-down.

**Keep the circuit simple.** My early plan had two branches and a bypass. It was harder to balance and harder to explain to myself later. The single loop I use now is easier to bleed, easier to test, and easier to reason about when something changes. Fewer joints also means fewer places for a slow drip to start in a space I rarely visit.

**Write down the baseline.** The most useful thing I did in the first weeks was record what normal looks like: how long the pump runs, how warm the pipes feel at set points, and how the battery behaves over a week. Every later observation only makes sense against that baseline. If I had skipped it, I would be guessing now.

**Small checks beat big overhauls.** A quick look with a torch, a hand on the casing, and a glance at the pipe joints takes five minutes. That is far better than a long, rare inspection that I would keep postponing. Short checks fit the way I actually work.

A short summary of the subject, as I keep it in my own records:

```text
device:        Tangio circulation pump
kind:          circulation pump
area:          ceramics
color:         green
energy source: battery
year installed: 2025
location:      loft
```

## Observations

This section collects what I have seen while the pump has been running. I try to separate what I measured from what I only felt or guessed.

**Sound.** After the mat was fitted, the pump is nearly silent from the room below. Standing next to it in the loft, I hear a soft, even whirr. A change in that tone is my earliest warning sign. Once the tone went slightly rough, and the cause was a small amount of air in the line, which cleared after bleeding.

**Heat.** The casing stays only mildly warm during normal running. In summer the loft air is warmer than the pump, so touch alone tells me little then. In winter the difference is clear, and I find the hand test much more useful in the cold months. I do not trust it in July.

**Battery behaviour.** The battery drains faster in cold weather. This is the most consistent pattern I have seen. A set of cells that lasts comfortably through a mild stretch gets noticeably shorter life during a frost. I now swap cells earlier in winter than in summer, and I do not wait for the pump to slow down before doing so.

**Dust.** The loft dust is fine and collects on the casing within a few weeks. It is not a problem for the pump itself, but it hides small drips, because a damp spot looks like a dark patch in the grey layer. Wiping the casing before each check makes leaks easier to spot.

**Flow.** The ceramics area is reached by a pipe run that drops from the loft. When the pump runs normally, the far end warms within a reasonable time. When it does not, I look first at the battery, then at trapped air, then at the valves, in that order. That order has solved every case so far, and I have not needed to go beyond the third step.

**Routine log.** My weekly entry is short. A typical line looks like this:

- Day of check, pump running, tone even
- Casing dry, no drips at joints
- Battery state noted, cells swapped or not
- Anything unusual, written in plain words

Over time this log has become the most valuable part of the study. Patterns that I could not see in one visit are obvious across many lines, especially the link between cold nights and shorter battery life.

**What I have not seen.** I have not had a leak, and I have not had a full stop caused by the pump itself. The two stoppages so far were both empty cells, which I could have prevented with an earlier swap. That makes me think the device is sound and my routine is the weak point, not the hardware.

**Open questions.** I still do not know how the pump behaves through a full second winter, since the cells and seals will have aged by then. I also want to test whether a small insulating sleeve over the battery compartment slows the cold-weather drain. I plan to try it and record the result in the same weekly log, using the same format so the lines stay comparable.

## References

These are the sources I rely on for this study. They are all my own records rather than outside documents.

- My weekly loft log, kept in the notebook next to the kiln schedule. It holds the baseline readings and every battery swap.
- The installation sketch I drew in 2025, showing the single loop between the loft and the ceramics area, with the pump position marked on the beam.
- The maker's printed leaflet that came in the box. I use it only for the general handling advice, and I have not copied any codes or ratings from it into this note.
- Photos of the pump in place in the loft, taken at installation and again after the mat was added. They show the green casing, the mounting beam, and the joints.
- My own short notes on the ceramics area, covering which parts of the workshop depend on the warm loop and which can tolerate a slow start.

When I update this study, I add the new source to this list first and then adjust the lessons and observations that depend on it. That keeps the chain of evidence clear for me later.

## Safety

The loft is the riskiest part of this setup, more than the pump itself. A few rules keep me out of trouble.

**Access.** Use a proper loft ladder and keep three points of contact. Never carry the cells or tools in your hands while climbing; use a bag. Only step on the beams or boards that are rated to take weight, because the insulation between them hides the ceiling below.

**Light and air.** Bring a good torch or a work lamp. The loft is dusty, so wear a dust mask when wiping the casing or disturbing insulation. Ceramics work adds fine particles to the household air, so I keep the mask habit even for short visits.

**Battery handling.** Because the pump is battery-powered, treat the cells with respect. Do not mix old and new cells, do not leave spent cells inside the compartment for long, and keep them away from heat sources. Store spares in a cool, dry place outside the loft, since hot summer air is bad for them. Dispose of used cells through a proper collection point, not the household bin.

**Water and leaks.** The system carries warm water, so isolate the loop before opening any joint, and let it cool first. Place a tray and a cloth under any joint you touch. A slow leak in the loft can soak insulation and damage the ceiling below without any sign for weeks, so I check for dark patches every time I go up.

**Working alone.** I tell someone at home when I am going into the loft and roughly how long I will be. A fall in a space that nobody visits is a serious risk, and a simple message costs nothing.

**When to stop.** If the casing is hot to the point of discomfort, if I smell something burnt, or if a cell looks swollen or damp, I stop, remove the battery if it is safe to do so, and leave the pump off until I have found the cause. The ceramics area can wait; nothing in it is worth a fire or a fall.

## Setup

The Tangio circulation pump is a green, battery-powered circulation pump that I installed in the loft in 2025. It belongs to the ceramics area of my notes, because the whole reason for it is to keep glaze water and slip moving in the drying and mixing corner I set up under the roof. This part of the note describes how the thing is put together and how I ran it, so that I can rebuild the arrangement if I ever have to take it down.

The pump sits on a short wooden shelf bolted to a rafter. I chose the shelf over the floor because the loft floor collects dust from the clay trimmings and I did not want fine ceramic powder getting into the housing. The green casing is easy to spot in the half light, which turned out to be a real advantage when I came up with a torch and needed to find it quickly.

Because the energy source is a battery, there is no mains cable running across the loft. That was the main reason I picked it. The loft has only one old socket, far from the work area, and I did not want an extension lead lying across a floor where I kneel and carry wet buckets. The battery sits in a small box beside the pump, held with a strap, and a short lead connects the two. I keep the box on the shelf, not hanging, so the weight does not pull on the connector.

### Layout

The water path is simple. A bucket of glaze water stands on the floor. A hose runs up from the bucket into the pump inlet. A second hose leaves the outlet and returns to the bucket through a loose ring clamp, so the water circulates in a loop and does not stir only at the surface. I cut the return hose to a length that ends just below the water line, because a hose that splashes in from above makes foam, and foam leaves pinholes in the fired glaze.

The order I follow when starting up:

1. Check the hoses are pushed fully onto the fittings.
2. Check the strap on the battery box is tight.
3. Fill the bucket to the mark I scratched on the inside.
4. Switch the pump on and watch the return hose for about a minute.
5. Look for drips at both fittings.

### Notes file I keep next to the pump

I keep a small checklist taped to the rafter. I copied it here so that the note and the loft stay in step.

```
TANGIO LOFT CHECK
-----------------
location ....... loft
colour ......... green
energy ......... battery
installed ...... 2025

before use
  [ ] hoses seated
  [ ] battery box strapped
  [ ] bucket at mark
  [ ] return hose below waterline

after use
  [ ] switch off
  [ ] rinse inlet hose
  [ ] wipe shelf
  [ ] note battery state
```

### Early observations

In the first weeks the pump ran well with thin glaze water. It kept the solids in suspension without any hand stirring, which saved my wrist on long sessions. With thicker slip it worked harder and the flow at the return hose dropped visibly. I came to treat it as a tool for thin and medium mixes only.

The loft is cold in winter and hot under the roof tiles in summer. I did not log temperatures carefully, but I noticed that the battery seemed to give shorter runs in the cold months. I started bringing the battery box down to the house between sessions in winter, which helped.

## Problems

None of the problems were dramatic, but several of them repeated, and I want them written down in one place.

**Settling in the hoses.** If I switch the pump off with glaze in the lines, the heavy particles sink into the low bends of the hose. The next time I start, the first few seconds push a plug of thick material through the pump. This is the thing that most often slowed the flow. The fix that works is to run clean water through the loop for a short time before switching off, and I now do that every session.

**Battery runs shorter than I expect.** The pump does not tell me how much charge is left in a way I can read from across the loft. I only find out when the flow weakens or stops. Twice it stopped in the middle of mixing a batch, and the solids began to settle while I went to fetch a spare. A stopped pump halfway through a batch is annoying, because I then have to stir by hand anyway.

**Clamp creep.** The loose ring clamp on the return hose slowly slid down the hose because of the vibration. Once it let the hose drop to the floor of the bucket, which gave a strong swirl and spilled a little water over the rim onto the loft boards. I replaced the clamp with a tighter one and added a mark on the hose with a marker pen so I can see if it has moved.

**Residue on the casing.** The green casing hides stains well, which sounds like a benefit, but it also means I do not notice a build-up of dried glaze around the inlet until it is quite thick. I now wipe the whole body at the end of each session.

**Dust.** Even on the shelf, the loft produces a fine film of dust. It settles on the battery box and on the connector. I once found the connector gritty and had to clean it with a dry brush before the contact was reliable again.

**Noise.** The pump hums, and in a quiet house the sound carries through the ceiling. It is not loud, but if I am working late I can hear it from the room below. I put a thin foam pad under the pump, and that softened the hum noticeably.

## Risks

I try to be honest about what could go wrong, because the loft is not a forgiving place to have a leak.

**Water and the battery.** This is the biggest risk. A battery and a bucket of water in the same small space is a bad pairing if a hose pops off. The battery box is on the same shelf as the pump, and a spray from a loose fitting could reach it. I raised the box edge a little, and I keep the hose joints on the side away from the battery. I would still like a better splash cover.

**Glaze materials.** Some glaze ingredients are harmful if they are swallowed or breathed in as dry powder. The pump itself reduces dust because I do not stir by hand, but dried residue on the shelf and casing can turn into dust again. I wipe things wet, never with a dry cloth, and I wear a mask when I handle dry material in the loft.

**Floor and ceiling.** A spill in the loft does not stay in the loft. Water finds the gaps between the boards and can stain the ceiling below. I keep a shallow tray under the bucket for this reason, and I check it after each session.

**Unattended running.** Because the pump is quiet and easy to forget, I could leave it on and walk away. A battery that runs flat is not a safety problem, but a hose that slips while I am away is. My rule is that the pump runs only while I am in the loft.

**Battery condition.** Batteries age, and one kept in a hot loft in summer ages faster. I do not leave it fully charged and sitting under the roof tiles for weeks. If the box ever feels warm or swollen, I stop using it and take it out of the house.

**Over-reliance.** I have started to trust the pump to keep the glaze even. If it quietly stops and I do not notice, a batch can go uneven and I only find out at the kiln. A quick check of the return hose before I start a brush session costs nothing.

## Ideas

These are things I might try, in rough order of how useful I think they would be.

- **A battery level marker.** I could write the date of the last charge on the box with tape, and a rough count of how many sessions it has run since. That would give me a warning without any new hardware.
- **A splash cover.** A simple lid made from a cut plastic tub, open at the bottom, that sits over the battery box and sheds water away from the connector.
- **A weighted return hose.** A small ceramic weight, made by me, tied near the end of the return hose so it stays below the water line without a clamp. It would be a nice use of my own craft, and I could glaze it in the same green as the pump.
- **A pre-filter on the inlet.** A coarse mesh over the inlet hose end to catch lumps and stop them reaching the pump. I would need to check that it does not clog too quickly with fine glaze.
- **A second, smaller loop.** For tests of small amounts, a jar and a short hose would let me circulate a cupful without wasting a bucket of material.
- **Cold-season routine.** A fixed habit of carrying the battery box down after every winter session, with a hook by the door as a reminder.
- **A simple log.** A few lines in my notebook after each session: how long it ran, how thick the mix was, and how the flow looked at the end. After a season I could see a pattern in the battery life and decide whether a larger battery is worth buying.
- **Cleaner shelf.** A removable wipeable tray on the shelf, so the whole surface can be lifted out and washed downstairs instead of being cleaned in place.

If I only do one thing from this list, it will be the splash cover, since the combination of water and a battery is the part of this setup that still worries me.

## Schedule

This part of the study covers the plan for looking after the Tangio circulation pump and the timing of the checks I want to run on it. The pump is a green circulation pump, installed in 2025 in the loft, and it runs on a battery. It serves the ceramics area, so the work below is arranged around how the ceramics side of the house uses it. The pump moves water through a small loop, and the loop matters more to me than the pump on its own.

I keep the schedule loose on purpose. A rigid calendar for a loft device means I skip it in the cold months, when climbing up is the last thing I want to do. Instead I tie each task to something that already happens regularly.

**Every week**
- Listen for the pump from the landing below the loft hatch. A steady low hum is normal. A rattle or a pulsing sound means air in the loop.
- Look at the status light when I pass the hatch with a torch. Green and steady means fine.
- Check that the loft is not damp near the pump. Condensation under the roof is the main enemy of anything battery powered.

**Every month**
- Climb up and read the battery state straight off the pump display.
- Wipe dust off the housing with a dry cloth. Ceramics work produces fine dust that finds its way upstairs, and it settles on the casing and the vent slots.
- Check the pipe joints on both sides of the pump with a dry paper towel. Any damp mark is a leak that has started.

**Every season**
- Swap or recharge the battery, depending on its state. I do not wait for it to run flat, because the pump stops silently and I only notice when the ceramics area cools down.
- Bleed air from the loop at the highest point.
- Test the pump in its slowest and fastest modes, and write down how each sounds.

**Once a year**
- Do a full inspection of the mounting, the cable, the pipe insulation and the loft ventilation.
- Review this note and update the checklist with anything I learned.

The first full year since the 2025 installation is now behind me, so the yearly inspection is due about now. I treat the seasonal swap as the anchor, and the monthly and weekly checks fit around it.

## Supplies

Everything I need for the pump lives in one plastic box that stays by the loft hatch, so I never go up empty handed. The box is labelled and kept dry. I restock it after each visit, not before the next one, because that is when I remember what ran out.

**Power**
- A spare battery for the pump, fully charged and stored at room temperature downstairs, never in the loft. Cold drains a battery faster than anything else.
- The charger and a short extension lead, kept coiled in the box.
- A small label stuck to each battery saying when I last charged it.

**Cleaning**
- Dry microfibre cloths, several of them.
- A soft brush for the vent slots.
- A small hand vacuum with a narrow nozzle for the dust around the base. I do not use water on the pump.

**Plumbing**
- A bleed key that fits the vent point on the loop.
- A few spare washers for the joints on either side of the pump.
- Pipe tape and a roll of foam insulation for any bare stretch of pipe I find.
- A shallow tray and an old towel to catch drips while bleeding the loop.

**Inspection**
- A torch with a headband, so both hands are free.
- Paper towels for the leak check.
- A small notebook and pencil. The loft is too cold for my phone to be pleasant, and the pencil never runs out.
- A cheap thermometer I leave near the pump to see how cold the loft gets.

**Ceramics side**
- A bucket and a sponge for settled slip and dust near the outlet in the ceramics area.
- A note of the preferred running mode, written on tape and stuck to the inside of the lid.

A short log extract from my notebook shows how I record a visit. I keep the format simple so I actually fill it in.

```
visit: seasonal check
location: loft
device: Tangio circulation pump (green, battery)
battery: swapped, old one set to charge
sound: steady hum, no rattle
leaks: none at either joint
vent: bled once, small hiss of air
housing: dust wiped off
next: monthly look at the display
```

I copy the useful lines into this note afterwards if anything changed. Most visits change nothing, and that is the result I want.

## Costs

I am not putting exact prices in this note. Prices change, and I do not need the figures to make decisions. What I do need is a clear sense of where the money goes and what is worth spending on, so the notes here are about proportions and habits.

**Purchase and installation**
The pump itself was the largest single outlay, and it was spent in 2025 when it went into the loft. Fitting it in the loft added to that, since the loop needed pipe work and some insulation. I treat that as sunk. The useful question now is how cheap it is to keep running.

**Running cost**
Because the pump runs on a battery, there is no mains bill attached to it directly. The cost shows up as batteries and charging. Charging at home uses very little electricity, so the real expense is the battery wearing out over time. Batteries that sit in a cold loft wear out faster, which is why I keep the spare downstairs and only carry it up when I swap.

**Consumables**
These are small and steady: washers, tape, foam insulation, cloths, and the occasional replacement bleed key. None of them is worth tracking individually. I restock when the box looks thin.

**Where money is easily wasted**
- Letting the battery run flat and stop the pump. The ceramics area then goes cold, and a cold loop can lead to a bigger repair.
- Ignoring a small joint leak. A damp patch in the loft can turn into ceiling damage below.
- Leaving dust to build up on the housing, which makes the pump run warmer and shortens its life.

**Where money is well spent**
- A good spare battery. It is the part most likely to fail first.
- Decent pipe insulation. It keeps the loop warm in winter and reduces how hard the pump works.
- A proper torch. It sounds trivial, but I make the checks more often when the loft is easy to see into.

**Budget approach**
I keep a mental split into three groups: replacement of the battery, small repairs, and a reserve for the day the pump itself needs replacing. I do not hold a separate account for it. I just remember that the third group is the one I should never raid, since a pump failure in the loft is a real nuisance to fix in a hurry.

If I ever want actual numbers for a comparison, I will pull them from receipts in the household folder, not from this note.

## Checklist

This is the list I take up with me. I tick it in the notebook, not here, and I only edit this version when the process itself changes.

**Before going up**
- [ ] Collect the supply box from beside the hatch.
- [ ] Take the charged spare battery from downstairs.
- [ ] Put on the headband torch and check it works.
- [ ] Lay the old towel and tray near the pump.

**At the pump**
- [ ] Confirm the status light is green and steady.
- [ ] Read the battery state on the display.
- [ ] Listen for rattling, pulsing or silence.
- [ ] Wipe the housing and brush the vent slots.
- [ ] Check both pipe joints with a dry paper towel.
- [ ] Look at the cable and the mounting for strain or movement.
- [ ] Look at the loft for damp, drips or condensation near the pump.

**Seasonal extras**
- [ ] Swap the battery and set the old one to charge downstairs.
- [ ] Bleed the loop at the highest point and catch any water.
- [ ] Test the slowest and fastest modes and note the sound of each.
- [ ] Check the pipe insulation for gaps and patch any bare stretch.

**Yearly extras**
- [ ] Inspect the whole loop from the pump to the ceramics area.
- [ ] Read the thermometer record and note how cold the loft got.
- [ ] Restock the supply box and replace anything worn.
- [ ] Review this note and fix anything that no longer matches reality.

**Before coming down**
- [ ] Take the tray, towel and any rubbish with me.
- [ ] Close the hatch properly so warm air does not leak up.
- [ ] Write the visit in the notebook.
- [ ] Put the old battery on the charger and label it.
- [ ] Check the ceramics area is warm and the loop is flowing.

**Things that mean stop and think**
- A pump that is silent while the light is off. Check the battery first.
- Water on the floor under a joint. Isolate the loop before doing anything else.
- A hot housing that is too warm to hold a hand against. Switch off and let it cool.
- Any smell of burning. Do not carry on; leave it off until I understand the cause.

That covers the practical side of the Tangio circulation pump. It is a simple device, a green battery-powered circulation pump sitting in the loft since 2025 and serving the ceramics area, and the whole point of these notes is to keep it simple to look after.

## Overview

This note collects what I know about the Tangio circulation pump, and what I still need to find out. The pump is a circulation pump. It is green, which makes it easy to spot against the grey insulation around it. The area it serves is ceramics: it moves water through the loop that supports the drying and glazing work. Its energy source is battery, which is unusual for a pump of this kind and shapes almost every decision about it. It was installed in 2025, and its location is the loft, under the roof slope, close to the hatch.

Here are the properties in one place so I can find them quickly later:

- Kind: circulation pump
- Area: ceramics
- Color: green
- Energy source: battery
- Year installed: 2025
- Location: loft

In practice, the pump has behaved well since it went in. It runs quietly, and I only notice it when I am in the loft. The battery arrangement means I do not depend on a mains socket in the roof space, which was the main reason I chose it. The cost of that choice is that I have to think about charge, runtime and access in a way I would never think about with a plugged-in unit.

What this study tries to do is answer three practical questions. First, is the battery supply stable enough to trust through a full season of ceramics work? Second, how much attention does the loft location demand, given that it is awkward to reach and gets hot and cold? Third, what would I change if I had to do the installation again?

My short answers so far: the supply is good but I have not tested it hard enough, the location is a nuisance mostly because of access, and I would add a better way to see the battery state from downstairs. The sections below go into the detail. Open questions comes first because it is the most useful part for planning, then maintenance, then the background of why the pump ended up where it is.

## Open questions

These are the things I do not know yet. I list them as plainly as I can so that I can tick them off when I have an answer.

**How long does the battery really last under load?**
I have a rough feel for it from ordinary weeks, but ceramics work is uneven. Some days the loop runs for a long stretch, and other days barely at all. I have not yet recorded a clean run from full to empty under a steady heavy duty. Until I do, any figure I quote is a guess, and I do not want to write a guess into the notes as if it were a fact.

**What happens to the battery in the cold of the loft?**
The loft gets cold in winter. Batteries generally give less when cold, and I do not know how much the Tangio loses. I should compare a cold morning with a mild afternoon. I also do not know whether the pump protects itself by cutting out early, or whether it simply runs until the supply collapses.

**Does the heat in summer shorten the battery life?**
This is the opposite worry. Under the roof tiles the loft can get very warm. I suspect heat ages the battery faster than anything else, but this is only a suspicion. I would like to put a small thermometer next to the pump and note the highest reading across a hot spell.

**Is the green housing a good choice or only a cosmetic one?**
The color is green, and I picked it partly because it stands out. I have wondered whether the housing material is also a decent thermal choice, or whether a lighter surface would have stayed cooler. I do not think the color matters much, but I have not checked.

**Can I see the battery state without climbing up?**
At the moment I have to go into the loft to check. That is the single most annoying thing about the setup. Options I have considered:

1. A small indicator light fitted near the hatch.
2. A reminder in my routine to check on a fixed day each week.
3. A simple log I keep by hand every time I go up.

I lean towards the third because it costs nothing, but it only works if I stay disciplined.

**What is the right replacement plan?**
I do not know how many seasons the battery will give before it has to be swapped. I would like a plan written down before it fails rather than after. This depends on the answers to the questions above.

**Does the ceramics loop tolerate a pause?**
If the battery runs flat, the pump stops and circulation stops. I do not yet know how long the ceramics work can sit without circulation before it causes a problem. I should test this on a quiet day, not in the middle of a busy batch.

**Is there noise or vibration I am missing?**
The pump seems quiet, but the loft is above a bedroom. I should listen at night once, to be sure that nothing carries through the beams.

## Maintenance

Maintenance on this pump is mostly about the battery and about getting to it safely. The pump itself, a circulation pump with few moving parts, has needed very little. The routine below is what I actually do, plus a few things I intend to start doing.

### Routine checks

When I go up into the loft, I do the same short sequence every time:

1. Open the hatch fully and secure it before I climb in.
2. Look at the green housing for dust, damp marks or discoloration.
3. Check that the pipework connections are dry. Any drip, however small, gets written down.
4. Listen to the pump running. A change in sound is the earliest warning I get.
5. Check the battery state and write it in the log.
6. Close the hatch and note the visit.

The whole visit takes only a few minutes if nothing is wrong. I keep a torch in the hatch frame so I never go up without light.

### Battery care

Since the energy source is battery, this is the part that matters most. My rules:

- Do not let the battery run flat if I can avoid it. A deep discharge is the usual way these things die early.
- Recharge or swap before the state looks low, not after.
- Keep the battery terminals clean and dry.
- Avoid leaving it fully charged in the hottest part of summer for long periods, if I can help it.
- Write down every swap or recharge so I can see the pattern over time.

### A simple log format

I keep the log as a plain text block in this note, copied from the loft visits. This is the layout I use. The values are placeholders showing the shape, not real readings.

```text
visit: loft check
pump: Tangio circulation pump
location: loft
energy source: battery
housing: green, clean
connections: dry
sound: normal
battery state: good
action: none
next check: one week
```

If something is off, the action line says what I did, and the next check line gets shortened so I look again sooner.

### Things that would make me act at once

- Any water on or under the pump.
- A grinding or rattling noise.
- The pump failing to start when the ceramics loop calls for flow.
- The battery state dropping faster than in previous visits.
- A smell of heat or anything burnt.

If any of these happen, I stop the loop, make the area safe, and deal with the cause before running the ceramics work again.

### Access and safety

The loft is the hard part. The hatch is small, the floor is only partly boarded, and the light is poor. I only step on the boarded sections and I never carry the battery up and down in one hand while holding the ladder. I pass it up in a bag or ask someone to help. I do not work up there when tired or in a hurry.

### Planned improvements

- Add a clear label on the pump saying what the battery type is and where the spare is kept.
- Put a thermometer beside the housing to answer the heat question.
- Keep a spare battery downstairs, charged and ready, so a swap is quick.
- Set a recurring reminder for the weekly visit.

## Background

The reason for this pump goes back to the way the ceramics area works. The ceramics work needs warm water moving steadily through a loop, and the loop passes through the loft before it comes back down. A circulation pump keeps the water moving so that the temperature stays even and nothing settles or cools in a dead section. Without it, the far end of the loop lags behind and the work becomes unreliable.

When I planned the setup, the loft had no convenient power. Running a mains cable up there would have meant opening ceilings and paying someone to do the job properly. A battery-powered pump avoided all of that. That is why the energy source is battery, and I accepted the trade-off knowingly: less building work now, more attention to the battery later.

I chose the Tangio because it was a circulation pump that fit the loop, and because it was available in green. The color was not a technical reason, but I liked that it would be obvious in a dark roof space. In a loft full of grey and brown, a green housing is the first thing the torch finds.

The pump was installed in 2025. Installation went reasonably smoothly. The location in the loft, near the hatch, was chosen so that I could reach it without crawling across the joists. I fixed it to a solid timber, kept it clear of the insulation so the housing could shed heat, and left enough slack in the pipework so that nothing is under strain.

Looking back, a few choices were good and a few were compromises:

- **Good:** keeping the pump near the hatch. It makes every check easier.
- **Good:** avoiding mains wiring in the roof. It kept the job simple.
- **Compromise:** relying on a battery for a device that may need to run for long stretches.
- **Compromise:** not fitting any remote battery indicator at the start.
- **Compromise:** not recording temperatures from the first day, which now leaves a gap in the data.

This study exists to close those gaps. The aim is not to prove the pump was the perfect choice, but to understand it well enough to run it with confidence and to know when it needs attention. If the open questions turn out well, the setup stays as it is. If they do not, the most likely change is a better battery arrangement or a way to monitor it from below, rather than replacing the pump itself.

For my own reference, the short summary is this: the Tangio is a green circulation pump for the ceramics area, powered by battery, installed in 2025 and sitting in the loft. Everything else in this note is detail around those facts.

## Measurements

This section records what I measured on the Tangio circulation pump and how I measured it. The pump is a green circulation pump used in the ceramics area, installed in the loft in 2025, and it runs on a battery. Every reading below was taken with those facts in mind. The loft is a different environment from a workshop floor, and a battery-fed pump behaves differently from a mains-fed one.

### Purpose of the measurements

I wanted to answer a few plain questions:

- How much power does the Tangio circulation pump draw while it is running normally?
- Does the draw change when the loft is cold or warm?
- Does the draw change as the battery runs down?
- Is the pump stable enough to leave unattended in the loft?

I did not try to build a full performance curve. This is a note for my own use, so I kept the method simple and wrote down anything that looked odd.

### Setup

The pump sits in the loft, close to the ceramics circuit it serves. It is green, which makes it easy to spot against the grey insulation and the dark rafters. Because the energy source is a battery, I could not use a wall-socket meter. I put an inline meter between the battery terminals and the pump input. The meter reads volts and amps and multiplies them for watts, so the reading is a direct measure of what the battery delivers.

Equipment I used:

- an inline DC power meter rated well above the pump's expected draw
- a notebook and a pencil, because the loft has no usable signal for a phone app
- a small torch, since the loft light is poor
- a second meter held in reserve to cross-check the first

I let the pump run for a while before reading anything. A pump that has just started draws more than one that has settled, and I did not want the startup surge in my main figure.

### Main result

The measured power draw of the Tangio circulation pump was 282.47 W. This is the steady running figure after the pump had settled. I read it several times across a session and the number stayed very close each time, so I treat it as the working value for this pump in this loft.

That figure is the one to use for any battery sizing or runtime estimate. It is the draw at the battery terminals, so it already includes whatever the pump's own electronics waste. I did not try to split the figure into motor power and electronics losses.

### Log extract

This is a cleaned-up extract of what I wrote down during one session. I removed the clock times and kept only the order of events.

```
session: loft, tangio circulation pump
subject: green circulation pump, ceramics area, battery supplied, installed 2025
step 1: pump switched on, startup surge seen, ignored
step 2: waited for reading to settle
step 3: steady reading logged -> power_draw = 282.47 W
step 4: repeated reading after a pause -> same value within meter resolution
step 5: cross-check with reserve meter -> agrees
step 6: pump left running, no alarm, no odd noise
status: ok
```

The log is deliberately short. The point was to confirm that the steady figure repeats and that the second meter agrees with the first. Both held up.

### Startup behaviour

When the pump switches on, the meter jumps to a higher value for a short moment, then falls back and settles. This is normal for a motor-driven pump, because the rotor has to accelerate and the fluid in the line has to start moving. I did not record the peak as a formal measurement, because the meter refreshes too slowly to catch it reliably. I only noted that it exists and that it is short.

This matters for the battery. A battery that is nearly flat may sag under the surge, and the sag can make the pump stumble or restart. I did not see that happen during my sessions, but I only tested with a battery that was in reasonable condition. I should repeat the test with a tired battery before I trust it in winter.

### Effect of loft temperature

The loft is the awkward part of this installation. It gets cold on winter nights and stuffy in summer. I took readings at a cooler time and a warmer time to see whether the draw moved.

What I saw:

- In the cooler loft, the pump settled a little more slowly. The steady figure ended up essentially the same.
- In the warmer loft, the pump settled faster, and again the steady figure was essentially the same.
- I saw no sign that temperature alone changed the steady draw enough to matter for planning.

I want to be careful here. I did not go to extremes. I did not test a hard frost or a heatwave. My conclusion is only that across ordinary loft conditions the figure of 282.47 W is a fair working value.

### Effect of battery charge

A battery-supplied device is sensitive to how full the battery is. As the battery empties, its voltage falls, and a constant-power load draws more current to compensate. The pump did not behave exactly like a constant-power load, but the meter showed the current creeping up as the battery drained while the watts stayed close to the main figure.

My reading of this:

- With a well-charged battery, the draw was stable and easy to read.
- With a partly drained battery, the current was higher and the voltage lower, but the power figure barely moved.
- I did not run the battery to empty, because I did not want to stress it or leave the ceramics circuit without circulation.

So the practical lesson is to watch current as well as watts. If the current climbs a lot, the battery is getting low even when the power figure looks fine.

### Noise and vibration

I also listened to the pump, since a worn or badly seated unit often tells you something before the meter does. The pump hums at a steady pitch while running. I heard no rattling, no grinding and no change of tone while the reading settled. I rested a hand on the housing and felt only a mild, even vibration.

The mounting in the loft is on a flat board. I checked that the board did not amplify the vibration into the floor below. It did not, as far as I could tell by ear from the room beneath. If that changes, I will add a rubber pad under the pump.

### Cross-check with the reserve meter

To make sure the main meter was not lying, I swapped in the reserve meter for one session. The two meters agreed within their resolution. That is good enough for a note like this. I do not claim laboratory accuracy. I claim that two independent meters gave matching results and that the pump's draw repeats from one reading to the next.

If the two meters had disagreed, I would have checked the connections first, because loose terminals in a cold loft are a common cause of odd readings.

### Repeatability

I took readings in more than one session, not only one. Each session started from a cold pump, went through the startup surge, and settled to the same steady figure. The repeat value matched the first within what the meter can show. That repeatability is the main reason I am comfortable writing 282.47 W as the figure for this pump.

### Things that could distort the figure

A few possible sources of error, listed so I remember them:

- The meter's own resistance adds a tiny loss, which I ignored.
- Long thin battery leads can drop voltage under load, so I kept the leads short and thick.
- The pump may draw more when the circuit is full of cold, thick fluid than when it is warm.
- A battery in poor condition can sag and change the current pattern.
- The ceramics circuit was in its normal state. If the line is partly blocked, the draw could differ.

None of these looked large during my sessions, but they are the first places to look if a later reading disagrees with this one.

### What I would do with the figure

For planning, I use 282.47 W as the running draw. Multiplying by the hours the pump runs gives the energy taken from the battery. I will also keep a safety margin, because the startup surge, a tired battery and a cold loft can all push the real demand above the steady figure.

For monitoring, the most useful habit is to read the meter at the same point in each session, after the pump has settled, and compare it with this value. A clear rise suggests a blockage or a failing bearing. A clear fall suggests the pump is not moving as much fluid as it should, or that the battery is no longer delivering properly.

### Summary of the subject and its measured state

To keep the facts in one place:

- Device: Tangio circulation pump
- Kind: circulation pump
- Area: ceramics
- Colour: green
- Energy source: battery
- Year installed: 2025
- Location: loft
- Measured power draw: 282.47 W

### Open questions

Some things I have not settled and want to test later:

- How the pump behaves in a hard frost in the loft.
- How it behaves in the hottest part of summer.
- Whether a nearly flat battery causes the pump to stumble at startup.
- Whether the draw drifts upward over many months as the pump ages.
- Whether a rubber pad under the mounting board would reduce the faint vibration.

For now, the measurement is done and the result is clear. The pump settles quickly, repeats well, agrees across two meters, and draws 282.47 W in steady running in its loft position.
