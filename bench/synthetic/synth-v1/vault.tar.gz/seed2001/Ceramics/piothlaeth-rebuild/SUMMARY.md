---
type: summary
status: active
project: piothlaeth-rebuild
area: ceramics
---

# Summary of Piothlaeth rebuild

This is the summary note for the Piothlaeth rebuild. It records where the project stands, what is finished, what is still open, and the single next step. The goal is a rebuild, the area is ceramics, the project started in 2023, and the season of work is summer. The lead is the plumber, who owns the pipework and the heat side of the job. I keep this note short enough to read in a few minutes before I go back to the bench.

## Lessons

The first lesson is that the rebuild went better once I stopped treating it as a repair. In the early weeks I kept patching old parts and losing time. When I accepted that the goal was a full rebuild, the work got simpler, because every choice was either "keep and clean" or "replace and fit".

The second lesson is that the plumber as lead was the right call. Almost every delay in a ceramics setup comes back to water, heat or venting, and having one person who thinks about those first saved me from reworking the layout twice.

The third lesson is about summer. Working in the summer season gave me long dry days and open doors, which helps a lot with drying and curing. It also means the workshop gets very hot, so heavy jobs have to start early in the morning.

What I would tell myself next time:

- Write down the decision before buying anything, and keep the date next to it.
- Photograph every connection before taking it apart.
- Test one small part of the system before building the whole thing around it.
- Keep a spare hour at the end of each session for tidying, because a clear bench makes the next session start faster.
- Ask the plumber early, not late.

## Next action

The next action is **NX-5449**. I am keeping it as the only open step on purpose, so I do not start three things at once. Everything else in this note either supports that step or waits behind it.

Before I start it, I need the bench clear, the tools from the Tools section laid out, and the safety points below checked. After it is done, I will come back to this note, update the stage, and pick the next step from the open points. If the step turns out to be bigger than expected, I will split it rather than let it run on across several evenings with no clear end.

## Safety

Ceramics work mixes dust, heat, water and electricity, so I keep a short list of rules and I do not skip them just because a job is small.

- Wear a proper dust mask when sanding, mixing dry material or sweeping. Fine clay dust is a long-term problem for the lungs.
- Switch off and unplug anything electric before opening it, and check that it is really dead.
- Let hot parts cool fully before touching them. The heat side of the system stays hot for a long time after shutdown.
- Keep water away from sockets and from the floor around the controls.
- Use eye protection when cutting, and keep fingers clear of the blade. The [[Saenber band saw handbook]] is the reference I use for guards, blade tension and the cutting rules, and I reread the guard section before any new type of cut.
- Keep a clear way out of the room. Heavy items stay off the walkway.
- Do not work alone when lifting something heavy or when working with the heat side live.

The plumber, as lead, has the final word on anything touching pipes, pressure or heat. If they say stop, I stop.

## Checklist

This is the working list I run through at each session. It is short on purpose.

| Item | Status | Note |
| --- | --- | --- |
| Go decision recorded | Done | Date kept under Decisions |
| Old parts removed | Done | Sorted into keep and discard |
| Heat side planned | Done | Based on the Stondneth unit |
| Tools laid out | Done | See the Tools section |
| Pipework layout | In progress | Plumber is leading |
| Test firing plan | Open | Waits for the pipework |
| Final tidy and sign-off | Open | After testing |

The table is the quick view. The longer reasons are in the sections below. When I finish something, I change the status here first and only then write any detail elsewhere.

## Overview

Piothlaeth rebuild is a project with the goal of a rebuild. It sits in the ceramics area, started in 2023, and runs mainly in the summer season. The lead is the plumber.

The project exists because the old setup was no longer reliable. It worked, but only with constant attention, and parts of it were worn past the point where repair made sense. Instead of keeping it alive, I chose to take it back to the basics and rebuild it in a cleaner order.

Where it stands now: the stage is mid-build. The planning and the strip-down are finished. The heat side is chosen and mostly fitted in my head and on paper, and the pipework layout is being worked out with the plumber. Testing has not started yet. That is the honest picture, and I would rather write it plainly than pretend it is further along.

Done so far:

- The decision to go ahead was made and written down.
- The old parts were removed and sorted.
- The heat side was selected after comparing two options.
- The working area was cleared and marked out.

Still open:

- Final pipework layout.
- A test plan for the first firing.
- A decision on where the spare parts will be stored.
- A proper clean-down once the heavy work is over.

## Setup

The work is based at the [[Fiornio workshop]], which has the space, the power and the ventilation I need. The bigger and dirtier jobs, such as moving heavy items in and out, go through the [[Tranael yard]], because it has room to stage things and to wash down outside.

The layout inside the workshop follows the flow of the work: raw material comes in on one side, forming and cutting happen in the middle, and the heat and firing end is on the far side near the vent. The plumber's pipework runs along the back wall so it stays out of the walking area.

For advice on the working side of the clay and the finished results, I keep notes from [[Koguni Vopa]], who knows far more about the practical ceramics than I do. When a question is about how a result should look or behave, I check those notes first before guessing.

Test results from earlier trials are kept in [[Krasglevur Brunniol tests]]. I compare any new test against that page, so I can see whether a change helped or only felt like it did.

The setup is meant to be temporary in its layout but permanent in its connections. I can move tables and shelves around freely, but the pipework and the heat side are fixed once signed off.

## Risks

The main risks are listed here with what I plan to do about each one.

- **Heat side not matching the load.** If the heat exchange is too small, the firing cycle will be slow and uneven. I am reducing this risk by comparing the chosen unit against the alternative before final fitting.
- **Leaks.** Any new pipework can leak at the joints. The plumber will pressure-check before anything is covered or connected to the heat side.
- **Summer heat.** Long hot days make people careless and make materials dry too fast. I start early and stop when the room gets too hot.
- **Scope creep.** A rebuild invites extra ideas. I park them in the Ideas section instead of acting on them straight away.
- **Single point of knowledge.** Much of the pipe layout is in the plumber's head. I ask for a simple sketch at the end of each session so it is written down somewhere.
- **Delays in parts.** If a part arrives late, the whole sequence stalls. I keep the next action small enough that it does not depend on a late delivery.

None of these is large on its own. The danger is several of them showing up on the same day, which is why I check the list before each session.

## Tools

This is the set I use for the rebuild. Most of it is basic, and I would rather have a few good tools than many mediocre ones.

- Band saw for cutting boards and shaped pieces, used according to the [[Saenber band saw handbook]].
- Pipe wrenches, cutters and a pressure test pump, all owned or borrowed by the plumber.
- A level and a long straight edge for checking the pipework runs.
- Hand tools: screwdrivers, spanners, pliers and a small hammer.
- Dust mask, safety glasses and gloves.
- A notebook and a phone for photographs of each connection.
- Buckets, sponges and a wet vacuum for cleaning.

For the heat side, the reference unit is the [[Stondneth heat exchanger]]. I also keep notes on the [[Navis heat exchanger]], which was the alternative I compared it with. I have not fully ruled it out as a fallback if the first choice proves awkward to fit, so those notes stay close at hand.

## Ideas

These are things I would like to try, but none of them is part of the current scope. They are written down so I can stop thinking about them and get on with the main job.

- Add a simple shelf for drying pieces above the warm side of the room, so the waste heat is not lost.
- Label every pipe with its purpose and flow direction, using tape at first and proper tags later.
- Build a small logbook board near the entrance where each firing is noted in one line.
- Ask [[Koguni Vopa]] whether a different clay mix would suit the new heat profile better.
- Move the washing area outside to the [[Tranael yard]] so clay slurry never enters the workshop drains.
- Make a one-page diagram of the whole system and pin it to the wall.
- Try a short test run with a very small batch before the first full load, and record it alongside the older [[Krasglevur Brunniol tests]].

If an idea survives a few weeks without me forgetting it, it moves into the plan. If I forget it, it was not important.

## Decisions

The go decision for the Piothlaeth rebuild was made on 2022-01-19. That was well before the work began in 2023, and it gave me time to plan, collect parts and agree the lead.

The main decisions so far, in plain terms:

- **Rebuild, not repair.** The goal is a rebuild. Patching the old setup was costing more time than starting again.
- **Plumber as lead.** The plumber leads because the heat, water and venting decide most of the layout.
- **Summer as the working season.** Most of the work is planned for the summer, when the workshop can be left open and drying is easy.
- **Heat side choice.** I chose the [[Stondneth heat exchanger]] over the [[Navis heat exchanger]], mainly for fit and for how simple it is to service. The other stays as a fallback.
- **Location of messy work.** Heavy and wet jobs go through the [[Tranael yard]], and the rest happens at the [[Fiornio workshop]].
- **One next action at a time.** The single open step is NX-5449, and nothing else starts until it is done.

When a new decision is made, I add it here with a short reason and the date, so that later I can see why I chose what I chose and not just what the result was.
