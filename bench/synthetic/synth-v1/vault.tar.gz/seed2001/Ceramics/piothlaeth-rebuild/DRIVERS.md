---
type: drivers
status: active
project: piothlaeth-rebuild
area: ceramics
---

# Drivers of Piothlaeth rebuild

## References

This note covers the drivers of the Piothlaeth rebuild: why the project exists, what limits it, what money is set aside, and how I will decide whether it worked. The other notes in the project hold the detail. This one is the short answer to "why are we doing this and what counts as done".

The project properties, stated once so I can find them quickly:

- Project: Piothlaeth rebuild
- Goal: rebuild
- Area: ceramics
- Start year: 2023
- Season: summer
- Lead: plumber

Related notes I keep returning to:

- [[Nirde workshop tests]] holds the trial results I use to judge whether the rebuilt setup behaves as expected.
- [[Stondneth heat exchanger]] describes the heat exchanger that the rebuild depends on and that shapes several constraints below.

When a driver here conflicts with something in those notes, this note wins on intent and the other notes win on technical detail.

## Schedule

The project started in 2023 and is tied to the summer season. That is not a coincidence. The work needs dry weather, open doors, and long days, and the ceramics area is quiet in summer, so nothing important is being fired or glazed while parts of the space are out of action.

The schedule is driven by three things:

- Weather. Anything that involves opening up the building or moving heavy items outdoors waits for settled summer conditions.
- Access. The plumber leads the project, so the order of work follows what the plumber needs first: water, drainage, heat transfer, and only then the finishing work.
- Drying and curing time. Any bonded, poured, or sealed part needs time before it can be loaded, and I do not rush that.

I do not keep a day-by-day calendar in this note. The rule is simple: the plumbing and heat side goes first, the ceramics-specific fit-out goes second, and testing goes last. If summer runs out before testing is done, the project is paused rather than squeezed, because a rushed test tells me nothing.

## Costs

Costs are driven mostly by the plumbing and heat side of the work. The ceramics fit-out is cheaper because much of it is reuse of things I already own.

The main cost groups, in rough order of size:

- Heat exchange and associated pipework, tied to the [[Stondneth heat exchanger]].
- Water supply, drainage, and fittings.
- Labour that I cannot do myself, mostly specialist plumbing tasks.
- Materials for the ceramics-side fit-out, such as shelving, surfaces, and protective coverings.
- Consumables and small tools that wear out during the work.

I deliberately do not list individual prices here. Quotes change, and a stale price in a drivers note is worse than none. Actual figures live in the budget tracking, and the overall ceiling is in the Budget section below.

One cost rule I follow: if a choice saves money now but makes the rebuild harder to repair later, I count the future repair work as part of the cost. This has already pushed me toward accessible pipe runs rather than hidden ones.

## Maintenance

A rebuild is only worth it if the result can be looked after without heroics. Maintenance is therefore a driver, not an afterthought.

What I want from the finished setup:

- Every valve, joint, and filter reachable without removing anything permanent.
- Clear labels on supply and return lines so I do not need to trace them by hand.
- A short routine I can actually keep up: look for leaks, check the heat transfer is behaving, clean what collects dust or residue, and note anything odd.
- Spare consumables stored close to where they are used.

The ceramics area adds its own wrinkle. Dust, clay residue, and glaze splashes get into everything. Anything that clogs easily needs a cleanable design. If a part cannot be cleaned or replaced in a sensible amount of time, it is probably the wrong part.

I will write the maintenance routine as a proper checklist once the build is complete, using what I learn during testing. For now the driver is simply: design for upkeep.

## History

The project began in 2023, in summer, with the goal of rebuilding rather than patching. That choice came after a run of small repairs that kept failing in the same places. Each repair was cheap, but together they cost time and attention, and the underlying layout was the real problem.

Before the rebuild I tried the following, roughly in order:

- Spot repairs to fix individual faults.
- Rearranging how the space was used to work around the weak points.
- Borrowing and testing ideas, some of which are recorded in [[Nirde workshop tests]].

None of these gave a lasting fix, which is why the goal became a full rebuild. The plumber took the lead early because most of the persistent faults traced back to water and heat handling, not to the ceramics equipment itself.

The history matters as a driver because it reminds me what I am not willing to repeat: patching symptoms. If a decision during the rebuild looks like another patch, I stop and ask whether it solves the cause.

## Budget

The budget for the Piothlaeth rebuild is 14510.33 EUR.

This is the ceiling for the whole project, not a target to reach. I treat it as the amount I am willing to commit given the benefits, and I would be happy to finish under it.

How I use the budget as a driver:

- Big decisions are checked against it before I commit, especially anything involving the heat exchanger or specialist labour.
- I keep a small reserve inside the ceiling for surprises. Rebuilds nearly always uncover something hidden once surfaces are opened.
- If the running total heads toward the ceiling before the work is done, I cut scope from the ceramics fit-out first, not from the plumbing and heat side, because the latter is the foundation.
- I do not quietly raise the ceiling. If it has to change, I write down why in this note and in the open questions.

The budget is also a measure of success. A rebuild that works but breaks the budget is only a partial win, and I would rather learn that cleanly than hide it.

## Tools

The tools I need split into those I own and those I borrow or hire.

Owned and used regularly:

- Basic hand tools for fitting, cutting, and tightening.
- Measuring and levelling tools, which matter a lot for drainage falls and shelf alignment.
- Cleaning equipment for the dusty ceramics side.

Likely to need from the plumber, who leads the work:

- Pipe cutting and joining tools suited to the pipework chosen.
- Pressure and leak testing equipment.
- Anything specific to connecting the [[Stondneth heat exchanger]].

Tool needs drive both cost and schedule. If a tool is only needed once, I borrow or have the plumber bring it. If I will use it repeatedly for maintenance, I buy it and store it with the maintenance supplies. I avoid buying specialist items for a single job unless hire is clearly worse.

## Setup

The setup is the arrangement I am aiming for when the rebuild is finished. It is described here only at the level of drivers; the details belong in the design notes.

Principles for the setup:

- Water and heat services are grouped together so the plumber and I can find and work on them in one place.
- The ceramics work area is kept apart from the wettest and dirtiest parts of the plumbing, so clay and glaze do not contaminate anything they should not.
- The heat exchanger sits where it can be inspected and where its connections are not boxed in.
- Layout allows a clear walking route, so loading and unloading ceramics does not involve squeezing past pipework.
- Everything that might need replacing in the next few years is mounted so it can be swapped without damage to its neighbours.

Constraints on the setup come from the building itself: existing wall positions, floor falls, and the points where services already enter. I would rather work with these than fight them, because moving them is expensive and eats the budget quickly.

## Checklist

This is a drivers-level checklist, used to check that the project is still pointed the right way, not to track tasks.

- The goal is still a rebuild, not a series of patches.
- The lead is still the plumber, and the plumbing and heat side is still ahead of the fit-out.
- Work is being done in the summer window, with nothing rushed at the end.
- The running total is below the ceiling stated under Budget, with a reserve intact.
- Every installed part can be reached and replaced.
- The results of testing are being recorded in [[Nirde workshop tests]].
- The heat exchanger arrangement still matches what is described in [[Stondneth heat exchanger]].
- No decision has been made that only masks a cause.

I run through this list whenever a significant choice comes up, and again before I call any phase finished.

## Open questions

Several things are not settled, and I want them visible rather than buried.

- How much of the ceramics fit-out can be reused, and how much must be bought new? This changes the cost balance.
- Is the current location of the heat exchanger the best one, or does it create awkward access once everything else is installed?
- How much reserve is enough within the ceiling? I have a feeling but no evidence yet.
- If the work does not finish within the summer, which tasks can safely wait and which cannot?
- Which maintenance tasks should the plumber handle, and which can I do myself?
- What exactly will I accept as proof that the rebuild succeeded? I have criteria below, but some are still vague.

I will move each of these into a decision, with a short reason, once I have enough information. Until then they stay here.

## Ideas

Ideas that might help, none committed to yet:

- Mock up the layout with tape and cardboard before cutting anything, to check access and walking routes.
- Photograph every concealed section before it is closed up, so future repairs start with a map.
- Keep a small log by the heat exchanger for noting anything unusual during use.
- Ask the plumber to talk me through each connection as it is made, so I understand the system I will be maintaining.
- Use the lessons from [[Nirde workshop tests]] to set a simple pass or fail test for the finished setup.
- Group all consumables into one labelled box near the equipment.

Ideas that cost little and reduce future effort are the ones most likely to be adopted. Ideas that need extra money are weighed against the budget ceiling and the reserve.

## Overview

The Piothlaeth rebuild is a project in the ceramics area, started in 2023, scheduled for the summer season, led by the plumber. Its goal is a rebuild: a proper redo of the underlying setup instead of another round of repairs.

The drivers can be summed up like this:

- Purpose: stop the repeating faults by fixing causes, mainly in water and heat handling.
- Constraints: the summer window, the existing building, and the dependence on the [[Stondneth heat exchanger]].
- Money: a ceiling of 14510.33 EUR for the whole project, with a reserve kept inside it.
- Priorities: plumbing and heat first, ceramics fit-out second, testing last.
- Upkeep: everything reachable, cleanable, and replaceable.

Success is measured in four ways. First, the old repeating faults no longer return. Second, the trial results in [[Nirde workshop tests]] show the setup behaving as expected. Third, the total spent stays within the ceiling. Fourth, I can carry out routine maintenance myself without needing to take things apart. If all four hold after a full period of normal use, the project has done its job.

## Lessons

Lessons so far, mostly from the history of earlier patching and from early planning:

- Repairs that treat symptoms come back. The only fix that lasted was one that addressed the cause.
- A lead who understands the water and heat side saves a great deal of rework, because most problems start there.
- Hidden pipework is cheap on the day and expensive for years afterwards. Accessible runs are worth a small premium.
- A budget ceiling works better with a reserve inside it than with a hard line and no slack.
- Writing down open questions early stops them from becoming surprises later.
- Testing needs its own time. If it is squeezed, the results cannot be trusted.

I expect to add to this list after the testing phase. Anything that surprises me during the build gets a line here, even if it seems minor, because minor surprises often point to a bigger assumption that was wrong.

## Risks

The main risks, and what I intend to do about each:

- Hidden problems found when surfaces are opened. Mitigation: keep a reserve inside the budget and photograph everything.
- Running out of summer before testing is done. Mitigation: keep the plumbing and heat work first, and pause rather than rush if time is short.
- Cost growth around the heat exchanger. Mitigation: check every change against the ceiling of 14510.33 EUR before committing, and cut ceramics fit-out scope first if needed.
- Dependence on one lead. Mitigation: have the plumber explain and label each connection so I can maintain the system myself.
- Dust and residue from ceramics work harming new equipment. Mitigation: keep the work area apart from sensitive parts and design for cleaning.
- Quiet drift back into patching. Mitigation: use the checklist at each major decision and ask whether a choice fixes a cause.

None of these is unusual, but together they are the things most likely to stop the rebuild from meeting the goal I set in 2023.
