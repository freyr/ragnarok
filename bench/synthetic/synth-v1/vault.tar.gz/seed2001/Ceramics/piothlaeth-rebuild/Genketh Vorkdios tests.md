---
type: research
status: active
project: piothlaeth-rebuild
area: ceramics
description: "Research about Genketh Vorkdios."
---

# Genketh Vorkdios tests

## Schedule

Genketh Vorkdios is my mentor in ceramics. I have known him since 2016, and the main thing to remember about the schedule is that he is available on weekends only. Weekdays are not an option, so I stopped asking. We meet in person. He does not like phone calls about clay, and he says that anything worth discussing needs hands and a wheel nearby.

My usual pattern is to ask him early in the week whether a weekend slot is open. I send a short message, nothing long. He answers when he answers, usually by Thursday. If he says yes, I bring my questions written down on paper, because I forget half of them otherwise.

A typical weekend visit goes like this:

- Arrive in the morning, when the studio is cool and quiet.
- Spend the first hour looking at whatever I made since the last visit.
- Work at the wheel while he watches and corrects.
- Break for tea and talk about glazes or kiln problems.
- Finish with a plan for what to make before the next meeting.

I try not to visit more than twice a month. He has his own work and a few other people he teaches. If I arrive every weekend I think it would stop being a favor and start being a burden. Two visits is enough to keep momentum and still leave me time to practice alone.

Some weekends are blocked in advance. He tends to be away when there are regional fairs, and in the cold months the studio is sometimes closed because the kiln shed is hard to heat. I note these in my calendar as soon as he mentions them.

## Problems

The problems I bring to Genketh fall into a few groups. I keep this list so I do not ask the same thing twice.

**Centering.** For years my clay wobbled off center when I pulled walls up. He pointed out that I was rushing the first stage and letting my elbows float. Bracing the arms against my body fixed most of it. It still comes back when I am tired.

**Wall thickness.** My pots were heavy at the base and thin at the rim. He showed me how to use a rib to compress the base and then check the wall with a thin wire tool. I still overbuild the bottom if I am not paying attention.

**Cracking in drying.** Several of my bowls cracked at the base while drying. His explanation was uneven drying: the rim dried fast and the thick bottom stayed wet. The solution was slower drying under loose plastic and a more even thickness.

**Glaze crawling.** Some glazes pulled back from the surface and left bare patches. He suspected dust on the bisque ware and glaze applied too thickly. Wiping the pieces with a damp sponge before glazing helped.

**Kiln results.** Colors came out different from what I expected. He keeps telling me that a glaze is a recipe plus a firing, and I only control half of that unless I understand the kiln I use.

**Motivation.** After a bad firing I sometimes stop for weeks. He does not make a big deal of it. He says the pots will wait.

## References

These are the sources I lean on, apart from Genketh himself. None of them replaces him, but they help me prepare.

- My own notebook of visit summaries, kept in paper form and copied here when something is worth keeping.
- A few old studio pottery books that he lent me and that I still have not returned. I should return them.
- A folder of photographs of my finished pieces, sorted by firing.
- A short handwritten list of clay body names and the temperatures he prefers for each.
- Notes from a community studio workshop I attended before I met him, which covered the basics of hand building.

When I cite something he told me, I mark it as his advice and not as general fact. He has strong opinions, and some of them are particular to his studio, his clay, and his kiln. For instance, his advice on drying times works in his dry shed and may not work in my damp cellar.

I also keep a list of the people he has mentioned who might be worth meeting. He knows several potters, a glaze chemist, and a woman who builds kilns. I have not contacted any of them yet. I want to ask him first whether he would introduce me, because I would rather be introduced than arrive cold.

## Observations

Over the years I have noticed some patterns in how Genketh teaches.

He rarely gives the answer directly. He asks what I think happened, lets me guess, and only then adds what is missing. It irritated me at first. Now I see that I remember those answers much better.

He works slowly and expects me to. When I rush he does not say anything; he just waits until I notice. This is more effective than a lecture.

He pays attention to small things: how I sit, how I wet my hands, how I cut the pot off the wheel. He says the large problems usually start in the small habits.

He is honest about my work. If a piece is poor he says so plainly, and if a piece is good he says that too, with no extra praise. Because of this, his compliments mean something.

He keeps his studio tidy in a working way, not a decorative way. Tools are where he can reach them without looking. I copied this habit and my own work improved.

He seems to enjoy teaching on weekends because the studio is quiet, and I think that is part of why weekends are the only option. It is not only about his schedule. He wants the room calm.

Our relationship has changed since 2016. At the start I was a beginner who needed everything explained. Now I am more like a younger colleague, though he still corrects me without hesitation.

## Risks

There are some risks in depending on one mentor, and I should be honest about them in my notes.

**Availability.** He is free on weekends only. If he is ill, travels, or gets busy, I have no fallback. I could go months without a lesson. To reduce this, I should keep practicing alone and build a few other contacts.

**Single viewpoint.** His methods are his own. I may be learning habits that work for him but not for everyone. Meeting other potters and comparing approaches would balance this.

**Age and health.** He works with heavy clay and long hours. I should not assume he will always be able to teach. I do not like thinking about it, but a note about risk should include it.

**Over-reliance.** If I wait for him to answer every question, I will not develop my own judgment. I try to test ideas at home first and only then bring the results.

**Studio access.** I fire some of my work in his kiln. If that stopped, I would need another way to fire, and the cost would be real. I should find a community studio or a nearby kiln I could use in an emergency.

**Misunderstanding.** Because we only meet in person, there is no written record of his advice unless I make one. I may remember things wrongly. Writing notes right after each visit lowers this risk.

**Strain on the relationship.** Asking for too much can wear a good mentorship down. I keep my requests modest.

## Costs

I try to keep a plain account of what this mentorship costs me. Genketh has never asked for a fee, but that does not mean it is free.

**Money for materials.** When I work at his studio I use his clay, and I pay him back by buying a bag for the studio from time to time. I also bring tea and something to eat. These are small amounts, but they add up over a year.

**Kiln firing.** When he fires my pieces together with his, I contribute something toward the electricity and the kiln wear. We agreed on this informally, and I always offer more than I think is needed.

**Travel.** Reaching him in person takes time and some fuel or a fare. Since he is available only on weekends, I give up weekend time that I could spend elsewhere. That is a real cost, and I accept it.

**Time at home.** Between visits I need to practice. That means hours at the wheel, and the clay and glaze I use during that time cost money too.

**Gifts.** At the end of the year I give him a piece of my best work or something useful for the studio. This is not required, but I want to show I value his help.

**Emotional cost.** Honest feedback is sometimes hard. I count this as a cost, though a worthwhile one.

Overall, the cost is modest compared to the value. A professional course in ceramics would cost far more and would not give me the personal attention I get from him.

## Tools

These are the tools I use most when working with Genketh, and what he has told me about them.

- **Wheel.** I use his wheel on weekends and a smaller one at home. He prefers a steady, slow speed for centering and says most beginners spin too fast.
- **Ribs.** He recommends a wooden rib for compressing and a metal one for refining. I have both.
- **Wire cutter.** For cutting pots from the wheel and checking the base thickness.
- **Needle tool.** For marking height and trimming the rim.
- **Trimming tools.** Loop tools in two sizes. He insists they be kept sharp.
- **Sponges.** A natural sponge for water and a small one for wiping bisque before glazing.
- **Calipers.** Used when making lids that need to fit a pot.
- **Brushes.** Wide ones for glazing and a thin one for decoration.
- **Kiln shelves and props.** I do not own these and use his, which is one reason I depend on his kiln.
- **Notebook.** The most useful tool I have. I write every correction and every glaze note.

He says tools matter less than attention, but he also says a good tool saves you from fighting the clay. His own tools are old and well cared for, and he has taught me to clean mine after every session. I follow that advice, though sometimes I am slower than I should be.

## Lessons

These are the lessons I have taken from Genketh, written in my own words.

1. Preparation matters. Well-wedged clay and a clean workspace prevent half of the problems before they start.
2. Slow down. Speed hides mistakes until the kiln reveals them.
3. Keep thickness even. Most cracking comes from uneven walls and uneven drying.
4. Test small. Try a new glaze on a tile before committing a full piece.
5. Record everything. A firing without notes teaches you very little.
6. Accept failure. Broken pots are information, not insults.
7. Finish things. A mediocre finished pot teaches more than ten perfect starts.
8. Look at other people's work. He often takes me to see other potters' pieces and asks what I notice.
9. Clean up. A tidy studio is part of the craft.
10. Be patient with the kiln. It does not care about my schedule.

Beyond technique, he has taught me how to learn. He says a mentor can point at the road but cannot walk it for me. That sentence stuck with me. When I get frustrated I remember it and go back to the wheel.

I also learned how to be a good student. Arrive on time, bring questions, do the homework, and say thank you. It sounds simple, but many people skip it.

## Overview

Genketh Vorkdios is a person in my life who matters a lot for my work. Here are the basic facts, stated exactly as I keep them:

- Name: Genketh Vorkdios
- Role: mentor
- Area: ceramics
- Contact: in person
- Availability: weekends
- Known since: 2016

He is the person who taught me how to throw pots properly and how to think about glazes and firing. I met him in 2016, and since then he has been the one I go to when something goes wrong or when I want to move to the next level.

Contact is in person only. He does not use messages much, though a short note to arrange a visit is acceptable. Availability is weekends, so every plan I make has to fit around that.

This note collects what I know about working with him, what I have learned, and what I should keep in mind. It is a research note in the sense that I am trying to understand how this mentorship works and how to make the most of it. I update it after significant visits.

If I had to describe him in one sentence: a patient, direct, and exacting teacher who prefers to show things rather than explain them.

## History

I met Genketh in 2016. At the time I had been making simple hand-built pieces at a community studio, and I wanted to learn the wheel. Someone there mentioned his name and said he occasionally took students.

The first visit was awkward. I brought a few pieces and he looked at them for a long time without speaking. Then he picked up the weakest one and asked me what I liked about it. I had no answer. He nodded and said we would start from there.

In the first year, I learned the basics: centering, opening, pulling walls, and trimming. Progress was slow. I wasted a lot of clay. He never complained about that.

In the following years I moved into glazing and firing. I started to understand why a pot that looked good wet could fail in the kiln. There were several bad firings, and he helped me work out what went wrong each time.

Some time later our relationship shifted. He began to treat me as someone who could make her own decisions about form and surface, and he commented more than he corrected. I still go to him for hard problems.

Over the years I have watched him work on larger pieces and commissions. That showed me what it means to run a ceramics practice, not only to make a good pot.

The history is long and mostly quiet. There were no dramatic moments. It was a steady accumulation of weekends, and I think that is how this kind of learning works.

## Ideas

Here are ideas I want to try or discuss with Genketh.

- Ask him to teach me how to mix a basic glaze from raw materials, rather than using only commercial glazes.
- Propose a small project together, such as a set of matching bowls, so I can learn how he plans a series.
- Ask whether I can watch a full kiln firing from loading to unloading, including how he judges the temperature.
- Try a different clay body and compare the results with my usual one.
- Visit another potter he respects and ask what they do differently.
- Start a journal of glaze tests with small tiles, each labeled and photographed.
- Practice making lids and handles, which I still find difficult.
- Ask him to critique a whole set of my work, not only single pieces, so I can see patterns.
- Build a simple drying box at home to control drying and reduce cracking.
- Find a way to give something back, perhaps by helping him prepare the studio before a fair.
- Write a short summary of what I have learned since 2016 and show it to him.

Not all of these will happen. I put them here so I can choose when I have the time and energy. I will raise one or two at the next suitable weekend visit and see which he likes.

## Supplies

This is the list of supplies I need for work with Genketh, and what is usually covered by whom.

**Mine to bring:**
- An apron and old clothes.
- A towel and a small bucket.
- My own tools in a roll.
- A notebook and a pencil.
- Tea or something to share.

**Provided at the studio:**
- Clay, which I top up by buying a bag now and then.
- Wheel, tables, and shelves.
- Kiln and kiln furniture.
- Basic glazes.
- Plastic sheeting and boards for drying.

**Kept at home:**
- Clay in sealed bags for practice.
- A small stock of glaze materials for tests.
- Sponges, brushes, and wire.
- A shelf with a plastic cover for slow drying.

I check my supplies the week before a visit so I do not arrive missing something. Running out of clay at the studio is embarrassing, and I do not want to depend on his stock for everything.

He likes to say that good supplies are the ones you know well. He uses the same clay and glazes for years and learns how they behave. I am trying to do the same, and I avoid changing too many things at once. When I change one thing, I know what caused the result.

## Contracts

There is no long formal agreement between Genketh and me, but there is one document worth recording. The contract date of Genketh Vorkdios is 2022-10-12. That is the date we wrote down the terms for the shared use of his kiln and studio space.

The terms were simple. I may use the studio on the weekends he is available. I contribute to the cost of firings and materials. I look after the space and clean up. Either of us can end the arrangement with a plain conversation, in person, as that is how we always talk.

I keep a copy of the paper with my notes. It is short, a single page, and written in everyday language. We made it because he wanted things clear, and I agreed it was a good idea. Clear terms protect the friendship as much as the work.

Since that date, there have been small adjustments, but nothing that changed the basic agreement. When something comes up, such as a change in firing contributions, we discuss it during a visit and I add a line to my notes.

It is worth remembering that the contract covers practical matters only. It does not describe the mentorship itself, which has been going on since 2016 and works on trust. The paper simply makes the practical side easy to manage, so we can both focus on the clay.

I review the arrangement once a year, around the end of the year when I give him a gift, to confirm that it still suits us both.
