---
type: log
status: active
project: piothlaeth-rebuild
area: ceramics
description: "Log about Vaespon Stavirk."
---

# Vaespon Stavirk log

## Setup

This is a running log of my dealings with Vaespon Stavirk. Vaespon is a supplier contact in the area of ceramics. I have known Vaespon since 2011, so most of what is written here is a long history of small orders, questions and favours rather than anything formal.

The practical details I need to keep in one place:

- Role: supplier contact
- Area: ceramics
- Contact: phone
- Availability: weekends
- Known since: 2011

Vaespon does not answer email reliably, and there is no point trying during the week. The phone is the only method that works. I call on a Saturday or Sunday, usually in the morning, and keep the call short and specific. If I leave a message, I say what I need and when I need it, and I wait for a call back instead of calling again the same day.

## Overview

Vaespon has been my main source for ceramic materials and finished pieces for a very long time. When I started out in 2011, I was buying small quantities and asking a lot of basic questions. Vaespon answered all of them patiently, and that set the tone for everything since.

What I value most is that Vaespon is straightforward. If something is not in stock, I hear it straight away. If a batch came out badly, I am told before I pay for it. That has saved me from several bad purchases and a few awkward conversations with my own customers.

Things I have learned about working with this contact:

- Prepare the list before calling. Vaespon prefers to go through everything in one go.
- Say clearly what the pieces are for, because the advice changes depending on the use.
- Ask about lead times every time, since they shift with the season.
- Confirm the arrangement out loud at the end of the call and write it down immediately afterwards.
- Do not expect a quick reply on a weekday. Plan orders around the weekend.

Since weekends are the only window, I now keep a short note on my phone with the items I want to raise, so I do not forget something and have to wait another week. This has made the whole relationship smoother. Missed items used to cost me a full week, and sometimes that delayed work for other people.

I also try to repay the reliability. I pay promptly, I give honest feedback on what I receive, and I pass on the names of people who might become new customers for Vaespon. After so many years, that kind of give and take is what keeps the arrangement working.

## Contracts

The most recent agreement with Vaespon Stavirk is dated 2025-06-21. It was settled by phone on a weekend, as always, and I wrote the terms down straight afterwards and kept them with my other supplier papers.

What I record for each agreement:

- What was agreed, in plain words, including the type of ceramic goods.
- The delivery arrangement and who is responsible for transport.
- How and when payment is made.
- What happens if a batch is faulty or arrives late.

I do not rely on memory for any of this. Even with a contact I have known since 2011, a written note avoids disagreements later. When the next renewal is due, I will go back to this entry, read through what was agreed, and prepare my questions before calling on a weekend.

One habit worth keeping: after any change to the arrangement, I add a line to this log the same day, so the history stays in order and I can see how the terms have moved over the years.
