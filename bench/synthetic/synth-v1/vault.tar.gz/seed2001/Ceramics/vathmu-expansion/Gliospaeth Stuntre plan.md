---
type: plan
status: active
project: vathmu-expansion
area: ceramics
description: "Plan about Gliospaeth Stuntre."
---

# Gliospaeth Stuntre plan

## Overview

This note is my working plan for dealing with Gliospaeth Stuntre, my supplier contact in the ceramics area. I have known Gliospaeth since 2019, and over those years the relationship has become one of the more dependable parts of my supply chain. The purpose of this plan is to keep everything in one place: how I reach them, when they are available, what is agreed, and what I still need to settle.

Key facts, so I do not have to search for them later:

| Property | Value |
|---|---|
| Name | Gliospaeth Stuntre |
| Role | supplier contact |
| Area | ceramics |
| Contact | phone |
| Availability | weekends |
| Known since | 2019 |

The main practical consequence is that Gliospaeth is reached by phone and only on weekends. Anything I need on a Monday has to be planned the weekend before. I do not send long written requests, because phone is the channel that works. If I need to confirm something in writing, I make a short note of the call afterwards and keep it with this plan.

The plan has five parts beyond this overview. Maintenance covers how I keep the relationship in good shape. Contracts records the agreement. Setup describes how I prepare for each call and order. Open questions lists what I do not know yet. Observations holds my own impressions from working together.

## Maintenance

Keeping a supplier relationship healthy takes small, regular effort. Since Gliospaeth is only available on weekends, I treat the contact as a routine rather than an emergency line.

What I do regularly:

- Call on a weekend, even when I have no urgent order, so the contact does not go cold.
- Keep a short list of topics before dialling, so the call is useful and brief.
- Write down what was agreed immediately after hanging up, while it is fresh.
- Pay attention to how the ceramics supply is going and mention problems early rather than letting them build up.
- Say thank you when something went well. It costs nothing and it has helped over the years.

What I avoid:

- Calling outside the weekend window, even if I am in a hurry.
- Asking for changes at the last minute.
- Leaving a long gap between calls. Since 2019 the best results have come from steady contact.

I also keep reference material close by. When a question comes up about equipment I use in the workshop, I look at [[Vorful radio receiver handbook]] first, because I often have the radio running during calls and sometimes have to adjust it to hear properly. It is a small detail, but a clear line matters when the only channel is the phone.

A rough rhythm that works for me: one planned call each month, one extra call when a larger order is coming, and one review of this note every few months to remove anything outdated.

## Contracts

The contract date of Gliospaeth Stuntre is 2018-02-18. That is earlier than the year I first met them in person, 2019, which I should remember: the paperwork came first, and the working relationship grew afterwards.

Points I keep in mind about the contract:

- It covers the supply of ceramics goods and nothing outside that area.
- Contact is by phone, and the agreement assumes weekend availability.
- Any change to the terms should be discussed on a call and then noted down by me.
- I should keep my own copy of the paper in a place I can find quickly.

I do not rely on memory for terms. Before any significant order I reread the contract and check that what I am asking for fits it. If it does not fit, I raise it with Gliospaeth first rather than assuming it will be accepted.

Things I want to check at the next review:

- Whether the terms still match how we actually work.
- Whether anything in the agreement refers to a way of contacting them other than phone.
- Whether the contract says anything about renewal, which I have not looked at carefully.

## Setup

This section describes how I prepare so that each weekend call goes smoothly.

Before the call:

1. Decide what I need: a new order, a check on an existing one, or just a catch-up.
2. Write down the questions in order of importance.
3. Have this note open, together with the contract.
4. Choose a quiet spot, as the phone line is the only channel and I want to hear clearly.
5. Keep paper and pen ready.

During the call:

- Start with a short greeting, as we have known each other a long time.
- Go through the most important point first.
- Repeat back anything that was agreed, so there is no confusion.
- Ask when the next good weekend would be for a follow-up.

After the call:

- Write a short summary with what was agreed and any promises on either side.
- Add anything unresolved to the Open questions section below.
- Update the Observations section if I noticed something worth remembering.

Small tools that help: a simple notebook kept by the phone, a reminder on my calendar for the weekend before any planned order, and this plan kept easy to reach. I do not need anything more complicated than that.

## Open questions

These are things I have not settled and want to raise on a future call.

- What is the best time of day on a weekend to reach Gliospaeth? Saturday and Sunday are both possible, but I do not know which is more reliable.
- Is there a backup way to reach them if the phone does not work on a given weekend?
- How far ahead do I need to place an order, given that I can only talk on weekends?
- Does the contract allow for adding other kinds of ceramics goods later, or would that need a new agreement?
- What happens if I need something urgent during the week? So far I have simply waited, but it would be good to have a plan.
- Is there someone else who can answer questions when Gliospaeth is unavailable?
- Should I review the contract together with Gliospaeth, rather than only by myself?

I will cross out each question once answered and move the answer into the correct section above.

## Observations

These are my own impressions after working with Gliospaeth since 2019. They are subjective, but they help me decide how to approach each call.

- Gliospaeth is reliable on weekends. When we agree on a time, the call happens.
- Phone works better than anything else. Conversations are quick and clear, and misunderstandings are rare when I repeat back the details.
- The relationship has grown steadily. The early period was more formal, and now it is relaxed while still being professional.
- Good preparation clearly pays off. Calls where I had my questions ready were shorter and more productive than calls where I improvised.
- Weekend-only availability is the main limitation. It is not a problem if I plan ahead, but it can be awkward when something unexpected happens in the middle of the week.
- Being consistent matters more than being clever. Regular contact, clear notes and honest communication have done more for this relationship than any special arrangement.

Next steps for me: confirm the best weekend time, reread the contract for renewal terms, and decide whether to ask for a second way of contact. I will update this plan after the next call.
