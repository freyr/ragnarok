---
type: log
status: archived
project: vathmu-expansion
area: ceramics
description: "Log about Zukriond loft."
---

# Zukriond loft notes 2020

This note is archived. It records the state of Zukriond loft in 2020. Later notes replace the values given here, so check the newer notes before relying on anything below.

## Costs

I did not keep exact receipts for the loft in 2020, so this section is about the kinds of cost and how they behaved, not about amounts.

The biggest running cost was electricity. The kiln and the drying racks were the main users, and the dehumidifier ran a close third. Because the loft is below ground, the lights are on whenever anyone is in it. Lighting is therefore a steady cost and not a occasional one.

The second cost was clay and glaze materials. I bought clay in large batches because the loft is large and has room for storage. Buying in bulk was cheaper per bag, but the bags at the bottom of a stack sometimes went hard. Next time I will buy less and more often.

The third cost was repairs. Mostly these were small: replacement shelf brackets, a new door seal, and sealant for the wall near the west side. I did not have any large unplanned repair in 2020.

A hidden cost was my own time. Cleaning the loft took longer than I expected because dust from dry clay settles everywhere in a large room. I count that as a cost even though no money changed hands.

For tool costs, the band saw I used for cutting wooden bats and boards is covered in [[Saenber band saw handbook]]. I only bought blades and nothing else for it that year.

## Risks

The main risks in 2020 came from the loft being below ground. Water is the first one. Even with no flooding that year, the walls can take on damp after long rain, and a below-ground floor has no easy way to shed water if something fails. I kept the lowest shelves off the floor for this reason.

The second risk is air quality. Dry clay dust, glaze powders and kiln fumes all stay in a room that has little natural air movement. A large room dilutes these better than a small one, but it does not remove them. I treated ventilation as a standing risk and not as a solved problem.

The third risk is fire. The kiln is the obvious source, but the wiring in a loft built in 1997 is old enough that I did not trust it fully. I kept flammable packing and card boxes well away from the kiln and away from the sockets.

The fourth risk is the stairs. Carrying wet work or heavy bags up and down is where I came closest to an accident. A slip with a full board of pots would be bad for me and for the work.

A smaller risk is the west orientation. Afternoon light can reach the upper part of the room and warm it, which makes drying uneven. Pots near the west wall dried faster than pots at the back, and the faster ones sometimes cracked.

Related notes on other places that I compared against: [[Trenvios shed plan]] and [[Krespa shed plan]] both have their own risk lists, which are different because those are sheds above ground.

## Checklist

This is the list I used at the start and end of each working session in 2020.

Start of session:
- Check the floor for damp or standing water.
- Switch on the dehumidifier and check that its tank is not full.
- Open the vent and check that the fan turns.
- Look at the kiln lid, the elements and the shelves for damage.
- Clear the walkway from the stairs to the wheel.
- Check that the lights work, including the one over the wheel.

End of session:
- Cover all unfinished work with plastic.
- Wipe the wheel, the table and the floor with a damp cloth. Never sweep dry.
- Seal the clay bags.
- Switch off the kiln at the wall and not only at the controller.
- Empty or note the level of the dehumidifier tank.
- Switch off the lights and close the door.

Monthly:
- Inspect the west wall for new marks.
- Check the door seal.
- Look under the lowest shelves.
- Tidy the glaze shelf and label anything unlabeled.

## Safety

Safety rules for the loft, as I followed them in 2020.

Wear a dust mask when mixing glazes, sanding dry work or cleaning up clay dust. A cloth mask is not enough for glaze powders. Keep the proper mask hung by the door so I do not skip it.

Wet-clean surfaces. Dry sweeping lifts fine dust into the air, and in a closed below-ground room it hangs there a long time.

Keep the kiln area clear. Nothing stored within arm's length on any side. The kiln gets hot enough to scorch a cardboard box left too close.

Never fire the kiln unless the ventilation is running. If the fan fails, I stop and wait. I do not open the door and hope.

Keep a fire extinguisher by the stairs, not near the kiln. If the kiln area is burning, I want my way out to be clear. I checked the gauge on it every few months.

Use the band saw only with the guard set properly and with the dust collection on. The handling rules are in [[Saenber band saw handbook]]. I do not use it when tired.

Because the loft is below ground, mobile phones have a weak signal. I told someone when I was working there alone, and I kept a landline-style plan: if something goes wrong, go up the stairs first and call from outside.

Lift with the legs. Clay bags are heavy and the stairs are narrow.

## Supplies

What I kept stocked in 2020.

Clay: several bags of stoneware body and one of a smoother white body for small pieces. I stored them on a pallet-style rack off the floor, with plastic over them.

Glazes: a set of ready-made liquid glazes and a smaller set of powders for mixing. Each jar has a label with the name and the day I opened it, though I do not record those days here.

Tools: wooden ribs, metal ribs, wire cutters, sponges, trimming tools, needle tools, a set of brushes and calipers. I keep the sharp tools in a roll so they do not get lost in clay.

Kiln supplies: shelves, props, stilts, kiln wash and a small stock of cones. I replaced worn props one at a time instead of waiting for a batch to fail.

Cleaning: buckets, cloths, a mop, a wet vacuum, and spare filters for the vacuum.

Wood and hardware: boards for bats, offcuts from the saw, screws, brackets and spare shelf supports.

Air and power: a spare fuse set, a spare extension reel, and a few spare filters for the dehumidifier and the fan.

For air tools, I used the notes in [[Taskras air compressor notes]] when I borrowed a compressor for spraying glaze. I did not buy one in 2020.

## Setup

Zukriond loft is a loft, built in 1997, and it sits below ground. It is large, and it faces west. In 2020 the main work area was ceramics.

The layout, from the stairs inward:

At the foot of the stairs there is a small landing and a coat hook. Past that, the floor opens into the main room. The wheel sits on the left, where the light from the west side is best. The wedging table is next to the wheel, so I can move clay from the bag to the table to the wheel without carrying it far.

The kiln stands against the back wall on a concrete pad, with clear space around it and the vent above. The vent runs out through the wall and is the only real air path in the room besides the door.

Shelving runs along the right-hand wall. The lowest shelf is raised off the floor. Drying work goes on the upper shelves, and finished work on the middle ones. Glazes and chemicals stay on a separate shelf at the far end, away from the stairs.

The dehumidifier sits near the foot of the stairs with a hose to a drain bucket. I placed it there so I can see the tank on the way in and out.

Because the loft is large, there was enough room for a separate corner for cutting wood and making boards. The band saw lives there. A larger plan for a similar workspace, built above ground, is in [[Zolbrel loft handbook]], which I used for ideas on shelving.

## Open questions

Things I had not settled by the end of 2020.

- Is the vent big enough for the size of the room, or does it only feel adequate because I run the kiln rarely? I would like a proper check from someone who knows airflow.
- Why does the west wall show marks after wet weather when the other walls do not? I suspect water gets in from outside on that side, but I have not found where.
- Should the kiln move to the other side of the room? It would be closer to the vent run but further from the stairs, which is worse in an emergency.
- Would a second dehumidifier help, or is better air movement the real answer?
- Can the heat from the kiln be reused to warm the room in winter? I read about a heat exchanger idea and have not tested it. Some related results are in [[Nedirk heat exchanger tests]].
- Is the old wiring from 1997 fit for the load of kiln, lights, saw and dehumidifier together? I should ask an electrician before I add anything else.
- Who could advise on damp proofing for a below-ground room? I have spoken informally to [[Serpi Muntran]] and [[Glendrol Naefur]], but I do not have a plan yet.

## Overview

Zukriond loft is a large loft below ground, built in 1997, with a west orientation. In 2020 I used it for ceramics. This note is a log of how it stood that year.

In short, the loft works well as a studio. It is large enough for a wheel, a kiln, a wedging table, drying shelves and a small wood corner without crowding. Being below ground keeps the temperature fairly even through the year, which helps clay stay workable. The same fact makes damp and air quality the two constant concerns.

The west orientation matters less than it would in an above-ground room, but it still shapes where the light falls and where work dries fastest. The wheel sits where the light is best and the drying shelves sit where the heat is gentlest.

The routine that kept the place in good order was simple: check the floor, run the dehumidifier, keep the vent working, wet-clean everything and cover the work. When I followed that routine, the loft stayed pleasant to use. When I skipped it for a few days, damp and dust showed up quickly.

This note is archived. Later notes replace the values here, so treat everything in it as the state of 2020 and nothing more.

## Maintenance

Regular maintenance I did in 2020.

Weekly:
- Wet-clean the floor, wheel and tables.
- Empty the dehumidifier drain bucket if it had filled.
- Wipe the kiln exterior and check the lid seat.
- Wash the sponges and buckets, and change the water.

Monthly:
- Clean the dehumidifier filter and check the hose for blockage.
- Check the fan and vent for dust build-up.
- Inspect the kiln elements and replace worn shelf props.
- Check the door seal and the stair handrail.
- Wipe the west wall and look for new marks.

Seasonal:
- Sort through the glaze shelf and throw out anything that has separated beyond use.
- Rearrange the clay stack so the oldest bags are used first.
- Sharpen cutting tools and replace the blade on the band saw, following [[Saenber band saw handbook]].
- Check the fire extinguisher gauge.

Yearly:
- Look at all the wiring I can see, including plugs and cables, for heat marks or cracks.
- Re-coat kiln shelves with wash.
- Review this checklist and fix anything that no longer matches how I work.

The rule I kept to: small jobs done often are better than large jobs done late. A below-ground room punishes neglect faster than a room above ground does.

## Problems

Problems I met in 2020.

Damp on the west side. After long wet spells, a patch of the west wall went dark near the floor and the air felt heavier on that side. It dried out when the weather turned, which suggests that water gets in from outside and does not come from a leak inside. I did not find the entry point.

Uneven drying. Work placed near the west wall dried faster than work placed at the back. A few pieces cracked at the rim because one side dried before the other. I fixed most of this by covering pieces loosely with plastic and moving them inward.

Hard clay at the bottom of stacks. Bags at the bottom of a pile dried out, probably because the plastic had small holes. I now check each bag when it goes onto the rack.

Dust. The wet vacuum helped, but fine dust still collected on high shelves. I need a better habit of wiping those, and not only the floor and tables.

Stale air. On days when I ran the kiln and the saw in the same session, the room felt close. I stopped doing both on one day.

Noise and vibration. The dehumidifier rattled against the wall until I moved it onto a thicker mat.

Stair clutter. Boxes crept onto the stairs more than once. I cleared them each time, but it kept happening. A fixed place for incoming boxes would help.

## Background

Zukriond loft was built in 1997 as a below-ground loft. It is large, and its main face looks west. I started using it for ceramics because it gave me more floor space than any shed I had looked at.

Before I chose it, I compared it with a couple of above-ground options. The plans for those are in [[Trenvios shed plan]] and [[Krespa shed plan]]. The sheds were cheaper to heat in theory and had better natural light, but they were smaller, and they swung hot and cold with the weather. The loft stays steadier, and that suited clay.

The loft had been used for general storage before I took it over. Because of that, the walls and floor were plain, and there was no built-in shelving. I added the shelves, set the layout and arranged the wiring extensions myself, though I would not call the electrical work finished.

Some of what I know about damp and air in below-ground rooms came from talking to [[Serpi Muntran]], who has worked in similar spaces. Advice on heat reuse and on how the kiln might warm the room came from [[Glendrol Naefur]], who suggested I look at heat exchange. I tried to read about it in [[Nedirk heat exchanger tests]].

For general ideas about how to organise a loft studio I also used [[Zolbrel loft handbook]], though its examples were above ground.

## Measurements

Properties of the loft, as recorded in 2020:

- Kind: loft
- Orientation: west
- Size: large
- Year built: 1997
- Floor: below ground

Measured humidity of Zukriond loft: 41.49 %

I took the humidity reading with a hand meter placed on the middle shelf, away from the dehumidifier and away from the kiln. I considered the reading acceptable for working with clay. Higher readings, especially after rain, made the air feel heavy and slowed drying, while much lower readings made work dry too fast near the west wall.

I did not take a full set of readings across the year, so this one value is the figure I trust for 2020. I did not measure the room's floor area in a way I could trust, so I have recorded only the size as large. For the same reason, I have not given temperature figures here.

If I take more readings later, they will go in a newer note, and that note will replace this one.

## References

Notes and handbooks I used while keeping the loft in 2020:

- [[Saenber band saw handbook]]: for blade changes, guard settings and dust collection on the saw in the wood corner.
- [[Taskras air compressor notes]]: for the borrowed compressor I used when spraying glaze, and for general air tool care.
- [[Nedirk heat exchanger tests]]: for the idea of reusing heat from the kiln. I have not built anything from it.
- [[Zolbrel loft handbook]]: for layout and shelving ideas for a loft studio.
- [[Trenvios shed plan]]: a comparison for a shed-based studio.
- [[Krespa shed plan]]: a second shed comparison.
- [[Serpi Muntran]]: a contact for advice on damp and below-ground rooms.
- [[Glendrol Naefur]]: a contact for advice on kiln heat and airflow.

None of these notes replace the others. I read them for different things, and I kept them separate on purpose. If a newer note about the loft exists, it takes priority over this archived one.

## History

A short history of the loft as I know it.

1997: The loft was built. It is below ground, large, and faces west.

Before 2020: The loft was used as general storage. It had no shelving built for studio work, and the electrical supply was basic.

Around the time I took it over: I added shelving, set the wheel and table near the west side for light, and placed the kiln against the back wall with a vent through the wall. I also added the dehumidifier and a corner for wood cutting.

2020: The year this note covers. I ran the loft as a ceramics studio, kept a regular cleaning routine, and recorded the humidity reading in the Measurements section. I met problems with damp on the west wall, uneven drying and dust. I left several questions open, mostly about ventilation, wiring and damp proofing.

After 2020: Later notes will replace the values in this one. This note stays in the archive as the record of how the loft stood in 2020, and I do not edit it to match changes made afterwards.
