---
type: plan
status: active
project: vathmu-expansion
area: ceramics
description: "Plan about Trenvios shed."
---

# Trenvios shed plan

## Checklist

This is my working plan for Trenvios shed, the medium-sized shed I use for ceramics. It was built in 2022, it faces east, and it has a raised floor. I want to go through everything below before I settle the layout for the next season of work.

**Before I start**
- Walk through the shed in the morning, when the east light comes in, and note where it falls on the benches.
- Check the underside of the raised floor for damp, rot or gaps where mice could get in.
- Test that the floor boards are firm, especially near the door where the heavy bags of clay get dragged.
- Clear out old buckets, broken bats and cracked pots that I have been keeping for no reason.

**Layout**
- Put the wheel on the east side so I get the morning light on my hands and the clay.
- Keep the wedging table close to the clay storage so I carry less.
- Place the shelves for drying work away from the door, where the air is calmer and the pieces dry more evenly.
- Leave a clear path from the door to the kiln area, with nothing on the floor.
- Keep glazes on a low, sturdy shelf, since jars are heavy.

**Safety and upkeep**
- Keep a bucket and sponge by the door for wet footprints, since a wet raised floor gets slippery.
- Sweep dry dust as little as possible; wipe it up with a damp cloth instead.
- Check the door seal and the roof before the cold season.
- Put a fire extinguisher near the exit and check it once a year.

**After the work is done**
- Write down what worked and what did not in the layout.
- Mark any repairs to the raised floor and plan when to do them.

## Dimensions

The floor area of Trenvios shed is 304.98 m². That is what I have to work with, and it is a medium size for a ceramics shed, so I need to plan the space with care rather than fill it.

The shed faces east and the floor is raised, so I should measure the height of the floor above the ground before I plan any ramp or steps. I want to measure these things next:
- The width of the door, to be sure the largest shelf and the wheel fit through.
- The height of the raised floor at the door, to plan a ramp for hauling clay.
- The length of the east wall, to decide how many benches fit under the light.
- The space around the kiln, so there is a safe gap on every side.

I will write these measurements here once I have taken them.
