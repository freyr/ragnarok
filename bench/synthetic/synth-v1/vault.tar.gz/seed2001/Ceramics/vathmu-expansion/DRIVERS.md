---
type: drivers
status: active
project: vathmu-expansion
area: ceramics
description: "Drivers about Vathmu expansion."
---

# Drivers of Vathmu expansion

## Setup

Vathmu expansion is a project with the goal of expansion. It sits in the ceramics area, started in spring 2019, and the lead is the plumber. I keep this note as the place where I write down what drives the project: why it exists, what limits it, what it costs and how I tell whether it worked.

The goal is simple to say. The ceramics work outgrew the space and the water setup that served it at the start, and Vathmu expansion is the answer to that. It is about adding capacity, not changing what is made. Anything that does not add capacity gets pushed to a later project.

The lead is the plumber, and that is not an accident. Most of the real constraints in a ceramics space come down to water: supply, drainage, and what goes down the drain. Clay and glaze residue settle in pipes and block them, so the drain layout decides what can be built and where. The plumber signs off on layout first, and everything else follows from that.

Constraints I am working with:

- Spring start. The work began in spring 2019, when the studio was quieter and the ground was workable. Anything that needs the space to be dry or empty is planned around that season.
- Drainage first. No new sink, wedging area or glazing station goes in until the drain route is agreed.
- Nothing may stop the existing production. The current kilns and work tables keep running while the new part is built.
- Floor load and ventilation have to be checked before any new kiln position is fixed.

How success is measured:

- The new space is in regular use and not just built.
- Drains run clear without being cleared by hand every few weeks.
- Output goes up without the old area becoming more crowded.
- The spending stays inside the budget below, or any overrun is written down with a reason.

## Budget

The budget of Vathmu expansion is 30115.42 EUR.

That figure is the ceiling for the whole project, not just for the first stage. I treat it as covering plumbing and drainage, the building work, any electrical changes for kilns, ventilation, and the furniture and shelving needed to use the space. Because the plumber leads, the plumbing and drainage lines are the ones I expect to be settled first and to be the hardest to change later.

How I handle it:

- Plumbing and drainage get the largest share and are costed before anything else.
- I keep a small reserve inside the total rather than on top of it, since hidden pipe problems are the most likely surprise.
- Every spending decision is written down with a short reason, so I can look back and see why a line grew.
- If a line passes its share, something else has to shrink or wait. The total does not move without a note here explaining it.

## Maintenance

An expansion that cannot be kept up is a poor expansion, so I plan the upkeep from the start rather than after the first blockage.

- Traps and settling tanks on the drains are emptied on a fixed routine. Clay slip is never rinsed straight into the pipes.
- The plumber checks supply lines and drain runs once a year, and I would rather do this in spring, matching the original start of the project.
- Ventilation filters and fans are cleaned on a schedule, and the kiln area is kept clear of clutter.
- A simple log lives with the project: what was checked, what was found, what was fixed. It helps the next person understand the system without guessing.
- Spare fittings and a few common pipe parts are kept on a shelf, so a small leak does not stop work for days.

I also want a short map of where every pipe, valve and shut-off runs. Without it, even a small repair turns into opening walls to find things.

## Open questions

- Is the drain capacity enough if the ceramics output grows more than planned, or will a second settling stage be needed?
- Which part of the budget is most exposed to surprises, and is the reserve inside the total large enough for it?
- Should the yearly plumbing check be done by the lead or handed to someone else once the build is finished?
- How should I measure output growth in a way that is easy to repeat, without a lot of extra bookkeeping?
- Is there any part of the old space that should be retired now that the new part exists, to avoid paying to keep both?
- Does the ventilation need to be upgraded if more kilns are added later, and who decides that?
