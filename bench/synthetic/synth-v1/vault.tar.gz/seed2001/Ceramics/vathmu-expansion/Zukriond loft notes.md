---
type: note
status: active
project: vathmu-expansion
area: ceramics
description: "Note about Zukriond loft."
---

# Zukriond loft notes

## Safety

Zukriond loft is a large loft built in 1997, and it sits below ground. That one fact drives most of my safety habits. A below-ground room with the kiln running needs fresh air, and the only way out is the one stair, so I keep that stair clear at all times.

- Keep the stair free of boxes, buckets and drying boards. Nothing gets parked on the bottom step.
- Open the vent before I light or start anything that makes heat or fumes, and leave it open until the room has cooled.
- Never work alone while glazing with powders. Dust hangs in the air down here longer than it would upstairs.
- Wear a proper mask for dry materials. Wet sponging is the default for cleaning surfaces, and I never sweep dry.
- Keep the fire extinguisher by the stair, not by the kiln. If the kiln is the problem, I need to reach it without walking past the kiln.
- Check the floor drain for blockage before any big wash-up. Clay slip in the drain is a slow disaster.

Because the loft is below ground, a power cut means total darkness. A battery lamp lives on a hook by the stair. It is topped up with the setup described in [[Glaendfior solar charger notes]], which I should keep using for that purpose.

## Ideas

Things I want to try in the loft, in no particular order:

- Add a second, lower vent so air actually moves through the room instead of only at the top.
- Build a slatted damp cupboard along the west wall for slow-drying large pieces. The west orientation means the wall gets warmer in the afternoon, which could help or hurt. I need to watch it.
- Put a rolling cart under the glazing bench so I can move finished work toward the kiln without carrying.
- Paint the ceiling white. The room is large, but being below ground it always feels dim, and the light would help me judge glaze colour.
- Hang a simple wall chart of firing programmes next to the kiln, written by hand, so I stop looking them up in my phone with dusty fingers.
- Add a small sink trap or settling bucket stage before the drain to catch clay.
- Link the kiln controller notes with this note so the room setup and the firing setup are in one trail. See [[Triondfis kiln controller notes]].
- Try a dehumidifier on a timer, only if the measurements below keep drifting upward.
- Make a tidy tool wall with outlines drawn behind each tool, so missing tools show at once.

None of these is urgent. The vents and the lighting would make the biggest difference to daily work, so those come first.

## Measurements

The basic properties of the place, stated plainly:

- Kind: loft
- Area: ceramics
- Orientation: west
- Size: large
- Year built: 1997
- Floor: below ground

Measured humidity of Zukriond loft: 57.55 %

That reading was taken in the middle of the room, away from the kiln and away from the damp cupboard idea. For a below-ground room that is a fairly comfortable number for working clay, though a bit high for storing dry bisque and powders. Raw glaze materials clump if left open, so the lids stay on.

Other things I measure by eye and by habit rather than with instruments:

- Walls: slightly cool to the touch, with no running water. A dark patch near the corner behind the shelves is worth checking after heavy rain.
- Air: stale if the vent has been shut for a day.
- Light: poor in the morning, better in the afternoon because of the west side.

If I ever get a proper logger I will put it on the shelf above the bench and compare it with the hand reading.

## References

Notes and sources I use when working in the loft:

- [[Triondfis kiln controller notes]] for firing programmes, ramp settings and the controller's quirks.
- [[Glaendfior solar charger notes]] for the battery lamp and the small charger that keeps it ready.
- My own glaze recipe notebook, kept on the shelf by the stair. It is paper, so it survives power cuts.
- The kiln's printed manual, stored in a plastic sleeve in the top drawer of the bench.
- A basic checklist I wrote for opening and closing the loft, copied below so I do not have to hunt for it.

```yaml
loft_checklist:
  opening:
    - clear the stair
    - open the vent
    - check the lamp
    - check the drain
    - look at the kiln lid and bricks
  closing:
    - kiln off and logged
    - lids on all glaze buckets
    - wet-wipe the bench
    - floor damp-mopped
    - vent left open a little
    - lamp back on its hook
```

I keep that list short on purpose. A long checklist gets ignored.

## Schedule

My routine for the loft, kept loose but regular:

- Early in the week: clean and tidy, check the drain, wipe shelves, throw out dried scraps.
- Midweek: main making sessions. Wedging, throwing and hand-building happen here while the air is still fresh and the room is not full of dust.
- Late in the week: glazing, then loading the kiln. I prefer to start a firing in the afternoon and be upstairs when it runs, checking in rather than staying down.
- Weekend: unload, assess results, write up notes. Cooling must be finished before I open the kiln, and I do not rush it.
- Once a month: wash the walls near the damp corner, check the vent screens, test the lamp, and read the humidity again.
- Twice a year: deep clean. Everything off the shelves, floor scrubbed, bricks and shelves in the kiln inspected.

The schedule shifts when a commission arrives. In that case I drop the tidy day first and keep the safety checks, never the other way around.

## Costs

I do not track exact figures in this note, only the shape of the spending.

- Biggest recurring cost: electricity for the kiln. A full firing is noticeable on the bill, so I fill the kiln properly before starting it.
- Second: clay and glaze materials. Buying clay in larger amounts is cheaper per piece, but storage below ground needs care because of the humidity.
- Occasional: kiln furniture, such as shelves and props, which crack over time and must be replaced.
- Small but constant: sponges, masks, filters, bags, bucket lids, tape.
- One-off items from the ideas list: vent work, paint and shelving. The lower vent would be the most expensive of those because it means cutting through a wall.

A rough rule I follow is to spend on safety first, then on things that save firings, and last on convenience. A dehumidifier would sit in the last group unless the readings force it into the second.

## Lessons

What the loft has taught me so far:

- A below-ground room hides problems. Stale air, damp and dim light all creep in slowly, so a regular check matters more than a clever fix.
- Humidity near the middle of the range is fine for work, but it is not the same as fine for storage. Keep powders sealed.
- Keep one clear route to the stair. Everything else can be rearranged.
- The large size tempts me to spread out. Messy spreading costs more time in cleanup than the space ever saves.
- The west orientation matters mostly through the afternoon warmth on that wall. I should not assume the loft stays at one temperature all day.
- Writing firing results immediately, while the pieces are still in my hands, is much better than trying to remember.
- Do not trust a single reading. One measurement is a clue, not a fact.
- A paper notebook beats a screen with powder on my fingers.

## History

The loft was built in 1997, and I only know its early life from what the structure shows. It is a large room below ground, and the thick walls and the single stair suggest it was meant for storage or workshop use rather than living space. Nothing in it suggests a previous ceramics setup, so the drain, the vent and the electrical lines I use were probably added or adapted later.

When I took the space over, the first jobs were clearing it, checking the walls for damp, and finding where the air actually moved. The kiln went in after the electrics were checked. The bench was built from what I could carry down the stair, which is why it is made in sections.

Since then the loft has slowly turned into a working ceramics room. The notes in this vault trace that change: first the safety habits, then the firing control described in [[Triondfis kiln controller notes]], and later the backup lighting described in [[Glaendfior solar charger notes]]. The next stage is the ventilation and the damp cupboard, if the ideas above survive contact with the budget.
