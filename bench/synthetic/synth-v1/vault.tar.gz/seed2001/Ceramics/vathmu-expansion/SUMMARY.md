---
type: summary
status: active
project: vathmu-expansion
area: ceramics
---

# Summary of Vathmu expansion

This is the summary note for Vathmu expansion. It is a project with the goal of expansion, in the ceramics area, started in spring 2019. The lead is the plumber. The project is past planning and in the build stage, since the go decision is made. Most of the groundwork is done. What is left is the water side of the work and a few loose ends on equipment.

## Costs

I am not tracking exact prices here. Those live in the receipts folder. This section only records where the money has gone and where it is likely to go next.

The biggest spending so far went on pipework and fittings, because the plumber insisted on buying the full run at once rather than piecemeal. That was the right call. Buying in one go avoided mismatched fittings, which cost me extra on an earlier job.

The second area is power and air. I compared the options in [[Taskras air compressor notes]] and [[Drirvuth air compressor notes]]. The cheaper unit would have needed replacing early, so I leaned toward the sturdier one. The final choice is still partly open, see Problems.

The third area is heat. The [[Navis heat exchanger]] is the most expensive single item still to be installed. I want it fitted properly the first time, so I am not trimming this line.

Things that could push costs up:

- Extra pipe length if the layout changes again.
- A larger compressor than planned.
- Rework if the drainage slope turns out wrong.

Things that keep costs down:

- Reusing offcuts and brackets from the old setup.
- Doing the unskilled labour myself.
- Keeping the plumber's visits short and planned, with the materials ready before he arrives.

## Problems

The open problems are listed here in rough order of how much they block.

1. **Drainage slope.** The floor in the new room is not as level as the plan assumed. The plumber wants to confirm the fall before any pipe is fixed in place. Until that is settled, the water work cannot be finished.
2. **Compressor choice.** Both compressors I looked at have drawbacks. One is louder than I want for a room where I will work for long hours. The other draws more power than the current supply likes. I need to decide, or else upgrade the supply.
3. **Heat exchanger placement.** The spot I picked is close to the wall that gets damp. I may need to move it, which affects the pipe run again.
4. **Power backup idea.** I considered running some light loads from solar, based on [[Glaendfior solar charger notes]]. It is not realistic for the main equipment, so it stays a side idea for lighting and small tools only.
5. **Space for storage.** The new room is bigger, but shelf space for glaze and clay is still unplanned.

None of these is a stopper on its own, but the first one gates the others. The slope question has to be answered first, and the placement of the heat exchanger follows from it.

## Supplies

Supplies are tracked by status. The table below is the working list. "Needed" means not yet bought. "On hand" means in the workshop already.

| Item | Purpose | Status | Related note |
| --- | --- | --- | --- |
| Pipe and fittings | Water supply and drain | On hand | [[Fiornio workshop]] |
| Heat exchanger | Heating for the new room | Needed, delivery pending | [[Navis heat exchanger]] |
| Air compressor | Tools and spraying | Undecided | [[Taskras air compressor notes]] |
| Spare air compressor option | Fallback choice | Undecided | [[Drirvuth air compressor notes]] |
| Timber for racks | Shelving for clay and glaze | Needed | [[Krespa shed plan]] |
| Small solar charger | Lighting and hand tools | Optional | [[Glaendfior solar charger notes]] |
| Sealant and tape | Joints and damp areas | On hand | none |

The timber for racks follows the same approach as the [[Krespa shed plan]], where I used simple frames and cut everything from standard lengths. That kept waste low, and I want to repeat it here.

For the greenhouse-style warm corner, where I might dry pieces slowly, I looked again at what worked in the [[Kaerksa greenhouse]]. Slow, even drying mattered more than raw heat. I will keep that in mind when I decide how to run the heat exchanger.

Most of the plumbing material is already in the workshop, so the delivery that matters is the heat exchanger. I should check that it has shipped before the plumber books his next visit.

## Decisions

These are the decisions made so far, with the reasoning, so I do not reopen them without a reason.

- **Go decision.** The go decision for Vathmu expansion was made on 2025-12-25. I held back until the layout was agreed with the plumber and I knew the project would fit in the space. After that date the work moved from planning to build.
- **Plumber leads.** The plumber leads the project. He sets the order of work for water, drainage and heat. I handle supplies, access and clean-up. This avoids two people giving different instructions.
- **Buy pipework in one go.** All pipe and fittings were bought together to keep sizes consistent.
- **Spring start stays as the reference.** The project started in spring 2019 as a small idea and grew over the years. I treat spring as the natural working season, because the damp problems are easiest to see and fix then.
- **Expansion, not a rebuild.** The goal stays an expansion of the existing ceramics space. I will not tear out working parts of the old room unless the plumber says it is unavoidable.
- **Solar stays minor.** Solar is limited to small loads. The main equipment stays on the normal supply.
- **Shelving copies the shed approach.** Racks follow the simple frame method from the shed plan.

Decisions still open are the compressor model and the final spot for the heat exchanger. Both depend on the slope check, so I will decide them after it.

## Next action

The next action is NX-6682. It is the first thing to do before anything else on this project moves. When it is done, I will update this summary with the result, then return to the open points in Problems, starting with the compressor choice and the heat exchanger position.
