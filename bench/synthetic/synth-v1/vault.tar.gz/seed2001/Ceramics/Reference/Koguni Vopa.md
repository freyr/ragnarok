---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Koguni Vopa."
---

# Koguni Vopa

## Safety

Koguni Vopa is my mentor in ceramics, and most of what I know about safe studio habits came from him. We meet in person, usually on weekends, so the safety rules below are the ones he repeats at the studio.

- Wear a dust mask whenever I sand dry clay, mix dry glaze, or sweep the floor. Dry clay dust is the main hazard in a ceramics space, and he is strict about it.
- Wet-wipe the tables and mop the floor. Never dry sweep.
- Keep glaze ingredients labeled. Some contain metals that should not touch food surfaces or skin for long.
- Open the kiln only when it is cool enough to touch the outside. Wear gloves and eye protection when unloading, because sharp shards can fall out.
- Keep the kiln room clear of paper, cloth and boxes. Ventilate the room during every firing.
- Wash hands before eating or drinking, and never eat in the studio.
- Lift heavy clay bags with the legs, not the back. Ask for help with the big ones.

He says most accidents in a studio are boring ones: a slip on a wet floor, a cut from a broken pot, a cough from dust. Boring habits prevent them.

## Costs

Koguni does not charge me for mentoring. We have known each other since 2020, and the arrangement has always been informal. Still, a few costs come with working with him, and I keep track of them so that I never take his generosity for granted.

- Materials: I pay for my own clay, glazes and any special tools. I buy clay in larger quantities because it is cheaper per kilogram that way.
- Kiln time: when I use his kiln, I offer to cover a share of the electricity and the shelf space. He usually waves it off, so I leave a contribution anyway.
- Travel: the studio is a trip away, and weekends are the only time we both are free, so the travel cost is part of my budget.
- Small gifts: coffee, pastries, and sometimes a book on glaze chemistry. This is not required, but it feels right.

If I ever need a paid class or a rented bench, I would ask him first. He knows who runs fair studios and who does not.

## Open questions

- Would he be willing to teach a short course on glaze testing for a small group, and if so, how would we split the work?
- Is there a better time than weekends for long firings? Weekends suit him, but a firing can run through the night.
- How much longer does he plan to keep his own studio open? He has hinted at slowing down.
- Which of his older notebooks would he let me copy? He keeps handwritten glaze recipes and I would like to preserve them.
- Should I start a small shared log of our sessions, so that his advice does not get lost?
- Can I bring a friend to a session, or does he prefer to work one to one?

## Observations

Some things I have noticed about Koguni over the years since 2020:

- He teaches by asking questions. When I ask why a pot cracked, he asks me to describe each step first, and I usually find the mistake myself.
- He prefers simple forms and honest surfaces. He distrusts decoration used to hide a poor shape.
- He is patient with beginners but expects me to repeat an exercise until it is clean. He once had me throw the same cylinder for a whole afternoon.
- He keeps tidy records. Every test tile in his studio has a mark on the back and a matching line in a notebook.
- He is reachable mainly in person. He does not like long messages, so I save my questions for the weekend.
- He remembers what I struggled with months earlier and brings it up at the right moment.
- He is always honest about failures, including his own. A ruined kiln load is something he talks about without embarrassment.

The pattern is that he values process over results. A good pot is the outcome of good habits.

## Contracts

There is no formal teaching contract with Koguni, but there is one written agreement that matters. The contract date of Koguni Vopa is 2019-04-18. It covers the use of shared studio space and the basic rules for the kiln, and it is the document that first connected me to his workshop before our mentoring began in earnest in 2020.

What the agreement says, as I remember it:

- I may use the shared bench and the wheel during agreed hours.
- I am responsible for cleaning my area after each session.
- Any damage I cause to the kiln or the tools must be reported to him at once.
- Either of us may end the arrangement with a simple notice.

I keep a copy in my paper folder. If the terms ever change, I will write the new version down and ask him to confirm it in person, since that is how we handle everything.

## Tools

These are the tools I use most when I work with Koguni, and the way he taught me to care for them.

- Wheel: a sturdy electric wheel at his studio. He taught me to center the clay with firm, slow pressure and to keep my elbows braced against my body.
- Ribs: wooden and metal ribs for shaping walls and smoothing surfaces. He prefers a flexible steel rib for finishing.
- Trimming tools: loop tools that I keep sharp. A dull tool tears the clay and leaves a rough foot.
- Wire cutter: for cutting clay blocks and for removing pots from the wheel head.
- Sponges and chamois: for smoothing rims. He insists on washing them at the end of every session.
- Calipers: for matching lids to pots. I measure twice before I commit.
- Kiln: a top-loading electric kiln. I do not run it alone. I only load it, and he handles the firing schedule.
- Test tiles: small clay samples for trying glazes before applying them to real work.

He says that good tools help, but patience matters more. I keep my own set in a labeled box so nothing gets mixed up with his.

## Lessons

The most useful lessons from Koguni, collected in the order I learned them:

1. Prepare the clay properly. Wedging removes air and makes the clay uniform. Skipping it causes trouble later in the kiln.
2. Center first, then everything else. If the clay is not centered, no later step will fix it.
3. Keep walls an even thickness. Uneven walls dry unevenly and crack.
4. Dry slowly. Cover pots loosely and let them dry over several days, especially thick bases.
5. Test every glaze on a tile before using it on a finished piece. Write down the recipe and the firing used.
6. Take notes after every session, including failures. The notebook is what turns practice into skill.
7. Do not hurry the kiln. A rushed firing ruins more work than a bad pot ever does.
8. Accept loss. Some pieces will break or warp, and the right response is to ask what they taught me.

The bigger lesson is about attitude. Koguni treats ceramics as a long conversation with the material. As a mentor in ceramics, whom I have known since 2020 and meet in person on weekends, he has shaped how I work more than any book. I plan to keep learning from him for as long as he is willing to teach.
