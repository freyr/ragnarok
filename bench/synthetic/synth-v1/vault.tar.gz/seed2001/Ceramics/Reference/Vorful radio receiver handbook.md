---
type: reference
status: active
project: reference
area: ceramics
---

# Vorful radio receiver handbook

## Open questions

These are the things I still do not know about the Vorful radio receiver. I keep them here so I can check them the next time I am in the workshop with the set in front of me.

- Why does the yellow casing feel slightly warmer on the left side after a long session? I suspect the battery compartment sits there, but I have not opened it to confirm.
- How long does one battery really last when the set runs all day beside the kiln? I have a rough feeling but no measured figure, and I want to keep a proper log.
- Is the faint hum on the low end of the dial coming from the receiver itself, or from the wiring of the workshop? It changes when I switch off the wheel motor, which points to the wiring, but I am not sure.
- Does dust from dry clay affect the tuning knob over time? The knob has felt stiffer lately, and the workshop is a dusty place for any electronics.
- Would a longer antenna wire help reception on the far side of the room, near the glazing table?
- What is the best place on the shelf to keep it so that steam from drying racks does not reach it?

I want to answer each of these with a short note and then remove it from this list. Until then, I treat the answers as unknown and do not rely on guesses when I explain the set to anyone else.

## History

The Vorful radio receiver is a radio receiver that I installed in the workshop in 2025. The workshop is where I do all my work in ceramics, so the area of the device is ceramics in the sense that it lives and works among clay, glaze and kiln. It is yellow, which was part of why I picked it: it is easy to spot on a shelf covered with grey and brown pots, and I do not lose it under a pile of cloths.

The energy source is battery. That was a deliberate choice. The workshop has few sockets, and most of them are already taken by the wheel, the lamp and the kiln controller. A battery set can sit anywhere, and I can move it closer to whatever I am working on without dragging a cable across a floor that is often wet.

Here is a short summary of the properties, so that I have them in one place:

- Kind: radio receiver
- Area: ceramics
- Color: yellow
- Energy source: battery
- Year installed: 2025
- Location: workshop

When I first set it up, I tried it on three different shelves before I settled on the current one. The first shelf was too close to the sink and got splashed. The second was too near the kiln and the casing became uncomfortably warm. The third, on the wall opposite the wheel, gave good reception and stayed dry, so it stayed there.

In the first months I used it mostly for talk programs while throwing pots, because the voices cover the sound of the wheel without being distracting. Later I started to leave it on during glazing too, as the work is slower and quieter and music fits better. Over time it became part of the normal rhythm of the day, and I now notice at once when it is off.

I have not made any repairs or modifications since the installation in 2025. Everything I describe in this handbook is therefore the set as it came, with only the battery replaced when needed.

## Observations

These are the practical things I have noticed while using the Vorful radio receiver in the workshop.

**Reception.** The signal is steady near the shelf and in the area around the wheel. It becomes weaker toward the glazing table, and it gets worse when the kiln is firing, probably because of the controller and its relay. If I need a clean signal during a firing, I move the set a little toward the door.

**Sound.** The speaker is clear for voices and a little thin for music. At low volume it is perfectly comfortable. At high volume the yellow casing buzzes slightly, so I keep it at a middle level. The wheel motor is louder than the set at low volume, so on throwing days I raise it a bit, and then lower it again afterward.

**Battery.** Because the energy source is battery, I pay attention to how it behaves:

- The sound gets quieter and a little distorted before the set stops, so there is a warning.
- Cold mornings in the workshop make the set start more slowly, and the first minutes can sound weak.
- When I leave it on overnight by mistake, the battery is clearly emptier the next day, so I try to switch it off at closing.

**Casing.** The yellow color has stayed bright. A film of clay dust settles on it within a day or two, and I wipe it with a dry cloth. A damp cloth works too, but I wring it out well and keep water away from the knob and the speaker grille.

**Controls.** The tuning knob moves smoothly in the morning and feels a bit stiffer after a dusty afternoon. The volume control is more reliable. I have not had any trouble with the buttons.

**Location effects.** Humidity in the workshop rises when the drying racks are full, and I have noticed that the sound is slightly duller on those days. It returns to normal when the room dries out. Heat is the other factor: the warmest part of the day, near the kiln, is the one time I would not trust the set to stay in place on its shelf without a check.

Overall, the set does what I need. It is simple, it has lasted since 2025, and it fits the way I work in the workshop.

## Safety

Safety in a ceramics workshop is mostly about dust, water and heat, and the Vorful radio receiver has to be kept away from all three as much as possible. These are my own rules, written from experience and not from any official guidance.

**Water and wet hands.** The set runs on battery, so there is no mains cable to worry about, and that removes the worst risk of mixing electricity and water. Still, I do not handle it with dripping hands. I rinse and dry my hands first, or I use a clean cloth. I never place it on the sink edge or on a surface where slip or glaze water collects.

**Heat.** The kiln gets very hot, and so does the air around it. A battery should not be kept somewhere warm, because heat shortens its life and can make it leak. I keep the receiver well away from the kiln and from any hot piece cooling on a rack. If the yellow casing feels hot to the touch, I switch it off and move it.

**Dust.** Dry clay and glaze dust are bad for the lungs and also for electronics. I do not blow dust off the set with my breath or with compressed air, because that puts the dust into the air and into the workings. I wipe the casing with a cloth instead, and I do it away from where I am working.

**Glaze materials.** Some glaze materials are toxic. I do not touch the set with glazed fingers, and I never put it down on the glazing table where powders may be spilled. Anything that touches the casing might end up on my hands later, near my mouth.

**Battery handling.**

- Replace the battery with the same type, never a mixed set of old and new.
- Take out a battery that is empty and do not leave it inside the set for weeks.
- Do not throw used batteries into the general waste bin; take them to a proper collection point.
- If a battery leaks, wear gloves, wipe the compartment, and dispose of the cloth carefully.

**Placement.** The set stays on a stable shelf, not on the edge, so that it cannot fall onto the floor or onto a work in progress. A falling battery set can break and spill its contents. I also keep the cord-free space around it clear so that nobody has to reach over the wheel to turn it off.

**If something seems wrong.** A burning smell, unusual warmth, a swollen battery or smoke means I switch the set off at once if I can do it safely, take the battery out with gloves or a cloth, and leave it outside on a non-flammable surface. I do not use the receiver again until I have found the cause.

## Schedule

This is the routine I follow to keep the Vorful radio receiver in good condition in the workshop. It is not strict, but I try to keep to it, and I adjust it when the season changes.

**Every day**

- Switch the set on after I have opened the workshop and checked the kiln area.
- Check that it is on its shelf and not near anything hot or wet.
- Switch it off at closing, so the battery does not run down overnight.

**Every week**

- Wipe the yellow casing with a dry cloth to remove clay dust.
- Check the tuning knob and volume control for stiffness.
- Look at the antenna and, if it is movable, make sure it has not been bent or knocked.
- Listen to the sound at a middle volume and note any new hum, crackle or dullness.

**Every month**

- Open the battery compartment and look for dirt, damp or signs of leaking.
- Test the sound on low volume and high volume, and compare it with my memory of how it was before.
- Move the set a short distance and test reception in a few places in the workshop, including near the glazing table.
- Clean the shelf and the area around the set.

**Every season**

- Check how it behaves when the drying racks are full and when the room is cold, and write a short line about it in the log.
- Replace the battery if the sound has been weak for several weeks, even if the set still works.
- Review the list of open questions and see whether any of them can be answered or removed.

**Once a year**

- Compare the set with how it was in 2025, when I installed it, and note any wear on the casing, the knob and the grille.
- Decide whether the shelf is still the best location in the workshop, or whether a different place would be safer or give better reception.
- Go through the safety rules again and update them if my way of working in ceramics has changed.

**Notes on keeping the schedule**

I keep the log short: the date, what I checked, and one line on what I found. This makes it easy to see changes over time without turning the maintenance into a chore. If I skip a week because of a busy firing, I do not try to catch up on everything at once; I simply do the next item at the next convenient moment. The only things I never skip are switching the set off at closing and keeping it away from heat, water and dust, because those protect both the battery and the receiver.

## Problems

This section lists the faults I have actually seen with the Vorful radio receiver, the yellow unit that has sat in the workshop since 2025. It runs on battery power, and most of its trouble comes from that and from the ceramics dust in the room. I keep the list in rough order of how often each thing happens.

- **Weak or fading sound.** Usually the battery is running low. The sound gets thin before it stops, and the tuning seems to drift.
- **Crackling between stations.** This is normal to a degree, but loud crackling on a station that was clear yesterday usually means dust in the tuning dial or a dirty battery contact.
- **No sound at all.** First check that the battery is seated properly. Then check the volume knob, because it gets knocked when I move tools around the bench.
- **Dial feels gritty.** Fine clay and glaze powder get into the dial. It turns stiffly and sometimes jumps past the station I want.
- **Reception drops near the kiln.** When the kiln is running, the signal gets worse. Moving the receiver to the far end of the bench helps.
- **Sticky casing.** The yellow casing picks up a film from damp hands and glaze, and the buttons get tacky.

When something goes wrong, I work from the simplest cause to the hardest. Nearly every fault so far has been the battery, a contact, or dust. I have not yet needed to open the electronics, and I would rather not unless I have to, because the workshop is a poor place to leave a opened radio.

One more thing I noticed: the receiver does worse in cold mornings, when the workshop has not warmed up. The battery seems weaker then. I give it a few minutes before judging the sound.

## Risks

The main risks come from the workshop environment, not from the radio itself. Because it uses a battery and not mains power, there is no cord to trip over and no mains shock risk. That is part of why I chose it for the workshop.

- **Dust and silica.** Dry clay and glaze dust is unpleasant to breathe, and it also settles inside the receiver. Cleaning with a dry cloth stirs it up, so I wipe with a slightly damp cloth instead.
- **Water and wet clay.** Splashes from the wheel or the sink can get into the speaker grille. I keep the radio on the shelf, not on the working bench.
- **Heat.** The yellow casing can warp or fade if it sits near the kiln or in direct sun. I keep it well away from both.
- **Battery leakage.** A battery left flat inside the device can leak and corrode the contacts. This is the most serious risk to the radio itself.
- **Drops.** A fall from the shelf onto the concrete floor could crack the casing. I avoid putting it near the edge.
- **Distraction.** Loud sound can hide the noise of a machine or someone calling out. I keep the volume moderate while using the wheel or any power tool.
- **Old batteries.** Spent batteries should not go in the general bin. I keep a small tub for them and take it to a collection point.

None of these risks is large if I follow a few habits. The ones I actually care about are keeping the radio dry, keeping it cool, and never leaving a dead battery in it for long.

## Maintenance

I do maintenance in small, regular steps so that the radio never needs a big repair. The Vorful radio receiver is simple, so the routine is short.

**Weekly**

- Wipe the yellow casing with a slightly damp cloth, then dry it.
- Check that the volume knob and tuning dial move smoothly.
- Look at the speaker grille for clay dust and brush it gently with a soft brush.

**Monthly**

- Open the battery compartment and look at the contacts. If they look dull or have a white crust, clean them with a dry cotton bud.
- Test the sound at low, middle and high volume to hear any crackle.
- Check the casing for cracks, especially around the corners.

**When the battery is changed**

1. Switch the receiver off.
2. Remove the old battery and look inside the compartment for dust or leakage.
3. Wipe the contacts and let them dry fully.
4. Fit the new battery the right way round and close the compartment firmly.
5. Switch on and check that a known station comes in clearly.

If I will not use the radio for a long time, such as over a holiday closure, I take the battery out. This stops leakage and also saves the battery. I store the receiver in a clean plastic box on the shelf, away from the kiln and the sink.

I never use strong solvents or spray cleaner on the casing. They can cloud the yellow surface or get into the controls. Plain water on a cloth does the job. I also avoid pushing anything sharp into the dial, because that damages it faster than the dust does.

## Supplies

This is what I keep on hand so that I can look after the radio without a special trip. Everything here is cheap and easy to find, and most of it I already have in the workshop for other jobs.

- **Spare batteries.** I keep a fresh spare of the type the receiver takes, stored in its packaging in a cool drawer. I check the spare now and then so I am not caught out.
- **Soft cloths.** A few lint-free cloths, one for damp wiping and one for drying.
- **Soft brush.** A small, clean paintbrush works well for dust in the grille and around the dial.
- **Cotton buds.** For cleaning the battery contacts.
- **Small plastic box.** For storing the radio when it is not in use for a while.
- **Collection tub.** A sealed tub for used batteries until I can take them for proper disposal.
- **Dust mask.** Not for the radio, but I wear it when I clean the shelf where the radio sits, because the dust there is mostly fine clay.
- **Notebook.** A page for when the battery was changed and what I noticed about the sound.

I do not keep spare electronic parts. If the receiver develops a fault that cleaning and a new battery do not fix, I would look for a repair person rather than try to fix it myself. For that reason I have not bought a screwdriver set just for the radio.

When I run low on any of these, I add it to the general workshop shopping list so it gets bought with the clay and glaze, instead of as a separate order. The batteries are the one item I try never to let run out.

## Checklist

I use this list for the regular check, and again whenever the radio has been moved or sounds odd. It takes only a few minutes.

**Before use**

- [ ] The Vorful radio receiver is on its shelf in the workshop, away from the kiln and the sink.
- [ ] The yellow casing is clean, dry and free of cracks.
- [ ] The battery is fitted correctly and the compartment is closed.
- [ ] The volume is at a moderate level.
- [ ] A familiar station comes in clearly.

**Weekly**

- [ ] Wipe the casing with a slightly damp cloth.
- [ ] Brush dust from the grille and dial.
- [ ] Turn the dial through its full range to check for grit.

**Monthly**

- [ ] Inspect the battery contacts and clean them if dull.
- [ ] Check the spare battery is still sealed and in date.
- [ ] Look for signs of heat or water damage on the casing.
- [ ] Empty the used battery tub if it is getting full.

**Before a long break**

- [ ] Take the battery out.
- [ ] Clean the compartment and contacts.
- [ ] Put the receiver in its box and store it in a cool, dry place.

**If something is wrong**

- [ ] Check the battery first.
- [ ] Check the contacts for dust or crust.
- [ ] Move the radio away from the kiln and try again.
- [ ] Clean the dial and grille.
- [ ] If the fault stays, stop using the radio and look for a repair person.

## Ideas

These are things I want to try with the Vorful radio receiver, the yellow battery-powered radio that has sat in the workshop since 2025. I keep them here so I can tick them off over time.

- Keep the receiver on the shelf above the glaze bench, not on the bench itself. Glaze dust gets into everything, and a radio on the bench has already had one near miss with a splash.
- Make a small padded sleeve out of old towel for carrying it between the workshop and the yard. The yellow case is tough, but the tuning dial is the weak spot.
- Choose one station for kiln days and a different one for wedging and trimming days. Music with a steady beat suits repetitive work. Talk programmes suit long firing watches.
- Write the preferred stations on a card taped inside the cupboard door, so anyone borrowing the radio can find them without turning the dial for ten minutes.
- Test whether the radio picks up interference when the kiln controller is running. If it does, move the radio further along the wall and note the distance that works.
- Try a short wire aerial clipped along the window frame. The workshop has thick brick walls, and reception is worse on the side facing the yard.
- Keep a spare set of batteries in a sealed tub with a silica packet. Damp is the main enemy in the workshop, and batteries stored loose go flat faster.
- Consider a hook for hanging the receiver by its strap when the table is crowded with drying pieces.

Some ideas are probably not worth the effort. A permanent shelf with a power adapter is one of them, because the point of this receiver is that it runs on battery and can go wherever I am working. Mains cables across a ceramics workshop floor are a nuisance and a trip hazard.

## Setup

The Vorful is a radio receiver, and its energy source is battery. That decides most of how I set it up. There is no cable to route and no socket to find, so the setup is mostly about where it stands and how it is looked after.

**Placement in the workshop**

The receiver lives in the workshop. I keep it at about shoulder height on the shelf near the window. Reception is clearer there than low down near the floor, and the radio stays out of the way of clay, slip and water. The yellow colour makes it easy to spot in a dusty room, which is useful because I tend to put things down and forget where.

**Batteries**

Open the battery compartment on the back, fit the cells the right way round, and close the cover firmly. I check the contacts for corrosion each time I change cells. If I see a white crust, I wipe it away with a dry cloth and leave the cover open for a while. When the radio will be unused for a long stretch, for example over a holiday closure, I take the cells out completely.

**First tuning**

When I first installed it in 2025, I did the following steps in order:

1. Extend the aerial fully and stand the radio in its usual spot.
2. Turn the volume low, then sweep the dial slowly from one end to the other.
3. Note which stations come in clearly and write them on the card.
4. Rotate the radio a quarter turn at a time to find the best direction.
5. Mark the best position on the shelf with a small strip of tape.

**Keeping it clean**

Ceramics work produces fine dust that settles on every surface. I wipe the case with a slightly damp cloth, never wet, and keep the speaker grille clear with a soft dry brush. I avoid blowing into it, since that pushes dust inward. If clay or slip gets on the dial, I let it dry and then flake it off rather than rubbing it in.

## Background

I bought the Vorful because the old radio in the workshop finally gave up. That one needed a mains socket and a long cable, and it spent years behind the wedging table collecting powder. I wanted something that did not depend on the wall, since I move around between the wheel, the glaze corner and the kiln area, and I like having sound wherever I stand.

The Vorful is a plain radio receiver. It does one job, which is receiving broadcasts, and it does not try to be anything else. That suits a workshop. I do not want screens, menus or anything that needs updating. Hands covered in clay cannot operate fine controls, so large knobs matter more than features.

The bright yellow colour was partly a practical choice. In a room full of grey clay, white plaster and brown shelves, a yellow object is hard to lose. It also stands out against the dust, which reminds me to wipe it down.

Ceramics is the reason the radio exists in my life at all, in a sense. Long processes such as wedging, trimming, burnishing and watching a kiln are well suited to background sound. Many of the best hours in the workshop are quiet repetitive ones, and a radio fills them without demanding attention. When a kiln is firing, I want to be in the room or close by, and a portable radio lets me stay near without being bored.

I installed it in 2025 and it has been in the same place since, apart from short trips outdoors. It has survived being knocked once, a few dusty weeks, and one cold spell when the workshop was unheated. The cold shortened the battery life noticeably, which I now take into account.

Things I learned early on:

- Reception depends heavily on the position of the aerial and the walls around it.
- Battery life drops in cold weather, so I keep spare cells indoors during winter.
- Dust matters more than I expected. Fine silica-rich powder can scratch and clog moving parts.
- Keeping a written list of stations saves time and avoids fiddling with the dial when my hands are busy.

## Costs

I am not recording exact prices here, because they change and because I would rather track the shape of the spending than the numbers. What follows is a practical breakdown of where the money goes with a battery-powered radio receiver in a workshop.

**Purchase**

The one-off cost was the radio itself. For a plain receiver without extra features it was modest, and I consider it good value compared with the old mains radio I replaced, which I had repaired more than once. The yellow case has so far held up well, which is part of the value.

**Batteries**

This is the main running cost, and it is the one I watch. Because the Vorful runs on battery, every hour of listening uses a little stored energy. Rough habits that keep this under control:

- Turn the radio off when I leave the workshop, even for a short break.
- Keep the volume at a moderate level, since loud playback drains cells faster.
- Remove the cells before long periods of disuse.
- Buy cells in multipacks and store them dry.
- Consider rechargeable cells if the radio is used daily for long stretches.

Rechargeable cells cost more at first and save money over the long run, as long as I remember to charge them. The risk is that they go flat at an awkward moment, so I keep one spare set ready.

**Upkeep**

Upkeep costs are small: a soft brush, a dry cloth and some tape for marking positions. I count a replacement aerial or a new case cover as possible future costs, though I have not needed either yet.

**Hidden costs**

The hidden cost is time. If reception is poor, I lose minutes moving the radio and adjusting the aerial. Writing down good positions and stations has paid for itself in time saved. Replacing the radio because of dust damage would be the largest avoidable cost, so keeping it clean and off the glaze bench is the cheapest protection I have.

## Overview

This section collects the properties of the Vorful in one place, for quick reference.

- **Subject:** the Vorful radio receiver
- **Kind:** radio receiver
- **Area:** ceramics
- **Color:** yellow
- **Energy source:** battery
- **Year installed:** 2025
- **Location:** workshop

**What it is.** The Vorful is a radio receiver. It receives broadcasts and plays them through its built-in speaker. It is not a recorder or a player, and I use it only for listening to stations.

**How it is powered.** It runs on battery, so it needs no mains connection. That makes it easy to move around the workshop, and it avoids loose cables near wet floors and kiln equipment. The trade-off is that I have to keep an eye on the cells and carry spares.

**Where it lives.** It stays in the workshop, on the shelf near the window, at about shoulder height and away from the glaze bench. I installed it there in 2025 and have kept it in that spot.

**Appearance.** The case is yellow. This makes it easy to see among clay, tools and shelves, and it shows dust clearly enough to prompt regular wiping.

**Connection to ceramics.** The radio belongs to my ceramics work. It keeps me company during wedging, throwing, trimming, glazing and kiln watching. Most of its use is background listening during long, repetitive tasks, and the radio has to cope with dust, damp and the occasional knock.

**Quick care checklist**

1. Check the batteries and contacts before a long session.
2. Place the radio at the marked spot and extend the aerial.
3. Pick a station from the card inside the cupboard door.
4. Keep it clear of glaze and slip.
5. Wipe it down and switch it off when I finish for the day.

If something goes wrong, I check in this order: cells first, then contacts, then aerial position, then interference from other equipment in the workshop. Nearly every problem so far has been solved by one of those four.

## Tools

This section lists what I keep on the bench for working on the Vorful radio receiver. It is a yellow, battery-powered radio receiver that was installed in the workshop in 2025. Its area is ceramics, so most of the dust and damp I worry about comes from clay, glaze and kiln work. The tools below are chosen with that in mind.

### Basic hand tools

- A small set of precision screwdrivers, both flat and cross-head. The case screws are small and soft, so a poorly fitting driver will strip them.
- A pair of fine tweezers for lifting out battery contacts and loose wire ends.
- A soft brush, the kind used for dusting glaze tests. I use it to clear clay dust from the grille and the dial.
- A plastic spudger or an old guitar pick to open the case seam without scratching the yellow shell.
- Cotton swabs and a small bottle of isopropyl alcohol for cleaning the battery contacts.
- A dry microfiber cloth. I never use a damp cloth near the speaker.

### Electrical tools

- A basic multimeter. I use it to check the battery voltage and to test continuity in the battery leads.
- A spare set of fresh batteries, kept in a labelled box on the shelf above the bench. Since the energy source is battery, this is the part I touch most often.
- A small soldering iron, used only if a battery lead has to be reattached. I try to avoid it, because the plastic around the contacts melts easily.
- Heat-shrink tubing and a few short pieces of wire for repairs.

### Cleaning and care supplies

- A small hand blower, so I do not have to blow on the device with my mouth and spray it with moisture.
- A sealed plastic tub with a lid. When the kiln room is dusty, the receiver goes in the tub overnight.
- A packet of silica gel placed in the tub. The workshop gets damp in winter, and ceramic work keeps the air humid.
- A roll of masking tape to cover the speaker opening while I sand or trim greenware nearby.

### Notes on using the tools

1. Before opening the case, remove the batteries first. I do this every time, even for a quick look.
2. Work on a clean tray so that screws do not roll into the clay bin.
3. Lay the screws out in the order they came out. The two at the back are slightly longer than the rest.
4. Wipe the contacts with alcohol, let them dry fully, and only then put the batteries back.
5. Keep all tools away from wet glaze. Glaze residue is gritty and will clog the tuning dial if it gets inside.

### What I do not use

- No compressed air cans. They push dust deeper into the case and can chill the parts, which then collect condensation.
- No water or general-purpose cleaners. They leave a film on the yellow plastic and can get into the speaker.
- No metal picks near the contacts. They scratch the plating and cause poor connections later.

### Where everything lives

The tools sit in a shallow drawer under the bench in the workshop, close to where the Vorful radio receiver stands. The spare batteries and the silica gel are on the shelf above. If I take something out, I put it back the same day, because small tools disappear quickly among the clay and glaze supplies.

## Measurements

This section records the figures I have measured or noted for the Vorful radio receiver, along with the basic properties of the device so everything is in one place. I use it as a quick reference when something seems off.

### Properties of the device

- Name: Vorful radio receiver
- Kind: radio receiver
- Area: ceramics
- Color: yellow
- Energy source: battery
- Year installed: 2025
- Location: workshop

### Flow rate

- Flow rate of Vorful radio receiver: 126.21 l/h

I wrote this figure down as the reference value and compare against it whenever I suspect the receiver is not behaving normally. If a later reading is clearly different from it, I treat that as a sign to check the device before trusting it. The unit is litres per hour, and I keep the unit written next to the number so I do not mix it up with anything else.

### How I take readings

1. Let the receiver sit in the workshop for a while, so that it is at the same temperature as the room.
2. Put in a fresh set of batteries, since weak batteries can change how the device behaves.
3. Take the reading in the same spot on the bench every time. Moving it around changes the conditions.
4. Repeat the reading a few times and compare the results with each other.
5. Write the result in my notes the same day, with a short remark about the conditions, such as whether the kiln was running.

### Conditions that affect readings

- Kiln running nearby: the air in the workshop gets warm and dry, and I note this beside the reading.
- Damp days: humidity from wet clay and glaze can make the device less steady.
- Dust: a layer of clay dust on the grille or dial can disturb the reading, so I brush it off first.
- Battery condition: a tired battery is the most common cause of a strange result. I replace the batteries before assuming a fault.
- Position: a spot close to a wall or a metal shelf can give a different result than the open bench.

### Checks I do with the multimeter

- Battery voltage with the batteries in place, to see whether they are still healthy.
- Continuity of the battery leads, to confirm that nothing has broken inside the wires.
- Contact condition, by looking at the plating and checking that it is clean and bright.

I do not record a long list of electrical values here. What matters in practice is whether the batteries are fresh and the contacts are clean, so those are the checks I repeat most.

### Reading the results

If a result matches the reference flow rate, I leave everything as it is. If it differs a little, I look at the conditions first: temperature, dust, damp and battery. If it differs a lot, I go through the cleaning steps from the tools section, replace the batteries and measure again. Only if the result still looks wrong do I open the case and inspect the leads and contacts.

### Record keeping

- I keep readings in date order in my notes, with the conditions written beside each one.
- I note when the batteries were last changed.
- I mark any day on which the kiln was fired, because it changes the air in the workshop.
- If I move the receiver to another place, I write down where it went and when, then return it to its usual spot in the workshop afterwards.

### Short summary of the device

The Vorful radio receiver is a yellow, battery-powered radio receiver used in the workshop for ceramics work and installed in 2025. Its reference flow rate is 126.21 l/h. With clean contacts, fresh batteries and a dust-free grille, it should stay close to that value from one session to the next.
