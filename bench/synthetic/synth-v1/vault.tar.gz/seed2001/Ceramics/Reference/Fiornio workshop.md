---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Fiornio workshop."
---

# Fiornio workshop

## Safety

The Fiornio workshop is a medium-sized ceramics workshop on the ground level, built in 2002. Its entrance faces north, so the room gets steady, cool light and very little direct sun. That is pleasant to work in, but it also means the floor and walls stay cool and damp longer than I expect, so I treat the room with some care.

Because the workshop is on the ground level, I can carry heavy things in and out without using stairs. Bags of clay, buckets of glaze and full kiln shelves all move across one flat floor. I still keep the main walkway clear, since a slip with a heavy load is the most likely accident here.

Clay dust is the main hazard. Dry clay and dried glaze leave fine silica dust that I should not breathe. My rules:

- Wipe surfaces with a damp sponge or cloth. I never dry-sweep.
- Wear a fitted dust mask when mixing glaze or trimming dry pieces.
- Keep the floor free of dried slip, because it turns to powder and then to dust in the air.
- Wash hands before eating or drinking, and never eat in the room.

Wet floors are the second hazard. A damp ground-level floor with a film of slip is slippery. I keep a mat near the wheel and the sink, and I wipe up spills at once.

For the kiln, I keep the area around it empty of paper, cardboard and cloth. I never leave it firing while I am away from the building. A fire extinguisher hangs by the door, and I check that it is reachable whenever I tidy up. Ventilation matters during firing, so I open the windows and the door before I start and leave them open until the kiln has cooled.

Glaze materials stay in labelled, closed containers on a low, stable shelf. Heavier containers go at the bottom. Anything I am unsure about gets a label before it gets used.

## Maintenance

The north orientation shapes most of my upkeep. With little sun, the room dries slowly, so I watch for damp, mould and slow-drying work.

Weekly tasks:

- Wet-wipe the benches, the wheel and the shelves.
- Mop the floor with a well-wrung mop.
- Empty and rinse the slip bucket, and never pour clay down the sink without using the trap.
- Check the trap and clean it when it is half full.

Monthly tasks:

- Look at the corners and the lower walls for mould or salt marks.
- Inspect the kiln shelves and props for cracks and glaze drips.
- Check the kiln lid, the bricks and the electrical cable for wear.
- Oil the wheel bearings as the maker's manual says.
- Test the extinguisher gauge.

Seasonal tasks:

- In autumn and winter, run a dehumidifier or leave the door open on dry days, since the north side stays cold.
- In spring, clear out any old clay and glaze that has gone off.
- Once a year, reseal any gaps around the window frames and the door, because the building dates from 2002 and its seals have aged.

Because the room is medium in size, it fills up fast. I keep a short list of what must stay: wheel, wedging table, two shelving units, kiln, sink and glaze shelf. Anything else needs a good reason to be in the room. A tidy room is easier to clean, and cleaning is the best protection against dust.

When I fix something, I write a short line in my notes with what I did and what I noticed, so I can spot patterns later, for example damp returning in the same corner.

## Measurements

These are the figures I keep on record for the workshop.

- Kind: workshop
- Area: ceramics
- Orientation: north
- Size: medium
- Year built: 2002
- Floor: ground level
- Measured humidity of Fiornio workshop: 74.75 %

The humidity reading is high for a room where I dry clay. At that level, pieces dry slowly and unevenly, and the risk of mould rises. It fits what I expect from a north-facing room on the ground level, where the floor holds cold and moisture. I read the humidity with a small hand meter placed near the middle of the room, away from the sink and the kiln, so that the number reflects the general air and not a wet spot.

I have not measured the room in metres. The size is simply medium: enough for one wheel, a worktable, a kiln and some storage, but tight if two people work at once.

## Open questions

- Is the humidity reading typical for the room, or was it high because of the weather that day? I need more readings at different times and seasons before I can say.
- Would a permanent dehumidifier pay for itself, or would better ventilation be enough?
- Is the damp coming through the floor, through the walls, or only from the air? Being on the ground level makes the floor a suspect.
- Should I add a window or a vent on a side other than the north wall to help air move through?
- Are the seals from 2002 still doing their job, or is it time to replace them all rather than patch them?
- Is the kiln position the best one for ventilation, or should it move closer to the door?
- Would a second dust mask station near the glaze shelf make me more likely to use it every time?
- Is there room in the medium space for a dedicated drying rack, so that slow-drying pieces do not crowd the benches?
