---
type: reference
status: active
project: reference
area: ceramics
---

# Luki band saw

## Ideas

The Luki band saw is a blue band saw that sits in the workshop. It was installed in 2014 and runs on solar power. I use it for ceramics work, mostly cutting greenware slabs, trimming dried clay blocks, and sometimes slicing bisque pieces that need a clean edge.

Things I want to try with it:

- Build a small side table with a damp cloth tray so clay dust stays down while I cut.
- Mark a fixed cutting guide on the bed so slab widths repeat without measuring each time.
- Schedule heavy cutting for sunny afternoons, since the saw runs on solar and output drops on grey days.
- Test a slower blade speed for thick, leather-hard clay to see if the edges chip less.
- Keep a short log of blade changes and cuts in the [[Krulpind workshop log]] so I can see how long a blade lasts on different clay bodies.

Another idea is to compare how much heat the saw area adds to the workshop against what I learned in the [[Zendgla heat exchanger study]]. The motor is not a big heat source, but the kiln corner nearby is, and it might make sense to move the saw to a cooler spot in summer.

I also want to think about moving spare blades and offcuts to the [[Guverk barn]], so the workshop stays clear and I have more floor space around the saw when handling large slabs.

## Risks

The main risk is dust. Dry clay and especially cut bisque produce fine silica-bearing dust that is bad to breathe over the years. Cutting dry material on this saw puts more of it in the air than any other tool I own.

Other risks I have noted:

- The blade can wander or snap if the tension is wrong or if a hard inclusion in the clay catches it.
- Because the saw is solar powered, a sudden drop in sunlight can slow the motor mid-cut. That can bind the blade in thick material.
- Wet clay sticks to the bed and the guides, which can cause rust over time. The saw has been in service since 2014, so I should check for wear on the wheels and guides.
- Offcuts and slurry on the floor around the saw make slipping a real concern.
- Cutting fired pieces with an unsuitable blade will dull it quickly and can throw chips.

## Safety

My habits for using the Luki band saw:

- Wear a fitted respirator whenever I cut anything dry or fired. A paper mask is not enough.
- Wear eye protection every time, even for soft greenware.
- Keep fingers well away from the blade line and use a push stick for narrow pieces.
- Set the blade guard just above the work, not at full height.
- Check blade tension and tracking before each session.
- Never clear a jam with the saw powered. Wait for the blade to stop completely first.
- Wipe the bed and floor with a damp mop after cutting. Do not sweep dry dust.
- Tie back hair and avoid loose sleeves or cuffs.
- If the sun drops and the motor sounds weak, stop cutting and wait rather than forcing the piece.

I should also store the blade covered when the saw is not in use, so nobody brushes against it in the workshop.

## Measurements

Summary of the saw's properties, for quick reference:

- Kind: band saw
- Area: ceramics
- Color: blue
- Energy source: solar
- Year installed: 2014
- Location: workshop

Measured power draw of Luki band saw: 886.02 W. I took this reading while the saw was cutting a medium-thickness slab of greenware, so it reflects a working load rather than idle running. Idle draw is clearly lower, and a thick or damp cut pushes it higher.

That figure is useful for judging whether the solar supply can handle the saw along with other loads in the workshop. When the kiln or other tools are running at the same time, I should plan around it. I will record later readings with different clay types and blade conditions in the [[Krulpind workshop log]], so I can compare them to this baseline.
