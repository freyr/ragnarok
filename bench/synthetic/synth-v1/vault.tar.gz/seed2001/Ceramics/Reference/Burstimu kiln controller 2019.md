---
type: reference
status: archived
project: reference
area: ceramics
description: "Reference about Burstimu kiln controller."
---

# Burstimu kiln controller 2019

## Overview

This note is archived. It records the state of the Burstimu kiln controller in 2019. Later notes replace the values given here.

The Burstimu kiln controller is a kiln controller used for ceramics. I installed it in 2016, and it sits in the workshop next to the kiln it controls. It runs on mains power, so it has no battery and needs a wall socket close by. The case is green, which makes it easy to spot on the shelf among the grey tools and boxes.

In 2019 I used it for every firing, both bisque and glaze. It held the firing schedule and switched the kiln on and off to follow it. I never had trouble with it in daily use. The main thing to remember is to check the display before leaving the workshop, because the controller does not warn me if the schedule is set wrong.

Quick facts as of 2019:

| Property | Value |
|---|---|
| Kind | kiln controller |
| Area | ceramics |
| Color | green |
| Energy source | mains |
| Year installed | 2016 |
| Location | workshop |

## Parts

The controller is one unit with the display and the keys on the front. The wiring goes out through the back to the kiln and to the mains socket. I have not replaced any part of it since 2016, so everything in the box is original.

The serial number is printed on a label on the side of the case: SN-23490223. I keep it here so I can quote it if I ever need to ask for support or spare parts.

Main parts as I noted them in 2019:

- Green case with the front panel and keys
- Display for the schedule and the current state
- Mains lead to the wall socket
- Output wiring to the kiln
- Sensor lead that goes into the kiln

A typical entry from my firing notes, written the way I log a run by hand:

```
firing: glaze
controller: Burstimu kiln controller
location: workshop
power: mains
check display before leaving: yes
```

If the display shows nothing, I check the mains socket first, then the lead, and only after that the controller itself. Most of the time the cause is the socket or the lead.
