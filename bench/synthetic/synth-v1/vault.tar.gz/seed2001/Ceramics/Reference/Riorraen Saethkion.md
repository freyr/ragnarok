---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Riorraen Saethkion."
---

# Riorraen Saethkion

## Checklist

- Confirm Riorraen Saethkion is the right person for the job: a carpenter who works in the area of ceramics.
- Call by phone. Contact is by phone only, so do not bother with email or messages.
- Call in the evenings. That is the only time Riorraen is generally available.
- Describe the job in two or three sentences before asking about price: what needs building, the rough size, and where it will be used.
- Ask whether the work involves ceramic pieces, such as shelves for fired work, a drying rack, or a wedging table.
- Agree on materials and who buys them.
- Agree on a delivery or collection day.
- Write down what was agreed straight after the call.
- Check the contract section below before starting anything new.

## Contracts

The contract date of Riorraen Saethkion is 2026-11-07. This is the date on the agreement for the most recent piece of work. It was settled by phone in the evening, which is how most things with Riorraen get settled.

What the agreement covers is kept short on purpose. I note the job, the materials, who pays for them, and the day the work is due. Anything more detailed goes in my own notes, not into the agreement.

A few practical points for future contracts:

- Always confirm the details by phone a second time a day or two before work begins.
- If the plan changes, call again in the evening and update my notes the same night.
- Keep a short log of each call so that it is easy to see what was said and when.

A simple log entry looks like this:

```text
contact: Riorraen Saethkion
channel: phone
time: evening
topic: workshop shelving for kiln room
agreed: materials bought by me, delivery on a weekday evening
follow-up: call again before work starts
```

## Overview

Riorraen Saethkion is a carpenter. The area I file this person under is ceramics, because nearly everything I have asked for has been connected to pottery work: shelving, racks, tables, and boxes for carrying finished pieces.

The key facts, kept together so I do not have to hunt for them:

- Role: carpenter
- Area: ceramics
- Contact: phone
- Availability: evenings
- Known since: 2012

Contact is by phone. Riorraen does not reply well to anything else, so I do not try. Evenings are the time to call. Calling during the day usually means no answer, and leaving a long message does not help. A short message asking for a call back in the evening is fine, but a direct call at the right hour works better.

Riorraen is practical and plain in how work is described and priced. I get the best results by saying exactly what I need and what it will hold or support. For ceramics work that matters a lot, since a shelf that will carry heavy clay or damp pieces needs to be built differently from an ordinary shelf.

## Background

I have known Riorraen Saethkion since 2012. We met through the pottery side of things, when I needed a sturdy workbench and was told that a carpenter who understood ceramics would build it better than a general joiner. That turned out to be true. The bench was built for the weight of clay and for being wiped down, and it has held up well ever since.

Since then I have returned for a number of smaller jobs. Most were in the same area: storage for tools and glazes, racks for drying, and boards for carrying work between rooms. Each time the process has been the same. I call in the evening, explain the job, and we talk through what is possible. Riorraen tends to suggest a simpler build than the one I first imagined, and the simpler version has usually been the better one.

Some lessons from the years of working together:

- Be specific about weight and moisture. Ceramics work is heavy and often wet.
- Give measurements of the room, not only of the object.
- Do not ask for a quick turnaround on short notice, because evenings are the only free time and they fill up.
- Pay promptly and say thank you. It is the reason the relationship has lasted.

If I ever need a replacement, I should start by asking Riorraen who else to call. A carpenter known since 2012 who works in ceramics is the best source for another recommendation, and the answer would be given by phone, in the evening, like everything else.
