---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Guverk barn."
---

# Guverk barn

## Overview

Guverk barn is a small barn used for ceramics work. It was built in 2012, it faces north, and it has a raised floor. I keep this note as a plain reference for myself, so that I do not have to rebuild the picture of the place from scattered logs every time I come back to it.

Here are the properties in one place:

- Kind: barn
- Area: ceramics
- Orientation: north
- Size: small
- Year built: 2012
- Floor: raised

The barn is small, and that shapes almost every decision about it. There is room for a few work stations, a drying area, shelving, and a narrow path between them. Anything larger than a modest kiln or a single wedging table makes the space feel crowded. I have learned to treat floor space as the scarcest thing in the building and to ask of every new object whether it earns its footprint.

The north orientation means the main openings do not take direct sun for most of the day. For ceramics this is a mixed blessing. The light is even and soft, which is good for glazing and for judging surface colour. But the building stays cool, and drying can be slow when the air is damp. The raised floor lifts the working surface off the ground, which keeps the interior drier than a floor laid directly on soil, and it leaves a gap underneath that has to be watched for pests and moisture.

Related notes: [[Krulpind workshop log]] holds the day-to-day record, [[Krespa shed plan]] is the layout I compared against when I thought about adding storage, and [[Fulmasvork workshop tests 2024]] has the results of the firing and drying trials I ran in a comparable space.

## Checklist

This is the list I run through when I arrive, and again before I leave. It is short on purpose, because a long checklist gets skipped.

- Look at the floor boards near the door for soft spots or new gaps.
- Check the space under the raised floor for standing water, nesting, or debris.
- Feel the air: if it is clammy, open the north openings before starting work.
- Confirm the drying shelves are clear and that nothing is touching the walls.
- Inspect the kiln area for dust and loose items.
- Check that the heat exchanger connection is secure and that nothing is stacked against it (see [[Stondneth heat exchanger]]).
- Wipe the work table and sweep, damp rather than dry, to keep clay dust down.
- Make sure the door latches properly on the way out.
- Write a line in the workshop log if anything changed.

On leaving, I also cover any damp work, switch off all equipment, and look once more at the floor for dropped tools. The raised floor has gaps at the edges where small items can vanish, so a quick look saves a search later.

## Dimensions

The barn is small, and the numbers back that up. The floor area of Guverk barn is 351.66 m².

That figure is the total floor area I use for planning. It is not all usable. Some of it is taken by the walkway, the door swing, and the clearance I leave around the kiln and the heat source. When I plan a layout, I think in zones rather than in total area: a wet zone for throwing and wedging, a dry zone for finished and bisque-fired work, a storage zone for materials, and a clear circulation path that I do not allow to be filled.

A few practical notes on how the size behaves:

- A small building warms and cools quickly. After a firing the interior temperature changes noticeably, and it falls again overnight.
- Humidity swings are larger in a small volume. Wet clay and fresh glaze put moisture into the air faster than a big building would absorb it.
- The raised floor adds height to the whole structure, so the working surface sits above ground level. Stepping up into the barn matters when carrying heavy bags of clay, and I keep a sturdy ramp or a solid step in mind for that.

When I compare against [[Krespa shed plan]], the main difference is that the shed plan assumes a lighter use and fewer heavy objects. The barn has to carry more weight on its floor, so I treat the shed plan as a layout reference only and not as a structural guide.

## Lessons

Several lessons have come from using this barn over the years since 2012.

First, the north orientation is steady but cold. I stopped expecting the building to dry work quickly by itself. Drying needs help from airflow and a controlled amount of warmth, and I plan around that rather than hoping for a sunny week.

Second, the raised floor is a real advantage when it is kept in good condition. It keeps the interior drier than ground-level construction would, and it makes it easier to inspect from below. But it needs attention. If I neglect the underside, small animals move in and moisture collects.

Third, small means disciplined. Every time I let the barn fill with half-finished projects, work got damaged. Keeping a rule that nothing stays on the floor, and that every shelf has a purpose, has prevented more breakage than any change to the building.

Fourth, write things down. The [[Krulpind workshop log]] has repeatedly saved me from repeating mistakes, especially about drying times and which shelves stay damp. [[Baerkpend Drormaeth notes]] contain useful general advice on organising a ceramics space that I return to when I rethink the layout.

Fifth, heat management matters more than I first assumed. In a small building, an unwanted heat source or a blocked vent changes conditions for everything in the room.

## Observations

These are things I have noticed through repeated use, not measured facts.

The light from the north is even and calm. I can judge glaze colour here better than in a space with strong direct sun, because shadows are soft and the colour does not shift through the day. This is the best thing about the orientation, and I use it deliberately when I evaluate test tiles.

The air near the floor is cooler than the air near the roof. In a small building with a raised floor this difference is noticeable, and it affects where I put drying work. The upper shelves dry faster, so I put thin pieces low and thick pieces high only when I want to slow them down, and the other way round when I want to hurry them along.

The boards of the raised floor have a slight give in some places. It is not a fault, but it means I avoid placing very heavy items on unsupported spans. Heavy things go near the supports.

Sound carries a lot in a small wooden barn. Rain on the roof is loud, and the building is easy to hear from outside as well, which is useful when someone arrives.

Dust settles on the north-facing sills more than anywhere else, probably because the air there is still. I wipe those surfaces more often than the rest.

The area around the heat exchanger is the warmest spot, and pieces left too close to it dry unevenly. See [[Stondneth heat exchanger]] for how it is set up and what I learned from it.

## Maintenance

Maintenance on a small barn is mostly about keeping water out and air moving. I split the work by frequency.

Routine, every visit:

- Sweep and damp-wipe the floor and work table.
- Look at the floor edges and the entrance for new damage.
- Open and close the north openings as the weather requires.

Seasonal:

- Clear the gutters and any drainage near the base of the building.
- Inspect the underside of the raised floor, remove debris, and check for nests or damp patches.
- Check the roof for loose fixings and the walls for gaps that let wind-driven rain in.
- Oil or treat hinges and latches so the door keeps closing properly.
- Review the shelving for sagging or rot.

Occasional:

- Re-treat exposed timber where the finish has worn thin, especially on the north side where the wood stays damp longest.
- Check the connection and condition of the heat exchanger and its surroundings.
- Rearrange the layout if the work has changed, and update the log.

For anything involving the structure itself, I would consult [[Serpi Muntran]], who knows timber buildings of this kind and has given me sound advice before. I try not to improvise structural repairs on a floor that carries heavy loads.

I record each maintenance job in the [[Krulpind workshop log]] so that I can see patterns, such as which corner always gets damp first.

## Ideas

These are things I might try, none of them committed.

- Add a simple, removable drying rack that folds against the wall, to free floor space when it is not needed.
- Install a small vent or louvre low on the north wall to improve airflow across the damp zone.
- Place a cheap hygrometer near the drying shelves so I stop guessing about humidity.
- Build a low platform for the kiln area so the heavy equipment sits on dedicated supports rather than on unsupported boards.
- Try a lightweight curtain or screen to separate the wet zone from the dry zone, reducing dust on finished work.
- Reuse some of the storage ideas from [[Krespa shed plan]] for a narrow wall-mounted shelf system.
- Repeat a version of the drying trials from [[Fulmasvork workshop tests 2024]] in this barn, to see how its cool north conditions compare.
- Add better lighting for winter evenings, aimed to avoid glare on glazed surfaces.
- Make a laminated one-page version of the checklist and hang it by the door.

Of these, the hygrometer and the vent are the cheapest and probably the most useful. The kiln platform is the most valuable but also the most work, and I would want advice before starting.

## Tools

The barn is not equipped like a large studio, and I try to keep the tool set modest so that it fits the space.

Core items:

- A sturdy work table for wedging and hand building
- A throwing wheel placed where the light is best
- Basic hand tools for trimming, cutting and smoothing
- Sponges, buckets and wiping cloths
- Shelving with removable boards for drying
- A kiln and its safety clearance zone
- A broom, a dustpan, and a damp mop for cleaning

Support items:

- A small hand truck or trolley for moving clay bags up into the raised-floor space
- A torch or small lamp for looking under the floor
- A basic toolkit for adjusting hinges, latches and shelves
- A notebook kept in the barn for quick entries before they go into the log

The heat source and exchanger are covered in [[Stondneth heat exchanger]]. I treat that as equipment that needs its own note because the surrounding clearance and airflow matter as much as the unit itself.

I keep tools off the floor and on hooks or in labelled boxes. In a small barn with a raised floor, anything dropped may slip through a gap at the edge, so tidy storage is a practical need and not a matter of appearance.

## Open questions

There are several things I do not yet know and would like to settle.

- How much does the raised floor really contribute to dryness compared with the cooling effect it causes? I suspect it helps, but I have no clear comparison.
- Would a low vent on the north wall reduce dampness without making the barn too cold in winter?
- Is the floor span near the middle strong enough for a larger kiln, or should I add supports before ever considering one?
- Which shelves stay consistently damp, and is that because of the wall behind them or the position relative to the door?
- Would a different layout, with the wet zone nearer the door, reduce the amount of water tracked across the floor?
- How does this barn compare with the conditions recorded in [[Fulmasvork workshop tests 2024]]? The tests were run elsewhere, so the results may not transfer directly.
- Are there any ideas in [[Baerkpend Drormaeth notes]] that I have dismissed too quickly and should test here?

I plan to answer some of these with simple observation over a season, recording in the [[Krulpind workshop log]] rather than relying on memory.

## References

These are the notes I link to when working on this barn.

- [[Krulpind workshop log]]: the running record of visits, jobs, problems and small discoveries.
- [[Baerkpend Drormaeth notes]]: general guidance on organising a ceramics workspace, which I use for layout thinking.
- [[Krespa shed plan]]: a layout for a smaller storage building that I borrow ideas from.
- [[Fulmasvork workshop tests 2024]]: results of drying and firing trials that give me a baseline for comparison.
- [[Stondneth heat exchanger]]: details about the heat equipment and how it is placed and used.
- [[Serpi Muntran]]: a person I consult for advice on timber construction and structural questions.

When I add new material about the barn, I link it from here so that this note stays the starting point. If a reference stops being useful, I remove it and say why in the log.

## Risks

The main risks come from moisture, load, heat, and neglect.

Moisture: the north orientation and cool interior encourage damp. Persistent damp can rot timber, spoil stored materials, and slow drying so that work cracks or grows mould. The raised floor reduces ground moisture but introduces its own risk if the space underneath is blocked or allowed to collect water.

Load: a raised floor has limits. Heavy kilns, stacked clay bags, and filled shelves can stress boards and supports. I should not place concentrated loads on unsupported spans, and I should check the supports before adding anything heavy.

Heat: a small building with a heat source can get uncomfortably hot near the equipment while remaining cold elsewhere. Combustible items too near the heat are a fire risk. I keep the clearance zone empty and make sure the heat exchanger is not obstructed.

Dust: clay and glaze dust in a small enclosed space is a health concern. Damp cleaning and good ventilation are the main defences.

Pests: the gap under the floor invites small animals. They can damage insulation, nest in warm corners, and chew through materials.

Neglect: the biggest risk is skipping routine checks. A small problem at the floor edge or roof becomes a large one if left through a wet season.

For structural doubts I would ask [[Serpi Muntran]] before acting.

## History

Guverk barn was built in 2012. It was designed as a small barn with a raised floor and a north-facing orientation, and over the years it has become a ceramics space.

In the early period, the barn was used lightly, mostly for storage and occasional hand building. Use grew as I added a wheel, then shelving, then a proper kiln area. Each addition changed how the space felt, and each one made the small size more obvious.

Over time I learned the building's habits: where it gets damp, where the floor gives, which corner is warmest, and how the north light behaves through the seasons. Most of that knowledge now lives in the [[Krulpind workshop log]], which records the changes and repairs in order.

The layout has been reorganised several times. Some of those changes were informed by [[Baerkpend Drormaeth notes]], and others by comparing against [[Krespa shed plan]]. The drying and firing trials in [[Fulmasvork workshop tests 2024]] influenced how I think about airflow and heat, even though they were not done in this barn.

The heat equipment was added later than the original construction, and its placement has been adjusted since. Details are in [[Stondneth heat exchanger]].

The structure has needed only modest repairs so far, mostly to do with moisture at the floor edges and the north side.

## Background

Ceramics needs a space that is controlled in a few particular ways: steady light for judging surfaces, a place where wet work can dry slowly and evenly, a safe area for heat, and enough order to prevent breakage. A small barn can do all of that if it is used with care.

The reasons I use a barn for this are mostly practical. It is separate from the house, so dust and moisture stay out of living space. It can take a bit of mess. And its simple construction makes it easy to understand, modify and repair.

The north orientation turned out to be a good fit for glazing and colour work, because the light does not swing from bright to dim during the day. It is a poor fit for fast drying, so the work flow adapts: slow drying becomes part of the process, and I plan projects so that they are not rushed.

The raised floor is a traditional way to keep a building dry and to keep air moving beneath it. In a ceramics space, where water is constantly present, that feature is useful. It also makes the floor a structural element that I have to respect, because it carries the weight of equipment and materials.

Because the barn is small, I think of it as a tool and not as a building to fill. Its limits are part of how I work, and the notes I keep are meant to help me stay within them.

## Problems

These are the ongoing or recurring problems with the barn.

- Damp in the north-side corners during wet weather, which slows drying and can stain walls.
- Uneven drying near the heat source, where pieces dry too fast on one side and crack.
- Dust collecting on sills and shelves, especially where the air stays still.
- Items falling through gaps at the floor edges and being hard to retrieve.
- Slight give in some floor boards, which limits where heavy objects can go.
- Limited space, so the walkway gets blocked when projects pile up.
- Occasional signs of small animals under the floor, which I only notice if I check regularly.
- Cold interior in winter, which makes clay stiff and slows glaze work.

For each of these I have a partial answer but not a complete one. The best defence is routine: follow the checklist, keep the space tidy, and write down what happens in the [[Krulpind workshop log]]. When a problem repeats, I move it up to the open questions and think about a more lasting fix, perhaps drawing on [[Baerkpend Drormaeth notes]] or asking [[Serpi Muntran]] about the structure.
