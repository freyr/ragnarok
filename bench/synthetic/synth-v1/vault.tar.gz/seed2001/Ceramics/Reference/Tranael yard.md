---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Tranael yard."
---

# Tranael yard

## Setup

Tranael yard is a yard in the ceramics area. It is small and faces south, so it gets sun for most of the day. It was built in 1990. The floor is raised, which keeps the ground clear of standing water after rain and makes it easier to sweep out clay dust and offcuts.

I use the yard mainly for work that needs open air and light. Pieces that need slow, even drying go along the sunny side. Because the space is small, I keep it tidy and bring in only what I am working on that day. Anything that is not in use goes back inside so the floor stays clear and I can move around without knocking into things.

## Equipment

The installed device in Tranael yard is a Nedirk heat exchanger. It is fixed in place, so I plan the layout of the yard around it and keep a gap clear on every side. I do not stack boards or wet pieces against it. When I check the yard, I look at the exchanger first and wipe off any dust that has settled on it. Other tools are movable and live indoors when not in use.
