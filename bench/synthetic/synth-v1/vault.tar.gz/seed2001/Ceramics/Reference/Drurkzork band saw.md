---
type: reference
status: active
project: reference
area: ceramics
---

# Drurkzork band saw

## Open questions

- Is the guide fence worth replacing with a better one? The current fence works, but the clamp on it sometimes creeps when I push thick slabs through. I want to find out whether the creep is the clamp or the table.
- Would a finer blade give a cleaner cut on leather-hard porcelain? I have only tried the blade that came on the saw, and I do not know how it compares.
- Can the dust be controlled better in the loft? A shop vacuum on the lower port helps, but I have not found a good way to catch what comes off the top wheel housing.
- Is the hum I hear at low speed normal, or is it a sign that a bearing is starting to go? I want to compare it with the sound after the next service.
- Should I fit a small light over the table? The loft has only one window, and in the afternoon the shadow of the upper guide falls right on the cut line.

## History

The Drurkzork band saw is a green band saw that I use for ceramics work. I installed it in 2025 in the loft, above the main studio. Before that I cut leather-hard clay and dry bisque blanks by hand with a wire and a fine hand saw. That worked for simple shapes but was slow and gave ragged edges on anything thicker than a finger.

The decision to buy a band saw came after a run of failed attempts at cutting tile blanks to a template. I spent a weekend cleaning up edges with a rasp, and I decided the time was better spent on a proper machine. I wanted something that runs from the mains, so I did not need to deal with batteries or fuel, and something compact enough to carry up the loft stairs in two trips.

Carrying it up was the hardest part of the whole project. The base is heavy, and the stairs have a tight turn. I removed the table and the upper guide first, then carried the column and the base separately. Reassembly took an afternoon.

After the first month I made a few changes. I moved the saw about half a metre away from the wall so I could get at the back door of the wheel housing. I also screwed a scrap of plywood under the legs to stop a slight rock on the uneven loft floor. Since then I have not moved it.

## Background

A band saw is a machine with a continuous loop of toothed blade stretched over two wheels. The blade runs down through a slot in a flat table, and the material is pushed along the table into the blade. For ceramics, it is useful for cutting clay at the leather-hard stage, for trimming bisque-fired pieces with a suitable blade, and for roughing out shapes in plaster molds and bats.

Key facts about this machine, for quick reference:

| Property | Value |
|---|---|
| Name | Drurkzork band saw |
| Kind | band saw |
| Area | ceramics |
| Color | green |
| Energy source | mains |
| Year installed | 2025 |
| Location | loft |

The saw is plugged into a wall socket on the loft wall. There is no battery and no engine. The only moving parts that matter are the two wheels, the blade, and the motor drive. The blade guides sit above and below the table, and the upper guide moves up and down to match the thickness of the work.

I chose a band saw over a jigsaw or a scroll saw because the blade does not lift and the cut stays steady. Clay is soft enough that a jigsaw tends to tear, and a scroll saw is too slow for my slabs. The band saw also gives me a long, even cut along the grain of a block of plaster.

One thing to remember is that clay dust is a health hazard when dry. Cutting leather-hard clay makes little dust, but cutting bisque or dry greenware makes a lot. That is why the safety section below is longer than I first expected it to be.

## Lessons

- Set the upper guide just above the work before every cut. If I forget, the blade flexes, the cut wanders, and the edge comes out wavy.
- Do not force the work. If I push too hard, the blade bends and the cut leans. Slow and steady gives a straight, clean edge.
- Wet clay clogs the teeth. Leather-hard works fine, but soft clay sticks. I now leave a slab to stiffen a bit longer than I would for hand cutting.
- A dull blade does more harm than good. I once kept a blade too long on bisque and ended up with chipped edges and a burning smell from the friction.
- Clean the table after every session. Clay and plaster dust packs into the slot and the track of the guide, and it makes the fence stick.
- Mark the cut line in pencil, not with a scribed groove, because a groove can steer the blade the wrong way on soft clay.
- Support long pieces on both sides. A slab that tips off the table at the end of a cut will often crack along the line.
- Write the date of each blade change on a piece of tape on the housing. It makes it easier to judge when the next change is due.

## Observations

The saw runs smoothly after a short warm-up. In the first few seconds I hear a slight hum, which fades as the blade reaches speed. On cold mornings in the loft the hum lasts a little longer.

The green paint has held up well. There are a few chips near the base where I hit it with a bucket, but no rust yet. The loft is dry, which helps.

The table is flat enough for my work, though I notice a faint ridge near the blade slot. It does not affect the cut on thick slabs, but thin tiles sometimes catch on it. I plan to file it down gently.

Vibration is low. A coin stood on its edge on the table stays up for a while with the saw running, so I have not bothered with extra damping. I do notice more vibration if the blade is loose or the wheel tire has clay stuck to it.

The saw is louder than I expected in the studio below. The loft floor carries the sound. I now wear ear protection and I try not to run it late in the evening.

When cutting plaster, the blade lasts a shorter time than with clay. Plaster is abrasive, and the teeth wear faster. I keep a separate older blade for plaster work.

## Checklist

Before each session:

- Check the blade for cracks, missing teeth and clay build-up.
- Check the blade tension and tracking by turning the upper wheel by hand.
- Set the upper guide just above the thickness of the work.
- Connect the shop vacuum to the lower port.
- Put on the dust mask, safety glasses and ear protection.
- Clear the table and the floor around the saw.

After each session:

- Switch off and unplug the saw.
- Wait until the blade has stopped completely.
- Brush and vacuum the table, the slot and the wheel housing.
- Wipe the table with a damp cloth, and dry it.
- Release some of the blade tension if I will not use the saw for a week or more.
- Empty the vacuum and wipe the floor with a damp mop, not a broom.

## Setup

The saw stands in the loft on a plywood pad, about half a metre from the wall. The pad keeps the legs from rocking on the uneven floor. The power cable runs along the wall to a socket, and I keep it away from the walkway so I do not trip on it.

The setup steps I follow after changing a blade are these:

1. Unplug the saw and open both wheel covers.
2. Loosen the tension knob and slip the new blade over both wheels, with the teeth pointing down at the table.
3. Tighten the tension until the blade is firm but not tight, and spin the upper wheel by hand to see how the blade tracks.
4. Adjust the tracking knob until the blade runs in the middle of the wheel tire.
5. Set the side guides so they almost touch the blade, with a gap about the thickness of a sheet of paper.
6. Set the thrust bearing just behind the blade, so it only touches when I push.
7. Close the covers, plug in, and run the saw for a few seconds before cutting.

A short log from one session helps me remember the routine. I keep it in my notes like this:

```
session: tile blanks, leather-hard stoneware
blade: standard, fitted before session
guide height: just above slab
vacuum: on, lower port
cuts: 12 straight, 3 curved
result: edges clean, one slab cracked at the end
note: support long slabs at both sides
```

## Problems

- **Wandering cut.** The blade drifts to one side. Usually the cause is a dull blade or a guide set too far from the blade. I replace the blade first, then check the guides.
- **Clay clogging the teeth.** This happens with soft clay. I let the work stiffen, or I wipe the blade with a dry rag while it is stopped.
- **Blade rubbing the wheel housing.** This happened once after I fitted a new blade without checking the tracking. I opened the covers and adjusted the tracking knob.
- **Dust in the loft.** Dry cutting spreads fine dust in the air. I now cut dry material only with the vacuum running, and I mop afterwards.
- **Fence creep.** The fence slips slightly under load. I have tightened the clamp and am still watching it.
- **Chipped edges on bisque.** This comes from a dull blade or from feeding too fast. A slower feed solves most of it.
- **Table ridge.** The faint ridge near the slot catches thin tiles. I put a sheet of thin card on the table as a temporary fix.

## Overview

The Drurkzork band saw is a green band saw for ceramics work. It runs on mains power, was installed in 2025, and stands in the loft. I use it mainly for cutting leather-hard slabs into tile blanks, for trimming the edges of larger forms, and for shaping plaster blocks and bats.

It is a straightforward machine with a column, a base, a table, two wheels, a blade, a set of guides and a motor. There are no electronic controls beyond the switch. This suits me, because there is less to go wrong.

My usual workflow is this: roll or cut a slab, let it stiffen to leather-hard, mark the cut line in pencil, set the guide, and make the cut. Bisque pieces need a different approach, with a slower feed, a dust mask, and the vacuum running.

I treat the saw as a rough shaping tool. For final finishing I still use a rasp, a sponge, or sandpaper. The saw saves time, but it does not replace careful hand work at the end.

## Safety

Safety matters more with a band saw than with most of my other tools, so I keep these rules in mind.

- Wear safety glasses at all times. A broken blade or a flying chip of bisque can hurt an eye.
- Wear a properly fitted dust mask when cutting dry or fired material. Fine clay and glaze dust can damage the lungs over time.
- Wear ear protection, because the sound is loud in the loft.
- Keep fingers well away from the blade. I use a push stick for small pieces, and I never hold a piece close to the blade with bare fingers.
- Do not wear loose sleeves, jewelry or a scarf, and tie back long hair.
- Unplug the saw before changing the blade, adjusting the guides or cleaning the housing.
- Never leave the saw running unattended, and never reach under the table while the blade is moving.
- Keep the floor clear. Dry clay on a wooden floor is slippery, so I mop it up at once.
- Do not cut anything that contains glazes with unknown ingredients, because the dust may be toxic.
- Keep the loft well ventilated. I open the window while the saw is running.

If the blade breaks, I switch off, unplug, wait for the wheels to stop and only then open the cover. A broken blade can whip around inside the housing, and I do not want to be near it.

## Tools

These are the tools and supplies I keep next to the saw:

- Spare blades, including a fresh standard blade and an older one reserved for plaster.
- A small screwdriver and a hex key set for the guides and the tracking knob.
- A push stick, made from a strip of scrap wood, for small pieces.
- A shop vacuum with a hose for the lower dust port.
- A soft brush and a hand brush for the table and the wheel housing.
- A pencil and a steel ruler for marking cut lines.
- A set square, to check that the blade is at a right angle to the table.
- A dust mask, safety glasses and ear protection, hung on a hook beside the switch.
- A roll of masking tape and a marker for dating blade changes.
- A small file for the ridge on the table.
- A damp cloth and a dry cloth for wiping down the table.

I keep these in a wooden crate under the saw's table so everything is within reach and nothing gets lost in the loft clutter.

## Measurements

I measured the power draw of the Drurkzork band saw with a plug-in meter while it was cutting a leather-hard stoneware slab at a steady feed. The reading was stable enough to note down.

| Item | Value |
|---|---|
| Measured power draw | 639.90 W |
| Energy source | mains |
| Location | loft |
| Year installed | 2025 |

The figure of 639.90 W is the power draw under load, while cutting. I did not record the idle draw in a careful way, so I do not quote it here. I would like to repeat the measurement with a bisque piece, because I expect the draw to be higher with the harder material.

Other things I have measured by hand and note in general terms: the gap between the guides and the blade is about a sheet of paper, the table sits flat enough for my work apart from the faint ridge, and the loft floor is uneven enough that the plywood pad is needed. I have not taken any further measurements, such as noise level, because I do not have the meter for it.
