---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Braessios heat exchanger."
---

# Braessios heat exchanger

## Maintenance

The Braessios heat exchanger is a black ceramic heat exchanger that sits in the shed. It runs on solar energy and was installed in 2015. Because it is in a shed and not in the house, I check it on a loose schedule and not by the calendar alone. The main rule is to look at it after any long spell of bad weather and again at the start of each season.

Routine checks I do:

- Wipe the black outer surface with a dry cloth to remove dust, cobwebs and grit. Dust on the surface cuts down how much solar heat it takes in.
- Look over the ceramic body for hairline cracks. I use a torch held at a low angle, since cracks show up best in raking light.
- Check the connections for dampness, staining or salt-like deposits that could point to a slow leak.
- Make sure nothing is stacked against the unit. The shed tends to collect boxes, and I want air to move freely around the exchanger.
- Listen while it warms up in the morning. Ticking is normal as ceramic expands, but sharp cracking is not.

Once a year, before the sunny months, I do a fuller check. I shut the system down, let it cool completely, and inspect every joint and gasket. I clean the fluid passages as far as I can reach, and I refill whatever needs topping up. I write the date of this check in my logbook, not in this note, so this note stays a stable reference.

Things I avoid: pouring cold water on a hot ceramic body, using abrasive pads on the surface, and moving the unit while it is still warm. Ceramic handles steady heat well but dislikes sudden change and knocks.

## Background

This is a heat exchanger in the ceramics area of my notes. I installed it in 2015 in the shed, and it has worked since then using solar energy as its only power source. The black color is not for looks. A dark surface absorbs sunlight better, which is the whole idea behind running it from the sun.

The reason for choosing a ceramic body was durability. Ceramic does not corrode the way many metals do, and it holds heat well, so the unit keeps giving off warmth for a while after the sun drops. The trade-off is brittleness, which shapes most of how I handle it.

The shed was picked as the location because it gets good sun for most of the day and is away from the daily traffic of the house. It also means that if something does go wrong, the damage stays out of the living space. On the other hand, a shed is colder, damper and dustier than a house, so the unit works in a tougher setting than I would give it indoors.

Quick facts for reference:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: solar
- Year installed: 2015
- Location: shed

Since 2015 I have had to deal with a few small things, mostly dust and a loosened connection, but nothing that has stopped it for long. I keep this note as the place where I gather what I know, so that I do not need to rediscover it each time I open the shed door.

## Risks

The biggest risk is cracking. Ceramic can take heat, but it does not forgive impact or quick temperature swings. A cold night followed by strong direct sun on a very cold body is the situation I watch for most, especially in winter.

Other risks I keep in mind:

- Frost damage. If any fluid stays in the passages during a freeze, it can expand and split the ceramic. In cold weather I make sure the system is drained or protected.
- Overheating. Solar input is not something I can turn down easily, so on a hot, clear day with no flow the unit can get hotter than intended. I do not leave it running without circulation.
- Leaks at connections. Joints are usually the first weak point, since they carry the stress of expansion and contraction.
- Damage from stored items. A falling tool or a box pushed against the body could chip it. The shed is a working space, so this is a real possibility.
- Burns. The black surface gets hot in the sun, and I treat it as hot even when it looks calm.
- Moisture and pests. Damp air and small animals nesting nearby can interfere with the connections and block airflow.

If I find a crack, I stop using the unit straight away. I do not try to patch a structural crack and carry on, because a small split can grow under heat. I would rather lose a few days of use than lose the whole body.

## Parts

The part number of the Braessios heat exchanger is XQ-9820-K. I use this when I look for matching spares or when I need to describe the unit to someone else.

Parts I keep an eye on:

- The ceramic body itself, which is the main and most expensive piece.
- Gaskets and seals at the connections, which wear out first and are the easiest to replace.
- Fittings and clamps, which can loosen with repeated heating and cooling.
- The surface finish, which gives the black color and helps absorb sunlight. If it wears thin, performance may drop.
- Mounting supports, which hold the unit steady and keep it off the shed floor.

I keep a small stock of spare gaskets in a labeled box in the shed, since those are the parts most likely to fail. For anything bigger, I would quote the part number above when asking a supplier, and I would compare the new part with the old one before installing it. Because the unit dates from 2015, some parts may no longer be sold in the same form, so I note down any substitute that worked.

## Costs

I do not keep exact figures in this note, since prices change and I record them in my accounts instead. What I can say is how the costs are shaped.

The purchase and installation in 2015 was the largest single cost. Since then the running cost has been very low, because the energy source is solar and there is no fuel to buy. That is the main advantage of this setup.

Ongoing costs are small:

- Cleaning cloths and basic supplies, which cost almost nothing.
- Replacement gaskets and seals, bought occasionally.
- Fluid top-ups during the yearly check.
- My own time, which I do not charge for but which is worth remembering.

The costly event would be a cracked ceramic body, since replacing it would approach the cost of a new unit. This is why I put effort into prevention. A few minutes of checking each season is cheap next to a full replacement. If I ever have to decide between repair and replacement, I will compare the price of the new body with the expected remaining life of the other parts, and I will also consider whether a newer design would suit the shed better.
