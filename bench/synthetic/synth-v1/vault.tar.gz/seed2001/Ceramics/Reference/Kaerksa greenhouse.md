---
type: reference
status: active
project: reference
area: ceramics
---

# Kaerksa greenhouse

## Overview

Kaerksa greenhouse is a small greenhouse built in 1998 and used for the ceramics work. It faces north, so it gets soft, even light and very little direct sun. The floor is raised, which keeps the ground level off the damp soil and makes it easier to sweep out clay dust and dried slip. The kind of place is simply a greenhouse, but in practice I treat it as a quiet workroom with plants in it.

Quick properties for reference:

- Kind: greenhouse
- Area: ceramics
- Orientation: north
- Size: small
- Year built: 1998
- Floor: raised

Because it is small, I can only run one activity at a time. If trays of drying pieces are out, the plant benches have to be pushed to one side. The north orientation means it stays cool in summer, which is good for slow drying of pieces and bad for anything that needs warmth in early spring.

Related notes I come back to when I think about this space: [[Nedirk heat exchanger tests]] for the heating question, [[Burstimu kiln controller 2019]] for how the kiln side was set up, and [[Nirde workshop tests]] for the comparison with the other building.

## Checklist

Things I go through on each visit. I keep it short so I actually do it.

1. Check the door seal and the vents before leaving, both open and closed positions.
2. Look at the raised floor boards for soft spots or standing water underneath.
3. Wipe the benches. Clay dust left on the benches ends up on the leaves and on the tools.
4. Turn the drying pieces so they dry evenly. The side near the north wall stays damper.
5. Check the glass panels for cracks or loose clips, especially after wind.
6. Empty the catch buckets and rinse them. Do not pour slip down the drain.
7. Check the heater and the power strip. Nothing should sit on the floor near the door.
8. Note anything that needs buying, and write it on the list in the shed.

Once a season I also do a longer pass: wash the glass inside, clear the gutters outside, and re-level any bench that has shifted.

## Admin

The paperwork for the place is small but easy to lose, so it is all here.

- Lease reference of Kaerksa greenhouse: LR-931491
- Contact for the site and access questions: [[Serpi Muntran]]
- Contact for equipment and repairs: [[Glendrol Naefur]]

I keep a paper copy of the lease in the folder in the shed and a scan in the shared drive. Any change to the building, such as a new vent or a changed heater, should be agreed first, so I message the site contact before I start and write down the answer in this note.

Repairs to glass and framing go through the equipment contact. For anything I fix myself, I take a photo before and after and add it to the folder.

## Lessons

What I have learned from using the greenhouse over time.

- The north orientation is a trade-off. It avoids heat spikes and scorched leaves, but the space stays cold longer in the morning. Heating tests, such as [[Nedirk heat exchanger tests]], were worth doing because guessing led to wasted fuel.
- The raised floor was a good feature. Water drains away, the boards dry quickly, and cleaning is easier than on bare ground. The only cost is that I have to check underneath now and then.
- Small size means discipline. Anything I leave out blocks something else. I clear the benches at the end of each session, even if I am tired.
- Controller settings from the kiln work, described in [[Burstimu kiln controller 2019]], should not be copied directly to the greenhouse. The space behaves differently, and the humidity changes how pieces dry.
- Comparing with the other building through [[Nirde workshop tests]] helped me see what is specific to this place and what is common to any workspace.
- Write down problems on the day. Notes made a week later are vague and I stop trusting them.

Next time I update this note I want to add a simple seasonal plan, covering when to move drying work in and out, and when to put the plants back on the benches.
