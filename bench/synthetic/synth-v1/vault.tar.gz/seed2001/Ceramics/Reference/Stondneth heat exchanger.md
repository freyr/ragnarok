---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Stondneth heat exchanger."
---

# Stondneth heat exchanger

## History

The Stondneth heat exchanger is a green ceramic heat exchanger that was installed in 2017 at the pond. It runs on a battery, which was a deliberate choice, since there is no mains socket near the water and I did not want a long cable lying through the wet grass.

I first read about the idea in my notes on the [[Vanstol heat exchanger study]], where the ceramic core came out better than the metal ones for water that stays cold and a bit dirty. The shed that holds the battery charger was planned in [[Trenvios shed plan]], and the exchanger itself went in a few weeks after that shed was finished.

The first season was rough. The battery drained faster than I expected, and I had to swap it twice in the first summer. After that I moved the battery to a dry box on the bank and the problem mostly went away. [[Koguni Vopa]] helped me carry the unit down to the pond and gave advice on how to level it in the mud. I still use that advice.

Since 2017 the unit has stayed in the same place. I have not replaced the ceramic core, and I have only changed the battery a few times for age, not for faults.

## Safety

Water and electricity are in the same spot, so I treat this device carefully.

- The energy source is a battery, so there is no mains voltage at the pond. That is the main reason I picked it.
- I disconnect the battery before touching the pipes or the core, every time, even for a quick look.
- The ceramic is green glazed and slippery when wet. I wear gloves and stand on the flat stones, not on the mud.
- The ceramic can crack if it gets a hard knock or a sudden temperature shock. I never pour hot water on it to clear a blockage.
- The battery box stays closed and raised above the waterline. If the water level rises after heavy rain, I check the box first.
- When I cut the mounting boards I use the [[Luki band saw]] in the workshop, never at the pond, and I keep the offcuts away from the water.

If the unit feels warm to the touch around the battery connection, I stop it and leave it disconnected until I find the cause.

## Measurements

These are the values I keep for reference.

- Kind: heat exchanger
- Area: ceramics
- Color: green
- Energy source: battery
- Year installed: 2017
- Location: pond
- Flow rate: 958.28 l/h

The flow rate of 958.28 l/h is the figure I wrote down when the unit was running on a fresh battery with a clean core. It drops as the battery runs down and as the core gets dirty, so I only compare new readings against it under the same conditions.

For comparison with a pump-driven setup, the notes in [[Tangio circulation pump study]] explain how I measured flow back then. I use the same bucket and timing method here, and I repeat the reading three times and take the middle one. I do not trust a single reading, because the water level in the pond changes the result a little.

I also note the battery state at the time of each reading, because that explains most of the differences I see from one visit to the next.

## Maintenance

My routine is simple and I keep to it.

1. Check the battery charge every two weeks in summer and once a month in winter.
2. Swap the battery when it can no longer hold a charge through a full day. I charge the spare in the shed.
3. Rinse the green ceramic core with pond water and a soft brush in spring. No soap, because it ends up in the pond.
4. Look over the pipe joints for leaks and tighten the clamps by hand.
5. Check that the unit is still level. Mud settles, and a tilt changes the flow.

The air line I use to blow out the small pipes comes from the compressor described in [[Taskras air compressor notes]]. I keep the pressure low, because the ceramic does not like being pushed hard.

Longer jobs, such as moving the unit or changing the clamps, go into the [[Sesdiortes workshop log]]. Smaller repairs and parts I bought go into the [[Krulpind workshop log]]. I try to write the entry the same day, since I forget the details quickly.

## Observations

The exchanger has been reliable for a device that sits outside all year. The battery is the weak point, not the ceramic. The green glaze has faded slightly but has not chipped.

Some things I have noticed over the years:

- Algae grows on the core fastest in late summer, and the flow falls noticeably when it does.
- Cold snaps do not seem to bother the unit as long as the water is moving and the pipes are not left full of still water.
- The unit is quiet. At the pond I mostly hear the water, not the device.
- The location at the pond works well for access, but a bit more shade over the battery box would help the battery last longer.

Things I would like to try next: a second battery on a simple changeover so I never have a gap, and a small cover over the core to keep leaves out. I should also compare the Stondneth against the unit in the [[Vanstol heat exchanger study]] again, now that both have run for several years.
