---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Niosdan greenhouse."
---

# Niosdan greenhouse

## Lessons

Niosdan greenhouse is a greenhouse that I use for ceramics work. It is large, and it faces east, so the morning sun comes in early and the glass warms up well before midday. It was built in 2001, and the floor is raised, which matters more than I first thought.

The raised floor keeps standing water away from the work benches. When I hose the paths down, the water drains below the boards and does not pool around the legs of the racks. Greenware stored near the floor dries more evenly than it did in my old shed, where the ground stayed damp for days.

Things I have learned from using the place:

- Because the greenhouse faces east, the morning side dries pots fastest. I put thin or delicate pieces on the far side, away from the early sun, so they do not dry too quickly and crack.
- Large pieces go on the shelves nearest the door, where they have room and where I can turn them without bumping anything.
- The space is large, so it is easy to let things spread out. I keep one bench clear for trimming and finishing, and I do not store buckets there.
- Afternoon light is weaker, so any drying I want to finish in a day has to start early.
- An older building from 2001 needs a regular check of the panels and seals. I look for gaps after every windy week, since a draft across damp clay will warp it.
- I wipe the raised floor boards weekly. Clay dust builds up in the gaps and holds moisture.

If I could change one thing, I would add a second shelf unit along the west wall for slow-drying work. For now I rotate pieces around the room and keep notes on which spot suits which kind of piece.

## Measurements

I take readings at bench height, in the middle of the room, away from the door and from any wet buckets. The most useful reading to keep is the humidity.

- Measured humidity of Niosdan greenhouse: 43.35 %

At that level, thin pieces dry safely if I leave them alone. For thick pieces I would want the air a little more humid, or I cover them loosely with plastic. I check the reading in the morning, before the sun has warmed the east side, because that gives the most stable number to compare from day to day.

Other fixed facts: kind is greenhouse, area is ceramics, orientation is east, size is large, built in 2001, floor is raised.
