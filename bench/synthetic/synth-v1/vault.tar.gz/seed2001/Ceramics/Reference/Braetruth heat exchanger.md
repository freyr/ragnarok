---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Braetruth heat exchanger."
---

# Braetruth heat exchanger

## Setup

The Braetruth heat exchanger is a heat exchanger that I use for ceramics work. It is black, and it runs on solar energy. I installed it in 2017 and it sits in the shed, against the south wall where the roof panel feed comes in.

I keep this note as a reference for myself, so it lists what the device is and how I run it. The short version of the properties:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: solar
- Year installed: 2017
- Location: shed

The unit is a plain black body with two pairs of connections. One pair takes the hot side from the solar loop. The other pair serves the drying rack I use for greenware and for glaze tests. I mounted it at chest height so I can see the gauges without bending down. The shed has a bench on the left, and the exchanger is on the wall to the right of the door, so the pipes stay short.

When I set it up in 2017, I flushed the loop twice before I trusted it. I also checked every joint with a dry paper towel, because a slow weep is easy to miss on a black body. I still do that check at the start of each season.

On a sunny day the unit warms up slowly, and that suits me. Greenware cracks if it dries too fast, so a gentle, steady heat is better than a strong one. On cloudy days it barely does anything, and I plan my drying around the weather.

## Ideas

Some things I want to try, in no particular order:

- Add a small insulated box around the drying rack so the warm air stays in. I want to compare it with the open rack, and I could write the results up next to [[Fulmasvork workshop tests 2024]].
- Fit a simple thermometer at both ends of the hot side, so I can see how much heat the exchanger really takes out. At the moment I only guess from touch.
- Link the loop to a small pump with a better flow rate. The notes in [[Tangio circulation pump study]] are a good starting point for choosing one.
- Use spare heat in the evening to pre-warm the kiln room. The control side of that would need something like what I built in [[Burstimu kiln controller 2019]].
- Paint the pipes between the roof and the shed with a matte black coating, to lose less heat on cold mornings.
- Try a timer on the drying rack fan, so it only runs when the exchanger is actually warm.

An idea I dropped: using the exchanger to heat water for the pond. The pond is too far away and the pipe run would lose most of the heat. The reasoning is in [[Nantusves pond log]].

## Maintenance

I do the work in a fixed order so I do not skip anything.

**Every season (spring and autumn):**
1. Look over all joints for weeping, stains or white crust.
2. Wipe the black body clean and check for dents or hot spots.
3. Check the loop pressure and top up if needed.
4. Bleed air from the highest point. Air in the loop is the most common reason for poor heat.
5. Run the unit for an afternoon and feel along the pipes for cold stretches.

**Once a year:**
- Flush the hot side with clean water until it runs clear.
- Check the hose clamps and tighten them gently. Over-tightening has cracked a fitting on me before.
- Inspect the mounting bolts on the wall bracket.

**When something looks wrong:**
- If the drying rack side stays cold on a sunny day, bleed the loop first, then check the pump.
- If I see damp on the shed floor, I shut the loop at once and trace it from the top down.
- If the heat is weak but everything else is fine, I look for dust on the roof panel.

I log every visit with a short line in my notes, including what I changed. That log has saved me more than once when I could not remember if I had already flushed the loop.

## Tools

The tools I keep in a box under the bench for this device:

- Two adjustable spanners, one large and one small
- A set of screwdrivers, flat and cross
- A bleed key for the air vent
- Spare hose clamps and a roll of thread tape
- A bucket and a few old towels
- A hand pump for topping up the loop
- A small infrared thermometer for checking pipe temperature
- A torch, because the shed is dark in the corners
- Dry paper towels for leak checks

For air in the lines I sometimes borrow the blower setup described in [[Taskras air compressor notes]], but only at very low pressure. I never push compressed air through the exchanger body itself.

For anything electrical near the shed, such as the fan and the timer, I refer to [[Vorful radio receiver handbook]] because it has the wiring habits I like to follow, even though the topic is different.

## Risks

The main risks, as I see them:

- **Scalding.** The hot side can get very hot on a clear day. The black body absorbs sun through the shed window and can burn a careless hand.
- **Leaks.** A slow leak damages the shed floor and the bench. It can also drip onto stored clay and spoil it.
- **Air lock.** Air trapped in the loop stops circulation. The unit then looks fine but does nothing.
- **Frost.** If the loop freezes it can split a fitting. I drain or protect it before a hard frost.
- **Overheating the greenware.** If I put pieces on the rack in full sun with no airflow, they dry unevenly and crack.
- **Neglect.** The unit has been in place since 2017. Old seals and clamps are the weak points, so skipping a season of checks is a real risk.

Notes from an earlier attempt to dry large pieces fast are in [[Zukriond loft notes]]. The lesson there was that patience beats heat.

I also keep a mental list of what I would do if the exchanger failed in the middle of a drying cycle: move the pieces to a covered, shaded shelf and let them dry slowly. That has worked every time.

## Parts

The part number of the Braetruth heat exchanger is DT-8002-F. I quote it whenever I ask for a spare or look for a matching fitting.

Other parts that belong to the setup, without numbers:

- Wall bracket with two bolts
- Hot side hoses and clamps
- Drying rack side hoses and clamps
- Air vent at the highest point
- Pressure gauge on the loop
- Isolating valves at both ends
- Insulation sleeves on the roof pipes

I keep the old clamps and washers in a labeled jar, because the same sizes fit other things in the shed. When a part wears out I write down what failed and how long it lasted. Some of that thinking carried over from [[Baerkpend Drormaeth notes 2022]], where I first started keeping part histories in a consistent way.

## Safety

My rules for working with this device:

1. Let the unit cool before touching the body or the joints. If I must work in the afternoon, I cover the black body with a light sheet first.
2. Wear gloves when opening the loop. Hot water can spray out when pressure drops.
3. Close both isolating valves before removing any hose.
4. Keep the shed floor dry. A wet floor and a ladder are a bad mix.
5. Never use compressed air at high pressure on the exchanger.
6. Keep the fan and timer wiring away from the pipes, and unplug before any repair.
7. Do not leave the shed door closed on a hot day with the unit running. The air gets stuffy and the temperature climbs fast.
8. Tell someone when I am working alone on the roof side of the loop.

If I get a burn, I cool it under running water for a good while and do not rush back to the job. The work can wait. Because the unit is solar, it cannot be switched off at a socket, so I rely on the valves and on shading the panel when I need it quiet.
