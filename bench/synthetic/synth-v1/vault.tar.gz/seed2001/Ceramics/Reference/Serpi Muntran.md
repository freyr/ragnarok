---
type: reference
status: active
project: reference
area: ceramics
---

# Serpi Muntran

## Risks

Serpi Muntran is a plumber whose work overlaps with ceramics, so most of the risk sits where pipes meet fired or glazed material. I have known Serpi since 2020, and the points below are what I watch for when planning a job.

- Availability is weekdays only. Anything urgent on a weekend has to wait or go to someone else, so I try to book early in the week.
- Contact is by email. There is no quick phone call, so I write down the full job details in the first message to avoid a slow back-and-forth.
- Ceramic fittings and kiln-room drains crack if they are tightened too hard or heated unevenly. I check the notes in [[Genketh Vorkdios tests]] before choosing any fitting.
- Older work in the building may not match current layouts. [[Rutro Storkstal notes 2018]] has the earlier pipe routes, and I should hand those over before Serpi starts.
- Water near tools is a hazard. Anything near the [[Luki band saw]] needs to be covered or moved first.
- Small outbuilding work, such as in [[Krespa shed plan]], may need extra pipe length that is not in the first estimate.

## Quotes

The quoted price of Serpi Muntran is 6038.80 EUR. I read it as covering the main job, but I should confirm in writing what is included before agreeing to anything.

Things to check when the quote is revisited:

- Whether materials are included or billed separately.
- Whether the weekday-only schedule affects the finish date.
- Whether any earlier agreements, such as those in [[Sesdiortes workshop log]], change the scope.

If the scope grows, I will ask for a revised quote by email and keep the reply with my other records. For a second opinion I can ask [[Riorraen Saethkion]] or [[Koguni Vopa]], and [[Baerkpend Drormaeth notes]] has some price comparisons from similar jobs.
