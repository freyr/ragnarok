---
type: reference
status: archived
project: reference
area: ceramics
description: "Reference about Guverk barn."
---

# Guverk barn 2024

## Maintenance

This note is archived. It records how Guverk barn stood in 2024. Later notes replace the values here, so check the newer notes before relying on anything below.

Guverk barn is a small barn built in 2012. It is used for ceramics work, and the building faces north. The floor is raised, which matters for most of the upkeep, because air moves under the boards and the underside needs to be looked at, not only the top.

In 2024 I kept the maintenance routine simple and did it in the same order each time. The main jobs were:

- Sweep the floor dry before anything else. Clay dust turns into paste if it meets a wet mop.
- Check the underside of the raised floor for damp, droppings and loose boards.
- Look at the north wall for staining or soft spots after heavy rain.
- Wipe down the work tables and the shelves where the drying pieces sit.
- Clear the vents under the floor so air can still pass through.
- Check the door seal and the window catches before the cold months.

Because the barn faces north, it gets little direct sun. It stays cool in summer, which I liked, but it also stays damp longer after wet weather. The wall and the vents were therefore the places I watched most closely. A raised floor helps against ground moisture, yet it only works while the vents stay open.

I did the full round once a season and a short round, floor and vents only, once a month. When something needed repair I wrote a short line in the log rather than trusting my memory.

## Dimensions

The barn is small. It is one room with no inner walls, and the raised floor sits clear of the ground on short supports.

The floor area of Guverk barn is 241.63 m². I measured it from the inside faces of the walls, so it does not include the thickness of the walls themselves.

The table gathers every property of the barn as it was recorded in 2024.

| Property | Value |
| --- | --- |
| Kind | barn |
| Area | ceramics |
| Orientation | north |
| Size | small |
| Year built | 2012 |
| Floor | raised |

The word "small" here is a label I use for myself, to separate this barn from the larger buildings I have written about. It is not a formal class. The measured floor area above is the figure to use when planning how many tables, racks and kiln stands will fit.

When I laid out the room I left a clear walking lane down the middle and kept the heavy items close to the supports, where the raised floor is strongest. That habit came from the way the floor feels underfoot: it is solid, but I did not want to test it with a loaded kiln stand in the middle of a span.

## Open questions

These were still unsettled when I wrote this note in 2024. Later notes may have answered them.

- Is the north wall taking in more moisture than it should, or is the staining only surface damp that dries off in spring?
- Would a few more vents under the raised floor improve airflow, or would they only let in more cold?
- Is the floor strong enough for a second, heavier kiln stand, and where would it sit?
- Would a small dehumidifier help in the wet months, and is the power supply good enough to run one all day?
- Should the work tables be moved away from the north wall to keep the clay from staying damp?
- Is it worth adding a light source on the north side, given how little sun comes in?

I did not have answers to any of these. I only noted the questions, and I planned to watch the wall and the vents through another year before changing anything.

## Tools

The tools I kept in the barn for upkeep were few and plain. I stored them by the door so they were easy to reach.

- A stiff broom and a soft brush for the floor and the shelves
- A dustpan with a long handle
- A torch for looking under the raised floor
- A damp meter for the wall and the boards
- A putty knife and a small tin of sealant for gaps
- A screwdriver and a hammer for loose boards and catches
- Buckets, sponges and cloths for the tables
- A notebook for the log

The damp meter was the most useful of these. A reading takes a few seconds, and it told me more than my eyes did. I took readings at the same three spots each time so that the numbers could be compared from one visit to the next.

I kept the sealant tin closed tightly and checked it each spring, because it dries out in the cool air of the barn if the lid is loose.

## Setup

The barn is arranged for ceramics work. The wet work is done at the tables in the middle, the drying shelves are along the side walls, and the kiln stands are close to the supports of the raised floor.

The layout in 2024 was roughly this:

- Work tables in the centre, with the lane left clear on both sides
- Drying shelves along the walls that are not the north wall
- Tools by the door
- Kiln stand near the strongest part of the floor
- Storage for clay in the driest corner

I kept the north wall mostly clear so that I could see it and reach it for the damp checks. Nothing was stacked against it.

For the monthly round I used a short checklist, saved in my notes as a plain file. This is the content of it:

```
# guverk barn monthly round
[ ] sweep floor dry
[ ] check vents under floor
[ ] damp meter: three spots, write readings in log
[ ] look at north wall
[ ] wipe tables and shelves
[ ] note any repairs needed
```

I ticked each line on paper and then copied any repair into the log. If the readings seemed higher than usual, I did the full seasonal round early instead of waiting.

This setup is the 2024 state only. If the layout has changed since, the newer notes hold the current version, and this one stays as a record of how the barn was.
