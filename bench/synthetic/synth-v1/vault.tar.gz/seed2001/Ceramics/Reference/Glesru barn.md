---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Glesru barn."
---

# Glesru barn

## Observations

Glesru barn is a small barn used for ceramics work. It was built in 2004 and sits at ground level, with no steps up to the door and no loft floor to climb to. The building faces east, so the doorway catches the morning light and the first sun of the day reaches the working area early.

What I notice most when I am there:

- The east orientation gives good light for glazing and for checking surface colour in the morning.
- Afternoons are noticeably cooler and more even, which helps when pieces are drying slowly.
- Ground-level access makes it easy to move heavy bags of clay and loaded boards in and out without lifting.
- The barn is small, so it fills quickly. Anything not in daily use has to be stored elsewhere.
- Being built in 2004, it is not new. The timber has settled, and I check the door seal each season.

The layout is simple. The wheel stands closest to the door for the light. Shelves run along the back wall for drying pieces. The cleaning bucket and the scrap clay bin stay near the entrance so dust and slip do not travel further inside.

A few habits keep the space usable. I sweep with a damp mop rather than a dry brush to keep dust down. I leave the door open for a short time after finishing so the air changes. I keep a short checklist pinned inside, copied below as a plain note of what I do at closing time.

```
# closing routine, Glesru barn
1. cover unfinished pieces with plastic
2. wipe the wheel and the table
3. empty the slip bucket into the settling tub
4. damp-mop the floor
5. check the door latch (east side)
```

This routine is short on purpose. If a step is too long, I skip it, and then the barn gets messy. Five quick steps are the most I will reliably do at the end of a tired day.

## Dimensions

The barn is small, and the measurements below are what I use when planning where to put equipment or shelving.

- Floor area: 50.23 m²
- Size category: small
- Floor level: ground level
- Orientation: east
- Year built: 2004

With a floor area of 50.23 m², the barn holds one wheel, a worktable, and drying shelves without feeling empty, but it cannot take a second workstation comfortably. If I ever add a kiln, it will need to go outside or into a separate shed, because the interior has no spare room for the clearance a kiln needs.

Because the floor is at ground level, the whole area can be used for storage and movement without ramps. That makes the floor area more useful than the same figure would be in a barn with a raised or split floor. When I plan a change, I mark the layout on the floor with tape first, leave it for a few days, and see whether I can still walk through with a loaded board before I move anything permanently.
