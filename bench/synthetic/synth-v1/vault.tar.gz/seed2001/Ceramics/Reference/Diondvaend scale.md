---
type: reference
status: active
project: reference
area: ceramics
---

# Diondvaend scale

## History

The Diondvaend scale is a grey scale used for ceramics work. It was installed in 2018 and it has stayed in the barn ever since. I keep it there because the clay, glazes and finished pieces are all stored and weighed in that space, so I do not have to carry anything far.

It runs on solar power. There is no mains lead to it. On dull weeks the display gets slow to wake up, but I have never lost a reading because of it. If the barn is shut up for a long time, I open the door and give it a few minutes of light before I use it.

Before this scale I weighed batches in the old store at [[Guverk barn]]. That setup was awkward, so the move to the new barn made sense. I still check the other building, [[Glesru barn]], when I look for spare weights and bags.

I have tested the scale against known weights a few times. The results from the latest round are in [[Fulmasvork workshop tests 2024]]. It held steady, and I did not need to adjust it.

The barn also holds some other equipment, and I keep separate notes on it. See [[Drirvuth air compressor notes]] for the compressor, and [[Drurkzork band saw]] for the saw. When something odd happens in the barn, I add it to [[Rabronstol Gothdraerk log]].

## Parts

The scale is a simple unit with a platform, a display, and a solar panel. Its part number is NV-5578-V. I use that number when I look for a replacement or when I describe the scale to someone else.

- Platform: the flat grey top where the buckets and boards go. Wipe it down after every glaze session, because dust and slip build up fast.
- Display: shows the weight. It is easy to read in the barn light.
- Solar panel: the only energy source. Keep it clear of clay dust, or it will charge badly.

The scale sits well away from the kiln heat. For notes on how heat moves around the barn, see [[Braessios heat exchanger]]. Heat is the main thing that can harm the display, so I keep that distance on purpose.
