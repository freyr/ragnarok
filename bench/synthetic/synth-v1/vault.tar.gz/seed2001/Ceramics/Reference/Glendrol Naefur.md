---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Glendrol Naefur."
---

# Glendrol Naefur

## History

I first came across Glendrol Naefur in 2022, and I have known him since then. He works as an inspector, and his area is ceramics. Most of what I know about his work comes from the times I asked him to look over pieces before I committed to buying or showing them.

The first contact was a short exchange about a batch of glazed tiles that looked fine on the surface but had hairline cracks I could not judge myself. He looked at them and explained what to check: how the glaze sits near the edges, how the body of the piece sounds when tapped, and where moisture tends to collect. Since then I have used the same checks on my own.

His contact method is email. He does not answer calls or messages in other places, so I send everything there. I keep my questions short and list the details he needs: the kind of piece, the firing type if I know it, the photos I have, and what I am worried about. When I do this he usually replies with clear answers and few extra questions.

His availability is evenings. Anything I send during the day waits until he is free, so I do not expect a quick answer and I plan around that. If I need something checked before a weekend, I write at the start of the week, not at the last moment.

Things worth remembering when I work with him:

- Role: inspector.
- Area: ceramics.
- Contact: email.
- Availability: evenings.
- Known since: 2022.
- Send photos taken in daylight, with a scale object in the frame.
- Mention any repairs or earlier damage right away.

Over the years he has become a steady point of reference for me. I do not treat his word as final on everything outside ceramics, and he does not pretend to cover other materials. For pottery, tiles and fired items, though, his opinion is the one I trust most.

## Quotes

The only price I have from him is a quoted price of 3797.51 EUR. I wrote it down after he assessed a larger lot, and I keep it here as a reference point for what a full inspection of that kind of work can cost.

I do not assume this figure applies to every job. A small single piece would be priced differently, and the scope of the lot mattered a great deal. Before I ask for a new quote, I note what has changed since the last one: the number of items, their condition and the time he would need.

When I request a quote, I ask him to state what is included, so I can compare it with this one without guessing.
