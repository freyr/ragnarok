---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Saenber band saw."
---

# Saenber band saw handbook

## Background

The Saenber band saw is a red band saw that I use for ceramics work. It runs on mains power. I installed it in 2020, and it lives in the shed at the back of the garden. This note is the reference I keep for it, so that I do not have to remember the details each time something changes.

Here are the basic properties in one place.

| Property | Value |
|---|---|
| Kind | band saw |
| Area | ceramics |
| Color | red |
| Energy source | mains |
| Year installed | 2020 |
| Location | shed |

I bought the saw because I wanted a machine that could cut fired and unfired clay shapes, trim dried slabs, and shape plaster molds without the mess and effort of doing it all by hand. Before it arrived I used a hand saw and a wire cutter. Both worked, but both were slow, and neither gave a clean straight edge on thick pieces. The band saw changed that quite quickly.

The shed is not a perfect workshop. It is a plain wooden building with one window, a concrete floor in the front half, and a socket near the door. I put the saw on the concrete part, a short walk from the door, so I can pull it a little way out when I need to feed long pieces through. The red color is useful in practice: it is easy to see in a dim shed, and I am less likely to walk into it when carrying something heavy.

Since the saw uses mains power, it has to be plugged in to work. I do not use an extension reel with it. The cable reaches the socket directly, and I keep it off the floor where dust and water collect. Any time I clean the machine I unplug it first. That is the one rule I never skip.

A few general points about how I think of this machine:

- It is a general cutting tool, not a precision instrument. I treat it as good for rough shaping and for cutting to a line, and I finish edges by hand afterward.
- It is a dusty machine when used on dry or fired material, so I use it only with the shed door open.
- It is not a wet saw. I keep water away from the motor and the switch at all times.
- It stays in the shed all year, so I check it for damp after winter.

I started this note a few years after installing the saw. By then I had learned enough through mistakes that I wanted the lessons written down in one place. The sections that follow cover what I keep in stock for it, what I have learned, what has gone wrong, and what it has cost me over time.

## Supplies

I keep a small, fixed set of supplies for the saw. Running out of any of them in the middle of a job is annoying, because the shed is a walk from the house and the shops are further still.

The main consumable is the blade. A band saw blade is a loop of toothed steel, and for ceramics work the choice of blade matters more than I first expected. A coarse blade tears soft clay and leaves ragged edges. A fine blade clogs quickly on damp material. I now keep spare blades in two types: one with wider teeth for green clay and plaster, and one with finer teeth for harder, drier material. I always keep at least one spare of each in a drawer, wrapped in a cloth so the teeth do not catch on anything.

Other things I keep nearby:

- A dust mask rated for fine particles. Dry clay and plaster dust are bad for the lungs, and I wear the mask every time.
- Safety glasses, hung on a hook next to the saw so I cannot forget them.
- A stiff brush and a small hand brush for clearing dust from the table and the wheel housings.
- A vacuum with a fine filter, used for the floor and the inside of the saw after a session.
- A few push sticks cut from scrap wood, so my fingers stay well away from the blade.
- A light machine oil and a clean rag for the moving parts that need it.
- A small tin of wax, which I rub on the table so pieces slide smoothly.
- Spare cloths, mostly old towels, for wiping down and for wrapping blades.

I keep these in a plastic crate under the workbench beside the saw. Nothing sits on the saw itself. Early on I left things on the table, and they slid into the blade path more than once.

For storage, I hang the spare blades loosely on a hook rather than stacking them flat, because a bent coil can kink and then cut crooked. I also keep a small notebook in the crate, where I write the date each time I change a blade, so I can judge how long a blade actually lasts. This is a simple habit but it has saved me from guessing.

One more item worth mentioning is light. The shed has one window and one ceiling bulb, which is not enough for careful cutting. I added a clip lamp that points at the table. It cost very little and made a real difference to how accurately I cut along a marked line.

## Lessons

Most of what I know about this saw came from doing things wrong first. These are the lessons I would give to anyone starting out with the same machine.

**Set the blade tension properly.** If the blade is too loose, it wanders and the cut curves away from the line. If it is too tight, it wears faster and puts strain on the wheels. I now check tension by pressing the side of the blade lightly with a finger, with the saw unplugged, and I look for a small, firm amount of give. I re-check after every blade change.

**Let the saw do the work.** Pushing a piece hard into the blade does not speed things up. It makes the blade bend and the cut rough. A slow, steady feed gives a cleaner edge, especially in fired material where the blade can skip.

**Match the material to the blade.** I learned this the hard way when I tried to cut a hard fired piece with the wide-toothed blade. The blade chattered, the piece cracked, and the teeth dulled quickly. Now I swap blades before I start, not halfway through.

**Support the work.** Long or heavy pieces need support on both sides of the table. I use a small stand at the same height as the table for anything longer than my forearm. Unsupported pieces tip, pinch the blade, and sometimes snap it.

**Keep the guide close.** The blade guard should sit just above the piece, not high in the air. A low guard protects my hands and also keeps the blade steadier.

**Clean after every session.** Dust builds up on the wheels and the table faster than I thought. A thin layer of damp clay dust on a wheel can make the blade track badly. Five minutes with the brush and vacuum at the end of a session is much better than a long cleanup later.

**Mark the line clearly.** In the dim shed, a faint pencil line is easy to lose. I use a bold marker on clay and a scratched line on plaster, and I cut on the waste side of the line so I can trim back to it.

A short routine I follow each time:

1. Unplug the saw and check the blade for cracks or missing teeth.
2. Check tension and the position of the guard.
3. Put on the mask and safety glasses.
4. Open the shed door and plug in.
5. Run the saw for a few seconds before the first cut, listening for anything odd.
6. Cut slowly, supporting the piece.
7. Unplug, brush, vacuum, and wax the table.

I have kept to this order for years, and it has prevented most accidents and ruined pieces. The only time I have gotten hurt was when I skipped the first step and reached in to clear a bit of clay while the saw was still connected. Nothing serious happened, but I have not forgotten it.

## Problems

These are the problems I have run into with the saw, with what I did about each one. I list them roughly in the order they appeared.

**The blade keeps wandering.** This was the first problem. The cause was nearly always tension or a dull blade, and once it was a build-up of dust on the lower wheel. I now check all three in that order. If the blade still wanders after a fresh blade and correct tension, I clean both wheels thoroughly.

**The blade snaps.** This has happened a handful of times. The usual causes were forcing the piece, cutting a tight curve with a wide blade, and leaving the blade too tight for a long time. A snapped blade is startling but not dangerous if the guard is low and the door of the housing is closed. I now choose narrower blades for curves and release the tension when the saw will sit unused for a long time.

**Damp in the shed.** The shed is not heated, and in winter moisture collects on the metal parts. I found light rust on the table one spring. I removed it with fine abrasive paper, then waxed the surface. Since then I wipe the table with an oily rag before the cold months and keep a bag of moisture absorber on the shelf nearby.

**Dust in the motor area.** Fine clay dust gets everywhere. After one long season, the motor casing was coated and the saw smelled warm in use. I now vacuum the vents regularly and I do not let dust sit. I also avoid cutting dry, powdery material without the door open.

**The switch sticking.** At one point the switch became stiff, probably from dust. I unplugged the saw, cleaned around the switch with a small brush, and it freed up. If it ever sticks again I will stop using the saw and have it looked at, because a switch that does not turn off is not something to gamble with.

**Rough cuts in fired material.** When the cuts came out chipped, the blade was almost always the wrong type or worn. A fresh fine blade and a slower feed fixed it. Some chipping is normal with hard, brittle material, so I leave extra material to sand off.

**Noise and vibration.** The saw hums and shakes a little when the wheels are dirty or the blade is badly fitted. A new blade and a clean wheel usually remove it. If the noise changes suddenly, I stop and look.

Here is a quick guide I use when something goes wrong:

| Symptom | Most likely cause | First thing to try |
|---|---|---|
| Cut curves away | Loose blade or dull teeth | Check tension, then swap blade |
| Blade snaps | Forcing the piece | Slower feed, narrower blade for curves |
| Rough, chipped edge | Wrong blade type | Change to a finer blade |
| Warm smell | Dust in vents | Unplug and vacuum |
| Vibration | Dirty wheel | Clean both wheels |
| Rust on table | Winter damp | Abrasive paper, then wax |

## Costs

I did not keep perfect records, so I describe the costs in general terms rather than with exact sums. The point of this section is to remind me where the money goes, so I can plan.

**Purchase.** The saw was the largest single cost. I bought it in 2020 and installed it in the shed that same year. It was a considerable outlay for a hobby tool, but it has paid for itself in the time it saves and in the pieces I can now make that I could not before. I would buy it again.

**Setup.** On top of the saw itself, I paid for a few small things to make the shed workable: a clip lamp, a sturdy workbench base, a dust mask, safety glasses, and a vacuum with a fine filter. The vacuum was the dearest of these. I also had an electrician check the socket near the door, which I think was worth doing, since the saw runs on mains power and the shed wiring was old.

**Running costs.** The electricity used by the saw is small. I use it in short bursts, not for hours, so it barely shows on the household bill. The real running costs are consumables:

- Blades, which are the most regular expense. I replace them when they dull or snap, and I note the date in the crate notebook.
- Machine oil and wax, which last a long time.
- Dust masks, replaced when they get clogged.
- Abrasive paper and rags, which cost almost nothing.

**Repairs.** So far I have not paid for a professional repair. The problems I listed above were all fixed with cleaning, a new blade, or a bit of care. I keep in mind that a motor or switch fault would be a different kind of cost, and I would weigh repair against replacement at that point.

**Hidden costs.** Some costs are not money. Cleaning takes time after every session. Winter upkeep takes a weekend afternoon. And I lose some shed space to the saw, which could otherwise hold storage. I accept these as part of owning the machine.

**Ways I keep costs down.** I buy blades a few at a time rather than in a large batch, since I only learned over time which types I really use. I choose the right blade for the material, because a wrong choice wears teeth out quickly and wastes money. I keep the saw clean and dry, which protects the metal parts and avoids repair bills. And I log blade changes, so I can see whether a blade is lasting as long as it should.

If I ever sell the saw or replace it, I will add a short entry here, with the reason and what I learned. For now it is a steady, useful machine in the shed, and its costs are low compared with the work it does.

## Schedule

The Saenber band saw is a red band saw that runs on mains power. It has stood in the shed since 2020, and I use it for cutting in my ceramics work. The shed is unheated and damp in winter, so the schedule below is as much about keeping the machine dry as keeping it sharp.

I do the checks by frequency, not by calendar date. The short ones happen at the bench while I am already there. The longer ones I save for a quiet afternoon.

| Frequency | Task | Notes |
|---|---|---|
| Every session | Wipe down table and guards | Dry cloth only, never a wet one |
| Every session | Check blade tension and tracking | Spin the wheel by hand first |
| Every session | Unplug and cover the saw | Cover stays on the hook beside it |
| Weekly | Clear dust from the wheel housing | Use a soft brush, then the shop vacuum |
| Weekly | Look over the power lead and plug | Check for nicks, heat marks and loose fit |
| Monthly | Wipe the table with a light film of oil | Prevents rust on the bare metal |
| Monthly | Check the guide blocks | Replace if worn or glazed |
| Each season | Full inspection and clean | See the Maintenance section |
| Each season | Test the shed for damp | Look at the walls near the saw |

A few rules I keep to for the schedule:

- If I have cut anything damp or abrasive, I do the weekly clean straight away, not at the end of the week.
- If the shed has been below freezing, I let the saw sit before switching it on.
- If I skip a session check, I do it before the next cut, not afterwards.

## References

This section lists where I look things up and the basic facts I keep coming back to. The manual lives in a folder in the house, not in the shed, because paper does not survive there.

Core properties of the machine, for quick reference:

- Kind: band saw
- Area: ceramics
- Color: red
- Energy source: mains
- Year installed: 2020
- Location: shed

Where information is kept:

- The paper manual is in the workshop folder indoors. It covers the blade change, the guide setup and the wheel alignment.
- The warning labels on the saw itself are still readable. I do not remove or paint over them.
- My own photos of the blade path and the guide setup are in the same folder as this note. I took them when the saw was first set up, so they show the correct layout.
- The supplier's help line has answered one question for me about tracking. I keep no record of the number here, since the manual has it.

Things I have learned that are not in the manual:

- The saw sits on a level patch of the shed floor. When it rocked slightly, the blade tracking drifted, so I shimmed the feet.
- The red paint chips easily around the table edge. I touch it up when I see bare metal, because bare metal rusts fast in the shed.
- The mains socket is shared with a lamp and a small heater, so I never run the heater while cutting.

## Tools

This section covers the tools I use with the saw and the tools I use to look after it. Most of them hang on a board next to the machine, so I can find them without searching.

Tools for using the saw:

- A push stick, kept within reach of the table, for any narrow cut.
- A square, to check the table against the blade before a precise cut.
- A pencil and a marking knife for guide lines.
- Safety glasses and a dust mask. The dust from ceramic material is fine and I treat it as harmful, so the mask is not optional.
- Ear defenders, because the shed is small and the noise bounces around.

Tools for looking after the saw:

- A soft brush and a small stiff brush for the wheel housing and the table slot.
- A shop vacuum, used after the brushing.
- A set of hex keys and a screwdriver that fit the guide blocks and the table insert.
- A light machine oil and a clean rag for the table and the adjusting screws.
- A straightedge for checking that the table is flat and the wheels are in line.
- A spare blade, wrapped and stored indoors so it stays clean and free of rust.

Tools I have decided not to use:

- Compressed air. It blows the fine dust around the shed and into my lungs, so I use a brush and a vacuum instead.
- Water-based cleaners on the table. They cause rust and gain me nothing.

## Maintenance

I do a full inspection each season, and smaller jobs in between. The notes below describe the order I follow, so I do not miss a step.

Before I start, I unplug the saw. I check that the plug is out of the socket and the cable is lying clear. I do not rely on the switch alone.

**Cleaning**

1. Remove the table insert and lift out the dust from the slot.
2. Open the wheel covers and brush off the dust from both wheels.
3. Vacuum the housing and the floor around the base.
4. Wipe the table with a dry cloth, then add a thin film of oil.

**Blade**

- Look along the whole blade for cracks, missing teeth or a kink. Replace it if I find any.
- Check that the blade runs in the middle of the upper wheel. If it creeps to one side, adjust the tracking a little at a time and spin the wheel by hand after each change.
- Release the tension when the saw will not be used for a while. A blade left under tension can stretch and the wheel tyres can take a set.

**Guides**

- Set the guide blocks close to the blade without touching it. A sheet of paper is a good gap.
- Set the support bearing behind the blade so it only turns when I cut.
- Replace the blocks when the faces are rounded or glazed.

**Electrical**

- Inspect the lead along its full length and the plug for heat marks.
- Check the switch for a firm click and no sticking.
- If anything looks damaged, the saw stays unplugged until it is repaired. I do not tape over a fault.

**Shed conditions**

The shed matters as much as the saw. I check the walls and roof near the machine for damp, and I keep the cover on whenever the saw is idle. If I see rust, I clean it off with a fine pad and oil the spot at once.

## History

I installed the Saenber band saw in 2020. I wanted a dedicated saw for ceramics work and had space in the shed, so the red machine went in there and has stayed. It runs on mains power, and I had the shed socket checked before first use.

The early years were mostly about learning. I fitted the first blade too loose, and the tracking wandered until I read the manual properly. After that I wrote the session checks in the Schedule section so I would not forget them.

Over the years a few things have changed:

- I added the shims under the feet after the saw rocked on the uneven floor.
- I started covering the saw after the first damp winter left light rust on the table.
- I moved the push stick and the brushes onto a board beside the saw, so they are always at hand.
- I stopped using compressed air for cleaning and switched to a brush and vacuum.
- I now keep the spare blade indoors, after finding the first one spotted with rust.

The machine has been dependable. Most of its problems have come from the shed, not the saw: damp, dust and cold. When something goes wrong, I check the conditions first, then the blade, then the guides.

I add to this section whenever I change something about the setup, so that future me knows why the saw is arranged the way it is.

## Observations

The Saenber band saw is a red band saw that runs on mains power. It was installed in 2020 and lives in the shed, at the back, away from the wheel and the glaze shelves. I use it for ceramics work: cutting greenware slabs, trimming dry clay blocks to size, and cutting up bisque offcuts that are too awkward to break by hand.

Things I have noticed over the years of using it:

- The red frame shows chalky dust very clearly, so I can tell at a glance when it needs cleaning.
- Because the shed is unheated, the saw is slow to settle on very cold mornings. The blade feels stiff and the first cut is never as clean as the fifth.
- Dry clay cuts quietly. Bisque is louder, and the pitch of the motor changes when the blade starts to dull.
- Damp clay clogs the blade quickly, so I only cut leather-hard or drier material.
- The saw stays steady on its stand, but the shed floor is uneven, so I check the feet if I notice any rocking.
- Fine dust collects under the table and around the lower wheel much faster than I expect.

A short summary of the saw, kept here so I do not have to search for it:

| Property | Value |
|---|---|
| Name | Saenber band saw |
| Kind | band saw |
| Area | ceramics |
| Color | red |
| Energy source | mains |
| Year installed | 2020 |
| Location | shed |

## Safety

Clay dust is the main hazard with this saw, along with the moving blade. Cutting dry clay and bisque throws silica-bearing dust into the air, and a shed has little ventilation. I treat the saw as a dusty tool first and a cutting tool second.

Rules I follow every time:

- Wear a well-fitted dust mask rated for fine particles, not a loose paper one.
- Wear eye protection. Chips of bisque can fly off the blade.
- Keep both hands clear of the blade line. I use a scrap piece of wood to push small pieces through.
- Tie back long hair and remove loose sleeves, cords and jewelry.
- Never clear a jam while the saw is running. Switch off, unplug from the mains, and wait until the blade has stopped completely.
- Keep the guard set just above the work, only slightly higher than the piece being cut.
- Do not cut anything that is wet or dripping, since the saw is powered from the mains and the shed can be damp.

After cutting, I do not sweep the dust dry. I wipe the surfaces with a damp cloth or use a vacuum fitted with a fine filter. Dry sweeping only puts the dust back into the air.

If the saw makes an unusual noise, smells hot, or the blade wanders, I stop at once and look at it before the next cut. The mains cable is checked by eye for cuts or crushing, because the shed door sometimes catches it.

## Checklist

I run through this list before and after each session. It takes about five minutes, and it has saved me from several bad cuts.

Before cutting:

- Check that the saw is unplugged while I inspect it.
- Look at the blade for cracks, missing teeth or a bright, glazed edge.
- Turn the wheel by hand to confirm the blade tracks in the middle.
- Check the guard height and lock it.
- Make sure the table is clear and the floor around the saw is free of clutter.
- Put on the mask and eye protection.
- Plug in the mains cable and run the saw empty for a few seconds.

After cutting:

- Switch off and unplug from the mains.
- Wipe the table, wheels and the red frame with a damp cloth.
- Vacuum the dust from under the table.
- Release a little blade tension if the saw will sit unused for a long time.
- Close the shed so that damp air does not settle on the metal.

Once a season I also check the wheel tyres for wear, the blade guides for clay build-up, and the feet for level.

## Setup

The saw sits in the shed on a firm stand, positioned so that I can walk around three sides of it. It has been in the same place since it was installed in 2020. The mains socket is on the wall to the right, and I keep the cable short and off the floor so I do not step on it.

How I set it up for a working session:

1. Open the shed door fully for ventilation and let air move through before starting.
2. Check the blade tension and tracking, as described in the checklist.
3. Set the guard to just above the clay.
4. Put a sheet of paper or a tray under the table to catch the offcuts, which makes cleaning faster.
5. Mark the cutting line on the clay with a needle tool so that I can follow it with my eyes and not push hard.

For feeding the work, I let the blade do the cutting. Pushing too hard bends the blade and gives a curved cut. Slabs are best cut slowly and held flat on the table. Thick blocks should be supported so they cannot tip into the blade.

Blade choice matters. A fine-toothed blade gives a cleaner edge on bisque, while a coarser one is better for dry clay because it clears the dust. I keep a spare blade of each kind on a hook next to the saw, so I never run a dull blade just because replacing it is a nuisance.

## Risks

The risks below are the ones I think are most likely in this particular setup, with what I do about each.

| Risk | Cause | What I do |
|---|---|---|
| Silica dust inhalation | Cutting dry clay and bisque in a closed shed | Mask, open door, damp cleaning, no dry sweeping |
| Blade break | Dull blade, too much tension, forcing the cut | Inspect before use, release tension when idle |
| Cut to hands | Hands near the blade while feeding small pieces | Push stick, guard set low |
| Electric shock | Damp shed, damaged mains cable | Dry material only, check the cable, unplug when cleaning |
| Fire or motor overheating | Dust packed around the motor | Vacuum the motor area, stop if it smells hot |
| Rust on the red frame | Condensation in the unheated shed | Wipe dry, close the shed, light oil on bare metal |

Other things to keep in mind:

- Because the shed is a separate building, nobody is nearby if something goes wrong. I tell someone when I am going to use the saw for a long session.
- Fine dust can reach the glaze shelf and contaminate materials, so I keep lids on glaze buckets while cutting.
- Dust tends to build up slowly over many sessions, so the saw may look clean on top and still be clogged inside. A deeper clean once a season is worth the time.
- If the saw ever needs repair, I will not open the motor housing myself while it is connected to the mains.

## Ideas

These are the things I want to try or change on the Saenber band saw. It is a red band saw that runs on mains power. It was installed in 2020 and lives in the shed, where I use it for ceramics work. Most ideas come from the small annoyances of using it in a shed rather than in a proper workshop.

### Dust and slurry control

Ceramics work with a band saw is not like woodworking. I cut bisque-fired pieces, dry greenware, and sometimes plaster molds. The dust is fine and gets everywhere in the shed. Ideas to reduce it:

- Fit a small hood behind the blade guide and connect it to a shop vacuum with a long hose.
- Keep a spray bottle nearby to dampen the cut line on plaster, so the dust stays down.
- Wipe the table with a damp cloth after every session instead of brushing it, because brushing only lifts the dust into the air.
- Wear the dust mask every time, even for short cuts. Leaving it on a hook by the door has not worked, so it should hang next to the switch.

### Blade choices

I have only tried a couple of blade types so far. I want to keep notes on what works for each material, then settle on a short list instead of buying blades at random.

- A fine-tooth blade for bisque and thin tiles, where chipping is the main risk.
- A coarser blade for plaster and soft fired clay bodies.
- A diamond-coated blade for very hard fired material, if the saw can keep it tracking properly. I need to check the wheel size first.
- Mark each blade with a strip of tape and a short label so I know what it has been used on. Cutting plaster with a blade that has already seen fired clay seems to dull it faster.

### Shed conditions

The shed is cold in winter and damp in autumn. Both affect the saw. Damp air leaves a thin film of rust on the table, and cold makes the blade feel brittle. Things to do:

- Keep a tin of paste wax on the shelf and wax the table at the start of each season.
- Put a small bag of silica gel inside the motor cover area, as long as it cannot touch moving parts.
- Cover the saw with an old sheet when I am not using it. A plastic cover traps moisture, so cloth is better.
- Move the saw a little further from the door so that rain blowing in does not reach the table.

### Layout and workflow

The saw is red, which helps because I can see it in the dim light of the shed, but the space around it is cramped. I would like to:

1. Build a simple outfeed support from scrap board, level with the table.
2. Add a shelf for blades, a square, and a pencil so they stop drifting around the shed.
3. Paint a line on the floor to show where I stand, so the cord stays out of the way.
4. Fix a proper light over the table. The overhead bulb throws a shadow from my own shoulder onto the cut line.

### Safety ideas

- Replace the loose plug with a switched socket within reach, so I can cut power without leaning over the blade.
- Add a residual current device on the shed circuit if there is not one already. I need to ask someone who knows the wiring before touching anything.
- Keep a first aid kit in the shed, not in the house.
- Write the blade change steps on a card and tape it inside the cover. I forget the order if I go a few weeks without changing one.

### Maintenance reminders

I tend to put off maintenance until something sounds wrong. A fixed routine would be better. After each session I clean the table and the wheels. Each season I check the tires on the wheels for cracks, check the guides for wear, and check that the blade tracks in the middle. Once a year I look at the cord and the switch for damage. None of this takes long, but it needs to be in a list I can see.

## Measurements

This section holds what I have actually measured on the saw, plus the fixed properties for quick reference. The power draw was taken with a plug-in meter while the saw was cutting a piece of bisque-fired tile at a steady pace. It is a single reading, not an average over many sessions, so I treat it as a rough guide.

The measured power draw of the Saenber band saw is 749.43 W. This is higher than I expected for a saw of this size, which makes me think the blade was slightly too coarse for the material, or that the tension was a little high. I plan to repeat the test with a finer blade and compare.

### Reference table

| Property | Value |
| --- | --- |
| Device | Saenber band saw |
| Kind | band saw |
| Area | ceramics |
| Color | red |
| Energy source | mains |
| Year installed | 2020 |
| Location | shed |
| Measured power draw | 749.43 W |

### How I measured

The method matters, because a different setup would give a different reading. I want to be able to repeat it later.

- The saw was plugged into the plug-in meter, and the meter into the shed socket.
- The blade was already at normal tension and tracking in the middle of the wheels.
- I let the saw run without any load for a short time to let the reading settle, then fed the tile in slowly with steady hand pressure.
- I read the meter during the cut, not before or after, because the idle reading is much lower and would be misleading.
- The shed was cool and dry. I did not run anything else on the same socket.

### What affects the reading

From what I have seen so far, these things change the power draw most:

- Blade type and sharpness. A dull blade pushes the reading up quickly.
- Feed pressure. If I push harder, the motor works harder and the meter shows it.
- Material. Plaster is easy on the motor, while fired tile is harder.
- Blade tension. Too much tension adds load on the bearings and the motor.
- Supply condition. The shed is at the end of a long cable run, so the voltage may sag a little when the saw starts.

### Things I have not measured yet

I have not recorded the idle draw, the starting surge, the noise level, or the blade speed. These would all be useful. The idle draw would show how much of the reading is the motor simply turning the wheels. The starting surge matters because of the long cable to the shed. Noise matters because I work early in the morning and the neighbors are close. Blade speed would help me pick blades with confidence.

### Plan for the next round

1. Repeat the cut with the same tile type and a fine-tooth blade, and compare the reading with the one above.
2. Take an idle reading and note it beside the cutting reading.
3. Try a plaster cut and see how far the draw drops.
4. Record the results in this table by adding rows, so I can see everything in one place.
5. Check the socket and cable for warmth after a long session, since a heavy load on a long run can heat a weak connection.

### Notes on interpreting the number

The figure of 749.43 W is real power as shown by the meter, so it already accounts for the way the motor draws current. It does not tell me anything about how efficient the saw is at cutting, only how much it takes from the mains. For a saw installed in 2020 and used mostly for ceramics, I think this is reasonable, but I want more readings before I decide whether anything is wrong. If later readings come out much lower with a sharp, correct blade, then the first number was mostly a sign of a poor blade choice and not a fault in the saw.
