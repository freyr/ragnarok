---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Navis heat exchanger."
---

# Navis heat exchanger

## Background

The Navis heat exchanger is a black ceramic heat exchanger that I installed in the shed in 2020. It runs on solar energy only. There is no mains connection and no backup burner, so on a dull day it simply does less. I keep this note as a reference for myself, so that I do not have to rediscover how the unit is set up every time I come back to it after a long gap.

The reason I put it in the shed was practical. The shed gets the best sun on the south side of the plot, and the ceramic work I do there needs steady, gentle warmth more than it needs high heat. The black finish helps the unit absorb sunlight, and the ceramic body holds that warmth for a good while after the sun moves off.

Earlier thinking on the heat exchange problem is in [[Vanstol heat exchanger study]]. The results of the first trial runs are in [[Nirde workshop tests]]. Both are worth reading before changing anything about the way the unit is fed or vented.

Quick facts, as I keep them:

- Name: Navis heat exchanger
- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: solar
- Year installed: 2020
- Location: shed

## Supplies

The unit needs very little in the way of consumables. What I keep on the shelf next to it:

- A soft brush for dusting the black surface, because dust cuts down how much sun it absorbs.
- Clean cloths, slightly damp, for wiping the outside when it is cool.
- A small tub of heat-safe sealant for the joints where the pipes meet the body.
- Spare pipe clamps, as the old ones loosen with the heat cycles.
- Thick gloves for handling anything near the unit after a sunny afternoon.
- A notebook and pencil for jotting down how it behaved on a given day.

I do not use any abrasive cleaner on it. The surface is easy to scratch, and a scratched surface sheds heat unevenly. If I need to move heavy things around it, I check the layout against what I wrote in [[Glivalsark band saw log]], because the band saw and the exchanger share the same corner of the shed and I have had near misses with long offcuts.

## Safety

Because the unit is solar and black, it can get hot without any warning. I treat it as hot whenever the sun has been on the shed for more than a short while.

- Wear gloves before touching the body or the pipe joints.
- Never cover the unit while it is in direct sun. Trapped heat is the main risk.
- Keep flammable material, such as solvents, paper and wood shavings, well away from it.
- Do not splash cold water on a hot ceramic body. Sudden cooling can crack it.
- Keep the shed door propped open when I work nearby on a bright day, so the air does not build up.
- Check the clamps and joints by eye before each season and tighten them if they have crept.

If I notice a crack, I stop using the unit until it is dealt with. A small hairline crack can grow quickly under repeated heating. I also keep a short list of who to ask for advice about ceramic repairs, which I note under [[Glendrol Naefur]].

## Overview

The Navis heat exchanger takes warmth gathered from the sun and passes it along to the working circuit that serves my ceramics area in the shed. It is a heat exchanger in the plain sense: heat goes in on one side, and it moves across the ceramic body to the other side without the two flows mixing.

Its black color is deliberate. A dark surface soaks up more sunlight, and for a solar-only device that matters a lot. On a clear day the unit warms up steadily through the morning, holds a good level through the middle of the day, and fades slowly in the evening. On a cloudy day the output drops, and I plan my work around that instead of fighting it.

Since it was installed in 2020 it has needed very little attention. The routine is simple:

- Dust the surface with the soft brush every couple of weeks.
- Wipe it down with a damp cloth when it is cool.
- Look over the clamps and joints at the start of each season.
- Write down anything odd in the notebook.

I have thought about whether a larger setup would be worth building. Those thoughts, including how the exchanger would fit with other equipment, are collected in [[Gaerkbaend Baengal plan]]. For now the single unit is enough for the scale of work I do.

One habit that has paid off is noting the weather alongside the behavior of the unit. After a few seasons, the pattern is clear enough that I can tell by the sky in the morning whether it is a good day for work that needs steady warmth, or whether I should do bench work instead.

## Parts

The unit is mostly a single ceramic body with a small set of fittings. Keeping the list short makes it easier to maintain.

- Ceramic body: the black main block, which does the actual heat exchange.
- Pipe connections: the inlet and outlet joints on the body, sealed and held with clamps.
- Clamps: metal bands that hold the pipes in place and need occasional tightening.
- Sealant joints: the heat-safe sealant at each connection.
- Mounting frame: the support that holds the unit steady in the sunniest spot of the shed.

The part number of the Navis heat exchanger is BY-3718-U. I quote this whenever I look for a replacement or compare notes with someone else who keeps a similar device.

If the ceramic body ever needs replacing, I will check the old unit's fittings first, since the clamps and sealant can usually be reused. The pipe connections are the most likely place for trouble, so they are the first thing I look at when the unit seems to be underperforming.
