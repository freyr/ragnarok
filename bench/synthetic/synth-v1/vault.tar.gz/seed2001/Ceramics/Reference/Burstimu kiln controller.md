---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Burstimu kiln controller."
---

# Burstimu kiln controller

## Supplies

The Burstimu kiln controller is a green kiln controller that runs on mains power. It has been installed in the workshop since 2016 and is used for ceramics firing. I keep these things near it so a firing never stalls:

- Spare thermocouple wire
- Heat-proof gloves
- Kiln wash and a small brush
- A notebook for firing logs
- Cord ties for the mains lead

## Parts

I check these before each firing season. The serial number is stamped on the label at the back of the unit.

| Property | Value |
|---|---|
| Kind | Kiln controller |
| Area | Ceramics |
| Color | Green |
| Energy source | Mains |
| Year installed | 2016 |
| Location | Workshop |
| Serial number | SN-52942011 |

If the display ever acts up, I first check the mains lead and the thermocouple connection.
