---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Zaendsturk pond."
---

# Zaendsturk pond

## Maintenance

Zaendsturk pond is a small pond in the ceramics area, built in 1997. It faces east, so it gets the morning light first and the afternoon shade comes early. The floor is raised, which keeps the basin sitting above the surrounding ground and helps it drain after heavy rain.

My routine for keeping it in shape:

- Skim the surface once a week to clear leaves and loose debris.
- Check the edges after rain, since the raised floor can shed water unevenly along the east side.
- Scrub the basin walls in spring, before the growing season starts.
- Look over the raised floor for cracks or loose sections each autumn.
- Keep a short log of anything unusual, such as sudden changes in water level.

Because the pond is small, it responds quickly to weather. A few hot days can drop the level noticeably, and a single storm can cloud the water for a while. I top it up slowly rather than all at once, so the water settles faster.

## Dimensions

Zaendsturk pond is small, and the numbers below are the ones I use when planning any work on it.

- Kind: pond
- Area: ceramics
- Orientation: east
- Size: small
- Year built: 1997
- Floor: raised
- Floor area: 124.48 m²

The floor area is the figure to use when estimating how much sealant, lining or cleaning solution I need. Since the floor is raised, I measure from the top of the raised surface, not from the ground around it.
