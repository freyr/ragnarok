---
type: reference
status: active
project: reference
area: ceramics
description: "Reference about Zolbrel loft."
---

# Zolbrel loft handbook

## Risks

The Zolbrel loft is a large loft below ground, and that one fact shapes almost every risk I have to watch. It was built in 1997, it faces north, and it is used for ceramics. Each of those properties changes how the space behaves, so I list them here with what they mean in practice.

**Below ground.** The floor of the loft is below ground level. Damp is the first concern. Water can come in through the walls or up through the slab after heavy rain, and the air stays humid for long periods. Damp ruins unfired work, softens cardboard boxes, rusts tools, and makes bags of dry clay go hard on the outside and sticky on the inside. I check the lowest shelf and the corners every week. Anything that must stay dry goes up off the floor.

A below-ground room also has a flooding risk. A blocked drain or a burst pipe upstairs can send water down to the loft faster than I can react. I keep the floor clear of anything I cannot lift quickly, and I never store finished pieces or paperwork directly on the ground.

Air is the second concern. Fresh air does not move well in a space under the ground. Dust from dry clay and glaze powder hangs in the room for a long time. Fumes from the kiln also linger. I treat ventilation as a safety matter, not a comfort. Silica dust is the main long-term health risk in ceramics, and a below-ground room makes it worse because the dust has nowhere to go.

Escape is the third concern. The only way out is up, so a fire or a smoke problem near the stairs would be serious. I keep the route to the stairs free at all times and do not stack boxes near the exit.

**Large size.** The loft is large, which sounds like a benefit and partly is. A large room lets me separate dusty work from clean work and keep the kiln away from storage. The risk is that a big room tempts me to let clutter spread. Clutter hides trip hazards, collects dust, and hides leaks until they are bad. Another risk is that I can be far from the stairs or the door when something goes wrong, so I try not to work alone for long stretches late at night.

A large space is also harder to heat and to dry. A small dehumidifier will not do much here, so I plan for equipment sized to the room.

**North orientation.** The loft faces north, so it gets little direct sun. This means steady, cool, even light, which is good for judging glaze colour and surface detail. It also means the room stays cold and slow to dry. In winter the loft can stay cold enough that wet clay and fresh glaze dry unevenly, and cold work is more likely to crack in the kiln later. Drying is slower, so I allow more time and do not rush pieces to the kiln.

The lack of sun also lets mould grow on walls, shelves, and any porous surface. I look for dark spots on the north wall first.

**Built in 1997.** The building dates from 1997, so the wiring, the pipes, and the waterproofing are not new. Older wiring may not cope with a kiln plus a dehumidifier plus lights all running together. I do not run several heavy machines on one circuit. Older pipes and seals are the likely source of slow leaks. I have the electrics checked by a qualified person before adding any new heavy equipment, and I note the result in my records.

**Ceramics work.** Because the area is ceramics, the usual hazards apply on top of the building ones: hot kiln surfaces, dust, glaze chemicals, heavy bags of clay, and wet floors that turn slippery. Wet clay on the floor dries to a fine dust that I then breathe, so I wipe up with a damp cloth or a wet mop, never a dry brush.

**Summary of the main risks**

- Damp and water ingress, because the floor is below ground.
- Flooding from drains or pipes above.
- Poor air movement and dust build-up.
- A single escape route upwards.
- Clutter and distance from the exit in a large room.
- Cold, slow drying and mould, because the loft faces north.
- Ageing wiring and pipes, because it was built in 1997.
- Silica dust and kiln heat from the ceramics work.

## Setup

The setup follows the risks above. I arranged the loft so that the wet, dusty, and hot activities are kept apart, and so that the exit and the damp spots are always easy to see.

**Zones.** Because the loft is large, I divided it into four zones. The first is the clay zone near the stairs, where bags are stored and clay is wedged. The second is the wet work zone, with the wheel and the sink bucket. The third is the glaze zone, with its own table and a mat on the floor. The fourth is the kiln zone, at the far side from the clay, with clear space around it. I put the kiln away from shelves and boxes so that nothing flammable is close to it.

**Floor and storage.** The loft floor is below ground, so everything I care about sits on shelves. I use metal or plastic shelving, not wood or cardboard, because those take up damp. The lowest shelf stays empty or holds only waterproof tubs. Dry clay lives in lidded bins, not in its original bags. Finished pieces sit on the upper shelves, wrapped in cloth only when I know the room is dry.

**Damp control.** I run a dehumidifier sized for a large room and empty it on a routine. A small humidity meter hangs on the north wall, the coldest place, so I get the worst reading. If the reading climbs, I check for leaks before I blame the weather. I leave a gap between shelves and the wall so air can pass and mould has less chance to start.

**Ventilation.** The loft needs moving air, so I set up an extractor near the kiln and keep a fan ready for the glaze zone. I open the door at the top of the stairs when I work with dry powders. I do not sweep dry dust; I use a damp mop and a vacuum with a fine filter made for dust.

**Light.** The north orientation gives soft, steady light, which I like for checking glaze. I add daylight-style lamps over the glaze table and over the wheel, because the natural light alone is thin so far below ground. I keep a battery torch on a hook by the stairs in case of a power cut.

**Heat.** Since the loft stays cold, I use a low, steady heater in winter to keep the room above the point where clay freezes or dries unevenly. I never leave it near wet cloths or paper. In summer the loft stays cool, which helps keep clay workable, so I rarely need to cool it.

**Electrics.** Because the building dates from 1997, I keep the kiln on its own circuit and do not plug the dehumidifier, heater, and kiln into the same extension lead. Leads are lifted off the floor, away from any water.

**Safety kit.** Near the stairs I keep a fire extinguisher, a first aid box, a dust mask rated for fine dust, and a list of emergency contacts. A smoke alarm and a water alarm sit in the loft; the water alarm is on the floor in the lowest corner. I test both on the first day of each month.

**Exit.** The path from every zone to the stairs is marked with tape on the floor and kept clear. Nothing is stored on the stairs.

## Supplies

I keep supplies in a way that matches the damp, cold, below-ground conditions. The list below is what I try to have on hand, grouped by use.

**Clay and materials**

- Clay bodies for throwing and for hand building, stored in lidded bins.
- Spare plastic sheeting to keep wet clay from drying out.
- Glaze powders in sealed tubs, labelled with the name and the date I opened them.
- Slip, underglaze, and wax resist.
- Kiln wash and kiln shelves, with spare props.

**Tools**

- Wheel tools, ribs, wire cutters, and sponges.
- Trimming tools and a set of needle tools.
- Brushes of several sizes for glaze work.
- Buckets, a sieve, and a scale for mixing glaze.
- A set of towels and cloths kept only for the loft.

**Damp and air**

- Spare filter for the vacuum.
- Silica gel tubs or similar moisture absorbers for small cupboards.
- A spare bag of salt-based moisture absorber for the lowest corners.
- Mould cleaner suitable for walls and shelves.

**Safety**

- Dust masks, with spares, and safety glasses.
- Heat-proof gloves for the kiln.
- Rubber gloves for glaze work.
- Spare batteries for the torch and the alarms.
- Non-slip mats for the wet work zone.

**Cleaning**

- Mop and bucket kept for damp cleaning.
- Cloths for wiping surfaces.
- Bin bags and a lidded bin for clay scraps.
- A bucket with a settling bottom for rinse water, so clay does not go down the drain.

**Storage rules.** Because the loft is below ground, I buy supplies in amounts I can use before they go off. Dry clay and powders keep well if sealed, but paper bags, cardboard, and labels do not. I replace cardboard with plastic as soon as boxes arrive. Large stock goes on upper shelves, and I keep a short list taped inside the cupboard door so I know what to reorder before it runs out.

**Reorder habit.** Once a month I walk through the loft with the list, check each tub and bin, and write down anything that is low. The cold and damp make some items fail faster, especially sponges, which go sour, and glaze that has taken in moisture. I throw those out rather than risk poor results.

## Costs

I do not record exact prices here, since they change and I would rather keep this section useful than precise. What matters is where the money goes and which items cost the most over time, given the loft's properties.

**One-off costs.** The largest one-off costs are the kiln, the wheel, and the shelving. The kiln is the biggest single item, and it also needs a proper electrical circuit, which adds to the cost. Because the building dates from 1997, I allowed extra for an electrical check and possibly some rewiring. The dehumidifier and extractor are the next group, and I bought equipment sized for a large room, which costs more than a domestic unit but works much better below ground.

**Running costs.** The main running costs are electricity and clay. The kiln uses a lot of power on every firing. The dehumidifier runs for long hours, and in winter the heater runs too, because the loft faces north and stays cold. I treat these as a steady monthly cost rather than a surprise. Clay and glaze materials are the next cost, and I buy them in sensible amounts so none is wasted by damp.

**Costs caused by the location.** Being below ground adds costs that a room upstairs would not have:

- Damp control equipment and its power use.
- Plastic bins and shelving in place of cardboard and wood.
- Extra lighting, since little daylight reaches the room.
- Water and smoke alarms.
- A repair fund for leaks, drains, and mould treatment.

**Costs caused by size.** A large loft needs more of everything: more shelves, more lamps, a stronger dehumidifier, and more heating. I try not to fill the space just because it is there. Each addition should earn its place.

**Costs caused by age.** The year of construction, 1997, means I expect repairs. I keep a small reserve for seals, pipes, and wiring, and I do not spend it on tools or materials.

**Where I try to save.** I buy tools second-hand when they are simple, such as buckets, shelves, and tables. I do not save on safety kit, electrics, or damp control, because failures in those areas cost far more than the saving. I reuse clay scraps by drying and reclaiming them, and I collect rinse water solids so that nothing goes down the drain.

**Review.** Every few months I look through my notes and bank records for the loft, sort the spending into the groups above, and check which group is growing. If damp control is rising, I look for the source of the problem before buying more equipment.

## Background

Zolbrel loft is a loft in the ceramics area. It is a large space, and it sits below ground, which is unusual for something called a loft. The building dates from 1997. The main windows and the working light face north, so the light is even and cool through the day, with no hard sun on the wheels or the glaze table. That is the main reason people choose to work here.

Being below ground shapes almost everything else about the place. The temperature stays steady, the walls hold a little moisture, and the air moves slowly. For ceramics this has good and bad sides. Clay stays workable for longer, and slow drying means fewer cracked pieces. But damp can creep into stored bags of clay, into dry glaze materials, and into cardboard boxes. I keep this in mind whenever I decide where to put something.

Quick reference for the properties of the place:

- Kind: loft
- Area: ceramics (also given in the frontmatter)
- Orientation: north
- Size: large
- Year built: 1997
- Floor: below ground

The size matters in practice. Because the loft is large, I can separate the work into zones: a wet zone for throwing and hand building, a dry zone for glaze mixing and packing, and a quiet zone for the shelves where pieces dry slowly. Keeping these zones apart limits dust and splashes. It also keeps people from walking through wet floor areas with dirty shoes.

I treat this note as a working handbook, not a description for visitors. The sections below cover how I keep the place in order, what I know about how it has changed, and what I would like to try next.

## Maintenance

Maintenance here is mostly about moisture, dust, and floor surfaces. I do the routines below in roughly the order given.

### Daily

- Wipe down the wheels, tables, and benches with a damp sponge, never a dry cloth. Dry wiping throws fine clay dust into the air, and in a below-ground room that dust has few places to go.
- Mop the wet zone floor before leaving. Clay slip dries into a pale film that is slippery when damp and gritty when dry.
- Cover any work in progress with plastic sheeting. The room is steady in temperature, but the air near the vents dries the surface of a pot faster than the rest.
- Empty the water buckets into the settling bucket, not the sink. Clay in the drain is the most common problem I have had.

### Weekly

- Check the walls along the base for damp patches or white salt marks. Salt marks show where water is moving through the masonry. I note the position and compare it with the previous week.
- Run the dehumidifier and empty its tank. In wetter weeks it fills several times, so I check it more often rather than letting it shut off by itself.
- Sweep the dry zone, then damp-mop it. I use a mask while sweeping.
- Rotate the drying shelves. Pieces near the wall dry more slowly than those near the middle of the room, so I swap them around to even it out.
- Look through the stored clay. Bags that feel soft or sweaty on the outside have taken in damp and should be used first.

### Monthly

- Clean the vent grilles and check that nothing blocks them. Airflow is the main defense against mold in a space like this.
- Check the lights and the wiring where it runs near the floor. Anything near the wet zone should be kept well off the ground and away from splash.
- Go through the glaze materials. Check lids, look for clumping, and discard anything that has gone hard or changed color.
- Inspect the sump or drain point. Clear any sediment before it builds up.
- Test the floor for slip. If I notice it getting slick even when clean, I scrub the surface with a stiff brush and a mild cleaner.

### Seasonal

- In the wet season, damp is the main worry. I raise storage off the floor, move cardboard to higher shelves, and run the dehumidifier longer.
- In the dry season, the risk shifts to too-fast drying near the vents. I hang damp cloths and use more plastic cover on larger pieces.
- Once a year I repaint or reseal any wall surface that has started to flake. Flaking paint is often the first visible sign of trapped moisture.
- Once a year I check the kiln area, the shelves, and the posts for damage, and replace anything chipped or warped.

### Things that go wrong

- **White powder on the walls:** salts left by evaporating water. Brush it off dry, wear a mask, and note where it came back.
- **Musty smell near stored clay:** usually a bag that has gone off. Find it and remove it quickly, because the smell spreads to the rest.
- **Cracks in drying pieces:** often caused by uneven drying. Check the position relative to the vents and cover more tightly.
- **Slow drains:** almost always clay. Clear the trap, then go back to settling the water in the bucket first.
- **Dust haze in the evening:** a sign that sweeping was done dry. Switch to damp methods.

## History

The loft was built in 1997. I do not have the original plans, so what I know comes from the building itself and from what people have told me over the years. I treat the following as the working story and not as a fully checked record.

The space was clearly made for work, not for living. The floor was laid with practical use in mind, and the below-ground position was probably chosen for the steady temperature and the protection from heat. The north orientation of the main light suggests the person who set it up wanted even light, which is what ceramics work needs for judging glaze color and surface.

Over the years the loft has gone through a few kinds of change, which I group as follows:

- **Early years:** the first use was simple. A few wheels, a long table, and open shelves. There was little separation of zones, and dust was a regular problem.
- **Middle period:** more storage was added, and the glaze work moved to one side of the room. This was the point at which the idea of a wet zone and a dry zone began to take shape.
- **Recent years:** the main concern became damp. The dehumidifier arrived, storage was lifted off the floor, and the vents were cleaned and kept clear on a schedule.

A few lessons have come out of this history, and I write them down so I do not repeat old mistakes:

1. Moisture is the main enemy, and it works slowly. Problems that look small in one month become large over a year.
2. Separate zones save time. Every time the layout drifted back to a single open space, cleaning took longer and dust spread further.
3. Light matters more than I first thought. The north light makes color judgments reliable, so I do not put bright lamps or colored bulbs near the glaze table.
4. Keeping notes helps. Marking the position of damp patches week by week showed a pattern that I would have missed by memory alone.

I would like to find the original plans for the loft, or at least a sketch of how the drainage runs. That would remove a lot of guessing during maintenance.

## Ideas

These are things I would like to try or improve. None are urgent, and I list them roughly from cheapest to most involved.

### Small changes

- Fit shelf liners that can be washed, so damp does not soak into bare boards.
- Add a simple hygrometer on each side of the room, so I can see how much the humidity differs between the wet zone and the dry zone.
- Label every glaze container with the date it was opened, to make the monthly check faster.
- Put a mat with a rough surface at the door of the wet zone, to catch slip before people walk into the dry zone.
- Keep a small notebook by the door for damp patches, so the weekly check is written down in one place.

### Medium changes

- Build a raised rack for clay storage, with open sides so air can pass under and around the bags.
- Add a second settling bucket in series with the first, so the water leaving the room is clearer.
- Move the packing table nearer to the north light, so I can check finished pieces in the best light before they go out.
- Install a proper cover or lid system for the slow-drying shelves, with an adjustable gap, to control the rate of drying through the year.

### Larger projects

- Improve the airflow with a quiet extraction fan placed away from the work areas. The goal is gentle movement of air, not a draft across drying pots.
- Seal or tank the lower part of the walls where salt marks keep returning, if the weekly notes show the same spots each time.
- Redo the floor surface in the wet zone with a finish that is easier to clean and less slippery when wet, with a slight slope toward a drain.
- Make a small viewing corner with neutral grey walls and a bench, for judging glaze samples under the north light.

### Questions to answer first

- Where does the water actually enter the walls, and is it the same place every season?
- Would a larger dehumidifier do the job, or would better ventilation do more for less running cost?
- How much of the dust comes from clay and how much from glaze materials? The answer decides where a filter would help most.
- Is it worth dividing the large space with a light partition, or are marked floor zones enough?

I will answer these in the order given, and update the maintenance routines once I know more.

## Safety

Zolbrel loft is a large loft below ground, built in 1997, and that combination shapes almost every safety habit I keep there. The room faces north, so it gets no direct sun, and being under the street level means it has no easy way out except the stairs. I treat it as a place where small problems grow quietly.

**Air and dust.** Ceramics work produces fine dust from dry clay, glaze powders and sanded bisque. In a large room below ground the dust settles slowly and hangs in the air for a long time. My rules:

- Wet-wipe surfaces. I never dry sweep.
- Mix dry glaze materials only with a mask on, and only near the extraction point.
- Keep the door to the stairs closed while mixing so dust does not travel up into the house.
- Wash cloths and sponges in a bucket, not in the sink, so clay does not go into the drain.

**Ventilation.** A below-ground room depends on forced air. When the kiln is firing I run the fan and leave the stair door slightly open for make-up air. If the room smells sharp or sweet, I stop what I am doing and go up for fresh air before deciding anything. Fumes from firing are the reason I do not sit in the loft while the kiln is climbing to temperature.

**Kiln.** The kiln stands away from the walls with clear space around it on all sides. I keep nothing flammable within arm's reach plus a bit more: no paper, no cardboard boxes, no solvent bottles. I check the power cable and plug for warmth after the first hour of a firing. I never leave the house during a firing.

**Floors and damp.** Because the loft is below ground, the floor can stay damp in wet weather. A wet floor with clay slip on it is very slippery. I keep rubber mats at the wheel and at the bottom of the stairs. Electric tools and extension leads never sit on the floor itself; they go on a shelf or on a raised hook.

**Light.** The north orientation gives steady, even light, but the loft is dim in winter. Poor light hides trip hazards, so the stair and the path to the kiln stay lit with lamps, and I switch them on before I go down, not after.

**Exit and emergencies.** The stairs are the only way out. I keep them clear at all times: no boxes, no bags of clay, no drying boards leaning against the rail. A fire extinguisher hangs near the foot of the stairs, and a first aid kit sits beside it. I keep a flashlight on the same hook in case the power fails.

**Lifting.** Bags of clay are heavy and the stairs are steep. I carry one bag at a time, keep one hand free for the rail, and leave bulk deliveries at the top for a second trip when I am rested.

**Working alone.** If I am working in the loft by myself, I tell someone in the house, or send a short message, when I go down and when I come up. This is a habit, not a worry, and it costs nothing.

## Open questions

These are things I have not settled about the loft. I write them down so I stop carrying them in my head.

- **Damp source.** The floor stays damp near the north wall after heavy rain. I do not know whether this is seepage through the wall, condensation, or a drain problem. I have not tested it properly. A simple check with a sheet of plastic taped to the wall for a few days might tell me whether moisture comes from inside or outside.
- **Air quality.** I have never measured dust levels in the room. I assume the extraction point helps, but I do not know how much. I would like to try a basic dust monitor and compare a working day with a quiet day.
- **Ventilation capacity.** The fan moves air, but is it enough for a large room during a long firing? I do not know the real air change rate. I should look at the fan rating and estimate it against the size of the room.
- **Wall condition.** Since 1997 the walls have had plenty of time to age. I have not asked anyone to look at the plaster or the damp-proofing behind it. Is it worth a proper survey?
- **Second exit.** Would a second way out be possible? The stairs are the only exit and I keep wondering if a window well or a hatch could be added. I do not know if the rules allow it or what it would cost.
- **Heating.** The loft is cold in winter, partly because it faces north. Would a small heater be safe near drying work, or does it risk cracking pieces by drying them too fast? I have no answer yet.
- **Glaze storage.** Some powders may clump in the damp. I do not know whether the shelves near the north wall are a bad place for them. I should move one tub to the other side for a season and compare.
- **Power.** I am not sure the circuit can carry the kiln and the lights and the fan together without strain. This one should be answered by an electrician, not by guessing.

## Tools

This is the practical list of what lives in the loft and what each item is for. I keep it short so I can see at a glance what is missing.

**Shaping**
- Wheel, with a splash pan and a stool at the right height.
- Wooden ribs and metal ribs for walls and curves.
- Wire cutter for removing pieces from the bat and for cutting clay blocks.
- Needle tool and a fettling knife for trimming and cleanup.
- Calipers for matching lids to pots.
- Bats, a few of them, so I can lift finished work without touching it.

**Handbuilding**
- Rolling pin and two wooden guide strips.
- Canvas cloth for rolling slabs.
- Soft sponges and a small bowl for slip.
- Scoring tool and a toothbrush for joining.

**Glazing**
- Digital scale for weighing dry materials.
- Buckets with lids for mixed glaze.
- Sieve for removing lumps.
- Tongs and a dipping jug.
- Brushes of several sizes for detail.
- Labels and a marker. Every bucket gets one.

**Firing**
- The kiln, with shelves and props.
- Kiln wash for the shelves.
- Heat-proof gloves and eye protection.
- A logbook that sits beside the kiln for the settings and results of each firing.

**Safety and cleaning**
- Dust masks and spare filters.
- Mop, bucket, and sponges for wet cleaning.
- Rubber mats.
- Fire extinguisher, first aid kit, flashlight.

**Lighting**
- Several lamps. Because the loft faces north and sits below ground, I use daylight-colored bulbs for judging glaze color. Warm bulbs mislead me.

**Storage**
- Plastic bins for clay scraps to be recycled.
- Shelving for drying work, kept off the floor.
- Racks for finished pieces.

I review this list at the end of each season and write down anything worn out or missing.

## Observations

These are notes from time spent in the loft. They are what I have seen, not what I have proven.

**The light.** The north orientation means the light is cool and steady. It does not move across the room during the day, which is good for judging surface and color. On the other hand, it never warms the room. A cloudy day makes the loft feel like evening.

**Temperature.** Being below ground keeps the temperature fairly even. Summer heat does not reach the loft the way it does the upper floors. In winter, though, the cold stays, and clay stiffens more slowly than I expect. Work dries evenly and rarely cracks from heat, but slow drying means I wait longer between steps.

**Dampness.** After long rain I notice a faint earthy smell and a cool dampness on the lower part of the north wall. It is mild, and it comes and goes. I keep paper and cardboard well away from that wall.

**Sound.** The loft is quiet. Street noise is almost absent, and I hear the wheel and the fan and little else. This helps concentration. It also means I do not hear anyone upstairs, so I keep to the habit of telling someone when I am down there.

**Space.** The loft is large, and I rarely feel crowded even with the wheel, the kiln, shelves and a long table. The size lets me keep dusty work, such as glaze mixing, at one end and wet work at the other. I try to keep that division, because when I do not, dust ends up on drying pots.

**Kiln effects.** During firing the room warms noticeably near the kiln, and the rest of the space stays cool. That uneven heat is useful in winter. I do sometimes open the stair door to let the warm air rise into the house, but I check first that the fan is running.

**Dust.** Even with wet cleaning, a thin film builds up on the shelves in a week or so. It is worst on the shelves nearest the mixing area. Cleaning those first saves effort later.

**Stairs.** The stairs are the thing I think about most. Carrying wet work or heavy bags down is slow and I have learned to plan trips: tools and small items first, heavy items last, and nothing carried when I am tired.

**Overall.** Zolbrel loft is a good place for ceramics because it is quiet, even in temperature, and large enough to keep separate zones. Its weaknesses are the damp, the single exit and the cold in winter. Those are the things I keep watching, and the open questions above are mostly about them.

## Overview

Zolbrel loft is a large loft used for ceramics. It was built in 1997 and sits below ground, with its orientation to the north. This section is the short version I keep for myself, so I do not have to rediscover the basics every time I come back to the place after a break.

The properties, stated plainly:

- Kind: loft
- Area: ceramics
- Orientation: north
- Size: large
- Year built: 1997
- Floor: below ground

The odd thing about the name is that a "loft" below ground sounds like a contradiction. It is not. The space was built in 1997 as a loft-style room, meaning one wide open volume with few interior walls, and it just happens to be dug in below street level. The openness is what makes it useful for ceramics. There is room for wedging tables, shelves of drying work, a glazing corner, and a firing area, all in one room without anything feeling crowded. Because the size is large, I can keep these zones apart and still walk between them without moving things.

The north orientation matters more than I expected. Light from the north is even and cool, and it does not swing around during the day. That is good for judging glaze colour, because a glaze looks the same at the start of the morning as it does at the end of the afternoon. It is also bad for warmth. Direct sun never reaches the room, so it relies on stored warmth from the ground and on whatever heating I run. Being below ground helps in summer, since the room stays cool and clay does not dry out too quickly on the tables. In winter the same fact means the walls feel cold and damp air settles near the floor.

How I think about the place in practical terms:

- It is a good room for slow, steady work. Clay stays workable longer than it would in an upper room.
- It is a poor room for anything that needs to dry fast. Plaster molds, freshly thrown pieces and washed tools all take their time.
- It is a good room for judging finished pieces, thanks to the consistent northern light.
- It is a room where air movement has to be arranged on purpose, because nothing happens by itself.

The rest of this part of the handbook covers what goes wrong in the loft, where to look things up, and how I organise recurring work there.

## Problems

These are the recurring problems I have run into, written as symptom, likely cause, and what I do about it. I keep this list honest rather than hopeful, so some entries say "unresolved".

### Damp near the floor

Because the floor is below ground, moisture comes in through the walls and slab, especially after long wet spells. The symptoms are a cold, slightly sweet smell, darkened patches along the base of the walls, and cardboard boxes going soft if left on the floor.

What I do:

- Keep everything off the floor. Shelving sits on raised feet, and boxes of dry materials go on the upper shelves, never the bottom one.
- Store bagged powders, such as silica-bearing materials and dry glaze stock, in sealed bins rather than in their paper sacks.
- Run a dehumidifier during the wet season and empty its tank every day, because it fills faster than I remember.
- Wipe down the wall base with a dry cloth when I see a patch, and note where it is so I can tell if it spreads.

Status: managed, not solved. The cause is the construction, so I can only reduce the effects.

### Slow drying

Thrown and handbuilt work dries unevenly in the loft. Thin rims dry first and thick bases stay wet, which leads to cracks, particularly at the join between a foot and a body.

What I do:

- Cover rims loosely with plastic while the base catches up.
- Turn pieces on the shelf so that the side facing the door does not dry faster than the side facing the wall.
- Do not move work close to the heater to speed it up. That has caused more cracks than it has saved time.
- Accept that in the cold season, the drying stage takes noticeably longer than in the warm season, and plan around it.

### Poor air movement and dust

A large room with no through-draught holds dust in the air. Dry clay dust is the main concern, and it builds up on shelves, tools and the floor.

What I do:

- Wet-wipe surfaces and mop the floor. I never sweep dry.
- Keep a mask near the door and wear it when mixing dry materials or sanding bone-dry work.
- Open the stairwell door and any vent at the same time to create a draught while cleaning, then close them again to keep warmth in.

Status: the habits work if I keep them. The moment I skip a cleaning round, the dust returns.

### Cold walls and winter chill

The north orientation plus the below-ground floor means the room is cold for long stretches. Hands get stiff, glazes thicken in cold buckets, and clay feels stiffer than it should.

What I do:

- Store glaze buckets on a shelf away from the wall, and stir them thoroughly before each use because cold makes them settle harder.
- Keep a small supply of lukewarm water to bring a stiff glaze back to a workable consistency, adding it little by little.
- Wear fingerless gloves while wedging so my hands keep their feel for the clay.

### Light is even but dim

The northern light is consistent, but there is less of it at the far end of the room, farther from the windows. Details like pinholes or thin spots in a glaze coat are easy to miss.

What I do:

- Keep a bright movable lamp for inspection, and use it at the glazing table every time.
- Check finished pieces near the window as well, since the cool light there shows true colour.

### Access and moving heavy things

Being below ground means stairs. Large boards of work, sacks of clay and full buckets all have to be carried up or down, and that is where accidents and breakage happen.

What I do:

- Move one load at a time and never carry a full bucket and a board together.
- Keep the stairwell clear and the rail free of tools.
- Plan deliveries so that heavy items arrive when I can get help.

### Things I have not figured out

- Whether a permanent vent would cut the damp enough to justify the cost of installing it.
- Whether the dim far end would be better served by a fixed light or by rearranging the layout.
- How to dry large pieces evenly without a dedicated drying cabinet.

## References

This section lists where I look when I need more than my own notes. All of them are things I keep or can reach from the loft, described by what they are rather than by any outside source.

### Physical records kept in the loft

- **The kiln log binder.** It sits on the shelf nearest the firing area. Each firing has a page recording what went in, how the load was arranged, how it was fired, and how it came out. When something goes wrong with a glaze, this is the first place I check.
- **The glaze recipe cards.** Each recipe is on its own card in a box, with the base ingredients, the additions, the application method and a small test tile glued to the back. The tile shows what the glaze actually looks like, which the written description never does well.
- **The clay body sheet.** A single page taped inside a cupboard door, listing the clay bodies I use, what each is good for, and how each behaves in drying and firing.
- **The damp map.** A rough sketch of the room with the wall patches marked. I update it whenever I find a new patch, and it tells me whether the damp is spreading.

### Notes in this knowledge base

- The other parts of this handbook cover the material I do not repeat here, so I check them before adding anything new to this part.
- My general notes on glaze faults and drying faults apply to the loft, but the Problems section above is the version adjusted for this room.
- My notes on safe handling of dry materials are the reference for the mask and cleaning habits described earlier.

### Facts I look up most often

When I just need a quick fact about the place, I come back to the Overview. The ones I use most:

- The loft is large, which decides how much work I can run at once.
- It is below ground, which explains the damp, the cool summers and the stairs.
- It faces north, which explains the even light and the lack of sun warmth.
- It was built in 1997, which is useful when thinking about how old the walls and the slab are and why the damp behaves as it does.

### Habits for keeping references useful

- Write the entry the same day. Details about a firing or a fault fade quickly.
- Put the test tile on the recipe card straight away, not later.
- When a fix works, add it to the Problems section. When it fails, add that too, since a failed fix is worth knowing about.
- Remove advice that I no longer follow, so the notes do not drift away from what I do.

## Schedule

This is the routine I follow for recurring work in the loft. It is organised by rhythm rather than by calendar date, because the room reacts more to the weather and the season than to any fixed day. I adjust it when the damp or the cold changes.

### Every working session

- Open the stairwell door and the vent for a short while to refresh the air, then close them if the room is cold.
- Check the dehumidifier tank and empty it if needed.
- Look at the wall base for new damp patches.
- Wet-wipe the wedging table before starting and again when finished.
- Cover or turn any drying work before leaving.

### Daily during the wet season

- Empty the dehumidifier tank and note whether it filled faster than usual.
- Check the bottom shelves and the floor for soft cardboard or standing moisture.
- Inspect drying work for cracks at the joins, since slow, uneven drying shows up quickly.

### Weekly

- Mop the floor and wipe down shelves, leaving no dry dust behind.
- Stir every glaze bucket thoroughly and check the consistency, adding a little lukewarm water if it has thickened.
- Check the sealed bins for any sign of moisture getting in.
- Update the kiln log binder so it matches what actually came out of the last firing.
- Rotate work on the drying shelves so no side is left facing the faster-drying direction for too long.

### Monthly

- Update the damp map and compare it with the previous version.
- Go through the glaze recipe cards and add test tiles for any new recipe.
- Check the lamps, the heater and the dehumidifier for faults, and clean the dehumidifier filter.
- Look over the stairs and the rail, and clear anything that has built up in the stairwell.
- Review the stock of clay and dry materials and plan deliveries for a time when I can get help carrying.

### By season

**Cold season**

- Expect longer drying times and plan the work so that pieces are not rushed.
- Keep glaze buckets away from the cold wall and stir them more often.
- Run the heater gently and keep work away from it.
- Watch the damp closely, since cold walls make it worse.

**Warm season**

- Take advantage of the cool room for slow work with clay that should stay soft.
- Keep ventilating, because the room still holds dust and stale air.
- Check that nothing is drying too quickly at the rims now that the air is dry elsewhere.

**Between seasons**

- Reassess the layout of the shelves and tables to see whether the dim far end is being used well.
- Go through the Problems section and cross out what is solved, then add anything new.
- Decide whether any of the open questions listed there deserve action.

### Yearly

- Do a full clear-out and wet clean of the whole room, moving shelving away from the walls so I can see the wall base properly.
- Throw away old, unused glaze and anything stored too long.
- Re-read the whole handbook and correct anything that no longer matches how the loft works.
- Think about whether the loft, as a large, north-facing, below-ground room built in 1997, still suits the way I work, or whether some part of the setup needs to change.

## Measurements

This section collects the readings and fixed properties I rely on when I plan work in Zolbrel loft. The loft is a large space for ceramics, built in 1997, and it sits below ground. Its windows and main light face north. Those five facts shape almost every reading below, so I keep them in view when I compare numbers from one visit to the next.

### Fixed properties

- Kind: loft
- Area: ceramics
- Orientation: north
- Size: large
- Year built: 1997
- Floor: below ground

The loft is below ground, so the walls hold a steady temperature through most of the year. That is good for slow drying of clay, and it is bad for anything that dislikes damp. The north orientation means no direct sun reaches the work tables. The light is even and cool, which is good for judging glaze colour, but it never warms the room by itself.

### Humidity

The measured humidity of Zolbrel loft is 72.80 %.

This is the reading I treat as the reference point for the room. It is high. For a ceramics loft, I find it workable for wet clay and slow drying, but it is too damp for storing dry materials, paper labels, cardboard boxes, or metal tools without some protection. I write down what that figure means in practice:

- Greenware dries slowly and evenly. Thin handles and rims are less likely to crack, but thick pieces take a long time to reach bone dry.
- Bagged glaze powders and plaster clump if left open. I keep them sealed and raised off the floor.
- Bisque ware picks up moisture if it sits for weeks. Before a glaze firing I let it dry out in a warmer place first.
- Iron tools and wire cutters rust at the edges. I wipe them and keep a light coat of oil on the ones I use less often.
- Cardboard softens. I use plastic bins with lids instead.

Because the room is below ground, the humidity does not swing much from day to day. It rises a little after heavy rain and after a long session with wet clay or a lot of washing. A single reading is therefore not a surprise, but a drifting reading over several weeks is a sign that something has changed, usually ventilation or a small leak.

### How I take readings

I use the same small hygrometer each time, so that my numbers are comparable even if the device is slightly off. These are the habits that keep the readings useful:

1. Place the device at about table height, in the middle of the room, away from the sink and from any door.
2. Leave it for a good while before reading, so it can settle after being carried in.
3. Take the reading at roughly the same time of day.
4. Avoid reading right after mopping, washing buckets, or running the kiln.
5. Write the number, the time and a short note about the weather outside.

If I move the device to a corner or near the wall, I expect a higher figure, because the cold wall holds more damp air next to it. I do not mix those wall readings with the room reference.

### Size and layout notes

Zolbrel loft is large, and that matters for measurement. A large room has pockets: the air near the far wall is not the same as the air near the stairs. I treat the room as three zones and note where I measured.

- Entrance zone: the driest part, because air from above mixes in here.
- Work zone: the middle of the room, where the reference reading is taken.
- Back zone: the dampest part, furthest from fresh air, so I store only sealed items there.

Large size also means the room is slow to change. If I run a dehumidifier or open the vents, I should expect to wait a long time before the middle of the room shows any difference. I do not judge the effect after an hour. I judge it over days.

### Light and temperature remarks

North light in a below-ground room is weak but steady. I do not measure it with an instrument; I just note that colour tests look the same in the morning and the afternoon, which is the main benefit. For temperature, the room stays cool and stable, so I do not worry about clay freezing or overheating. What I watch is the combination of cool air and high humidity, because that is where condensation shows up on cold metal and on the glass of shelves.

### Using the readings

I use the humidity figure to decide a few routine things:

- Whether to cover greenware loosely or tightly. With this humidity, I cover loosely, since the room already slows drying.
- Whether a piece needs extra drying time before the kiln. Usually yes, and I add time rather than risk steam damage inside the kiln.
- Whether stored materials are still safe. If powders have clumped, I treat the room as having drifted damper than the reference and check the vents.
- Whether to run a dehumidifier. I do this when the reading stays clearly above the reference for more than a few days, not for a single high number.

### What would make me re-measure

I take fresh readings and compare them with the reference when any of these happen:

- A long period of rain, or a flood risk nearby.
- A change to the vents, the door, or the stairs area.
- New shelving or large items that block the air near the walls.
- Visible mould, a musty smell, or white salt marks on the wall.
- Glaze or clay behaving differently from how it usually does.

### Short summary of the values

- Zolbrel loft is a loft for ceramics.
- Orientation: north.
- Size: large.
- Built in 1997.
- Floor: below ground.
- Measured humidity: 72.80 %.

I keep this list at the end so I can check the whole set of facts at a glance. When I update the humidity reference after a proper round of readings, I change the figure in the humidity subsection and in this summary together, so that the two never disagree.
