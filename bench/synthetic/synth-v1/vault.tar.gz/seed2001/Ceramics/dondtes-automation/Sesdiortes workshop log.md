---
type: log
status: active
project: dondtes-automation
area: ceramics
---

# Sesdiortes workshop log

## Schedule

The Sesdiortes workshop is a medium-sized ceramics workshop, built in 2009, and it sits below ground with its main orientation to the north. I plan my time there around the fact that it stays cool and steady, so the schedule follows the clay rather than the clock.

Monday is for preparation. I wedge clay, sort out what is drying, and check which pieces are ready to move on. I do not throw on Mondays unless a deadline forces it.

Tuesday and Wednesday are throwing days. The cool room means the clay stays workable for longer, so I can do longer sessions without the pieces slumping or drying at the rim too quickly.

Thursday is for trimming and attaching handles, spouts and feet. Pieces are leather-hard by then, if they were thrown early in the week and covered properly.

Friday is for glazing and loading. I try to finish the glaze work before lunch so the afternoon is free for packing the kiln and cleaning.

Saturday is optional. I use it for testing, reading, or sketching ideas. If nothing is pressing, I leave the workshop closed.

Sunday is always off. I do not go down the stairs at all.

A few fixed habits apply to every working day:

- Open the door and let the air move for a few minutes on arrival.
- Look at the floor and the corners for damp patches.
- Wipe down the wedging table before and after use.
- Write one line in this log before leaving.

## Ideas

Because the room is below ground and faces north, it has little direct light. Most of my ideas are about making that a strength instead of a problem.

- Build a slow-drying shelf area at the back wall, where the air is calmest, for large plates and platters that tend to warp.
- Add a small bench lamp with neutral light for judging glaze colour, since daylight is not a reliable guide down here.
- Try a series of tall, narrow vases, since the steady conditions suit pieces that need even drying.
- Keep a dedicated test-tile board on the wall, with each tile labelled by clay and glaze, so I stop forgetting what worked.
- Set aside one shelf for unfinished experiments and review it once a month, throwing out anything I no longer care about.
- Try a rotation system for buckets so the oldest slip and reclaim get used first.
- Make a simple rolling cart for moving bisque ware to the kiln area in one trip.
- Paint the lower part of the walls with a washable coat to make cleaning faster.

Some ideas are longer term. A small dehumidifier on a timer might help in wet months. A better extractor near the glazing corner would help too. I would also like to rearrange the room so that clay work and glaze work are clearly separate zones, with a clean path between them.

## Risks

The main risks come from the location. A workshop below ground collects moisture, holds dust, and has limited escape routes.

**Damp.** Moisture can creep in through the walls and floor. It can ruin stored bags of clay dust, cardboard boxes, and any paper labels. It can also encourage mould on wooden shelves.

**Dust.** Dry clay dust is a real health concern. Silica in the dust is harmful to the lungs over time. In a closed space with little air movement, it lingers. I must wet-clean surfaces and never sweep dry.

**Ventilation.** The room has limited natural airflow. Glaze materials and kiln fumes need proper extraction. If the fan fails, I should stop firing and leave the room.

**Stairs and floors.** Wet clay on steps is slippery. Carrying heavy boxes or full kiln shelves up and down is a strain on the back and a trip hazard.

**Electricity and water.** Water near sockets is a standing risk in a below-ground room. If there is ever flooding, the power must be switched off before I step into the room.

**Cold.** The north orientation and the lack of sun keep the temperature low. Cold clay is stiff, and cold hands tire quickly. Glazes can also behave differently if stored too cold.

**Isolation.** I often work alone. I should tell someone when I go down for a long session, and keep a phone within reach.

## Setup

The workshop is a medium-sized room, built in 2009. It is on a level below ground, and the working side faces north. The area of the work is ceramics, and the layout reflects that.

The main zones are:

- **Wheel corner.** The wheel sits near the middle of the room, with a splash tray and a low stool. A bucket of water and a sponge stay within reach.
- **Wedging table.** A sturdy table along one wall with a canvas surface. Clay is stored underneath in sealed bins.
- **Drying shelves.** Open racks along the back wall, with boards for pieces to rest on. Larger pieces get a loose cover of plastic at the start.
- **Glaze corner.** A separate area with shelves for jars, a scale, a sieve, and a small sink or bucket station. It is kept away from the clay area to avoid cross-contamination.
- **Kiln area.** The kiln stands in its own space, clear of walls and anything flammable, with the extractor close by.
- **Tool storage.** A pegboard with the regularly used tools, plus a drawer for small items such as needles, ribs, and sponges.
- **Cleaning station.** A mop, a bucket, cloths, and a wet vacuum.

Lighting is a mix of overhead panels and a bench lamp. Because the room faces north and is below ground, I treat all light as artificial and plan accordingly.

I keep a first aid kit near the stairs and a fire extinguisher near the kiln. A basic checklist is pinned beside the door.

## Maintenance

Maintenance is the thing that keeps a below-ground workshop pleasant to use. I split it into frequent small jobs and occasional bigger ones.

**Every session**
- Wet-wipe the wedging table and wheel.
- Empty the splash tray into the settling bucket, not the sink.
- Cover unfinished pieces.
- Put lids back on glaze jars and clay bins.

**Weekly**
- Mop the floor with a damp mop.
- Check the corners and the base of the walls for signs of damp.
- Clean sponges, ribs, and brushes.
- Wipe the shelves where bisque ware is stored.

**Monthly**
- Check the extractor fan and clean its filter.
- Inspect the kiln elements, lid, and shelves for cracks or flaking kiln wash.
- Stir all glazes thoroughly and add water if they have thickened.
- Reorganise the reclaim buckets and mix a new batch.
- Check the first aid kit and the fire extinguisher.

**Yearly**
- Look over the wiring and sockets, and have anything doubtful checked by a professional.
- Repaint or seal any wall patch that has started to flake.
- Replace worn tools and the wheel splash pan if it is damaged.
- Do a deep clean, moving everything out where possible.

If I notice any new smell, stain, or soft patch on the wall, I write it in the log right away and keep an eye on it over the next few sessions.

## Background

The workshop was built in 2009. It was designed as a medium-sized working space, and the choice to put it below ground gave it a naturally steady temperature. The north orientation was chosen on purpose: potters have long preferred north light because it is even and does not cast harsh shadows or heat the room.

Over the years the room has been used almost entirely for ceramics. Early on it was a rough space with bare walls and a few shelves. Gradually it picked up proper storage, a better floor, better lighting, and a dedicated kiln corner.

The below-ground position has real advantages. Summer heat barely reaches it, and clay stays workable without much effort. Noise from the wheel and the wedging does not bother anyone upstairs. The drawback is moisture, and most of the work I have done on the room has been about managing that.

I keep this log to remember what I tried, what worked, and what did not. It is also a record of how the room behaves through the seasons: when it feels damp, when the pieces dry too slowly, when the cold becomes a problem. I look back through the notes when planning changes, so I do not repeat old mistakes.

Some basic facts, for reference:

- Kind: workshop
- Area: ceramics
- Orientation: north
- Size: medium
- Year built: 2009
- Floor: below ground

## Checklist

**Arriving**
- [ ] Open the door and let the air move.
- [ ] Switch on the lights and the extractor.
- [ ] Check the floor and corners for damp.
- [ ] Look at the kiln area for anything out of place.

**Starting work**
- [ ] Set out the tools I need for the day.
- [ ] Fill the water bucket.
- [ ] Check the clay is the right stiffness.
- [ ] Uncover the pieces I plan to work on.

**Before firing**
- [ ] Make sure pieces are fully dry.
- [ ] Check the kiln shelves are coated and level.
- [ ] Confirm the extractor is working.
- [ ] Clear the area around the kiln.
- [ ] Note the firing in the log.

**Leaving**
- [ ] Cover all unfinished pieces.
- [ ] Wipe the table, wheel, and tools.
- [ ] Close lids on glazes and clay bins.
- [ ] Turn off the kiln, lights, and extractor when it is safe to do so.
- [ ] Take out the rubbish.
- [ ] Write one line in the log.
- [ ] Lock the door.

## Measurements

I take readings in the middle of the room, away from the kiln and the door, at about the height of the wheel. I try to measure at the same time of day so the results are comparable.

The measured humidity of Sesdiortes workshop: 24.13 %

That is the reading I recorded for this entry. I treat it as a single snapshot, not a trend, and I compare it to earlier notes before drawing any conclusion. Humidity in a below-ground room can change quickly after cleaning with water, after a firing, or after a wet spell outside.

Other things I keep track of alongside humidity:

- Room temperature at the start and end of a session.
- Whether the walls feel cold or damp to the touch.
- How long a thrown pot takes to reach leather-hard.
- Whether glazes in open jars form a skin or thicken faster than usual.

The room is medium in size, so a single hygrometer placed centrally gives a fair picture. If I ever suspect a problem near a particular wall, I move the instrument there for a day and compare. For now, one reading per visit is enough, and I write it at the bottom of that day's log line.
