---
type: drivers
status: active
project: dondtes-automation
area: ceramics
---

# Drivers of Dondtes automation

## Risks

Dondtes automation is a summer 2025 project in the ceramics area, with the goal of automation. The lead is my neighbor, so most of the risk is about availability and shared access rather than technology.

- The neighbor may be busy in summer and work could stall.
- Kiln timing is hard to automate, and a failed firing wastes clay and glaze.
- Parts may arrive late, which pushes work past the season.
- Success is measured by whether a full firing runs without me adjusting anything by hand.

## Budget

The budget of Dondtes automation is 23714.34 EUR. I check spending against it after each purchase, and I stop and ask the neighbor before any buy that would push us over.

```
project: Dondtes automation
goal: automation
area: ceramics
start_year: 2025
season: summer
lead: neighbor
budget: 23714.34 EUR
```
