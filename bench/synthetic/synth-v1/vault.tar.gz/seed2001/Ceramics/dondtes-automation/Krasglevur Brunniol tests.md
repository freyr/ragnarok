---
type: research
status: active
project: dondtes-automation
area: ceramics
description: "Research about Krasglevur Brunniol."
---

# Krasglevur Brunniol tests

## Observations

Krasglevur Brunniol is an inspector. I have known Krasglevur since 2022, and the work is always in ceramics. Contact goes through email, and that is the only channel I use. Availability is weekends, so I plan any visit or review for a Saturday or Sunday and send the request a few days ahead.

What I notice about the way Krasglevur works:

- Inspections start with the glaze surface, then move to the body of the piece, and last to the base.
- Notes are short and written down on the spot, not from memory afterwards.
- Questions come by email in a single message, not in pieces, so I try to answer them the same way.
- A piece that fails is explained with a reason, not only a verdict.

Over the years the pattern has been steady. When I bring a batch, I get back a clear sorting: pass, rework, or reject. The rework group is usually the most useful, because the comments tell me what to change in the next firing. Earlier remarks from the first year are collected in [[Baerkpend Drormaeth notes 2022]], and I still compare new results against those.

One thing I want to remember: weekend availability means there is no quick turnaround on a weekday problem. If a kiln run goes wrong on a Tuesday, I should write it down and send it so that it waits in the inbox for the weekend. Sending late on Friday does not help much, since the reply tends to arrive after the next weekend has started.

## Checklist

Before I send anything to Krasglevur Brunniol, I go through this list.

- Pieces are clean and dry, with no dust in the recesses.
- Each piece has a small label with my own batch mark, written in pencil on tape, not on the ceramic.
- The email states what I want checked: glaze, shape, cracks, or fit.
- I have photographs of every piece from at least three sides.
- I know which weekend I am aiming for and have said so in the message.
- Packing is done with enough soft material so that nothing touches anything else.
- I have a spare copy of my firing notes to refer to if there are questions.

After the inspection:

- Write the result next to each batch mark the same day.
- Move rejected pieces to a separate shelf, so they do not get mixed back in.
- Add anything new to the running notes, and link it from the 2022 page if it relates to an old problem.

## Safety

Ceramics work looks calm, but a few risks are worth writing down because they come up around inspections.

- Handle fired pieces with both hands, and never carry a stack of more than a few at once.
- Cracked edges can be sharp. I wear cut-resistant gloves when I sort rejected pieces.
- Broken glazed pottery should go into a sturdy box, not a thin bag.
- Dust from sanding or grinding is harmful to breathe. I use a proper mask and wet cleaning, not sweeping.
- If a piece is meant for food use, I keep it apart from anything that failed a glaze check until the glaze question is settled.
- When a weekend visit happens at the workshop, I keep the floor clear and the walkways free of boxes.

I treat any piece that Krasglevur marks as doubtful as not safe for food use until it has been reworked and checked again. That rule is simple and I do not bend it, even for pieces I like.

## Quotes

The only price I have on record for this work is the quote from Krasglevur Brunniol: 5868.48 EUR.

Some notes about how I read that quote:

- It came by email, which fits the way Krasglevur prefers to be contacted.
- I want to confirm in writing what the amount covers before agreeing, including how many pieces, how many visits, and whether a written report is included.
- Because availability is weekends only, I should ask whether weekend work changes the scope or the timing.
- If I ask for a second review after rework, I need to ask whether that is inside the same amount or counted separately.

I have not yet compared this against any other inspector, and I should do that before deciding. For now the quote stays as a reference figure, and I will add a line here once I have an answer to the questions above.

## Tools

These are the tools I use around inspection days. None of them are special, but I keep them together so that I am not looking for things on a weekend morning.

- A bright lamp with a daylight bulb, for checking glaze color and small flaws.
- A small hand magnifier for hairline cracks and pinholes in the glaze.
- A flat, soft work mat so that pieces do not slide or chip.
- A ruler and a set of calipers for checking rims, lids, and fit.
- A notebook and pencil, plus my phone for photographs.
- A tapping stick or just a knuckle, since a dull sound can show a crack that the eye misses.
- Masking tape for labels.

I keep the notebook with the 2022 notes in the same place, so I can look back at older comments quickly. See [[Baerkpend Drormaeth notes 2022]] for the earlier context.

## Supplies

Supplies I want on hand so that an inspection weekend does not get wasted:

- Soft packing material, such as paper, cloth, or foam sheets.
- Sturdy boxes in a few sizes, with dividers where possible.
- Tape, both masking tape for labels and stronger tape for sealing.
- Marker pens and pencils for batch marks and notes.
- Cut-resistant gloves and a dust mask.
- Clean cloths and a small bucket for wet cleaning.
- Spare printed copies of my firing notes.
- A few clean envelopes or folders for the written comments that come back.

I check the stock a week before each planned weekend. If anything is low, I order it right away, because running out of packing material is the most common reason I delay sending a batch to Krasglevur Brunniol, the inspector I have worked with since 2022.
