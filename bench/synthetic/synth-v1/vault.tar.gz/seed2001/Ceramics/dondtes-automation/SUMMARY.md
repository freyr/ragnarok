---
type: summary
status: active
project: dondtes-automation
area: ceramics
description: "Summary about Dondtes automation."
---

# Summary of Dondtes automation

This is the summary of Dondtes automation, a project with the goal of automation in the area of ceramics. It started in the summer of 2025, and my neighbor is the lead. I keep this note as the one place to check where things stand before I talk to them again.

Current stage: the project is past the idea phase and in the middle of preparation. The basic plan is agreed, the test results are in, and most of what we need to buy has been chosen. Nothing has been built for real yet. What is left is mainly ordering, a few checks and one open question about the control side.

## Supplies

The supply list is mostly settled. I went through it with my neighbor and marked each line as in hand, ordered or still undecided. The earlier results in [[Fulmasvork workshop tests 2024]] shaped most of the choices, especially the ones about heat and dust near the kiln.

| Item | Purpose | Status |
|---|---|---|
| Control board | Runs the sequence for the kiln and the turntable | In hand |
| Motor driver | Moves the glazing turntable | In hand |
| Temperature probe | Reads the kiln chamber | Ordered |
| Heat-proof cable | Keeps wiring safe near the kiln | Ordered |
| Relay unit | Switches the kiln on and off | Undecided |
| Enclosure box | Protects the electronics from clay dust | Undecided |
| Radio link module | Sends status to the workbench | Undecided |

Things I still need to sort out around the supplies:

- Check that the relay unit can handle the load of our kiln. My neighbor wants to ask the person who sold them the kiln.
- Decide whether the radio link is really needed or whether a plain cable is enough. The notes in [[Vorful radio receiver handbook]] help here, since they explain the range problems in a workshop full of metal shelves.
- Find a spot for the enclosure that is away from the glaze table, because splashes ruin electronics quickly.
- Keep a short spare list: fuses, connectors and a few meters of cable, so one failure does not stop the work for weeks.

## Next action

The next action is NX-8800. I will take it up with my neighbor at the next visit, and it comes before any other ordering. Until it is done I will not buy the three undecided items from the table, because the result may change which of them we need.

After that the order of work is simple:

- Finish the relay and enclosure choice.
- Wire the control board on the bench, away from the kiln, and run it with a dummy load.
- Connect the temperature probe and compare its readings with the old manual dial.
- Only then move everything next to the kiln for a trial firing.

What is done so far: the plan is written, the early tests are reviewed, and the board and driver are on my desk. What is open: the relay, the enclosure, the radio link, and a clear rule for who watches the first automatic firing. My neighbor says they will be present, but I want that written down before we start.

## Decisions

The decisions made so far are few, but they are firm.

- Go decision date: 2020-06-04. This is the date recorded for the go decision on Dondtes automation, and I treat it as the point where the project was approved to continue.
- Lead: my neighbor stays the lead. They make the final call on anything touching the kiln, and I handle notes, lists and ordering.
- Scope: only the kiln sequence and the glazing turntable are automated at first. Loading, unloading and cleanup stay manual.
- Season: the work is planned for summer, when the workshop is warm and dry and there is less risk to the wiring from damp.
- Safety: the first automatic firing happens with a person in the room, and a manual cutoff stays in place whatever the electronics do.

Decisions still waiting: whether to use the radio link, which relay unit to buy, and how we log temperature during firings. I will update this note when NX-8800 is finished, and move the stage forward if the bench test goes cleanly.
