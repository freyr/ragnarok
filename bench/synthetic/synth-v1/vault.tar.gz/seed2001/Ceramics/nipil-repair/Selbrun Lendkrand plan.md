---
type: plan
status: active
project: nipil-repair
area: ceramics
description: "Plan about Selbrun Lendkrand."
---

# Selbrun Lendkrand plan

## Tools

These are the things I use when I plan work with Selbrun Lendkrand, my supplier contact for ceramics. He is reached by phone, and he is available in the evenings. I have known him since 2011, so most of my tools are built around that routine.

The first tool is the phone itself. I keep it charged and nearby from the late afternoon so that I do not miss the evening window. Calls are the only contact method that works with him, so I do not waste time writing long messages that he will not read.

The second tool is a paper notebook that stays next to the phone. Before each call I write three or four lines at the top of a fresh page: what I need, how much, by when, and what I am willing to accept instead. During the call I write down what he says, in his words where I can. After the call I add one line that says what we agreed.

The third tool is a simple order sheet. It has columns for item, quantity, glaze or finish, and notes. I keep one sheet per order and clip it to the notebook page for that call. This makes it easy to compare what I asked for with what arrived.

The fourth tool is a small calendar reminder for evening calls. I set it for the time I usually phone, and I add a second reminder for a follow-up call if the first one goes unanswered. I do not try to call him during the day, because that has never worked well.

The fifth tool is a shoebox of samples. Over the years I have kept tiles, small cups, and test pieces from different batches. When I describe a color or a surface to him, I can hold a sample in my hand and describe exactly what I mean. He often asks which piece I am looking at, and I can answer clearly.

The last tool is a folder with past delivery notes and receipts. I use it to check what we agreed before and to settle small disagreements without guessing.

## Lessons

The main lesson from working with Selbrun Lendkrand is that a good relationship with a supplier is mostly about being predictable. He is a supplier contact in the ceramics area, and since we have known each other since 2011, we both know how the other works. I call in the evening, I am clear, and I do not rush him.

The second lesson is to prepare before I dial. When I call without notes, I forget something, and then I need a second call. A second call costs goodwill, so I try to cover everything in one conversation.

The third lesson is to ask for confirmation of details in plain words at the end of the call. I repeat the quantity, the finish, and the expected timing. If he agrees, I write it down. If he hesitates, I know there is a problem that I should handle at once.

The fourth lesson is that ceramics is slow. Firing, drying, and cooling take time, and nobody can hurry them without risking the work. I plan with a buffer, and I do not promise my own customers anything until Selbrun has confirmed his side.

The fifth lesson is about tone. He responds better to a calm, direct request than to a long explanation. I say what I need, I listen, and I leave room for him to suggest something better. Several times his suggestion saved me money or gave me a better result than my original idea.

The sixth lesson is to keep a record of small favors. If he helps me with a rush job, I remember that, and I try to give him an easy order or a prompt payment in return. Over many years this has built trust.

The last lesson is that long relationships need occasional check-in calls with no business purpose. A short call to ask how the season is going keeps the connection warm and makes the next order easier.

## Problems

The most common problem is simply reaching him. Because he is available in the evenings and uses the phone, a missed call can mean waiting until the next day. I have learned to try twice in the same evening, with a gap of an hour or so, before I give up.

A second problem is that phone calls leave no written trail. If we agree on something and later remember it differently, there is nothing to point to except my own notes. That is why the notebook matters so much, and why I add the agreement line after each call.

A third problem is color and finish variation between batches. Ceramics can come out slightly different each time, even with the same glaze name. I have received pieces that were a little lighter or glossier than the sample. The sample box helps, but it does not remove the issue completely.

A fourth problem is breakage in transit. Even with good packing, some pieces arrive cracked. I need to check each delivery soon after it arrives and call him about any damage in the next evening window, while the details are fresh.

A fifth problem is that lead times can shift without much warning. A kiln problem or a busy season can add days. I try to ask at the start of each call whether he sees any delays coming.

A sixth problem is my own habit of leaving things late. When I order close to a deadline, I have no room for these delays. I am working on ordering earlier and keeping a small stock of the items I use most.

## Maintenance

Maintaining the relationship with Selbrun Lendkrand is a small but steady task. I treat it like maintaining any other tool that I depend on.

Each month I look at my notebook and check whether there are open items: orders not yet confirmed, damaged pieces not yet credited, or questions I meant to ask. I list them on one page so that the next call can cover them all.

Every few months I make a call that is only a check-in. I ask about his work, about whether his materials have become harder to get, and whether he plans any changes to what he offers. I take notes, because small changes in his range can affect my plans.

I also keep my own records in order. The order sheets are filed by date, the delivery notes are in the folder, and the sample box is labeled with the batch or the approximate time I received each piece. When a sample is no longer representative, I replace it or mark it as old.

I maintain the phone routine too. I keep his number saved with a note that says evenings only, so that anyone using my phone does not call him at a bad time. I also check that my calendar reminders are still set.

Once a year, around the anniversary of when we first started working together, I review the whole relationship. I look at what went well, what went wrong, and whether I should change how I order. That review feeds directly into this plan.

## History

I first met Selbrun Lendkrand in 2011. At that time I was looking for a reliable source of ceramics and was trying several suppliers. He was one of them, and he stood out because he answered questions honestly, even when the honest answer was that he could not do something.

In the early years our orders were small. I bought a few items at a time and tested them. We spoke by phone in the evenings from the beginning, because that was when he had time. That habit never changed.

Over the following years the orders grew. He began to suggest items I had not thought of, and I began to give him more notice about my needs. We had a few rough moments, mostly about late deliveries and damaged goods, but each time we sorted it out by talking.

At some point I stopped trying other suppliers for the same items. That was not a formal decision. It simply became clear that the effort of finding someone new was not worth it when he was already dependable.

Later on I started keeping proper notes of each call, because the volume and complexity of orders made memory unreliable. That is when the notebook and the order sheets became part of my routine.

More recently we formalized part of our arrangement with a contract, which I describe in the Contracts section. That step felt natural after so many years, and it gave both of us a clearer basis for pricing and timing.

## Risks

The biggest risk is dependence. If I rely on one supplier contact for ceramics, then anything that happens to him affects my work. Illness, a kiln failure, or a decision to close or change his business would leave me scrambling.

A second risk is communication. Since he is reached only by phone and only in the evenings, any problem with that channel causes delay. A broken phone, a bad signal, or a change in his schedule could cut me off for days.

A third risk is the lack of written records from calls. If a disagreement arises and my notes are incomplete, I may have a weak position. I reduce this risk by writing everything down and by confirming key points at the end of each call.

A fourth risk is quality drift. Over a long relationship it is easy to stop checking carefully because everything has been fine. I try to inspect every delivery as if it were the first.

A fifth risk is that my own needs change. If I move toward items he does not make, I will need another supplier, and I should be ready to raise that honestly rather than let the relationship fade.

A sixth risk is financial. Prices can move, and I should not assume that today's terms will last. The contract helps, but I still review the costs regularly.

To limit these risks I keep a short list of alternative suppliers, even though I do not use them now. I also keep a modest stock of my most-used items so that a short interruption does not stop my work.

## References

These are the sources I use when I plan around Selbrun Lendkrand.

- My notebook of call notes, kept next to the phone.
- The order sheets, one per order, filed by date.
- The folder of delivery notes and receipts.
- The signed contract, kept with my other paperwork.
- The sample box, which acts as a physical reference for color and finish.
- My calendar, which shows when I called and when follow-ups are due.
- The short list of alternative ceramics suppliers.

When I need to settle a question, I check them in that order: the notebook first, then the order sheet, then the delivery notes, and finally the contract. Most questions are answered by the first two.

For basic facts about him, I rely on this note. He is a supplier contact, his area is ceramics, his contact method is phone, his availability is evenings, and I have known him since 2011. If any of that changes, I update this note first and then adjust the other records.

## Safety

Safety matters with ceramics, even when I am only handling finished goods. The first concern is handling breakage. Broken ceramic has sharp edges, so I wear cut-resistant gloves when I unpack deliveries and when I clear damaged pieces.

The second concern is lifting. Boxes of ceramics are heavier than they look. I lift with my legs, I do not carry more than I can manage comfortably, and I ask for help with large cartons.

The third concern is the surface of glazed items. Some glazes are not suitable for food use, and I should not assume they are. When I plan an order for items that will touch food, I ask Selbrun directly whether the glaze is food-safe and I write his answer down.

The fourth concern is dust. If I need to cut, sand, or grind ceramic material, I wear a dust mask and eye protection and work in a ventilated space. Fine ceramic dust is not something I want to breathe.

The fifth concern is storage. I keep boxes off the floor and away from the edge of shelves, and I do not stack them too high. A falling carton can hurt me and ruin the contents.

The sixth concern is the evening call itself. I make calls from a quiet and safe place and I do not handle fragile items while I am on the phone.

## Checklist

Before the call:

- Phone charged and nearby.
- Notebook open to a fresh page.
- Order sheet filled out with item, quantity, finish, and notes.
- Samples within reach.
- Open items from the last call listed.
- Deadline for my own customer clear in my mind.

During the call:

- Ask whether he sees any delays.
- State the order clearly.
- Ask about price changes.
- Ask about food-safe glaze if relevant.
- Repeat the quantity, finish, and timing at the end.
- Write down what we agreed.

After the call:

- Add the agreement line to the notebook.
- Clip the order sheet to the page.
- Set a calendar reminder for the expected delivery.
- Note any follow-up needed.

On delivery:

- Check the packaging for damage.
- Unpack with gloves.
- Compare each item with the order sheet and a sample.
- Record any breakage or variation.
- Call him in the next evening window about any problem.
- File the delivery note.

Each quarter:

- Review open items.
- Make a check-in call.
- Refresh the sample box.

## Observations

Over the years I have noticed several patterns in how Selbrun Lendkrand works. He is most relaxed in the evenings, and calls that start in that window tend to be longer and more useful than hurried ones.

He is honest about limits. If he cannot make something or cannot meet a date, he says so, and I value that more than a cheerful promise that falls through.

He prefers simple requests. When I give him a clear item, quantity, and date, things go smoothly. When I ramble or change my mind during the call, errors become more likely.

His quality is steady, but not perfect. Variation between batches is real, and I have learned to treat each delivery as its own thing to inspect.

He remembers history. He often refers to earlier orders and to what we agreed in the past, which is a reminder that I should keep my own records as carefully as he seems to keep his memory.

Busy periods affect him. When the season is heavy, his answers are shorter and his lead times grow. I try to order earlier at those times and to keep calls brief.

He is open to suggestions. If I describe the problem I am trying to solve rather than only the item I want, he sometimes proposes a better option.

Finally, the phone works for us. I once considered pushing for written messages, but I decided that it would cost more goodwill than it would gain. The better answer was to improve my own note-taking.

## Supplies

The supplies I normally source through Selbrun Lendkrand fall under ceramics. I will keep the list general, since the exact range changes over time.

- Finished ceramic items for resale or use.
- Test pieces and small samples when I am exploring a new finish.
- Occasional special pieces made to my description.

Supplies I keep on my own side to support the work:

- Packing paper and padding for storing and moving ceramics.
- Strong cartons in a few sizes.
- Cut-resistant gloves.
- A dust mask and eye protection.
- Labels and a marker for the sample box.
- Notebook pages and order sheets.
- Spare phone charger.

I try to keep a small reserve of his most popular items so that a late delivery does not leave me with nothing to offer. The reserve should be modest, because stored ceramics take space and can be damaged by handling.

When I order, I think about whether the items are for immediate use or for stock, and I tell him so. It helps him plan, and it sometimes affects what he suggests.

At the start of each season I review the list of supplies and check whether anything is running low, whether any packing materials need replacing, and whether any sample in the box is out of date.

## Costs

I do not record exact prices in this note, because they change and because I keep them on the order sheets instead. What I record here is how I think about costs when working with Selbrun Lendkrand.

The main cost is the price of the ceramics themselves. I ask about price at the start of each call and write down what he says. If something has changed, I ask why, and I decide whether it is acceptable.

The second cost is shipping and packing. Ceramics are heavy and fragile, so shipping is not trivial. I ask whether the price includes careful packing, and I compare that with the cost of breakage.

The third cost is breakage itself. Even a small percentage of damaged items adds up. I track damage on the delivery notes so that I can discuss it calmly and, when appropriate, ask for a credit or a replacement.

The fourth cost is my own time. Evening calls take part of my free time, and preparing for them takes more. Good preparation reduces the number of calls I need, which reduces this cost.

The fifth cost is storage. Keeping a reserve of items uses shelf space and carries a risk of damage. I weigh this against the cost of running out.

The sixth cost is the cost of a mistake. A wrong finish or a wrong quantity can be expensive to fix. That is why I confirm details at the end of every call.

Finally, there is the hidden cost of switching suppliers. A new contact would need to learn my needs, and I would need to learn theirs. After many years with Selbrun, that cost is high, and it is one reason I keep the relationship in good order.

## Background

Selbrun Lendkrand is a supplier contact in the ceramics area. I reach him by phone, and he is available in the evenings. I have known him since 2011.

My need for a ceramics supplier comes from the kind of work I do, which relies on steady access to finished pieces of reliable quality. I am not a producer myself in this area, so I depend on someone who understands the craft and can supply what I describe.

When I started out, I did not know much about the differences between clay bodies, glazes, and firing methods. Over the years, through many calls with him, I learned a good deal. He explained things patiently, and that knowledge now helps me describe what I need more precisely.

The nature of the business shapes how we communicate. Ceramic work is done in batches, with long steps that cannot be hurried. A small workshop does not sit by a desk all day. That is why evenings and the phone suit him, and why I adapted my habits to match.

The plan in this note exists to make my dealings with him smoother. It collects the practical routines, the lessons, the risks, and the checklists that I use. It is a personal document, written for my own use, and I update it when something changes.

I also keep in mind that this is a relationship between two people, not only a supply chain. Courtesy, patience, and honesty have done more for our arrangement than any clever negotiation.

## Contracts

The contract date of Selbrun Lendkrand is 2024-08-25.

The contract is the written basis for part of our arrangement. After more than a decade of working together by phone and handshake, it gave us both a clear reference for terms, timing, and expectations. I keep the signed copy with my other paperwork and I refer to it when a question cannot be settled from my notes.

In practice, the contract does not replace the evening calls. We still talk by phone, and we still agree on specific orders in conversation. What the contract does is set the frame within which those orders happen, so I do not have to renegotiate basic points each time.

I review the contract once a year, around the time I do my broader review of the relationship. I check whether the terms still fit how we actually work, whether my needs have changed, and whether anything should be raised with him in a call.

If I want to change something, I raise it in an evening call first, not in writing, since that is how he prefers to talk. If we agree, I then make sure the change is recorded properly, and I add a note in the notebook about when and how we agreed it.

I also keep in mind that a contract is only as good as the relationship behind it. I try to honor my side promptly, including paying on time and giving fair notice, so that if a problem comes up, I am in a good position to ask for his flexibility in return.
