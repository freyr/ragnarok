---
type: summary
status: active
project: nipil-repair
area: ceramics
---

# Summary of Nipil repair

## Setup

This note summarizes the Nipil repair project. It is a repair project in the area of ceramics. It started in the spring of 2022, and the lead is the plumber. The goal is simply "repair": bring the Nipil back to a working state without rebuilding it from scratch.

I keep this summary as the one place to check where the project stands. The longer working notes hold the details, but this page tells me the stage, what is finished, what is still open, and what I should do next.

The working setup is plain. The piece sits on a sturdy bench in the workshop, with a drip tray under it and a basin of clean water close by. I keep a small tray for fittings so nothing gets lost between sessions. The plumber handles anything that involves pipe, seals or flow. I handle the ceramic side: cleaning, checking the glaze, and judging whether a crack is cosmetic or structural.

Tools in use are ordinary ones: a soft brush, a sponge, masking tape, a flexible scraper, a set of spanners, and a clamp set for holding parts while adhesive cures. Nothing special has been bought for this job apart from consumables.

## Safety

Ceramic breaks into sharp pieces, so gloves and eye protection stay on whenever a part is being moved, clamped or loosened. A chipped edge can cut deeply and the cut is easy to miss until later.

Water and workshop floors do not mix well. The drip tray is emptied before it fills, and any spill is wiped at once. The bench is kept clear of loose cloth and cords.

Adhesives and sealants are used with the window open and the lid back on between uses. I do not eat or drink at the bench. Old sealant is removed with the scraper, not with a blade pointed toward my hand.

Before any joint is opened, the supply is shut off and the line is allowed to drain. The plumber confirms this, not me. If a part will not move with moderate force, we stop and rethink instead of leaning harder, because forcing a fitting is the quickest way to crack the body of the piece.

Heavy lifting is done by two people. The piece is heavier than it looks, and a dropped ceramic part is both a hazard and the end of the repair.

## Costs

I have kept the costs loose and practical rather than itemized to the last coin. The spending falls into three groups.

First, consumables: adhesive, sealant, tape, cleaning supplies and a few replacement washers. These are cheap and I buy them as needed.

Second, replacement fittings. These are the largest share of the spending, since the old ones were worn and not worth saving. I chose to replace instead of patching, because a failed fitting later would mean opening everything again.

Third, the plumber's time. Because the plumber leads the project, this is the main cost overall. I agreed to pay for focused visits instead of an open-ended arrangement, so each visit has a defined task.

I am not recording exact figures here. If the total starts to matter, I will collect the receipts and write a separate cost note. For now the rule is simple: spend on parts that affect water tightness, and save money on cosmetic work.

## History

The project began in the spring of 2022. The first stage was inspection: the plumber looked over the working parts, and I looked over the ceramic body. We found wear in the fittings and a few surface problems in the glaze, with one crack that needed a closer look.

After the inspection, the project went quiet for a long stretch. Other work took priority, and the Nipil stayed on the bench, covered and out of use. During that time I kept a short list of what had been learned so the knowledge would not fade.

Work picked up again once I had settled what the repair should include. We cleaned the piece thoroughly, removed old sealant, and checked each connection. The crack was tested and judged to be limited, not a sign of a failing body. That judgment was important, because it meant a repair was reasonable instead of a replacement.

Since then, progress has been steady but slow. Parts were sourced, the fittings were prepared, and the plan was reviewed with the plumber. The project now sits in the middle: the diagnosis is done, the decision is made, and the remaining work is putting things back together and testing them.

## Decisions

The main decision was whether to repair the Nipil or replace it. I chose to repair, for three reasons. The ceramic body is sound apart from a limited crack. The fittings are the real problem, and they can be replaced. And the piece has value to me that a new one would not carry.

The go decision date of Nipil repair is 2024-11-09. That is the day I committed to the repair and told the plumber to proceed. Before that date the work was exploratory; after it, the work was a real project with a defined goal.

Other decisions that follow from it:

- The plumber leads. I defer to the plumber on anything involving water, pressure or seals.
- Fittings are replaced, not reused, when they show wear.
- The crack is repaired and watched, not hidden. If it spreads during testing, the repair is reopened.
- Cosmetic glaze work comes last and is optional. It will not hold up the functional repair.
- Testing happens in stages: first dry fit, then a low-flow test, then normal use.

I wrote these down so I do not have to reargue them every time a difficulty appears.

## Next action

The next action of Nipil repair is NX-8323.

I keep this as a single concrete step so the project always has an obvious way forward. When it is done, I will replace it here with the following step and note the change in the history.

Before starting, I will make sure the bench is clear, the drip tray is empty, the gloves and eye protection are at hand, and the plumber is available for a quick check if something unexpected appears.

## Problems

Several open points remain.

The crack is the main concern. It looks limited, but cracks in ceramic can behave unpredictably under load or temperature change. I will watch it through every test stage and photograph it before and after, so I can compare.

Parts availability has been uneven. Some fittings were easy to find, and others took a long time. A delay in one part can stall the whole reassembly, so I try to confirm everything is on hand before opening anything.

Scheduling with the plumber is another friction point. Because the plumber leads, progress depends on shared free time. I have tried to batch tasks into fewer, longer visits.

There is also some uncertainty about the old sealant residue. In places it bonded firmly to the glaze, and removing it risks scratching the surface. I am taking this slowly, and I accept a slightly imperfect finish over a damaged one.

Finally, I have not decided how much cosmetic glaze work to do. It is optional and can wait.

## Background

The Nipil is a ceramic piece with working parts attached, which is why the project needs both a plumber and some ceramic care. The mix of materials makes repair trickier than it looks: the hard body tolerates little stress, while the fittings need to be tightened firmly to seal.

The project is classed as a repair, not a restoration. The aim is function first. If it works reliably and looks acceptable, that is a success, even if it is not flawless.

I chose the spring of 2022 as the start because that was when the problem became too obvious to ignore. Since then the project has run in fits and starts, which is normal for my personal projects. Keeping this summary current is how I avoid losing the thread.

What I have learned along the way applies beyond this job. Ceramic should be supported evenly when clamped. Old sealant should be softened before scraping. Fittings should be tightened gradually and in turn. And a stage-by-stage test is much safer than a single full-power trial.

## Observations

A few things I have noticed that are worth keeping.

Patience pays off. Every time I tried to hurry a step, I created more work. The slow cleaning stage, which felt tedious, made later steps easier because I could see exactly what I was dealing with.

Dividing the roles between the plumber and me works well. Each of us has a clear area, and disagreements are rare. When they do come up, the rule that the plumber decides on water matters settles them quickly.

Writing down decisions saves effort. The go decision, the choice to replace fittings and the plan for staged testing all came back to help when a problem appeared and I was tempted to change course.

Current stage in one line: the diagnosis is complete, the decision is made, the parts are mostly ready, and the work is in the reassembly and testing phase.

What is done: inspection, cleaning, sealant removal, crack assessment, the go decision and most parts sourcing.

What is open: final reassembly, staged testing, watching the crack, and the optional glaze finish.

What happens next: the step recorded in the next action section above, then an update to this note.
