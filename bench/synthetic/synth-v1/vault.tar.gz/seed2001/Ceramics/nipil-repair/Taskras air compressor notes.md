---
type: note
status: active
project: nipil-repair
area: ceramics
description: "Note about Taskras air compressor."
---

# Taskras air compressor notes

## Overview

The Taskras air compressor is a yellow air compressor that sits in the yard. It runs on mains power and was installed in 2018. I use it for the ceramics work: blowing dust out of molds, cleaning bisque pieces before glazing, and driving the small spray gun when I do thin coats of glaze. This note is my working record of how it behaves, what I have set up around it, and what I still want to find out.

Quick facts, so I do not have to hunt for them later:

| Property | Value |
| --- | --- |
| Kind | air compressor |
| Area | ceramics |
| Color | yellow |
| Energy source | mains |
| Year installed | 2018 |
| Location | yard |

The yard location is both good and bad. It keeps the noise and the dust away from the studio, and the pieces stay clean inside. But it means the machine lives outdoors, with weather, temperature swings and damp air, and every long hose run is my own responsibility.

I do not have a manual that I trust, so most of what is written here comes from my own observation. Where I link to other notes, it is because the same problem showed up there first or because the measuring method was borrowed from them.

## Open questions

- Why does the compressor take longer to refill on cold mornings than in the afternoon? I suspect the cold oil or the cold air intake, but I have no proof. The notes in [[Vanstol heat exchanger study]] may help, since that was about moving heat around and I may be able to reuse the same logic.
- Is the moisture I find in the tank a normal amount for a yard-sited machine, or is the drain being left shut too long?
- Does the flow rate change noticeably over a full day of use, or is it steady? I have one good measurement and need more.
- How much of the vibration is the compressor and how much is the table it stands on?
- Would a longer hose cause a visible pressure drop at the spray gun? I have not compared lengths properly.
- Is the mains socket in the yard shared with something that causes a voltage dip when the compressor starts? [[Brugar data logger log]] has the logger I would use to check this, but I have not set it up for the purpose yet.
- What is the right service interval for a machine that was installed in 2018 and has been outside since? I do not want to guess.

## Risks

- **Weather.** The compressor is in the yard. Rain, frost and direct summer sun all affect it. The yellow paint has held up so far, but the connectors and the cable are the weak points.
- **Moisture in the air line.** Water carried into the line ends up on the bisque or in the glaze spray. A wet burst on a finished surface can ruin a piece, so I treat this as the main quality risk for my ceramics work.
- **Dust and clay particles.** Blowing clay dust around is bad for the lungs and bad for the machine's intake if it stands too near the work.
- **Electrical load.** It runs on mains. A damaged outdoor cable or a poor extension lead is a fire and shock risk.
- **Noise.** Long sessions are tiring and the neighbours can hear it. I keep sessions short and avoid early hours.
- **Neglected maintenance.** Since it is out of sight, it is easy to forget the drain and the filter check. I have noted this several times for myself and still forget.

## History

The compressor was installed in 2018, in the yard, on a firm base near the wall. It was chosen because I needed steady air for cleaning molds and had grown tired of using hand bellows and canned air. The yellow body is the main reason I can find it quickly when it is covered in dust or tarp.

In the early years I used it only occasionally. Over time it became part of the normal routine: dust off, spray, clean, repeat. A few events worth remembering:

- The first winter showed me that the yard location needed a cover and a better cable route.
- A hose fitting was replaced after it began to leak slowly. I did not write down exactly when.
- I started keeping notes on the machine after a long run of inconsistent spray results, which turned out to be mostly a moisture problem.

Related older notes from other projects that touched this machine or similar tools: [[Baerkpend Drormaeth notes]] and the later [[Baerkpend Drormaeth notes 2022]]. The first covers the earlier layout of the yard, the second covers changes made after that. I also checked [[Sesdiortes workshop log]] for hints about where I used to keep compressed-air tools in the workshop.

## Setup

The compressor stands on a flat slab in the yard, off the ground by a few centimetres on a wooden board to keep the feet dry. A tarp covers it when it is not in use, but I leave the sides open so air can move and condensation does not collect.

Power comes from a mains outlet via a short outdoor-rated lead. I try never to use a long extension, because the voltage drop makes the motor work harder on start-up.

From the machine, a hose runs through a small water trap and a filter before it reaches the studio door. I use quick-release fittings so that I can swap between the blow gun and the spray gun without losing much pressure.

My routine before each session:

1. Check the cable and plug for damage.
2. Open the drain valve for a moment to release any water.
3. Close it, switch on, and let the tank fill.
4. Check the filter bowl for water.
5. Connect the tool and test on a scrap piece.

My routine after each session:

1. Switch off and unplug.
2. Release the pressure in the tank and the line.
3. Open the drain and leave it open until it stops hissing.
4. Cover the machine.

The [[Fulmasvork workshop tests]] note has a few comparisons of tools I tried in the studio that fed from this line, and I rely on it when I decide which nozzle to use.

## Measurements

I do not have a precise lab setup. These are practical measurements made with simple tools, repeated a few times where possible.

The main figure I trust is the flow rate of Taskras air compressor: 1336.89 l/h. I measured it by timing how long the machine took to fill a known volume at a steady output. This is the number I use when I plan how long a spray session can run before the tank needs to catch up.

Other things I tracked in a rough way:

- **Refill time**: noticeably longer in cold weather than in warm weather. I did not record exact figures, only the pattern.
- **Pressure drop at the gun**: visible when the hose is long or coiled tightly. A straight, short hose behaves better.
- **Run time before restart**: depends on the tool. The blow gun drains the tank much faster than the spray gun.
- **Noise**: loud enough to need ear protection for sessions longer than a few minutes.

For more systematic logging I plan to use the approach from [[Brugar data logger log]], which describes how I recorded readings over a full day with a small logger. A similar idea appears in [[Fithkrir radio receiver study]], where I learned to keep the logging interval consistent so the data could be compared across days.

## Safety

- Always release the tank pressure before opening any fitting. Compressed air in a tank is stored energy.
- Wear eye protection when blowing out molds. Dried clay chips fly fast.
- Wear a dust mask when cleaning bisque or plaster molds. The fine dust is a lung hazard.
- Wear ear protection for anything longer than a short burst.
- Never aim the air gun at skin or at another person.
- Keep the plug and socket dry. In wet weather I only run the machine if the socket is under cover.
- Keep the area around the compressor clear. Do not stack boxes against it, since the motor needs airflow.
- Do not leave the machine plugged in unattended overnight.
- If the machine makes an unusual noise or smells hot, switch it off and leave it until it has cooled.

If I ever have an electrician or a technician look at the machine, I should tell them it is installed outdoors and runs on mains power, because that changes what they should check. I have noted [[Riorraen Saethkion]] as someone to ask about this, since that contact knows the yard wiring.

## Ideas

- Build a small ventilated housing with a roof, so the compressor is protected from rain but still gets airflow.
- Add a second water trap closer to the spray gun, because the first one is far from where I actually work.
- Mount the compressor on rubber feet to cut vibration and noise.
- Use the logger to record the mains voltage when the motor starts, to check if the outlet is adequate.
- Make a laminated checklist for the before and after routines and hang it beside the door.
- Test a coiled hose against a straight hose and write down the difference at the gun.
- Look at whether waste heat from the compressor could be used to warm the air near the drying shelf. This would need ideas from [[Vanstol heat exchanger study]], and I would have to be careful about dust.
- Paint a clear mark on the drain valve so I remember to open it. The yellow body is easy to spot, but the valve is not.
- Keep a short monthly log of refill time, so I can see if the machine is slowing down with age.
