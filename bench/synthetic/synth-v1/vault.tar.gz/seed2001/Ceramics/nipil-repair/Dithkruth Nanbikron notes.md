---
type: note
status: active
project: nipil-repair
area: ceramics
---

# Dithkruth Nanbikron notes

## Maintenance

Dithkruth Nanbikron is a carpenter I know through ceramics work. I have known him since 2025. He is reachable by phone, and evenings are the time he is available. I keep this note to track how I look after the relationship and the practical details around working with him.

Things I do to keep the contact in good shape:

- Call in the evening, never during the day. Daytime calls usually go unanswered because he is on a job.
- Keep a short list of what I want to ask before I dial, so the call stays brief and he does not feel pulled into a long chat.
- After each call, write down what was agreed: what he will build, what I will supply, and when we will talk again.
- Check in every so often even when I need nothing. A short call to ask how his work is going keeps the contact warm.
- Return anything I borrow, such as clamps or a straightedge, clean and quickly.

Maintenance of the working arrangement itself is mostly about clarity. I write measurements down twice. I describe the object in plain words and also draw a rough sketch. When I send a sketch, I note which side is the front, because that has caused confusion before.

## Ideas

Several projects could use a carpenter who understands ceramics:

- A drying rack for pots with shallow slotted shelves so air moves freely around each piece. Ware dries unevenly if it sits on solid boards.
- A set of ware boards cut to fit the kiln shelf sizes, made from a wood that will not warp easily.
- A wedging table with a sturdy top and a lower shelf for clay bags. The height needs to suit my back.
- A glaze bucket stand with a lid and a handle so I can move buckets without spilling.
- A carrying crate with dividers for taking finished pieces to a market or to friends.
- A turning stand for trimming bowls, with a simple clamp for holding the wheel head steady.
- A display shelf for the finished work at home, in a light wood that does not compete with the glazes.

I would like to ask him which of these he finds interesting. A carpenter will often have a better idea of the joinery than I do, so I should describe the purpose and let him suggest the method.

## Lessons

What I have learned so far:

- Evenings are the right time. Anything urgent in the daytime will sit unanswered.
- Say what the piece is for. If he knows it will hold wet clay or heavy buckets, he picks different wood and joints.
- Wood and water do not mix well. Anything near the studio sink needs a proper finish, and I should ask what he recommends.
- Dust is a problem in a ceramics space, so smooth surfaces that are easy to wipe are better than rough ones.
- Agree on the dimensions in writing. A verbal figure over the phone is easy to mishear.
- Do not rush him. Good work takes the time it takes, and pushing only makes the next conversation awkward.
- Ask early whether he wants me to supply materials or whether he will source them.

## Schedule

There is no fixed calendar with Dithkruth. The pattern is simple:

- Calls happen in the evening, by phone.
- For a new request, I make the first call, describe the idea, and ask when he could look at it.
- I then wait a few days before a follow-up, so he has time to think and to fit it around his other work.
- When a piece is in progress, I check in about once a week, in the evening, unless he tells me otherwise.
- Pickup or delivery is arranged by phone at the end, again in the evening, and I make sure I am home.

I should avoid planning anything that depends on him being free on a weekday morning or afternoon. If something has a deadline, such as a market date, I must raise it at the very first call and not partway through the job.

## Setup

The practical setup for working with him is light.

- Contact method: phone. I have the number saved in my phone under his full name.
- Availability: evenings.
- Role: carpenter.
- Area: ceramics.
- Known since: 2025.

For each job, I prepare a small bundle of information before the call: the sketch, the measurements, the purpose of the piece, the place where it will stand, and my budget limit. I keep the bundle in a folder with the note for that job. After the call, I add what he said about wood, timing, and cost.

In the studio I keep a clear space where a delivered piece can be set down and checked straight away. I check it for level and for fit against the kiln shelf or the table where it is meant to go.

## Contracts

The contract date of Dithkruth Nanbikron is 2022-08-09.

I keep agreements simple and written. For each job, I note the following in my own records:

- What is being built, described in plain words.
- The agreed measurements.
- Who supplies the materials.
- The price, as agreed on the phone and then confirmed in a message.
- The rough time frame.

If anything changes during the work, I write the change down and send it to him so we both have the same version. I do not rely on memory alone. He seems comfortable with this, and it prevents small disagreements.

## Open questions

- Which of the project ideas is he most interested in building first?
- Does he prefer to buy the wood himself, or would he rather I bring it?
- What finish does he recommend for wood that will be near water and clay slip?
- Would he be willing to visit the studio to see the space before building anything large?
- Is there a time of year when he is busier, so I can plan around it?
- Does he know other makers in ceramics who need similar work done, and would he be happy to be introduced?
- How does he prefer to be paid: on delivery, or in parts?

## Background

Dithkruth Nanbikron is a carpenter. I first came to know him in 2025, and our contact has been tied to ceramics since then. My interest is in equipment and furniture for a ceramics workspace, and his skills as a woodworker fill a gap that I cannot fill myself.

He is best reached by phone, and evenings suit him. That tells me he probably spends his days on site or in his workshop and keeps the later hours for calls. I respect that.

What I value most in working with him is that he is practical. He asks what a piece must do before he decides how it should look. For ceramics equipment, that is the right order. A rack, a table, or a crate has to serve the work first, and appearance comes after.

I want to keep this relationship friendly and fair. I pay what we agree, I keep my requests clear, and I try not to take up his time without a reason. If the first few projects go well, I would like him to be the person I turn to for anything wooden in the studio. This note is where I gather what I learn, so each new job starts a little better than the last.
