---
type: drivers
status: active
project: nipil-repair
area: ceramics
description: "Drivers about Nipil repair."
---

# Drivers of Nipil repair

## Background

Nipil repair is a project I started in spring 2022. The goal is repair, the area is ceramics, and the lead is the plumber. I keep this note as the drivers note: it records why the project exists, what limits it, what money is set aside, and how I will know it worked.

The name Nipil comes from the object at the center of the work, a large glazed ceramic basin and the pipework attached to it. The basin had been in use for years before the trouble started. It cracked along the base, and the joint where the outlet pipe meets the ceramic began to weep. At first it was only a damp patch under the basin. By the time I wrote the first plan it had stained the wall and lifted the paint in a band about a hand wide.

I chose to repair rather than replace for three reasons. First, the basin is a good piece and replacing it with something similar would cost more than fixing it. Second, the glaze is hard to match, and a new basin would not sit well with the tiles around it. Third, I wanted to learn how ceramic repair actually works, because I have more cracked pieces in the house.

The plumber leads because the water side is the part that can go badly wrong. A hairline crack in a bowl is a nuisance. A failing outlet joint is a flood. So the plumber sets the order of work, decides when the water can be turned back on, and signs off on the final test. I handle the ceramic work under that plan.

The drivers in this note fall into four groups:

- **Goal**: a basin that holds water and drains without weeping, and still looks like the original.
- **Constraints**: the repair must be done in the spring season, the house must keep a working water supply elsewhere, and the basin cannot be removed from the wall if it can be avoided.
- **Budget**: a fixed amount, set out in its own section below.
- **Success measures**: dry checks over time, visual checks of the finish, and the plumber's pressure and drain tests.

## Problems

The problems fall into two kinds: the ones I knew about at the start and the ones that appeared once the work began.

Known at the start:

- A crack running along the base of the basin, visible from underneath and faintly on the inside surface.
- A weeping joint at the outlet, where the pipe meets the ceramic.
- Water damage on the wall behind and beside the basin.
- A glaze with a slightly warm white tone that is hard to match with off-the-shelf products.

Found during the work:

- The old sealant around the outlet was not one layer but three, applied by different people at different times. Removing it took far longer than planned.
- The wall fixings that hold the basin were corroded. They still held, but I could not trust them to carry the basin through a repair that involves pressing, clamping and curing.
- The crack was longer than it looked. Once the dirt was cleaned out, it ran further toward the back edge.
- The shut-off valve nearby turned stiffly and did not close fully. That made isolating the basin harder than expected.

The main problem is the interaction between the two sides. A ceramic repair needs the piece to stay still and dry while the adhesive cures. A plumbing repair needs the water to be tested under load. Doing both at once means each one slows the other. The plan has to separate them clearly, and a lot of the drivers below come from that.

## Overview

Nipil repair is a repair project in the area of ceramics. It started in 2022, in spring, and the plumber is the lead. The aim is to bring the basin back to a sound and watertight state without replacing it.

The plan, in order:

1. Isolate the water and drain the pipework.
2. Support the basin so its weight does not rest on the damaged base.
3. Clean out the crack and remove the old sealant at the outlet.
4. Stabilize the crack, then fill and bond it with a ceramic-safe adhesive.
5. Rebuild the outlet joint with new seals and sealant.
6. Retouch the glaze to blend the repair.
7. Cure, then test with water in stages.
8. Refit the fixings and check the wall.

What counts as success:

| Measure | What I check | Pass condition |
|---|---|---|
| Watertightness | Fill the basin and leave it | No new damp under the basin after a full day |
| Drainage | Run water through the outlet | Drains freely, no weeping at the joint |
| Structure | Press gently along the repaired base | No movement, no sound of grinding |
| Appearance | View in daylight from standing height | Repair is hard to see at normal distance |
| Durability | Check again after a few weeks | Still dry, no new hairlines |
| Sign-off | Plumber's pressure and drain tests | Plumber confirms the work |

The plumber's sign-off is the one measure I cannot give myself. The other five I can check on my own, but I write down the result each time so I do not rely on memory.

## Lessons

Some of these come from earlier small repairs, and some from this project.

- Dry-fit everything first. Twice I have started gluing before I had checked that the clamps reached. It never goes well.
- Old sealant is almost never what the label says. Plan for scraping, solvent and patience.
- Cure time on the packet is a minimum for a warm, dry room. In a cold spring room I should assume longer.
- Do not trust old fixings. Replace them while the basin is already apart in effect.
- Photograph the crack before cleaning, after cleaning and after filling. The pictures show whether it is growing.
- Leave the water test to the plumber's schedule. When I tested early out of impatience, I only found out how much I did not know.
- Write the success checks before the work, not after. It is too easy to define success as whatever happened.

One lesson is about roles. Having the plumber lead was the right call. The few times I made a water-side decision on my own, the plumber changed it. Each time the change was an improvement.

## Costs

I split the costs into groups so I can see where the money goes and where it can be saved.

- **Materials**: ceramic adhesive, filler, glaze touch-up kit, sealant, replacement seals, new fixings and cleaning supplies.
- **Labor**: the plumber's time for isolation, the outlet joint, and the final tests. My own time is not charged.
- **Support equipment**: clamps, props and padding to hold the basin while it cures.
- **Wall repair**: filler, primer and paint for the damaged band behind the basin.
- **Contingency**: a reserve for things I did not see coming, such as a failed valve.

The biggest single cost is the plumber's time, and I accept that, because the water side is the highest-risk part. The second biggest is the glaze work, since a good match needs more than one product and some trial pieces.

Savings I have made so far: I reused clamps and props I already owned, and I did the wall preparation myself. I will not try to save on the seals or the sealant. A cheap seal is the likeliest cause of a repeat failure.

Costs I have to watch: any extra plumber visits, a replacement shut-off valve if the stiff one cannot be freed, and a second round of glaze retouching if the first does not blend.

## Budget

The budget of Nipil repair is 6820.59 EUR.

This is a fixed ceiling. I treat it as the total for materials, plumber's labor, support equipment, wall repair and contingency together. If a decision would take the project past it, I stop and reconsider before spending.

Rules I follow with the budget:

- Spend on the water side first, since that is where failure is most costly.
- Keep the contingency untouched until something actually goes wrong.
- Record every purchase the day I make it.
- Review the running total at each major step, not only at the end.

## Observations

These are things I noticed that shape the drivers, even though I did not plan to look for them.

The damp patch got worse after heavy use of the basin and eased after a few days of rest. That suggests the weeping is tied to water load and not to a steady leak from the supply. The plumber agreed.

The crack seems to follow the line where the base was thickest, so the stress likely built up where the wall fixings pulled unevenly. This is another reason to replace the fixings.

The glaze is not pure white. In daylight it leans warm, and under artificial light it looks cooler. A match that looks right in one light may look wrong in another, so I check in both.

The wall behind the basin was damper than the surface suggested. I have to let it dry before closing anything up, or the damp will return, and I will wrongly blame the repair.

Spring is a good season for this. The room is cool enough that the adhesive does not set too fast, and the weather is mild enough to leave a window open for ventilation.

## Tools

The tools I need are mostly ordinary, with a few specialist items.

- Clamps and padded props to hold the ceramic still while it cures.
- Plastic scrapers and a small blade for old sealant.
- A solvent suitable for sealant removal.
- Fine brushes and sponges for filler and glaze touch-up.
- A mixing board and spreaders for the adhesive.
- A moisture meter for the wall.
- A torch and an inspection mirror for looking under the basin.
- The plumber's wrenches, a pressure test kit and a drain test setup.
- A camera for progress photos.
- A notebook, for the dry checks and results.

Anything that touches the ceramic is soft or plastic. Metal tools stay away from the glaze unless the plumber needs them at the pipe.

## Safety

Most of the hazards are common but easy to forget.

- Turn off and confirm the water before touching the outlet. Check by opening a tap downstream, not by trusting the valve.
- Because the nearby shut-off valve does not close fully, the plumber isolates at a point further back.
- Wear gloves and eye protection when working with adhesive, solvent and anything that can chip.
- Ventilate the room while solvents and adhesives are in use, and keep the window open during curing.
- Never let the basin's weight rest on the cracked base while it is unsupported. A sudden break could cause cuts.
- Keep electrical items away from the wet area. Any socket near the basin stays off while the work is under way.
- Lift carefully. The basin is heavy, and a second person helps with any movement.

If anything unexpected happens, such as a sudden drip or a loud crack, I stop and call the plumber before continuing.

## Risks

| Risk | Likelihood | Effect | Response |
|---|---|---|---|
| Crack grows during the work | Medium | Basin might need replacing | Stabilize early, support the base, photograph often |
| Outlet joint fails the test | Medium | Extra plumber visit | Rebuild with new seals, test in stages |
| Glaze does not match | High | Visible repair | Test on a spare piece, check in two lights |
| Corroded fixings fail | Low | Basin could shift | Replace them before the cure |
| Damp returns in wall | Medium | Wrongly blamed on the repair | Dry the wall fully and measure it |
| Budget overrun | Low | Work stops | Keep contingency, review at each step |
| Cold room slows the cure | Medium | Delay | Allow extra time, do not rush the tests |

The risk I take most seriously is the crack growing. Everything else can be fixed with time or money. A basin that breaks cannot be repaired.

## Maintenance

Once the repair is signed off, the basin needs light and regular attention.

- Check under the basin for damp once a week for the first month, then once a month.
- Look at the repaired line in daylight every few months for new hairlines.
- Do not use harsh abrasive cleaners on the repaired area. They wear the retouched glaze faster than the original.
- Avoid pouring very hot water into the basin right after a cold spell, because a sudden change in temperature is hard on ceramic.
- Do not lean on the basin or use it as a step.
- Re-check the wall fixings once a year.
- Replace the outlet seals when the plumber next visits for any other reason.

I record each check in the notebook with a short note, even when nothing has changed. A clean record is what lets me say the repair worked.

## Ideas

Some ideas I am considering, none of them committed to.

- Fit a small drip tray or a leak sensor under the basin, so a future failure is caught early.
- Replace the stiff shut-off valve with a better one, since it caused trouble during isolation.
- Put in a service hatch or access point so the outlet joint is easier to reach.
- Make a small kit of matched glaze touch-up for future chips.
- Write a short repair guide from this project, for the other cracked pieces in the house.
- Add a soft mat or liner in the basin to reduce knocks from heavy items.
- Ask the plumber to note the pipe layout so the next job starts faster.

## History

The project began in spring 2022. The first stage was observation: I noticed damp under the basin, then traced it to the outlet joint and the base crack.

The next stage was planning. I decided to repair rather than replace and asked the plumber to lead. We agreed the order of work and wrote this drivers note to fix the goal, the constraints, the budget and the success measures before any work started.

After that came the early work: isolating the water, removing the old sealant, and discovering the extra layers and the corroded fixings. These findings changed the plan. The fixings moved from optional to required, and the valve problem moved isolation further back along the pipe.

The project has run on a slower schedule than I first hoped, mostly because of cure times and the need to dry the wall. I accept that, since a rushed repair would defeat the purpose.

## Setup

The working setup is simple and I keep it the same each session.

- The area under and around the basin is cleared and covered with dust sheets.
- The water is isolated by the plumber and confirmed off.
- The basin is supported with padded props so the base carries no load.
- A work table nearby holds the adhesive, filler, glaze kit and tools in the order I use them.
- The camera and notebook sit on a shelf out of the splash zone.
- A window stays open for ventilation, and the room is kept as steady in temperature as I can manage.
- Lighting is a portable lamp for close work, with daylight for judging the finish.

Before I start each session I read the last entry in the notebook, so I know what state the repair is in. At the end I clean up, photograph the work, and write down what was done and what comes next.
