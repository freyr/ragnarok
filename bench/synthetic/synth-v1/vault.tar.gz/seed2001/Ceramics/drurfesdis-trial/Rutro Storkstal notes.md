---
type: note
status: active
project: drurfesdis-trial
area: ceramics
---

# Rutro Storkstal notes

## References

Rutro Storkstal is my supplier contact for ceramics. I have known him since 2010, which makes him one of the longest-running contacts in my notes. He prefers email, and he answers in the evenings, so I write to him during the day and expect a reply after work hours.

Where he shows up in my other notes:

- [[Birkpioth pond notes]]: the ceramic liner and edging pieces I priced for the pond came through him.
- [[Riorraen Saethkion]]: she introduced me to him a long time ago, and she still checks his glazes when I am unsure.
- [[Fudralvend Sirmeller tests]]: the sample tiles from these tests were his stock.
- [[Tangio circulation pump study]]: he supplied the ceramic bearing parts I compared during the study.
- [[Sasvaeth workshop tests]]: I used his fired test pieces for the heat and frost runs.
- [[Niosdan greenhouse]]: floor tiles and planters for the greenhouse were discussed with him.
- [[Braessios heat exchanger]]: I asked him about ceramic plates and what they can take.
- [[Zukriond loft notes]]: wall tiles for the loft were first raised with him.

## Lessons

Fifteen years of dealing with one supplier has taught me a few things, and I want them written down so I do not relearn them.

- Email suits him. A phone call during the day goes nowhere, and he does not like being pushed. A clear email with sizes, quantities and the use of the pieces gets a full answer.
- Evenings are his time. If I send a message in the morning, I should not chase it before the next evening. Chasing early has never made anything faster.
- Say what the piece is for. When I explain that something will sit outdoors in frost, or near heat, he suggests a different clay or firing. When I only give dimensions, I get exactly what I asked for, which is not always what I need.
- Ask for a few test pieces first. The pond, the workshop and the greenhouse all went better because I tested before I ordered the full amount.
- Keep his replies. He often explains in one line why a glaze behaves badly in certain conditions, and that line is worth more than the price list. I copy the useful ones into the project notes.
- Do not squeeze him on price at the last moment. He is fair at the start, and when I tried to renegotiate late, the answer was cooler and slower for weeks.
- Confirm delivery in writing. He is reliable, but the pieces are fragile, and a short email about packing saves arguments later.
- Cross-check against my other work. The results in [[Sasvaeth workshop tests]] and [[Fudralvend Sirmeller tests]] showed me which of his batches I can trust for harder conditions, and I should compare any new batch against those before using it anywhere important.

## Quotes

This section holds the figures and the words I want to keep from him.

The latest quoted price of Rutro Storkstal is 7464.24 EUR. I treat it as a starting point and not a final number, since earlier quotes shifted once I told him what the pieces would be used for. Before I accept it, I want to confirm what the quote includes: the pieces, the packing and the delivery.

Things he has said that I want to remember, written from memory and not word for word:

- A glaze that looks perfect on the sample can still craze outdoors, so test it in the weather first.
- Thick pieces take longer to dry and fire, and rushing that step is where most cracks come from.
- Tell him the working temperature early, because that changes the clay he picks.

When I compare the quote with past work, I look at the pond and the greenhouse, because those had the closest quantities. The pond project in [[Birkpioth pond notes]] is the cleanest comparison, as the list of pieces was short and I kept good records.

## Schedule

My contact rhythm with him is simple, and it follows his availability in the evenings.

- Send any new request by email during the day, with sizes, quantities and the intended use.
- Expect a reply in the evening, usually the same day or the next one.
- If nothing comes after two evenings, send one short reminder, and nothing more.
- Ask for test pieces before any large order, and allow time for firing and drying before I plan any installation.
- Confirm the packing and delivery arrangement by email once the order is agreed.

Open items to schedule next:

- Decide whether to accept the quote above, after checking what it covers.
- Write to him about ceramic plate limits for [[Braessios heat exchanger]], including the temperature range.
- Ask about wall tile options for [[Zukriond loft notes]] and compare them with the floor tile discussion for [[Niosdan greenhouse]].
- Ask whether the bearing parts for the [[Tangio circulation pump study]] are still made the same way, since I may want more.
- Send [[Riorraen Saethkion]] a short update, since she likes to hear how the supplier relationship is going and has helped with glaze questions before.

I will review this note once a year, around the anniversary of when we first started working together, and update the lessons if anything changes.
