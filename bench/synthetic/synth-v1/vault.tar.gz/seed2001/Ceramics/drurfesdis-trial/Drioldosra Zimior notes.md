---
type: note
status: active
project: drurfesdis-trial
area: ceramics
description: "Note about Drioldosra Zimior."
---

# Drioldosra Zimior notes

## Overview

Drioldosra Zimior is a carpenter whose work overlaps with ceramics. I have known them since 2020. I contact them in person, and they are available on weekdays.

| Property | Value |
|---|---|
| Role | carpenter |
| Area | ceramics |
| Contact | in person |
| Availability | weekdays |
| Known since | 2020 |

Related notes:

- [[Rutro Storkstal notes]] for earlier material work
- [[Sandbris yard study]] for the yard layout questions
- [[Taskras air compressor notes]] for workshop tools

## Quotes

- Quoted price of Drioldosra Zimior: 5801.17 EUR

I should ask in person on a weekday if I want the quote confirmed or changed. I will compare it with the other notes before I decide.
