---
type: summary
status: active
project: drurfesdis-trial
area: ceramics
---

# Summary of Drurfesdis trial

## Risks

The Drurfesdis trial is a ceramics project that started in spring 2019, and it is still a trial, not a finished process. The main risks are listed here so I remember what could go wrong.

- The trial depends on my neighbor, who is the lead. If the neighbor is busy or away, the work stops, because I do not have the kiln routine written down in enough detail.
- Results from one firing may not repeat. I have not yet shown that the glaze and clay behave the same way across several batches.
- Notes from the early spring seasons are thin. Some measurements were kept only in memory, so comparing old and new results is hard.
- Material supply could change. If the clay body changes, earlier results may no longer apply.

## Next action

The next action for the Drurfesdis trial is NX-9845. This is the one step to do before anything else moves forward.

When it is done, I will write down the outcome the same day, while the details are fresh. I will also ask the neighbor to read the notes and correct anything I got wrong. After that I will update this summary, move the open points forward, and check whether any risk above can be removed.

## Decisions

The go decision date for the Drurfesdis trial is 2020-06-24. That was the point when we agreed to continue the trial instead of stopping it.

- Goal: trial, so we keep the scope small and do not plan for production yet.
- Area: ceramics, with all work done in the neighbor's workspace and kiln.
- Lead: neighbor, who makes the practical calls on firing and materials.
- Start: spring 2019, which is the baseline for comparing results.

Open points still to settle: how many repeat firings count as proof, and who keeps the written record. I lean toward keeping the record myself, since I use these notes most. Until those points are settled, the project stays in the trial stage and I will not call it done.
