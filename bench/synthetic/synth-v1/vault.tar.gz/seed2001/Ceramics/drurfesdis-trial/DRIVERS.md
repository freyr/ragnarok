---
type: drivers
status: active
project: drurfesdis-trial
area: ceramics
description: "Drivers about Drurfesdis trial."
---

# Drivers of Drurfesdis trial

## References

- Project: Drurfesdis trial
- Type of note: drivers
- Goal: trial
- Area: ceramics
- Start year: 2019
- Season: spring
- Lead: neighbor

This note covers the drivers of the Drurfesdis trial: what it is for, what limits it, what it costs and how I decide whether it worked. The trial began in spring 2019 and is led by my neighbor. It sits in the ceramics area of my notes. Related material such as firing logs, glaze test tiles and clay batch notes is kept in separate notes and is only summarized here.

## Setup

The goal of the Drurfesdis trial is, as the name of the goal says, a trial. It is not a production run and not a finished line of work. The point is to find out whether the approach holds up in ordinary conditions before anyone commits more time or money to it.

The neighbor leads the project. That matters for how things run. My neighbor decides the order of the work, owns the kiln schedule and has the final word on whether a batch is good enough to count. I help, keep the notes and handle the purchasing records. When there is a disagreement about method, the lead decides, and I write down what was decided and why.

The work started in spring 2019, and the season still shapes it. Spring gives us a workable window: the garage studio is not too cold for drying clay, and it is not yet hot enough to make pieces dry too quickly and crack. Most of the planning assumes we keep to that kind of weather.

Constraints I keep in mind:

- Space is limited to one shared studio, so only a few pieces can dry at once.
- Kiln access depends on the neighbor's availability, so firings cannot be rushed.
- Materials come from a small number of suppliers, which means delays are likely if one of them runs short.
- The trial has to stay small enough that a failed batch does not hurt anyone's finances.
- Everything must be written down as we go, because memory of what we changed between batches is unreliable.

How success is measured: a batch counts as a success if most of the pieces come out of the final firing intact, if the surface finish is consistent across the batch, and if the neighbor would be willing to repeat the same steps without changes. A second measure is whether the notes are good enough for someone else to follow the process. If the steps cannot be repeated from the notes alone, the trial has not really answered its question.

## Lessons

These are the points I have learned that shape the drivers, written plainly so I can reread them before planning the next stage.

- Drying time is the quiet limit on everything. Rushing it costs more pieces than any other mistake.
- Keeping one change per batch is the only way to know what caused a result. Whenever we changed two things, we ended up guessing.
- Labels on the pieces matter. Unlabeled test tiles became useless within a week.
- The lead should confirm the kiln date before any clay is prepared, not after.
- A short written note after each firing is worth more than a long summary at the end of the month.
- Small batches make mistakes cheap, and they make the results easier to compare.

I also learned that the success measures need to be agreed before the first batch, not after seeing the results. When we judged only after the fact, we were tempted to call a mediocre batch good enough. Writing the criteria first removed that problem.

Another lesson concerns communication. My neighbor works from experience and often does not write things down, so I ask short questions at the end of each session and record the answers the same day. That has kept the notes honest and has saved arguments about what was actually done.

## Budget

The budget of Drurfesdis trial: 29170.50 EUR

This figure is the ceiling for the whole trial. It is meant to cover materials, firing costs, tools that need replacing, and a reserve for repeating batches that fail. It is not a target to spend. If the trial answers its question for less, the remainder stays unspent.

How I treat the budget:

- Materials and firing costs are tracked per batch, so I can see which batch cost the most.
- Any purchase beyond what the plan expected needs the lead's agreement before it is made.
- The reserve is used only for repeating a failed batch, not for extending the scope.
- If spending reaches about three quarters of the ceiling and the success measures are not yet met, we stop and decide together whether to continue.

I keep receipts in one folder and update the running total after each purchase, not at the end of the month. That habit keeps surprises small.

## Risks

The main risks follow from the constraints above.

- Cracking during drying, especially if the weather turns warm or windy in spring. Mitigation: slow drying under cover and fewer pieces at once.
- Kiln unavailability, because the neighbor leads the work and the schedule depends on one person. Mitigation: agree on firing dates early and keep a fallback plan.
- Supplier delay or a change in a clay batch, which could make results hard to compare. Mitigation: buy enough of one batch for the whole stage.
- Budget drift from small unplanned purchases. Mitigation: record every purchase and ask the lead before going outside the plan.
- Poor records, which would leave the trial unable to show whether the process can be repeated. Mitigation: write a note after every firing.
- Scope growth, where the trial slowly becomes a production project. Mitigation: return to the stated goal, a trial, whenever new ideas come up.

If two or more of these risks appear at once, I stop and review the drivers with my neighbor before spending anything further.
