---
type: log
status: archived
project: drurfesdis-trial
area: ceramics
description: "Log about Rutro Storkstal."
---

# Rutro Storkstal notes 2018

This is an archived log. It records what I knew about Rutro Storkstal in 2018, and later notes replace these values, for example [[Zukriond loft notes 2020]].

| Property | Value in 2018 |
| --- | --- |
| Name | Rutro Storkstal |
| Role | supplier contact |
| Area | ceramics |
| Contact | email |
| Availability | evenings |
| Known since | 2010 |

## Problems

Rutro is reliable once reached, but reaching him is the main difficulty. He only answers in the evenings, so anything I send during the working day waits until after he finishes his own work. Email is the only contact route I have for him. A phone call has never worked, and I stopped trying.

The problems I logged during 2018:

- Replies come late in the evening, so a question asked in the morning is rarely settled the same day.
- Short questions get short answers. If I leave out a detail, he does not ask for it, and I get a reply to the wrong question.
- Glaze samples arrived twice without a note saying which batch they came from. I had to match them against my own records.
- Packaging was thin on one shipment, and a few tiles chipped at the corners. He replaced them without argument, but it cost me time.

Because of these, I now write every email as if it were the only one he will read that week. I put the full question, the quantity, and the deadline in one message.

## Quotes

The one quote I hold from 2018 is for the full set of tiles planned for the workshop floor. Rutro's quoted price is 7942.25 EUR. He sent it by email, in the evening, as expected, and he did not offer a discount for taking the whole set.

How I read the quote:

- It covers the tiles and the glaze, as far as I understood his message.
- Delivery looked separate, and I never got a firm answer on it.
- He said the price holds only while his current clay supplier stays the same. That is a risk, and I should ask again before ordering.

I compared this against the earlier thinking in [[Gliospaeth Stuntre plan]], where I had budgeted less. The gap is real, so I either trim the order or accept the higher cost. I have not decided. The quote is also part of the reasoning in [[Zorksaeval Giotio plan]], which depends on the same tile supply.

I also tried to judge the quality of his tiles against the grading in [[Diondvaend scale]]. By my own reading, his work sits comfortably in the upper part of that scale, which is why I tolerate the slow replies.

## Maintenance

This section covers keeping the relationship working, not equipment.

- Write to him by email only, and aim to send messages in the afternoon so they are waiting when his evening starts.
- Keep a short running list of open orders, so I do not have to ask him what is outstanding.
- Say thanks when a delivery is right. He does not say much, but he seems to remember who is easy to deal with.
- Review this note once a year. People change jobs and habits, and what I wrote about his evenings may stop being true.
- Check [[Riorraen Saethkion]] before any new request, since it holds the related contact details and earlier agreements.

Since I have known him since 2010, the relationship is old enough that small mistakes are forgiven. I still treat each order carefully, because a long acquaintance does not protect me from a bad batch.

For testing samples, I follow the routine in [[Fulmasvork workshop tests]]. I run the same checks on every new delivery before I accept it. If something fails, I photograph it and send the pictures to Rutro the same evening, so he has them when he reads his email.

## Open questions

These were unresolved when I closed the notes for 2018:

- Does the quoted price of 7942.25 EUR include delivery, or is that charged on top?
- Will his clay supplier change, and if it does, how much would the price move?
- Is there any way to reach him during the day for urgent problems, or is email in the evening the only option?
- Can he label glaze batches on every shipment, so I stop guessing?
- Would he accept a smaller first order to test the packaging before I commit to the full set?
- Should I look for a second ceramics supplier as a backup, given how few ways I have to contact him?

I expect later notes to answer some of these. Where a later note disagrees with anything above, I trust the later note and treat this log as history only.
