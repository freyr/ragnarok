---
type: drivers
status: active
project: lunsurkmo-retrofit
area: ceramics
description: "Drivers about Lunsurkmo retrofit."
---

# Drivers of Lunsurkmo retrofit

## Overview

Lunsurkmo retrofit is a project with the goal of a retrofit. It belongs to the ceramics area and started in 2019, in the summer season. The lead is the accountant, so the project is run with a close eye on cost and records.

The main driver is simple: bring the existing ceramics setup up to date without replacing all of it. Work is planned in stages, so each stage can be checked before the next one begins.

Constraints are the budget, the summer working window, and the need to keep the existing setup usable while the work goes on.

Success is measured in three ways:

- The retrofit is finished within the agreed budget.
- Each stage is completed and checked before moving on.
- The accountant can reconcile all spending against the plan.

## Budget

The budget of Lunsurkmo retrofit is 36022.55 EUR.

This figure is the ceiling for the whole project. The accountant tracks spending against it and flags any stage that runs ahead of plan, so that scope can be adjusted before the limit is reached. Any change to the figure needs a clear written reason in this note.
