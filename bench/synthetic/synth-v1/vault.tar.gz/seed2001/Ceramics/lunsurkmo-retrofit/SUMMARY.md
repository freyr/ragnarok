---
type: summary
status: active
project: lunsurkmo-retrofit
area: ceramics
---

# Summary of Lunsurkmo retrofit

## Lessons

The main lesson so far is that a retrofit in ceramics goes better when the people who count the money are also close to the work. The Lunsurkmo retrofit is led by an accountant, and that has shaped how the project runs. Every choice has to show its cost before it is accepted. That slowed some early talks, but it also stopped a few expensive ideas from getting far.

Other lessons I want to keep:

- Write down the reason for each decision on the day it is made. Memory fades fast, and I have already had to rebuild the reasoning for two choices from scratch.
- Do not mix the goal of the project with wishes that came later. The goal is a retrofit, and when I drifted toward a full rebuild, the scope grew and the plan got blurry.
- Keep the summer season in mind. The project started in summer, and summer work in ceramics depends on heat, drying times and the availability of helpers. Plans made in a cooler month often ignore this.
- Short notes written often are better than long notes written rarely. This summary is easier to keep up because the log behind it is small and regular.
- Ask the lead for a plain statement of open points at each review. An accountant tends to answer such questions in a precise way, which is useful.

I also learned that a retrofit has a different rhythm from a new build. Much of the effort goes into finding out what the existing setup can still do, and only then deciding what to change. I now spend more time at the start of any retrofit on looking, measuring and listing, and less on drawing new plans.

## Background

Lunsurkmo retrofit is a project in the area of ceramics. Its goal is retrofit, which means improving and updating something that already exists instead of replacing it. The project started in 2019, in the summer season. The lead is an accountant.

The idea came from a simple observation: the existing ceramics setup still worked, but it was uneven, costly to run and hard to keep in good order. A full replacement was too expensive and would have meant a long stop in work. A retrofit promised a middle path, where the useful parts stay and the weak parts are changed step by step.

Choosing an accountant as the lead was a deliberate move. The project touches many small costs: materials, repairs, time and the upkeep of equipment. Someone who tracks these naturally keeps the whole picture visible. The lead does not need to be an expert in ceramics, but needs to ask good questions and keep records clean. That has worked out well, though it sometimes means that technical points wait for a specialist to weigh in.

The properties of the project, for reference:

- Name: Lunsurkmo retrofit
- Type: project
- Goal: retrofit
- Area: ceramics
- Start year: 2019
- Season: summer
- Lead: accountant

Since the start in 2019 the project has gone through several phases: a first survey of what exists, a long period of weighing options, a formal go decision, and then the work of carrying out the plan. This note is the current summary of where all that stands.

## Next action

The next action of Lunsurkmo retrofit is NX-1399.

I keep this section short on purpose, so that when I open the note I see at once what to do. The next action should be small enough to start without more planning. When it is finished, I replace it with the one that follows, and I move the finished item into the checklist below as done.

Before starting, I check three things. First, that the materials or information needed are at hand. Second, that the lead has seen the item and agrees it is the right one to do now. Third, that nothing in the open points blocks it. If any of these fails, I fix that first and write down what I found.

## Overview

This is the summary note for the Lunsurkmo retrofit project. It gives the stage of the project, what is already done, the open points and the next action. It is not the full log; it is meant to be read in a minute or two and to tell me where things stand.

**Stage.** The project is past the decision point and in the execution phase. The go decision was made, the scope is fixed as a retrofit, and the work is moving through the planned steps. The main risk now is not whether to proceed but whether the steps stay in order and within budget.

**What is done.**

- The survey of the existing ceramics setup is finished.
- The options were compared and one was chosen.
- The go decision was taken and recorded.
- The lead has set up a simple cost record that is kept up to date.
- The first parts of the work are complete, and what they showed has been written down.

**Open points.**

- Some parts of the existing setup have not been fully tested, so their condition is still partly a guess.
- The order of the remaining steps could change if a hidden problem turns up during the work.
- The budget has a reserve, but I have not yet agreed with the lead how much of it can be used before a new review is needed.
- Helpers for the summer period need to be confirmed early, since their time is limited.
- The final check, meaning how I will decide the retrofit is really finished, is only roughly described.

**Next action.** It is given in its own section above, and it is the first thing to do when I return to the project.

Overall the project is in reasonable shape. It is not fast, but it is steady, and the records are good enough that I can pick it up after a break without losing the thread.

## Decisions

The key decision of the project is the go decision. The go decision date of Lunsurkmo retrofit is 2020-04-07. Before that day the project was in a survey and planning phase, and after it the project moved into carrying out the work.

Reasoning behind the go decision:

- The survey showed that most of the existing setup could be kept, which made a retrofit sensible.
- The cost of a retrofit was clearly lower than the cost of a full replacement.
- The lead was satisfied that the costs could be tracked and controlled.
- There was a workable path to do the job in stages, so that normal work in ceramics would not stop completely.

Other decisions worth remembering:

- **Scope stays a retrofit.** I chose not to expand into a rebuild, even when it looked tempting. Any change in scope needs a new review with the lead.
- **Stage by stage work.** The project is carried out in small steps, each with its own cost note, so that a problem in one step does not spread.
- **One lead.** The accountant is the single lead. Others advise, but one person holds the overall picture and signs off the steps.
- **Reserve in the budget.** A part of the budget is kept aside for surprises, which are likely in any retrofit.

When I make a new decision, I add it here with a short reason. If a decision is reversed, I do not delete it; I add a line saying what changed and why. That way the history stays honest.

## Checklist

This list tracks the main items of the project. I update it whenever something changes.

- [x] Survey of the existing ceramics setup
- [x] Comparison of options
- [x] Choice of the retrofit approach
- [x] Go decision recorded
- [x] Cost record set up by the lead
- [x] First part of the work completed
- [ ] Test of the parts whose condition is unclear
- [ ] Agreement with the lead on use of the budget reserve
- [ ] Confirmation of helpers for the summer period
- [ ] Remaining steps of the work
- [ ] Description of the final check
- [ ] Final check and closing of the project
- [ ] Short review of what went well and what did not

A few notes on how I use this list. Items are written so that each can be judged as done or not done, without arguing. If an item is too large, I split it. If one is no longer needed, I strike it out and write a reason instead of deleting it quietly.

## Schedule

The project began in the summer of 2019, and that season still sets its pattern. Summer is the time when the work in ceramics is easiest to do, because of the warmth and the longer days, and it is also the time when helpers are hardest to find. I try to plan the heavy steps for summer and leave the lighter, paper-based tasks for the other seasons.

The rough timeline looks like this:

- **2019:** start of the project, first survey and early ideas.
- **2020:** options weighed, the go decision taken in the spring, and the first work begun.
- **Following years:** the work carried out in stages, with reviews by the lead between them.
- **Now:** execution continues, with open points being closed one by one.

I do not keep a strict calendar of every step, because a retrofit often reveals surprises and a rigid plan would only need constant repair. Instead I keep an order of steps and a rule: do not start the next step until the cost of the last one is recorded. The lead reviews this order at regular points, and I adjust it when there is a reason.

For the coming period the plan is simple. Do the next action first. Then clear the open points that could block later steps, especially the untested parts and the budget reserve. Then confirm helpers well before the next summer, so that the heavy work can be placed in the best season. When these are done, I will update this summary, move finished items to the checklist and write a new next action.
