---
type: research
status: active
project: lunsurkmo-retrofit
area: ceramics
description: "Research about Nirde workshop."
---

# Nirde workshop tests

The Nirde workshop is a large ceramics workshop built in 2009. It sits below ground and faces north. I wrote these notes to record how the room behaves, what I check on it, and what the tests have shown so far. The north orientation and the underground position are the main reasons the space stays cool and steady, and most of my routine follows from that.

## Maintenance

The room is large, so upkeep is mostly about keeping air moving and keeping surfaces dry. Being below ground means moisture is the main concern, not heat. I go through the same short list whenever I work there.

- Check the walls and floor near the lower edges for damp patches or salt marks.
- Empty and clean the drain trap so water does not back up.
- Wipe down the work tables and shelves after each session to keep clay dust from building up.
- Run the extraction fan for a while after glazing or sanding.
- Look over the ceiling and stair area for any sign of water coming in from above.
- Keep the shelves away from the outer walls so air can pass behind them.

Because the workshop faces north, it gets little direct sun. That keeps the temperature even, which is good for drying greenware slowly and avoids cracking. It also means damp clears slowly, so I do not skip the fan. When I leave unfired work in the room, I cover it loosely and not tightly, since sealed plastic traps moisture and can leave the clay soft at the base.

The kiln area needs its own attention. I keep the floor around it clear and check that nothing stored nearby is damp or flammable. Heat from firing does help dry the air a little, but the effect does not last long in a space this size.

## Measurements

I took readings on a normal working day, with the door closed and the fan off, so the numbers show the room at rest. I placed the meter at table height near the middle of the floor and let it settle before I wrote anything down.

- Measured humidity of Nirde workshop: 52.98 %
- Area: ceramics (as set in the frontmatter)
- Size: large
- Orientation: north
- Floor: below ground
- Year built: 2009

The humidity reading is acceptable for clay work. It is not dry enough to cause trouble with fast drying, and it is not damp enough to encourage mould on shelves or boxes. I would be concerned if it climbed much higher for several days in a row, especially in the wetter months, when an underground room tends to pick up more moisture.

One reading is not a trend. I plan to repeat the test at different times of day and after the fan has run, then compare. I also want to take a reading near the lower wall and one near the stairs, because the middle of the room may not match the edges. If the edges are much damper, I will move storage and consider a small dehumidifier for the worst corner.

## References

- My own handwritten notes from the first visit, kept in the workshop folder.
- The meter's printed instruction sheet, used to confirm how long to let it settle.
- Earlier notes on drying greenware and storing glazes, which cover the habits I use here.
- A short list of repair jobs for the drain and fan, kept with the maintenance checklist.
