---
type: research
status: active
project: lunsurkmo-retrofit
area: ceramics
---

# Fulmasvork workshop tests

## Supplies

The Fulmasvork workshop is a medium-sized ceramics workshop, built in 2001, with its floor below ground and its main orientation to the west. Because it sits below ground, I have to carry everything down the stairs, so I keep supplies in a few fixed groups and check them before each test session.

- Clay bodies: a stoneware body, a white earthenware body, and a small bag of grogged clay for larger pieces.
- Glaze materials: powdered base glazes, a few oxides for colour tests, and clean water in labelled buckets.
- Test tiles: small flat tiles that I press and stamp with a mark so I can tell the batches apart.
- Tools: ribs, wire cutters, sponges, brushes, and a set of cheap plastic bowls for mixing.
- Kiln furniture: shelves, props, and stilts, plus a spare shelf in case one cracks.
- Labels and notebook: masking tape, a waterproof marker, and a paper notebook that stays on the shelf by the door.

I try to keep the clay in the coolest corner and the powders on the highest shelf, away from any water that might run along the floor. The workshop is below ground, so the floor can stay damp, and anything stored low gets soggy sooner or later. Powder in a damp bag turns into a lump, and a lump of glaze material ruins a test because I cannot tell how much I actually used.

When supplies run low I write the item on the list taped inside the cupboard door. I do not trust my memory, because the stairs make me less likely to go back for something I forgot.

## Maintenance

The workshop is from 2001, so it is not new, and the maintenance is mostly about keeping water, dust, and old wiring under control. I go through the same routine every few weeks and a longer one at the change of each season.

- Wipe down the work tables and the wedging surface after every session.
- Sweep and then mop the floor with a damp, not wet, mop, so the dust does not rise.
- Empty and rinse the buckets, and scrape the sediment out of the bottom.
- Check the walls near the floor for new damp patches or white salt marks.
- Look at the cables, plugs, and the kiln connection for heat damage or loose fittings.
- Clean the window glass on the west side so the afternoon light is not blocked.

The west orientation means the room gets light late in the day, which is pleasant for judging glaze colour. It also means the wall on that side takes the weather, so I check it more often than the others. Rain from the west is the most likely cause of any new damp, and I note the date and the spot in the notebook when I see it.

The drain needs attention too. Clay slip is hard on pipes, so I use a settling bucket and never rinse thick slip straight into the sink. I empty the settled sludge into a bin, not the drain. If the sink starts to run slowly, I stop the washing tests until it is cleared.

Tools wear out slowly. Ribs crack, sponges rot, and brushes lose their shape. I replace them when they start to affect a test, since a worn tool changes the result in ways I cannot measure.

## Safety

Safety in a below-ground room comes down to air, dust, fire, and getting out. The workshop is medium in size, which helps, but it is not so large that bad air disperses by itself.

Dust is the first concern. Dry clay and glaze powder are harmful to breathe over the years, so I mix powders slowly, wear a proper mask, and wet-clean surfaces rather than sweeping them dry. I never dry-sweep the floor.

Ventilation is the second concern. With the floor below ground, there is less natural airflow, so I open the door and run the extraction before I light the kiln and keep it running while it fires. Fumes from the kiln, especially during early heating when organic material burns off, should not collect in the room.

Other points I keep in mind:

- Keep a fire extinguisher near the stairs, and check that it is in place each month.
- Never leave the kiln running when nobody is in the building.
- Wear closed shoes, since the floor can be slippery with slip and water.
- Keep the path to the stairs clear of boxes and buckets.
- Keep a first aid kit on the wall, with eye wash for glaze splashes.
- Do not eat or drink in the room, and wash hands before leaving.

The stairs are the only way out that I count on, so I treat them as an escape route and never store anything on them. If I am carrying a heavy bag of clay, I go down one step at a time and keep one hand free for the rail.

## Open questions

There are several things I still do not understand about how this room behaves, and the tests are meant to answer some of them.

- Does the damp change how fast the test tiles dry, and does that explain the cracking I saw in the thicker ones?
- Is the humidity steady throughout the year, or does it climb in wet months because the room is below ground?
- Does the west wall let in more moisture than the other walls, or is that only my impression?
- Would a small dehumidifier pay for itself, or would it only move the problem elsewhere?
- Does the late western light change how I judge glaze colour compared with a lamp at night?
- Is the extraction strong enough for a medium room when the kiln is on and the door is open?
- Should the powders be moved out of the room entirely in winter?

I would also like to know whether the age of the building, from 2001, matters here. The wiring and the damp protection may both be older than I assume, and I have not found any papers describing them. Asking the owner is on my list, but I keep putting it off.

For now I treat each of these as a question to test, not a fact. When I have an answer, I will move it out of this section and into the relevant one above.

## Measurements

The main number I have taken so far is humidity, because it affects drying, storage, and the comfort of working in the room.

- Measured humidity of Fulmasvork workshop: 84.72 %

That is high. It fits what I would expect from a room below ground, and it explains why bags of powder go hard and why tiles dry unevenly. I took the reading with a small hand meter placed on the middle table, away from the door and the kiln, so it should reflect the general air and not a local pocket.

Other properties I record alongside it, so each reading has context:

- Kind: workshop
- Area: ceramics (as set in the frontmatter)
- Orientation: west
- Size: medium
- Year built: 2001
- Floor: below ground

When I take further readings I will note the time of day, the weather outside, whether the kiln was running, and whether the door was open. A single figure is not very useful without those details. I also plan to take readings in the corners and near the west wall to see if the numbers differ across the room. Until then, I only trust the one reading as a rough picture of the room, not a full account of it.

## Overview

The Fulmasvork workshop is a ceramics workshop. It is medium in size, was built in 2001, faces west, and has its floor below ground. I use it for tests with clay and glaze, which is why the note has the word tests in its title.

Each property shapes the work in a practical way. The ceramics area means the room is set up for clay, glaze, and firing, with tables, shelves, and a kiln. The medium size gives enough space for two or three people to work without crowding, but it also means dust and fumes build up if I am careless. The year, 2001, tells me the building is old enough to have wear, and I should not assume the fittings meet current standards. The west orientation gives warm late light and a weather-exposed wall. The below-ground floor keeps the temperature fairly even, which is good for clay, but it also brings damp, limited airflow, and a single route in and out.

My general plan for the tests is simple. I make small batches, label them clearly, fire them together, and record the results in the notebook. I change only one thing at a time, such as the clay body, the glaze thickness, or the drying time. I write down the conditions of the room, especially damp, because they may be part of the reason a result came out as it did.

So far the room is workable and pleasant, but it needs steady attention to moisture and air. If I solve those two, the workshop is a good place for this kind of testing.

## Costs

I do not keep exact accounts for this note, so I describe costs in general terms rather than listing prices. The main thing is knowing where the money goes and which items are worth paying for.

The biggest ongoing cost is clay and glaze materials. Stoneware and earthenware are bought by the bag, and glaze powders and oxides in small quantities. Oxides are the most expensive per weight, so I use them sparingly and only in planned tests.

The second cost is firing. Each kiln load uses electricity, and I try to fill the kiln properly before starting, because a half-empty firing costs nearly the same as a full one. Test tiles are small, so many fit on one shelf, which helps.

Smaller costs include:

- Replacement tools, such as sponges, ribs, and brushes.
- Masks and filters for the dust.
- Labels, tape, and notebook pages.
- Kiln shelves and props when they crack.
- Cleaning supplies and bin bags for slip waste.

A possible larger cost is moisture control. A dehumidifier or better extraction would cost real money, and so would any repair to the west wall. I will hold off until I have more readings and know whether the damp is a steady problem or a seasonal one. Spending on the wrong fix would waste money, and the humidity reading suggests I should take the question seriously.
