---
type: note
status: archived
project: lunsurkmo-retrofit
area: ceramics
description: "Note about Fulmasvork workshop."
---

# Fulmasvork workshop tests 2024

## References

This note is archived. It records the state of the Fulmasvork workshop in 2024. Later notes replace the values given here, so do not treat them as current.

The Fulmasvork workshop is a workshop, and its area is ceramics. I keep this note as a plain record of what the place was like when I tested it, so I can compare it with later checks.

Properties of the place as recorded in 2024:

- Kind: workshop
- Area: ceramics
- Orientation: west
- Size: medium
- Year built: 2001
- Floor: below ground

The workshop was built in 2001. It sits below ground, which matters for the damp and for how the air behaves in the room. The orientation is west, so the room gets little direct light from the sun, and what light there is arrives late in the day. The size is medium, enough for a few people to work at the wheels and the tables without crowding.

When I read old entries, I check the year first. Anything dated 2024 belongs to this note. Anything newer should be in a later note, and that later note wins if the two disagree.

## Measurements

These are the tests I took in 2024. I kept the method simple and did not use any special equipment beyond a basic hygrometer that I placed on a shelf near the middle of the room.

The measured humidity of Fulmasvork workshop: 52.62 %

I took the reading with the door closed and no kiln running, so it shows the room at rest. Because the floor is below ground, I expected the number to be higher, and I was glad it was not. For ceramics work, damp air slows the drying of clay and can make glazed pieces behave in odd ways, so this value is worth watching.

I did not repeat the test on different days for this note. If I test again, I will write the result in a new note and leave this one unchanged.
