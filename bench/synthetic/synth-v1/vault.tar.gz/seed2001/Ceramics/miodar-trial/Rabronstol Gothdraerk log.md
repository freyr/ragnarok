---
type: log
status: active
project: miodar-trial
area: ceramics
description: "Log about Rabronstol Gothdraerk."
---

# Rabronstol Gothdraerk log

## Lessons

Rabronstol Gothdraerk is my mentor in ceramics. I only reach him on weekends, so I save questions during the week and send them by email so we can go through them when he is free. He answers email well, usually with short notes and sometimes a sketch.

What I keep coming back to from our sessions:

- Wedge the clay longer than feels necessary. Most of my cracked pieces trace back to air pockets I left in.
- Keep wall thickness even. He checks it by tapping the pot and listening, and I am slowly learning the sound.
- Dry pieces slowly under loose plastic. Rushing the first two days of drying ruins more work than a bad glaze does.
- Do not change more than one thing in a firing. If I change the clay, the glaze and the schedule together, I learn nothing.
- Write down every firing, even the dull ones. The notes are what let me find a pattern later.

He tends to give one lesson per session rather than five. I used to find that slow. Now I think it is the reason things stick.

When I talked to him about planning my practice for the year, he pointed me back to [[Zorksaeval Giotio plan]]. His advice was to cut it down to three goals and drop the rest.

## Background

I have known Rabronstol Gothdraerk since 2010. He was already working in ceramics then, and he has been my mentor for most of that time. His role has stayed the same: he does not do the work for me, he looks at what I made and asks why I made it that way.

Quick facts for reference:

- Role: mentor
- Area: ceramics
- Contact: email
- Availability: weekends
- Known since: 2010

Over the years our contact has settled into a routine. I send photos and notes by email on a weekday evening, he reads them when he has time, and on the weekend we either talk or he writes back at length. If I need something urgent on a weekday, I accept that it will wait.

He introduced me to [[Glendrol Naefur]], who has been useful for a second opinion on glaze problems. I still take big decisions back to Rabronstol first, though, because he knows my history with this work better than anyone.

## Quotes

Things he has said that I wrote down, close to how he said them:

- "A pot tells you what went wrong. You just have to stop arguing with it."
- "Slow is a technique, not a delay."
- "If you cannot explain the failure, you have not finished the firing."

On equipment spending, he gave me a quoted price for a setup he thought was reasonable for my studio: 4447.53 EUR. I noted that this was his quote and not a final invoice, and that I should ask again before buying in case anything has changed. He also reminded me that a good result matters more than a new machine, and that I should only spend once I have hit a clear limit with what I already own.

## Tools

Tools and equipment that come up most often when we talk:

- Wooden ribs and a metal scraper for shaping and smoothing walls.
- A wire cutter and a sturdy table for wedging.
- A small notebook kept next to the kiln for firing logs.
- Calipers for checking wall thickness and lid fit.
- The [[Braetruth heat exchanger]], which we discussed as a way to manage heat and airflow around the kiln area. He thought it was worth considering only after I fixed my drying routine.

His general rule on tools is to learn one properly before adding another. He still uses a few very old, worn items, and he says the wear shows what he really relies on. When I am unsure whether to buy something, I ask him by email and wait for the weekend answer. So far the answer has usually been to wait a little longer.
