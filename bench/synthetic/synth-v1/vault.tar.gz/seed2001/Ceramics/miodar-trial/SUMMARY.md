---
type: summary
status: active
project: miodar-trial
area: ceramics
description: "Summary about Miodar trial."
---

# Summary of Miodar trial

## Open questions

These are the points I still cannot answer for the Miodar trial. The project is a trial in the ceramics area, started in autumn 2024 and led by the carpenter, so most of the questions come from the woodworking side meeting the clay side.

- Will the wooden support frames hold their shape near the kiln, or will the heat slowly warp them? I have not watched a frame through a full firing cycle yet.
- Is the drying rack tall enough for the larger pieces, or will I need to add a second tier later?
- Which of the two heat exchangers suits the setup better? I have notes on [[Braetruth heat exchanger]] and [[Stondneth heat exchanger]], but I have not compared them side by side in the actual space.
- Does the yard give enough shelter for the outdoor stage of drying? The [[Sandbris yard study]] suggests it does in dry weather, but it says little about wind.
- How much of the cutting work can the [[Luki band saw]] take before I need a different blade or a different tool?
- Who checks the finished frame before the first real load goes on it? The carpenter leads the project, but I would like a second pair of eyes.

I will move questions out of this list as they are answered, and record the answer under Decisions or Observations.

## Observations

This section collects what I have actually seen so far, as opposed to what I expected.

The trial has run through its early stage without major surprises. The carpenter's approach of building small test pieces first has paid off. Each small piece showed a problem that would have been expensive in a full-size build.

- Joints made in damp timber loosen as the wood dries. I now let all stock sit indoors before cutting.
- Clay dust gets everywhere in the workshop and clogs the saw's dust path faster than sawdust alone does.
- The [[Luki band saw]] gives clean cuts on thin stock, but it wanders a little on thick pieces unless the blade is freshly set.
- Warm air moves differently in the corner I picked than I assumed. The corner is draughty near the door, which affects drying speed.
- Pieces dried near the wall dry more evenly than those in the open middle of the room.

I also noticed that my notes were thin in the first weeks. I wrote down results but not the conditions, such as weather and room temperature. From now on each observation gets a short line about conditions.

The general feeling is that the trial is workable but fussy. Nothing has failed outright. Most problems are about patience and timing rather than design.

## Next action

The next action for the Miodar trial is NX-0141.

I keep this section short on purpose. It should be the one thing I can start on the next free evening without rereading the whole note. Once NX-0141 is done, I will replace this entry with the next item from the checklist and move the old one into the notes under Observations if it taught me anything.

Before starting, I will clear the bench, check that the blade on the saw is in good shape, and make sure the materials listed under Supplies are within reach. I do not want to stop halfway to hunt for a clamp.

## Costs

I am not recording exact prices in this note, since the figures live in my separate household ledger. What I can say here is where the money goes and how I think about it.

The trial is meant to stay small. The main spending falls into a few groups:

- Timber for frames and racks, which is the largest group because I waste some on test pieces.
- Clay and glaze materials, bought in modest amounts so nothing goes stale.
- Consumables such as saw blades, sandpaper, and fixings.
- A possible heat exchanger, which would be the biggest single purchase if I go ahead with one.

The heat exchanger question matters most for cost. Between [[Braetruth heat exchanger]] and [[Stondneth heat exchanger]], one looks cheaper to buy and the other looks cheaper to run. I have not settled which matters more, because it depends on how often I will really fire pieces during the trial.

A rule I am following: no purchase above the small-consumables level without writing the reason under Decisions first. That slows me down a little, but it has already stopped one impulse buy. Since this is a trial, I also treat part of the spending as the price of learning. If the trial ends in a no-go, I still want to know the money taught me something useful.

## Decisions

This section holds the choices I have made and the reasons, so I do not reargue them every time.

The go decision date for the Miodar trial is 2018-06-13. I treat that as the formal point where the trial was approved to proceed, and everything after it is carried out under that approval.

Other decisions so far:

- The carpenter leads the project. Woodwork is the bottleneck, so it makes sense for that person to set the order of work.
- The trial stays in the ceramics area and does not expand into other crafts, even where a tempting side project appears.
- Start small. Test pieces come before full-size frames.
- Use the [[Luki band saw]] for all curved and thin cuts, and avoid forcing it through thick stock.
- Use the [[Sandbris yard study]] as the base reference for outdoor conditions rather than redoing the measurements myself.
- Keep the heat exchanger choice open until I have run at least one full firing cycle with the current arrangement.

If I change one of these, I will add a line saying what changed and why, rather than overwriting the old text. The history is useful when I look back at the trial and try to judge whether the decisions were sound.

## Maintenance

A trial that runs for a while needs regular upkeep, or the setup degrades and the results become unreliable.

For the woodwork side:

- Clean and check the [[Luki band saw]] after every long session. Clay dust and sawdust together form a paste that is hard to remove later.
- Inspect the blade for wear and set it before any cut in thick stock.
- Look over the frames for loose joints, especially after a damp spell.
- Oil or seal exposed timber that sits near moisture.

For the ceramics side:

- Wipe down surfaces after each session so dried clay does not build up.
- Check the drying racks for sagging or warping.
- Keep the area around the kiln clear of anything flammable and of loose dust.

If I install a heat exchanger, it will need its own routine. Either [[Braetruth heat exchanger]] or [[Stondneth heat exchanger]] would need periodic cleaning, and I will write that routine when I choose one. For now, a short weekly walk-through of the whole space is enough. I keep it informal: look, touch, fix small things at once, and note anything bigger on the checklist.

## References

These are the notes and sources I lean on for the trial.

- [[Sandbris yard study]]: my main reference for how the yard behaves in different weather, useful for the outdoor drying stage.
- [[Braetruth heat exchanger]]: notes on one candidate for managing heat in the workspace.
- [[Stondneth heat exchanger]]: notes on the other candidate, kept separate so I can compare them fairly.
- [[Luki band saw]]: the tool notes, including how it behaves with different stock and blades.

Beyond those, I use my own earlier test results from this project. I do not link outside material here. If I read something worth keeping, I will turn it into its own note and link it from this list. The aim is that every reference can be reached from this summary in one click, so I can find the background without searching.

## Setup

The setup is a shared workspace where woodwork and ceramics happen close together. That closeness is convenient but also the source of most problems.

The woodworking side has a sturdy bench, the [[Luki band saw]], hand tools, and a rack for stock that is seasoning. The ceramics side has a table for forming, a set of drying racks, shelves for finished pieces, and the kiln position. A walkway separates the two areas so that dust from one does not drift easily into the other, though in practice some always does.

I arranged the room so the draughty door side holds only things that do not mind moving air, such as stored timber. The wall side is for drying, since pieces dry more evenly there. Outdoor space in the yard is used for the first stage of drying in good weather, guided by the [[Sandbris yard study]].

The carpenter leads the project, so the layout follows the woodworking needs first. The ceramics area adapts around it. I may change this once the trial shows whether the ceramic output is steady enough to deserve priority.

The heat arrangement is still provisional. I am working with the current kiln position and holding off on installing either [[Braetruth heat exchanger]] or [[Stondneth heat exchanger]] until the decision is made.

## Ideas

These are loose thoughts, not commitments. Some may become decisions later.

- Build the drying racks with removable shelves so the height can change for large pieces.
- Add a simple dust screen between the saw and the forming table, perhaps a hung cloth to start with.
- Try a small test of both heat exchangers in a temporary arrangement before buying either.
- Make a set of reusable jigs for repeated cuts on the [[Luki band saw]], so frames come out consistent.
- Keep a tiny logbook by the door for conditions: weather, room feel, and drying speed.
- Use offcuts from the frames to make tool holders or small stands for the ceramics table, so little timber is wasted.
- Re-read the [[Sandbris yard study]] in a different season and see whether its advice still holds.
- Make a shelf design that doubles as a transport rack, so finished pieces can be carried safely.

If one of these starts to look good, I will test it as a small piece first, the same way as everything else in the trial.

## Checklist

A running list for the trial. I tick items off as they are done and add new ones as they appear.

- [x] Define the goal of the trial and its area
- [x] Assign the carpenter as lead
- [x] Set up the shared workspace
- [x] Make the first small test pieces
- [ ] Check frames after a full firing cycle
- [ ] Compare [[Braetruth heat exchanger]] with [[Stondneth heat exchanger]] in the real space
- [ ] Decide on a dust screen between the saw and the forming table
- [ ] Review the drying rack height for larger pieces
- [ ] Refresh the saw blade and set it for thick stock
- [ ] Write the maintenance routine for the chosen heat arrangement
- [ ] Move answered questions out of Open questions
- [ ] Complete the next action listed above

I review this list at the end of each session. If an item sits unticked for too long, I either break it into smaller steps or decide it is not worth doing and remove it with a note about why.

## Overview

Miodar trial is a project in my knowledge base. Its goal is a trial, meaning I am testing an idea in practice and not yet committing to a full production effort. It belongs to the ceramics area. It started in 2024, in the autumn season, and the carpenter leads it.

The reason a carpenter leads a ceramics trial is that the main unknowns are in the supporting structures: frames, racks, shelves, and the way they cope with heat, damp, and dust. The clay work itself is familiar. The structures around it are where the trial is learning most.

The current stage is early to middle. The setup is in place, the first small test pieces are done, and the main open work is checking how things hold up through a full firing cycle and deciding on the heat arrangement. The go decision is recorded under Decisions, and the next action is recorded under Next action.

What is done so far: the workspace is arranged, the lead is assigned, test pieces have been made, and I have gathered the reference notes. What is open: the heat exchanger choice, the frame durability question, and the drying rack height. These are listed in more detail under Open questions.

This note is meant to be read first. If I come back after a break, the Overview, Next action, and Open questions should be enough to get going again.

## Schedule

I keep the schedule loose, because a trial should adjust to what it teaches. Still, there is an order that makes sense.

The trial started in autumn 2024. Since then the work has moved through a few stages:

- Early stage: planning, choosing the area, and assigning the lead.
- Setup stage: arranging the workspace and gathering tools.
- Test stage: making small pieces and noting what fails.
- Current stage: carrying out the next action and checking durability.

What comes next is a full firing cycle with the existing frames, followed by a review. After the review I will either settle the heat exchanger choice or run a short temporary comparison first. Only then do I plan any larger build.

I try to do woodwork on days with dry weather, since damp timber causes trouble. Forming and drying fit better on days when the yard can be used for the early drying stage, following the [[Sandbris yard study]]. Firing days are planned around the other work so the kiln area is clear and I can watch it.

I have no hard deadline for the trial. The check is simple: if progress stalls for a long stretch, I review the checklist and decide whether to continue, change direction, or stop.

## Safety

Woodwork and ceramics each carry their own hazards, and combining them in one room adds a few more.

Dust is the main one. Clay dust and fine sawdust are both bad to breathe. I wear a proper dust mask when cutting or sanding, and I wipe surfaces damp rather than sweeping dry. I do not dry-sweep clay residue.

Around the [[Luki band saw]]:

- Keep fingers well clear of the blade and use a push stick for narrow stock.
- Check the guard position before each cut.
- Never clear off-cuts while the blade is moving.
- Tie back loose clothing and hair.

Around the kiln:

- Keep the area clear of timber, cloth, and paper.
- Do not leave a firing unattended in the early part of the cycle.
- Allow plenty of cooling time before opening, and use proper gloves.
- Ventilate the room well during firing.

If I add a heat exchanger, either [[Braetruth heat exchanger]] or [[Stondneth heat exchanger]], I will review the safety notes again, since any new heat path changes where hot surfaces are. I also keep a fire extinguisher within reach and check it occasionally. Because the carpenter leads the work, safety around tools is part of that role, and I treat it as non-negotiable.

## Supplies

This is the working list of what I need on hand for the trial, grouped by use.

Woodwork:

- Seasoned timber for frames and racks
- Spare blades for the [[Luki band saw]]
- Fixings, glue, and sandpaper
- Clamps and measuring tools
- Sealant or oil for exposed timber

Ceramics:

- Clay in modest amounts
- Glaze materials
- Forming tools and sponges
- Boards or bats for drying pieces
- Kiln furniture and props

General:

- Dust masks and gloves
- Cloths and buckets for damp cleaning
- A notebook for conditions and results
- Labels so test pieces can be traced to their notes

I keep stock low and top up when needed, since clay and glaze materials can go stale and timber can warp if stored badly. If I buy a heat exchanger, whether [[Braetruth heat exchanger]] or [[Stondneth heat exchanger]], it will move from the ideas pile to this list with its fittings and any extra parts.
