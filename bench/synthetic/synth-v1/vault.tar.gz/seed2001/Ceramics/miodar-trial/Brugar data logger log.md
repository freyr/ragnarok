---
type: log
status: active
project: miodar-trial
area: ceramics
description: "Log about Brugar data logger."
---

# Brugar data logger log

## Setup

The Brugar data logger is a black data logger that sits in the loft. I installed it in 2021 for my ceramics work, and it has run on battery power ever since. There is no mains lead going up there, so the battery is the only energy source. That was a deliberate choice, because I did not want to pull a cable through the ceiling just to record a few readings.

This log is where I keep running notes about the device: how it is set up, what I have seen from it, what has gone wrong, and what I still do not know. It is written for my own use, so it is short on polish and long on detail I will want later.

Quick facts, so I do not have to hunt for them:

- Kind: data logger
- Area: ceramics
- Color: black
- Energy source: battery
- Year installed: 2021
- Location: loft

The logger is mounted on a wooden rafter, away from the roof slope, so that it does not get dripped on if a tile ever slips. The black case absorbs a bit of heat on warm days, which I keep in mind when reading the temperature trace. I left a small gap behind it for air to move.

The loft is reached by a fixed ladder. I only go up when I have a reason, such as swapping the battery or pulling the stored readings. Each visit is a small chore, so I try to bundle jobs together.

## Background

I started using a logger because my ceramics work depends on conditions I cannot judge by feel. Drying time, humidity, and temperature swings all change how clay behaves before it ever reaches a kiln. I wanted a record over weeks and months rather than a guess on the day.

Before I bought this unit I ran a few comparison trials with other gear. The notes from those are in [[Fulmasvork workshop tests]], which covers how I judged readings against a simple reference in the workshop. That note is where I decided that a logger had to be steady more than it had to be clever.

For the radio side of things, such as how the logger might be read from a distance, I looked at [[Vorful radio receiver handbook]]. In the end I did not wire up any radio link. The logger stores its readings internally and I collect them by hand. The handbook is still useful for understanding why a weak signal through a roof is a poor plan.

A friend, [[Glendrol Naefur]], suggested the loft position. The argument was that the loft sees the widest swings, so if the logger copes there, it will cope anywhere else I might move it. I have found that advice sound.

I also compared how heat moves in a building with what I was seeing. The ideas in [[Kesdridaer heat exchanger study]] helped me think about why the loft warms and cools the way it does. The idea of moving air to even out temperature came from there, and from [[Tangio circulation pump study]], which I read for the general principle of steady circulation rather than for any pump detail.

## Safety

The main risks are not the device itself, which is a small battery unit, but the place where it lives.

- The loft ladder is the biggest hazard. I check that it is locked in place before climbing and I never carry the logger in one hand while going up.
- Loft floors are often just joists with insulation between them. I step only on boards or joists and never on bare insulation or plasterboard.
- Heat builds up under the roof in summer, so I avoid long visits on hot afternoons.
- I take a torch rather than relying on one light bulb, since the loft light can fail.
- The battery should be handled carefully. I do not short the terminals, I do not leave a spent cell in a hot spot, and I do not mix old and new cells.
- Dust in the loft is irritating, so I wear a simple mask when I disturb anything.

I also keep ceramics dust in mind. Some of my materials make fine powder, and I do not want any of that near the logger or carried into the loft on my clothes. I change or brush down before going up.

If the battery ever swells, leaks, or smells odd, the rule is simple: take it out, put it somewhere non-flammable, and dispose of it properly. I do not try to keep using it.

## Observations

Over the years since 2021 the logger has given me a fairly consistent picture of the loft.

The daily pattern is clear. Temperature climbs through the afternoon, peaks late, and falls through the night. In summer the swing is large. In winter it is smaller, but the loft is noticeably colder than the rooms below. Humidity tends to move the opposite way to temperature, rising when the air cools.

Some things I have noticed in my own notes:

- The black case does seem to bias readings slightly on sunny days. The trace rises faster than I would expect from the air alone.
- Sudden dips line up with times when I opened the hatch, which let in cooler air from the house below. I now mark these visits so I can discount them.
- Slow drifts over several months are real seasonal change, not a fault. I checked this by comparing against a simple reference reading in the workshop.
- After a battery swap the first few readings are sometimes a little odd. I now ignore the first short stretch after any change.

The ceramics link is the reason for all this. When the loft stays steady and dry, any clay or glaze material I store there behaves predictably. When humidity climbs, I see it in how slowly things dry and how fragile they become. The logger lets me match those memories to actual numbers.

I also tested the idea of comparing with another site, recorded in [[Fudralvend Sirmeller tests]]. That note covers a side-by-side check where I put two sources of readings next to each other to see how closely they agreed. The result was reassuring: the loft logger followed the same shape, even if the absolute values were offset.

## Tools

What I use when I deal with the logger:

- A fixed ladder and a headtorch for access.
- A small screwdriver for the battery cover.
- Spare batteries, kept in a labeled box so I know which are fresh.
- A soft cloth to wipe dust from the black case.
- A notebook, paper, for recording the time of each visit.
- A laptop for reading out the stored data once I am back downstairs.
- A basic reference thermometer, kept in the workshop, for sanity checks.
- Cable ties and a small piece of foam to keep the logger snug against the rafter.

I keep the tools in one tray so a visit does not turn into three trips. The tray lives near the foot of the ladder.

A habit that has paid off is writing the visit time down at once. Without it, the dips caused by the open hatch look like mystery events months later.

## Software

The logger runs firmware version v9.26.123. I have not changed it since I noted it, and I do not plan to unless a clear fault shows up. With a device that is hard to reach, I prefer a known state over the newest one.

Reading the data is done from the laptop after I bring the logger down or connect to it at the hatch. The workflow is simple:

- Connect the logger and let the software detect it.
- Download the stored readings.
- Save a copy of the raw file before doing anything else.
- Clean and plot the data in a separate step.

I never edit the raw file. Any cleanup happens on a copy, so I can always go back. I label each copy with the range it covers.

For analysis I use a plain spreadsheet. I plot temperature and humidity on the same time axis, shade the periods when I visited, and then look at the rest. That is enough for the questions I ask.

One lesson: settings can reset after a full battery drain. I now write down the sampling interval and other settings after each swap, so I can restore them if they vanish.

## Problems

The problems have been small but real.

The first is battery life. In cold spells it drops faster than in warm ones, which is typical of a battery unit. A cell that seems fine in autumn may be flat by midwinter. I replace before the cold arrives rather than waiting.

The second is gaps in the record. When the battery ran out between visits, I lost a stretch of readings. The gap shows up as a flat line or as nothing at all. I cannot recover those hours.

The third is the clock. Over long periods the logger's clock drifts a little. It is not dramatic, but when I line up its data with other sources, I notice the offset. I reset the clock at each visit now.

The fourth is the case color. Black is fine for looks, but it makes the sun bias worse. I have thought about shading it with a small card, though I have not yet done it.

The fifth is dust. Loft dust gets into everything, and I have had to wipe the case and the battery contacts more than once. Poor contact caused one false low reading that I first mistook for a real drop.

None of these has been a disaster, and none has made me think the device is unfit for the job.

## Open questions

There are several things I still want to settle.

- How much does the black case bias the readings on sunny days? I could test by shading it for a month and comparing.
- Would a different mounting spot, lower on the rafter, give a more representative trace?
- Is the battery drain mainly from cold, or from the sampling interval I chose? A longer interval might double the time between swaps.
- Should I add a second, cheaper logger in the workshop so I can compare the two permanently?
- Can I find a better way to mark my own visits automatically rather than by notebook?
- Is it worth replacing the logger at some point, given that it dates from 2021, or is it simply a matter of keeping fresh batteries in it?

I may also revisit the question of a radio link. The reasons against were practical, but if I tire of the ladder, the argument could change. For that I would go back to [[Vorful radio receiver handbook]] and think about range through the roof.

## Risks

The risks fall into three groups: loss of data, loss of the device, and harm to me.

For data, the main risk is a flat battery between visits, which leaves a gap. A second risk is a corrupted or overwritten file if I do not keep a raw copy. I reduce both by swapping early and by saving the raw download first.

For the device, the loft is hostile. Heat, cold, damp, and dust all work against a small electronic unit. A roof leak could ruin it. I check the area around the rafter for signs of moisture each time I go up. A leaking battery could also damage the case and contacts.

For me, the ladder and the loft floor are the real danger, as described in the safety section. A moment of carelessness there matters far more than anything the logger might do.

There is also a risk of trusting the numbers too much. The logger is a good guide, but it has a case color bias, a drifting clock, and gaps. I treat it as a trend tool, not a precise instrument. When a decision really matters, I cross-check with another reading, as I did in [[Fudralvend Sirmeller tests]].

Finally, there is the risk that I stop looking at it. A logger that is installed and then forgotten is just a black box in the loft. The value comes from the routine, so I keep the visits regular and the notes current.
