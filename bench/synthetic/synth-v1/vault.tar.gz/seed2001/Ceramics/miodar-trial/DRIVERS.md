---
type: drivers
status: active
project: miodar-trial
area: ceramics
---

# Drivers of Miodar trial

## References

This note covers the drivers of the Miodar trial: why it exists, what limits it, what it costs and how I will decide whether it worked. It is a project in the ceramics area. The goal is a trial, it started in 2024, in the autumn season, and the carpenter leads it.

Project properties, as I keep them:

- Name: Miodar trial
- Type: project
- Goal: trial
- Area: ceramics
- Start year: 2024
- Season: autumn
- Lead: carpenter

The goal is a trial, not a finished product. I want to learn whether the approach holds up before I commit more time and money to it. Everything below follows from that.

### Constraints

- The work happens in the autumn season, so drying and firing time is limited by cool, damp weather.
- The lead is the carpenter, so any wooden parts (racks, boards, frames) are made in-house rather than bought.
- The scope stays small: a few test pieces, not a full run.
- Nothing is bought before the previous step has been checked.

### Measuring success

I judge the trial by a short list of checks, written down before starting so I cannot move the goalposts later.

| Check | What I look at | Pass condition |
|---|---|---|
| Surface | Cracks or warping after drying | Most pieces intact |
| Fit | Wooden parts hold the pieces securely | No wobble or slipping |
| Cost | Spending against the budget | Stays within the limit |
| Repeat | Can I do it again from my notes | Yes, without guessing |

A trial counts as a success if three of the four checks pass and the cost check is one of them.

## Budget

The budget of Miodar trial is 10424.33 EUR. This is the ceiling for the whole trial, including materials, wood for the carpenter's parts, firing costs and small tools.

I track spending in a plain text log so I can see at a glance how much is left. A simple format works best:

```text
project: Miodar trial
budget: 10424.33 EUR
entries:
  - category: materials
    note: clay and glaze tests
  - category: wood
    note: racks and boards from the workshop
  - category: firing
    note: kiln time
```

Rules I follow for money:

- Record each expense on the day it happens.
- Check the running total before any new purchase.
- If spending nears the limit, stop and review the cost check before continuing.
- Do not move money between categories without writing the reason in the log.

If the trial passes, the leftover amount tells me how much room a larger second round could have.
