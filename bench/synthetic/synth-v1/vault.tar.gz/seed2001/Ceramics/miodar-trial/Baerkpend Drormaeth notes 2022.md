---
type: log
status: archived
project: miodar-trial
area: ceramics
description: "Log about Baerkpend Drormaeth."
---

# Baerkpend Drormaeth notes 2022

This note is archived. It records how things stood with Baerkpend Drormaeth in 2022. Later notes replace the values below.

## Maintenance

Baerkpend Drormaeth is an accountant. I have known Baerkpend since 2015. The contact is in person only, and Baerkpend is available in the evenings. These are the facts I keep current in my own notes, and in 2022 they looked like this:

- Role: accountant
- Area: ceramics (also in the frontmatter)
- Contact: in person
- Availability: evenings
- Known since: 2015

Keeping up the relationship in 2022 took very little work, but it did take some habit. Because contact is in person, there is no message thread to scroll back through. If I want to remember what we agreed, I have to write it down myself right after we talk. So after each meeting I add a short paragraph to this log. I keep it plain: what was asked, what was answered, and what I still have to bring next time.

Evenings are the only reliable window. Daytime visits to the workshop side of things never worked, because Baerkpend is busy with client books. I stopped trying daytime slots early in 2022 and settled on evenings only. That removed most of the missed meetings.

Small upkeep tasks I did through the year:

- Kept one folder of receipts for the ceramics work, sorted by type, so there was something to hand over in person.
- Wrote down questions in advance so an evening meeting did not run long.
- Noted any advice that touched the kiln purchases and the studio running costs.
- Reviewed this log once in a while to see whether anything had gone stale.

## References

The notes below are the ones I linked to this person's advice in 2022. Baerkpend's accounting view often changed how I read them.

- [[Gaerkbaend Baengal plan]]: the plan for the studio side of the work. Baerkpend looked at the cost lines and suggested I separate the one-off items from the running ones.
- [[Guzefaen heat exchanger notes]]: my notes on the heat exchanger. Baerkpend asked what the expected useful life was, because that affects how the purchase is written off.
- [[Drurkzork band saw]]: the saw I use for cutting. Baerkpend wanted to know if it counted as a tool or as equipment.
- [[Genketh Vorkdios tests]]: the test notes. I mentioned them in passing, and Baerkpend only asked whether any test material had been bought separately.
- [[Gliospaeth Stuntre plan]]: another plan that needs a budget check. I planned to bring it to an evening meeting.
- [[Navis heat exchanger]]: the second heat exchanger entry. Baerkpend suggested I compare it with the other one before deciding.

Each of these is a place where a number or a decision touches money, which is why they connect to an accountant. When I reopen any of them, I check this log first for any remark from Baerkpend.

## Risks

The risks in 2022 were mostly about access and timing, not about the person.

1. **In-person only.** If I cannot get to a meeting, there is no fallback channel. A missed evening can mean waiting a long time. I accepted this in 2022 but noted it as the main weak point.
2. **Evenings only.** Baerkpend is available in the evenings, so anything urgent during the day has to wait. I should not leave time-sensitive questions to the last moment.
3. **Memory.** Since nothing is written between us, advice can be forgotten or recalled wrongly. This log is the only record, so a gap in it is a real loss.
4. **Scope.** Baerkpend is an accountant, and the area is ceramics. I should not ask for advice on the craft itself, only on the money side of it. Mixing the two leads to vague answers.
5. **Dependence.** I have relied on one person since 2015. If Baerkpend moved away or changed work, I would have no other accountant who knows my situation.

None of these felt severe in 2022. Still, I wrote them down so I would see them if the arrangement started to slip.

## History

I have known Baerkpend Drormaeth since 2015. The start was casual, a chance introduction through the ceramics circle, and the relationship has stayed practical ever since.

Rough outline of how it went:

- **2015:** First met. At that point it was only a conversation about how to keep records for small craft sales.
- **The years after:** Occasional evening meetings, usually once the working season slowed down. Baerkpend gave advice on keeping income and expenses apart and on what to keep as proof.
- **2022:** The year this note describes. Meetings stayed in person and in the evening. The topics were the studio plan, the equipment purchases, and how to write up the heat exchangers and the saw.

What I noticed in 2022 compared with earlier years was that the questions had become more specific. In the early years I asked general things. By 2022 I was bringing particular items, such as the saw and the heat exchangers, and asking how each should be treated. Baerkpend's answers were short and direct, which suited me.

I made no change to the way we communicate in 2022. In person and evenings remained the rule, and I did not try to move anything to another channel.

## Checklist

Before each evening meeting with Baerkpend Drormaeth, I went through this list in 2022:

- [ ] Confirm the evening in person beforehand, since there is no other way to reach out.
- [ ] Bring the receipt folder for the ceramics work.
- [ ] Open [[Gaerkbaend Baengal plan]] and mark the cost lines I want checked.
- [ ] Open [[Guzefaen heat exchanger notes]] and [[Navis heat exchanger]] and note the question about comparing them.
- [ ] Open [[Drurkzork band saw]] and note the tool-or-equipment question.
- [ ] Have [[Gliospaeth Stuntre plan]] ready if there is time.
- [ ] Skim [[Genketh Vorkdios tests]] in case the material purchases come up.
- [ ] Bring something to write on.

After the meeting:

- [ ] Write a short entry in this log the same night.
- [ ] Note anything Baerkpend asked me to bring next time.
- [ ] Update the linked notes if any decision was made.

## Costs

I paid no regular fee in 2022 that I tracked in this note. The arrangement was informal, and advice came during evening meetings. The costs that mattered were of other kinds:

- **Time.** Each meeting took an evening, so I planned it around other things.
- **Travel.** Meeting in person meant getting there, which took more effort than a call would have.
- **Preparation.** Sorting receipts and writing questions took a little time before every meeting.
- **Gifts and small thanks.** I sometimes brought something small from the studio as thanks. I did not record these as expenses.

The only price I wrote down from 2022 is the quote listed in the Quotes section. It is a quoted price, not a regular cost, and I did not treat it as a recurring amount. If I ever do pay Baerkpend for formal work, I should add the rate and the billing method here, but in 2022 there was nothing to add.

## Schedule

The schedule in 2022 was simple, because the two constraints were fixed: in person, and in the evenings.

- **Contact:** in person
- **Availability:** evenings
- **Pattern:** one evening meeting whenever I had enough open questions to justify it, usually not more often than needed.
- **Planning:** I agreed the next meeting at the end of the current one, since I could not message in between.
- **Busy periods:** Baerkpend is less free when client books are due, so I avoided asking for time then and brought my questions earlier or later.

A rough yearly rhythm I followed:

1. Early in the year, one meeting about the plans and what I intended to buy.
2. Midyear, a check on how the purchases had been recorded.
3. Late in the year, a review before the books closed.

I did not stick to this strictly, but it gave me a frame. Because later notes replace this one, the actual current schedule lives in newer entries.

## Quotes

Baerkpend gave one quote that I wrote down in 2022.

- Quoted price of Baerkpend Drormaeth: 8950.71 EUR

I kept it as the single figure from that year. It was a quote, not an invoice, and I did not treat it as agreed until it was confirmed in person at an evening meeting. If I need the context, I check the linked plans, especially [[Gaerkbaend Baengal plan]], since that is where the cost lines are listed.

One remark Baerkpend made, which I paraphrase: keep the one-off items apart from the running costs, so the books stay readable. I followed that advice in the plans, and it made later reviews easier.

Because this note is archived, this quote is the 2022 state only. Later notes replace the value if it changes.
