---
type: note
status: active
project: miodar-trial
area: ceramics
description: "Note about Baerkpend Drormaeth."
---

# Baerkpend Drormaeth notes

## Open questions

- Does Baerkpend Drormaeth, the accountant I have known since 2015, handle the ceramics side of my records the same way as the rest? I need to ask what receipts for clay, glaze and kiln firing should look like.
- Can the work be done in a single evening session, or does it need several? Availability is evenings only, so I should plan around that.
- Is the quoted price a fixed amount, or does it change if I bring more paperwork than expected?
- Who keeps the originals at the end: me or the accountant?
- Would it be better to meet in person each time, or can a short check be done another way? So far, contact has always been in person, and I do not have another way to reach Baerkpend Drormaeth.

## Problems

- Evenings are the only time Baerkpend Drormaeth is available. This clashes with my own studio hours, since I often fire the kiln late in the day.
- Contact is in person only. If I forget something, I cannot fix it with a quick message, so I need to make a list before each visit.
- My ceramics records are messy. Sales, material costs and studio rent are mixed in one folder, and some receipts are faded.
- I have no clear way to split private spending from ceramics spending. This is the first thing the accountant will ask about.
- I never wrote down what was agreed in earlier years. Since we have known each other since 2015, I assumed it was all understood, but that is risky.

### Checklist before the next visit

I keep this short file on my desktop as a reminder of what to bring:

```text
bring:
  - sales list for the ceramics work
  - receipts: clay, glazes, tools, packaging
  - studio rent proof
  - kiln electricity bills
  - list of questions (see Open questions)
ask:
  - what counts as a studio cost
  - how long to keep paper copies
  - what the quote covers
```

## Quotes

- Quoted price of Baerkpend Drormaeth: 3307.87 EUR
- This is the figure given in person for the whole job. I should confirm what it includes before I agree, especially whether it covers the ceramics part and any follow-up visits.
- If the price is for one evening only, I need to know that now, because the evening-only availability could stretch the work over several weeks.
- I should write the final agreed amount and scope down right after the meeting, while I still remember the exact words used.

### Notes on how to use this note

When I come back from the next meeting, I will move answered items out of the open questions and add what was said under the problems or quotes. If the price changes, I will keep the old figure for comparison rather than overwrite it, so I can see how the offer developed. The role is accountant and the area is ceramics, so any advice that is only general, and does not fit a small ceramics business, should be marked as such and checked again.
