---
type: research
status: active
project: giorkkel-trial
area: ceramics
description: "Research about Sasvaeth workshop."
---

# Sasvaeth workshop tests

## Background

These notes cover the tests I ran in the Sasvaeth workshop. It is a workshop for ceramics. The building is large and sits below ground, and its orientation is north. It was built in 2008. I wanted one place where I keep what I learned about the room, because the space behaves differently from any studio I have used above ground.

The properties of the place, so I do not have to look them up again:

- Kind: workshop
- Area: ceramics
- Orientation: north
- Size: large
- Year built: 2008
- Floor: below ground

Why test at all? A ceramics workshop below ground stays cool in summer and does not swing much in temperature, which is good for slow drying of clay. But it also holds moisture. A north orientation means little direct sun, so the room stays even in light and cool, but nothing dries it out either. Because the size is large, the air does not behave the same in every corner. I wanted to know where the best spots for drying, wedging, glazing and storage really are, and where I should not put things.

The tests were simple and practical. I did not use special equipment beyond a few cheap meters, a notebook, and some test tiles. I repeated the same checks across several weeks so I could see whether one reading was a fluke. This note records what I did, what went wrong, and what I would do next time.

## Schedule

I kept the testing on a loose schedule so that it did not eat into real working time. The pattern was the same each week.

- Monday morning: walk the whole room, open the notebook, and note anything that changed over the weekend, such as damp patches, smell, or condensation on pipes.
- Tuesday: place the drying tests. I set out clay test tiles of the same size and thickness at four positions, then checked them each day.
- Wednesday: take readings in the morning and again in the late afternoon, at the same four positions.
- Thursday: glaze and kiln tests, where the kiln was available. I loaded the test tiles on the shelf in the same order each time.
- Friday: write up the week, compare it with the earlier weeks, and clean the room.

The test period ran across a stretch of weeks in autumn, when the weather outside was changing. I wanted a period with some variety, because a below-ground room can look stable on a single dry day and then behave badly after rain. I tried to do at least one reading on a wet day and one on a dry day, so I could compare them.

I also kept a small rule: never change two things at once. If I moved the tiles to a new position, I did not also change the ventilation. If I changed the ventilation, the tiles stayed put. That made the schedule slower, but the results were easier to read afterward.

## Problems

Several problems came up, and some of them I only noticed because I was measuring.

**Dampness.** The first and biggest problem is moisture. The room is below ground, so the walls carry water from the soil, even when nothing looks wet. The far wall on the north side was the worst. Paper labels curled there, and a cardboard box of dry materials went soft at the bottom within a couple of weeks.

**Slow and uneven drying.** Test tiles at the far end of the large room dried more slowly than tiles near the stairs. In the damp corner, tiles stayed cool and slightly soft to the touch for much longer. Slow is good up to a point, but a wide gap between positions meant that big pieces left in the wrong place risked drying unevenly and cracking at the thin edges.

**Condensation.** On days when the outside air was warm and the room was cool, water formed on the cold pipes and on the metal legs of shelves. A few drops fell on a tile once and left a mark that showed after firing.

**Stale air.** With no windows to speak of, the air did not move much. A faint musty smell built up when the door was shut for a day or two. I did not enjoy working in it for long stretches.

**Light.** The north orientation gives soft, even light, but for a below-ground room that mostly means artificial light. Glaze colors looked different under the ceiling lamps than they did when I carried a tile up the stairs and looked at it outside. I had to learn to judge color in daylight, not in the workshop.

**Dust.** Dry clay dust settled on everything because the air was still. This ties into the safety notes below.

**Notebook gaps.** I forgot a few readings during busy days. Those gaps make the data weaker, so I mark them clearly rather than guessing.

## Lessons

The main lessons from the tests, written as plain rules for myself:

1. Treat the room as damp by default. Assume that anything absorbent will take on water, and store it accordingly.
2. Use the stair end for drying whenever possible. It dries faster and more evenly than the far north wall.
3. Do not store paper, cardboard, or bagged powders on the floor or against the outside walls. Use plastic bins with lids, and keep them on shelves off the ground.
4. Cover large pieces loosely when I want drying to be slow, and leave small pieces uncovered. Do not rely on the room alone to control the speed.
5. Wipe cold pipes and shelf legs, or keep tiles away from them, on warm humid days.
6. Judge glaze color in daylight. The lamps are fine for working but not for deciding.
7. Air the room on dry days. Even a short period with the door open and a fan running makes the smell go away.
8. Take readings at the same time and in the same places. A reading with no context is nearly useless.
9. Change one thing at a time.

A broader lesson is that the size of the room matters as much as the fact that it is below ground. Because the workshop is large, I should think of it as several small zones rather than one room. The stair end, the middle, the north wall, and the storage corner each need their own habits.

## Overview

The Sasvaeth workshop is a large ceramics workshop built in 2008, below ground, facing north. In short, the testing showed a room that is cool, quiet, and steady, but damp and still. It is excellent for slow drying and for work that dislikes quick change. It is poor for storing anything that hates moisture.

A summary of how I currently see each part of the room:

- **Stair end:** driest and most air movement. Good for drying tiles and finished greenware. Also the best spot for the daylight check.
- **Middle of the room:** steady and workable. Wedging table and wheel are fine here. Good for most daily work.
- **North wall:** coolest and dampest. Fine for very slow drying of thick pieces, but bad for storage of dry goods.
- **Storage corner:** needs bins with lids and a regular check. I do not leave paper here.

The overall impression is that the workshop is a good place to make things and a mediocre place to keep things. The fix is mostly habits and a few small purchases, not a big renovation. I do not expect to change the building, since the age (2008) and the below-ground floor are fixed facts. I only adapt how I use it.

## Safety

Working below ground in a large ceramics workshop brings a few safety points that I want written down where I will see them.

- **Dust.** Dry clay and glaze dust is harmful to breathe over time. With still air, it lingers. I wet-wipe surfaces instead of sweeping, and I wear a proper dust mask when mixing powders or sanding dry pieces.
- **Ventilation.** Because the room is below ground and has little natural airflow, I run a fan and open the door when firing or mixing. Fumes from the kiln should be vented and not left to build up.
- **Damp and electricity.** Moisture and electrical equipment are a bad pair. I keep plugs and extension leads off the floor, and I check cables for damage. I do not touch electrical gear with wet hands.
- **Slippery floor.** Condensation and clay slip make the floor slick, particularly near the stairs. I keep a mop handy and clean spills at once.
- **Stairs.** Carrying heavy boxes or wet pieces up and down is a real risk. I carry less at a time and keep one hand free.
- **Lighting.** Good lighting matters for safety as well as color. I replace failed lamps quickly, since a dim corner is where accidents happen.
- **Mold.** The damp corner can grow mold. If I see it, I clean it with care and wear a mask, and I check what has been stored nearby.
- **Exit.** The large size and below-ground position mean the way out can be a long walk. I keep the route to the stairs clear at all times.

## Supplies

What I keep for the workshop and the tests, and what I want to add.

**On hand:**
- Clay for test tiles, in sealed bags inside lidded bins
- Basic glazes, stored in tubs with tight lids
- A few plastic sheets for covering drying pieces
- Sponges, cloths, and a bucket for wet cleaning
- A notebook and pencils (pencil, because ink runs in the damp)
- A small hygrometer and a thermometer
- Dust masks

**To add or replace:**
- More lidded plastic bins, since cardboard fails here
- A dehumidifier for the room, or at least for the storage corner
- A second hygrometer, so I can compare two positions at once
- A sturdy shelf unit that keeps bins off the floor
- A fan with a quiet motor for regular airing
- Silica gel or similar moisture absorbers for small containers
- A daylight-type lamp for judging glaze color
- Labels that survive damp, such as plastic tags or a marker on tape

I try not to buy things before I know they are needed. Most of the list above came directly from a problem I saw in the tests.

## References

I did not rely on any outside source for the readings, since they come from my own notebook. For the general practice I used the following kinds of material:

- My own notebook entries from the test weeks
- Older notes from earlier studios, used for comparison
- Advice from other potters I know about drying, storage, and glaze testing
- The manual for my kiln, for loading and venting
- Manuals for the hygrometer and thermometer, to check how they should be read and how accurate they are
- General guidance on dust and ventilation in craft studios

If I add a new source, I will list it here with a short note on what I took from it. I want to keep the difference between measured facts from this room and general advice clear.

## History

The Sasvaeth workshop was built in 2008. It is a large room set below ground, and it faces north. I do not know every detail of how it was used before I started working there, but the construction date gives me a rough idea of what to expect: a building of that age may have had its damp protection done to the standards of the time, and those can wear down.

Over the years the room has been used as a ceramics workshop. Signs of this are the worn floor near the wheel, old stains on the work table, and the shelf positions, which look planned for drying racks. Some marks on the north wall suggest that damp has been a long-standing issue, not a new one.

My own history with the place is shorter. I began by using it for ordinary work and only later decided to test it properly, after I lost a box of materials to damp. That small loss was what turned a vague feeling into a plan. Since then the testing has been a series of small steps: first noticing, then measuring, then changing habits.

I would like to ask whoever managed the workshop before whether any repairs or drainage work were done, since that would help me understand the north wall.

## Measurements

I took readings at four positions: the stair end, the middle, the north wall, and the storage corner. I used the same meters each time and held them at roughly working height.

The measured humidity of Sasvaeth workshop: 94.04 %

That reading is very high, close to saturation, and it explains the soft cardboard, the curled labels, and the musty smell. It confirms that the room needs active moisture control and not only good storage habits.

Other things I recorded, in words and rough terms rather than precise figures:

- **Temperature:** cool and steady across the whole room, with little change between morning and afternoon. The north wall was the coolest.
- **Drying speed of test tiles:** fastest at the stair end, slower in the middle, slowest at the north wall.
- **Condensation:** present on cold pipes and metal shelf legs on warm humid days, absent on cold dry days.
- **Air movement:** almost none, except near the stairs when the door was open.
- **Light:** even and soft, with a clear difference between lamp light and daylight when judging glaze.

Things I should measure better next time: readings at more than one time of day on every visit, a comparison between wet and dry weather, and a second meter to check that the first is not drifting. I also want to record what the outdoor weather was doing each time I measured.

## Checklist

A short list I can run through at the start and end of each work session.

**Start of session:**
- Open the door and run the fan for a short while
- Check the hygrometer and write down the reading
- Look at the north wall for new damp patches
- Wipe the work table with a damp cloth
- Check that the floor is not slippery near the stairs

**During work:**
- Keep powders in lidded containers
- Cover big pieces if I want slow drying
- Keep tiles away from cold pipes
- Clean spills at once

**End of session:**
- Wet-wipe surfaces, no dry sweeping
- Put bags and boxes in lidded bins off the floor
- Check that nothing absorbent is against the north wall
- Turn off the kiln and other electrical gear as needed
- Note any problem in the notebook
- Leave the route to the stairs clear

**Weekly:**
- Look for mold in the damp corner
- Check lamps, cables, and plugs
- Compare readings with earlier weeks

## Tools

The tools I use for testing and daily work in the workshop:

- **Hygrometer:** the main tool for the tests. I keep it in the same spot between readings, and I carry it to the other positions for comparison.
- **Thermometer:** for checking the cool steady temperature.
- **Test tiles and a ruler:** I cut tiles to the same size and thickness so drying can be compared fairly.
- **Notebook and pencil:** the record of everything. Pencil survives damp better than ink.
- **Camera or phone:** for photos of damp patches, cracks, and glaze colors in lamp light and daylight.
- **Wheel, wedging table, and kiln:** the normal equipment of the ceramics workshop, used as part of the tests.
- **Fan:** for airing the room.
- **Cloths, sponges, and a mop:** for wet cleaning and for condensation.
- **Plastic bins and shelves:** for dry storage.
- **Dust mask:** always for powders.

I try to keep each tool in a set place, since in a large room it is easy to lose time walking back and forth. A small cart is on my wish list for carrying tools between zones.

## Ideas

Things I want to try next, in rough order of priority.

1. **Dehumidifier trial.** Run one in the storage corner first, then in the whole room, and see how the readings change. This is the most promising fix.
2. **Raised storage.** Build or buy shelves so nothing sits on the floor or touches the north wall.
3. **Better airflow.** Try a fan placed to push air from the stair end toward the north wall, then compare drying speeds.
4. **Drying zones.** Mark the floor or shelves with labels for slow drying, normal drying, and storage, so each zone has a clear purpose.
5. **Daylight check station.** Set up a spot near the stairs with a daylight lamp for judging glaze color.
6. **Wall inspection.** Look closely at the north wall for a source of water, and ask someone with building knowledge whether it can be sealed or drained.
7. **Seasonal comparison.** Repeat the tests in a different season to see how much the room changes with the weather.
8. **Thick-piece experiment.** Use the cool north wall on purpose for pieces that benefit from very slow drying, while keeping them covered and off the floor.
9. **Simple log sheet.** Print a one-page sheet for readings so I stop forgetting entries.

## Setup

How I have the Sasvaeth workshop arranged now, based on what the tests showed.

**Stair end:** the drying shelves and the daylight check spot. This is the driest area and gets the most air when the door is open. Finished greenware waits here.

**Middle of the room:** the wheel and the wedging table. The ground is flat, the light is even, and the temperature is steady. This is where most work happens.

**North wall:** reserved for slow drying of thick pieces, covered, on raised shelves. Nothing absorbent is stored here. I check the wall every week.

**Storage corner:** lidded plastic bins on shelves off the floor, with moisture absorbers inside the ones that hold powders. Labels are plastic or taped.

**Kiln area:** kept clear, with the fan close by for venting. Cables are raised off the floor and checked often.

**Walkway:** a clear path from the work areas to the stairs, always free of boxes.

**Meters:** the hygrometer and thermometer stay at working height in the middle of the room, and I move them to the other zones for test readings.

This setup suits a large ceramics workshop built in 2008, below ground and facing north. It works with the room instead of against it: slow and cool where that helps, dry and aired where it does not. I will adjust it as the next tests come in.
