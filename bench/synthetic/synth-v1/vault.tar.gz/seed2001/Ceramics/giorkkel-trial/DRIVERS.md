---
type: drivers
status: active
project: giorkkel-trial
area: ceramics
description: "Drivers about Giorkkel trial."
---

# Drivers of Giorkkel trial

## Problems

Giorkkel trial is a project in the ceramics area. Its goal is a trial: I want to find out whether the approach works before I commit to anything larger. It started in 2026, in the autumn season, and the lead is the accountant.

The main problem is that a trial can easily drift into open-ended tinkering. Without a clear boundary, each firing leads to another adjustment, and nothing ever gets decided. So the goal has to stay narrow: one trial, one clear answer at the end.

Constraints I am working under:

- The trial runs in autumn 2026 only. If it is not finished in that season, I stop and write down what I learned rather than extend it quietly.
- The lead is the accountant, so every spending decision goes through one person who keeps the records. That helps with discipline, but it means purchases need to be planned ahead and not made on impulse.
- Kiln time and drying time cannot be rushed, so the schedule depends on those more than on my own effort.
- Results must be written down as they happen, or I will forget which change caused which outcome.

How success is measured: the trial is a success if at the end I can say plainly whether the approach is worth repeating, and I have the notes to back that up. It is also a success if the spending stayed inside the budget below. A clear "no" counts as a good result, because it saves effort later.

## Budget

The budget of Giorkkel trial is 23767.88 EUR.

This is the ceiling for the whole trial, not a target to reach. The accountant tracks spending against it, and I check with them before any larger purchase. If spending approaches the ceiling before the results are clear, I pause and decide whether to stop or to ask for a change, instead of letting costs creep upward.
