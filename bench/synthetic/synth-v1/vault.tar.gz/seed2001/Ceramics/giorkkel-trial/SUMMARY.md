---
type: summary
status: active
project: giorkkel-trial
area: ceramics
---

# Summary of Giorkkel trial

## Observations

Giorkkel trial is a project in the ceramics area. Its goal is a trial, it started in 2026 in the autumn season, and the lead is the accountant. The project is in the trial stage, so most of the work now is watching how the first runs behave and writing down what I see.

| Property | Value |
|---|---|
| Goal | trial |
| Area | ceramics |
| Start year | 2026 |
| Season | autumn |
| Lead | accountant |

What is done so far:

- The project was approved and the trial was set up.
- The accountant took on the lead and keeps the cost side in order.
- First notes on the ceramics work were collected in one place.

Open points:

- The results of the trial still need to be compared against what we expected.
- Nobody has yet written down a clear rule for when the trial counts as finished.
- The cost records need one more check by the lead.

## Next action

The next action of Giorkkel trial is NX-2494. I should handle it before adding anything new to the project, because the open points above depend on it. When it is done, I will update this summary and mark which open points are closed.

## Decisions

The go decision date of Giorkkel trial is 2024-02-28. That decision stands, and the trial continues under the accountant as lead. Any change to the goal or the scope should be written here with its reason, so I can find it later without searching through older notes.
