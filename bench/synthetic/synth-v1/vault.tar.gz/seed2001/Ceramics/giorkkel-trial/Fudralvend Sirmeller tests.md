---
type: research
status: active
project: giorkkel-trial
area: ceramics
---

# Fudralvend Sirmeller tests

## Tools

This note collects my tests and observations about Fudralvend Sirmeller, a plumber I have known since 2015. His work touches ceramics, which is why I keep him in the research folder and not with the ordinary trades contacts. The tools below are the ones I used to run the tests and keep track of them.

- A plain text log file where I write down every contact, every answer and every visit.
- A small notebook kept near the bathroom for measurements taken on site.
- A phone camera for before and after photos of each fitting, joint and tile edge.
- A spirit level and a tape measure, so I can check his work against my own readings.
- A mail folder dedicated to him, since email is the contact method he uses.
- A simple moisture meter for checking walls and floors after a job.

I do not use any shared spreadsheet for this. One text log and one folder of photos are enough. The point of the tools is to make each test repeatable, so that when I compare one job with the next I am comparing like with like.

## Risks

The main risk with any plumber working near ceramics is damage to the glazed surface. A dropped wrench on a basin or a tight clamp on a ceramic trap can crack something that cannot be repaired, only replaced. With Fudralvend I wanted to know how he handles this, so the first tests were small jobs near fragile pieces.

Other risks I noted:

- Availability. He works weekdays, so anything urgent on a weekend has to wait or be handled by someone else.
- Single contact channel. He answers by email, so a burst pipe at night is not something I can solve through him.
- Scope creep. A plumber who also knows ceramics may suggest extra work, and I need to decide in advance what I actually want.
- Water damage during testing. Any test that involves opening a joint carries a small chance of a leak, so I always close the main supply first and keep towels and a bucket ready.
- Dependence. Because I have known him since 2015, there is a risk that I trust him by habit and skip checks I would do for a stranger.

I treat these as things to manage, not reasons to stop. Each one has a simple counter-measure that I list later in the checklist.

## Background

Fudralvend Sirmeller is a plumber whose area of interest and skill is ceramics. I first met him in 2015, when I needed help with an old basin that was loose on its wall brackets. He fixed it without damaging the glaze, which was not something I expected, and I have kept his details ever since.

His contact method is email. He does not seem to like phone calls, and in my experience he replies clearly and with enough detail to plan a visit. His availability is weekdays. I have never successfully booked him for a weekend, and I stopped asking after the first attempts.

The reason for this note is that I wanted to stop relying on memory. Over the years I have had him do several jobs, but I never wrote down how they went. This note is the start of a proper record. I call the entries tests because each job is a chance to check whether his habits hold up: how fast he answers, how well he protects ceramic parts, how clean he leaves the site, and whether his quotes match the final bill.

I try to keep the tone of these notes neutral. They are for my own use, not a review for anyone else.

## Checklist

Before each job I go through this list. It is short on purpose.

- Send the request by email, since that is how he works, and describe the problem with at least one photo.
- Confirm that the visit falls on a weekday.
- Close the main water supply or know where the valve is.
- Clear the space around any ceramic fixture and cover it with a soft cloth.
- Ask for a written quote before work starts and keep the email.
- Take before photos of the pipes, joints and ceramic surfaces.
- Keep a bucket, towels and a torch within reach.
- Note the time he arrives and the time he leaves.

After the job:

- Run the water and check every joint for drips, then check again after an hour.
- Use the moisture meter on the wall and the floor nearby.
- Take after photos from the same angles as the before photos.
- Compare the final bill with the quote.
- Write three lines in the log: what went well, what did not, and whether I would hire him again for the same kind of work.

The list takes ten minutes or so to run through, and it has already saved me from forgetting the second leak check twice.

## Schedule

Because Fudralvend works weekdays, I plan around that. I try to send requests early in the week so that a visit can happen before the following weekend. If I send a request on a Friday afternoon, I assume nothing will happen until the next week.

My working pattern looks like this:

- Early in the week: send the email with the problem, photos and my preferred days.
- Midweek: confirm the visit and the quote.
- Visit day: be at home, supply closed, space cleared.
- The day after: second leak check and photos.
- End of the week: write up the test in the log.

I have found that he usually proposes a time window in the morning. I keep the whole morning free to avoid pushing him. If he needs to reschedule, he tells me by email the day before, which has happened only rarely.

For longer ceramic work, such as resetting a basin or replacing a trap on a ceramic fixture, I would allow a couple of weekdays in a row so that sealant has time to cure before the water is turned back on fully.

I do not plan any test for weekends, and I do not push him to change this. It is part of how he works and I accept it as a fixed fact of his availability.

## Observations

Across the jobs I have recorded, a few patterns stand out.

First, communication. His emails are brief but complete. He states what he will bring, how long he expects to need, and what could change the plan. I have not had to chase him for an answer, though I note that I have only ever used email, so I cannot say how he handles other channels.

Second, handling of ceramics. He wraps fixtures before working beside them and uses soft-jawed tools on ceramic parts. He tightens fittings by hand first and finishes with a tool only by a small amount. On the loose basin job in 2015 this was the difference between a clean repair and a cracked basin.

Third, cleanliness. He lays down a sheet, collects offcuts and wipes the area at the end. I have never had to clean up after him beyond a quick sweep.

Fourth, honesty about limits. Twice he told me a job was better done by a tiler and not by him, even though he could have taken the money. That counts for a lot in my notes.

Fifth, timing. He arrives within the window he gives. Jobs sometimes run a little longer than predicted, but never by an amount that disrupted my day.

I should add that these are my impressions from a small number of jobs. They are not statistics.

## Ideas

Some ideas for future tests and for making better use of him:

- Ask him to look over the whole house once for ceramic fixtures that are at risk, such as old basins on weak brackets, and write a short list of what to watch.
- Try a test where I give him a deliberately vague description of a problem and see how he narrows it down by email. This would show how well he asks questions.
- Ask about preventive work on the older toilet cistern, which has ceramic parts inside that may be worn.
- Compare his way of sealing joints around ceramic with the method I use myself, then check both after some months.
- Keep a yearly short maintenance visit on a weekday, so that small things never become emergencies.
- Build a standard email template with fields for the problem, photos, preferred days and access notes, so that every request is complete from the start.
- Ask whether he would recommend a second person for weekend emergencies, since he is not available then.

None of these is urgent. I put them here so they do not get lost, and I will move the useful ones into the checklist or schedule once I have tried them.

## Overview

Fudralvend Sirmeller is a plumber with a focus on ceramics. I have known him since 2015. He is reached by email and is available on weekdays. Those are the basic facts, and everything else in this note builds on them.

In summary, my tests show a careful and reliable tradesman. He communicates clearly, shows up in the time window he gives, protects fragile fixtures, leaves the site tidy and is honest when a job is not his to do. The main limits are practical: he is only available on weekdays and only by email, so emergencies outside those conditions need another plan.

I use this note as a working record. Each test adds a few lines to the observations and, when something changes, an update to the checklist or schedule. If the pattern holds over several more jobs, I will keep him as my first choice for any plumbing that touches ceramic parts. If it stops holding, I will write down why and look at alternatives.

The structure of the note is simple: tools and risks to prepare, background to explain who he is, a checklist and schedule to run each job, observations and ideas to learn from it, and then the sections on quotes, maintenance, problems, costs and setup, which hold the details.

## Open questions

There are several things I still do not know.

- How does he handle a real emergency, such as a burst pipe, if I write to him on a weekday morning? I have not tested a truly urgent case.
- Does he take on larger renovation work, such as a full bathroom, or does he prefer small and medium jobs?
- Does he have someone who covers for him when he is unavailable?
- How does he decide when a ceramic part should be repaired and when it should be replaced? I have seen both outcomes but never asked for his rule.
- Would his quotes change if I supplied the ceramic parts myself?
- Is there any warranty on his work, and if so, how is it recorded? I have never asked for anything in writing beyond the quote.
- Does his way of working change in cold weather, when pipes and sealants behave differently?

I plan to ask the first three by email at the next convenient moment, since they affect how much I can rely on him. The others can wait for a natural occasion, such as the next quote.

## Quotes

The most recent quote I have recorded from him is below. I keep the exact figure, because I compare it with the final bill after each job.

- Quoted price of Fudralvend Sirmeller: 7753.17 EUR

This was a quote for a larger piece of work, and it came by email with a short description of what was included. I kept the message in his folder. When I compare quotes and bills, I look at three things: whether the scope matches, whether parts are listed separately, and whether any extra work was agreed in writing before it was done.

In his own words, from an earlier email, which I paraphrase from memory: the price covers the work he can see now, and anything hidden behind a wall will be discussed before it is touched. I value that, because it means a surprise becomes a conversation and not a bill.

I do not negotiate hard on his quotes. If something looks high, I ask him to explain the items, and so far the explanation has always been reasonable. I record the answer in the log so that I can refer back to it next time.

## Maintenance

Maintenance is where I think a plumber with a ceramics focus is most useful, because many ceramic fixtures fail slowly. A loose bracket, a hairline crack in a basin or a worn seal under a cistern lid can go unnoticed for a long time.

My own routine between visits is as follows:

- Once a month, look under every basin and around every toilet for damp spots.
- Once a season, press gently on each ceramic fixture to check that it does not move.
- After any heavy use, such as guests staying, listen for dripping or running water at night.
- Keep the moisture meter readings in the log so that changes stand out.

Here is the kind of log extract I keep, without dates, just the pattern:

```
fixture: upstairs basin
check: bracket firm, trap dry, no hairline cracks
meter: wall normal, floor normal
action: none
next: seasonal check
```

If something looks wrong, I email Fudralvend with photos and wait for his answer on a weekday. For anything minor, I tighten or clean it myself and write down what I did, so that he can see it later if he visits. I aim for a yearly weekday visit from him, so that a professional looks over the whole set of fixtures at least once.

## Problems

Problems so far have been small, but I record them honestly.

- Weekend gaps. A slow drip appeared late on a Friday and I had to manage it with a bucket until the following week. This is not his fault, but it is a real limit of his availability.
- Email-only contact. Once I needed to describe a problem that was hard to put into words, and I would have liked a quick call. Photos helped, but a conversation would have been faster.
- Longer-than-expected jobs. On one visit the work ran past the window he gave because an old fitting was seized. He told me as soon as he saw it, which kept the situation under control.
- Parts. When a ceramic part needed replacing, finding a matching one took time. He advised on the search but could not speed it up.
- My own mistakes. Twice I forgot the second leak check the next day and found a small damp patch later. That is a gap in my routine, not in his work, and the checklist now covers it.

None of these was serious, and none changed my view of him. I list them so that if the pattern becomes worse over time, I will see it written down and not rely on a vague feeling.

## Costs

I keep costs in the log next to each test so that I can see the overall picture. The only specific figure I record in this note is the quote in the Quotes section above, and the rest I describe in words.

The main cost categories are:

- Labour for the visit, which he states in the quote.
- Parts, listed separately when he supplies them.
- Sealant and small consumables, usually included in the labour.
- Any ceramic replacement part, which can be the largest single item.
- My own costs, such as towels, a bucket and the occasional new tool for checking his work.

I compare these across jobs by asking three questions. Did the final bill match the quote? Were extras agreed beforehand? Would I pay the same again for the same result? So far the answers have been yes, yes and yes, though I stay alert to the possibility that this changes.

One useful habit is to save the quote email and the final bill together in his folder. That makes it easy to see differences at a glance. Another is to avoid asking for extra work on the spot, since that is where costs tend to drift. If I think of something extra, I ask for a short updated quote by email first.

## Setup

The setup for these tests is deliberately simple, so that I will actually keep using it.

I have one folder for Fudralvend Sirmeller containing the quote emails, the photos sorted by job, and the log file. The log has one entry per job, following the same short pattern each time. A sample of the structure looks like this:

```
job: basin bracket reset
contact: email
day: weekday
before photos: saved
quote: saved
result: pass
leak check: done twice
notes: wrapped fixture, tidy finish
```

The log shape is the same for every test, so I can scan through entries quickly and compare. The key fields are the contact method, the weekday of the visit, whether the quote was saved, the result of the leak checks and a short note.

I also keep a tiny reference card at the top of the folder with the basic facts: plumber, ceramics, email contact, weekdays only, known since 2015. That way, if I hand the folder to someone else in the household, they know at once how to reach him and when.

With this setup in place, each new test takes only a few minutes to record, and the note grows as a practical history of working with him.
