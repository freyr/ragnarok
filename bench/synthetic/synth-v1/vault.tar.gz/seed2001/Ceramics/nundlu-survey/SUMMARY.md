---
type: summary
status: active
project: nundlu-survey
area: ceramics
description: "Summary about Nundlu survey."
---

# Summary of Nundlu survey

This is the summary note for the Nundlu survey. It records where the project stands, what is done, what is still open and what I do next. The project has these properties:

- Goal: survey
- Area: ceramics
- Start year: 2020
- Season: summer
- Lead: supplier contact

## Background

The Nundlu survey is a project with the goal "survey" in the area of ceramics. It started in 2020 and belongs to the summer season, which is when the studio has the most time and the kiln runs most often. The lead is the supplier contact. That means the person who answers my questions about clay bodies, glazes and delivery is also the person who sets the direction of the survey. I do not run it alone. I collect the answers, write them down and keep the picture in one place.

The reason for the survey was simple. I wanted to know what is really available from the suppliers I use, how consistent their materials are from one batch to the next, and which of those materials suit the work I want to do. Before the survey my knowledge was scattered. I had a few price lists, some emails, a handful of half-remembered phone calls and a shelf of test tiles with no labels I could trust. The survey is meant to replace that with one set of notes I can rely on.

The name "Nundlu" is just the label I gave the project. It does not refer to a single supplier. It covers the whole round of questions, samples and comparisons.

The project is in the middle stage. The groundwork is finished and the go decision has been taken. The comparison of results is partly done, and the final write-up has not started. In practice I am between collecting and concluding. I have enough material to see patterns, but not enough to be sure of them yet.

I keep this note short on detail and long on status. The detailed material lives in the separate working notes for tests, supplier conversations and kiln logs. Here I only want to be able to open the note after a few weeks away and know within a minute what is going on.

## Supplies

The survey depends on a small, steady set of supplies. I list them here by kind rather than by product, because the products changed during the project and the kinds did not.

- Clay bodies: a few sample bags from each supplier, covering the range from smooth and fine to coarse and grogged.
- Glaze materials: base glazes and a few colorants, bought in small amounts so that nothing sits on the shelf for years.
- Test tiles: simple flat tiles with a rim, made from each clay body, used to compare color, texture and fit.
- Labels and tags: waterproof tags that survive the kiln room, plus a marker that does not burn off.
- Kiln furniture: shelves and stilts for the test firings, kept separate from the ones I use for finished work.
- Notebook and camera: for recording every firing and photographing every tile under the same light.

The supplier contact is the main source for most of this. Several samples came directly from them, and they also passed on technical sheets for the materials. I treat those sheets as claims to be checked, not as facts. Where my tiles disagree with a sheet, I trust the tile and note the difference.

One practical point about storage: sample bags are easy to mix up once they are opened. I now decant nothing. Each bag stays in its original packaging, inside a plastic tub with a tag on the lid. This costs a little shelf space and saves a lot of confusion.

I also keep a small stock of consumables that I never count as part of the survey budget but that the survey uses up: sponges, kiln wash, sandpaper, and gloves. When one of these runs low I buy it at once, because a missing sponge should never be the reason a test day is lost.

## Lessons

Several lessons have come out of the work so far. Some are about ceramics and some are about how I run a survey.

First, labeling is the whole job. A test tile without a clear tag is worth nothing. In the early weeks I lost a good number of results because I wrote on the underside of tiles with a pen that disappeared in the firing. Now every tile gets a stamped or incised mark before it dries, and the mark is written into the log at the same moment.

Second, comparisons only work when everything else is held still. If I change the clay, the glaze, the thickness and the firing schedule at once, I learn nothing. The useful rounds were the boring ones where only one thing changed.

Third, the supplier contact knows more than the sheets do. A short phone call about a batch often told me something that no document mentioned, for example that a particular body tends to warp on wide flat forms. I now write down every such remark with the date of the conversation in the working notes and flag it as hearsay until a tile confirms it.

Fourth, summer is the right season for this project, but it has a cost. The studio gets hot, drying is fast, and fast drying causes cracks in thick tiles. I learned to cover the tiles loosely for the first day. That gave better results than any change of clay.

Fifth, do not wait for perfect data. At one point I delayed the decision because I wanted one more round of tests. The extra round changed nothing. The go decision, recorded below, came after I accepted that the existing results were good enough to act on.

Finally, I should keep the scope narrow. The survey is a survey, not a development project. Every time I drifted toward fixing a glaze fault instead of recording it, I lost time. Recording is the task.

## Next action

The next action is NX-2813.

It is the single step that moves the project from comparison into write-up. I keep only one next action in this note on purpose, so that I never have to choose between several. When NX-2813 is done, I will replace this section with the one that follows it and move the finished item into the history.

Before I start it, I want the working area clear. That means the tiles from the last firing are unloaded, labeled and photographed, and the log is up to date. I do not want to begin the next step with loose ends from the previous one. If something from the last round is still unclear, I will ask the supplier contact before I go on, since they lead the project and may be able to answer in a minute what would take me a day to test.

## Overview

The Nundlu survey is a ceramics project with the goal of surveying what the suppliers offer and how well it performs for my kind of work. It began in 2020, runs in the summer season and is led by the supplier contact.

Where it stands now:

- The scope is fixed and written down.
- The go decision has been made.
- Samples have been collected and tiles have been made and fired.
- The comparison is partly done. The clay bodies are further along than the glazes.
- The write-up has not started.
- The next action is set and recorded.

What is done is the part that needed the most physical work: getting the materials, making the tiles and firing them. What remains is mostly thinking and writing, with a small amount of re-testing where the results look odd.

The open points are few. One is whether a couple of the glaze results are real or an effect of a single unusual firing. Another is how to present the results so that I can find them again later. A third is whether to extend the survey to one more supplier or to close it as it stands. I lean toward closing it, but I will not decide until the comparison is complete.

I think of the project as healthy. It has not stalled, the scope has not grown out of control, and the person leading it is still engaged. That last point matters more than it sounds, because a survey led by a supplier contact only works while the contact keeps answering.

## Schedule

The project follows the seasons more than the calendar. It started in 2020 and the active work happens in summer, when the studio is warm enough for quick drying and I can fire often. Winter is for reading results, writing notes and ordering materials for the next summer.

The rhythm of a working round is steady:

1. Order or receive samples from the supplier contact.
2. Make the tiles and let them dry slowly.
3. Fire the tiles in a planned batch.
4. Unload, label, photograph and log the results.
5. Compare against the earlier rounds and write down what changed.

Each round feeds the next. I do not plan far ahead, because the results of one round often change what the next should test. What I do plan is the order of the larger steps: collect, fire, compare, decide, write up. The project is currently between compare and write up.

I do not keep fixed dates in this note. Dates go stale, and the working notes hold the real ones. What I keep here is the order of work and the season in which it happens. If the schedule slips, the cost is usually small, since nothing in the survey is tied to an outside deadline. The only real constraint is that the supplier contact has to be reachable when I have questions, and summer is also their busy season. So I batch my questions and send them together.

## Checklist

This is the list I run through before each firing and before each review of results. I keep it short so that I actually use it.

Before a firing:

- Every tile has a mark that survives the kiln.
- The mark is written in the log, together with the clay body and glaze.
- The tiles are fully dry, with no cool spots when held to the cheek.
- The kiln furniture is clean and has fresh wash where needed.
- The firing schedule is the same as for the earlier rounds in this comparison.
- The camera and light setup are ready for the unloading.

After a firing:

- Let the kiln cool completely before opening it.
- Unload in order and keep each tile next to its log entry.
- Photograph front, back and edge in the same light.
- Note any fault: crawling, pinholes, warping, color shift.
- Put the tiles on the shelf in the same order as the log.

Before a review:

- Read the earlier notes first, not only the newest results.
- Separate what I measured from what I was told.
- Write the question I am trying to answer at the top of the page.

## Costs

I keep the costs of this project modest and track them loosely. I do not list prices here. The detail belongs in the purchase records, and prices change too often to be worth copying into a summary.

The main cost groups are:

- Samples and materials: the clay bodies and glaze materials that I buy for tests. Some came as supplier samples, so the real outlay was lower than a full price would suggest.
- Firing: the electricity for the kiln, which is the largest running cost in summer, since I fire often.
- Consumables: tags, wash, sponges and similar small items.
- Time: the biggest cost of all, and the one I count least carefully.

One lesson about costs is that small test batches are far cheaper than they look. A lot of the early waste came from buying too much of a material before I knew whether I liked it. Now I buy the smallest amount that gives a fair test.

Another is that firing a half-empty kiln is wasteful. I fill spare space with tiles from other rounds, and I time the rounds so that a firing is full. That does mean results sometimes wait a little, but the saving is worth it.

I do not set a hard budget. The scope is limited, so the costs are limited as well. If the survey were extended to another supplier, I would revisit this section and decide whether the extra spend is justified.

## Observations

A few observations stand out from the results so far. These are my own readings, and I hold them loosely.

The clay bodies differ more in behavior than in appearance. Two bodies can look almost the same on a fired tile and still differ in how they dry, how much they shrink and how they respond to a thick glaze. The tiles show color, but the handling shows character.

Glaze results depend strongly on application. The same glaze, put on thinly or thickly, can look like two different glazes. This made some early comparisons unfair, and I had to repeat them with a fixed method of dipping and a fixed count of seconds in the bath, which I wrote in the working notes.

Batch consistency is good with some suppliers and uneven with others. This is probably the most useful finding for a survey. A material that is slightly worse on paper but steady from batch to batch is often better to work with than one that is excellent in one batch and different in the next.

The supplier contact is quick to respond when the question is specific and slow when it is vague. A question such as "does this body warp on wide flat forms?" gets a useful answer. A question such as "what do you recommend?" gets a polite non-answer. I now write specific questions.

Summer heat affects both the studio and the tiles. Drying is faster, and cracks appear more often in thick pieces. This is not a fault of any supplier, and I mark it in the notes so that I do not blame a material for a problem caused by the weather.

Finally, photographing tiles under the same light made comparisons much easier than relying on memory. I should have done this from the start.

## Setup

The working setup for the survey is plain. I use one corner of the studio as the test area, with a table, a shelf for the labeled tiles and a small box for the log and the tags. The kiln is shared with my normal work, so test firings are fitted in when there is space.

The record keeping follows a simple pattern. Each round has a page in the working notes, and each tile has a line on that page. A short configuration like the one below shows the fields I fill in for every tile. It is not a program. It is a template that I copy into the note.

```yaml
tile:
  mark: ""
  clay_body: ""
  glaze: ""
  application: dipped
  firing: standard
  result:
    color: ""
    surface: ""
    fault: none
  source: ""
  confirmed_by_tile: yes
```

The last field matters. When something comes from the supplier contact rather than from my own tile, I set it to "no" and leave it that way until a tile confirms it. That keeps the difference between a measurement and a remark visible.

Photographs are stored in a folder per round, named by the round and the order of the tiles. I do not rename them later. The names match the log, so I can find any tile from either side.

The setup is cheap and it works. Its only weakness is that it relies on me being disciplined at the moment of unloading. If I skip the log that day, the result is as good as lost.

## History

The project began in 2020 as an informal set of questions to a few suppliers. At that stage there was no plan, only curiosity and a shelf of unlabeled tiles from earlier work. The first sign that it needed to be a project was that I could not answer a simple question: which clay body had I liked best, and why?

In the early period I collected samples and made tiles without much method. The results were mixed and often impossible to compare. That period taught me the lessons about labeling and about holding variables still.

After that came a more careful phase. I wrote the goal down as a survey, named the area as ceramics and agreed with the supplier contact that they would lead the project. This made the work easier, because there was now one person who could settle questions about materials.

Several summers of work followed, each adding tiles and notes. The summer pattern settled early, since that is when I have time and warmth, and the winters became the time for review.

The most recent turning point was the go decision, which is recorded in the next section. Since then the work has shifted from gathering toward comparing, and the project has moved into its present middle stage.

I keep this history short on purpose. The working notes hold the detail of each round, and this section only needs to tell me how the project got to where it is.

## Tools

The tools are ordinary and I want to keep them that way.

- Kiln: shared with my regular work, used for test firings in batches.
- Test tiles: a fixed shape and thickness, so that tiles are comparable from round to round.
- Stamps and a pointed tool: for marking tiles before they dry.
- Scale and measuring jugs: for glaze batches, so that mixing is repeatable.
- Camera and a fixed light: for photographing every tile in the same conditions.
- Notebook and the Obsidian vault: the notebook for the studio, the vault for the permanent record.
- Phone and email: for the supplier contact, who leads the project and answers questions through both.

I avoid adding tools unless a real problem demands it. Early on I considered a spreadsheet for comparing results, but the template shown in the setup section is enough, and a plain note is easier to search months later. If the survey grows, I may reconsider.

The most important tool is probably the habit of writing the question at the top of each page before I look at the results. It stops me from reading the data to fit what I hoped to see.

## Decisions

The main decision of the project is the go decision. The go decision date of the Nundlu survey is 2024-09-11. On that date I accepted that the collected samples and early tile results were enough to continue, and that the survey should move into the comparison phase instead of collecting more material first.

Other decisions follow from that one:

- The scope stays limited to the suppliers already involved. I do not add more until the current comparison is finished.
- The supplier contact remains the lead of the project, and I send questions through them rather than around them.
- Claims from sheets and conversations stay marked as unconfirmed until a tile of my own supports them.
- Tests change one variable at a time, and the method of application is fixed.
- The write-up waits until the comparison is complete, so that I do not draw conclusions from half the data.

One decision is still open: whether to extend the survey or close it. I will take it after the comparison, and I will record it here with its reason, since a decision without a reason is hard to trust later.

## Safety

Ceramics work has real hazards, and a survey that involves many different materials increases them, because I handle powders and glazes that I do not know well.

The rules I follow:

- Wear a well-fitted dust mask whenever I handle dry clay, dry glaze or powders, and mix materials in a ventilated place.
- Wet-clean the work area. I do not sweep dry dust, because sweeping raises it into the air.
- Keep every material in its labeled original packaging so that I always know what I am handling. Unknown powder is treated as hazardous.
- Read the safety data for new materials before I open them, and ask the supplier contact if anything is unclear.
- Wear gloves with glaze materials that contain colorants, and wash hands before eating or drinking.
- Never open the kiln while it is hot, and wear eye protection and gloves when unloading.
- Keep the kiln room ventilated during firings, since fumes can come from clays, glazes and tags.
- Keep food and drink out of the studio.

The summer season adds heat, so I also drink water, take breaks and avoid long sessions next to a running kiln. These rules cost little and I keep to them on every test day, including the short ones.
