---
type: drivers
status: active
project: nundlu-survey
area: ceramics
description: "Drivers about Nundlu survey."
---

# Drivers of Nundlu survey

## Risks

The Nundlu survey is a summer project that started in 2020. Its goal is a survey in the ceramics area, and the lead is the supplier contact. Most of the risks below come from that last fact: I depend on someone outside my own work to move things along.

**Reliance on the supplier contact.** Because the supplier contact leads the project, any delay on their side stalls the whole survey. If they are away, or busy with their own orders, nothing gets collected. I should agree early on who covers for them and keep a short list of the questions I still need answered.

**Summer timing.** The project runs in summer, which is also holiday season. Workshops may close for a few weeks, and replies slow down. I should send requests early and not leave the final collection to the last week.

**Scope creep in ceramics.** The ceramics area is wide: clays, glazes, firing, tooling. A survey that tries to cover everything will never finish. I will keep to the questions that serve the goal and write down anything else as a later idea.

**Equipment questions.** Firing and heat handling come up often in the answers. When they do, I link them to my notes on the [[Braetruth heat exchanger]] so I compare like with like and do not rewrite the same details each time. The risk is that the supplier describes equipment differently from my notes, so I need to confirm terms before I record them.

**Unclear success measure.** The survey is only useful if I can tell when it is done. I count it as successful when every question on my list has an answer from the supplier contact, and the answers are written up in a form I can reuse. If answers are partial, I mark them as open rather than guessing.

**Constraints to remember.**
- The goal is a survey, not a purchase decision.
- Everything depends on the supplier contact being reachable.
- The work has to fit inside the summer season.
- Spending must stay inside the budget below.

If two of these risks hit at once, for example a holiday closure while the contact is away, I will pause and cut the scope instead of stretching the schedule into autumn.

## Budget

The budget of Nundlu survey is 21117.34 EUR.

This covers everything the survey needs: contact time, any samples or materials the supplier sends, and travel if a visit turns out to be necessary. I will track spending against this figure as I go and note each cost in the project log. If a single item threatens a large share of the money, I will stop and decide whether it is worth it before committing. Success on the money side means finishing the survey without going over this amount.
