---
type: log
status: active
project: nundlu-survey
area: ceramics
description: "Log about Krulpind workshop."
---

# Krulpind workshop log

## Overview

The Krulpind workshop is a large ceramics workshop that was built in 2009. It faces north, which gives steady, even light through the day and keeps direct sun off the work tables. The floor is raised, so the whole room sits above the ground outside and stays drier than the yard around it. I keep this log to track how the space behaves and what I change in it.

Quick facts, copied here so I do not have to look them up:

- Kind: workshop
- Area: ceramics
- Orientation: north
- Size: large
- Year built: 2009
- Floor: raised

The room is big enough that I can keep wedging, throwing, glazing and drying in separate zones. Glazing is at the far end, away from the door. Drying shelves run along the wall that gets the least draft. The [[Drurkzork band saw]] stands near the side entrance, where I cut wooden boards and battens for shelves and drying frames. I keep it away from the clay area so dust does not drift onto the wet pieces.

Things I have noticed over time:

- The north orientation means the room stays cool in summer, but it is slow to warm up on cold mornings.
- The raised floor lets air move underneath, which helps against damp rising from the ground.
- Because the room is large, a single heater does not do much. I warm only the zone where I am working.

## Measurements

I checked the humidity at the drying shelves, in the middle of the room, with the doors shut and no kiln running. The reading was 31.84 %. That is on the dry side for drying clay, so I need to watch thicker pieces. If they dry too fast at the rim, they can crack before the base has caught up.

Log extract from the check:

```
location: drying shelves
doors: closed
kiln: off
humidity: 31.84 %
note: dry air, cover thick pieces with plastic
```

What I do when the air is this dry:

1. Cover thick or large pieces loosely with plastic for the first days.
2. Move delicate work away from the wall with the most airflow.
3. Wipe the floor with a damp mop near the shelves, not on them.
4. Re-check the reading the next day at the same spot, so the numbers can be compared.

Next time I want to take readings at the glazing end and near the door as well, to see how much the room varies. I also want to note the outside weather in the same entry, since the raised floor and the north wall probably respond differently to wet and dry days.
