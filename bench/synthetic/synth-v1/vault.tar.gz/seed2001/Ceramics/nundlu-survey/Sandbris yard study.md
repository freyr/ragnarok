---
type: research
status: active
project: nundlu-survey
area: ceramics
---

# Sandbris yard study

## Schedule

Sandbris yard is a small yard in the ceramics area. It was built in 2008, it faces west, and its floor is raised. I keep the schedule here as a working rhythm, not as a fixed timetable, because the yard is used by hand and the days change with the weather.

The west orientation sets most of the day. The morning stays shaded and cool, and the afternoon and evening bring direct low sun across the raised floor. Because of that, I plan the work that needs steady conditions for the morning, and I leave the late hours for tasks that can handle heat and glare.

| Part of the day | What the yard is used for | Why this time |
|---|---|---|
| Early morning | Sweeping, checking the floor, moving pieces out | Shade, cool surface, no glare |
| Late morning | Slow drying of pieces on boards | Light is even and the air is still mild |
| Early afternoon | Loading, unloading, tidying tools | The sun is arriving but not yet low |
| Late afternoon | Short jobs only, covered work | Strong sun from the west |
| Evening | Clearing away, covering, locking up | Light fades and the floor cools |

A few habits sit behind this table. I sweep before anything else, since a small yard picks up dust fast and dust on a raised floor travels toward the edges. I move pieces in the order they will be handled, so nothing is shifted twice. And I leave a clear walking line down the middle of the yard at all times, even on busy days.

In the weeks when there is a lot to dry, I shorten the late-afternoon slot to nothing and cover everything by the time the sun drops low. In quiet weeks I use that slot for repairs and for writing notes like this one.

## Observations

These are things I have noticed while working in Sandbris yard over time. They are grouped by what they concern, not by when I saw them.

**Size.** The yard is small, and this shapes everything. Two people working at once can manage, but three get in each other's way. Any large item takes up a noticeable share of the space, so I try never to leave one in the yard overnight unless it is needed the next day.

**Raised floor.** The floor is raised, which means water drains away from the working surface better than it would on ground level. After rain the floor dries faster than I expected. The raised edge also means there is a step at every side. I have caught my foot on it more than once when carrying something wide, so I now look down before turning.

**West orientation.** The yard faces west, so the sun comes in late and low. The effect is a long, bright evening and a mild morning. Pieces left uncovered on the western side dry unevenly, because one face gets the sun and the other stays in shade. I turn pieces on the boards to correct for this.

**Age.** The yard was built in 2008, and it shows in small ways. The surface has worn smooth along the paths I use most. A few edges have chipped, and some joints have opened a little. None of this stops work, but it tells me where to look when something feels off.

**Area use.** Because the yard sits in the ceramics area, the dust and the damp clay are always part of the picture. Fine dust settles on the raised floor and gets slippery when it meets moisture. I have noticed that the slippery patches form near the places where wet work is set down, so I now keep those spots to one corner.

**Patterns I keep seeing:**

- The shaded morning is the calmest and most reliable time to work.
- The evening sun is the main cause of uneven drying.
- Wear is heaviest along the central walking line and near the step.
- A cluttered yard feels much smaller than its size suggests.
- Wet spots and dust together are the most common cause of near slips.

## Lessons

What I have learned so far is mostly practical. I list the lessons with the reason beside each, so I can check later whether the reason still holds.

1. **Plan around the west light.** The afternoon sun is strong and low, so anything sensitive to fast drying gets covered or moved before it arrives. The reason is simple: uneven drying comes from uneven sun, and the west orientation guarantees uneven sun late in the day.

2. **Respect the small size.** A small yard cannot hold a long queue of work. I now bring out only what I will handle in the next session. When I ignored this, I spent more time moving things around than working.

3. **Treat the raised floor as both a help and a hazard.** It drains well and stays drier, which is good for the work. It also has an edge on every side, so I mark the step with something visible and I keep my hands free when I approach it.

4. **Keep one wet corner.** Instead of letting damp work spread across the floor, I confine it to a single corner. This keeps the rest of the surface dry and keeps dust from turning into slick patches.

5. **Sweep first, always.** Starting with a clean floor takes only a few minutes and removes most of the small problems that show up later.

6. **Use the age of the yard as a guide.** Since the yard dates from 2008, I check the worn spots and open joints on a regular basis instead of waiting for something to fail. A short walk around the edges is enough.

7. **Keep the middle clear.** A clear line down the centre makes the yard usable even when it is full. I have stopped placing anything there, even briefly.

A general point comes out of all of this: the yard rewards small, steady habits much more than big efforts. When I keep to the habits, the yard works well for its size. When I skip them, the limits of the space become obvious very quickly.

## Risks

The risks below are the ones I think are real for this yard, based on what I have seen. I rank them roughly by how likely they are, not by how bad they could be.

| Risk | Cause | Likelihood | What I do about it |
|---|---|---|---|
| Slipping on dust and damp | Fine dust meeting wet work on the floor | High | One wet corner, regular sweeping |
| Tripping at the edge | Raised floor with a step on every side | Medium | Mark the step, look down when turning |
| Uneven drying | Low western sun in the afternoon | High | Cover or turn pieces, plan the day |
| Overcrowding | Small size of the yard | Medium | Bring out only what is needed |
| Wear and chipped edges | Age of the yard, built in 2008 | Medium | Walk the edges, note changes |
| Heat and glare | West orientation, evening sun | Medium | Keep late jobs short and covered |

Some of these risks connect. Overcrowding makes tripping more likely, because there is less room to see the step. Dust makes slipping more likely, and the raised floor makes a slip more serious since a fall can go over the edge. I think of the yard as a place where small problems stack up, so I try to remove one early before it combines with another.

There is also a slower risk: the surface and joints will keep wearing. Nothing about this is urgent today, but if I stop checking, a small chip or gap could grow into something that affects the floor itself. The yard is old enough that I treat this as something to watch, not something to ignore.

Finally, there is a risk in my own routine. On busy days I am tempted to skip sweeping or to leave a piece in the walking line. Those shortcuts have caused most of my near misses, so I count my own haste as a risk too.

## Open questions

These are things I do not yet know and would like to settle with more observation or a few small tests.

- **How much does the west sun matter by season?** I have only a general picture. I would like to note, across a full year, when the afternoon light becomes a problem and when it can be ignored.
- **Is the wear along the central line speeding up?** The surface looks smooth, but I have not measured anything. I would like to compare the same spots over several months.
- **Can the small size be used better?** Perhaps a different layout of boards would free up more floor. I have a rough sketch but have not tried it.
- **Would a simple cover on the western side help?** It could reduce uneven drying and glare, but I do not know whether it would block too much light in the morning.
- **Where exactly are the open joints?** I have noticed some, but not recorded them. A proper walk with notes would help.
- **Is the raised floor draining evenly?** Water leaves quickly, but I suspect one side is slower. I would like to watch the next few rainy days.
- **How many people is too many?** I guess three, but I have not tested it under normal work.

I plan to answer these one at a time. None needs special equipment; each needs only attention and a short note after each visit.

## Safety

Safety in Sandbris yard comes down to a few firm rules. I keep them short so I actually follow them.

- **Watch the step.** The floor is raised, so every side has an edge. Look down before turning, especially when carrying something wide or heavy.
- **Keep the floor clean and dry.** Sweep first. Confine wet work to one corner, and wipe up any slick patch at once, since dust and damp together are slippery.
- **Keep the centre clear.** Nothing is left in the walking line, even for a moment.
- **Limit the number of people.** The yard is small, so two people is a comfortable number. A third person should wait outside until there is room.
- **Handle the late sun with care.** Because the yard faces west, glare in the evening can hide the edge and the floor surface. Slow down when the light is low, and do not carry anything awkward at that time.
- **Wear suitable shoes.** Flat shoes with a good grip are best on a worn, smooth surface.
- **Check the edges and joints.** The yard was built in 2008, so look over the edges for chips and open joints when walking the yard, and report or fix anything that could catch a foot.
- **Cover and clear at the end.** Before locking up, cover the work, clear the floor, and make sure nothing is left near the step.
- **Mind the dust.** Fine ceramic dust is not good to breathe in over long periods, so sweep gently, damp down where possible, and avoid raising clouds.

If something feels unsafe, I stop and fix it before carrying on. A few minutes of delay is always cheaper than an injury, and in a yard this size there is rarely a good reason to hurry.

## Overview

These are my own notes on Sandbris yard. It is a yard, and its area is ceramics. It is small, it faces west, and it has a raised floor. It was built in 2008. I keep the notes because the place is easy to misjudge. It looks simple, but the small size, the western light and the raised floor affect almost every job done there.

The yard is used for ceramics work. Pots are shaped, dried, stacked and moved on to firing from here. Because it is small, only a few things can be out at once. If I leave a drying rack in the wrong spot, the whole yard stops working. The raised floor keeps the working surface off the wet ground, which is the main reason the clay stays clean. It also means everything heavy has to be lifted or rolled up a step.

The west orientation gives the yard its character. The mornings are cool and shaded. The afternoons bring direct low sun, which dries work quickly and sometimes too quickly. Much of what I have learned here comes down to timing: what to put out in the morning, what to bring in before the sun gets round, and what to leave covered.

Properties of the place, stated once so I can find them later:

- Kind: yard
- Area: ceramics
- Orientation: west
- Size: small
- Year built: 2008
- Floor: raised

This study covers the recurring problems, the upkeep routine, a short history, and a checklist I can run through before a work session. The last section is background on why I treat these properties as the key to the place.

## Problems

Most of the trouble comes from the combination of a small yard, a west-facing aspect and a raised floor. None of these is a fault on its own, but together they cause a predictable set of problems.

**Uneven drying.** The afternoon sun from the west hits the open side of the yard and leaves the back in shade. Pieces on the sunny side dry faster than those at the back. Thin walls and handles are the first to crack. I have lost work by leaving a full rack out through a bright afternoon.

**Crowding.** Because the yard is small, I cannot spread work out. Pieces get placed close together, and then there is no room to walk around them. Knocks and chips happen mostly when I am squeezing past a rack with something in my hands.

**Edge hazards on the raised floor.** The floor sits above the ground, so there is an edge on every open side. A wheeled trolley that gets a little too close to the edge can tip. Loose boards near the step are the worst spot, because they move under load.

**Water and grit.** Rain blows in from the west during storms. Water pools in the low joins of the raised floor and carries grit and dried clay slip into the gaps. Once the gaps fill, the boards stay damp, and damp boards go soft.

**Heat in late summer.** The afternoon sun warms the floor surface until it is uncomfortable to kneel on. Anything stored directly on the boards, such as bags of clay, can dry out or go stiff.

The table below sums up the problems with the usual cause and the quick response I use.

| Problem | Usual cause | Quick response |
| --- | --- | --- |
| Cracked thin parts | Sun from the west on one side | Turn racks, cover the sunny side |
| Chipped rims | Crowding in a small yard | Clear a walking lane first |
| Tipped trolley | Edge of the raised floor | Keep wheels away from the edge |
| Soft boards | Water and slip in the joins | Rinse and dry the gaps |
| Stiff clay bags | Heat from the floor | Store off the boards, in shade |

None of these needs a rebuild. They need habits, and the next section describes the habits that work best.

## Maintenance

Maintenance here is mostly small and regular. The yard is not large, so a short routine each week does more than a big clean now and then.

**After each session.** I sweep the floor from the back toward the open edge so the dust and dried slip leave the yard instead of settling into the joins. Then I wipe the work surface with a damp cloth. Dry clay dust is the thing I most want out of the yard, both for the boards and for my lungs.

**Weekly.** I rinse the raised floor with a bucket of water and push the water toward the edge with a stiff brush. I pay attention to the joins between boards, because that is where slip gathers. I let the floor dry fully before putting anything heavy on it. I also check each board near the step by pressing with my foot. Any board that flexes gets marked so I can deal with it.

**Seasonally.** Before the sunniest part of the year I set up shade for the west side. A simple cloth screen on a light frame is enough. It cuts the low afternoon sun without blocking the air. Before the wet season I check that water can run off the edge and that nothing is blocking the gaps under the floor. I also look under the raised floor for damp, for pests and for anything that has been pushed in there and forgotten.

**Fixing the floor.** The raised floor is the part that wears. When a board goes soft I replace it rather than patching it, since a patched board tends to fail again at the worst moment. I keep a couple of spare boards that match the originals. After a replacement I seal the cut ends, because open end grain soaks up water fastest.

**Storage.** Because space is short, I keep tools on a wall rack and not on the floor. Clay stays in shade and is covered. Finished work goes out of the yard as soon as it is ready, since the yard is for working and not for keeping things.

**What I do not do.** I do not hose the floor hard, because it forces grit into the joins. I do not leave wet work out at the end of the day facing the sun. I do not stack more than I can lift down in one go.

## History

The yard was built in 2008. It was made as a small working space for ceramics, and from the start it had a raised floor and faced west. I do not have the original plans, so what follows comes from memory, from what I can see in the structure, and from what people who used it have said.

The early years were simple. The yard was used lightly, mostly for drying and stacking, and the raised floor was in good condition. The west orientation was probably chosen to catch afternoon warmth for drying, which suited the work. The trade-off, uneven drying, was something people learned to manage rather than something that was designed out.

Over time, use grew. More pieces passed through, and the small size began to matter more. Racks were added, then trolleys. That was when the edge of the raised floor started to cause trouble, because wheeled loads and a step do not mix well. Several boards were replaced in the middle years as water and slip took their toll in the joins.

More recently I have changed how I use it rather than changing the structure. I added a shade screen for the west side, cleared a walking lane, and moved tools to the wall. These changes cost little and fixed most of the daily irritations. The yard itself is much as it was when it was built in 2008, and I think that is a sign the original idea was sound.

## Checklist

I run through this before a work session and again before I leave.

**Before starting**
- Floor is dry and swept, with no loose slip in the joins
- Boards near the step do not flex
- Walking lane is clear from the entrance to the back
- Shade screen is in place if the afternoon will be bright
- Trolley wheels are kept away from the raised edge

**During work**
- Turn racks so the thin parts are not facing the western sun
- Keep clay bags in shade and covered
- Place new work only where I can still walk around it
- Wipe up spills at once, before they reach the gaps

**Before leaving**
- Sweep from the back toward the open edge
- Wipe the work surface with a damp cloth
- Move finished or unsafe pieces out of the yard
- Hang tools on the wall rack
- Cover anything that must stay out overnight

**Now and then**
- Rinse the floor and let it dry
- Replace any soft board
- Check the space under the floor for damp
- Look over the shade frame for wear

## Background

I treat the six properties of the yard as a set, because each one explains part of how the place behaves. It is a yard, so it is open to weather and air, and that is good for drying and bad for anything that dislikes rain. Its area is ceramics, so the work is clay, and clay is sensitive to how fast it dries. Its orientation is west, which decides when the sun arrives. Its size is small, which limits how much I can do at once. It was built in 2008, so the structure has had time to show wear. Its floor is raised, which keeps things clean and also creates edges and joins that need care.

Seen this way, the problems in this note are not random. Uneven drying comes from the west orientation meeting an open yard. Crowding comes from the small size. Soft boards come from the raised floor meeting water over the years since 2008. If I ever change the yard, I should start from these properties and ask which problem each change would help.

I wrote this note as a working reference, not as a full survey. It records what I have seen and the habits that worked. If a future change alters one of the properties, for example a new roof or a different floor, I should revisit the problems and the routine, since the balance between them would shift.

## References

These are the sources I used while studying Sandbris yard. They are my own notes and observations, since the place is small and nobody else has written much about it.

- My field notebook from the first visits, where I wrote down what the ground, walls and drainage looked like before I changed anything.
- A sketch plan I drew by hand, showing the gate, the raised floor, the west wall and the place where the kiln shed stands.
- The recollections of the person who looks after the yard. They told me the yard was built in 2008 and that the floor was raised from the start so water would run off toward the lane.
- A short list of questions I kept in the back of the notebook, mostly about why clay stays damp in some corners and dries too fast in others.
- My earlier general notes on drying clay outdoors. They are useful for the basic rules, but they were written for flat, open ground and do not fit a raised floor facing west very well.

A few things I want to remember about how I treat these sources:

- The caretaker's memory is good for history but not for numbers. I trust it for the year built and for how the floor was laid, and I check everything else by measuring.
- My sketch plan is not to scale. It shows relative position only, so I do not use it to work out distances.
- The older notes on outdoor drying are a starting point. Where they disagree with what I see in the yard, I go with the yard.

## Tools

I keep the tool list short because the yard is small and I carry everything by hand. Everything here is ordinary and cheap, and I could replace any of it in a day.

**For measuring**

- A hand-held humidity meter with a probe that I can hold in the air for a while. This is the main instrument. I let it settle before reading it, because it lags when I move from shade into sun.
- A plain thermometer that I hang in the shade near the wall, so the sun does not skew the reading.
- A long spirit level, to check that the raised floor still slopes the way it should.
- A folding ruler, for the height of the floor above the lane and the gap beside the wall.
- A notebook and a pencil. Pen runs in damp air, so I use pencil.

**For working**

- A stiff broom and a soft brush, for sweeping dust and clay crumbs off the floor.
- A bucket and a sponge, for wiping the shelves and the edge of the floor.
- A tarp that I can pull over the pieces if rain comes in from the west.
- A few flat boards for carrying pieces without bending them.
- A small trowel, for lifting dried slip from the corners.

**Habits with the tools**

- I wipe the probe of the humidity meter dry after each session and store it indoors, never in the yard.
- I check the level at the same two spots every time, so I can compare the readings across visits.
- I keep the notebook in a sealed bag whenever I carry it outside.

## Setup

Sandbris yard is a small yard for ceramics, built in 2008. It faces west and has a raised floor. Each of these properties changes how I set the place up, so I go through them one at a time.

**Kind and area.** It is a yard, not a room, so it has no roof of its own over most of its length. It belongs to the ceramics area, which means everything in it is for drying, storing or staging clay pieces and nothing else. I do not keep tools for other crafts here.

**Size.** The yard is small. I can reach most of it in a few steps, and that shapes the whole layout. There is no room for a separate drying zone and a separate storage zone, so I use the same shelves for both and move pieces in a fixed order.

**Orientation.** The yard faces west. The morning is mild and shaded, but the afternoon and evening sun comes straight in and hits the wall and the floor. Pieces on the west side dry quickly late in the day, which can crack thin edges. I keep fresh work toward the back and move it forward only once it has firmed up.

**Floor.** The floor is raised. This keeps standing water away from the pieces and lets air pass underneath, but it also means the floor edge is a drop. I put the heaviest items well back from the edge and keep the broom on the gate side, where I will not trip over it.

**My layout**

1. The gate end is for loading and unloading only. Nothing stays there overnight.
2. The middle stretch holds the shelves for pieces that are still soft.
3. The back, near the wall, holds pieces that are nearly dry and waiting for the kiln.
4. The tarp lives folded at the west edge, so I can reach it quickly when the weather turns.

Before each session I sweep the floor, check that the slope still carries water toward the lane, and hang the thermometer in its usual spot in the shade.

## Supplies

The supplies are the things I use up, as opposed to the tools I keep. I try to hold only what a small yard can store without clutter. The table below lists what I keep on hand, what each item is for, and how I decide when to restock.

| Supply | Purpose | Restock when |
|---|---|---|
| Plastic sheeting | Slows drying on fresh pieces | A sheet tears or goes stiff |
| Damp cloths | Keeps rims soft between sessions | They dry out and cannot be rewetted |
| Wooden battens | Raise pieces off the floor for airflow | One cracks or warps |
| Sponges | Wiping shelves and smoothing edges | They crumble |
| Clean water in a lidded jug | Rewetting cloths and cleaning tools | The jug is less than half full |
| Spare slip in a sealed tub | Mending small cracks | The slip thickens past use |
| Dust sheets | Cover shelves when the broom is out | They become gritty |

Some notes on how I handle these:

- Plastic sheeting is the item I rely on most. Because the yard faces west, I cover fresh work in the afternoon and uncover it in the evening once the sun is off the wall.
- I keep the damp cloths in a lidded box so they do not dry in the open air. A dry cloth is useless and can pull moisture out of the very rim it is meant to protect.
- The wooden battens matter because the floor is raised. Air already moves under the floor, but the battens let it move under the pieces too, which dries the base evenly.
- I keep the jug of water in the shade at the back. Warm water is fine for cloths, but I do not like it for mixing slip.
- I never stock more than I can store off the floor. Spare supplies on the floor get in the way and collect dust.

When I am short of something, I write it in the back of the notebook rather than trusting myself to remember. A small yard punishes forgetting, because I cannot easily leave to fetch a missing item mid-session.

## Measurements

I measured the yard on a settled afternoon, after letting the meter rest in the shade for a good while. The measured humidity of Sandbris yard was 86.45 %. That is high for a place meant for drying, and it matches what I noticed by hand: the cloths stayed wet longer than expected and the thin edges of the pieces stayed soft well past the usual time.

**What I think explains the reading**

- The raised floor lets air through underneath, but when the air outside is already wet, that airflow does not help much.
- The west wall holds heat after the sun leaves it, then slowly gives up moisture into the still air at the back of the yard.
- The yard is small, so there is little volume for the damp air to spread into. A reading taken at one point is close to a reading anywhere in the yard.

**What I checked alongside the humidity**

- The slope of the floor with the long spirit level. It still carries water toward the lane, so standing water is not the cause.
- The gap beside the wall, with the folding ruler. It is clear, so air can pass.
- The temperature in the shade, which was mild and steady during the whole session.

**What I changed because of it**

1. I now cover pieces with plastic sheeting less often, because trapping moisture on top of an already damp day slows drying further.
2. I lift pieces onto battens every time, even for short waits.
3. I keep the freshest work toward the back during the afternoon, and bring nearly dry pieces forward to catch the evening sun.

**What I still want to find out**

- Whether the reading changes much between the morning, when the yard is shaded, and the evening, when the sun is full on the west wall.
- Whether the reading is different after a dry spell than after rain.
- Whether moving the shelves a short way from the wall changes how fast the back pieces dry.

For now I treat 86.45 % as my baseline for a normal visit. If a later reading is far from it, I will note the weather and the time of day next to it, so I can tell whether the yard changed or only the day did.
