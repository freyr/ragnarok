---
type: plan
status: active
project: gilgloth-expansion
area: ceramics
description: "Plan about Zorksaeval Giotio."
---

# Zorksaeval Giotio plan

## Tools

Zorksaeval Giotio is a carpenter whose work overlaps with ceramics, which is the area I know him for. I have known him since 2012. He is available in the evenings, and the way to reach him is in person, so I plan to catch him at his workshop rather than try to call or write.

The plan for tools is to settle what he will bring and what I need to supply before any work starts. Here is the list I want to go through with him:

- Hand planes and chisels for fitting joints on the shelving and tables.
- A saw set for cutting boards to length, plus a small saw for fine cuts.
- Clamps, since the work surfaces for the ceramics studio need to be glued up and held flat.
- Sandpaper in several grits, and a sanding block, for finishing the edges so they do not chip clay or glaze.
- A square and a measuring tape, so the dimensions match the space in the studio.

Things to ask him in the evening visit:

- Which of these tools he already owns, and which I should buy or borrow.
- Whether he wants to use his own bench or mine.
- How he wants to handle dust, because dust near drying pottery is a problem.

I want to write the answers down right after we talk, so the list stays accurate.

## Contracts

The contract date for Zorksaeval Giotio is 2024-08-14. That is the date I use as the reference point for the agreement, and I keep it here so I do not have to hunt for the paper copy.

Since he is available only in the evenings and I reach him in person, any change to the contract has to wait for a visit. The plan is to keep the terms simple and to record them in writing after each conversation.

Points to confirm with him:

- What work is covered: the shelving, the tables, and any repairs to the studio fittings.
- How the materials are paid for, and who buys them.
- Who is responsible if a piece needs to be redone because of a fault in the joinery.
- What happens if a visit is missed, since evenings are the only time we can meet.

After each visit I will add a short note under this section with what we agreed, so the record of the contract stays current and easy to check later.
