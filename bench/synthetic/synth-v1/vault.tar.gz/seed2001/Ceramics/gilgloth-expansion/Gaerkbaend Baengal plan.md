---
type: plan
status: active
project: gilgloth-expansion
area: ceramics
---

# Gaerkbaend Baengal plan

## Risks

This plan covers how I work with Gaerkbaend Baengal, my supplier contact in ceramics. The main risks are about reaching one person through one channel, so I list them first.

- **Single channel.** Gaerkbaend Baengal is reachable by phone only. There is no email thread and no messaging group. If the phone is off, I have no fallback.
- **Narrow availability.** Evenings are the only reliable time. A call at midday usually goes unanswered, and I should not read that as a refusal or a problem with the order.
- **Single contact.** Gaerkbaend Baengal is my supplier contact, and I have no second person at the same workshop. If this person is away, orders stall.
- **Short history.** I have known Gaerkbaend Baengal since 2025. That is not long, so I do not yet know how the workshop behaves during a rush season or after a bad firing.
- **Verbal agreements.** Phone calls leave no record unless I write one. Anything agreed on a call and not noted afterward is a risk of misunderstanding later.
- **Fragile goods.** Ceramics break in transit and sometimes in the kiln. Even with a good contact, some loss is normal and should be planned for.

How I reduce these risks:

1. Write a short note straight after every call, while I still remember the details.
2. Keep a list of the questions I want to ask, so a single evening call covers everything.
3. Look for a backup ceramics supplier, without dropping Gaerkbaend Baengal.
4. Ask early about holidays and closures, so I can order ahead.

## Safety

Safety here means handling ceramic materials and goods properly, and keeping my own dealings tidy.

**Handling goods.** Finished ceramics can have sharp chips and edges. I wear cut-resistant gloves when unpacking, and I open boxes on a table with a cloth on it, not over a hard floor. Broken pieces go into a dedicated container, not a general bin bag where they could cut someone.

**Dust.** Raw clay, glaze powder and sanding dust are hazards when breathed in. If Gaerkbaend Baengal ever sends raw materials or unfired pieces, I use a proper dust mask and wipe surfaces with a damp cloth. I never sweep dry. I should ask for the safety information on any glaze or powder before it arrives.

**Food contact.** If any piece will hold food or drink, I need to confirm with Gaerkbaend Baengal that the glaze is suitable for that use. I do not assume it. I write the answer down, and if I get no clear answer, the piece is decorative only.

**Lifting and storage.** Boxes of ceramics are heavy for their size. I store them on low shelves, never above shoulder height, and I keep the heaviest ones at floor level. Packing material is kept dry.

**Phone safety.** I only talk business with this contact on the number I already have. If an unknown number claims to be calling for Gaerkbaend Baengal about payment details, I do not act on it. I hang up and call back on the known number in the evening.

## Overview

This note is my working plan for the relationship with Gaerkbaend Baengal. The facts about the person are below, so I do not have to hunt for them.

| Property | Value |
| --- | --- |
| Name | Gaerkbaend Baengal |
| Role | supplier contact |
| Area | ceramics |
| Contact | phone |
| Availability | evenings |
| Known since | 2025 |

In plain terms, Gaerkbaend Baengal is the person I deal with when I need ceramic items or related materials. I do not deal with a company department, only this person, and the way to reach them is the phone. The best time is in the evening. I have known Gaerkbaend Baengal since 2025, so the working relationship is fairly new, although it has been steady.

The goal of this plan is to make the relationship predictable. I want to know what to order, when to call, what to write down, and what to do when something goes wrong. The plan is not about negotiating hard. It is about being a reliable, easy customer so that Gaerkbaend Baengal keeps wanting to help me.

The rest of the note goes through the contract, history, problems, observations, supplies, tools, lessons, a schedule, ideas, background, and maintenance of the relationship.

## Contracts

The contract date of Gaerkbaend Baengal is 2023-02-23.

I keep this date here because it is the reference point for anything involving terms. It is worth remembering that I have known Gaerkbaend Baengal since 2025, so I should treat the contract date as a piece of recorded information and not assume I know the full story behind it. If I want to know why the contract is dated that way, I should ask on a call.

What I want to keep track of regarding the contract:

- **What it covers.** I should confirm in writing, in my own words, what goods and services the contract applies to. Ceramics is the area, but the details (standard items, custom items, repairs) need to be clear.
- **Who signs and who calls.** The contact for day-to-day matters is Gaerkbaend Baengal, by phone, in the evenings. If a change to the contract is needed, I should check that Gaerkbaend Baengal can actually agree to it and that I am not just chatting with someone who has no authority.
- **Changes.** Any change agreed on a call should be repeated back to Gaerkbaend Baengal at the end of the call, then written in my notes the same night.
- **Renewal and review.** I should ask in the next call whether the contract has a review point and when it falls. I will not guess.
- **Copies.** I keep one copy of the contract in my paper folder and one scanned copy in my files. Both should be easy to find.

Questions to raise in the next evening call:

1. Is the contract still current as it stands?
2. Are there terms that were meant to be reviewed?
3. What is the process if a delivery arrives damaged?
4. Is there a way to agree on changes in writing, even if we mostly talk by phone?

## History

My history with Gaerkbaend Baengal is short, and I want to record it before the details fade.

**2025.** This is the year I started dealing with Gaerkbaend Baengal. The first contact was by phone, and phone has stayed the channel ever since. In the early calls I learned that evenings are the only reliable time, because daytime calls rarely get an answer. I adjusted my routine accordingly.

**Early dealings.** My first orders were small. I used them to test how the workshop packs goods, how honest the description of each item is, and how quickly Gaerkbaend Baengal responds when I follow up. The responses were consistent: calm, direct, and usually the same evening or the next one.

**Growing trust.** As I placed more orders, the calls became shorter, because we both knew the routine. I started to trust that if Gaerkbaend Baengal said something would be ready, it would be ready, or I would be told in good time when it was not.

**Contract in the background.** The contract date, 2023-02-23, comes from before I knew Gaerkbaend Baengal. I do not have the early story, and I should not invent it. What I have is the record of my own dealings since 2025.

**What the history tells me.** The relationship is a young but stable one. There have been no serious disputes. The weak points are practical: one channel, one time of day, one person. That is why a good part of this plan is about keeping the process simple and recorded.

## Problems

These are the problems I have run into, or expect to run into, with this relationship, along with what I do about each one.

**Missed calls.** I call during the day, get no answer, and wonder if something is wrong. Nothing is wrong; Gaerkbaend Baengal is simply available in the evenings. The fix is to stop calling at other times, and to leave a short voicemail only when something is truly urgent.

**Calls running into late hours.** Because evenings are the only window, I sometimes call too late. I try to call early in the evening, so the call is not rushed and I do not catch Gaerkbaend Baengal at a bad moment.

**No written trail.** Phone-only contact means there is nothing to look back on. My fix is a call log, shown in the code block below, that I fill in right after each call.

**Mismatch between what I ordered and what arrives.** This has been rare, but with ceramics, color and size can differ slightly from what I imagined. I now ask for a clear description and repeat it back on the call.

**Breakage.** Some pieces will arrive damaged. I photograph the box and the pieces before I throw anything out, and I call Gaerkbaend Baengal in the evening to report it.

**Single point of contact.** If Gaerkbaend Baengal is unavailable for a long time, I have no one else to ask. I should find out who covers for them, and I should look into a second supplier.

Here is the format I use for the call log:

```text
call_log:
  contact: Gaerkbaend Baengal
  channel: phone
  time_of_day: evening
  topic: <what the call was about>
  agreed:
    - <item agreed>
    - <item agreed>
  open_questions:
    - <thing to ask next time>
  follow_up: <what I do next, and when>
  written_up: yes
```

## Observations

These are things I have noticed about working with Gaerkbaend Baengal. They are not conclusions, only patterns.

- **Responsive in the evenings.** When I call in the evening, the call is answered or returned soon. This matches the stated availability, and I have no reason to doubt it.
- **Clear, not chatty.** Gaerkbaend Baengal tends to give short, direct answers. That suits me. If I need more detail, I have to ask for it directly.
- **Honest about limits.** When something cannot be done, I am told so. I find that more useful than a vague yes.
- **Good knowledge of ceramics.** Questions about clay, glaze, and firing get practical answers. I treat this as the main value of the relationship, more than price or speed.
- **Prefers phone.** Any attempt to move the conversation to another channel feels like a detour. I accept that the phone is the way, and I plan around it.
- **Better with a prepared list.** Calls go best when I have my questions written down. Without a list I forget things and have to call again.
- **Seasonal pace unknown.** I have only known Gaerkbaend Baengal since 2025, so I do not know how the workshop behaves in busy periods. I will pay attention to this over time.

What I want to watch for next:

1. Whether response times change when the workshop is busy.
2. Whether the quality of the pieces stays consistent between orders.
3. Whether Gaerkbaend Baengal mentions other people at the workshop I could contact.

## Supplies

This section lists the kinds of supplies I get, or might get, through Gaerkbaend Baengal. Ceramics is the area, so the list is built around that.

**Finished goods.**
- Plain bowls, cups, and plates.
- Planters and small pots.
- Tiles, for small projects.
- Decorative pieces.

**Raw and working materials.**
- Clay, in the types Gaerkbaend Baengal recommends.
- Glazes, when I need a particular finish.
- Underglaze colors for decoration.

**Packing and handling.**
- Boxes with dividers.
- Paper and soft wrapping.
- Labels, so I know what is in each box.

**How I order.**
1. Prepare a short list of what I need and a few words about each item.
2. Call Gaerkbaend Baengal in the early evening.
3. Describe each item, and ask what is in stock and what would need to be made.
4. Repeat the order back at the end of the call.
5. Write it in the call log that same night.

**Things to ask about each time.**
- Is the item food safe, if it needs to be?
- Is it a standard item or a custom one?
- How will it be packed?
- When should I expect it?

I keep a small amount of spare stock of the items I use often, so a delayed delivery does not stop me.

## Tools

The tools I use for this relationship are simple, and that is deliberate.

**Phone.** The phone is the only channel for reaching Gaerkbaend Baengal. I keep the contact saved with a label that includes the word evenings, so I do not call at the wrong time by habit.

**Call log.** A plain text file, using the layout shown earlier. I fill it in right after each call. It is the only written record I have of what was agreed.

**Question list.** A running list in my notes app. Whenever something comes to mind during the day, I add it. Before the evening call, I read it through and pick what matters.

**Calendar reminder.** A repeating reminder in the evening, set for the days I plan to call. It stops me from forgetting, and from calling at the wrong hour.

**Camera.** I use the phone camera to photograph deliveries as they arrive, particularly if a piece is damaged. The photos go in the same folder as the call log.

**Contract folder.** A paper folder and a scanned copy of the contract, so I can check terms without having to ask.

**Packing supplies for returns.** If I have to send a piece back, I need boxes and wrapping. I keep a few in reserve.

**Backup contact list.** A short list of other ceramics suppliers, in case Gaerkbaend Baengal is unavailable for a long time. It does not replace this relationship. It only protects me from a gap.

## Lessons

These are lessons I have drawn so far from working with Gaerkbaend Baengal. Some I learned the easy way, some less so.

1. **Respect the availability.** Evenings are when Gaerkbaend Baengal can talk. Calling at other times wastes effort and creates needless worry.
2. **Write it down at once.** The phone leaves no record. If I wait until the next day, I lose details. The call log has to be done right after the call.
3. **Repeat things back.** A short summary at the end of each call prevents most misunderstandings. It takes half a minute and saves a lot of trouble.
4. **Prepare before calling.** A written list of questions makes the call shorter and more useful, and it shows respect for the other person's evening.
5. **Do not assume.** For anything about food safety, custom work, or terms, I ask directly. Gaerkbaend Baengal answers plainly, so there is no reason to guess.
6. **Keep the relationship simple.** One person, one channel, one time of day. Adding complexity would not help.
7. **Plan for loss.** Ceramics break. I allow for it in how many pieces I order, and I do not blame anyone when a piece arrives chipped. I report it, calmly, in the evening.
8. **Be patient with a young relationship.** I have known Gaerkbaend Baengal since 2025. Trust builds with repeated, small, successful dealings. I should not expect more than that yet.

## Schedule

This is the routine I follow. It is a rhythm more than a calendar, because exact days depend on my own needs.

**Weekly.**
- Check the question list and add anything new.
- If an order is open, decide whether a follow-up call is needed.
- Make the call in the early evening, and fill in the call log right away.

**Monthly.**
- Review the call log for open questions that nobody has answered.
- Check my stock of the supplies I use often, and decide whether to order.
- Look through the photos of deliveries and note any recurring problems.

**Seasonally.**
- Ask Gaerkbaend Baengal about holiday closures and busy periods, so I can order ahead.
- Check the backup supplier list is still current.

**Yearly.**
- Review the whole relationship: quality, reliability, response time, and whether the contract still makes sense.
- Raise the contract in a call. The recorded contract date is 2023-02-23, and I should ask whether there is a review point I should know about.
- Update this plan with what I have learned.

**Order sequence.**
1. Prepare the list.
2. Call in the early evening.
3. Confirm items, packing, and timing.
4. Write the call log.
5. Check the delivery against the log when it arrives.
6. Photograph any damage and report it on the next evening call.

## Ideas

These are ideas I may try. None are commitments.

- **Ask for a second contact.** Politely ask whether there is someone else at the workshop I could reach if Gaerkbaend Baengal is away. This would lower the single-contact risk.
- **Offer a written summary.** After a larger order, I could offer to send a written summary, if there is any way for Gaerkbaend Baengal to receive it, such as a posted note with the delivery. I will ask whether that is welcome.
- **Visit the workshop.** If possible, a visit would help me understand the process and put a face to the voice. It would also help me see how pieces are packed.
- **Trial of a custom piece.** A small custom order would show how the workshop handles something outside the usual range.
- **Bulk ordering.** If I find I order the same items again and again, I could ask whether larger, less frequent orders would make sense for both of us.
- **Shared calendar of busy periods.** Even a rough idea of when the workshop is busy would help me plan.
- **Sample set.** Ask for a small sample set of glazes or clays, to try before committing to a larger order.
- **Better packing for returns.** Develop a standard way of packing pieces that have to go back, so returns are less likely to break twice.
- **Thank-you gesture.** A small sign of appreciation after a good run of orders. It costs little and keeps the relationship warm.

## Background

Some context helps explain why this plan is shaped the way it is.

Gaerkbaend Baengal is a supplier contact working in ceramics. The role matters: I do not deal with a shop front or a catalog. I deal with a person who can answer practical questions about materials, finishes, and what can be made. The contact method is the phone, and the availability is evenings. I have known this person since 2025.

The contract date on record is 2023-02-23. This predates my own dealings, so I regard it as background I inherited rather than something I helped shape. I should ask when I get the chance what led to it.

Ceramics as an area has its own habits. Items are made in batches, firing takes time, and small differences in clay or glaze can change the result. That means delivery times are not always firm, and some variation between pieces is normal. A supplier who is honest about this, as Gaerkbaend Baengal seems to be, is more valuable than one who promises perfection.

The phone-only setup is a feature of this relationship, not a defect. It means conversations are personal and direct, though it also means I carry the burden of record-keeping. My call log and question list exist for that reason.

I keep this plan for my own use. It is not a formal document, and it will change as I learn more. The aim is a steady, low-friction working relationship with someone who knows their craft.

## Maintenance

A plan like this only helps if I keep it up to date. Here is how I maintain it.

**After each call.**
- Fill in the call log immediately.
- Update the question list: remove what was answered, add what is still open.
- If anything about the contract, availability, or contact method changed, update the Overview table.

**After each delivery.**
- Check the contents against the call log.
- Photograph damage before discarding anything.
- Note anything surprising in the Observations section.

**Regularly.**
- Reread the Risks section and ask whether any risk has grown or shrunk.
- Reread the Lessons section and add anything new.
- Check that the Schedule still matches how I actually work.

**When something changes.**
- If Gaerkbaend Baengal changes the contact method or the evening availability, I update the properties at the top of this note first, since everything else depends on them.
- If I get a second contact at the workshop, I add it to the Overview and revise the Risks.
- If the contract is renewed or amended, I record the new details and keep the earlier date, 2023-02-23, for reference.

**Keeping the record honest.**
- I write what was said, not what I wish had been said.
- I mark guesses as guesses.
- I do not delete old entries; I add corrections beneath them.

**When to retire this plan.**
If the relationship ends or changes so much that this plan no longer fits, I will archive it with a short note explaining why, and start a new one. Until then, I treat it as a living document, small and practical, kept in step with how things actually go with Gaerkbaend Baengal.
