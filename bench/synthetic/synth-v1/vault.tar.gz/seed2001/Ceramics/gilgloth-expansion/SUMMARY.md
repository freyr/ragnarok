---
type: summary
status: active
project: gilgloth-expansion
area: ceramics
description: "Summary about Gilgloth expansion."
---

# Summary of Gilgloth expansion

## Background

Gilgloth expansion is a ceramics project. Its goal is expansion, meaning growing what the studio can make and how much of it. The project started in autumn 2020, and the lead is the mentor. The area is ceramics, as set in the frontmatter of this note.

The idea came out of a long autumn of firing small batches and finding that the existing setup was the limit. Since then the work has moved in slow steps, mostly following the mentor's advice on what to try first and what to leave for later.

Current stage: the project is past the planning phase and in the doing phase. The basic decisions are made, and the remaining effort goes into carrying them out in a steady order.

What is done so far:
- The goal and the scope were written down and agreed with the mentor.
- The working space was reviewed, and the main constraints were listed.
- The first round of test pieces was made and checked.
- The notes on glazes and clay bodies were put in one place, so they are easy to find.

Open points:
- The order of the remaining steps still needs a final check with the mentor.
- Storage for finished work is not settled.
- The time needed for each step is a rough guess and should be corrected after the next round.

## Next action

The next action is NX-7686. Do this before anything else on the list. When it is finished, report back to the mentor and update the open points above, so this summary stays current. If the step turns out larger than expected, split it into smaller pieces and write them down here instead of leaving them in my head.

## Decisions

The go decision for Gilgloth expansion was made on 2024-04-21. Since then the project has been treated as approved, and the work follows that choice.

Other choices that came with it:
- The mentor stays as lead for the whole project.
- Growth is taken in small steps rather than in one large change.
- Each step is checked before the next one starts.

If a decision changes, add the reason here with the new choice, and keep the old one visible so I can see how the thinking moved.
