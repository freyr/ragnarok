---
type: drivers
status: active
project: gilgloth-expansion
area: ceramics
description: "Drivers about Gilgloth expansion."
---

# Drivers of Gilgloth expansion

## Lessons

Gilgloth expansion is a ceramics project that started in autumn 2020. The goal is expansion, and the lead is my mentor. I keep this note to remember what pushed the project forward and what held it back.

The main driver was the wish to grow the kiln capacity without losing the quality of the glaze. Early on I learned that more space alone does not help if the heat is not handled well. The [[Zendgla heat exchanger study]] showed where we were wasting warmth, and the [[Braetruth heat exchanger]] was the practical answer that came out of it. I would read the study again before any new kiln work.

The second driver was room. The [[Tranael yard]] gave us the outdoor space for loading and cooling, and the [[Krespa shed plan]] set out how to cover the new work area. Without those two the expansion would have stayed on paper.

Constraints were mostly about time and weather. Autumn is a short season for outdoor ceramics work, so every delay cost us. My mentor kept the schedule tight and asked for small steps with a test after each one. That habit saved us from at least two bad firings.

Notes I should keep close:

- [[Baerkpend Drormaeth notes 2022]] for the clay and firing observations from the second year.
- [[Drioldosra Zimior notes]] for the advice on layout and workflow.
- [[Fudralvend Sirmeller tests]] for the results I use to judge whether a change really worked.

Success is measured by three things: the kiln runs a full load with even results, the work area stays dry and usable through autumn, and the spending stays inside the plan. If one of these fails, the expansion is not finished, even when the building looks done.

What I would do differently: test earlier, write down each result the same day, and avoid buying anything before the plan for it is on paper.

## Budget

The budget of Gilgloth expansion is 5425.39 EUR. It covers materials, the heat exchanger work, and the covered area. I treat it as a hard limit, not a target. Any purchase that would push past it has to wait or replace something else. My mentor reviews the spending with me at the end of each stage, and I note the reason for every change so the numbers can be explained later.
