---
type: log
status: active
project: gilgloth-expansion
area: ceramics
description: "Log about Nantusves pond."
---

# Nantusves pond log

## Maintenance

Nantusves pond is a medium-sized pond built in 1995, and it sits below ground. It belongs to the ceramics area, so most of what I do here is shaped by the clay and glaze work that happens nearby. This log is where I keep the practical record of how I look after it.

The pond faces south, so it gets long hours of direct sun. That helps in cooler months and causes trouble in summer. Algae builds up faster here than it would on a shaded site, and the water warms quickly. I check it often for that reason.

My routine maintenance tasks are these:

- Skim the surface for leaves, dust, and any fine clay debris that has blown in from the studio side.
- Check the water level against the mark on the inner wall and top it up slowly if it has dropped.
- Clear the intake screen so the circulation does not slow down.
- Look over the edge stones for movement, since the pond is below ground and the soil around it shifts after heavy rain.
- Scrub the algae from the walls in small sections, never all at once, so the water stays balanced.

Because the pond is below ground, runoff is the main thing I watch. Anything that washes in from the surrounding ground ends up in the water. After a storm I always do an extra skim and check the clarity before I leave it alone.

## Setup

The pond was built in 1995 and has been in the same spot ever since. It is a below-ground installation, dug into the earth with the rim close to the level of the surrounding path. The south orientation was chosen on purpose, and I think it was the right call for light, though it makes summer upkeep harder.

The basic setup is:

- A lined basin set into the ground, with a firm edge of flat stones.
- A small circulation pump housed at the lowest corner, with a screened intake.
- A shallow ledge along one side for plants.
- A gravel apron on the north side to stop soil sliding into the water.

Since this is the ceramics area, I keep a covered bin near the pond for offcuts and rinse water. None of that goes into the pond. Glaze residue and clay slip are bad for the water, so I keep a clear separation between the work area and the edge.

## Dimensions

The pond is medium in size. The floor area of Nantusves pond is 356.74 m². That is the figure I use whenever I work out how much liner patching, gravel, or treatment I need.

The pond is below ground, so the depth is measured from the rim down, and the walls are straight enough that the area figure stays reliable for planning. I note the following practical points about its size:

- Medium size means a full clean-out is a real job and takes a whole day with help.
- The large floor area means the water takes a long time to change temperature, but once it warms in summer it stays warm.
- Any treatment has to be dosed for the whole volume, so I measure carefully and never guess.

When I plan supplies, I always start from the floor area and work outward. It keeps my estimates honest.

## Risks

The main risks I have noted over the years are:

- Overheating in summer, because of the south orientation and the long sun exposure.
- Algae blooms, which follow from the heat and from any nutrients washing in.
- Contamination from the ceramics area, especially glaze, slip, and cleaning chemicals.
- Ground movement, since the pond is below ground and the surrounding soil can settle or swell.
- Liner damage, which is more likely as the pond gets older. Built in 1995, it has had a long life already, and I treat the liner as something that could fail without much warning.
- Falls, because the rim sits close to ground level and is easy to miss in poor light.

For each of these I try to have a simple response ready. For overheating, I add shade plants on the ledge and avoid disturbing the water in the hottest part of the day. For contamination, I keep the bin lid shut and the work area away from the edge. For liner damage, I inspect the walls whenever the level drops without an obvious reason.

## Overview

Nantusves pond is a medium-sized, south-facing, below-ground pond in the ceramics area, built in 1995. It is an old installation, and it has held up well because it gets steady attention. This log is meant to be a working record rather than a formal manual.

What I want from the pond is simple: clear water, a stable level, and no trouble for the work happening beside it. The main influences on that are the sun, the runoff, and the habits of whoever is working in the studio. If those three are under control, the rest is routine.

When I come back to this note after a gap, I read the Risks section first, then the Schedule, and then I walk the pond edge before touching anything. Looking first saves me from fixing the wrong thing.

## Schedule

My working rhythm is based on how often things actually go wrong, not on an ideal plan.

**Every few days**
- Skim the surface.
- Check the water level.
- Look at the intake screen.

**Weekly**
- Check the pump is running smoothly and quietly.
- Inspect the edge stones.
- Look at water clarity and colour, and note anything unusual.

**Monthly**
- Scrub a section of the walls.
- Clear the gravel apron of debris.
- Check the bin area in the ceramics space for spills.

**Seasonal**
- Spring: a thorough inspection, pump service, and replanting of the ledge.
- Summer: extra checks for heat and algae, with more frequent skimming.
- Autumn: net or clear fallen leaves before they sink.
- Winter: keep the intake clear and check that the edge is safe in frost.

**Yearly**
- Inspect the liner as far as I can see it, and note any wear.
- Review this log and adjust the routine.

## Supplies

I try to keep a small stock so a problem does not wait on a shopping trip.

- A long-handled skimming net and a fine net for small debris.
- A stiff brush for the walls.
- Spare intake screen material.
- Liner repair patches and matching adhesive.
- A water testing kit.
- Clean gravel for the apron.
- Flat edge stones for replacing any that shift.
- Shade plants for the ledge.
- Buckets, gloves, and boots.
- A spare pump seal and fittings.

I size anything that depends on quantity, such as gravel or treatment, from the floor area. For the ceramics side, I keep a separate set of containers so that rinse water and offcuts never share tools with the pond gear. Mixing them is the quickest way to contaminate the water.

## Costs

I do not track every small purchase, but I keep a rough idea of where the money goes. The biggest recurring costs are the pump servicing and replacement parts, followed by gravel and edge stones. Plants and testing supplies are small but regular.

The largest possible cost is liner work. Because the pond dates from 1995, I assume that a major liner repair or replacement will eventually be needed. A medium pond with a large floor area is not cheap to reline, so I put a little aside each year rather than face it all at once.

Some ways I keep costs down:

- Catch small problems early, since a patched edge is cheaper than a rebuilt one.
- Buy gravel and stones in one trip each year.
- Keep the pump clean so it lasts longer.
- Keep contamination out, which avoids expensive water treatment and emergency clean-outs.

In short, the cheapest pond to run is the one I look at often.
