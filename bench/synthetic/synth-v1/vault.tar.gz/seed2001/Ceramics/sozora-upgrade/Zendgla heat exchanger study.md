---
type: research
status: active
project: sozora-upgrade
area: ceramics
description: "Research about Zendgla heat exchanger."
---

# Zendgla heat exchanger study

## Schedule

This study follows the Zendgla heat exchanger, a black ceramic heat exchanger that has sat at the pond since it was installed in 2021. It runs on mains power. I do not run the study in one block. It is a loose routine that fits around the other things I keep an eye on at the pond.

The rhythm I settled on:

- Every week: look at the unit, listen to the pump side, and write a short line in [[Nantusves pond log]].
- Every month: pull the readings from the logger and compare them with the previous month. The raw numbers live in [[Brugar data logger log]], and I only copy summaries here.
- Every season: a longer visit. I drain what needs draining, inspect the ceramic surfaces, and check every mains connection.
- After any storm or power cut: an unscheduled check, because the unit sits outside and the supply has dropped out before.

I keep the schedule light on purpose. Earlier attempts at daily checks on other devices fizzled out within a few weeks. The comparison work with [[Nedirk heat exchanger tests]] taught me that a modest routine kept up for years beats a strict one that stops. The tests in that note were short and intense, whereas this study is meant to be slow and dull and to show drift over time.

If a season is missed, I do not backfill it. I write "missed" in the pond log and move on. Gaps are information too.

## Setup

The Zendgla heat exchanger is a black ceramic unit mounted at the pond. The black finish matters more than I expected. In summer the casing absorbs sun and warms noticeably, which has to be kept in mind when I read surface temperatures. The ceramic body is dense and heavy, so it sits on a levelled base and not on the bank itself.

Key properties, stated plainly:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: mains
- Year installed: 2021
- Location: pond

Because it runs on mains, the supply comes down from the house through armoured cable and ends at a weatherproof enclosure near the pond edge. I wanted this arrangement so the study would not depend on batteries. My solar experiments, written up in [[Glaendfior solar charger notes]], showed how much effort a self-powered setup needs, and I did not want that effort here. Mains also means the unit gives steady, repeatable behaviour, which suits a long study.

The water side connects with flexible hose and clamps so I can disconnect it without cutting anything. I fitted sensors at the inlet and outlet and one on the casing. They feed the data logger, which sits in a dry box. I tested the radio link between the logger and the house using the approach in [[Vorful radio receiver handbook]], and that saved me from placing the receiver in a dead spot.

I photographed the layout after installing the sensors and keep the photos with the pond log, so I can tell if anything has shifted.

## Supplies

Supplies for the study are mostly small and cheap, but running out of any one of them stops a visit halfway. I keep them together in one lidded crate that lives in the shed.

What the crate holds:

- Spare hose clamps and a short length of spare flexible hose
- Silicone-based grease for the connector seals
- Soft cloths and a bottle of mild cleaner that is safe for ceramic and for the pond
- Cable ties, self-amalgamating tape, and spare cable glands
- A spare sensor and a spare weatherproof enclosure lid gasket
- Notebook, pencil, and a waterproof marker
- Disposable gloves and a small bucket

I avoid strong solvents completely. The pond holds living things, and anything that rinses into the water is a risk. The cleaner I use is gentle and I rinse with pond water drawn from the same place, not tap water, so I do not change the water chemistry near the unit.

For the mains side, I keep only what I am allowed and competent to handle. Anything beyond checking that the enclosure is dry and the cable is undamaged goes to someone qualified. [[Serpi Muntran]] is the person I call for that, and I have noted that I should not try to be clever with the supply. The crate holds no spare mains components for that reason.

Every few months I go through the crate and replace anything that has perished. Rubber and grease age faster outdoors than I expect, and the gasket in particular goes stiff.

## Maintenance

Maintenance on a ceramic exchanger is mostly about keeping surfaces clean and keeping the connections sound. The ceramic itself does not corrode, but it can chip, and a chip near a hose fitting is the sort of thing that grows into a leak.

The routine for each seasonal visit:

1. Switch off the mains at the house before touching anything at the pond.
2. Look over the black casing for chips, hairline cracks, and stains.
3. Wipe the surface with a damp cloth and mild cleaner, then rinse.
4. Check each hose clamp and replace any that show rust.
5. Inspect the cable and enclosure for moisture, then grease the seals.
6. Restore power, listen for any change in sound, and watch the readings settle.

The thing I watch most closely is fouling. Algae and fine silt build up on the water side and reduce how well heat moves across the ceramic. I see this in the logger as a slow widening of the gap between inlet and outlet readings. When the gap grows and stays grown, I clean, and then check whether the gap closes again. That before-and-after comparison is the most useful result of the whole study so far.

Anything structural I cut or trim, such as offcuts of timber for the base, I do with the [[Luki band saw]] in the workshop, not at the pond. Cutting at the pond leaves dust and swarf in the water.

I write every maintenance action into [[Nantusves pond log]] with a plain description of what I found.

## Tools

The tools I use are ordinary, and I keep a short list so I know what to bring. Most of the kit stays in the shed, and a smaller set travels to the pond.

At the pond:

- Screwdrivers and a small adjustable spanner for the clamps
- A torch with a head strap, since the enclosure is often in shade
- A basic multimeter for confirming that the supply is off or on
- A handheld thermometer to cross-check the fixed sensors
- A soft brush and a scraper made of plastic, never metal, so the ceramic stays unmarked

In the workshop:

- The [[Luki band saw]] for the timber base and any packing pieces
- A drill and a small bench vice
- A laptop for pulling data off the logger

The logger deserves its own note, and it has one: [[Brugar data logger log]]. I only record here that it samples at a steady rate and stores everything locally, so a failed radio link does not lose data. The handheld thermometer is my sanity check. If it disagrees with a fixed sensor by more than a little, I treat the fixed sensor as suspect and look at its wiring first.

I keep the multimeter strictly for confirming status. Anything that needs a live measurement on the mains side is not my job, and I leave it to [[Serpi Muntran]].

## Open questions

There are several things I do not yet understand about how this unit behaves, and I want to record them before I forget why they bothered me.

- How much of the summer warming comes from the black casing absorbing sun, and how much from the water itself? I could test this with a shade screen, but I worry a screen would change airflow around the unit.
- Does fouling grow at a steady pace, or does it come in bursts after warm spells? The monthly readings hint at bursts, but I have too few seasons to be sure.
- How does the Zendgla compare with the units in [[Nedirk heat exchanger tests]] once both are cleaned to the same standard? The earlier tests were short and indoors, so the comparison may not be fair.
- Is the settling time after switching the mains back on getting longer as the years go by? If so, it may point to a slow change in the water side that I cannot see from outside.
- Would a simple cover over the enclosure reduce the moisture I find each spring, or just trap more of it?
- Should I move the casing sensor? It sits where the sun hits first, and that may exaggerate the readings.

I also want to know whether the study is asking the right question at all. So far I have measured how clean the unit is, and I have not measured how much it matters to the pond. Linking the exchanger readings to the water observations in [[Nantusves pond log]] might answer that, but it needs a plan I have not written yet.

## Costs

The Zendgla heat exchanger is a black ceramic unit that runs on mains power. It was installed at the pond in 2021. I keep these cost notes so I can see where the money has gone and what is likely to come next.

- Purchase and delivery: this was the biggest single cost. I did not record the exact figure in a way I trust, so I treat it as a sunk cost and do not try to recover it on paper.
- Installation: most of the work was done by me with some help carrying the unit down to the pond. The main outlay was fittings, hose clamps and a weatherproof outdoor socket.
- Electricity: because the energy source is mains, the running cost shows up on the household bill. The pump side is the part that draws power, and the ceramic core itself is passive.
- Cleaning supplies: soft brushes, a bucket kept only for this job, and mild cleaner. These are cheap but recurring.
- Spare seals and hose: I keep a small stock, because replacing a perished seal in the middle of summer is annoying and the shop is not close.

The ongoing cost is low compared with the first year. The one item that could change that is a cracked ceramic core, which would mean replacing the whole unit. I think of the exchanger as a long-term purchase that has to last well beyond its first few seasons at the pond.

## Risks

The ceramic body is hard and corrosion-proof, which is why it suits a pond, but it has weak points. Below is what I worry about, roughly in order of how likely it is.

- Frost cracking: if water is left inside the black ceramic core during a hard freeze, it can expand and crack the body. Draining it before winter is the single most important habit.
- Impact damage: ceramic does not bend. A dropped tool or a knock while cleaning can chip or split it.
- Fouling: algae and silt build up on the surfaces and cut the heat transfer. This is slow and easy to reverse, but if ignored it makes the unit work harder.
- Mains safety: the unit is connected to mains power at the water's edge. The socket must be protected, the cable kept off the ground where it can be stepped on, and the circuit should have a residual current device.
- Black surface heating: the dark colour absorbs sun. In full summer sun the casing gets hot, so I keep it shaded where I can and avoid touching it with bare hands in the afternoon.
- Seal failure: the connections between the hoses and the ceramic are the usual place for slow leaks.

None of these has caused a serious problem so far, but frost and impact are the two I could not undo.

## History

The device was installed in 2021 at the pond. Before it, the pond had no way of controlling water temperature, and the water swung a lot between hot spells and cool nights. That was the reason I looked at a heat exchanger in the first place.

The early period was mostly learning. I positioned the unit once, then moved it a short distance after noticing that the first spot caught too much direct sun on the black casing. After that the layout stayed the same.

Over the following seasons the routine settled into a pattern:

- Spring: reconnect, check seals, refill, and run it for a short test.
- Summer: light cleaning every few weeks and a look at the cable and socket.
- Autumn: a thorough clean, then drain the unit.
- Winter: leave it drained and covered, with the power disconnected.

I made small changes over time, such as a better cover, a firmer base so the ceramic does not rock, and clips to keep the cable tidy. None of these changed what the device is or how it works. The unit has been in place since 2021 without being replaced, which I count as a good result for a ceramic heat exchanger left outdoors.

## Checklist

This is the list I follow each year. I tick it off in my head, but writing it here keeps me from skipping steps.

- Confirm the power is off before touching anything.
- Inspect the black ceramic body for chips, hairline cracks and stains.
- Check the hose connections and replace any seal that looks flattened or dry.
- Brush the surfaces clean with a soft brush and mild cleaner, then rinse well.
- Check the mains cable for damage and make sure the outdoor socket cover closes properly.
- Test the residual current device.
- Make sure the unit sits level and does not rock on its base.
- Restore power and run it, watching for leaks in the first few minutes.
- Before winter: disconnect power, drain all water, leave the ports open so nothing is trapped, and cover the unit.

If any step turns up a crack, I stop and decide whether the unit is safe to keep using before putting it back into service.

## References

These are the sources I rely on. They are my own records rather than published documents.

- My own photographs of the unit at the pond, taken at installation in 2021 and after each autumn clean.
- Handwritten notes on the seasonal routine, kept in the shed.
- The maker's printed leaflet that came in the box, covering connection and care of the ceramic body.
- Notes from a neighbour who also keeps a pond and has used a similar ceramic exchanger.
- Household electricity bills, used to judge the running cost of the mains supply.

I treat the leaflet as the authority on connection and frost care, and my own notes as the authority on what actually happened at this pond. Where they disagree, I go with what I have seen work and write the difference down.

## Background

The Zendgla heat exchanger is a heat exchanger in the ceramics area. It is black, runs on mains power, and has been installed at the pond since 2021.

A heat exchanger moves heat from one body of water to another, or between water and the surroundings, without the two flows mixing. Ceramic is an unusual material for this. It conducts heat less well than metal, but it does not corrode, does not release metal into the water, and keeps its surface for years. For a pond, where fish and plants are sensitive to what dissolves in the water, that trade-off makes sense to me.

The mains supply drives the circulation. The exchanger itself has no moving parts in the ceramic core, so the electrical load is small and the main thing to manage is safety, not consumption.

The black colour is not decoration. It affects how the casing behaves in sunlight, and I have had to plan around that. The pond location also matters: damp ground, falling leaves, algae and winter frost all act on the unit in ways they would not indoors.

What I want from this study is a practical picture of whether a ceramic exchanger is a sensible choice for a small garden pond, what it costs to keep, and what can go wrong. So far the answer is yes, provided I drain it before frost, keep the electrics protected, and handle the body with care.

## Lessons

The Zendgla heat exchanger has been running at the pond since 2021, and most of what I have learned comes from simply living with it. It is a black ceramic unit powered from the mains, and those three facts shape almost every decision I make around it.

- Ceramic does not forgive knocks. When I cleaned it the first time, I rested a bucket against the casing and heard a sharp tick. Nothing cracked, but I now keep everything away from it and use a soft brush only.
- Mains power means the pump and the exchanger depend on the same socket. When the socket tripped after a storm, both stopped together. I added a small label on the plug so I remember to check it first.
- Black surfaces get hot in the sun. The casing is black, so on a bright afternoon it warms well above the water temperature. This is not a fault, but it explains why my midday readings look different from the morning ones.
- Cleaning on a schedule is better than cleaning when I notice a problem. By the time I notice reduced performance, the film on the ceramic is already thick.
- Write the readings down on the day. I trust my notes far more than my memory of how the water felt.
- Do not change two things at once. Whenever I adjusted the valve and cleaned the unit in the same visit, I could not tell which one had helped.

A short list of habits that came out of all this:

- Check the plug and socket before anything else.
- Look at the casing for chips or hairline marks.
- Brush the surface gently, never scrape.
- Record the flow before and after any change.
- Leave the unit alone for a full day after a change before judging it.

The biggest lesson is that this device rewards patience. It is not complicated, but it is slow to show the result of anything I do to it, and impatience has cost me more than any defect in the unit.

## Overview

The Zendgla heat exchanger is a heat exchanger in the ceramics area. It is black, runs on mains energy, was installed in 2021, and sits at the pond. Those are the basic properties, and I repeat them here so this note can be read without the others.

The purpose is to move heat between the pond water and the circuit it serves. A ceramic body is a sensible choice for pond water, because it does not corrode and does not leach anything into the water. The trade-off is that it is brittle and heavy, and it does not tolerate being moved once it is settled in place.

The position at the pond matters. It is close to the water so that the pipe runs are short, and it is partly shaded in the morning but exposed in the afternoon. I did not plan the shade; it is an accident of where the nearby shrubs grow. The mains cable runs along the edge of a path and enters the unit from the lower side, which keeps drips from following the cable into the socket.

What I wanted from this study was simple:

- To know what the unit really delivers in everyday use, not what I assumed when I installed it.
- To find out whether the black colour causes noticeable heating in sunlight.
- To learn how fast the surface fouls and how often it needs cleaning.
- To decide whether it is worth keeping or whether a different layout would suit the pond better.

I am not trying to prove anything about ceramics in general. This is one device, in one pond, and the notes are for my own use. Conclusions that apply elsewhere are a bonus, not a goal.

Since 2021 the unit has been through several winters, a few cleanings, and one change of pump upstream. The ceramic body has stayed intact and the colour has not faded. The main wear I can see is a light mineral crust near the water line, which is easy to brush off.

## Ideas

These are things I want to try, roughly in order of how likely I am to do them.

- Add a simple shade board on the west side of the unit, so the black casing does not take the full afternoon sun. I want to see if it changes the readings at all.
- Fit a small switch or timer on the mains line so I can run the unit on a schedule instead of continuously. This would also give me a clean way to compare running and resting periods.
- Install a second thermometer on the return pipe, so I have both ends of the circuit. At the moment I only guess at the difference from one point.
- Make a proper cleaning log on a card kept in the shed, with a tick for each visit. My current habit of remembering is not good enough.
- Try a different brush. The one I use is fine, but a softer one might leave the surface cleaner without any risk to the ceramic.
- Build a low wooden guard around the unit to stop accidental knocks from tools or buckets.

Some bigger ideas are further off. I have wondered whether moving the unit a short distance along the bank would give it more even shade. It would mean redoing the pipe runs and the cable, so it is not a casual job. I would also like to compare the Zendgla with a different kind of exchanger at the same pond, but that would be a new project, not an extension of this one.

One idea I have rejected is painting the casing a lighter colour. Paint on ceramic is likely to flake into the pond, and it would change the very thing I am studying. If I want to know what the black does, I should shade it, not coat it.

## Observations

Over the seasons I have seen the same patterns again and again, so I am fairly confident in them.

In spring the unit is easy to live with. The water is cool, the sun is gentle, and the surface stays clean for weeks. Flow stays steady and I rarely touch anything.

In summer the black casing is clearly warm to the hand by mid-afternoon. The water around it does not seem to change, but the surface of the unit does. The algae film grows faster in this season, and the crust near the water line gets thicker. I clean it more often, about every few weeks.

In autumn, leaves are the main problem. They collect near the intake side and can reduce flow if I leave them. A quick check after windy days is enough to keep it clear.

In winter the unit sits quietly. The mains supply keeps it running, and I have not seen any cracks from frost, which was my biggest worry in the first year. I still check the casing after hard freezes.

Other things I have noticed:

- The unit makes a faint, steady hum, only audible when I stand right next to it. If the sound changes, something upstream has gone wrong.
- The ceramic stays clean-looking even when the film is present, so I cannot judge fouling by eye alone. I need to look at the flow.
- The area around the unit is slightly drier than the rest of the bank, probably from the warmth of the casing.
- Frogs sometimes sit on the warm side in the evening, and I leave them alone.
- There has been no sign of leaks at the joints since I re-seated them in the second year.

Overall, the unit behaves predictably. The surprises have nearly all come from me, not from the device.

## Measurements

I take readings with the same simple tools each time: a bucket and timer for flow checks, and a stick thermometer for temperature. They are not laboratory instruments, so I treat the numbers as good for comparison and not as exact truth.

The most recent flow check gave a flow rate of Zendgla heat exchanger: 1231.82 l/h. I took it on a dry day with the unit freshly brushed, so I regard it as close to the best the unit gives in its present setup.

For reference, here are the fixed properties again, so the readings have context:

- Kind: heat exchanger
- Area: ceramics
- Colour: black
- Energy source: mains
- Year installed: 2021
- Location: pond

How I take a reading:

- Run the unit for at least an hour before measuring, so the flow has settled.
- Measure on a day without strong wind, because leaves and ripples change the intake.
- Repeat the bucket test three times and use the middle result.
- Note the weather, the time and whether the unit was recently cleaned.
- Do not measure straight after cleaning without waiting, because loose debris can briefly alter the flow.

The flow figure is the one I trust most, because it is the easiest to repeat. Temperature readings vary more with the time of day and the sun on the casing, so I use them only to compare morning and afternoon on the same day.

What I would like to add next is a regular schedule: one reading each month, always at the same hour, written down in the same place. With a year of those I could see the effect of the seasons and of cleaning without relying on my memory. Until then, the flow figure above is my reference point, and any future reading that falls well below it is my signal to check the intake, the plug and the surface of the ceramic.
