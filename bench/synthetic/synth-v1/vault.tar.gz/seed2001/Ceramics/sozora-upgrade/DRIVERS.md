---
type: drivers
status: active
project: sozora-upgrade
area: ceramics
---

# Drivers of Sozora upgrade

## Ideas

The Sozora upgrade is a project in the ceramics area. Its goal is an upgrade, and the work began in the summer of 2023. My neighbor leads it, and I help where I am needed. These notes are about what drives the project: why we do it, what limits us, what money we have and how we will know it worked.

A few ideas keep coming back when I think about the drivers.

- The upgrade should make the ceramics work more reliable, so that fewer pieces are lost to avoidable mistakes.
- It should make the shared space easier to use for more than one person at a time.
- It should reduce the amount of time spent on repeated chores, such as moving things around, cleaning up and resetting the space after each session.
- It should be something we can maintain ourselves without calling in outside help every few weeks.
- It should leave us with a clear record of what was done, so that the next upgrade is easier to plan.

None of these ideas is a measurable target on its own. They are the reasons behind the targets. When I am unsure whether a decision is a good one, I come back to this list and ask which idea it serves. If a decision serves none of them, it is probably a distraction.

Another idea is to keep the scope small enough to finish. A project that starts in summer and drags into winter loses momentum, and the ceramics area is more pleasant to work in during warm months. So the plan favors a few solid changes over a long list of small ones.

## Background

The Sozora upgrade started in the summer of 2023. The area is ceramics, the goal is upgrade, and the lead is my neighbor. I am the second pair of hands and the one who keeps the notes.

The reason for the project is simple. The existing setup worked, but it had grown by accident. Things were added when someone needed them, and nobody planned how the parts would fit together. Over time this created small frustrations: tools in the wrong place, uneven working conditions, and a layout that made some tasks awkward.

My neighbor has more experience with ceramics than I do, which is why the lead role went to them. I made the first list of problems, and they sorted it by what mattered most. Their order was different from mine. I had put the cosmetic issues high up; they put the practical ones first. In hindsight they were right, and I have kept their order in these notes.

We agreed early on a few ground rules:

- Decisions are made together, but the lead has the final say if we disagree.
- We write down what we spend, as we spend it.
- We do not start a new part of the work until the previous part is finished and checked.
- We keep the old arrangement running as long as possible, so we are never left with nothing usable.

The last rule has cost us some time, but it has saved us from the worst kind of stress, which is having a half-finished space and no fallback.

The project is described as an upgrade rather than a rebuild on purpose. We keep what works, replace what does not, and improve what is merely adequate. That framing helps in arguments about whether to throw something away.

## Budget

The budget of Sozora upgrade is 24536.18 EUR.

This is the total amount set aside for the whole project. It is not a target to spend; it is a ceiling. If we finish under it, the remainder stays unspent and is not carried into some other purchase.

I think about the budget in broad groups rather than exact line items, because exact figures change as we learn more. The groups are:

- Main equipment and the larger changes to the space, which take the biggest share.
- Materials and consumables needed to carry out the work.
- Safety and cleanliness items, which I do not like to cut even when money is tight.
- A reserve for surprises, which I treat as part of the budget and not as spare money.

The reserve matters most. Every project I have kept notes on has had at least one cost nobody expected. Having a reserve means a surprise is an annoyance rather than a crisis. I try not to touch it unless something truly unplanned comes up, and when I do, I write down why.

Spending is recorded in a simple running list kept by me. My neighbor checks it now and then. We do not argue about small amounts, but anything large is discussed before it is paid. We agreed that "large" means anything that would noticeably change how much of the reserve is left.

When prices change between the time we plan a purchase and the time we make it, we note the difference. This helps with the lessons later, since price drift is one of the things that made earlier estimates wrong.

## Risks

The main risks I can see are listed here, with how I plan to handle each one.

- **Overspending.** The budget is firm, and the easiest way to break it is a steady stream of small extras. The answer is to write every spend down and to review the list regularly.
- **Delays.** Work that depends on deliveries or on both of us being free can slip. The answer is to order early and to plan the work so that one delayed item does not block everything else.
- **Poor fit.** Something we buy may not suit the space or the way we actually work. The answer is to measure twice, check the space before ordering, and ask my neighbor before committing.
- **Damage during the work.** Moving ceramics equipment and finished pieces around creates a chance of breakage. The answer is to clear and protect things first and to do heavy moving when both of us are there.
- **Loss of momentum.** A project begun in summer can fade as the weather changes. The answer is to keep the scope small and to finish the most important parts first.
- **Single point of knowledge.** My neighbor knows a lot that is not written down. If they are unavailable, I might be stuck. The answer is to write down what they explain as we go.
- **Safety.** Dust, heat and heavy items all carry real risk in this kind of work. The answer is to keep safety items in the budget and to stop work if something feels unsafe.

I rate overspending and poor fit as the two most likely risks. I rate damage during the work as the one with the worst immediate effect, because broken work cannot be bought back. I review this list at the start of each stage of the project and cross out risks that have passed.

## Maintenance

An upgrade is only worth the money if it stays in good condition. I therefore treat maintenance as part of the drivers, not as an afterthought.

The aim is that routine care can be done by the two of us, with no outside help. That shapes what we choose: simpler and more common parts and methods are preferred over clever ones that only a specialist could look after.

The routine I intend to follow is:

- A quick check after each working session, covering cleanliness, loose items and anything that looks worn.
- A fuller check at the change of each season, when I look at everything more carefully and write down what I find.
- A short log of repairs and adjustments, so that patterns show up over time.
- A habit of fixing small problems the same week they appear, before they grow.

My neighbor is better at spotting wear than I am, so the seasonal check is done together. I learn by watching what they look at and asking why.

I also want the maintenance routine to be written clearly enough that someone else could follow it. If I am away or ill, the work should not fall apart. That is partly a matter of writing and partly a matter of keeping the space tidy and labeled.

Over the long run I expect the cost of upkeep to be small compared with the original spend, but I do not have a firm figure. I will track it after the first year and compare it with my expectation. If upkeep turns out to be heavier than planned, that will be a sign that some choice made during the upgrade was wrong, and I will note it for the next project.

## Setup

The setup of the project is mostly about people, order of work and place.

**People.** My neighbor is the lead. I keep the notes, track the spending and handle most of the ordering. We both do the physical work. For jobs that need more hands, we ask friends, but only for short periods and only with plenty of notice.

**Order of work.** The plan goes in stages:

1. Clear and protect the area, and record how it looks before we start.
2. Do the most important changes first, the ones that fix the practical problems my neighbor ranked highest.
3. Check each finished change by using it for a few sessions before moving on.
4. Do the lower-priority improvements next, if time and money allow.
5. Finish with tidying, labeling and a full written record.

**Place.** The work happens in the ceramics area we already use. Because we keep the old arrangement running as long as possible, the work is done in pieces so some of the space is always usable.

**Measuring success.** Success is judged against the ideas listed at the top of this note. In practice I look at a few things:

- Whether the project stayed within the budget.
- Whether it was finished within the summer season, or close to it.
- Whether the routine chores take less time than before.
- Whether fewer pieces are lost to avoidable mistakes.
- Whether two people can work in the space together without getting in each other's way.
- Whether the maintenance routine can be kept up without outside help.

These are judgments rather than precise numbers, and that is fine for a small project like this one. I would rather have honest rough measures than exact ones that I do not trust.

## Supplies

Supplies are kept in three groups so I can find things and see what is running low.

- **Working materials.** The clay, glazes and related items used in the ceramics work itself. I keep only what we expect to use soon, since storage space is limited and some materials age.
- **Construction and fitting items.** Fixings, fittings, protective coverings and the small hardware that the upgrade itself needs. These are bought for the project and counted against the budget.
- **Safety and cleaning items.** Masks, gloves, cleaning materials and anything else that protects us or keeps the space clean. These are checked at the start of every stage.

For each group I keep a short list of what is on hand and what needs buying. I check it before every shopping trip to avoid duplicates, which used to be a regular small waste.

My neighbor and I have different preferences about where to buy. They like a local supplier they know well and trust for advice. I tend to compare options more widely. We settled on using the local supplier for anything where advice matters and comparing elsewhere for plain items where it does not.

I try to buy a little more than the minimum of common consumables, because running out in the middle of a job costs more time than the extra stock costs money. For specialized items I buy only what the stage in hand needs, since requirements can change.

Anything left over at the end of the project goes into the general stock of the ceramics area. I write down what was left, so it is not bought again by mistake.

## Lessons

The project is still in progress, so these lessons are partly from earlier work and partly from the early stages here.

- **Write things down at once.** Memory of what was spent or decided fades within days. Notes made on the spot are far more reliable than notes made later.
- **Listen to the person with experience.** My neighbor's ordering of priorities was better than mine. Putting practical problems ahead of cosmetic ones saved effort.
- **Keep a fallback.** Keeping the old arrangement usable has been worth the slower pace. It removes the pressure to rush.
- **Protect the reserve.** The reserve inside the budget has already reduced stress. Treating it as untouchable except for real surprises keeps it useful.
- **Small scope finishes.** Fewer, better changes beat a long list that never ends.
- **Test before moving on.** Using each finished change for a few sessions exposes problems while they are still easy to fix.
- **Label everything.** Labels cost almost nothing and save a lot of confusion, especially when someone else has to find something.

There are also things I would do differently. I would make the first list of problems together with my neighbor instead of alone, since my version needed reordering anyway. I would also take more photos of the area before starting, because my written description of the starting state is thinner than I would like.

At the end of the project I will return to this section, check which lessons held up, and add what I learned that I could not foresee now.

## References

These are the places in my own notes and records that this note relies on. They are described in words, as I keep no links for them.

- My running list of spending, which is the source for everything related to the budget.
- The first list of problems I wrote, together with my neighbor's reordered version.
- My notes from conversations with my neighbor about priorities and methods.
- The photos and written description of the area before the work began.
- The repair and adjustment log, which I will start once the first stage is complete.
- My notes from earlier small projects in the ceramics area, which informed the reserve and the ground rules.

If I add anything to this list, I record where it came from and why I trust it. Advice from my neighbor is marked as such, since it comes from experience and not from a written source.

## Overview

The Sozora upgrade is a project in the ceramics area. The goal is an upgrade. It started in the summer of 2023, and my neighbor is the lead.

The drivers can be summed up in a few lines. The project exists to make the ceramics space more reliable, easier to share and less tiring to use, while staying simple enough for the two of us to maintain. The budget is 24536.18 EUR, treated as a firm ceiling with a reserve inside it. The main constraints are that the space must stay usable during the work, that the scope must stay small enough to finish in good time, and that safety is never traded away to save money.

Success is measured by whether the project stays within budget, whether it is finished close to the summer season, whether chores take less time, whether fewer pieces are lost, whether two people can work together comfortably and whether we can maintain the result ourselves.

The biggest risks are overspending, poor fit and damage during the work. The plan for each is written above. The most useful habits so far have been writing things down immediately, following my neighbor's priorities and keeping a fallback in place.

When the project ends I will review this note against what actually happened, update the lessons and keep the note as a starting point for the next upgrade.
