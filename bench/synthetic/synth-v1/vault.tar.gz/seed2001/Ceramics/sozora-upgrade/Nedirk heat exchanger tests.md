---
type: research
status: active
project: sozora-upgrade
area: ceramics
description: "Research about Nedirk heat exchanger."
---

# Nedirk heat exchanger tests

## History

The Nedirk heat exchanger is a black heat exchanger that I installed in the yard in 2022. It runs on mains power. I use it in my ceramics work, which is the area this note belongs to. I bought it second-hand from a person who had used it for a small pottery studio, and the paint was already a little worn when it arrived. It sat in the garage for a few weeks before I found a good place for it.

The first year was mostly about getting it to work at all. I ran it with short cycles and wrote down what I saw. In the second year I began to test it more carefully, because I wanted to know whether it was worth keeping outside through the winter. By the third year I had a routine, and this note collects what I learned from the tests.

A short timeline of how things went:

- 2022: installed in the yard, connected to mains, first short runs.
- 2023: longer runs, first notes on how the surface behaves in cold weather.
- 2024: tests with different loads and different pauses between runs.
- 2025: a review of wear, cleaning, and a check of all connections.
- 2026: this write-up, and a plan for what to test next.

## Setup

The unit stands in the yard on a flat base of paving slabs. I leveled it with thin shims and checked it again after the first heavy rain, because the ground settled a little. The black casing absorbs sun, so on bright days the outside gets warm even before the unit is switched on. I keep that in mind when I read temperatures.

The power comes from the mains through an outdoor-rated cable that runs along the wall of the shed. I put a small cover over the plug connection so water cannot sit on it. The cable is tied up off the ground with clips.

For the tests I use the same basic arrangement each time:

- The unit is switched on and left to settle for a fixed time before I measure anything.
- I record the air temperature in the yard and note whether it is sunny, cloudy, or raining.
- I take readings at the inlet and the outlet at regular intervals.
- I write the readings on paper first and copy them to the computer in the evening.
- I clean the outside before the first test of a season so dust does not change the results.

The location in the yard matters. It is exposed to wind from one side, and I have noticed that strong wind changes the readings. I tried a simple screen made of plywood, and it helped a little, but I do not trust it as a permanent fix. So for the cleanest comparisons I run tests on calm days only.

## References

I keep this list short and practical. These are the things I go back to when I check my own notes.

- The paper manual that came with the unit. It is thin and some pages are missing, but the diagram of the connections is still useful.
- My own logbook, a notebook with a blue cover, where the raw readings from every test are written.
- Notes from the person who sold me the unit, which I wrote down during a phone call. They mention that the unit should not be left running with the cover off.
- A general book on kiln and studio equipment that I borrowed once. It has a chapter on heat recovery that helped me understand what the exchanger is supposed to do.
- My earlier notes on ceramics firing, which explain why the heat output matters for the rest of the workshop.

I have not found any official test standard that fits this unit, so my method is homemade. I try to keep it consistent from one season to the next so that the results can at least be compared with each other.

## Background

A heat exchanger moves heat from one stream to another without mixing the two. In my case the purpose is to recover some of the warmth that would otherwise be lost during ceramics work, so that I use less energy overall. The idea is simple, but in practice the result depends on many small things: how clean the surfaces are, how steady the flow is, and how large the difference in temperature is between the two sides.

The Nedirk heat exchanger is a compact unit with a black outer casing. Black matters outdoors because it takes up sunlight. This can help in winter and hurt in summer. I did not choose the color, but I have learned to account for it.

Why I test it at all: I wanted to answer a plain question. Is the unit doing useful work, or is it just running and using electricity? My tests are meant to give an honest answer, and to show when the unit works best. I also wanted to know how it ages when it stays in the yard all year.

What I look at in each test:

- How much the temperature changes between inlet and outlet.
- How long the unit takes to reach a steady state after switching on.
- How the readings change over a long run.
- How the weather changes the result.
- Whether any noise, vibration, or smell shows up that was not there before.

A few general observations from the years of use. The unit warms up slowly, and short runs give poor results because most of the time is spent reaching a steady state. Long runs are much more useful. The readings drift a little as the day warms up, so I always compare tests made at similar times of day. Dirt on the surface reduces performance more than I expected, and cleaning gave a clear improvement each time I tried it.

## Open questions

There are several things I still do not understand, and I want to keep them written down so that I do not forget them.

- Does the black casing cause overheating on the hottest summer days, and does that shorten the life of the unit?
- How much does wind really change the result, and would a proper screen make a permanent difference?
- Is the drop in performance over the years real, or is it just a change in how I measure?
- Would a different position in the yard, for example closer to the wall, give steadier readings?
- Is it worth covering the unit in winter, or does the cover trap moisture and cause more harm?
- How does the unit compare with a newer model of the same kind? I have no way to test this at the moment.

I plan to take these one at a time. The wind question is probably the easiest, since I can compare days with and without the screen. The overheating question needs a very hot day and a way to measure the casing temperature safely.

## Costs

I keep a rough record of what the unit costs me. I do not write exact prices here, only the general picture.

- Purchase: the unit was bought second-hand and was cheaper than a new one by a good margin.
- Installation: small, mostly the paving slabs, the outdoor cable, and the plug cover.
- Electricity: this is the main running cost. It is hard to separate from the rest of the house, so I estimate it from how many hours the unit runs.
- Maintenance: cleaning materials and the occasional replacement of small fittings.
- My time: each test takes a few hours, and I count this as a cost too, even if I do not pay for it.

My overall feeling is that the cost is acceptable for the use I get out of it. The running cost is what I would watch most carefully. If I find that the unit is not recovering much heat, then the electricity would not be justified. This is one more reason to keep testing in a consistent way.

## Tools

The tools I use for the tests are simple and mostly things I already had.

- Two digital thermometers with probes, one for the inlet and one for the outlet. I compare them against each other before each season to make sure they agree.
- A stopwatch, which is the timer on an old phone.
- The blue logbook and a pencil, since pens run in the damp.
- A soft brush and a cloth for cleaning the casing.
- A small spirit level for checking that the unit is still flat.
- A set of shims, in case the ground settles again.
- A plywood screen for testing the effect of wind.
- A flashlight, because some of my winter tests finish after dark.

I would like to buy a better way to measure airflow, but so far I have managed without it. The two thermometers give me enough for the comparisons I care about. Before each season I check them side by side in the same place, and if they differ I note the difference and correct for it.

## Safety

The unit runs on mains power and stands outside, so safety deserves attention. I treat it seriously even though nothing has gone wrong so far.

- The power connection is protected from rain by a cover, and I check the cover before every test.
- The supply goes through a residual current device, which I test regularly using its test button.
- I never open the casing while the unit is connected to the mains. I switch off and unplug first.
- The black casing can become hot in the sun and during long runs, so I wear gloves when I touch it.
- I keep children and pets away from the area during tests.
- I do not run the unit during a storm.
- I keep the cable off the ground and away from standing water.

If I notice a burning smell, a strange noise, or any sign of damage to the cable, I stop the test at once and disconnect the unit. I would then inspect it before running it again. I wrote these rules down so that I follow them even when I am in a hurry.

## Problems

Over the years I have run into a few problems. None was serious, but each one taught me something.

- Dust and pollen settle on the surface in spring and lower the performance. Regular cleaning fixes this.
- Water got into the plug connection once during heavy rain, before I fitted the cover. The residual current device tripped, which is exactly what it should do. The cover solved the problem.
- The ground settled on one side, so the unit was no longer level. I fixed it with shims.
- The paint on the casing has faded in a few places from sun and weather. This looks bad but does not seem to affect how the unit works.
- Wind makes readings unstable, and I still have no permanent answer to this.
- A fitting became loose after one winter and I had to tighten it. Now I check all the fittings every spring.
- My own measurements are not perfectly consistent. Sometimes I forget to wait long enough before reading, and I have thrown away a few tests because of that.

The general lesson is that most problems come from the yard environment rather than the unit itself. Weather, dirt, and settling ground cause more trouble than any fault in the device.

## Parts

The part number of the Nedirk heat exchanger is GC-0308-X. I wrote it here because the label on the casing has faded and is now hard to read, and I do not want to lose it. If I ever need to order a spare or ask someone about the unit, this is the number I would give.

Here is a summary of the properties of the unit, for quick reference:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: mains
- Year installed: 2022
- Location: yard

Other parts I keep track of in a general way:

- The outdoor cable and its plug cover, which I added myself.
- The shims under the base, which keep the unit level.
- The connection fittings, which I check each spring.
- The plywood wind screen, which is only used during tests.

I do not have a full parts list from the maker, so these notes are what I rely on. If I find the missing pages of the manual, I will add anything useful here.
