---
type: summary
status: active
project: sozora-upgrade
area: ceramics
description: "Summary about Sozora upgrade."
---

# Summary of Sozora upgrade

## Checklist

This note summarizes the Sozora upgrade, a project whose goal is upgrade. It sits in the ceramics area and started in 2023, in the summer season. The lead is my neighbor, who has carried most of the practical side from the beginning.

Current stage: the project is under way. The idea has been approved, the first round of work has been done, and what remains is mostly finishing and checking.

Done so far:
- [x] Agreed the goal with the neighbor: an upgrade of the existing setup, not a rebuild.
- [x] Cleared the workspace and sorted the tools and materials that we already had.
- [x] Did the first trial pieces and wrote down what worked and what did not.
- [x] Settled who does what, with the neighbor leading and me helping and keeping notes.
- [x] Kept a short log of each session so we do not repeat mistakes.

Open points:
- [ ] Repeat the trial pieces once more to confirm the results are steady.
- [ ] Decide where the finished items will be stored and how they will be protected.
- [ ] Ask the neighbor for a final list of anything still missing.
- [ ] Tidy the notes into one clean reference page after the work is finished.
- [ ] Review the whole project once everything is in use and see whether the upgrade met its goal.

The main risk is that small jobs keep getting pushed back because the work depends on the neighbor's free time. I should keep each step small so it can be done in a single afternoon.

## Next action

The next action is NX-0109. I want to do it at the next session with the neighbor, so I should bring my notes and the session log. When it is done, I will tick it off in the checklist above, write a line in the log and pick the following open point. If it turns out to be larger than expected, I will split it into smaller parts instead of leaving it half finished.

## Decisions

- Go decision date: 2021-07-21. This is when the project was given the green light, well before the 2023 summer start, and the plan has not changed since.
- The neighbor stays as lead for the whole project. I support and record.
- The scope stays limited to the upgrade. Anything that looks like a new project goes into a separate note.
- Trial pieces come before the final work, so mistakes are cheap.
- Notes are kept after every session, even short ones, because I tend to forget the details otherwise.
