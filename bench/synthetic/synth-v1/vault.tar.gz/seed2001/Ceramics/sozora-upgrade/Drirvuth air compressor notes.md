---
type: note
status: active
project: sozora-upgrade
area: ceramics
description: "Note about Drirvuth air compressor."
---

# Drirvuth air compressor notes

## Safety

The Drirvuth air compressor is a blue, solar-powered air compressor that I installed in the loft in 2025. It is used for the ceramics work, so most of my safety habits come from that setting: dust, heat, and a tight space up under the roof.

- Before any work on the compressor, I switch off the solar feed and wait until the pressure gauge reads zero. Solar power keeps arriving whenever there is daylight, so the unit is never really "off" on a bright afternoon unless I cut the feed myself.
- I release the tank pressure through the drain valve slowly, with my face turned away from the outlet.
- The loft gets hot in summer. I do not run the compressor for long stretches when the air up there is stifling, because the motor runs warmer and the hoses get soft.
- I wear eye protection every time I use the air line. Dried clay dust and glaze powder blow around easily, and I do not want either in my eyes.
- I keep a dust mask next to the ladder. Blowing clay dust off a shelf with compressed air is a bad idea, so I vacuum instead and use the air only for tools and small parts.
- The hatch to the loft is narrow. I never carry the tank or any heavy part up the ladder alone.

If I smell anything hot or burnt, I stop, cut the solar feed, and look at the wiring before doing anything else.

## Supplies

The things I keep in a small crate beside the compressor so I do not have to climb down for them:

- Spare hose clamps and a short length of spare air hose
- Thread seal tape for the fittings
- Light machine oil for the moving parts, used sparingly
- A clean cloth and a small brush for the cooling fins
- A soft pencil and a roll of masking tape for marking positions
- A small bottle of soapy water for leak checks
- Spare filter element for the intake

The soapy water is the one I use most. I brush it on each joint while the tank is under pressure, and any bubbles show a leak right away. It is much quicker than listening for a hiss.

The compressor feeds the air line used for the glaze sprayer and for cleaning kiln furniture. Because of that, I try to keep the intake filter fresh. A clogged filter makes the motor work harder, and on a solar supply that matters more, since a cloudy day already limits how much power there is.

I also keep a notebook page taped inside the crate lid with the dates of the last filter change and the last leak check. I do not trust my memory for those.

## References

Notes and things I look at when something needs sorting out:

- [[Braessios heat exchanger]]: the heat exchanger is the nearest other piece of equipment that deals with heat in the same part of the workshop. When the loft gets very warm, I check my notes on it to compare how each unit behaves, because the same hot spell affects both.
- The maker's paper manual, kept in the drawer under the glaze shelf. It has the pipe layout and the wiring sketch. I have scribbled corrections in the margins where it did not match what I actually installed.
- My own installation photos from 2025, stored in the project folder on the computer. They show the way the hoses were routed and where the mounting bolts went, which I would otherwise forget.

Quick facts about the unit, kept here so I do not have to search:

- Kind: air compressor
- Area of use: ceramics
- Color: blue
- Energy source: solar
- Year installed: 2025
- Location: loft

If I ever move the compressor, I will update this list first, then fix the links in the other notes that mention it.

## Adjustment

The compressor sits on a plate that can shift a little, and the pressure switch and the belt guard both depend on it being in the right place. Over the first months after installing it in 2025, the plate crept slightly, so I now check the setting every season.

The calibration offset of the Drirvuth air compressor is 0.344 mm. That is the gap I measure between the plate edge and my marked reference line when everything is set correctly. If the gap is bigger or smaller, I loosen the mounting bolts a quarter turn, tap the plate into place, and tighten again.

My routine for the adjustment:

- Cut the solar feed and drain the tank to zero.
- Wipe the plate and the reference line clean so the measurement is honest.
- Measure the gap with feeler strips and compare it with the offset above.
- Loosen the bolts slightly, nudge the plate, and tighten them in a cross pattern.
- Measure again, then run the compressor for a few minutes and listen for any new rattle.
- Brush soapy water on the joints one more time, since moving the plate can disturb a fitting.

If the offset keeps drifting even after I tighten everything, the likely cause is the loft floor flexing as the temperature changes. In that case I will add a small shim under one corner and write down which corner and why. Until then, a seasonal check is enough.
