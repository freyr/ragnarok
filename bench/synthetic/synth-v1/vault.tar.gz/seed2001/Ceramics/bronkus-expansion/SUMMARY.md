---
type: summary
status: active
project: bronkus-expansion
area: ceramics
description: "Summary about Bronkus expansion."
---

# Summary of Bronkus expansion

## Checklist

Bronkus expansion is a project with the goal of expansion in the area of ceramics. It started in 2026, in the summer season, and the lead is the carpenter. The project is in the build-and-review stage. The main shape is settled, and the details are still being checked.

- [x] Confirm the goal: expansion of the ceramics area
- [x] Name the lead: the carpenter
- [x] Fix the start year at 2026 and the season at summer
- [x] Compare the two shed layouts in [[Krespa shed plan]] and [[Trenvios shed plan]]
- [x] Read the heat notes in [[Kesdridaer heat exchanger study]]
- [x] Walk through the upper storage ideas in [[Zukriond loft notes]]
- [ ] Settle the final shed layout
- [ ] Decide which unit goes in, using [[Navis heat exchanger]] as the main candidate
- [ ] Check the kiln-side wiring plan with the lead
- [ ] Write up the final materials list

Open points:

- The two shed plans still disagree on where the door goes. I lean toward the one that keeps the drying shelves out of the draft.
- The heat study is useful, but it does not say how the unit behaves in a small room with clay dust. That needs a second opinion.
- The loft idea is attractive, but the load on the floor is not yet checked.

## Decisions

The go decision date for Bronkus expansion is 2018-04-24. That is the date I wrote down when the idea was first accepted as worth doing. The actual work only began in 2026, in the summer season, once the carpenter took the lead.

Other decisions so far:

- The project stays an expansion of the existing ceramics area, not a move to a new place.
- The carpenter leads and makes the final call on structure. I make the call on what goes inside the space.
- I prefer to build the shed first and add the loft later, if the floor check passes. The ideas for it stay in [[Zukriond loft notes]] for now.
- For advice on the working layout I rely on [[Dithkruth Nanbikron notes]], which are practical and close to how I actually work.
- For contacts and suppliers I go through [[Riorraen Saethkion]], who knows the local trade and has been quick to answer.
- The bench and storage sizing follows [[Rutro Storkstal notes]], unless the shed plan forces a change.

Not decided yet: the final shed layout and the choice of heat unit. Both wait on the checks listed above.

## Next action

The next action for Bronkus expansion is NX-4723.

Once that is done, I will go back to the checklist and close the open points in this order: first the door position in the shed plan, then the heat unit choice, then the wiring check with the carpenter. After that I will update this summary with the stage and a clean list of what is finished.
