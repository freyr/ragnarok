---
type: drivers
status: active
project: bronkus-expansion
area: ceramics
description: "Drivers about Bronkus expansion."
---

# Drivers of Bronkus expansion

## Observations

Bronkus expansion is a ceramics project with the goal of expansion. It starts in summer 2026, and the lead is the carpenter. I keep this note for the reasons behind the project, so I can check later whether the choices still make sense.

What I have noticed so far:

- The current setup in the ceramics area is too small for the amount of work I want to do. Shelves and drying space fill up fast.
- Wood work is a large part of the job: racks, benches and a better layout for the workshop. That is why the carpenter leads the project and not someone from the pottery side.
- Summer suits the project because the drying time is short and the doors can stay open while building.
- Work should be done in small steps, so the workshop can still be used during the build.

### Goal

The goal is expansion: more room, more storage and a calmer workflow from clay to finished piece.

### Constraints

- Time: the work belongs to summer 2026, and anything unfinished has to wait for the next season.
- Space: the new parts must fit the existing building without moving the kiln.
- Money: everything has to stay inside the budget below.
- People: one lead, the carpenter, with me helping on the lighter tasks.

### Success measures

| Measure | What I check | Target |
|---|---|---|
| Space | Can all current work be stored and dried without stacking? | Yes |
| Workflow | Is there a clear path from clay to kiln to shelf? | Yes |
| Timing | Is the build finished within the summer season? | Yes |
| Cost | Is the total at or under the budget? | Yes |

I will review these four measures at the end of the season and write down which ones were met and which were not. If the space and workflow measures are met but the timing is missed, I will still call the project a partial success, because those two matter most to me.

## Budget

The budget of Bronkus expansion is 30491.81 EUR.

How I plan to treat it:

- Keep the money for the main build first: wood, fixings and the shelving.
- Hold back a part for surprises, because old buildings often hide problems once the walls are opened.
- Record each purchase as it happens, so I do not guess the total at the end.
- Stop and rethink if the spending runs ahead of the progress.

The budget is a limit, not a target. If the work finishes cheaper, the rest goes to tools and storage for the next ceramics project. If it goes over, I will cut the optional extras before touching the structure, since those are what the goal depends on.
