---
type: note
status: active
project: bronkus-expansion
area: ceramics
---

# Triondfis kiln controller notes

## References

- Device: Triondfis kiln controller
- Kind: kiln controller
- Area: ceramics
- Color: grey
- Energy source: mains
- Year installed: 2018
- Location: shed

The controller sits in the shed next to the kiln. It is grey, runs from mains power, and has been in use since 2018. I keep these notes for my own reference, mainly so I remember how it behaves when I fire a load.

Things I check before each firing:

- The power cable and plug are not warm or damaged.
- The controller case is clean and free of dust.
- The shed is dry, since damp air is the main risk for the electronics.

## Measurements

- Flow rate: 1152.07 l/h

This is the figure I wrote down for the Triondfis kiln controller. I use it as a baseline when I compare one firing with another. If a later reading looks very different, I check the connections and the surroundings before I blame the device.

Other notes on measuring:

- I take readings with the shed door closed, so drafts do not change the result.
- I write the reading down right after the controller has settled, not while it is still starting up.
- I keep the readings in this note so I can see changes over the years since 2018.

The controller has been reliable so far, and the shed location has not caused any trouble.
