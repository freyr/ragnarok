---
type: note
status: active
project: bronkus-expansion
area: ceramics
description: "Note about Birkpioth pond."
---

# Birkpioth pond notes

## Supplies

These are the things I keep on hand for Birkpioth pond. It is a medium pond, built in 2019, and it sits at ground level on the south side of the ceramics area. Because it is a working pond tied to the studio, I keep the supplies in two groups: things for the water, and things for the equipment.

For the water:
- A basic test kit for hardness, acidity and cloudiness. I use it every time I check the pond.
- A bag of pond-safe water conditioner, for when I top up with tap water.
- A long-handled net for leaves and floating clay flakes.
- A bucket I use only for the pond and nothing else. Soap or glaze residue in a bucket is a real risk to the water.
- A small stock of clean sand and fine gravel for patching the edges.

For the equipment:
- Spare hose clamps and a few lengths of flexible hose.
- A soft brush and a plastic scraper for cleaning the heat exchanger surfaces without scratching them.
- Rags, gloves and a headlamp for the early-morning checks in winter.
- A notebook that stays in the shed, so readings get written down on the spot and not remembered wrongly later.

I try never to let the conditioner or the test kit run out. Everything else I can replace within a day or two, but those two matter right away.

## Risks

The main risks I have noted so far, roughly in order of how worried I am about them:

1. **Clay and glaze getting into the water.** The pond is in the ceramics area, so dust, slip and rinse water are always close. Even a small amount of glaze material in the pond could harm it. I keep rinse buckets well away from the edge.
2. **Overheating or overcooling.** The pond is tied to a heat exchanger, so a stuck valve or a blocked flow could push the temperature outside what is comfortable for the pond's life. Watch the readings, not the weather.
3. **Sun exposure.** The pond faces south, so it gets the strongest light for most of the day. In summer that means warm water and fast algae growth.
4. **Leaks at the fittings.** Hose joints are the weak point. A slow leak lowers the level and can go unnoticed for days.
5. **Frost.** At ground level, the pond edge and the pipework near it are exposed. A hard frost can crack exposed fittings.
6. **Slipping.** The edge gets wet and slick. Anyone carrying heavy ceramics near it should take care.
7. **Power loss.** If the pump stops, the heat exchange stops too. Water goes still and the temperature drifts.

None of these has caused a serious problem yet, but the first three have come close.

## Ideas

Things I would like to try, none of them started:

- Put a light shade on the south side, maybe a trellis with climbing plants, to cut the harshest afternoon sun without blocking the view.
- Add a small settling basin where studio rinse water can sit before any of it is released elsewhere, so that nothing goes near the pond.
- Fit a simple float marker so I can see the water level at a glance from the studio door.
- Add a few more shallow planting shelves along one edge for better shelter and more natural filtering.
- Build a lid or cover frame for the equipment access point to keep leaves and clay dust out.
- Compare my readings with the findings in [[Vanstol heat exchanger study]] and see whether my pond behaves the same way.
- Keep a yearly photo, taken from the same spot in the same month, to see how the planting changes.
- Check whether any of the kiln waste heat could be used, which would link this to [[Burstimu kiln controller 2019]]. This is only a thought for now, and I would need to look into safety first.

## History

Birkpioth pond was built in 2019. It is a medium pond, and it was placed at ground level in the ceramics area with its main orientation to the south.

The first year was mostly about getting the shape right. The edges were reworked once because the original slope was too steep and soil kept sliding in. After that I settled on a gentler profile with one deeper section.

The heat exchanger was added as part of the original idea, not as an afterthought. The plan was to use the pond as a thermal buffer for the ceramics area, and the timing lined up with the work I recorded in [[Burstimu kiln controller 2019]], when I was also rethinking how heat moves around the studio.

In the years since, the changes have been small: replaced hoses, a better cleaning routine, new plants along the edge and a slightly different schedule for checking water. The basic layout of 2019 is still what is there today.

## Setup

The pond is a medium-sized body of water at ground level. There are no steps, no raised walls and no stairs to get to it. You walk straight up to it from the ceramics area, which makes cleaning and checking easy.

Layout notes:
- **Orientation:** south. The long side faces the sun, so the warm side and the cool side of the pond are easy to tell apart.
- **Edge:** one side has a gentle slope for planting and for small animals to get out. The other side is firmer, and I use it for access.
- **Depth:** one deeper section holds cooler water in summer and gives some protection in winter.
- **Pipework:** the hoses run from the pond to the heat exchanger along the ground. I keep them tidy and labelled with tape so I can tell supply from return.
- **Shed:** the shed is nearby and holds the notebook, the test kit and the spare parts.

When I set things up after a long break, I do it in this order: check the level, check the hoses, check the pump, then start the circulation and watch for leaks for at least a quarter of an hour before leaving it alone.

## Equipment

The one installed device that matters most is the **Stondneth heat exchanger**. It is the heart of the pond's technical setup, and everything else is there to support it or to protect it.

What I know about how it fits into the pond:
- It is connected to the pond water by hoses and a pump, so water moves through it rather than the exchanger sitting passively in the pond.
- Its job is to move heat between the pond and the studio side, so the pond works as a buffer rather than just a decoration.
- Its surfaces are the part that gets dirty first. Fine clay dust and algae both show up there.
- It needs steady flow. If the flow drops, performance drops too.

Other equipment around it:
- A circulation pump, which I treat as a consumable and not as something permanent.
- Hoses and clamps, checked regularly.
- A basic thermometer in the pond and another near the exchanger, so I can compare the two.
- A small shelf in the shed for the test kit and the cleaning tools.

For background on how this type of exchanger behaves, I go back to [[Vanstol heat exchanger study]]. I do not treat it as the final word, but it helps me judge whether my readings look normal.

## Maintenance

Maintenance is simple but has to be regular. The order below is what I follow.

**Each visit**
- Look at the water level and the colour.
- Skim leaves and clay flakes off the surface.
- Look at the hose joints for drips or damp ground.
- Listen to the pump. A change in sound usually comes before a failure.

**Each month**
- Run the water test and write the results down.
- Brush the visible surfaces of the heat exchanger gently.
- Check that the clamps are still tight.
- Trim plants that are growing over the edge too much.

**Each season**
- Do a deeper clean of the exchanger and flush the lines.
- Check the sloped edge for erosion and patch it with sand and gravel.
- Replace worn hose sections before they fail.
- Think about what the coming weather will do. Before winter I drain exposed fittings if frost is likely. Before summer I check the shade and the water level.

**Rules I keep**
- Never use soap or strong cleaners near the pond.
- Never rinse tools from the ceramics area in or near the pond.
- Write down anything unusual, even if it seems small.

## Schedule

This is the rhythm I try to keep. It is not strict, but it works if I stay close to it.

| Frequency | Task | Notes |
|---|---|---|
| Every visit | Level, colour, hoses, pump sound | Quick walk around, a few minutes |
| Weekly | Skim surface, empty the net | More often in autumn |
| Monthly | Water test and written record | Keep in the shed notebook |
| Monthly | Brush the heat exchanger surfaces | Soft brush only |
| Each season | Deep clean, flush lines, edge repair | Pick a dry day |
| Before winter | Drain or protect exposed fittings | Watch the frost forecast |
| Before summer | Check shade, planting and level | South side gets strongest sun |
| Once a year | Photo from the same spot | Same month each year |

If I miss a week I do not panic, but if I miss a whole month I start with the full set of checks and not just the quick ones.

## Costs

I do not keep exact accounts for this pond, so I am describing the costs in general terms and not with figures.

- **Biggest cost:** the heat exchanger itself and the work of installing it. That was a one-time cost, paid when the pond was built in 2019.
- **Medium costs:** the pump and large replacement hose sections. These come around every few years.
- **Small, repeated costs:** conditioner, test kit refills, clamps, brushes and rags.
- **Hidden costs:** my own time. A visit is short, but the seasonal tasks take half a day, and that adds up.
- **Costs I avoid:** buying decorative extras that need more upkeep than they are worth.

If I ever do a proper budget, I will split it into build cost, yearly running cost and replacement reserve. For now the main lesson is that the pond is cheap to run once the equipment is in place, provided I keep up with maintenance. Skipping the small jobs is what leads to the expensive repairs.

## Overview

Birkpioth pond is a pond in the ceramics area. It is medium in size, was built in 2019, faces south and sits at ground level. Its installed device is the Stondneth heat exchanger, which links the pond to the heat needs of the studio side.

In practice, the pond does two jobs. It is a calm, living water feature next to a busy workspace, and it is a working thermal element. Those jobs sometimes pull in different directions. A pond wants stable conditions and clean water, while an exchanger wants flow and a steady temperature difference. Most of my notes are really about keeping these two aims in balance.

Quick facts:
- **Kind:** pond
- **Area:** ceramics
- **Orientation:** south
- **Size:** medium
- **Year built:** 2019
- **Floor:** ground level

Related notes: [[Vanstol heat exchanger study]] for the equipment background, and [[Burstimu kiln controller 2019]] for the heat side of the studio.

## Background

The reason for building a pond in the ceramics area was partly practical and partly personal. The ceramics area produces a lot of heat, dust and noise. A pond next to it softens that. It also gave me a way to try out the idea of using water as a thermal buffer.

The south orientation was chosen on purpose. It gives good light for plants and helps keep the water from getting too cold in colder months. The downside is that summer sun can be strong, which is why shading is on my ideas list.

Ground level was also a deliberate choice. A raised pond would have needed walls and more materials, and it would have been harder to reach. A ground-level pond is easy to walk up to, easy to clean and easy to blend into the surroundings. The trade-off is that it is more exposed to frost and to anything carried in by feet or wind.

The medium size is a compromise. A smaller pond would swing in temperature too quickly. A larger one would have cost more and needed more upkeep. Medium has turned out to be about right for one person to look after.

## Observations

Things I have noticed over the years, written down so I do not forget them:

- The south side warms up first in spring, and plants there start growing earlier than those elsewhere.
- Algae grows fastest in the strongest sun, usually in the middle of summer. It shows up on the heat exchanger surfaces and on the pond edge first.
- Clay dust drifts in on dry, windy days, and the water looks slightly cloudy afterwards. It settles in a day or so if I leave it alone.
- The pump sound changes when the intake is partly blocked. This is my earliest warning sign.
- After heavy rain, the level rises and the colour changes. I do not adjust anything unless the water test shows a real problem.
- The gentle slope on one edge is used by small creatures to get in and out. I have seen it often enough to leave that part alone.
- Hose joints are where nearly all the small problems start.
- Readings are only useful if I take them at similar times of day. Morning and late afternoon give very different numbers.

When something looks odd, I compare my notes with [[Vanstol heat exchanger study]] before I decide to change anything.

## Tools

The tools I actually use, in the order I reach for them:

1. **Long-handled net:** for surface cleaning.
2. **Soft brush:** for the heat exchanger and the edges.
3. **Plastic scraper:** for stubborn algae, never metal.
4. **Test kit:** for the monthly water check.
5. **Thermometers:** one in the pond, one near the exchanger.
6. **Screwdriver and spanner:** for hose clamps and fittings.
7. **Bucket:** used only for the pond.
8. **Headlamp:** for dark winter mornings.
9. **Notebook and pencil:** pencil because it still works when my hands are wet.

I keep them together in one box in the shed so nothing goes missing. After each use, I rinse the tools with clean water and let them dry. If a tool has been near glaze or slip in the studio, it does not go near the pond until it has been thoroughly cleaned, or it gets a separate place on the shelf.

## Open questions

Things I still do not know or have not decided:

- Is the south-facing position causing more summer problems than I think? I have not measured this properly.
- How much of the heat exchanger's performance loss is due to dirt, and how much is due to the pump or hoses?
- Would shading the pond make a real difference to the algae, or only a small one?
- Is there a safe way to connect the pond to the kiln-side heat described in [[Burstimu kiln controller 2019]], or is that a bad idea?
- Should I replace the hoses on a fixed schedule instead of waiting until they show wear?
- Is a medium size still the right choice, or would a small extension help with temperature stability?
- Do my readings match what [[Vanstol heat exchanger study]] would predict, or am I doing something different?
- What is the best way to keep clay dust out of the water without covering the pond completely?

I will add answers here as I find them, and move anything settled into the sections above.
