---
type: research
status: active
project: bronkus-expansion
area: ceramics
description: "Research about Kesdridaer heat exchanger."
---

# Kesdridaer heat exchanger study

## Background

This note is the first part of my long study of the Kesdridaer heat exchanger. I keep it so that when something goes wrong in the shed, I can read what I already know instead of working it out again. It is written for my own use, so it is plain and a little repetitive on purpose.

The Kesdridaer heat exchanger is a heat exchanger. Its area is ceramics, meaning the working body of the unit is a fired ceramic core and not a metal coil. Its color is black. The black finish is not decoration: dark ceramic takes up sunlight better and gives up heat more evenly than a pale body would. Its energy source is solar, so it has no burner, no mains heater and no fuel line. It was installed in 2022, and its location is the shed at the back of the plot.

Here is the short list of properties, so I can find them quickly:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: solar
- Year installed: 2022
- Location: shed

### Why I started the study

I put the unit in during 2022 because the shed was damp in winter and too hot in summer. I wanted something that would move heat around without drawing power. A solar-driven ceramic exchanger looked like a good fit. It has few moving parts, and ceramic does not rust the way the old metal fittings in the shed did.

At first I just used it and did not write anything down. After the first couple of seasons I noticed that its behavior changed with the weather in ways I could not remember from one month to the next. That was when I began keeping notes, and this study grew out of them.

### How the unit works, in my own words

Sunlight lands on the black outer face and warms the ceramic. The ceramic passes that heat into the channels running through its body. Air or water moving through those channels picks up the heat and carries it where I want it. When the sun goes in, the ceramic keeps giving heat back for a while, which smooths out the swings. That slow release is the main reason I chose ceramic.

I am not an engineer, so I describe the unit by what I can see and feel:

- the face warms first, then the body, then the outlet
- the outlet stays warm for a good while after the face has cooled
- the unit is quiet, with no hum or rattle
- the black surface collects dust quickly, and a dusty face works noticeably worse

### Scope of this part

This part covers the background, the sources I lean on, and my first observations. Later parts go into maintenance, performance over the seasons, faults, and comparisons. I try not to repeat here what belongs in those parts.

### Things I am not sure about

I should be honest about the gaps. I do not know the exact composition of the ceramic. I do not know how long the glaze on the black face is meant to last. I have only a rough feel for how much heat the unit actually delivers on a poor day, because I have never measured it with proper instruments. Where I guess in this study, I say so.

## References

I did not find much written about this exact unit, so my references are mostly my own earlier notes and a few related notes in the same knowledge base. I would rather list them honestly than pretend there is a large literature behind this.

### Linked notes

The first related note is [[Vanstol heat exchanger study]]. That is my study of another heat exchanger, and it is the closest comparison I have. The Vanstol unit has a different build, so I use it mainly to check whether something I see on the Kesdridaer is normal or particular to this unit. When both units show the same pattern, such as slow warm-up in the morning, I treat it as a general trait of heat exchangers. When only the Kesdridaer shows it, I look at the ceramic or the black finish as the cause.

The second is [[Zolbrel loft handbook]]. It is mostly about a loft space, but it has useful notes on how heat collects under a roof and how ventilation changes it. The shed has a similar roof, so the same reasoning applies. I took from it the habit of checking the roof space first when a room feels too hot, before blaming the exchanger.

The third is [[Vorful radio receiver handbook]]. This one is a little off topic. I mention it because the handbook has a good section on keeping a clear log of readings and settings, and I copied that habit. The way I record observations below, with the same fields every time, comes from that handbook. It has nothing to do with heat itself, but the logging method works well.

### How I use these sources

I do not treat any of them as proof. They are prompts for what to check. My working rules are:

- compare with the Vanstol study before deciding a behavior is a fault
- check the roof and ventilation, using the loft handbook, before blaming the unit
- log readings in a fixed format, following the radio handbook
- write down guesses as guesses

### Personal records

Besides the linked notes, I rely on my own installation memory from 2022 and on the loose scraps I kept afterward. These include a few sketches of where the unit sits in the shed, a list of what I changed in the first year, and a pile of short comments on weather and how the unit felt. They are not tidy, which is one reason for this study: I want one organized place for what is now scattered.

### What is missing

I have no maker's documentation that I trust, and I will not invent any. If I find proper documents later, I will add them here and mark which statements they confirm or contradict. Until then, everything about the Kesdridaer in this study rests on observation and on comparison with the notes above.

## Observations

These are my first observations of the unit. I made them over several seasons since the 2022 installation. They are practical and informal, and I note where I am unsure.

### Fixed facts

The table repeats the properties of the unit alongside the way each one shows up in daily use. It is the quickest summary I have.

| Property | Value | What it means in practice |
|---|---|---|
| Kind | heat exchanger | Moves heat from the sunlit face to the air or water in the channels |
| Area | ceramics | Fired ceramic body, slow to warm and slow to cool |
| Color | black | Absorbs sunlight well, shows dust and marks easily |
| Energy source | solar | No fuel or mains supply needed, output follows the sun |
| Year installed | 2022 | Several seasons of use so far |
| Location | shed | Exposed to damp, dust and large temperature swings |

### Daily behavior

On a clear morning the black face warms first. The outlet lags behind, and I notice the delay most in cooler months, when it can take a good part of the morning before the outlet is properly warm. On a bright afternoon the unit does its best work. In the evening the ceramic keeps releasing heat, and the shed stays comfortable longer than it did before 2022.

On overcast days the unit still works, but weakly. Because the energy source is solar, there is no backup, and I accept that. For those days I rely on the shed's own insulation and on closing it up early.

### The effect of the black finish

The black color is a clear advantage for heat gain. It is also a nuisance. Dust, pollen and cobweb show up at once, and a thin film on the face visibly reduces how warm the unit gets. I now wipe the face with a dry cloth whenever I am in the shed for other reasons. A damp cloth leaves streaks that dull the surface, so I avoid it unless the dirt is stubborn.

### The effect of the location

The shed is a mixed environment. It is damp in winter, and the damp does not seem to hurt the ceramic, which was my hope. It is hot in summer, and the unit adds to that heat at peak sun. This is the main drawback I have found. In midsummer the exchanger can make the shed warmer than I want, so I have learned to shade the face a little or open the vents. The loft handbook was helpful here, since the same ventilation logic applies.

### Comparison with the other unit

Next to the unit in the Vanstol study, the Kesdridaer is slower to respond but steadier. It never swings sharply. I put this down to the ceramic body, though I cannot prove it. The Vanstol unit reacts quickly to sun and cools quickly too. For a shed where I want a stable temperature and not a fast one, I prefer the Kesdridaer's behavior.

### Open questions

- How much does the dust film really reduce output? I have only a rough feel for it.
- Is the glaze on the black face wearing, or is the dullness just dirt?
- Would shading in summer do more good than extra venting?
- Does the ceramic suffer from the shed's winter damp over many years?

I will come back to these in later parts of the study, once I have kept more careful logs in the fixed format I borrowed from the radio handbook. For now the summary is simple: a black ceramic solar heat exchanger, installed in 2022 in the shed, slow, steady, quiet and dust-prone, and more useful in winter than in summer.

## Problems

The Kesdridaer heat exchanger is a black ceramic unit that has sat in the shed since 2022, running on solar energy. It has worked well enough to keep, but it has not been trouble free. These are the problems I have run into, written down in the order I noticed them, so that I can check them against each other later.

### Uneven heating across the day

The first thing I noticed was that the output depends heavily on the sun. Because the energy source is solar, the exchanger does very little on grey mornings and then catches up in the early afternoon. That is expected, but it has a side effect I did not plan for. The ceramic body takes a long time to warm up, and it also takes a long time to cool down. On a day with passing cloud, the unit swings between warm and lukewarm several times, and the stored heat in the ceramic smooths only part of that.

The shed makes this worse. It has one small window and a roof that shades the unit's south side for part of the afternoon in winter. I did not measure the shading carefully in the first year, so I do not have good data from 2022. What I have is a set of rough notes from later seasons.

### Thermal stress on the ceramic

Ceramics do not like sudden changes in temperature. The black surface soaks up sun quickly, and on cold clear mornings the sunny side warms much faster than the shaded side. I have seen fine surface marks appear near the edges. So far they are cosmetic, but I treat them as an early warning. If a crack ever runs through a wall, the exchanger would leak and I would have to shut it down.

I have also noticed that the problem is worse after a long cold spell. The unit seems to hold a bit of moisture in the ceramic, and this freezes in the shed overnight.

### Dust and film on the surface

The shed is not a clean place. Dust from stored materials settles on the black surface and forms a thin film. A dusty surface absorbs less sunlight, and I could see the difference in how warm the unit felt by midday. Cleaning it brings the performance back, but it is one more chore.

### Fouling inside

The inner passages gather a light scale over time. This is the slowest problem and the hardest to see. I only noticed it because the flow slowed down and the outlet felt cooler than it used to. Flushing the passages helped, but I cannot see inside, so I do not know how much scale is left.

### Summary of the problems

| Problem | Where it shows up | How serious | Current status |
|---|---|---|---|
| Uneven heating | Output across the day | Medium | Accepted, partly managed |
| Thermal stress | Edges of the ceramic | High if cracks grow | Watching |
| Dust film | Black outer surface | Low | Cleaned regularly |
| Inner scale | Flow passages | Medium | Flushed, not fully solved |

## Lessons

After several seasons with the device I have a fairly clear idea of what matters and what does not. Most of the lessons are about patience and maintenance rather than about clever changes.

### What I would do the same way

- Keep the unit in the shed. The shelter from rain and wind protects the ceramic far better than an open yard would, even with the shading.
- Choose black. The dark surface does what it is supposed to do and picks up sun even in weak light.
- Use solar as the only energy source. It keeps the system simple, and there is nothing to refuel or wire in.

### What I would change

- Plan the position around the winter sun. I placed the unit where it looked best in summer. Winter is when the shading shows up, and by then moving it is a big job.
- Add a way to warm the ceramic gently. A slow start in the morning would reduce the stress on the edges. A shade cloth in the early hours would be a cheap first test.
- Set up a cleaning routine from the start. I waited until the dust film was obvious. A fixed schedule is easier than judging by eye.
- Keep a simple log. Even a short line each week about weather, output and any marks on the ceramic would have given me proper data from 2022 onward.

### Practical rules I now follow

1. Never splash cold water on a warm ceramic surface.
2. Wipe the surface before the sun gets strong, not after.
3. Flush the inner passages at the start of each cold season, before frost arrives.
4. Look at the edges every month and note any new marks.
5. Do not move the unit while it is warm or full.

### What I still do not know

I do not know whether the surface marks will stay cosmetic. I also do not know how much the inner scale reduces the output compared with the first year. Both questions need a better record than I have kept so far. My plan is to keep the weekly log going for a full year and then compare it with the cleaning dates.

One more lesson is about expectations. A solar ceramic heat exchanger is slow, steady and quiet. It is not a device that reacts quickly. Once I stopped expecting fast response and treated it as a slow store of heat, most of my frustration went away.

## Costs

I did not keep every receipt, so I describe the costs by type rather than by exact amounts. I am deliberately not putting invented figures here. What matters for my own use is knowing where the money and effort went.

### Money

The largest cost was the purchase and installation of the unit in 2022. After that, the running cost is close to nothing, because the energy source is solar. There is no fuel, and no electricity is used for the heating itself.

The ongoing spending is small:

- Cleaning supplies for the black surface: soft cloths and mild cleaner.
- Materials for flushing the inner passages.
- Occasional small items for the shed, such as a cover and shade cloth.

### Time

Time is the bigger running cost. A rough picture of the regular work looks like this:

| Task | How often | Effort |
|---|---|---|
| Wipe the outer surface | Every few weeks | Small |
| Check the edges for marks | Monthly | Very small |
| Flush the inner passages | Once per cold season | Medium |
| Update the log | Weekly | Very small |

### Possible future costs

- **Repair of the ceramic.** If a surface mark turns into a crack, I would need a repair or a replacement section. This is the cost I worry about most.
- **Moving the unit.** Relocating it within the shed to get better winter sun would take a day or more of work and some help.
- **Descaling the inner passages.** If flushing stops being enough, a stronger treatment may be needed.
- **Shading fix.** Changing the roof or window of the shed is the most expensive option and I would try the cheaper steps first.

### Overall view

Looking at the whole picture, the device is cheap to run and moderately demanding to look after. The main risk is not the daily cost but one expensive failure of the ceramic. For that reason I think the best use of money is small and early: a shade cloth, a cleaning routine and a good log. These cost little compared with a damaged exchanger, and they address the problems listed at the start of this part directly.

## Overview

This part of the study describes the Kesdridaer heat exchanger as a physical object and as something I live with. It is a heat exchanger, and it sits in the shed at the back of the plot. Its body is black. It runs on solar energy, and I installed it in 2022. The work I do with it falls in the area of ceramics, which is the reason it exists at all. I wanted a way to move heat around the shed without burning anything, and I wanted that heat to be useful for drying clay and warming the kiln room in cool weather.

The table below holds the properties I keep coming back to. I copy them here so I do not have to search through older notes when I need a quick check.

| Property | Value |
| --- | --- |
| Kind | heat exchanger |
| Area | ceramics |
| Color | black |
| Energy source | solar |
| Year installed | 2022 |
| Location | shed |

The black color is not decoration. A dark surface takes in sunlight and gives it up to the air or the fluid passing through, so the color is part of how the device works. When the sun is on the shed wall, the casing becomes warm enough that I can feel it from half a meter away. When the sun goes, it cools slowly, and the slow cooling is one of the things I like about it.

The solar energy source means the device has no fuel line and no mains connection that matters for heat. It collects what the day gives and passes it along. On a bright day the shed is noticeably warmer near the exchanger, and drying shelves placed close to it dry greenware more evenly than shelves by the door. On a dull day the effect is small. I have learned to plan glazing and drying work around the weather, not the other way round.

What I want from this study is a plain record. I want to know what the device does well, where it falls short, and what I need to keep it working. I am not trying to prove it is a perfect solution. I am trying to keep honest notes so that in a few years I can read them and know what I was thinking.

A few working observations so far:

- The unit performs best when the shed door faces the sun for most of the afternoon.
- Damp clay dries faster and with fewer cracks when kept in the warm band near the exchanger.
- The black casing collects dust and clay powder quickly, and a dusty surface absorbs less light.
- The device is quiet. I only notice it by the warmth, never by sound.
- It does not replace the kiln. It only helps with the slow, gentle work around it.

I treat the shed as a small system. Air comes in low, warms near the exchanger, rises, and leaves through the upper gap under the roof. That loop is simple, and it works only if I keep the lower and upper openings clear. Several times I stacked boxes in front of the intake and wondered why the shed felt flat. The fix was always to move the boxes.

## History

I installed the Kesdridaer heat exchanger in 2022. Before that, the shed was cold and damp for much of the year, and my ceramics work suffered for it. Pieces dried unevenly, some warped, and the glaze shelves picked up moisture. I had tried a small portable heater, but it cost too much to run and dried the air too harshly. Clay that dries too fast on the outside cracks, and I lost several good pieces that way.

The idea of using solar heat came from watching how the shed behaved on its own. On a clear day the south wall got warm, and the inside of the shed held a little of that warmth for a while. I thought that if I could collect that heat on purpose and spread it, I could make the drying slower and kinder. That thinking led me to a heat exchanger instead of a heater. An exchanger moves heat from one place to another, and I already had a source of heat that cost nothing.

The first season after installation was a learning period. I made mistakes with placement. I put the unit too far from the drying shelves at first, and the warmth faded before it reached the clay. I moved it closer to the work area and the difference was clear within days. I also found that a black casing in direct sun can get hotter than I expected, so I added a simple guard to keep sleeves and cloths away from it.

In the second year I started keeping proper notes. I recorded how the shed felt in the morning, how the clay behaved, and whether I had to bring pieces indoors to finish drying. Those notes are scattered across older entries, and part of the reason for this study is to gather them in one place.

Over the following seasons the routine settled into something steady. In spring and autumn the exchanger does most of its useful work, because the sun is low enough to reach the wall and the air is cool enough that the extra warmth matters. In deep winter it helps less, since there is simply little sun. In midsummer the shed is warm enough already, and I sometimes shade the unit so the room does not overheat.

A short outline of the stages as I remember them:

- 2022: installed in the shed, first placement too far from the shelves.
- The season after: moved closer, added a guard, noted the first clear gains in drying.
- Later seasons: regular notes, a cleaning habit, and a plan for each time of year.
- Recent period: stable use, with small changes made only when something looks wrong.

I should also record what I did not do. I did not wire it to any other energy source, and I did not add a pump or fan beyond what the design needed. I wanted the device to stay true to its solar nature. If it fails on a gray day, I accept that and plan around it. That choice keeps the system easy to understand, and easy things are easier to repair.

One more point about history: the device has changed less than I have. The unit itself looks nearly the same as when I installed it, apart from dust and a few marks on the casing. What changed was my understanding of where to put pieces, when to open the shed, and how much to expect from a sunny day. Most of the improvement came from habits, not hardware.

## Tools

Keeping the Kesdridaer heat exchanger in good shape does not need much. I keep a small set of tools in the shed and use them on a regular rhythm. None of them are special, and most were already in the shed for ceramics work. The point is to have them within reach so that cleaning and checking do not become a chore I put off.

The tools I rely on:

- A soft brush, for sweeping dust and clay powder off the black casing without scratching it.
- A damp cloth, for wiping the surface after brushing, since a clean dark surface absorbs sunlight better.
- A basic hand thermometer, for checking the warmth near the exchanger and at the far end of the shed.
- A notebook, kept on the shelf by the door, for writing what I see on each visit.
- A spanner and a screwdriver, for tightening fittings and the guard if they loosen.
- A torch, for looking at the lower intake and the upper gap, which are dark corners.
- Gloves, because the casing can get hot in strong sun.

I use the brush and cloth most. Clay dust is fine and settles everywhere, and the black surface shows it clearly. A light brushing every week or two is usually enough. If I have been trimming or sanding a lot, I clean it more often. I never use harsh cleaners, because I do not know how they would affect the finish, and plain water has always been enough.

The thermometer tells me whether the device is doing anything. I check a spot near the exchanger and a spot by the drying shelves, and I compare them with the air near the door. If the warm spot is not clearly warmer than the door, I look for blocked openings or a dirty casing before I assume anything is wrong with the unit. Most of the time the cause is something simple, like a box in the way.

The notebook matters more than it sounds. Writing down the weather, the feel of the shed, and the state of the clay gives me a trail to follow later. It is how I noticed that the unit works best in spring and autumn, and how I caught the slow buildup of dust before it hurt performance.

I keep a simple routine for checks:

- Look at the lower intake and upper gap, and clear anything blocking them.
- Brush and wipe the casing.
- Check the guard and the fittings for looseness.
- Read the thermometer near the exchanger and by the door, and note the difference.
- Write a line in the notebook.

I do not use any electronic monitoring. It would add parts that can break, and it would pull the setup away from the quiet, solar approach I chose. The thermometer and my own hands are enough for what I need.

If I ever have to replace a part, I will note down its details at that time and keep them here. For now, the device has needed care, not repair. The tools above cover everything I have done in the shed, and I think that is a good sign for a device meant to stay simple.

## Safety

The Kesdridaer heat exchanger is a heat exchanger used in my ceramics work. It is black, runs on solar energy, and has stood in the shed since I installed it in 2022. Most of the safety notes below come from the fact that it is black and sits in a small wooden building in full sun. Black surfaces soak up heat, and the shed adds to it.

### Heat

The casing gets hot enough to burn skin on a clear afternoon, even when nothing is being fired or dried. I treat every black surface on the unit as hot until I have checked it with the back of my hand held close, not touching. I never use my palm or fingertips for the first check.

Because the energy source is solar, the unit does not switch off when I walk away. Covering it or turning a panel away is the only way to slow it down. This is easy to forget. I used to think of it as "off" when I had not touched anything that morning, and that was wrong. If the sun is out, it is working.

Rules I follow for heat:

- Wear leather gloves before touching the casing, pipes or any joint.
- Keep a bucket of cool water outside the shed door for burns and for cooling tools.
- Never lean tools or shelving against the black casing, because they pick up heat and can warp or ignite.
- Keep the area around the unit clear so I can leave quickly in any direction.
- Cover the unit with the pale reflective sheet when I am not working with it.

### Ceramics dust and fumes

The area of use is ceramics, so there is fine dust in the shed all the time. Dry clay and glaze powders are the main hazard. Breathing silica dust over years does lasting damage, and the shed has poor air movement. I wipe surfaces with a damp cloth instead of sweeping, and I wear a fitted dust mask whenever I handle dry material near the unit. A hot exchanger also dries damp dust faster and lifts it into the air, so cleaning needs to happen before the sun has warmed things up, not after.

Some glazes release fumes when heated, including those with metal oxides. I keep these well away from the exchanger inlet. If a smell of burning or chemicals shows up, I open the door and the high vent, step outside, and wait until the air clears before going back in.

### The shed itself

The location is a shed, which means a few extra concerns:

- The wooden walls and roof are flammable, so I keep a gap between the unit and the wall.
- The floor can be damp in wet weather, so I check for standing water before touching any metal part.
- Lighting is poor in the evening. I do not adjust the unit in low light, because I cannot see hot spots or leaks.
- Only one door opens easily, so I never block it.

### Leaks and fluid

If fluid leaks from the joints, I stop and cover the unit rather than trying to fix it while it is hot. The fluid can be hotter than the casing. I wait until the unit has cooled fully, which usually means the next morning, then tighten or replace the fitting. I do not tighten anything while the sun is on it.

### First aid

A first aid kit hangs on the inside of the shed door. It holds burn gel, clean dressings, an eye wash bottle and a small card with the emergency number for my area. I check it at the start of every season. For a burn, I run cool water over it for a good while before doing anything else.

## Supplies

I keep the supplies for the Kesdridaer heat exchanger in one plastic crate and one shelf inside the shed. Keeping them together means I do not hunt around while the unit is hot. Everything is chosen to survive heat, dust and the occasional splash of water.

### Core items

The table lists what I keep and why. The first column is the item, the second is what it is for, and the third is where it lives.

| Item | Purpose | Where kept |
|---|---|---|
| Leather gloves | Handling the hot black casing | Hook by the door |
| Dust mask | Protection from clay and glaze powder | Crate, top layer |
| Pale reflective sheet | Covering the unit to stop solar heating | Folded on the shelf |
| Soft brush | Clearing dust from vents and fins | Crate |
| Damp cloths | Wiping surfaces without raising dust | Bucket under the shelf |
| Spare seals | Replacing worn joints | Small tin in the crate |
| Basic spanner set | Tightening fittings once cool | Toolbox |
| Notebook and pencil | Logging weather and observations | Shelf, in a zip bag |
| Bucket of water | Cooling tools and treating burns | Outside the door |

### Why these choices

The gloves are leather and not cloth because cloth ones wore through quickly at the hot joints. The reflective sheet is pale because a dark cover would defeat the purpose. I tried an old tarp at first, and it only made things hotter underneath. A pale sheet reflects most of the sunlight and the casing stays much cooler.

The brush has soft bristles because ceramic dust is abrasive, and a stiff brush scratches the finish on the black casing. The scratched patches then heat unevenly. I learned this in the first season after the 2022 installation, when I used a wire brush and regretted it.

I keep the spare seals in a closed tin to stop dust getting into them. A seal with grit on it never sits flat, and it will leak again within days.

### Things I do not keep in the shed

Some supplies stay in the house because the shed is too hot or too damp for them:

- Batteries and any electronics, which suffer in the heat.
- Paper records and manuals, which curl and fade.
- Solvents and anything flammable, because I do not want them near a hot black surface.
- Food and drink, which attract insects and are a poor idea around glaze materials.

### Restocking

I look through the crate at the start of each season and replace anything worn. Gloves and masks go first. The seals and cloths come next. I write the replacements in the notebook so I can see how long each item really lasts. Over time this has told me that gloves last about a season of regular use, masks need changing far more often than I once thought, and seals are fine for years if kept clean.

## Setup

The unit is a black heat exchanger for ceramics work, powered by solar energy. It was installed in 2022 and stands in the shed. This section describes how I set it up for a working session and how the layout of the shed was arranged around it.

### Summary of the subject

For quick reference, these are the properties I rely on when planning a session:

- Kind: heat exchanger
- Area: ceramics
- Color: black
- Energy source: solar
- Year installed: 2022
- Location: shed

Each of these affects the setup. The solar energy source decides when I can work. The black color decides how I protect myself and the shed. The shed location decides how much room I have, and the ceramics area decides what has to be kept clean.

### Position in the shed

The unit stands against the wall that gets the most sun, near the window, with a gap behind it so air can move and the wooden wall does not scorch. I chose this spot because the solar source needs light for as long as possible during the day. The drawback is that the shed gets very warm, so I fitted a high vent above the door and I leave the door propped open when the unit is working.

The ceramics bench is on the opposite side of the shed, as far from the exchanger as possible. This keeps clay dust away from the vents. The path between the bench and the door runs past the unit but not close to it, so I do not brush against hot metal while carrying work.

### Before a session

I follow the same order each time:

1. Open the door and the high vent, and let the air settle.
2. Check the floor for damp and the area around the unit for clutter.
3. Put on gloves and the dust mask.
4. Remove the reflective sheet and fold it away from the unit.
5. Look over the joints for leaks or dust buildup, and clear the vents with the soft brush.
6. Check the fluid level and that the connections look tight.
7. Note the weather in the notebook.

I do the check before the sun has been on the unit for long. Once it has heated up, I cannot touch it safely, and any small fault has to wait.

### During a session

While the unit is working I stay aware of the casing. I do not rest anything on it. I move ceramic pieces only when the bench side of the shed is clear, and I keep the damp cloth nearby to wipe dust before it builds up. If clouds roll in, the output drops and I use the time for cleaning or notes, since waiting for the sun is part of working with a solar device.

If the day is very bright, I sometimes cover half the unit with the pale sheet to hold the heat steady. I write down when I do this, because it changes how the results should be read in the study.

### After a session

When I finish, I put the reflective sheet back over the unit at once, even if it still feels warm. I then wipe down the nearby surfaces with the damp cloth, brush the vents again, and put gloves and mask back in their places. The last step is to close the high vent and shut the door, and then I write a short entry in the notebook covering the weather, what I did, and anything that looked wrong.

### Seasonal adjustments

In summer the unit is too hot for long afternoon use, so I work in the morning and cover it by midday. In winter the sun is low, so I tilt my working plan toward the middle of the day and keep the door shut more of the time to hold some warmth. In the wet months I check the floor and the seals more often, because damp gets into everything in the shed.

### Open questions for the study

A few setup questions remain, and I plan to test them over the coming seasons:

- Whether moving the unit a little further from the wall changes how well it holds heat.
- Whether a second vent would keep the shed cooler without letting in more dust.
- Whether a lighter cover over the casing could reduce how much I need to rely on the reflective sheet.

I will record the answers in later parts of this study as I go.

## Risks

The Kesdridaer heat exchanger is a black ceramic unit, installed in 2022 in the shed and driven by solar energy. Most of the risks come from that combination: a brittle material, a building that is not climate controlled, and a heat source that changes with the weather.

**Thermal shock.** Ceramics tolerate steady heat well but dislike sudden change. On a clear morning the sun can heat the black surface quickly, and a cold night leaves it much colder than the air in the shed. If cold fluid is pushed through the unit while the surface is hot, or the reverse, the material may crack. A hairline crack might not show for a long time. It would first appear as a slow loss of performance.

**Mechanical damage.** The shed is a working space. Tools, ladders, boxes and bicycles move around in it. The ceramic body is hard but not tough, so a knock from a dropped tool could chip an edge or crack a joint. A dark unit in a dim corner is also easy to bump into without seeing it.

**Overheating.** Solar input does not follow the demand. On a hot, still afternoon with little flow through the exchanger, the temperature can climb higher than I want. The black color helps absorb heat, which is good for gathering energy and bad when there is nowhere for the energy to go.

**Freezing.** If the working fluid contains water and the shed drops below freezing, ice could form inside the channels. Ice expansion is a classic way to break ceramic parts. The shed gets cold in winter and offers little protection.

**Moisture and dirt.** Dust, cobwebs and damp air collect in a shed. Dust on the surface reduces solar gain. Damp near the connections can lead to corrosion of metal fittings, even though the ceramic itself does not rust.

**Leaks at the joints.** Ceramic and metal expand at different rates. Over many heating cycles, seals and fittings at the transitions can loosen. A slow leak is likely to go unnoticed in a shed that I do not visit every day.

### Risk summary

The table below is my own rough rating, based on what I know about the material and the location, not on measured failure data.

| Risk | Likelihood | Impact | Main trigger |
|---|---|---|---|
| Thermal shock | Medium | High | Sudden change of fluid or surface temperature |
| Mechanical damage | Medium | High | Tools or boxes in the shed |
| Overheating | Medium | Medium | Strong sun with low flow |
| Freezing | Low to medium | High | Winter nights with water in the channels |
| Moisture and dirt | High | Low | Damp, dust, cobwebs |
| Joint leaks | Medium | Medium | Repeated heating and cooling |

The rating that worries me most is the pair of medium likelihood and high impact: thermal shock and knocks. Both can ruin the unit in a single event, while dirt only costs a little efficiency and can be fixed with a cloth.

### What reduces the risks

- Keep a clear zone around the unit and mark it so nobody stacks things against it.
- Start flow gently in the morning and avoid sending cold fluid into a hot body.
- Drain or protect the unit before the first hard frost.
- Make sure there is always a path for heat to leave when the sun is strong.
- Check the joints after any big temperature swing.

## Open questions

I have not settled several points about this device. I am listing them so I do not forget them, and so that I can later check each one against what I observe.

1. **What is the real safe temperature range?** I know the unit is ceramic and black, but I do not have a trustworthy figure for the highest surface temperature it should see, or for how fast it can change. I need to find that from the maker's documents or by careful testing, and I should not guess.

2. **How much of the energy is actually used?** The solar source gives plenty of heat on good days, but I do not know what fraction ends up in the fluid. The rest is lost to the air in the shed. A simple comparison between inlet and outlet temperatures on a sunny day would give a first answer.

3. **Does the shed location help or hurt?** The shed protects the unit from rain and wind, which is good. But it also shades part of the day and traps heat in summer. I have not compared this with how the unit would behave outdoors. It could be that a different spot in the shed gets better sun.

4. **How has the performance changed since 2022?** I have been using it since it was installed, but I did not record early performance in a consistent way. Without a baseline, I cannot say whether it is getting worse. Starting a record now is the best I can do.

5. **Are there hidden cracks?** A ceramic part can be damaged without any visible sign. I do not know a cheap way to check for this. Tapping and listening for a dull sound is one idea, but I am not sure it is reliable.

6. **What happens in a long cloudy spell?** The solar source drops off, and I have not written down what the backup plan is. I need to decide whether the system simply stops, or whether something else should take over.

7. **Is the black surface coating stable?** The color is black, and I do not know whether it comes from the ceramic body itself or from a coating. If it is a coating, it may fade or flake over time and change how much heat the unit absorbs.

### Things I could test

- Record inlet and outlet temperatures at the same hour on several sunny days.
- Take photos of the surface every season to catch changes in color or cracks.
- Note how the shed temperature varies through a full day in summer and in winter.
- Try placing a simple shield or reflector and see whether output changes.

None of these needs special equipment. A basic thermometer, a notebook and a camera are enough to make progress on most of the questions.

## Maintenance

Maintenance on the Kesdridaer heat exchanger is mostly a matter of regular looking, gentle cleaning and avoiding stress. The device is a ceramic heat exchanger in the shed, installed in 2022, and it uses solar energy, so the routine follows the seasons and the sun.

### Routine

- **Monthly:** Look at the unit with a torch. Check for chips, cracks, drips or damp patches. Make sure nothing is leaning on it.
- **Every season:** Wipe the surface with a soft, damp cloth to remove dust. Do not use hard brushes or strong chemicals, because they might scratch the black surface and change how it absorbs heat. Dry it afterwards.
- **Before winter:** Drain the unit, or confirm that the fluid cannot freeze. Check that the shed does not have gaps that let in hard cold air or water.
- **After winter:** Look closely at joints and fittings for leaks, and run the system gently at first.
- **Once a year:** Inspect all metal fittings and seals. Replace anything that looks hard, cracked or corroded. Clean the area around the unit, including cobwebs and dirt.

### Seasonal view

| Season | Main job | Watch for |
|---|---|---|
| Spring | Leak check, gentle restart | Damage from frost |
| Summer | Keep flow going, wipe off dust | Overheating, dust on surface |
| Autumn | Clean, inspect fittings | Damp, falling leaves, debris |
| Winter | Drain or protect, minimal use | Freezing, ice in channels |

### Good habits

Handle the ceramic with care. Never lift it by a pipe or fitting, and never put tools down on top of it. When I must work near it, I cover it with a folded blanket so a slipped spanner does not hit it.

When starting the system after a cold night, I let the flow begin slowly. I do not pour hot fluid into a cold body or the reverse. Taking a few minutes here costs nothing and removes the biggest single threat to a ceramic part.

### Keeping records

I keep a short log in my notebook. For each check I write the date, what I saw, and what I did. I also note the inlet and outlet temperatures when the sun is strong. Over time, this log should answer the open question about performance changes and give me a baseline.

### When to stop and call for help

If I see a crack, a steady leak or a sharp drop in output, I stop the flow and isolate the unit. I do not try to patch a ceramic crack with glue, because it will probably fail under heat. In that case the options are a replacement part or a replacement unit, and I should work out which before spending money.

### Small improvements to consider

- A simple cover or guard around the unit to prevent knocks.
- A small label with the drain steps, so I do not forget them in autumn.
- A thermometer fixed near the unit to make the temperature records easier.

With these habits, the unit should keep working for many more years, and any problem should be found while it is still small.

## Ideas

These are the ideas I want to try or at least think through for the Kesdridaer heat exchanger. It is a black ceramic heat exchanger that runs on solar energy. I installed it in 2022 and it sits in the shed. Most of what follows comes from watching how it behaves over several seasons, so treat it as working notes, not a finished design.

### Why the shed location matters

The shed is a mixed blessing. It keeps rain and wind off the unit, which is good for the ceramic surfaces and for any fittings. But the shed also limits how much light and radiant heat the black body can pick up. The unit works best when the roof or wall nearby is warm and the air around it is not stuck. My first idea is to treat the shed itself as part of the system, not as a neutral box.

Ideas about the shed:

- Add a light-colored reflective board on the side opposite the window, so more light lands on the black surface.
- Leave a gap at the top of the shed wall so warm air does not pool around the unit and then slow down heat transfer.
- Keep the shelf area below the unit empty. Clutter blocks airflow and shades the lower part of the body.
- Check the window glass every spring. A dusty pane cuts the useful light more than I expected.

### Using the black color on purpose

The black color is not decoration. A dark ceramic body absorbs more of the incoming light than a pale one, and it also gives that heat back to the fluid more evenly because ceramic holds temperature well. The downside is that it also loses heat quickly once the sun goes away. So one idea is to pair the black body with a way to slow the evening cooling.

Options I have thought about:

- A loose wrap of old blanket or foam sheet that I can pull over the unit at dusk and remove in the morning.
- A small insulated box around the lower half only, leaving the upper half open to the light.
- Moving the heaviest use of warm output to the early afternoon, when the unit is at its best, instead of fighting the evening drop.

I like the first option because it costs nothing and is easy to undo. The second needs measuring and some building work, so it goes lower on the list.

### Ceramics and thermal stress

Since the area is ceramics, the main risk is cracking from fast temperature swings. A sudden cold draft on a hot body is the worst case. Ideas to reduce that risk:

1. Never open the shed door wide in winter while the unit is hot and in full sun.
2. Do not pour or flush cold fluid through a hot unit. Let the temperature come down first, or run the fluid slowly.
3. Look at the surface once a month with a torch held at a low angle. Hairline cracks show up as faint lines in the beam.
4. Keep a record of any mark I find, with a rough position on the body, so I can tell later whether it is growing.

I have not found any damage since 2022, but I want the checking habit anyway. Ceramic tends to fail quietly and then all at once.

### Solar side improvements

The energy source is solar, so anything that improves the daily light helps more than any change to the exchanger itself. A few thoughts:

- Trim the tree branch that shades the shed in late afternoon.
- Clean the shed window and the reflective board on the same day, so I do not forget one.
- Note which weeks of the year the unit gets the least sun, and plan heavier jobs outside those weeks.
- Consider a second light source on cloudy stretches only if the cost is small. I am not convinced it is worth it.

### Questions I still want answered

These are open points, not decisions.

- How much of the output loss in winter comes from low light, and how much from heat leaking out of the shed?
- Would a thin dark coating on the pipes feeding the unit change anything, or is the ceramic body doing nearly all the work?
- Does the reflective board help enough to justify the space it takes?
- Is the evening cooling fast enough that a wrap pays for itself in a normal week?

My plan is to try the cheap ideas first: the reflective board, the evening wrap and the monthly crack check. Then I will write down what changed and decide whether the bigger ideas are worth the effort. I want to change one thing at a time, otherwise I will not know what helped.

## Parts

This section lists the parts I keep track of for the Kesdridaer heat exchanger, and the main facts about the device so that I can find them in one place.

The part number of the Kesdridaer heat exchanger is LM-7229-W. I should quote this exactly if I ever need to order a replacement or ask someone about compatibility. I have written it on a label inside the shed door as well, in case this note is not at hand.

### Summary of the device

| Property | Value |
| --- | --- |
| Kind | heat exchanger |
| Area | ceramics |
| Color | black |
| Energy source | solar |
| Year installed | 2022 |
| Location | shed |
| Part number | LM-7229-W |

### Parts I watch

The device is mostly one solid ceramic body, so the list of separate parts is short. What I actually watch is the following:

- **Ceramic body.** The black main block. It is the part that matters most and the hardest to replace. I check it for cracks and for dirt that blocks heat transfer.
- **Fluid connections.** The points where pipes meet the body. These are the most likely place for a slow leak, so I look for damp marks or mineral crust.
- **Seals and gaskets.** Soft parts that wear out first. They harden with heat and age, and I expect to replace them before anything else.
- **Mounting supports.** The brackets or rests that hold the unit in the shed. I check that they are firm and that they do not press hard on one spot of the ceramic.
- **Light-facing surface.** Not a separate part, but the side that gets the sun. I wipe it gently with a soft cloth, never with anything abrasive.

### Care notes for each part

For the ceramic body I use only a damp soft cloth. Harsh cleaners can leave a film that changes how the surface absorbs light, and the black color is what makes the solar side work well.

For the fluid connections I tighten by hand and only a little. Ceramic does not like point pressure, and over-tightening is an easy way to cause damage that I would not notice until later.

For the seals I keep a note of when I last looked at them. Since the unit has been in the shed since 2022, they have been through several hot summers and cold winters. If a seal looks flattened, dry or cracked, it is time to change it.

For the supports I make sure there is some soft padding where the ceramic rests, and I check that it has not shifted or rotted.

### Spare and replacement thinking

Because the ceramic body is the costly piece, I would rather keep small wear parts on hand than think about a whole new unit. My approach:

1. Keep a spare set of seals in a labeled bag in the shed.
2. Keep the part number, LM-7229-W, in this note and on the shed door label.
3. Photograph the connections and supports now, while everything is working, so I can rebuild them correctly later.
4. Write down the date of any repair in the log, along with what I changed.

### What to check before ordering anything

Before I order a part, I go through a short list:

- Is the problem really the part, or is it dirt, shade or a draft in the shed?
- Does the part number match LM-7229-W?
- Is the damage on the ceramic body itself, or only on a seal or a support?
- Can a cheap fix, such as new padding or a cleaned connection, solve it first?

I add to this list as I learn more. For now it keeps me from replacing things that were never broken.
