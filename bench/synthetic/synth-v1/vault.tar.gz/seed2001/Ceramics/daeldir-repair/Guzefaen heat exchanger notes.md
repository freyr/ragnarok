---
type: note
status: active
project: daeldir-repair
area: ceramics
description: "Note about Guzefaen heat exchanger."
---

# Guzefaen heat exchanger notes

## Problems

The Guzefaen heat exchanger is a black ceramics heat exchanger that has been in the shed since 2015. It runs on a battery, and most of my trouble with it comes from that. The battery is the weak point of the whole setup, and the shed makes it worse.

The first problem is cold. In winter the shed gets very cold, and the battery loses charge much faster than it does in autumn. On some mornings the unit does not start at all until I bring the battery inside and warm it for a few hours. I have written this down several times and it is always the same pattern.

The second problem is dust. The shed is not sealed, and a fine layer of grit settles on the black ceramic surface. Because the colour is black, the dust shows up clearly, which helps me notice it, but it also means I clean more often than I would like. If I leave it, the surface seems to hold heat unevenly.

The third problem is damp. After a long wet spell, the lower edge of the casing stays cold and slightly moist. I have not found a leak. I think it is condensation, but I want to keep watching it before I decide.

The fourth problem is small cracks in the glaze near the fittings. They are hairline marks and they have not grown, but ceramics can fail suddenly, so I treat them as something to monitor and not ignore.

## Observations

Here is what I have noticed over the years of using this device.

- The ceramic body holds warmth for a long time after the unit stops. In the evening it is still faintly warm to the touch well after shutdown.
- Performance is steadiest in mild weather. When the shed is cold, the output is lower and less even.
- The battery is the first thing to show age. The ceramic part has hardly changed since 2015.
- Dust on the surface reduces how evenly the heat spreads. After a wipe down, the difference is easy to feel.
- Condensation appears mostly after several damp days in a row, not after a single wet night.
- The hairline cracks near the fittings look the same each time I check. I photograph them now so I can compare.

The earlier tests I did with other equipment helped me understand how the unit behaves, and I kept those results in [[Sasvaeth workshop tests]]. For a wider comparison with similar devices, [[Vanstol heat exchanger study]] is the closest thing I have to a reference on how ceramic exchangers age.

I also want to remember that the shed temperature matters more than I first thought. A few degrees either way changes how the battery behaves. The note [[Zukriond loft notes]] has a similar story about a different space, and the lesson there was the same: the room matters as much as the device.

## Checklist

Routine checks I try to do, roughly in this order.

1. Look at the shed before touching the unit. Note whether it is cold, damp or dusty.
2. Check the battery charge and the battery contacts for corrosion or looseness.
3. Wipe the black ceramic surface with a dry, soft cloth.
4. Look at the lower edge of the casing for moisture.
5. Inspect the glaze near the fittings and compare with the last photograph.
6. Make sure nothing is stacked against the unit or blocking airflow around it.
7. Start the unit and listen for anything unusual.
8. Feel the surface after a while to see whether the warmth is even.
9. Write a short line in these notes about anything that changed.

Before winter I add two things: move the spare battery to a warmer place, and clear the shed of anything that traps damp air near the device.

## History

The Guzefaen heat exchanger was installed in 2015 in the shed. It was one of the first devices I set up there, and at the time I chose it because it was ceramic and looked sturdy.

In the first years there were few problems. The battery lasted well and I only cleaned the surface now and then. Over time the cold winters began to affect the battery, and I started bringing it indoors on the worst days.

Some of my earlier thinking about the unit and the shed is collected in [[Rutro Storkstal notes]], and a later round of updates went into [[Rutro Storkstal notes 2018]]. Those two notes show how my habits changed: first I did very little maintenance, then I started to keep a schedule.

More recently I noticed the damp edge and the hairline cracks, and that is why I began writing the checklist above. The plan for what to do if the cracks worsen is still unsettled. I have started a rough outline in [[Gliospaeth Stuntre plan]], but it is not finished.

## References

Notes and documents I use alongside this one.

- [[Vanstol heat exchanger study]] for general behaviour of ceramic exchangers over time.
- [[Sasvaeth workshop tests]] for my own test results.
- [[Rutro Storkstal notes]] and [[Rutro Storkstal notes 2018]] for earlier history.
- [[Zukriond loft notes]] for a comparison with another space.
- [[Zolbrel loft handbook]] for general advice on keeping equipment in unheated spaces.
- [[Vorful radio receiver handbook]] for the section on battery care, which applies here too even though it is about a different device.
- [[Gliospaeth Stuntre plan]] for the repair and replacement outline.

## Parts

The part number of the Guzefaen heat exchanger is SR-1842-W. I use it whenever I need to describe the unit to someone or look for a matching replacement.

Main parts as I understand them:

- The black ceramic body, which is the heat exchanging element itself.
- The casing and fittings around the body, where the hairline cracks appear.
- The battery and its contacts, which supply the energy.
- The mounting in the shed, which keeps the unit off the damp floor.

The battery is the part I expect to replace first. The ceramic body should last much longer if I keep an eye on the glaze. If the fittings crack further, I will need to replace them, and I would check the part number above before ordering anything.

## Safety

Ceramic can be hot after use, so I let the unit cool before cleaning it. I do not pour water on it while it is warm, because sudden temperature changes can crack the glaze.

The battery needs care too. I do not leave it connected in a damp shed for long periods, and I check for swelling, leaks or corrosion. A damaged battery should not be used again.

Because the shed is not sealed, I keep flammable things away from the unit. I do not store solvents, paper or old cloth near it.

If I see a new crack, I stop using the unit until I have looked at it carefully. Cracked ceramic can break under heat, and I do not want to find out the hard way. When working in the shed in winter, I also watch for slippery floors and poor light.

For general advice on working in unheated buildings, I go back to [[Zolbrel loft handbook]].

## Supplies

Things I keep on hand for this device.

- A soft dry cloth for wiping the ceramic surface.
- A small brush for dust near the fittings.
- A spare battery, stored somewhere warm.
- A small tool for cleaning the battery contacts.
- Silica packs or similar to reduce moisture near the unit.
- A camera or phone for photographing the cracks.
- A notebook, or this note, for logging each check.

I try to look through the supplies at the start of autumn, so I am not hunting for things in the cold. The battery care tips in [[Vorful radio receiver handbook]] remind me what to keep in the kit.
