---
type: log
status: active
project: daeldir-repair
area: ceramics
---

# Glivalsark band saw log

## Supplies

These are the things I keep within reach of the Glivalsark band saw, the green band saw in the loft. Most of it lives on a shelf by the loft ladder so I do not have to hunt for anything.

- Spare blades in a few widths, wrapped in cardboard so the teeth do not catch on anything
- A soft brush and a small hand vacuum for clay dust
- A dust mask rated for fine particles, plus safety glasses
- Ear defenders, because the loft roof amplifies the motor hum
- A push stick made from offcuts, and a second one with a notch for small pieces
- A straight steel rule and a small square for checking the table
- Light machine oil and a dry lubricant for the guide blocks
- A damp sponge and a bucket for wiping down afterwards
- A roll of masking tape for marking cut lines on dry or bisque-fired pieces
- A notebook, which is where this log started before I moved it here

The saw is an odd one for ceramics, since most people would reach for a wet saw or a wire. I use it mainly for trimming plaster moulds, cutting bats and slabs of dry material, and shaping greenware that is bone dry. I do not cut fired ware on it. That decision is explained in the Safety section.

## Setup

The Glivalsark band saw has been in the loft since 2016. It runs from the mains, through a single extension-free socket that I had fitted on the loft wall. I do not like running a motor on a long lead, so the saw sits close to that socket.

The loft is a awkward place for a heavy machine, but it has good light from the roof window and the floor is solid enough. I put the saw on a plywood pad that spreads the weight over several joists. The pad is wedged level and I check it with the square whenever I think the floor may have moved.

My setup routine for each session:

1. Unplug the saw and check the blade for cracks or a missing tooth.
2. Check the tracking by turning the upper wheel by hand and watching where the blade sits.
3. Set the upper guide just above the thickness of the piece.
4. Square the table to the blade with the small square.
5. Clear the floor around the saw and open the roof window a little.
6. Plug in, stand clear, and let the blade reach full speed before cutting.

I keep the dust extraction simple. A hose from the hand vacuum is taped near the lower wheel housing, which catches most of the dry clay dust. It does not catch everything, which is why the mask stays on.

Related reading: my notes on the other workshop machines are in [[Drirvuth air compressor notes]], which covers the compressor I sometimes use to blow dust out of the guides, and [[Krespa shed plan]], which is where I decide what could eventually move out of the loft.

## Measurements

I wanted a real number for how hungry the saw is, so I plugged it into a plug-in power meter and ran it under a few conditions. The measured power draw of Glivalsark band saw: 375.43 W. That figure was taken while cutting a slab of dry greenware at a steady feed rate, which is the typical working load.

Some other observations from the same session, kept loose because I did not log them precisely:

- Idling with the blade spinning free, the draw was clearly lower than the cutting figure.
- At start-up there is a short surge, as with any induction motor, but the meter did not hold it long enough for me to read it.
- Pushing the work too hard raised the draw and slowed the blade audibly, which is a useful cue to ease off.
- A dull blade drew visibly more power for the same cut, so the meter doubles as a sharpness check.

Other measurements I care about are physical rather than electrical. The table is square to the blade when the square sits flat against both with no light showing. The blade tension feels right when a firm finger push on the side of the blade moves it only a little. I do not have a tension gauge, so this stays a judgement by feel.

For comparison, I took similar notes on another machine in [[Fulmasvork workshop tests]]. The method there was the same: meter in the socket, steady load, write down what the meter says.

## Background

I bought the saw for general workshop work and installed it in 2016, but it found its real purpose in ceramics. Early on I used it for wood only, cutting boards for shelves and mould frames. Over time the pottery work took over, and now almost everything it cuts is dry clay, plaster, or the odd bit of foam used for making forms.

Why a band saw for clay at all? A few reasons:

- Dry greenware cuts cleanly without chipping if the blade is fine and the feed is slow.
- Plaster blocks can be roughed out to a shape before carving, saving a lot of hand work.
- Curves are easy. A wire cannot follow a tight curve, and a jigsaw tears the edge.

The downside is dust. Dry clay dust is fine and it hangs in the air, so the saw is a machine that demands care. I treat it more like a woodworking tool in a dusty trade than a studio tool.

The green paint on the saw is original, or at least it was there when I got it. It is chipped in a few places near the base. I have never repainted it, partly because the colour makes it easy to spot in a dim loft.

For the manufacturer's guidance I rely on the [[Saenber band saw handbook]], which is a general handbook for saws of this type rather than a manual for this exact one. It covers tracking, tension, and blade selection in a way that applies well enough. I also keep comparison notes on another machine in [[Drioldosra Zimior notes]], mainly for the way I wrote down maintenance intervals.

## Costs

I am not going to put figures here, since I do not keep a tidy ledger for the workshop and I would only be guessing. What I can do is list the cost categories and how they behave.

- **Purchase and installation:** a one-off cost back in 2016, including the socket fitting in the loft and the plywood pad.
- **Blades:** the main running cost. Cutting clay and plaster dulls teeth faster than wood does, so I replace blades more often than I expected.
- **Electricity:** small. At the measured draw, the saw is cheaper to run than a heater, and I only use it in short bursts.
- **Consumables:** oil, masks, vacuum bags and filters. The vacuum filters in particular go quickly with clay dust.
- **Repairs:** so far minimal. The only real repair was a replacement guide block, which was cheap.

If I had to rank them, blades come first, then masks and filters, then everything else. The saw itself paid back its cost long ago in work I would otherwise have done by hand.

One thing I would change is buying blades in bulk. I tend to order one at a time when the old one fails, which means a pause in work while I wait for delivery. A small stock of spares, as listed in Supplies, solves this.

## References

These are the notes and sources I check when something about the saw is unclear.

- [[Saenber band saw handbook]] for tracking, tension and blade choice
- [[Fulmasvork workshop tests]] for how I run and record power tests on workshop machines
- [[Drirvuth air compressor notes]] for the compressor I use to clear dust from the guides
- [[Drioldosra Zimior notes]] for the maintenance interval format I copied
- [[Krasglevur Brunniol tests]] for another set of test notes with a similar method
- [[Fithkrir radio receiver study]] for the radio I listen to in the loft, which is useful because it picks up interference when the saw motor starts
- [[Krespa shed plan]] for the long-term plan about where machines should live

The radio note may look out of place here, but it is relevant. The motor produces noise that I can hear on the receiver, and it was my first hint that the brushes or windings were doing something odd one winter. It turned out to be nothing serious.

## Safety

This is the section I reread most often. A band saw is not forgiving, and the loft makes some risks worse.

- Always unplug the saw before changing the blade or adjusting the guides.
- Wear a dust mask every time. Dry clay and plaster dust are a long-term lung hazard, not just a nuisance.
- Wear glasses, since small pieces of dry clay can fly off the blade.
- Keep fingers well away from the blade and use the push stick for small pieces.
- Never cut fired ceramic on this saw. Fired ware is hard, abrasive and brittle, and it would ruin the blade and could throw sharp fragments.
- Do not cut wet clay. It clogs the blade and gums up the wheels.
- Do not wear loose sleeves, and tie back long hair.
- Keep the loft floor clear. The ladder opening is close, and tripping near a running saw is the scenario I worry about most.

I also keep a rule about fatigue. If I am tired or rushed, I do not use the saw. Most workshop accidents seem to come from hurrying, and the loft has no one nearby to hear a shout.

Dust control is the second half of safety. After each session I wipe surfaces with a damp sponge instead of sweeping, because sweeping throws the fine dust back into the air. The hand vacuum is for the saw housing and the floor around it.

The wiring is also a point to watch. The saw runs from the mains, and the socket in the loft is protected, but I check the lead for damage regularly. A nicked cable near a dusty machine is a bad combination.

## Schedule

I try to follow a simple schedule rather than rely on memory. It is not strict, but it keeps the machine in decent shape.

| Task | How often | Notes |
|---|---|---|
| Brush out dust from wheels and housing | After each session | Use the brush first, then the hand vacuum |
| Check blade for damage | Before each session | Replace if any tooth is missing or a crack shows |
| Check tracking and guides | Weekly when in use | Adjust if the blade wanders on the wheel |
| Oil guide blocks | Monthly | Light machine oil, wipe off any excess |
| Inspect lead and plug | Monthly | Look for nicks and heat marks |
| Check table is square | Seasonally | The loft floor moves a little with temperature |
| Full clean and inspection | Once a year | Remove table, clean wheels, check bearings by hand |

Besides the table, I plan my cutting work in batches. Dry greenware cuts best when it is completely dry, so I leave pieces on the loft shelf for a good while before they get anywhere near the blade. Doing all the cuts in one session means I set up once, clean up once, and wear the mask for one block of time instead of many.

## Overview

The Glivalsark band saw is a green band saw used for ceramics, powered from the mains, installed in 2016, and located in the loft. It is the main shaping machine for dry clay and plaster in my workshop. The table below gathers the basic properties.

| Property | Value |
|---|---|
| Kind | band saw |
| Area | ceramics |
| Color | green |
| Energy source | mains |
| Year installed | 2016 |
| Location | loft |
| Measured power draw | 375.43 W |

In day-to-day terms, it is a reliable machine that asks for steady care. It is not fast or fancy, but it does what I need: clean curves in dry material, quick roughing of plaster, and the occasional wooden jig or frame. The main burdens are dust and blade wear, both of which I have learned to manage.

It sits at the centre of the loft workspace. Shelves, a small bench and the radio are all arranged around it. If I ever redo the workshop layout, as sketched in [[Krespa shed plan]], the saw would be the first machine I plan around, because its weight and its dust make it the least flexible item to move.

## Lessons

Years of using this saw have taught me a few things I wish I had known at the start.

- A fine blade and a slow feed give far better results on greenware than a coarse blade pushed quickly.
- The meter is a good diagnostic. A rise in power draw tells me the blade is dull before I can see it.
- Dust is the real enemy. The saw itself is fine, but without cleaning it the wheels and bearings suffer.
- Sweeping is a mistake. Damp wiping and vacuuming are better in every way.
- Keeping spare blades on hand saves more time than any other single habit.
- Mark cut lines with tape on dry pieces. Pencil does not show well on clay, and tape gives a clear line to follow.
- Let the blade reach full speed before the work touches it. Entering a cut early causes the blade to grab.
- A level, firm base matters. When the loft floor shifted, the table went out of square and my cuts drifted.

I also learned to keep notes on every machine in the same format. The comparison with [[Krasglevur Brunniol tests]] and [[Fulmasvork workshop tests]] showed me how much easier it is to spot problems when the notes use the same headings and measure the same things.

## Open questions

Some things I still do not know, and would like to settle.

- Is there a better dust extraction arrangement for the loft that does not involve a long hose? A small dedicated extractor might work, but I am not sure about the space.
- Does the power draw change much between different materials, for example plaster versus greenware? I only measured the one case.
- How long will the current bearings last? I check them by hand each year, but I have no real way to judge the remaining life.
- Should the saw move out of the loft eventually? The [[Krespa shed plan]] suggests a ground-level home, but moving a heavy machine down a ladder is a serious job.
- Would a different blade tooth pattern cut plaster more cleanly? I have only tried a couple.
- Is the interference I hear on the radio a sign of a problem, or just normal motor noise? I did not find a clear answer in [[Fithkrir radio receiver study]].

## Ideas

A few improvements I might try when time allows.

- Build a small enclosure around the lower wheel housing with a better dust port, so the vacuum catches more at the source.
- Make a set of simple jigs for repeat cuts, such as a circle-cutting jig for bats and a fence for straight slabs.
- Add a work light clipped to the frame. The roof window helps in daytime, but evenings are dim.
- Keep a dedicated blade for plaster and another for clay, so that grit from one does not wear the other.
- Fit a simple switch with a clear off position near the ladder, so I can cut power quickly in an emergency.
- Write a short laminated card of the setup routine and tape it to the wall beside the saw.
- Try recording the power draw over a longer session to see how it drifts as the blade wears.
- Cross-check my maintenance schedule against the [[Saenber band saw handbook]] once more, in case I have missed an interval.

## Checklist

Before each session:

- [ ] Saw unplugged while I inspect it
- [ ] Blade checked, no cracks or missing teeth
- [ ] Tracking looks right when I turn the wheel by hand
- [ ] Guides set just above the work
- [ ] Table square to the blade
- [ ] Mask, glasses and ear defenders on
- [ ] Push stick within reach
- [ ] Floor clear, roof window open
- [ ] Material completely dry and not fired

After each session:

- [ ] Saw unplugged
- [ ] Wheels and housing brushed and vacuumed
- [ ] Surfaces wiped with a damp sponge
- [ ] Floor vacuumed, not swept
- [ ] Blade left with tension eased if the saw will sit unused for a while
- [ ] Notes added to this log if anything unusual happened

## History

- **2016:** The Glivalsark band saw was installed in the loft. At first it was used mainly for wood, cutting boards and frames.
- **Following years:** Ceramics gradually became the main use. I started trimming plaster moulds and cutting dry slabs, and I learned the hard way about dust.
- **Mid period:** I added the hand vacuum arrangement near the lower wheel and began wearing a proper mask every session. The plywood pad under the saw was added after the floor shifted and threw the table out of square.
- **Later:** I began keeping spare blades and started using the power meter as a sharpness check. The measured draw of 375.43 W under a steady cutting load became my reference figure.
- **Recently:** I moved the notes from a paper notebook into this log, linked them to the other workshop notes such as [[Drirvuth air compressor notes]] and [[Drioldosra Zimior notes]], and started thinking seriously about the saw's long-term home.

The saw is still green, still in the loft, and still running from the mains. It has been in service for a good many years now and, with regular cleaning and fresh blades, I expect it to keep going for many more.
