---
type: drivers
status: active
project: daeldir-repair
area: ceramics
description: "Drivers about Daeldir repair."
---

# Drivers of Daeldir repair

## Problems

Daeldir repair is a project in the ceramics area. Its goal is repair. It started in spring 2023, and the lead is the electrician. The problems below are what push the project forward and what I need to keep in mind while I work.

The first problem is that the ceramics setup does not hold a steady temperature. When the kiln controls drift, the firing results change from one batch to the next. A repaired piece can look fine after one firing and crack after the next. That makes it hard to tell whether the repair itself worked or whether the firing was the cause.

The second problem is the wiring and the controls. The lead is an electrician, so most of the early work was about checking the electrical side before anyone touched the ceramic parts. Loose connections, worn insulation and a controller that sometimes reads wrong were the main suspects. I would rather fix these first, because a repair done on top of a faulty heat source is wasted effort.

The third problem is water. Some of the pieces and the cooling and rinsing arrangement are connected to the pond water, see [[Zaendsturk pond]]. Water quality and level change with the weather, and that affects how the pieces are cleaned and cooled. I need to keep this in mind when I compare results between seasons.

The fourth problem is records. In the first months I did not write down enough. I could not say later what had been changed and when. This is why the logger notes now matter so much, and why I keep [[Brugar data logger log]] as the single place for readings.

The fifth problem is scope. A repair project like this tends to grow. Every time I open something up I find another thing that could be done. I need a clear line between what is part of Daeldir repair and what is just nice to have.

## Budget

The budget of Daeldir repair is 38362.46 EUR.

This figure covers the whole project. It is meant to cover parts, materials, tools that I have to buy or hire, and any outside work that the electrician cannot do alone. It does not cover my own time, which I do not count.

I try to keep the budget split into rough groups so that I can see where the money is going without a spreadsheet:

- Electrical parts and safety items, which come first.
- Ceramic materials and replacement pieces.
- Measuring equipment, mainly what feeds the logger.
- Water handling items connected to the pond.
- A reserve for things I did not expect.

I keep the reserve on purpose. In the past, projects in this area went over because I assumed every repair would be done on the first try. They rarely are. If the reserve is gone before the project is two thirds done, that is a signal to stop and rethink the scope, not to find more money.

## Costs

The costs are the actual spending against the budget. I do not repeat exact figures here beyond the budget itself, because the running totals live with the receipts. What I record in this note is the shape of the costs.

Early spending was heavy on electrical work. That was expected, since the lead is the electrician and the first job was to make the power side safe and reliable. After that the costs moved toward ceramic materials and test pieces.

Some costs repeat. Test firings use power and materials every time. Each failed repair costs a little, and I count that as the price of learning rather than as waste, as long as I write down what I learned.

Some costs are one-off, such as measuring equipment. These are easy to justify because they pay back in better information. The logger is the best example. Without it I was guessing, and guessing is expensive in ceramics.

Costs I try to avoid:

- Buying spare parts "just in case" without a reason in the notes.
- Paying for rush delivery when waiting a week would do.
- Redoing work because I skipped a check.

When a cost looks larger than I expected, I write one line in the history section about why, so that I do not have to remember it later.

## History

The project started in spring 2023. The season matters here because the first work was done when the weather was changing and the pond conditions were not stable.

Rough timeline, in my own words:

- At the start, the goal was simply to get the equipment working again and to repair the damaged ceramic pieces. The plan was loose.
- The electrician took the lead early on, mostly because the electrical faults were the most urgent and the most dangerous.
- After the wiring was sorted out, I began to run test firings and compare results.
- Later I added logging so that I could see temperature behaviour over time rather than relying on memory.
- Over the following years the project became slower and more careful. Fewer big changes, more small checks.

A lesson from the history: the biggest delays came from not knowing the starting state. When I did not record how things were before a repair, I could not tell whether my change helped. This is now a rule for the project.

## References

Notes and links that this project depends on:

- [[Zaendsturk pond]] for the water side, including level and quality notes.
- [[Brugar data logger log]] for readings and the dates when I changed something.
- [[Zorksaeval Giotio plan]] for the wider plan that Daeldir repair fits into.

I also keep paper receipts and the electrician's handwritten notes in a folder. They are not linked here, but I check them when a cost or a change is unclear.

## Setup

The setup is simple on purpose.

The project lives in the ceramics area of my notes. It is a repair project, so the work is organised around one object or group of objects at a time, not around a long list of tasks.

Working arrangement:

- The electrician leads. Decisions about power, wiring and controls go through them first.
- I handle the ceramic side, the notes and the budget tracking.
- Readings are collected by the logger and copied into [[Brugar data logger log]] after each session.
- Water use is noted against [[Zaendsturk pond]] when it is relevant.

Before each work session I check three things: that the power side is safe, that the logger is running, and that I know what state the piece is in. If one of these is missing, I fix it before starting.

After each session I write a short entry covering what was done, what changed, and what I want to check next time. Short is fine. A short entry written the same day is worth more than a long entry written a week later.

## Risks

The main risks, roughly in order of how much they worry me:

1. **Electrical risk.** Faulty wiring or controls can hurt someone and can ruin a piece. This is why the electrician leads. I do not change anything electrical myself.
2. **Thermal shock and cracking.** Ceramic repairs are sensitive to heating and cooling speed. A repair that is sound can still fail if the temperature changes too fast.
3. **Budget overrun.** The budget is fixed at 38362.46 EUR in the Budget section, and the reserve is the only cushion. Scope growth is the usual cause of overruns.
4. **Water conditions.** Changes in the pond can affect cooling and cleaning. See [[Zaendsturk pond]].
5. **Poor records.** If I skip logging, I lose the ability to judge results. This is a quiet risk, but it has hurt me before.
6. **Lead availability.** The electrician is the lead, so if they are not available, electrical work stops. I try to plan sessions around their time.

For each risk I try to have a simple response: stop, check, write it down, and only then continue.

## Observations

Things I have noticed over the course of the project:

- Most failures come from the conditions around the repair, not from the repair itself. Heat control and handling matter more than the material.
- Results differ between seasons. Spring work tended to be more variable than later work, probably because the starting conditions were less stable.
- The logger made the biggest difference to my confidence. Once I could see the temperature curve, arguments with myself about what went wrong mostly ended.
- The electrician's checks often found small problems that would never have shown up in the ceramics alone.
- Short, regular sessions work better than long ones. Tired work leads to skipped checks.
- When I compare results, I need the same conditions. If the water or the weather changed, I note it, otherwise the comparison is not fair.

How I measure success, as I currently understand it:

- The repaired pieces survive repeated firing and normal use without new cracks.
- The electrical side passes the electrician's checks and stays stable.
- The project finishes within the budget of 38362.46 EUR.
- The notes are complete enough that someone else, or me in a year, could repeat the work.

## Ideas

Ideas that I have not committed to yet:

- Write a one-page checklist for the start of every session and keep it at the top of the logger log.
- Add a simple rule to the logger notes: every reading gets a short comment about the weather and the water condition.
- Test slower heating and cooling on one sample piece and compare it with the usual speed, using the same logger setup.
- Ask the electrician to write a short guide to the electrical side, in plain language, so I understand what is checked and why.
- Review the wider plan in [[Zorksaeval Giotio plan]] and see whether any of its goals should change what I do here.
- Set a clear stopping point: a list of conditions under which I will call the project finished, so that it does not drift on.
- Keep a small box of tested spare parts so that I do not stop work waiting for a delivery.

## Overview

Daeldir repair is a project with the goal of repair, in the ceramics area. It began in spring 2023 and the lead is the electrician.

This note is the drivers note. It sets out why the project exists, what limits it, how much money it has, and how I will know that it worked.

Goal: repair the equipment and the ceramic pieces so that they work reliably and survive repeated use.

Constraints:

- The electrical side must be safe, and the electrician has the final say on it.
- The budget is 38362.46 EUR and does not grow without a clear reason written down.
- Water conditions from the pond affect the work and cannot be controlled, only noted.
- Time is limited to sessions when the lead is available.

Measure of success: stable results across repeated firings, a clean electrical check, spending within budget, and records that make the work repeatable.

## Background

The project comes from a practical need. Equipment in the ceramics area had worn down, and some pieces were damaged. Replacing everything would have cost far more than repairing it, and some parts were hard to replace anyway. So I chose repair.

I made the electrician the lead because the first and most serious problems were electrical. A ceramic repair is pointless if the heat source is unreliable, and unsafe wiring is a danger to anyone nearby. Putting the electrician in charge made the order of work clear: power first, then controls, then ceramics.

The water connection comes from the location. The pond, described in [[Zaendsturk pond]], is the practical water source, and its condition changes with the season. That is why I started noting conditions alongside readings.

The logging habit came later, after I lost track of changes. It now sits in [[Brugar data logger log]], and I treat it as the memory of the project.

The project also fits into a larger set of intentions. [[Zorksaeval Giotio plan]] describes that wider picture, and Daeldir repair is one part of it. I try not to let the repair project take over time and money meant for the other parts.

In short, Daeldir repair is a modest, careful project. It started in spring 2023, it is led by the electrician, it belongs to the ceramics area, its goal is repair, and its budget is 38362.46 EUR. If I keep the records and respect the electrical checks, it should end with working equipment and pieces that last.
