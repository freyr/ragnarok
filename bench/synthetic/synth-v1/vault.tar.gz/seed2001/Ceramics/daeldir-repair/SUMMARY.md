---
type: summary
status: active
project: daeldir-repair
area: ceramics
description: "Summary about Daeldir repair."
---

# Summary of Daeldir repair

## Safety

Daeldir repair is a project in the ceramics area. The goal is repair, it started in spring 2023, and the lead is the electrician. Because the lead is an electrician, most of the safety thinking here is about power and heat, not about the clay itself.

Current safety points I keep in mind:

- Disconnect the supply and confirm it is dead before anyone opens a panel or touches a wire. Do not trust a switch alone.
- Let the equipment cool fully before any work on heating parts. Ceramic stays hot much longer than it looks.
- Wear gloves and eye protection when handling broken pieces, because the edges are sharp and fine dust gets into the air.
- Keep the work area dry and clear of loose cables, so nobody trips or touches a live part by accident.
- Only the lead does the electrical work. Others handle the ceramic parts and cleaning.

Stage of the project: it is past the planning stage and now in the repair phase. The go decision has been made, so the work is no longer waiting for approval. What is done so far is the inspection, the list of damaged parts, and the basic safety setup in the work area. What is not done is the actual mending and the final test.

Open safety question: I still want a written order of steps for the first power-on after repair. It should say who switches on, who stands where, and what we check before leaving it running. I have not written it yet.

## Next action

The next action is NX-9603. I treat it as the single thing to do before anything else on this project, so I do not start other jobs until it is finished.

How I work on it:

- Read the current notes on the damaged parts first, so I do not repeat the inspection.
- Confirm with the lead that the supply is off and tagged before I start.
- Do the work in one sitting if I can, because stopping halfway leaves parts loose and easy to lose.
- Write down what I did and what I saw straight afterwards, while I still remember it.

After NX-9603 is done, I will review the open points below and pick the next step from them. I do not plan further ahead than that, because the result of this action will change what is needed.

Open points still waiting:

- The written order of steps for the first power-on, as described under Safety.
- A decision on whether the cracked piece can be mended or must be replaced. It depends on what we find when we look closer.
- A check of the wiring condition once the housing is open. The lead expects it to be fine but wants to see it.
- A final test plan, short and practical, with a clear pass or fail result.

## Decisions

The go decision date for Daeldir repair is 2026-10-03. On that date I agreed with the lead that the repair is worth doing and that we proceed. Before that, the question was whether to replace the whole item instead. We chose repair because it matches the goal of the project and because the item is worth keeping.

Decisions taken so far:

- Proceed with repair, not replacement.
- The electrician leads the project and has the final say on anything electrical.
- Safety steps come before speed. If a step cannot be done safely, it waits.
- Work is done in small steps with notes after each one, so the history is easy to follow later.

Decisions still to make:

- Mend or replace the cracked piece, after closer inspection.
- Whether to add a simple protective cover once the repair is finished.
- How we will record the final test result, and where the note will be kept.

Since the project began in spring 2023, it has gone slowly with long gaps. That is normal for this kind of work, but I want the current phase to move steadily. Keeping one clear next action and a short list of open points is how I plan to do that. When the final test is passed, I will close the project and write a short closing note with what was learned, so the next ceramics repair starts from better knowledge.
