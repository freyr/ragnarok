---
type: research
status: active
project: daeldir-repair
area: ceramics
---

# Vanstol heat exchanger study

## Lessons

These are the points I would want to remember before I touch the Vanstol heat exchanger again. I wrote them down after living with it for years, so they are practical rather than theoretical.

- The Vanstol is a blue ceramic heat exchanger, and the colour is not just cosmetic. The blue glaze is the first thing that shows damage. A hairline crack or a chipped edge is easy to see against it, so a quick look each time I walk past the yard is enough to catch trouble early.
- It runs on mains power, so every job on it starts with the supply being switched off and confirmed dead. I do not trust a switch alone. I check at the unit.
- It has been installed in the yard since 2017. That means it has seen many winters, many summers and a lot of rain. Most of what I have learned is about weather, not about the device itself.
- Ceramics do not forgive sudden change. A cold rinse on a hot body, or a knock from a tool, is how things go wrong. I move slowly around it.
- Writing down what I did each season is worth the effort. Without notes I forget which fitting I loosened and which one I left alone.
- Keep the area around it clear. Leaves, stored pots and a leaning ladder have all ended up too close to it at some point, and each one was a mistake.

A short summary of the subject, so the exact values sit in one place:

- Device: Vanstol heat exchanger
- Kind: heat exchanger
- Area: ceramics
- Color: blue
- Energy source: mains
- Year installed: 2017
- Location: yard

## Setup

This section describes how the Vanstol is arranged and how I prepare it for use. It is a heat exchanger, so its job is to move heat from one flow to another without letting the two mix. The body is ceramic and blue, and it stands in the yard where it was put in 2017.

### Position

The unit sits outdoors in the yard, on a firm and level base. I checked the level with a small spirit level when it went in, and I check it again once a year. If the base settles on one side, the connections take a strain they were never meant to take, and with a ceramic body that is a real concern. I keep a clear gap around it on every side so that I can reach the fittings and so that air can move past.

### Power

The energy source is mains. The supply comes from the house through a protected outdoor circuit. I keep the cable off the ground, away from standing water, and out of the path where I walk with a barrow. The isolator is within sight of the unit, so I can see that it is off while I work.

### Routine before use

My usual order is this:

1. Look over the blue body for cracks, chips and stains.
2. Check the connections for weeping or damp patches.
3. Check the cable and the plug or isolator for wear.
4. Make sure nothing is stacked against the unit.
5. Switch on and listen. A steady, quiet note is normal. Any new rattle or hum means I switch off and look again.

### Routine after use

When I am finished I let the unit settle to outdoor temperature before I touch it with anything wet. I wipe the dust off the glaze with a soft dry cloth, and I never use anything abrasive. If the weather is bad, I cover the fittings but not the whole body, because a sealed cover traps damp and causes more trouble than it prevents.

## Safety

The Vanstol is a mains device sitting outdoors, so there are two kinds of hazard to respect: electrical and thermal. A third, the fragility of the ceramic, affects both.

### Electrical

- Always isolate the mains supply before any inspection that involves touching the fittings.
- Keep the supply on a protected circuit that cuts out quickly if there is a fault. Outdoors, damp is the normal condition, not the exception.
- Never work on it with wet hands or while standing in a puddle.
- Do not run an extension lead across the yard to power it. A fixed, proper supply is the only sensible option.
- Replace any cable that looks cracked, stiff or faded. Sunlight ages the outer layer over the years.

### Thermal

A heat exchanger is meant to carry heat, so surfaces can be hot. I treat the blue body as hot until I have proved otherwise with the back of my hand held near, not on, the glaze. After a long run I leave it alone for a good while. Children and pets are kept out of the yard area while it is running.

### Mechanical

Ceramic breaks in a sharp way. A cracked body may leak or may fail suddenly. I wear gloves and eye protection when I handle anything close to it. If I find a crack, I switch off, isolate the supply, mark the unit as out of use and think about it before doing anything else. I do not try to patch a crack with glue and carry on.

### General habits

- Do not lean on it, climb on it or hang anything from it.
- Keep a torch near the yard door so I am never tempted to work in poor light.
- Tell someone in the house when I am going to work on it.

## Background

I put the Vanstol in during 2017, when I wanted a way to move heat in the yard without wasting it. The choice of a ceramic exchanger was deliberate. Ceramic resists corrosion well, which matters outdoors, and it does not stain or flake the way some coated metals do. The price I pay for that is brittleness, and most of my cautions come from that one fact.

The area of the subject is ceramics, and that shapes how I think about it. In my notes it sits alongside other ceramic items I look after, and I use the same habits for all of them: look often, handle gently, avoid sudden temperature change, and keep a record.

The blue colour was not a requirement. It came with the unit. I have grown to like it, though, because it stands out against the yard wall and the gravel, and because it makes any damage easy to see.

Since 2017 the setup has changed very little. The base has been re-levelled once. The cable run has been tidied. A small shelter over the fittings was added after a wet season showed me where water tended to collect. The device itself has not been altered.

What this study is for:

- To gather in one place what I know about the Vanstol.
- To record the exact properties so I do not misremember them later.
- To list the practical lessons from the years of use.
- To work out what could go wrong and what I should do about it.

I am not an engineer, and these notes are the observations of someone who owns the device and looks after it. Where I am unsure, I say so. Where I have been caught out, I say that too.

## Risks

This section lists what I think could realistically go wrong with the Vanstol, and how worried I am about each one.

### Frost and weather

The unit is outside and has been since 2017. Frost is the biggest worry for a ceramic body. If water is trapped in a small crack or a joint and freezes, it can widen the damage. My answer is to inspect before the cold season and make sure the fittings drain and do not hold pools. I rate this risk as moderate and growing as the unit ages.

### Thermal shock

A sudden change in temperature can crack ceramic. Cold rain on a warm body is a plausible case in the yard. I cannot fully prevent it, but the small shelter helps, and I avoid hosing the unit down while it is warm. Moderate risk.

### Impact

The yard is a working place. Barrows, ladders and tools move around in it. A single knock to the blue body could be enough to chip or crack it. I keep a clear zone around it and avoid storing anything nearby. Moderate risk, but easy to reduce.

### Electrical faults

Because the energy source is mains, a damaged cable or a damp connection is a real hazard. The protected circuit lowers the danger but does not remove it. I check cable and connections often. Low to moderate risk, with serious consequences if ignored.

### Ageing

Years of sun and damp wear down seals, cable covering and fixings, even when the ceramic itself is sound. Parts that are not the ceramic are the ones most likely to fail first. I plan to check them each year and replace them before they give out.

### Neglect

The biggest risk of all may be me forgetting. A device that works quietly for years invites carelessness. The notes, the seasonal checks and this study are all meant to guard against that.

- Check before the cold season.
- Check after any storm.
- Check after any work done in the yard near the unit.
- Write down what I find each time.

## Problems

The main trouble with the Vanstol heat exchanger is that it lives in the yard. It is a blue unit, and the paint takes a beating from weather. Water collects around the base after rain, and I have seen a thin rust line forming where the frame meets the concrete. Since it was installed in 2017, the surface has never been fully repainted, only touched up here and there.

The second problem is the power supply. The exchanger runs on mains, and the cable runs across the yard to the outlet by the wall. In wet weather I do not trust the connection. I have tripped the breaker twice after heavy rain, and both times the cause was damp in the plug housing, not the device itself.

The third problem is noise. When the pump starts, there is a low hum that carries into the house if the windows are open. It is not loud, but it is regular, and it bothers me in the evening.

The fourth problem is performance drift. Because the device is used for ceramics work, I care about steady temperatures. Over the last season the output water seemed to take longer to settle. I cannot say if this is scale inside the plates, a tired pump, or just my own impression from poor record keeping.

Short list of what is wrong right now:

- Rust forming at the base of the frame
- Damp in the plug housing after rain
- Hum from the pump in the evening
- Slow settling of the output temperature
- No proper written log of readings

## Schedule

I want to put the work into a fixed order, so nothing is skipped when the weather changes. The yard is only comfortable to work in during dry spells, so the outdoor jobs come first.

- Spring: inspect the frame, wire-brush any rust, apply primer and blue paint, check the base for standing water.
- Early summer: flush the plates with a mild descaling solution, rinse well, and check the pump mounting for looseness.
- Late summer: test the mains connection, replace the plug housing if there is any sign of moisture, and test the breaker.
- Autumn: cover the unit before the wet season, clear leaves from around it, and record a full set of readings.
- Winter: only a quick look once a month, mainly for ice, cracks and water pooling.

For the readings, I plan to take them at the same time of day, on a dry morning, and write them in a notebook kept in the workshop. Each entry should have the date, the air temperature, how long the output took to settle, and any odd sounds. A plain table in this note would work, but paper is easier with wet hands.

I also want one yearly check on the anniversary of the installation. The device went in during 2017, so every year I will treat that month as the time for a longer review, with photographs of the frame, the connections and the plates if I open the unit.

## Supplies

Most of what I need is cheap and simple. I should keep it together in one box near the yard door, so I do not have to hunt for things in the middle of a job.

- Wire brush and coarse sandpaper for the rust
- Rust-converting primer suitable for metal outdoors
- Blue exterior paint, matched as closely as I can to the original color
- Small brushes and a roll of masking tape
- Mild descaling solution safe for the plate material
- Clean buckets and a hose with a gentle spray head
- Spare outdoor plug housing with a sealed cover
- Silicone grease for the connection points
- Rubber feet or a raised pad to lift the base off the concrete
- Anti-vibration mounts for the pump
- Waterproof cover that fits the unit
- Notebook, pencil and a simple thermometer

I should also keep rags, gloves and eye protection nearby. The descaling liquid is not dangerous in small amounts, but I do not want it on my skin or splashed near the mains connection. Before any work on the electrical side, I switch off at the breaker, unplug, and only then open anything.

One more item to consider is a small outdoor socket box fixed higher on the wall, so the plug is no longer near the ground where water collects.

## Ideas

A few ideas have come up while thinking about the problems. None is decided yet.

First, a simple roof over the unit. It does not need to be fancy: a slanted sheet on two posts would keep most of the rain off, protect the paint and keep the plug dry. The risk is that the roof traps heat or blocks airflow around the exchanger, so I need to leave open sides.

Second, a raised plinth. A small block or set of paving stones under the frame would keep it out of the puddles and reduce rust. It would also make it easier to reach the underside for cleaning.

Third, moving the electrical connection. Instead of a plug lying on the ground, I could install a proper weatherproof outlet on the wall at chest height and run the cable in a short, neat loop. A drip loop in the cable would stop water running along it into the housing.

Fourth, deal with the noise using rubber mounts and perhaps a low fence panel or a trellis with plants on the house side. Plants will not block sound much, but a solid panel might help a little.

Fifth, make the record keeping easier. A cheap temperature logger placed in the output line could replace the notebook for some readings, so I can see how the settling time changes without standing there with a watch.

Last, a comparison idea: once the plates are clean, I should record the settling time right away and keep that as the baseline. Then every later reading can be compared with the clean state, and I can tell whether scale is the real cause of the drift.

## Observations

These are things I have noticed while looking at the unit, written down so I can compare them later.

The Vanstol is a heat exchanger used in my ceramics area, and it is blue. The color has faded on the side facing the afternoon sun, and the shaded side looks almost new. It has been in the yard since 2017, and it still works, which says something good about the build. The energy source is mains, and I have never had a problem with the supply voltage itself, only with the connection outdoors.

The rust is worst at the lower corners, where water runs down the frame and stays. The upper part of the casing is mostly clean. There are no leaks that I can see at the pipe joints, but I should check again after a long rainy period, because small drips could hide in the damp.

The hum from the pump changes with temperature. On cold mornings it is a little louder at start and then settles down after a few minutes. On warm days it is hardly noticeable. That makes me think the pump is not failing, but the mounting may be transmitting vibration to the frame.

The output temperature seems to climb steadily in the first ten minutes and then level off, though I have not timed it carefully. Some days it levels sooner, and I suspect air temperature and wind play a part, since the unit stands in the open. Wind seems to matter more than I expected.

Finally, spiders and insects like the space behind the unit. I should clear that area during each check, because debris there can hold moisture against the frame.

What I want from the next season is better data, not more guessing. If the readings show a clear pattern, I can decide whether to clean, repair or replace parts, and I will write the result into this note.

## References

These are the sources I used for the study. Most of them are my own records, because the Vanstol heat exchanger is a private installation and there is very little published about it. It is a blue heat exchanger that runs on mains power. It was installed in 2017 and stands in the yard.

- My own logbook for the unit, kept in a paper notebook in the workshop. It holds the first observations after the 2017 installation and every service visit since.
- The installer's handover sheet, which I scanned and stored with the other papers for the yard. It lists what was connected, which valves were left open, and what the installer told me about normal running sounds.
- The owner's booklet that came with the unit. It is short and mostly useful for the wiring diagram and the list of warning signs.
- My photographs of the unit through the seasons, taken from the same spot by the yard gate. They show how the blue paint has weathered and where moisture collects.
- Notes from conversations with a neighbour who runs a small ceramics workshop and has used similar equipment for longer than I have.
- My earlier notes in this knowledge base about the yard drainage and the outdoor power supply. Both affect how the exchanger behaves, so I reread them while writing this part.

I treat the handover sheet and the booklet as the most reliable sources for design intent. I treat my logbook as the most reliable source for how the unit actually behaves. Where they disagree, I trust the logbook, and I say so in the text.

One caveat: the neighbour's experience comes from a different site, with a different power supply and a more sheltered position. It helps as a comparison but should not be read as direct evidence about my unit.

## Open questions

Several things are still unclear after all the years of watching this unit. I list them here so I can come back to them and tick them off as I learn more.

- Why does the unit run a little louder in cold weather? I have noticed it every winter since 2017. It may be thicker fluid, it may be the mains supply behaving differently under load, or it may just be the yard air carrying the sound further. I have not tested any of these.
- How much does its position in the yard matter? The unit stands in the open. I do not know whether a simple roof or screen would make it last longer, or whether it would only restrict airflow and cause new problems.
- Is the blue coating original, or was it repainted at some point before I took over the records? The handover sheet does not say. The colour has faded unevenly, which suggests either a repaint or uneven sun exposure.
- What is the real condition of the ceramic parts inside? The area is ceramics, and the ceramic elements are the part I cannot see without opening the unit. I do not know how to judge wear on them without taking it apart.
- Does the mains supply to the yard have enough margin? On a few occasions the unit seemed to hesitate at start-up when other tools were running on the same circuit. I have not measured anything, so this is only an impression.
- Would a second, smaller unit make sense later? I have only thought about it in general terms and have not worked out whether the yard has room or whether the supply could carry it.
- How should I record small changes better? My logbook entries are uneven. Some are detailed and some are one line. A fixed set of questions for each visit would make comparison across years easier.

None of these is urgent. The unit has run steadily, and the open questions are mostly about getting longer life out of it and understanding it better.

## Costs

I am not writing exact amounts here, because I do not want old figures drifting out of date in a note I will reread years later. Instead I describe the kinds of cost and how large each one feels relative to the others.

The biggest single cost was the original purchase and installation in 2017. That covered the unit itself, the connections, the base it stands on in the yard, and the work of bringing mains power to it. Since then, the running costs have been much smaller and more spread out.

Running costs come mainly from electricity. Because the energy source is mains, the cost follows the general price of power and how many hours the unit runs. In my experience it is a modest part of the yard's total energy use, but it is steady and it grows in cold months when the unit works harder.

Maintenance costs are small but regular:

- Cleaning supplies and basic tools, which I mostly already owned.
- Replacement seals and fittings, bought only when a check showed wear.
- Touch-up paint in the right shade of blue, needed now and then where the coating chips.
- My own time, which I do not price but which is the real cost of the checklist below.

Possible larger costs in the future are the ones to plan for. A repair of the ceramic parts would be the most significant, and I would want a professional opinion first. A new power line or a protective structure for the unit would also be a real expense. I keep a loose reserve in mind for these, rather than a fixed sum.

The main lesson from the cost side is that regular small attention costs far less than a late repair. Most of my spending has gone on prevention, and I think that has been the right balance.

## Checklist

This is the list I follow at each visit to the unit. It is short on purpose, so that I actually do it. I go through it in the order written, and I record the answers in the logbook.

Before starting:

- Confirm the mains supply to the unit can be switched off safely and that I know where the switch is.
- Switch the unit off and wait for it to settle before touching anything.
- Check the weather. I do not open or clean the unit in rain.

Visual checks:

- Look over the blue casing for chips, rust spots, and flaking paint.
- Check the base in the yard for cracks, sinking, or standing water.
- Look at the cable and its entry point for damage, kinks, or signs of chewing by animals.
- Check around the unit for leaves, dirt, or stored items that block airflow.

Operating checks:

- Switch the unit back on and listen to it for the first few minutes.
- Note any change in sound compared with the last entry, especially anything new.
- Feel for unusual vibration at the casing.
- Look for drips or damp patches near the connections.

Closing up:

- Write the date in my logbook entry, with anything unusual I noticed.
- Take one photograph from the usual spot by the yard gate.
- Add a line to the open questions if something new came up.

If any check turns up something I cannot explain, I stop and leave the unit off until I understand it. I do not try to fix the ceramic parts myself.

## Maintenance

Maintenance of the Vanstol heat exchanger is mostly about keeping it clean, dry, and safely powered. The unit has been in the yard since 2017, so the main enemy is weather rather than heavy use.

I do a light check every month and a fuller one at the change of each season. The monthly check is just the visual and listening part of the checklist. The seasonal check adds cleaning and a closer look at fittings.

Cleaning is simple. I wipe the blue casing with a damp cloth and mild soap, then dry it. I never use a strong jet of water, because I do not want water forced into the electrical connections. I clear leaves and dirt from around the base by hand. Before winter I make sure nothing can pool around the unit and freeze against it.

For the power side, I check the cable and plug connection by eye and make sure the outdoor socket cover closes properly. I do not open any electrical part. If I see damage to the supply, I leave the unit switched off and get a qualified electrician.

For the paint, I touch up chips as soon as I find them. Bare spots rust quickly in a yard, and a small patch of matching blue is much easier than treating spread corrosion later. I sand lightly, apply a rust inhibitor, and then paint.

The ceramic parts are the one area where I limit myself to observation. I note sound, performance, and any change in how long the unit takes to do its work. A slow drift in any of these may mean wear, and I would then ask for a professional inspection instead of opening the unit myself.

Finally, I keep the records tidy. The logbook, the photographs, and the handover sheet are all part of maintenance, because without them I could not tell normal ageing from a new fault. Looking back over several years of entries is the best tool I have for deciding when something deserves attention.

## History

The Vanstol heat exchanger is a blue unit that sits in the yard, next to the wall of the old ceramics workshop. It was installed in 2017. I keep these notes for my own use, so they cover what I remember, what I wrote down at the time, and what I have checked since.

Before 2017 the workshop had no proper way to recover heat. The kiln cooling water and the glaze room washdown both ran to waste, and in winter the glaze room was cold enough that slip would not dry evenly. I had been thinking about a heat exchanger for a couple of seasons. The main reason I finally bought one was the cost of heating the glaze room. A second reason was that I wanted one device that could take the warm water from the kiln side and pass its heat to a clean loop, without the two liquids ever mixing.

### Choosing the unit

I looked at several makes. I picked the Vanstol for practical reasons:

- It runs from mains power, so I did not have to bring in a gas line or a fuel tank to the yard.
- The housing is blue, which is a small thing, but it is easy to spot in the yard and hard to confuse with the grey pipework around it.
- It is a plain heat exchanger with few moving parts. The only electrical part is the circulation side, which draws from the mains socket I had already put on the outside wall.
- It is rated for use outdoors, which mattered because the yard is its permanent location.

I did not choose it for any special ceramics feature. The ceramics area is simply where it is used. The warm water comes from the kiln cooling circuit and from the rinse tanks, and the recovered heat goes to the glaze room and the drying shelves.

### Installation in 2017

The unit went in during 2017, in the dry part of the year, so the ground around the base was firm. The steps were roughly these:

1. I laid a small concrete pad in the yard, level to within what I could judge with a spirit level.
2. I set the unit on the pad and fixed it with the supplied brackets.
3. I ran insulated pipe from the kiln cooling circuit to the primary side of the exchanger.
4. I ran a second insulated pipe from the secondary side to the glaze room.
5. I connected the mains supply through a weatherproof socket and tested the circulation by hand before closing up the trenches.

The first run showed me two problems. One of the pipe joints wept slightly, and I had not insulated the elbow nearest the wall. I fixed both within the week. I also found that the primary side needed bleeding of trapped air, which I now do at the start of every season.

### Early use and changes

For the first winter I ran the exchanger on a simple routine. I switched it on in the morning when the kiln cooling began, and off in the evening. The glaze room warmed up much more evenly than before, and the drying shelves stopped giving me the uneven results I used to get on cold days.

Over the following years I made a few changes:

- I added a cover over the pad to keep leaves and rain off the top of the unit.
- I replaced the first length of secondary pipe with a better insulated one, after I noticed it was losing heat in the yard section.
- I added a strainer on the primary inlet, because ceramic dust and bits of clay were getting into the water from the rinse tanks.
- I started keeping a small logbook next to the glaze room door, with notes on cleaning and on anything odd.

### Maintenance habits

I clean the strainer often, because that is the part that clogs first. Once a year, before winter, I flush the primary side, check the joints and look over the housing for rust or chips in the paint. The blue paint has held up well. There is some fading on the side that faces the afternoon sun, but no corrosion.

I have not had a major failure since 2017. The worst events were a clogged strainer and a loose connection on the mains plug, which I fixed by replacing the plug with a better sealed one.

## Measurements

This section records what I have measured on the Vanstol heat exchanger, and how. I keep the method with the result, because a number alone is not much use when I come back to it later.

### Summary of properties

Here are the fixed properties of the unit in one place, so I do not have to search for them:

- Kind: heat exchanger
- Area: ceramics
- Color: blue
- Energy source: mains
- Year installed: 2017
- Location: yard

### Flow rate

The main figure I track is the flow rate through the unit. The flow rate of the Vanstol heat exchanger is 1752.12 l/h. I got this by timing how long the primary side took to fill a marked container, repeating the test several times, and averaging the results. I then converted the result to litres per hour. I did the test with the strainer freshly cleaned, because a dirty strainer lowers the reading noticeably.

A few notes on that figure:

- It is a working figure, not a lab figure. My container marks and my stopwatch are both rough.
- It applies to the primary side. The secondary loop runs a little differently, because it is a closed loop with its own pump and its own pipe length.
- It was measured with the unit running from the mains socket at its normal supply, with no other heavy equipment on the same circuit.
- If the reading drops, I check the strainer first, then the air in the lines, then the pump.

### How I measure

I keep the method simple so I can repeat it every season without special tools.

1. Clean the strainer and bleed the air from the primary side.
2. Run the unit for a few minutes so that the flow settles.
3. Divert the outlet into a marked container and start the stopwatch.
4. Stop when the container reaches the mark, and write down the time.
5. Repeat several times and take the average.
6. Convert to litres per hour and write the result in the logbook.

I use the same container every time. It is a plain plastic bucket with a mark I made myself. The mark is not precise, but because I use the same bucket, the comparison between seasons is still fair.

### What the flow tells me

The flow rate is a good early warning. When the strainer begins to clog, the flow falls before I see any change in the glaze room. When air gets into the line, the flow becomes uneven and the pump is louder. When the flow is steady and near the figure above, the rest of the system usually behaves well.

I have learned to read the unit by feel and sound as well as by number. A healthy run has a low, even hum from the pump and no knocking in the pipes. The housing is warm but not hot to the hand on the primary side. If the housing is hot in one patch, I suspect a blockage and stop the unit.

### Heat transfer in practice

I do not have a precise way of measuring the heat recovered, so I rely on practical checks instead:

- The glaze room is comfortable to work in during cold mornings once the unit has run for a while.
- The drying shelves dry evenly, with no damp side.
- The water leaving the secondary side feels clearly warmer than the water returning to it.
- The kiln cooling water returns to the circuit cooler than it left, which tells me the heat is going somewhere useful.

If I ever want a proper figure, I would need two thermometers on the pipes and a more careful flow test. For now, the practical checks are enough for how I use the room.

### Condition of the unit

Last time I looked it over, the condition was good:

- The blue housing is intact, with some sun fading on one side.
- The brackets and pad are solid, with no cracks in the concrete.
- The joints are dry.
- The insulation on the yard pipes is in place, though the oldest section is a little brittle and I plan to replace it.
- The mains plug and socket are dry and sealed.

### Things to check next

I want to follow up on a few points when I have time:

- Repeat the flow test after the next strainer clean and compare it with the figure above.
- Replace the oldest insulation on the secondary pipe.
- Add a simple thermometer on each side so I can estimate the heat recovered, instead of judging by feel.
- Touch up the paint on the faded side before it begins to chalk.
- Write the next flow reading in the logbook, with the date and the strainer state next to it.

These checks are all small jobs. The Vanstol heat exchanger has been dependable since it went into the yard in 2017, and most of my effort is routine care rather than repair.
