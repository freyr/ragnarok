---
type: drivers
status: active
project: fartark-rebuild
area: aquaponics
description: "Drivers about Fartark rebuild."
---

# Drivers of Fartark rebuild

## Overview

This is the drivers note for the Fartark rebuild. It records why the project exists, what limits it, what money is set aside, and how I will know it worked. The project is a rebuild in the aquaponics area. It started in spring 2021, and the lead is the carpenter.

Properties of the project, stated plainly so I do not have to hunt for them:

- Project: Fartark rebuild
- Goal: rebuild
- Area: aquaponics
- Start year: 2021
- Season: spring
- Lead: carpenter

The goal is a plain rebuild. I am not redesigning the system from scratch and I am not expanding it. The existing Fartark setup stays in the same place, does the same job, and gets rebuilt so that it is sound again. Where something has to change to make it hold up, I change it. Where it does not, I leave it alone.

The carpenter leads because most of the rebuild is wood and framing: the stands, the bed supports, the covers, and the bench that carries the grow beds. The water and plant side follows the structure, not the other way round. If the structure is wrong, nothing else matters.

I keep this note short on technique and long on reasons. The reasons are what I forget. The how-to belongs in the other notes for the project.

## Tools

The tools drive the project because the lead is a carpenter and the work is mostly cutting and joining timber. Having the right tool on the day is a constraint in itself, since a missing tool stalls the whole crew.

Main tools I expect to need:

- A band saw for ripping and resawing timber. The [[Turen band saw]] is the one I plan to use, so its condition and blade matter before spring.
- Hand saws, chisels and a mallet for the joinery that does not suit a machine.
- A drill and driver with a good set of bits.
- Clamps, more than I think I need.
- Squares, a level and a long straightedge. The beds must sit level or the water will not flow properly.
- A plain tape measure and a marking knife.
- Basic plumbing tools for cutting and fitting pipe.
- Sanding blocks and a scraper for finishing wood that will be near water.

The shop layout is covered in [[Nizi workshop plan]]. I should read that before I set up for cutting, because the order of the benches decides how timber moves through the room. If lengths have to be carried around corners, I will lose time and probably damage something.

Tool rule for this project: check each tool a week before it is needed, not the morning of. Blades get checked first.

## Supplies

Supplies are the second driver. Timber is the largest item and the one with the longest lead time, so it is ordered first.

What the rebuild needs, in rough groups:

- Timber for frames, stands and supports. It should be sound, dry and straight. Wet timber moves as it dries and will wreck tight joints.
- Fixings: screws, bolts and brackets suitable for damp conditions. Plain steel will rust and stain, so I use coated or stainless fittings.
- Food-safe sealant and a water-safe finish for any wood that touches or sits near water.
- Pipe, fittings and valves for the water circuit.
- Liner or tubs for the grow beds, if the old ones cannot be reused.
- Media for the beds, reused where it is clean.
- Spare parts for the pump and the air supply.

Constraint on supplies: anything that touches the water must be safe for fish and plants. That rules out some cheap paints and treated timber. When in doubt, I leave it out and ask.

Humidity in the storage area can spoil timber and fittings before the work begins. The [[Kathses dehumidifier]] helps with that, and I plan to run it where the timber is stacked.

## Schedule

The project is set for spring, which is the right season for aquaponics: the water warms, the plants wake up, and the fish become active. Starting in spring in 2021 meant the rebuild had to be done early enough for the growing season to begin on time.

The order of work matters more than the dates:

1. Clear and drain the old system, and move the fish and plants to a safe temporary place.
2. Strip the old structure and record what is reusable.
3. Build the new frames and supports. This is the carpenter's main phase.
4. Fit the beds and check they are level.
5. Run the plumbing and test it with plain water.
6. Cure and clean, then fill with system water.
7. Return the fish, then plants, in stages.

Constraints on timing:

- The fish can only stay in temporary housing for a limited time without stress, so the gap between draining and refilling should be as short as I can make it.
- Wood must be ready before the system is drained, not after.
- A leak test comes before any live stock goes back.
- Weather affects any outdoor work, so I leave slack at the front, not the back.

I treat the schedule as a sequence with checkpoints, not as a calendar. Each stage ends with something I can check.

## Costs

Costs are the third driver, and the main way I keep the project honest. Money goes to three places: structure, water system, and stock and consumables.

Cost thinking I follow:

- Timber and fixings are the biggest and least flexible lines. I buy decent material once instead of cheap material twice.
- Plumbing is smaller but easy to underestimate, because fittings add up quickly.
- Power matters. The pump runs all the time, so a plan for reliable energy is a cost question as well as a technical one. The [[Kuglend solar charger plan]] covers one way of supplying part of it.
- Fish and plants are a cost if I lose any during the move.
- Small items such as tape, glue, sealant and sandpaper are never in the plan and always in the receipts.

Rules for spending:

- Write down every purchase the day it happens.
- Check the running total against the budget at each schedule checkpoint.
- If one line overruns, find the saving in another line before buying more.
- Do not buy tools I will only use once. Borrow or hire.

The actual budget figure is in the Budget section below.

## Checklist

A short list I can tick off. These are the conditions that must be true for the rebuild to count as done.

- [ ] Old system drained, stock housed safely
- [ ] Structure removed and reusable parts recorded
- [ ] New frames and supports built and checked for square
- [ ] Beds set level
- [ ] All wood near water sealed with a safe finish
- [ ] Plumbing fitted and leak tested
- [ ] Pump and air supply working
- [ ] System filled and run before stock returns
- [ ] Water checks acceptable
- [ ] Fish returned in stages
- [ ] Plants returned in stages
- [ ] Spending written up against the budget
- [ ] Notes updated with anything that went differently

Before I start, also confirm: tools checked, timber dry, workshop layout settled, and a person available to help with the heavy lifting.

## Ideas

Ideas that are not part of the goal but might be worth doing if the budget and time allow. They stay here until they earn a place.

- Build the bench so the beds can be lifted out in sections for future cleaning.
- Add an access hatch beside the pump so I do not have to move beds to reach it.
- Use removable joints, such as bolts instead of glue, where I may need to take things apart later.
- Label each pipe run with a small tag.
- Add a simple cover over the fish tank to cut algae and keep leaves out.
- Run part of the pump power from solar, following the [[Kuglend solar charger plan]].
- Build a small shelf for test kits and notes so they are always at hand.
- Ask [[Drarktend Sunnarzio]] to look over the frame design before I cut, since a second pair of eyes tends to catch mistakes.

None of these should delay the main rebuild. If an idea adds more than a day of work, it waits.

## Lessons

Lessons I want to carry into this project, from earlier builds and from planning this one:

- Level is everything. A bed that is slightly out will drain unevenly and cause trouble for months.
- Dry timber costs more up front and saves time later.
- Test with plain water first. A leak found early is an annoyance; a leak found with fish in the system is a crisis.
- Leave room for access. Anything I may need to reach should be reachable without dismantling.
- Do not rush the return of stock. The biological side needs time to settle after a rebuild.
- Record the dimensions as I build, not afterward. Memory is unreliable.
- Keep the temporary fish housing in a quiet, shaded, stable place.
- Protect timber from humidity during storage, or it will warp before it is used.

A lesson I keep relearning: the plan is only as good as the checkpoints in it. Without them, small errors stack up unseen.

## Open questions

Questions I have not settled yet:

- How much of the old structure is really reusable once it is stripped?
- Will the old grow beds hold, or does the liner need replacing?
- Is the current pump the right size for the rebuilt layout, or does the height change require another?
- How long can the fish safely stay in temporary housing at the expected temperature?
- Can the solar option supply enough power to be worth installing, or should it stay a backup?
- Is there enough dry storage for the timber, or will the dehumidifier need to run longer than planned?
- Who can help on the day the heavy beds go back in place?
- What is the smallest set of water checks that still tells me the system is healthy?

I will move each of these to Lessons once answered.

## History

The Fartark system is an aquaponics setup in which fish and plants share one water circuit. Over time the structure aged. Wood softened where it stayed damp, fittings corroded, and a few joints moved enough to cause worry. That wear is what led to the decision to rebuild.

Key points in the history of this project:

- The project is named Fartark rebuild, and its goal is a rebuild.
- The work was set to begin in spring of 2021.
- The carpenter was named lead early, because the structure was the main problem.
- The workshop was planned in [[Nizi workshop plan]] so the building work could happen in a sensible space.
- Equipment choices, such as the [[Turen band saw]], were made with the timber work in mind.

I have kept this short on purpose. The history matters only because it explains why the project is a rebuild and not a repair: the structure had reached a point where patching it would cost more than starting the frame again.

## Budget

The budget for the Fartark rebuild is 16953.45 EUR.

How I treat that figure:

- It is the ceiling, not a target. I would be happy to finish under it.
- It covers structure, water system, power and consumables, and stock losses.
- It does not include my own time.
- I check the running total at each checkpoint in the schedule.
- Anything that pushes the total over needs a saving found elsewhere first.

Success is measured partly by this figure. If the rebuild is finished, tested and running within the budget, that is a good result. If it is finished but over budget, I note where the money went and what I would do differently.

The other measures of success are listed in the Checklist: level beds, no leaks, a working pump, and healthy fish and plants after they return.

## Background

Aquaponics joins fish keeping and plant growing. Fish waste feeds bacteria, the bacteria turn it into nutrients, and plants take up those nutrients and clean the water before it returns to the fish. The system depends on steady water flow, steady temperature and a stable biological balance.

For a rebuild this has practical consequences:

- The structure must carry the weight of full water tanks and beds without moving.
- Everything touching the water must be safe for fish.
- Pumps and air supply cannot be off for long without risk to the stock.
- The beneficial bacteria live on surfaces and in the media, so I avoid scrubbing them away or using harsh cleaners.

The carpenter's lead role fits this. A system that holds this much water is heavy, and a weak frame is the most dangerous failure. A good frame also makes the other work easier, because the plumbing and beds are laid out against something true and level.

The area is aquaponics, the season is spring, and the project started in 2021. Spring suits the work because the system is naturally restarting then, so the rebuild lines up with the biology instead of fighting it.

## Observations

Notes from looking at the system and from planning, kept as simple statements:

- The weakest points are where wood meets water for long periods.
- Fittings near the pump show the most corrosion.
- The beds are heavy enough that a slightly weak support shows up quickly as sag.
- Storage conditions matter: damp air will undo good timber before it is used.
- The workshop layout affects how easily long pieces can be handled.
- Power is the quiet risk. A pump stopping for a few hours can matter more than a late delivery.
- A second opinion on the design is valuable. [[Drarktend Sunnarzio]] has a good eye for this kind of structure.

What I will watch during the work:

- Whether any frame member twists after cutting.
- Whether sealed surfaces stay sealed after the first fill.
- Whether the water settles quickly or stays cloudy.
- Whether the fish feed normally after they return.

If any of these go wrong, I stop and fix the cause before going on.

## Setup

How I intend to set things up before the main work starts, so that the project runs smoothly once it begins.

Workspace:

- Lay out the workshop following [[Nizi workshop plan]], with timber entering at one end and finished parts leaving at the other.
- Set the [[Turen band saw]] where long pieces can feed through without hitting a wall.
- Keep a clear, dry area for stacking timber, with the [[Kathses dehumidifier]] running if the air is damp.

Temporary housing:

- Prepare a tub or tank in a shaded, stable place for the fish before draining anything.
- Set up aeration there so the stock has oxygen from the first minute.
- Keep plants somewhere bright but not harsh, and keep them damp.

Records:

- Start a simple log for purchases, dimensions and water checks.
- Take photos of the old layout before stripping anything.
- Keep this drivers note open as the reference for goal, constraints, budget and success measures.

Power:

- Decide whether the pump runs from the mains only, or whether part of the load moves to the plan in [[Kuglend solar charger plan]].

Once the setup is done, the build follows the schedule in order, with the checklist as the measure of progress.
