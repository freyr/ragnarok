---
type: summary
status: active
project: fartark-rebuild
area: aquaponics
---

# Summary of Fartark rebuild

## Schedule

The Fartark rebuild is a project in the aquaponics area. The goal is a rebuild. It started in 2021, in spring, and the lead is the carpenter. Those are the basic properties, and I keep them here so I do not have to look them up in the frontmatter each time.

The project has not run in a straight line. The spring start in 2021 was chosen because the water is cold then and the fish are slow, so the system can be opened up without much stress on the stock. Since then the work has come in bursts. Each spring the carpenter has had a window to do the heavy work, and the rest of the year goes to smaller jobs and waiting.

Stage right now: the rebuild is past the planning stage and in the middle of the build stage. The main frame work is done. The plumbing and the final fit-out are not. I think of the stage as "structure finished, systems still open."

What the schedule looks like in practice:

- Spring: the heavy carpentry. This is when the lead does the frame, the bed supports and the tank stand. It is also when the system is drained and moved, if it has to be.
- Summer: planting and watching. Nothing structural is touched, because the plants are growing and the fish are active.
- Autumn: tidying up, small fixes, and writing notes like this one.
- Winter: planning, ordering, and thinking about what went wrong.

I try not to promise dates that I cannot keep. The one fixed point is the go decision, which is recorded under Decisions. Everything after that depends on the weather in spring and on the carpenter's time.

A rough order of work, kept as a checklist in my head:

1. Confirm the frame is square and level.
2. Fit the bed supports and check them under a full load of water.
3. Set the tank stand and test it the same way.
4. Run the plumbing and test it with clean water only.
5. Cycle the system before any fish go in.
6. Add the plants and fish slowly.

I am at the point between step two and step three. The frame is good. The load test on the supports was done. The stand is next to be confirmed.

## Setup

The Fartark rebuild is an aquaponics system: fish in tanks, plants in beds, water moving between them. The rebuild means taking the old layout apart and putting it back in a better form, not building something new from nothing. The carpenter leads because most of the problems in the old version were structural.

What the setup consists of now:

- A new timber frame that carries the grow beds. It is built heavier than the old one, because the old one sagged once the beds were full.
- Bed supports that spread the load across more of the frame. Water is heavy, and a full bed is heavier than it looks.
- A tank stand that is separate from the bed frame. I wanted the two to move independently, so that a problem with one does not twist the other.
- Plumbing runs that are planned but only partly installed. The routes are marked, and the main drain path is clear.
- A pump position chosen to be easy to reach, so that servicing does not mean lifting anything out of the way.

The reasoning behind the layout is simple. In the old system, every repair meant moving something else first. In the rebuild, I want each part to be reachable on its own. That is the main design rule, and I check each decision against it.

What is finished:

- The frame is built and has been checked for level.
- The bed supports are fitted and have been tested under load.
- The working space around the system has been cleared and kept clear.
- The plan for the plumbing routes is drawn and agreed with the carpenter.

What is not finished:

- The tank stand has not had its final check.
- The plumbing is not run end to end.
- The system has not been cycled, so there is no biological activity yet.
- No fish or plants have been moved back in.

I keep these two lists short and honest. If something is half done, it goes on the not-finished list.

A note on materials. I chose timber that is treated for wet use and sealed the cut ends, because cut ends are where moisture gets in first. Anything that touches water directly is food-safe. Anything that only sits near water is just well sealed. I do not mix the two groups up.

## Open questions

These are the points I have not settled. I write them down so they do not get lost over winter.

- Is the tank stand strong enough for the planned volume with some margin, or should it get extra bracing? The carpenter thinks it is fine. I would like to see it tested before I believe it.
- Should the drain path be one large line or two smaller ones? One is simpler. Two gives a backup if one blocks.
- Where should the overflow go if the pump fails? The current idea is a catch point that can be seen easily, but I have not confirmed the position.
- How much of the old plumbing is worth reusing? Some is in good shape, but some has been in place a long time and I do not trust it.
- Can the cycling start before the plumbing is fully finished, using a temporary loop? It would save time, but it adds a second thing to manage.
- What is the right order for returning fish and plants? I lean toward plants first, then a small number of fish, but I want to read my own old notes before deciding.
- Is the working height of the beds comfortable for long sessions? I tested it with a short visit only.

I do not try to answer all of these at once. The first one blocks the most, so it comes first. The rest can wait until that is resolved.

Some of these questions will probably answer themselves once the stand is tested. If the stand passes with room to spare, the bracing question disappears. If it flexes, the whole layout of the plumbing may have to shift slightly, and then the drain question and the overflow question change too. That is why I do not spend time on the later ones yet.

## Next action

The next action is NX-2928.

It is the job that comes before everything else on the list. Until it is done, the open questions about the stand and the plumbing cannot be properly answered. I do not plan anything beyond it in detail, because what comes after depends on how it turns out.

How I approach it:

- Set aside a clear block of time, not a spare half hour.
- Have the carpenter present, since the lead should see the result first-hand.
- Write down what happened straight afterwards, while it is still fresh.
- Update this note, including the stage and the open questions.

If the result is good, the project moves on to the plumbing. If not, I fix what is wrong and repeat. I do not skip ahead.

## Background

The Fartark rebuild came out of the old system wearing out. The first version was put together quickly, with the idea of improving it later. Later came, and by then it had a list of faults: a sagging bed frame, plumbing that was hard to reach, and a layout where nothing could be serviced alone.

I decided on a rebuild rather than a repair because the faults were connected. Fixing the frame meant moving the beds. Moving the beds meant touching the plumbing. Touching the plumbing meant draining the tanks. Once I looked at it that way, doing it piece by piece would have meant doing the same work several times.

The project belongs to the aquaponics area. That matters because it shapes the rules. Fish and plants share the same water, so anything I do to help one can hurt the other. Materials have to be safe for both. Timing has to suit both. And a failure in one part can spread to the rest.

The start year is 2021, and the season is spring. Spring was chosen because it is the gentlest time to disturb the system, and because the carpenter is most available then. The goal, a rebuild, has not changed since the start. What has changed is my understanding of how long it takes. I first thought one season would be enough. It is now clear that the work spreads over several.

The lead is the carpenter. This was an easy choice, because the main problems are about wood, load and fit. I am the one who keeps the notes and makes the decisions about the system, but the structural work is the carpenter's to run.

## Lessons

These are the things I have learned so far, written plainly.

- Water is heavy. Everything that holds it needs to be stronger than my first guess, and then a bit more.
- Test under load before building on top. A support that looks fine empty can fail when full.
- Keep parts independent. If the stand and the beds are separate, one problem does not become two.
- Make every part reachable. A good design is one where servicing does not need a lot of lifting and moving.
- Seal cut ends on timber. Moisture finds them first.
- Do not rush the cycling. The biology takes the time it takes.
- Write things down the same day. My memory of why I chose something is much worse after a month.
- Do not promise dates to myself that depend on weather and on another person's time.
- Short lists of what is done and not done are more useful than long descriptions.
- Do not trust old parts because they look fine. Check first.

Some of these I knew already and ignored. Others I only learned by getting it wrong. The one about reachability is the one I would repeat to anyone starting out.

## History

2021, spring: the project began. The old system was taken apart in part, and the first plans for the new frame were drawn. The early work was mostly measuring and clearing.

After the start, progress came in seasonal bursts. Each spring the heavy carpentry moved forward. Each summer it paused for the plants. Autumn and winter were for planning and small repairs.

Over the years the design changed in a few important ways. The frame got heavier. The tank stand became separate from the bed frame. The plumbing plan was redrawn more than once, mostly to make it easier to reach. Early versions were tidy on paper but hard to service, and I rejected them.

The frame was finished and checked. The bed supports were fitted and load tested. These two steps took longer than I expected, mainly because I kept finding small things to adjust.

At present the project is in the middle of the build, with the stand and the plumbing still ahead. The go decision for the current phase is recorded under Decisions.

## Problems

These are the problems I have run into, and what I did about them.

- The old frame sagged. This was the original reason for the rebuild. The answer was a heavier frame and better supports.
- Plumbing was hard to reach. The answer was to redesign the runs so that each can be serviced alone.
- Some old fittings were of doubtful quality. I decided to check each one rather than reuse them all.
- Time was lost between seasons. Work stopped each summer and restarted slowly. The answer was to keep a short note of exactly where I stopped, so that I could pick up quickly.
- Space around the system filled up with stored items. I now keep it clear, because a crowded working space makes mistakes more likely.
- Some decisions were made verbally and then forgotten. Now they go in this note.

Problems that are still live: the stand has not had its final check, and the plumbing is not finished. They are listed again in Open questions, because they are the same things seen from a different side.

## References

These are the sources I rely on. They are my own records, not outside documents.

- My earlier notes on the old system, which show what failed and when.
- The drawings of the frame and the plumbing routes, which I keep with the project.
- The carpenter's own list of measurements and cuts.
- My notes from previous seasons on cycling and on the order of returning plants and fish.
- The other notes in my knowledge base about aquaponics in general, which cover water quality, fish stocking and plant choice.

I do not copy details from these here. This note is a summary, and the sources are where the detail lives. If a detail matters, I go back to the source.

## Maintenance

Once the rebuild is finished, the system needs regular care. I plan for it now, since the design is meant to make it easy.

- Check the frame and the supports for movement or damp, at least once each season.
- Look at the plumbing joints for slow leaks, especially after a cold spell.
- Clean the pump and its intake on a regular schedule, and keep the position clear so it is simple.
- Check the overflow path is open, since it matters most when something else has gone wrong.
- Inspect the sealed ends of the timber and reseal where the coating has worn.
- Keep the working area clear.
- Write a short note after each check, even if nothing was found.

The point of the reachable design is that none of this should be a big job. If a task is hard to do, that is a sign the design needs changing, and I note it.

## Safety

Safety matters here because of water, weight and electricity in the same place.

- Never work on the pump or any electrical item while it is plugged in. Isolate the power first.
- Keep electrical connections high and away from water, with protection suited to wet areas.
- Do not stand under a loaded bed or stand until it has passed its test.
- Fill and test in stages, so that a failure releases a small amount of water, not all of it.
- Keep the floor clear and dry. Wet floors and tools are a poor mix.
- Wear gloves and wash hands after handling system water, as it can carry bacteria.
- Lift with care. Parts of the frame are heavy and awkward.
- Do not work alone on the heavy steps. The carpenter or someone else should be present.

I treat these as fixed rules, not suggestions. The load test in particular is as much a safety step as a design step.

## Tools

The tools I use are ordinary ones, and most belong to the carpenter.

- Measuring tape, a long level and a square, for checking the frame.
- Saws, drills and drivers for the timber work.
- Clamps, because there is never enough hands.
- Sealant and a brush for the cut ends.
- Pipe cutters and fittings tools for the plumbing.
- A bucket and sponges, for the spills that will happen.
- A notebook, or this note, for writing things down straight away.
- A water test kit, for when cycling begins.

I keep the tools together in one place near the work, and put them back after each session. This sounds minor, but it saves a lot of time and avoids the loss of small items into the system.

## Decisions

The go decision date of the Fartark rebuild is 2026-05-26. That was the day I decided the current phase would go ahead, once the frame and supports were far enough along to trust.

Other decisions I have made and kept:

- Rebuild rather than repair, because the faults were linked.
- Carpenter as lead, because the main problems are structural.
- Spring as the main work season, for the sake of the fish and the carpenter's availability.
- Stand separate from the bed frame, so that the two can move independently.
- Every part must be reachable on its own, as the main design rule.
- Test under load before building on top.
- Check old fittings before reuse, not assume they are fine.
- Cycle the system fully before any fish return.

Decisions still to make are listed under Open questions. I do not treat them as decided until they are written here.

## Risks

These are the risks I see for the project, with how I try to manage each.

- Structural failure under load. Managed by testing in stages, with margin, and by keeping people clear during tests.
- A leak during filling or testing. Managed by filling slowly and by using clean water only at first.
- Pump failure. Managed by a visible overflow path and by keeping the pump easy to reach.
- Loss of fish during the return. Managed by cycling first and adding stock slowly.
- Delay from weather or from the carpenter's time. Managed by not fixing dates that depend on either, and by keeping the notes current so that restarts are quick.
- Poor material choice, such as timber that rots or fittings that fail. Managed by sealing, by choosing materials for wet use, and by checking old parts.
- Losing track of decisions. Managed by writing them here.
- Losing momentum over the quiet seasons. Managed by a clear note of where I stopped and by keeping the next action obvious.

The biggest risk is probably rushing. The project has gone slowly and been better for it. If I feel pushed to skip a test, I should treat that as a warning, not a reason.
