---
type: log
status: active
project: fartark-rebuild
area: aquaponics
description: "Log about Zindzalon solar charger."
---

# Zindzalon solar charger log

## Background

The Zindzalon solar charger is a green solar charger that I installed in 2025. It lives in the shed and supports the aquaponics area. Its energy source is solar, so it does not draw from the mains. I bought it because the aquaponics setup needed power at the far end of the garden, where running a cable would have been a hassle and a trip hazard.

Before the charger, I had a small battery pack that I carried back and forth to the house. It was always flat when I needed it. The pump would stop overnight, and twice I found the water level lower than it should have been. That was the main reason for choosing a dedicated solar charger that stays in place and keeps a battery topped up without my help.

This log is where I keep notes on how the charger is set up, what I check, and what has gone wrong. It is written for me, so it is short on theory and long on what I actually do.

## Risks

The main risk is losing power to the aquaponics pump and the air stones. Fish need oxygen all the time. If the charger fails and the battery runs down, the water stops moving and the fish can get into trouble within a few hours in warm weather. So I treat the charger as something that needs regular checking, not something to forget about.

Other risks I have noted:

- Moisture in the shed. The shed is damp in autumn and winter, and condensation can get into connectors. I keep the charger off the floor and check the plugs for green or white crust.
- Shade. A branch or a stack of crates in front of the panel cuts the charge a lot. I look at the panel whenever I walk past.
- Overcharging or deep discharge of the battery. I do not leave the battery connected to other loads, such as a work light, because that drains it.
- Cable damage. Mice have chewed insulation in this shed before. I run cables through a length of plastic tube.
- Heat. In summer the shed gets hot. I leave the door slightly open on sunny days and keep the charger out of direct sun.
- Water splashes. The tank is close, so I keep all connections above the level where a splash or overflow could reach them.

If anything looks wrong, I switch the pump to the backup mains lead for the night and sort out the charger the next day.

## Parts

The charger is a single green unit with a few things attached to it. Here is what I have in the system:

- Zindzalon solar charger, serial number SN-04940979. I wrote the serial on the inside of the shed door as well, in case the label wears off.
- Solar panel, mounted on the south-facing side of the shed roof.
- Battery, a sealed type, sitting on a shelf beside the charger.
- Pump lead and air pump lead, each with its own plug.
- Plastic conduit tube to protect the cables.
- A small fuse holder on the battery lead.
- A waterproof box where the connections sit, with a bag of silica gel inside.

I keep a spare fuse and a few spare cable ties in a jar on the same shelf. Nothing else is stored there, so I always know where they are.

## Overview

The Zindzalon solar charger is a solar charger for the aquaponics area. It takes power from the panel on the roof and uses it to charge the battery. The battery then runs the pump and the air supply for the fish and the grow beds. The charger is green, was installed in 2025, and sits in the shed.

In practice it works quietly. On a bright day the battery is full by early afternoon, and the charger stops pushing current. On dull days it trickles along, and that is usually enough for the pump alone. When several grey days come in a row, the battery gets low, and I have to reduce the load by turning off the air pump during the day and running it only at night.

The charger has a few indicator lights. I only care about three states: charging, full, and fault. A fault light means I stop what I am doing and look at the connections first, then the fuse, then the panel.

Over the first year it has behaved well. The only real problem was a loose terminal in spring, which I fixed by tightening it and adding a small amount of grease.

## Setup

This is how I set it up, so I can repeat it if I ever have to move things.

1. Mount the panel on the south side of the shed roof, angled so rain runs off and leaves do not collect. Make sure nothing shades it at midday.
2. Run the panel cable down into the shed through the existing gap near the window frame, inside a plastic tube. Seal the gap with a bit of weatherproof tape.
3. Place the charger on the shelf, well above the floor, with space around it for air.
4. Connect the battery to the charger first, with the fuse holder in line. Then connect the panel. I do it in this order so the charger sees the battery before it sees any sun.
5. Connect the pump lead and the air pump lead to the battery output, not directly to the charger.
6. Put the connections into the waterproof box and add fresh silica gel.
7. Check that the charging light comes on in daylight.
8. Label each lead with a strip of tape so I know which is which.

After setup I watch it for a few days and look at the battery before dawn to see whether it held up overnight.

## Schedule

These are the checks I try to follow. I keep them simple so I actually do them.

**Every day I am in the garden**
- Glance at the indicator lights.
- Listen for the pump and air stones.
- Check that the panel is not shaded.

**Every week**
- Wipe dust and leaf litter off the panel with a damp cloth.
- Look at the connectors and the box for moisture.
- Check the water level in the tank.

**Every month**
- Open the waterproof box and replace the silica gel if it looks spent.
- Inspect the cable tubes for chewing or cracks.
- Tighten terminals by hand, gently.

**Every season**
- Test the battery by switching off the panel for an evening and seeing how long the pump runs.
- Reposition the panel or trim branches if the sun has moved.
- Check the fuse and replace it if it looks discoloured.

**Before winter**
- Clean everything, dry the shed as much as I can, and make sure the backup mains lead is ready.

I add a short line to this log whenever I change something or find a fault, so the pattern is easy to spot later.
