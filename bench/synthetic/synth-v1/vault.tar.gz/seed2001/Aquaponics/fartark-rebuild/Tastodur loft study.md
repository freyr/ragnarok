---
type: research
status: active
project: fartark-rebuild
area: aquaponics
---

# Tastodur loft study

## Lessons

The first thing I learned about the Tastodur loft is that its size sets the tone for everything else. It is a large loft, and a large space in an aquaponics setting behaves differently from a small one. Water volume is bigger, the plant beds are longer, and any mistake travels further before I notice it. I now plan every change as if it will take twice as long as I expect, because walking the length of the loft alone eats a good part of a work session.

The second lesson is about the raised floor. The loft sits on a raised floor, and that has both good and bad sides. The good side is that air can move under the structure, which keeps the floor from staying damp for long after a small spill. The bad side is that every leak is harder to see. Water can run along a joist and drip somewhere far from where it started. I learned to check for wet spots at the edges and below the floor line, not only where the tanks and grow beds stand. A dry surface above does not prove a dry structure below.

The third lesson comes from the orientation. The loft faces west, so the strongest light arrives in the afternoon and evening. In the morning the plants get gentle light, and by late afternoon the same spot can run hot. I stopped treating the whole loft as one climate. The west end warms up first in the afternoon, and the water in the beds nearest the glass follows. Leafy plants there wilt earlier in the day than the ones further in. I now place the tougher plants on the west side and keep the delicate ones back from the glass.

The fourth lesson is about age. The loft was built in 1999, and it shows in small ways. Nothing is broken, but fittings have been replaced over time, and not always with matching parts. When I trace a pipe, I cannot assume it is the same material along its whole length. I write down what I find each time I open something up, because the next repair will go faster with a record than with my memory. A loft from 1999 has had many hands on it, and I treat its layout as something to confirm rather than something to trust.

The fifth lesson is that aquaponics punishes patience in the wrong places. Fish and plants run on a slow balance. If I change too many things at once, I cannot tell which change caused the result. So I change one thing, wait, watch, and then write it down. This is dull, but it has saved me more than once from chasing a problem that I created myself.

A few smaller lessons are worth keeping:

- Keep a towel, a bucket and a flashlight in a fixed place near the entrance. I need them most when I am in a hurry.
- Label every valve in plain words. Memory fails at the worst time.
- Walk the whole loft at the same time each day. Patterns appear only when the check is regular.
- Do not trust a single sensor. Compare it with what I can see and smell.
- Write the date next to every note about a fault, even when it seems minor.

## Maintenance

Maintenance in the Tastodur loft is a routine, not a project. The loft is large, so I split the work into short passes that cover one zone at a time. I do not try to do everything in one day. A tired pass that skips half the loft is worse than a short pass that is done properly.

### Daily checks

Each day I walk the loft from the entrance to the west end and look at the same things in the same order. I check that the pumps are running and that water is moving where it should. I look at the fish for normal behaviour at feeding time. I look at the plant leaves for colour and droop. I listen for changes in pump sound, because a pump that has started to struggle usually sounds different before it fails.

Because the loft faces west, I do one extra look in the late afternoon. That is when the glass side gets the most sun, and it is when I see stress on the plants and warmth in the water first. If the beds near the west end look tired, I adjust shading or move plants the next morning, not in the heat of the moment.

### Weekly checks

Once a week I clean the places that collect residue: filter screens, the inlets of pumps, and the edges of grow beds where algae likes to start. I wipe down surfaces that stay damp. I also check the floor in a slower way than I do daily. Since the floor is raised, I look along the edges and, where I can, underneath, for drips, stains or soft spots. I press gently on suspicious boards. A floor that feels different underfoot is a warning I do not ignore.

I also test the water on a fixed day, and I write down the results next to the date. The numbers matter less than the trend. A slow drift tells me more than one odd reading.

### Seasonal work

Twice a year I do a longer pass. This is when I look at the things the loft's age makes me careful about. The building dates from 1999, so I inspect fittings, clamps and supports for wear, and I replace anything that looks tired before it fails. I check that old pipe joins are still tight. I check that the supports under heavy tanks are sound, because a large loft carries a lot of weight in water.

In the warm part of the year I focus on heat and light. I clean the glass so that light is even, and I check that shading is ready for the strong western afternoons. In the cool part of the year I focus on keeping the water stable and on drafts near the entrance and the west wall.

### Keeping records

I keep a plain log. Each entry has a date, what I did, and what I saw. I do not write long text. A line or two is enough. Over time the log has become the most useful tool I own for this place, because it tells me what normal looks like. When something goes wrong, I read back a few weeks and usually find the first small sign.

### Things I avoid

- I avoid opening several systems at once. If something goes wrong, I want to know where it started.
- I avoid leaving tools on the raised floor near the edge, where they can slip into gaps.
- I avoid working in the loft in the hottest part of a west-facing afternoon unless it is an emergency.
- I avoid replacing parts without writing down what I removed.

## Overview

This note collects what I know about the Tastodur loft. It is a research note, so I try to keep the facts separate from my opinions and to say clearly what I have seen myself.

The subject is a loft, and its area of use is aquaponics. That means the space is given over to keeping fish and growing plants in one connected system, where the water from the fish feeds the plants and the plants help clean the water. The loft is large. It was built in 1999. It has a raised floor, and it faces west.

Each of these properties matters in daily work, and I find it useful to state them one by one:

- **Kind:** loft
- **Area:** aquaponics
- **Orientation:** west
- **Size:** large
- **Year built:** 1999
- **Floor:** raised

The large size means there is room for several beds and tanks, and also that the work is spread out. The west orientation means the light and heat peak late in the day. The year of construction, 1999, tells me to expect older fittings and a layout that has been changed over time. The raised floor affects how water, air and weight behave in the space, and it is the first thing I think about when I look for a leak.

I wrote this study to give myself a reference. When I return to the loft after a break, or when I plan a change, I want one place that tells me what the building is like and what I have already learned. The lessons and the maintenance routine above come from ordinary use, not from any formal test. They are practical habits, and I will adjust them as I learn more.

The remaining parts of this note go into more detail on the layout, the systems, and the history of the loft. For now, the main point is simple: the Tastodur loft is a large, west-facing, raised-floor aquaponics loft from 1999, and it rewards regular, careful attention.

## History

The Tastodur loft was built in 1999. It is a large loft with a raised floor, and its main windows face west. From the start it was set up for aquaponics, which means the building was planned around tanks, grow beds and the pipes between them rather than being converted later. I treat that as the key fact of its history. Most of what happened afterwards follows from a building that was made for wet work.

The raised floor is the feature I notice most when I read old accounts of the place. The builders lifted the working level above the ground so that water lines could run underneath and drain by gravity. That choice made the loft easier to maintain in some ways and harder in others. Pipes are reachable from below, but anything that leaks under the boards can go unnoticed for a long time.

The west orientation was probably chosen for afternoon and evening light. In an aquaponics loft that is a mixed blessing. Plants get strong light late in the day, but the same light heats the tanks when the air is already warm. Early users seem to have learned this quickly, because the oldest notes mention shading and moving the tanks away from the glass.

### Early years

In the first years after 1999 the loft ran a simple layout: a row of fish tanks along the inner wall, grow beds along the west side, and a sump at the lowest point of the raised floor. The routine was plain. Feed the fish, check the water, harvest greens, clean the filters. Not much was written down, and what exists is mostly short practical remarks about what failed.

Common early problems were these:

- Water temperature swinging between day and night.
- Algae in the grow beds where light was strongest.
- Pumps clogging with solids from the tanks.
- Condensation on the glass and on the underside of the roof.

None of these was dramatic. They did teach the early users that the loft needs steady attention more than clever design.

### Middle period

As the loft aged, the work shifted from getting things to grow toward keeping the building sound. Moisture is the main driver. A large space with constant water and warm air will wear out its materials, and a raised floor gives that moisture a place to hide. Boards swelled, fasteners rusted, and seals around pipe passages dried and cracked. Repairs were done piece by piece, and I suspect that some of them were never recorded.

The size of the loft also mattered. A large space is hard to keep at an even temperature, and the west side always behaved differently from the east. Users learned to treat the two ends almost as separate zones, with separate habits for watering, ventilation and inspection.

### What the history tells me

Reading the whole record together, I come away with three working conclusions:

1. The loft was designed for aquaponics, so its structure tolerates water better than an ordinary loft, but not without limit.
2. The raised floor is both an asset and a hiding place for faults.
3. The west orientation shapes the daily rhythm, with heat and light peaking late.

I keep these in mind when I look at the risks below, because most of them are slow versions of problems that already showed up in the early years.

## Risks

The risks here are the ones I think matter most for a large, raised, west-facing aquaponics loft built in 1999. I have grouped them by cause so I can check them one at a time.

### Water and structure

Water is the first risk, and the raised floor makes it harder to see. A slow leak from a tank, a fitting or a drain can soak the boards from below. Because the floor is lifted, the damage may show only when a board softens or a section sags. I would rather inspect under the floor on a schedule than wait for a visible sign.

The age of the building adds to this. A loft from 1999 has had many years of damp air. Wood, metal brackets and old seals all wear out. I should assume that anything hidden under the floor is older and weaker than it looks from above.

Weight is a related concern. Full tanks and wet grow beds are heavy, and a large loft invites more of them over time. A raised floor has a load limit, and I do not know the exact figure, so I treat it as unknown and avoid adding heavy tanks without checking the supports first.

### Heat and light

The west orientation brings strong late sun. The risks are:

- Tanks overheating on warm afternoons, which stresses the fish and lowers the oxygen in the water.
- Leaf scorch on plants closest to the glass.
- Fast algae growth in sunlit channels and beds.
- Uneven temperatures between the west and east ends.

Shading is the simple answer, but shading brings its own trouble, since it can cut light for plants further in. I try to balance it by watching the plants and the water temperature together rather than following a fixed rule.

### Power and pumps

An aquaponics system depends on moving water and air. If the pumps or aerators stop, the fish are at risk within hours, especially in a warm tank. A large loft probably has several pumps, and each one is a point of failure. Power cuts, tripped breakers and clogged intakes are the likely causes.

I note these weak points:

- A single pump feeding many beds.
- Cables and sockets close to water.
- No backup air supply for the fish tanks.
- Filters that are hard to reach from the raised floor.

### Biology

Fish disease, plant disease and unbalanced water chemistry are ordinary risks in any aquaponics setup. In a large loft the volume of water is bigger, so a problem spreads further before anyone notices it. Equally, a large volume changes slowly, which gives a little more time to react if I am checking regularly.

Pests are a separate matter. Warm, damp air attracts insects and sometimes rodents looking for fish feed. The raised floor gives them a sheltered route, so gaps around pipes and walls deserve attention.

### Humidity and air

Constant evaporation raises the humidity in the loft. The effects are condensation, mold on surfaces, rust on metal, and a general feeling of heaviness in the air. Mold is a health concern as well as a maintenance one. Ventilation helps, but opening windows on the west side in the afternoon also lets in more heat, so the choice is not always simple.

### Ranking

If I had to rank the risks by how much harm they could do, I would put them in this order:

1. Pump or power failure, because the consequences are fast.
2. Hidden water damage under the raised floor, because the consequences are slow but costly.
3. Heat in the tanks from the west sun.
4. Mold and humidity.
5. Pests and disease.

This order is my own judgment, not a measurement. I would revise it if an inspection turned up something worse.

## Safety

Safety in the Tastodur loft comes down to three things: water, electricity and the floor. I keep the rules short so that I actually follow them.

### Electricity near water

This is the most serious hazard. Water and mains power are always close together in an aquaponics loft. My rules:

- Keep all sockets and plugs off the floor and away from splashes.
- Use protected circuits that cut the power quickly if there is a fault.
- Never touch a pump or heater with wet hands while it is connected.
- Switch off the power before working in or near a tank.
- Check cables for cracks and chewing damage on a regular basis.

If I find a damaged cable, I leave it disconnected until it is replaced. I do not tape it and carry on.

### The raised floor

A raised floor can hide soft boards. Before walking across an area I have not used recently, I look for sagging, dark stains or spongy spots. Wet boards are also slippery. I wear shoes with a good grip and avoid carrying heavy loads over any section I have doubts about.

If I need to open the floor to reach pipes, I mark the opening clearly and close it again when I am done. An open hatch in a large loft is an easy thing to step into, especially in the evening light from the west windows when glare hides the edge.

### Slips and falls

Water on the floor is the commonest cause of accidents here. I wipe up spills at once and keep walkways clear of hoses and buckets. Because the loft is large, I try to keep one clear route from the entrance to the main work areas, and I do not leave tools on it.

### Air quality and mold

Mold spores and damp air can irritate the lungs. When I clean visibly moldy surfaces, I wear a mask and gloves, and I ventilate the space first. I do not mix cleaning chemicals, and I keep them away from the tanks, since even small amounts can harm fish and plants.

### Working with fish and water

Handling fish water and plant material means hygiene matters. I wash my hands after any contact with tank water and keep food preparation apart from the growing area. Tools used in the tanks stay in the loft and are not carried into the kitchen.

### Heat

On warm afternoons the west side can become uncomfortable. I avoid doing heavy work there during the hottest hours, drink water, and take breaks in the cooler end of the loft. Heat also affects the fish, so a hot day for me is a day to check the tanks more often.

### Emergencies

I keep a short plan in mind so that I do not have to think in a crisis:

1. If someone is shocked or I suspect a fault, switch off the power at the main control first, then help.
2. If a pump fails, restore water movement or add air to the tanks as quickly as I can.
3. If a major leak starts, shut off the supply, switch off nearby equipment, and move people away from wet areas.
4. If the floor looks unsafe, stop work in that area and mark it off.

I also keep a torch, a first aid kit and a clear path to the exit near the entrance. In a large loft it is easy to be far from help, so I try not to work alone on risky jobs, and I tell someone when I am going to be in the loft for a long time.

### Routine checks

A simple routine reduces most of these hazards:

- Look under the raised floor for leaks and damp.
- Test the protective circuits.
- Inspect cables, sockets and pump housings.
- Clear walkways and wipe up water.
- Check the tank temperature in the afternoon.
- Make sure the exit and emergency supplies are accessible.

I do this often enough that it becomes habit. For a loft of this age, with a raised floor, a west aspect and a working aquaponics system, regular small checks are the most practical way to stay safe.

## Background

The Tastodur loft is a large loft built in 1999. It sits on a raised floor, and its main windows face west. The area of the note is aquaponics, and that shapes almost everything I look at here: water, fish, plants, light, and the weight of all of it on the floor.

I keep this part of the study short on history and long on what matters for practical work. The loft is a working space, not a showpiece. Anything I write down should help me decide what to bring, what to check, and what to leave alone.

**Why the raised floor matters.** A raised floor means there is a void or a structure under the boards. In an aquaponics space this has two consequences. First, water is heavy, and a large loft invites large tanks. I should never assume the floor can take a full tank just because the room is big. Second, any leak finds its way down and may not show up for a long time. So I treat the floor as something to watch, not something to trust.

**Why the west orientation matters.** West-facing light arrives late in the day. In the morning the loft is comparatively dim, and in the afternoon and evening it gets strong direct sun. For plants this can be useful, since the grow beds get a long warm stretch of light. For the water it can be a problem, because a tank in the afternoon sun warms up, algae grows faster, and fish get stressed when the temperature swings. I note the pattern here so that later observations about heat and algae make sense.

**Why the size matters.** A large space is easy to fill and hard to keep consistent. Air moves differently at the far end than near the windows. Humidity collects in some corners. Walking distance between the tanks and the beds is longer, which makes small chores slower and makes it more likely that I skip them. I plan the layout so that the things I check every day are close together.

**Why the year matters.** A building from 1999 is not ancient, but it is old enough that I do not assume modern standards for wiring, damp protection, or load. Sockets near water need extra thought. I check what is actually installed rather than what I expect.

**What I am trying to learn.** The study has a few plain questions:

- How much weight can the raised floor realistically carry, and where is it strongest?
- How hot does the west side get on a sunny afternoon, and how fast does the water follow?
- Where does moisture collect, and does any of it reach the floor structure?
- Is the electrical supply good enough for pumps, heaters, and lights running together?
- Can I walk the whole system in a reasonable time during a daily round?

I do not have final answers yet. This note collects the method and the checks so that I can repeat them, and so that I can compare one season with another.

## Tools

I keep the tool list small. Most of the useful measurements need only a few simple things, and I would rather have a tool I actually carry than a better one left in a drawer.

**For the floor and structure**

- A long spirit level, to see whether the raised floor slopes or sags under load. I lay it across the boards in several places and note the gap.
- A tape measure, for the span between supports and for the distance from tanks to walls.
- A small torch and a mirror on a stick, for looking under edges and into any gap where I can see the void.
- A notebook page with a rough floor plan, where I mark soft spots, creaks, and stains.
- A bathroom scale and a few marked buckets, so I can work out the weight of water per tank instead of guessing.

**For water and fish**

- A liquid test kit for ammonia, nitrite, and nitrate.
- A pH test, either drops or a pen, whichever is working that week.
- A floating thermometer in each tank, since the west sun makes temperature the main risk.
- A small net and a lidded bucket for moving fish when needed.
- A clean jug for topping up, kept separate from every other container.

**For light, air, and damp**

- A basic thermometer and humidity gauge, moved between the window end and the far end of the loft.
- A light meter app on my phone. It is crude, but it shows the difference between morning and late afternoon well enough.
- Cloth or paper towels, pressed on suspect spots, as a very cheap way to detect damp.
- Shade cloth, kept folded near the west windows, ready to hang when the afternoon sun gets harsh.

**For electrics**

- A mains tester for sockets, to confirm that they are wired correctly.
- A timer for each light and pump, labelled with what it controls.
- A power strip that is rated for damp areas, mounted off the floor.
- A torch that does not depend on the mains, because a power cut also stops the pumps.

**For records**

- A waterproof pen and a clipboard hung near the door.
- A phone camera. I photograph the same angles each visit so I can compare changes in stains, algae, and plant growth.
- A single running log, with date, observation, and action on each line.

**Notes on how I use them**

I measure at the same time of day whenever I can. Because the loft faces west, a reading at midday and a reading at the end of the afternoon can differ a lot, and a comparison between them is worthless. I usually take one set in the morning and one in the late afternoon.

I also try to measure the same spots. I mark them with small pieces of tape on the floor or wall. This sounds fussy, but it cuts out a lot of noise.

I do not trust a single reading. If something looks odd, I repeat it after a few minutes. If it is still odd, I write it in the log and check again the next day.

## Checklist

This is the list I run through on a visit. I split it into a quick daily round and a slower periodic round. Each item is short enough that I can tick it without thinking.

**Daily round**

- Look at the fish before anything else. Are they feeding, spread out, and swimming normally?
- Read the thermometer in each tank and write the number down.
- Listen for the pumps. Any change in sound is worth a closer look.
- Check that water is moving through the beds and that no pipe is blocked or dripping.
- Look at the floor around each tank for wet patches.
- Glance at the plants for wilting, yellow leaves, or pests.
- Check the west windows: is the afternoon sun hitting a tank directly? If so, hang the shade cloth.
- Confirm that the lights and timers are doing what the labels say.

**Weekly round**

- Run the water tests for ammonia, nitrite, nitrate, and pH, and log the results.
- Top up evaporated water with the clean jug, and note how much was needed.
- Clean the pump intakes and any filters that are clogged.
- Wipe algae from the sides of tanks facing the sun.
- Check the humidity at the far end of the loft and compare it with the window end.
- Press a cloth against the lowest corners and the edges of the floor to detect damp.
- Test the sockets and look at plugs for heat marks or corrosion.
- Walk the whole floor and listen for new creaks or movement.

**Seasonal round**

- Re-measure the floor with the spirit level and compare with the previous marks.
- Review the weight plan: the number of tanks, their volume, and where they stand relative to the supports.
- Take the photographs from the fixed angles and compare them with older ones.
- Check seals, hoses, and fittings for age and cracks.
- Review the shading. In summer the afternoon sun is the main issue; in winter the low light may need to be supplemented.
- Look at the wiring and the power strips again, and ask whether any new equipment has been added since the last review.
- Read through the log and look for patterns: repeated problems, repeated fixes, and anything I keep postponing.

**Before adding anything new**

- Where will it stand, and is that spot over a support?
- How much will it weigh when it is full?
- Does it need power, and is there a safe socket nearby?
- Will it be in the afternoon sun?
- Can I reach it easily on the daily round?
- What happens if it leaks?

**If something goes wrong**

- If a tank leaks, switch off the pumps and nearby power first, then deal with the water.
- If the fish look stressed, test the water and check the temperature before doing anything else.
- If the floor feels soft or looks stained, stop adding weight and write down where it is.
- If a socket is warm or smells hot, switch it off and leave it until it has been checked.
- If the afternoon heat is too much, shade first, then ventilate, and avoid a sudden change in water temperature.

I tick items on the clipboard and copy anything unusual into the running log afterwards. The point of the list is not to be thorough about everything every time, but to make sure the few risks that matter in this loft, namely weight, water, heat, and electricity, get looked at on a regular schedule.

## Setup

This part of the study covers how I set up my visits to the Tastodur loft and what I carried with me. The place is a loft, built in 1999, and it sits on a raised floor. It is a large space, and the main windows face west. The area it belongs to is aquaponics, which is why I keep coming back to it: fish and plants share one water system here, and the layout shows it.

I kept the routine plain so I could repeat it. Each visit followed the same order:

- Arrive in the early afternoon, before the western light gets strong.
- Walk the whole raised floor once without touching anything, just to see what changed since last time.
- Check the tanks first, then the grow beds, then the pipes and pumps.
- Sit near the west windows for a while and write down how the light moves across the beds.
- Leave through the same door I came in by, so the walking path stays the same each time.

Tools were few. I used a small notebook, a pencil, a water test kit, a basic thermometer, a torch for the dark corners under the raised floor, and a tape for rough distances. I did not bring a camera on the first visits, because I wanted to describe things in words before I trusted pictures. Later I added photos, but I still wrote first.

The raised floor shapes everything about the setup. Because the floor is lifted, there is a gap beneath it where pipes run, and some of the plumbing can be reached only by kneeling at an access hatch. I noted where each hatch is so I do not waste time hunting for them. The floor also carries the weight of the tanks, so I stay off the edges and walk along the central line where the boards feel firmest.

Since the loft is large, I split it into zones in my head and used the same names every time:

- The west zone, along the windows, where the light is strongest in the late day.
- The middle zone, where the main fish tanks stand.
- The back zone, which is darker and holds storage and the pump gear.
- The stair end, where the loft opens onto the way down.

I wrote the zone names at the top of each page of the notebook. That made it easy to compare one visit with another, because every observation belonged to a zone.

For the water, I tested in the same spot each time, taking a sample from the middle tank and another from the end of a grow bed. I wrote down the reading, the time, and what the weather was doing outside. I did not trust a single reading. A number only meant something when it sat next to the previous ones.

A last point on setup: I decided early to treat this as a study of a place, not a study of the fish or the plants alone. The building matters as much as what lives in it. A loft from 1999 has its own habits: how it holds heat, how it leaks, how the floor flexes, and how the light comes in through the west side. All of that affects an aquaponics system, so all of it goes into the notes.

## Ideas

These are the ideas I had while working in the loft. Some I have tested, and some are only plans. I keep them here so I can come back and sort them out.

**Use the west light on purpose.** The windows face west, so the loft gets its strongest light late in the day. That light is a resource and a problem. The plants in the west zone like it, but the same light warms the nearby tank. My idea is to put the most light-hungry plants closest to the glass and keep the fish tanks further in, toward the middle zone, where the water stays steadier. If the glare gets too much, a light cloth or screen could soften it without blocking it fully.

**Treat the raised floor as a service space.** The gap under the floor already holds pipes. I would like to tidy it so every line is easy to follow and every valve can be reached from a hatch. A simple labelling scheme would help: one mark for water going to the beds, another for water coming back, and another for air. Right now I rely on memory, and that is a weak system.

**Make the zones real.** I named four zones for my own notes. It might help to make them real with small signs or colored tape on the floor. Then anyone else who visits would read the loft the same way I do. It would also help if something went wrong and I had to describe the place quickly.

**Watch heat more carefully.** A loft is usually the warmest part of a building, and this one is large, so warm air collects overhead. I want to put a thermometer at plant height and another near the water, then compare them across the day. If the gap is big, I might need better airflow, maybe a slow fan near the top of the space or an opened vent on the side away from the sun.

**Plan for the floor's load.** Since the floor is raised, I should not keep adding weight without thinking. Before I place another tank or heavy bed, I want to check where the supports are and spread the load over them. A sketch of the floor with support lines marked would be a good first step.

**Keep a tidy water log.** I already write readings down, but they are scattered across pages. One clean table, one row per visit, would make patterns easier to see. I would add columns for the zone, the weather, and any change I made. That way I can tell whether a shift in the water came from me or from the loft.

**Try a quiet corner for observation.** There is a spot near the west windows where I like to sit. I would like to make it a proper observation point, with a small stool and a shelf for the notebook. Sitting still for a while shows things that walking past does not: how the fish gather, how the leaves turn toward the light, and how the sound of the pumps changes.

**Compare the loft with its age.** The year of construction, 1999, makes me curious about what has been changed since. If I can find out which parts of the space are original and which were added for the aquaponics work, I can understand why some corners are awkward. The back zone feels the most original, and the west zone feels the most adapted.

## Observations

These are the things I actually saw, kept in plain terms. I have tried to separate what I noticed from what I guessed.

**Light.** The west windows do what I expected. In the early afternoon the loft is bright but gentle. As the sun drops, the light crosses the west zone at a low angle and reaches deep into the middle zone. The plants nearest the glass looked strongest. The ones further back were paler and leaned toward the windows. The back zone gets almost no direct light, and it stays dim even on clear days.

**Warmth.** The air near the roof felt warmer than the air near the floor, and the west zone felt warmest of all once the sun had been on the glass for a while. The middle zone stayed more even. I could feel the difference when walking from the windows toward the stair end. The water in the tank nearest the glass seemed to warm faster than the water in the middle tanks, though I need cleaner readings to be sure.

**The floor.** The raised floor is solid along the center, but I noticed a slight give near some edges. It is not alarming, but it is enough that I walk carefully when carrying anything heavy. Under the floor, the pipes are crowded in places. At one hatch I could see several lines running close together, and I could not tell at a glance which was which. That confirmed my idea about labelling.

**Sound.** The loft is quieter than I expected for a place with pumps. The main sound is moving water, which is steady and low. The pump gear in the back zone hums a little, and I could hear it clearly only when I stood close. The wooden floor adds a faint creak when I move, so I try to stay slow and quiet near the tanks to avoid startling the fish.

**Fish and plants.** The fish moved toward the surface when I came near the tanks, which I took as a sign they expect feeding when someone appears. The plants in the grow beds looked healthy in general, with the best growth in the west zone. A few leaves near the glass showed dry edges, which may be from too much afternoon sun or heat.

**Water.** My readings stayed fairly steady from visit to visit. The sample from the end of a grow bed usually looked a little different from the sample taken at the middle tank, which fits the idea that the plants change the water as it passes through. I do not want to draw strong conclusions from a small set of readings, so I am keeping them as a record for now.

**Space.** The loft is large, and it feels it. There is room to walk between the tanks and beds without squeezing past anything. Even so, the back zone is cluttered, with storage and loose gear that make the area harder to read. The stair end is clear, and it gives the best first view of the whole space when I come up.

**Overall impression.** The Tastodur loft works as an aquaponics space because its good points and its weak points are easy to see. The west light helps the plants. The raised floor hides the plumbing but limits where the weight can go. The age of the building shows in the back zone, and the newer work shows near the windows. I think the next step is simple: measure heat and light more carefully, tidy the space under the floor, and keep writing down what I see in the same order every time.

## Schedule

The schedule for the Tastodur loft study follows the growing year, because the loft is an aquaponics space and the fish and plants set the pace. The loft is large, raised above the ground floor, and faces west, so the light arrives late in the day and the heat builds in the afternoon. I plan every task around that pattern.

### Daily rhythm

- **Early morning:** Check the water in each tank by eye first, then with the test kit. Look at the fish at the surface, since that tells me more than any number. Check that the pumps are running and that the return flow is steady.
- **Midday:** Feed the fish in two small portions rather than one big one. Look over the plant beds for wilting, pale leaves, and pests.
- **Late afternoon:** This is when the west light hits hardest. Check the temperature near the glass and under the roof line, open the vents if needed, and pull the shade cloth across if the leaves look stressed.
- **Evening:** Write down anything unusual in the logbook. Confirm the pumps and the aeration are still running before I leave.

### Weekly tasks

- Clean the pre-filters and rinse the foam.
- Test water for ammonia, nitrite, nitrate, and pH, and record each reading in the logbook.
- Top up the water lost to evaporation. The west exposure makes this more frequent in summer.
- Trim and harvest the leafy crops so the beds stay open for airflow.
- Walk the whole floor and look for leaks, damp patches, and loose fittings. The raised floor means a leak shows up below, so I check the ceiling underneath as well.

### Monthly tasks

- Deep-clean the settling area and remove solids.
- Inspect the pipework, clamps, and valves.
- Check the structure of the raised floor for flex, cracks, or signs of moisture. This matters more in a building from 1999, which has had many years of load and humidity.
- Review the logbook and compare it with the previous month, looking for slow drifts in pH or temperature.

### Seasonal plan

| Season | Main focus |
|---|---|
| Spring | Restart growth, sow seedlings, bring fish feeding back up as the water warms |
| Summer | Control heat from the west glass, increase shading, watch oxygen closely |
| Autumn | Final big harvests, clean down beds, reduce feeding as the water cools |
| Winter | Hold temperature, reduce plant load, keep the system stable and quiet |

### Study phases

I split the study itself into stages, so the notes stay in order.

1. **Baseline observation.** Record how the loft behaves with no changes: temperature across the day, light patterns, humidity, and water readings. This stage runs for a full season before I change anything.
2. **Problem listing.** Write down every weak point I have seen, such as afternoon overheating, uneven light across the beds, and condensation near the roof.
3. **Trial changes.** Make one change at a time, for example a new shade layout or a different bed position, and watch the effect for several weeks.
4. **Review.** Compare the trial results with the baseline and keep only the changes that clearly helped.
5. **Settling.** Fold the successful changes into the regular routine and update the daily and weekly lists above.

### Things that shift the plan

- A heat spell moves shading and water top-ups to the top of the list.
- A fish health problem stops all other work until it is sorted out.
- A pump failure is always an immediate job, because the plants and the fish both depend on steady flow.
- Repairs to the raised floor have to be done when the tanks can be partly drained, so I schedule them for the quiet season.

## Costs

I am not putting exact prices in this note. Prices change, and what matters for my own planning is the shape of the spending: what is a one-time outlay, what repeats, and what grows with the size of the loft. This is a large space, so many costs scale up compared with a small setup.

### One-time costs

- **Tanks and beds:** The biggest outlay. Large tanks, sturdy grow beds, and a frame that can carry the weight on a raised floor.
- **Structural checks and reinforcement:** Water is heavy. Because the floor is raised and the building dates from 1999, I want any support work done properly before adding load. This may be the single item I should not cut back on.
- **Pumps and aeration:** Main pumps, a spare pump, air pumps, and tubing. A spare is a cost I accept in order to avoid an emergency.
- **Plumbing:** Pipes, valves, fittings, and clamps. Good fittings cost more at the start and save leaks later.
- **Shading and ventilation:** West-facing glass or openings need shade cloth, vents, and possibly a fan. This is a direct response to the orientation.
- **Lighting:** Supplemental lights for the darker months, if I decide to use them.
- **Testing equipment:** A water test kit, a thermometer with a memory, and a humidity gauge.

### Recurring costs

- **Fish feed:** Steady and predictable, but it rises when the fish grow.
- **Electricity:** Pumps run all day and night. Heating or lighting in winter would add to this and would be the largest variable.
- **Water:** Topping up evaporation, higher in summer because of the afternoon heat.
- **Seeds and seedlings:** Small but constant.
- **Test reagents and filter media:** Replaced on a regular cycle.
- **Replacement fish:** Some losses are normal and need budgeting.

### Hidden or easy-to-forget costs

- My own time. The daily rhythm above takes real hours, and a large loft takes more of them.
- Cleaning supplies and small tools that wear out.
- Wear on the raised floor and any protective coating or sealing it needs.
- Condensation damage to the roof area or fittings if ventilation is weak.
- Backup power, if I decide a pump outage is too risky.

### Where I would save and where I would not

**Safe to economise:**
- Start with fewer beds and add more once the system proves stable.
- Use simple, sturdy shading instead of automated systems at first.
- Grow hardy leafy crops before trying anything demanding.

**Not safe to economise:**
- Floor support and leak protection.
- A spare pump and reliable aeration.
- Water testing gear. Cheap or unreliable readings lead to costly fish losses.

### Cost review habit

Once a month I go through the logbook and note what I spent time or money on. After a full year I want to know three things: which costs were steady, which surprised me, and which changes from the trial phase actually reduced spending. Heat control is the one I expect to matter most, since the west light drives the water use, the shading, and the plant stress all at once.

## References

These are the sources behind the study. Everything here is my own material or general knowledge, with no outside website named.

### My own records

- **Loft logbook:** The daily and weekly entries on water readings, temperature, feeding, and harvests. This is the main source for the baseline phase.
- **Photo series:** Pictures taken at the same spots at set times of day, mainly to show how the west light moves across the beds.
- **Sketch plans:** Hand-drawn layouts of the large floor, showing tanks, beds, pipes, and walkways, with notes on the raised floor and where the load sits.
- **Repair and maintenance list:** A running list of fixes, leaks, and replaced parts, kept with the order in which things happened.
- **Trial notes:** Short write-ups of each change I tested, what I expected, and what actually happened.

### Facts about the loft I rely on

- Kind: loft
- Area: aquaponics
- Orientation: west
- Size: large
- Year built: 1999
- Floor: raised

These six properties shape most of the decisions above. The west orientation drives the heat and shading work, the large size drives the scale of the costs and the weekly walk-through, the raised floor drives the structural caution, and the year 1999 is why I keep a regular eye on the building's condition.

### General background I used

- Basic aquaponics practice: the balance between fish feed, bacteria, and plant uptake, and the usual order in which ammonia, nitrite, and nitrate rise and fall.
- Common guidance on stocking fish gently and feeding in small portions.
- General knowledge of how glass and west-facing rooms heat up in the afternoon, and how shade and airflow reduce it.
- Plain building sense about the weight of water on raised floors and the need for dry, ventilated structure underneath.

### Open questions for later

- How much does the afternoon shade really lower the water temperature, compared with the baseline?
- Is supplemental lighting worth the extra electricity in the dark months?
- Does the raised floor need reinforcement beyond what is there now?
- Would a second pump circuit make the system safer without making it too complicated?

I will answer these in later notes once the trial phase has produced enough entries to compare against the baseline.

## Open questions

These are the things I have not settled about the Tastodur loft. I keep them here so I do not mistake a guess for a finding.

**Why the west orientation matters for the aquaponics work.** The loft faces west, so most of the direct sun arrives in the afternoon and evening. I do not yet know whether that suits the plants in the grow beds or works against them. Afternoon light is strong and warm, and I suspect the water in the tanks heats up later in the day than it would in an east-facing room. I have no temperature log that proves it. Until I have one, this is only an impression.

**How the raised floor behaves under load.** The loft sits on a raised floor, and the building dates from 1999. Aquaponics is heavy. Water, gravel or clay media, fish and wet plant material all add weight, and the weight sits in a few concentrated places. I have not found any record of what the floor was designed to carry. I need to find out whether the original plans exist, who holds them, and whether anyone has checked the structure since the building went up. I would rather ask this early than discover the answer from a sagging joist.

**Whether the large size is an advantage or a burden.** The loft is large, and on paper that is a plus. More room means more tanks, more beds and space to walk around them. In practice a large space is harder to keep at a steady temperature and humidity. I want to know if one system spread across the whole loft would work better than several smaller, separate ones. A leak or a pump failure in one corner would then not threaten everything else. I have no firm view yet.

**Water handling on a raised level.** Because the floor is raised, any spill has farther to fall and may reach rooms below. I have not worked out where drains are, whether there is a floor drain, or how water would leave the loft in an emergency. I also do not know if the floor surface is sealed. These are practical points, and they could limit where equipment can go.

**Light and shade.** With a west orientation, low evening sun could be a problem in summer and a help in winter. I have not checked how many windows there are, what they are made of, or whether blinds or screens are already fitted. I would like to walk through the loft at three different times of day and note where the light falls.

**Ventilation and humidity.** Plants and open water raise humidity quickly. The 1999 construction may not have been planned for that. I do not know if the walls and roof can cope with damp air, or if condensation would collect on cold surfaces. A moisture check on the walls is something I should do before the first tank is filled, not after.

**Access and moving things in.** A raised floor may mean stairs or a lift. I have not confirmed how large tanks, pumps and bags of media would get up there. If the access is narrow, the size of the loft would matter less than the size of the doorway.

**Who else uses the space.** I have not recorded whether the loft is shared, rented or owned, and that affects how much I can change. Drilling into walls, running pipes or adding drains might need permission. I should write this down plainly once I know.

A short list of next steps, in the order I would do them:

1. Look for the original building plans and any floor-load information.
2. Measure temperature and humidity in the loft over a week or two.
3. Walk the space at morning, midday and evening, and mark where light reaches.
4. Locate drains, water supply and electrical points.
5. Confirm the access route for heavy items.
6. Find out what changes are permitted.

## Dimensions

The Tastodur loft is a large space, and the floor area is 344.47 m². I note the figure here because most of my planning depends on it. Tank counts, walking room and the amount of ventilation I will need all scale with the area.

For the record, the other properties of the place are as follows. It is a loft. Its area of use is aquaponics. It faces west. It is large. It was built in 1999. It has a raised floor.

**What the area means in practice.** A floor of 344.47 m² is big enough to divide into zones. I am thinking of something like this:

- a growing zone, where the beds and any shelving would go;
- a fish zone, with the tanks and the pumps;
- a work zone, for feeding, testing water and storing tools;
- a clear walkway that runs through all of them.

I do not want to fill the floor edge to edge. Walkways must stay open for carrying buckets and for reaching every tank. A rough habit I keep is to leave at least a third of the floor free, though I have not tested whether that is the right amount for this loft.

**What I still need to measure.** The floor area is the only dimension I have written down so far. I have not recorded the ceiling height, the width of the loft, the length, the height of the raised floor above the level below, or the sizes of the doors and windows. These all matter. Ceiling height decides whether I can stack beds or hang lights. The shape of the floor decides how pipes can run. The door sizes decide what can be carried in. I will add each of them to this section once I have measured them myself, with the tape and not by estimate.

**Checking the area figure.** I would like to confirm the area by measuring the length and width on site and comparing the product with the stated figure. If the loft is not a plain rectangle, because of alcoves, columns or stairwells, then the usable area will be smaller than the full floor area. I should mark those parts on a sketch and subtract them, so that I plan with usable space rather than total space.

**Weight spread over the area.** The raised floor and the 1999 build matter here again. A large area helps, because load can be spread out. Heavy tanks could be placed over the strongest parts of the structure, ideally near walls or supports, and lighter beds could go in the middle. I cannot decide that without knowing how the floor is built, which links back to the open questions above.

**Working notes on layout.** For now I treat the large size as room to separate things rather than room to add more. Keeping fish tanks apart from the growing beds makes cleaning easier. It also limits how far a spill can travel. With the west orientation, I lean toward putting the growing zone nearer the windows and the equipment on the darker side, but this is a first idea and I will revise it after the light walk-through.

Summary of the properties, for quick reference:

- Kind: loft
- Area: aquaponics
- Orientation: west
- Size: large
- Year built: 1999
- Floor: raised
- Floor area: 344.47 m²
