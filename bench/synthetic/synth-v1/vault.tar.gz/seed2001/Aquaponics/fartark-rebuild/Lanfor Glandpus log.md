---
type: log
status: active
project: fartark-rebuild
area: aquaponics
description: "Log about Lanfor Glandpus."
---

# Lanfor Glandpus log

## Checklist

Lanfor Glandpus is my supplier contact for aquaponics. I have known him since 2024. The best way to reach him is by phone, and he picks up on weekdays only. I keep this log so I do not have to remember what was agreed on each call.

Before I call, I run through this list:

- Check the weekday. Weekends are a waste of time, so I wait until Monday.
- Write down what I need: fish feed, grow media, pump parts, or water test supplies.
- Look at the stock in the grow room and the fish tanks so I order only what is missing.
- Have the last order note open so I can compare quantities.
- After the call, add a short entry to the log table below.
- If he promises a delivery, write the day he named and check it on the day.

A rule I follow: never agree to anything on the phone without repeating it back to him. It saves arguments later.

## References

These are the things I keep next to this note when I deal with Lanfor Glandpus.

| Item | Where I keep it | Why it matters |
|---|---|---|
| Supplier profile | This note | Role, area, contact method, availability |
| Order history | Paper folder in the workshop | Shows what I bought before |
| Tank notes | Notebook by the grow bed | Tells me what is running low |
| Delivery notes | Drawer under the bench | Proof of what arrived and when |
| Call log | Section below | Short record of each conversation |

Quick summary of the person:

- Role: supplier contact
- Area: aquaponics
- Contact: phone
- Availability: weekdays
- Known since: 2024

He knows the products well and answers technical questions about feed and media without fuss. When he does not know something, he says so and calls back, which I value. Questions about pump sizing usually take a second call, so I plan for that.

A sample of how I record a call, kept as a template:

```
call: Lanfor Glandpus
channel: phone
day: weekday
topic: feed and media restock
agreed: quantities repeated back
follow-up: check delivery on the day he named
```

I copy this block into my daily notes whenever I speak with him, then fill in what changed.

## Contracts

The supply arrangement with Lanfor Glandpus is informal in daily practice, but we put the basic terms on paper so both sides know what to expect.

- Contract date of Lanfor Glandpus: 2025-06-06
- Scope: regular supply of aquaponics consumables
- Contact for changes: phone, on weekdays
- Renewal: I review the terms once a year and call him to talk before anything changes

Things I want to remember about the terms:

1. Orders are placed by phone and confirmed by repeating the quantities.
2. If a delivery is late, I call him on the next weekday and note it in the log.
3. Damaged goods are reported as soon as I find them, with a short description of what was wrong.
4. Any change to the terms should be written down the same day, not left to memory.

I keep a copy of the signed paper with the delivery notes. If a dispute ever comes up, I begin with that paper and my call log, because together they show what we agreed and how things went in practice.

## Maintenance

This section covers how I keep the relationship and this note in good shape.

Regular habits:

- Review this note every few months and fix anything that has changed.
- Call Lanfor Glandpus before I run completely out of something, not after. Since he is only available on weekdays, a weekend shortage can become a long wait.
- Keep the references table current, especially the place where I store paper records.
- Clear old entries from the call log once the matching delivery has been checked.

Practical points from experience since 2024:

- Planning orders around the weekday schedule avoids most problems.
- A short call with clear quantities works better than a long chat with vague promises.
- When a part for the system fails, I describe the symptom first and ask him what he would check, then decide what to order.
- I thank him when a delivery goes well. It keeps things friendly and makes the next request easier.

If his availability or contact method ever changes, I update the checklist and the reference summary right away, so the note stays an honest picture of how I really work with him.
