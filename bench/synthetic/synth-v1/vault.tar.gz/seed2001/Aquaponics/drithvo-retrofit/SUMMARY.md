---
type: summary
status: active
project: drithvo-retrofit
area: aquaponics
description: "Summary about Drithvo retrofit."
---

# Summary of Drithvo retrofit

## Schedule

The Drithvo retrofit is a retrofit project in the aquaponics area. It started in 2026, in the spring season, and the lead is the supplier contact. At the moment the project is in the middle of its early work: the plan is agreed, the supplier is engaged, and the physical work on the system has not been finished.

What is done so far:

- The scope of the retrofit was written down and checked against the existing system.
- The supplier contact was named as lead and agreed to coordinate the parts and the visits.
- The first walk-through of the tanks, pipes and grow beds was completed, with notes on what can stay and what must be replaced.
- A rough order of work was drawn up: water side first, then the grow beds, then the controls.

What is still open:

- The final list of parts that the supplier will deliver.
- The time slot for the shutdown of the system, which has to fit around the fish and the plants so that nothing is lost.
- A check of how long the new parts will take to arrive.
- A decision on who does the cleaning and the restart tests after the work.

Because the project started in spring, the main risk is that the work drifts into the colder months, when the water temperature is harder to keep steady. I want the shutdown to be as short as possible and to avoid the coldest weeks.

## Decisions

The go decision date of Drithvo retrofit is 2019-08-12. That is the date recorded for the go decision, and everything else in the project follows from it.

Decisions made so far:

- Go ahead with the retrofit rather than rebuild the system from scratch.
- Keep the supplier contact as the lead, so there is one person who answers questions about parts and timing.
- Do the work in stages, so the fish are never left without working filtration.
- Keep the old parts until the new ones are tested and running.

Decisions still to make:

- How long the shutdown can safely last.
- Whether to replace the controls in this round or leave them for later.
- Who signs off the restart.

I will write each of these down here once it is settled, with a short reason, so I can see later why I chose it.

## Next action

The next action is NX-2270. I will do it first, before booking any shutdown time, because the other open points depend on it. Once it is finished, I will go back to the open list above, fix the parts list with the supplier contact, and then pick a date for the first stage of the work.
