---
type: log
status: active
project: drithvo-retrofit
area: aquaponics
description: "Log about Lorzera shed."
---

# Lorzera shed log

## Safety

Lorzera shed is a small shed in the aquaponics area. It was built in 2023, it faces west, and the floor is raised off the ground. Those five facts matter for safety, so I keep them in mind every time I go in.

The raised floor is the main thing. Water gets onto it from the tanks and the grow beds, and wet boards are slippery. The step up at the door is easy to miss when I carry a bucket, so I look down before I enter.

Because the shed faces west, the afternoon sun hits the door and the front wall directly. On warm days the inside gets hot fast. I open the door and the vent before I start any work, and I do not leave the pump controller in the sun.

Safety habits I follow:

- Switch off the power at the wall before touching any pump or heater.
- Keep the extension lead off the floor, hung on the hook by the door.
- Wipe up spills right away, and never leave a wet mat on the boards.
- Wear gloves when handling fish netting, plant cuttings or cleaning products.
- Wash hands after any contact with tank water.
- Keep the first aid box on the shelf nearest the door.

Never store cleaning chemicals next to fish food. I keep them on opposite sides of the shed, with the chemicals on the low shelf in a tray.

## Admin

The shed is on a lease, and the reference is LR-244196. I quote it whenever I write to the site owner about repairs or changes.

Basic facts about the shed, kept here so I do not need to look them up:

| Property | Value |
| --- | --- |
| Kind | shed |
| Area | aquaponics |
| Orientation | west |
| Size | small |
| Year built | 2023 |
| Floor | raised |

Admin jobs I need to remember:

- Tell the site owner before adding any new shelving or fixing anything to the walls.
- Keep the paper copy of the lease in the folder at home, not in the shed, because damp ruins paper.
- Photograph any damage before and after repair, and save the photos with the notes.
- Ask before running any new cable from the main supply.

I check the lease terms once a year, usually in winter when the system is quiet, to make sure I am still following the rules about use of the building.

## Risks

The biggest risk is damp. The floor is raised, which helps air move underneath, but the boards still take on moisture from splashes and from humid air around the tanks. Left alone, that leads to soft wood and mould.

The second risk is heat. With the west orientation, summer afternoons can push the temperature inside well above what the electronics like. A hot controller can fail, and a hot shed can stress the fish if the water lines run through it.

The third risk is electrical. Water and mains power sit close together here. I treat every socket as a possible hazard and keep leads tidy and raised.

Other risks, in rough order of how likely they are:

- Pests getting under the raised floor, especially mice looking for fish food.
- Condensation dripping from the roof onto the shelves.
- A power cut stopping the pumps while I am away.
- Algae growth on anything that sits in light and water.
- Theft, since the shed is small and the door lock is basic.

For the power cut, I rely on checking the tanks first thing on any visit. If the pumps have stopped for a long time, I restart them and check the fish before doing anything else.

## Supplies

I keep the shed stocked with only what I use regularly. Because it is small, there is no room for spares of everything, so I top up often and buy in small amounts.

Current stock categories:

- Fish food in a sealed tub with a tight lid.
- Water test kits for ammonia, nitrite, nitrate and pH.
- Spare tubing and a few fittings for the water lines.
- Cable ties, tape and a small tool roll.
- Nets, buckets and a scrubbing brush.
- Gloves, cloths and a roll of paper towels.
- A bag of grow media for topping up the beds.

I store the heavier items on the low shelf so the shelves do not tip. Anything that must stay dry goes on the high shelf, away from the floor and from the west wall, which gets the warmest.

When a test kit runs low, I write it on the list on the back of the door. I do the same for food and tubing. I would rather buy early than find the shed empty on a day when something breaks.

## Maintenance

I do a quick check each visit and a longer job once a season. The raised floor needs the most attention, then the roof and the door seals.

Each visit:

- Look under and around the raised floor for pests, standing water or damage.
- Wipe the floor and shelves if they are damp.
- Check that the vent is clear and the door closes properly.
- Check the pump controller and leads for heat or wear.

Each season:

- Sweep out the shed and scrub the boards with a mild cleaner, then let them dry with the door open.
- Inspect the roof for leaks and the walls for gaps.
- Repaint or treat any bare wood, mainly on the west side where sun and weather do the most harm.
- Check the door lock and hinges, and oil them if they are stiff.
- Test the sockets and replace any worn lead.

Since the shed was built in 2023, the wood is still in good shape, but the west wall already shows some fading. I plan to treat it before the next hot season. I record each job in this log with a short note about what I found, so I can spot patterns over the years.
