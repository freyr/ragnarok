---
type: drivers
status: active
project: drithvo-retrofit
area: aquaponics
description: "Drivers about Drithvo retrofit."
---

# Drivers of Drithvo retrofit

## Setup

Drithvo retrofit is a project in the aquaponics area. The goal is a retrofit of the existing system, not a new build. It starts in 2026, in the spring season, and the lead is the supplier contact. I am not the lead, so most of the scheduling depends on what the supplier contact can deliver and when.

This note is the drivers note. It records why the project exists, what limits it, how much money is set aside and how I will tell whether it worked. Day-to-day work goes in other notes.

The goal in plain terms: take the current aquaponics setup and upgrade it so it runs more steadily with less hands-on correction. The retrofit should reuse as much of the existing tanks, grow beds and plumbing as is sensible. Anything that can stay in place should stay in place.

Constraints I am working with:

- The work happens in spring, when the plants are going back into the beds. Fish stress and plant timing both matter, so the system cannot be down for long.
- The supplier contact leads, so orders and delivery slots follow their calendar.
- The budget is fixed and has no obvious room to grow.
- The existing footprint cannot change. New parts must fit the space we already have.

How success is measured:

- The system runs through a full growing cycle after the retrofit without an emergency intervention.
- Water readings stay in the range I consider normal for the fish and the plants.
- I spend less time on daily checks than I did before.
- The project stays inside the budget below.

## Tools

The tools list is short. Most of it is already in the workshop, and I only want to buy something if a job cannot be done without it.

- Basic hand tools: wrenches, pipe cutters, screwdrivers, a drill and a set of bits.
- A water test kit for ammonia, nitrite, nitrate, pH and hardness, plus a thermometer.
- A bucket set and a small spare pump for moving water during the swap.
- A multimeter for checking the electrical side before anything is switched back on.
- A level and a tape measure, since the new parts have to fit the existing frame.
- A notebook, or this vault, to log each change with the day it was made and the readings after.

If the supplier contact lends anything for fitting, I will write down what it was and when it goes back.

## Supplies

Supplies come mainly through the supplier contact, who also leads the project. I want a single order list so nothing arrives half complete.

- Replacement pump and fittings sized to the current pipe runs.
- Tubing, clamps and sealant that are safe for fish.
- Any new sensors or controllers the supplier contact recommends.
- Spare seals and connectors, because there is always one that fails.
- Cable, a fused supply and a weatherproof box for the electrical changes.
- Some extra media for the grow beds in case the old media needs topping up.

Before ordering I will check each item against what is already in place, so I do not pay twice for something that still works. Each delivery gets checked on arrival against the list, and missing items are noted the same day.

## Open questions

- Which parts of the current system are worth keeping, and which should be replaced outright? I need a proper inspection before deciding.
- How long can the fish live in temporary holding without trouble? This sets the real limit on downtime.
- Does the supplier contact have firm delivery slots for spring, or only estimates?
- Will the new controller work with the sensors I already own?
- Who is responsible for fixing faults found shortly after handover, me or the supplier contact?
- Is there a sensible way to test the new setup before the plants are back in?
- What counts as less time on daily checks? I should write down my current routine now so I can compare later.

## Budget

The budget of Drithvo retrofit is 17816.82 EUR.

This is the whole amount for the project, covering parts, supplies and anything the supplier contact charges for work or advice. I treat it as a ceiling, not a target.

How I plan to handle it:

- Split the amount into rough groups: pumps and plumbing, controls and sensors, electrical work, spare parts and a reserve.
- Keep part of it unspent until the inspection is finished, because surprises usually show up once things are opened.
- Record each purchase with the date and the supplier contact's quote, so I can see where the money went.
- Stop and review if the spent total reaches about two thirds before the main work is done.

Money is one of the three success measures, so a project that works but goes over budget is only a partial success.

## Risks

- Fish stress or loss if the system is down too long or the water chemistry swings during the swap.
- Delivery delays from the supplier contact, which could push the work past the spring planting window.
- Parts that do not fit the existing frame or pipe sizes, causing rework.
- Hidden damage found when old parts come out, such as corroded fittings or cracked tubing.
- Electrical faults near water. I will switch everything off and check with the multimeter before restoring power.
- Budget overrun from small extras that each look minor.
- Dependence on one person leading the project. If the supplier contact is unavailable, work could stall, so I will keep notes clear enough for me to continue alone.
- New controls that behave badly in the first days, so I will keep the old setup available as a fallback until the new one has proven stable.
