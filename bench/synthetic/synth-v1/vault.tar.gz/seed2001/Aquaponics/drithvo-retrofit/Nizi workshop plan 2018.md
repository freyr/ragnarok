---
type: research
status: archived
project: drithvo-retrofit
area: aquaponics
description: "Research about Nizi workshop."
---

# Nizi workshop plan 2018

## Schedule

This note is archived. It records how the Nizi workshop was set up and used in 2018. Later notes replace these values, so do not treat anything here as current.

The Nizi workshop is a workshop in the aquaponics area. It was built in 2005, it is large, it sits below ground, and its orientation is east. Those are the fixed facts I keep at the top of every note about it.

In 2018 I ran the week in a fairly steady pattern:

- Monday: check the water in all grow beds and the fish tanks, then clean the pump intake screens.
- Tuesday: seedling work. Sow trays, move older trays to the beds, and label everything.
- Wednesday: repairs and building. This is the day for pipe fittings, bed frames and anything that needs the bench.
- Thursday: harvest and replanting. Greens go out the same morning.
- Friday: tidy, restock consumables, and write up the week in the log.
- Weekend: only a quick look at temperature and water level, no real work.

Because the room is below ground, the morning routine started with the lights and the ventilation fan before anything else. The air is damp early in the day, and I did not want to start work in it. The east orientation mattered more for the small high windows at the top of the wall than for anything else. Early light reached the seedling shelf first, so that shelf got the first sowing slot of the day.

I kept a simple timer plan for the lights and fan. This is the extract I copied into the log in 2018:

```
# timer plan, Nizi workshop
lights_on    06:00
lights_off   20:00
fan_cycle    10 min on / 20 min off
pump_cycle   15 min on / 15 min off
night_check  manual, none scheduled
```

## Tools

The tools lived in three places: the wall board by the door, the bench drawers, and a rolling cart that moved between beds. I wrote down what was in each so I could tell quickly when something was missing.

Wall board:
- Pipe cutters and a hacksaw
- Two adjustable wrenches
- Hand drill and a set of bits
- Tape measure and a spirit level

Bench drawers:
- Silicone sealant, thread tape and spare clamps
- Pipe fittings sorted by size in small tubs
- Marker pens, plant labels and a notebook
- Spare air stones and tubing

Rolling cart:
- Water test kit for pH, ammonia, nitrite and nitrate
- Thermometer and a net for the tanks
- Small buckets and a hand siphon
- Gloves and a spray bottle for cleaning

Measuring and testing gear is the part I trust least. The test kit reagents expire, and I wrote the opening dates on the bottles with a marker. In 2018 I replaced reagents about twice a year. The thermometer was checked against a second one when I remembered, which was not often enough.

The power tools were few on purpose. A damp, below-ground room is not a place for a lot of mains-powered equipment, so I kept to the drill and one work lamp. Everything else was manual.

## Safety

The main hazards in the workshop come from the combination of water, electricity and a below-ground room.

- All sockets are fed through a residual current device. I tested it by pressing the test button on the first day of each month.
- Pumps and heaters are plugged in above the level of any possible spill, never on the floor.
- The floor is below ground, so a failed pump or burst pipe can put water on it quickly. I kept a squeegee and a wet vacuum next to the door and checked the floor drain every Monday.
- Ventilation matters. Damp air and stale air build up in a room like this, so the fan runs on a cycle and the door stays open when I work for a long time.
- Wet floors are slippery. I put rubber mats in front of the beds and the bench.
- Wash hands after touching tank water, and keep food and drink out of the room.
- Chemicals, such as cleaner and pH adjusters, are stored on the top shelf, closed and labeled, away from the electrics.
- The only way out is the stairs. I kept them clear and the light on the stairs working. I never worked alone late at night.

If power fails, the first step is to stop feeding the fish and check the aeration by hand. Fish can survive a few hours without pumps, but not without air for long. After that I look at the temperature and the water level.

## Dimensions

The properties of the Nizi workshop, as recorded in 2018:

- Kind: workshop
- Area: aquaponics
- Orientation: east
- Size: large
- Year built: 2005
- Floor: below ground

The floor area of Nizi workshop is 367.32 m².

That area is shared roughly like this. About half is grow beds and fish tanks, a smaller part is the bench and tool wall, and the rest is walking space and storage. I did not measure each zone exactly, so these are approximations only and the total above is the one figure I trust.

Because the room is below ground, the walls are thick and the ceiling is lower than I would like for tall plants. I kept tall crops, such as tomatoes, to the beds nearest the middle where the ceiling is highest. The small windows on the east side are high on the wall, which means they bring in light but give no view and not much air.

Large is the right word for it. Walking from the door to the far tank takes a good while with a full bucket, which is why the rolling cart earned its place.

## Observations

These are the things I noticed during 2018, kept as a record and not as advice for today.

- The room stays cooler than rooms above ground in summer, and the water temperature was easier to hold steady. In winter it needed less heating than I expected, though the damp was worse.
- Condensation collected on the cold pipes and on the wall opposite the door. I wiped it regularly and watched for mold on the wall board.
- Morning light from the east reached the seedling shelf first, and seedlings there grew faster than those near the far wall. I moved trays along over the course of the day to even this out.
- The fan cycle in the timer plan kept the air acceptable, but on humid days I ran it longer by hand.
- The biggest recurring chore was the pump intake screens. They clogged with plant debris more often than I planned for.
- The floor drain was never blocked, but I came close once after a bed leak, which is why I check it each week.
- Walking distance was a real cost. Putting the test kit on the cart saved many trips.

Things I meant to improve and may have done later: better lighting over the middle beds, a second thermometer fixed in place, and a proper shelf for the reagents. If those were done, a newer note will say so and replaces what is written here.
