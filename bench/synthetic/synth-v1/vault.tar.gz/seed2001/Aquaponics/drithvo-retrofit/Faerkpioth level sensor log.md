---
type: log
status: active
project: drithvo-retrofit
area: aquaponics
description: "Log about Faerkpioth level sensor."
---

# Faerkpioth level sensor log

## Problems

The Faerkpioth level sensor is a red level sensor that has been installed in the yard since 2019. It belongs to the aquaponics setup and runs on mains power. This log keeps track of the faults I have seen with it and what I did about each one.

The main trouble is the yard itself. The sensor sits outdoors, so damp, dirt and temperature swings all affect it. Most of the odd readings I have logged trace back to one of three causes: a wet connector, algae on the probe, or a power dip on the mains line.

- Readings jump up and down when the pump starts. This is usually a power dip, not a real change in water level.
- The reading drifts slowly upward over a few weeks. Algae film on the probe is the usual reason, and wiping it clears it.
- The sensor goes silent after heavy rain. The connector had water in it, so I dried it and sealed it again.
- Red housing has faded a little in the sun, but it has not cracked or let water in.

| Symptom | Likely cause | What I do |
|---|---|---|
| Jumping readings | Power dip at pump start | Check the mains socket and the cable |
| Slow upward drift | Algae on the probe | Wipe the probe clean |
| No signal after rain | Wet connector | Dry it and reseal it |
| Faded housing | Sun exposure | Nothing needed for now |

When a fault shows up, I first compare the sensor with a look at the tank by eye. If the two agree, I leave the sensor alone and note the event here.

## Software

The sensor runs firmware version v6.40.167. I have not changed it since I first noted it down, and it has behaved well enough that I see no reason to touch it.

Things I keep in mind about the software side:

- Do not update the firmware in the middle of a growing cycle. A failed update could leave the tank without any level reading.
- If the readings start to look strange, first rule out the hardware causes in the table above before blaming the firmware.
- Write down the firmware version before and after any change, so I can go back if something breaks.
- A restart by cutting the mains power fixes small glitches, but I only do it after checking that the pump is off.

For now the plan is simple: keep the current firmware, keep cleaning the probe, and keep logging every fault in the Problems section so that patterns are easy to spot later.
