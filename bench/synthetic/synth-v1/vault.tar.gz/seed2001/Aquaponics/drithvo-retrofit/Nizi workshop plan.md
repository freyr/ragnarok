---
type: plan
status: active
project: drithvo-retrofit
area: aquaponics
description: "Plan about Nizi workshop."
---

# Nizi workshop plan

## Observations

The Nizi workshop is a large workshop built in 2005. It sits below ground, and its main face and doors point east. The area it serves is aquaponics, so almost everything in it is there to support fish tanks, grow beds and the plumbing that links them.

Being below ground is the biggest fact about the place. The temperature stays steady through the year. In summer it is cool and in winter it holds heat far better than any shed I have used. The downside is damp. The walls sweat in spring, and anything made of untreated steel rusts if I leave it out. I keep a small log of which tools rust first, and the hand tools in the open racks lose every time.

The east orientation means morning light comes in through the upper openings and the stair well. By midday the room is lit mostly by the lamps. I plan work that needs good eyesight, like fitting small fittings and checking weld seams, for the early hours. Afternoon work is for cutting, sanding and cleaning.

Because the room is large, it has separate zones. The plan is to keep them as they are:

- A cutting zone near the stairs, where the dust can be carried out most easily.
- A wet zone along the far wall, with a floor drain and a deep sink for rinsing tanks and media.
- A bench zone in the middle, with the vise and the main work surface.
- A storage zone along the north side, with shelves off the floor.

Air movement is the main problem. Fumes from glue and solvent settle low in a below-ground room, and a single fan is not enough. The test of the existing fan showed it moves air around the middle but leaves the corners still.

The warm-water side of the system also matters. The notes in [[Dranlu heat exchanger]] describe how heat is pulled from the tank loop, and I want the workshop to borrow a little of that warmth in winter instead of running a separate heater. That is only an idea until I check how much the loop can spare.

## Lessons

Several things from earlier years apply directly to this plan.

1. Moisture control comes first. Every time I put a tool in before dealing with damp, I paid for it later. The dehumidifier goes in before the new benches do.
2. Keep wood and metal work apart. Sawdust in the wet zone clogs the drain within weeks, and wet floors ruin sheet stock.
3. Raise everything off the floor. Even a small flood from a failed tank line spreads across the whole room, because the floor is nearly level.
4. Do not trust one exit. With the room below ground, the stairs are the only easy way out, so the layout should leave a clear path from every zone to them. I want a second route planned before I add any more large equipment.
5. Test before you commit. The results in [[Renlior band saw tests]] showed that the saw I wanted was too heavy for the bench I had planned, and that blade changes were awkward in a tight spot. I would have found this out expensively if I had bolted it down first.
6. Write down what you decided and why. The [[Methreth Bentroputh notes]] record the reasoning for several layout choices, and I have already saved myself from repeating one bad idea by rereading them.

A smaller lesson: label the shutoff valves. I spent far too long once tracing a leak because nothing was marked.

## Dimensions

The Nizi workshop is a large room, and the numbers below are the ones I plan around.

- Floor area: 321.99 m²
- Size class: large
- Year built: 2005
- Floor: below ground
- Orientation: east
- Kind: workshop
- Area: aquaponics

The floor area is enough for the four zones to sit apart without crowding. It is not enough to ignore layout. A room this size lets me leave wide aisles, and I want to keep the aisle in front of the wet zone clear at all times so that I can carry a full tank bin through without turning sideways.

For planning, I think in terms of paths, not area. The main path runs from the stairs to the bench zone, then to the wet zone. The cutting zone and the storage zone branch off it. Nothing should sit on that path, including temporary piles.

Ceiling height is limited by being below ground, so tall items such as grow racks have to be assembled on their side and stood up in place. I measure each large piece against the stair opening before I buy it.

## References

- [[Dranlu heat exchanger]]: heat from the tank loop and whether the workshop can use some of it.
- [[Methreth Bentroputh notes]]: past layout decisions and the reasons behind them.
- [[Renlior band saw tests]]: results that decided which saw fits the bench.

Next steps, in order: install the dehumidifier, label the valves, mark the main path on the floor, and then move in the heavy equipment one piece at a time.
