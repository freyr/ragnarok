---
type: log
status: archived
project: drithvo-retrofit
area: aquaponics
description: "Log about Lorzera shed."
---

# Lorzera shed log 2023

## Open questions

These were open when I wrote this log in 2023. Later notes may settle them and replace the values recorded here.

- Is the west orientation a problem in late afternoon? The sun hits the wall hard, and I do not yet know how much it heats the inside.
- Is a small shed enough once the tanks and the grow beds are all running? I may run out of floor space for tools and spare parts.
- Will the raised floor stay dry and solid through a wet winter? I want to check the supports again after the first season.
- Should I add shade on the west side, such as a screen or a few climbing plants?
- Is there a better place to keep fish feed so that damp air does not reach it?

## Setup

This section records how the shed stood in 2023, the year it was built. The shed sits in the aquaponics area of the property. I use it as the working base for the fish tanks and the plant beds around it.

The basic properties, as recorded in 2023:

| Property | Value |
| --- | --- |
| Name | Lorzera shed |
| Kind | shed |
| Area | aquaponics |
| Orientation | west |
| Size | small |
| Year built | 2023 |
| Floor | raised |

A few practical notes on each property:

- **Kind:** it is a shed. It is not a greenhouse and not a full workshop. It stores things and gives me a dry spot to work.
- **Area:** it belongs to the aquaponics area, so everything inside relates to the fish and plant system.
- **Orientation:** the door and main wall face west. Evening light comes straight in, which is pleasant for working but warms the place up.
- **Size:** small. Two people fit inside, but not comfortably with a bucket and a net.
- **Year built:** 2023. Everything in it was new that year, so I had no wear to judge yet.
- **Floor:** raised. The floor sits off the ground on supports. This keeps the boards away from soil moisture and gives air flow underneath. It also means a step up at the door, which matters when I carry water.

I kept the layout simple. Tools hang on the north wall. Nets, test kits and small pumps go on a shelf by the door. Feed stays in a sealed bin on the floor, away from the west wall.

## Admin

The paperwork for the shed was minimal in 2023. I kept everything in one folder and wrote down the main reference here so I can find it quickly.

- Lease reference of Lorzera shed: LR-171878
- Status in this note: archived, recording 2023 only
- Where the papers are kept: the folder marked for the aquaponics area

Things I did for admin in 2023:

- Checked that the shed was covered by the lease for the aquaponics area.
- Wrote the reference on the inside of the door, so it is visible to anyone who helps me.
- Kept a short list of what was in the shed, in case I needed to explain it later.

If any detail here differs from a newer note, trust the newer note. This log is a record of the past, not a current statement. Later notes replace the values listed here, including orientation, size, floor and anything about the lease.

## Overview

Lorzera shed is a small shed in the aquaponics area, built in 2023. It faces west and has a raised floor. This log is an archived record of how it stood in that year.

My main impression from the first year was that the shed did its job. It kept tools, test kits and spare parts dry, and it gave me a place to stand out of the wind while I checked the system. The raised floor was the best choice I made. Even after heavy rain, the inside stayed free of damp, and I never saw standing water near the door.

The west orientation was mixed. It gave me warm light in the evening and made the shed pleasant to visit after other work. In summer, though, the wall took a lot of heat. I noticed that anything plastic left near that wall felt warm by the end of the day, which is why I moved the feed bin away from it.

The small size was the main limit. I found that a shed this size works well as a storage and check-in point, but not as a place to do long jobs. Repairs and cleaning usually happened outside, with only the tools and parts coming from the shed.

What I would want to know next is listed under the open questions above. The short version: watch the heat, watch the floor supports, and see whether the space is still enough once the system is fully running. Any answers belong in a newer note, since this one is closed and records 2023 only.
