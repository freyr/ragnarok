---
type: research
status: active
project: gonvus-automation
area: aquaponics
---

# Tisiork greenhouse tests

## Ideas

These are the tests I want to run at the Tisiork greenhouse, a large aquaponics greenhouse built in 2015. It faces west, and it has a raised floor. The west orientation means the late afternoon sun hits the grow beds hard, so most of my ideas are about heat and water temperature.

- Compare water temperature in the fish tanks at morning and at evening for two weeks, and see how far it swings.
- Try shade cloth on the west wall only, then compare plant growth on the shaded side against the open side.
- Check whether the raised floor keeps the cold out of the pipes in winter. I suspect it helps, but I have no readings yet.
- Run the circulation pump on a timer instead of continuously, and see if oxygen stays acceptable.
- Power a small monitoring unit from solar. The earlier results are in [[Firkglor solar charger tests]], and I should read them before buying anything.

I want to change only one thing at a time. Last season I changed the shading and the pump timing together and could not tell which one made the difference.

## Maintenance

The raised floor makes some jobs easier. I can get underneath to look at the plumbing without kneeling in water. It also means leaks drain away quickly and I may not see them, so I check the underside regularly.

Routine checks I do:

- Look at the pump intake and clear any debris.
- Wipe the sensor probes, since algae builds up fast on the west side.
- Check the fittings under the floor for drips.
- Rinse the filter media in tank water, never in tap water.

For the pump itself I follow the notes in [[Lonturktru circulation pump handbook]]. For the sensor readings I keep a running record in [[Faerkpioth level sensor log]]. Older notes on the outbuilding where I keep spare gear are in [[Lorzera shed log 2023]].

A typical entry I add to the log after a check looks like this:

```
check: greenhouse west bed
pump intake: clear
level sensor: reading steady
floor underside: dry
filter media: rinsed
action: none needed
```

If any line says something other than normal, I write a follow-up item and test it again within a few days.

## Dimensions

The Tisiork greenhouse is large. The floor area is 267.93 m². That is enough space for several grow beds, a row of fish tanks and a walkway down the middle, with some room left for a work bench.

The size matters for my tests in a few ways:

- Water volume is big, so temperature changes slowly. Short tests tell me little, and I need to run each one for weeks.
- The west side and the east side can behave differently, so I should measure both and not trust one spot.
- Pipe runs are long, so the pump has to work against more resistance than in a small setup.

Because the floor is raised, the working height is a little above ground level. I keep this in mind when I plan where to put sensors, so I can reach them without a ladder.

## Supplies

I keep these on hand for the aquaponics work and for the tests above:

- Shade cloth, enough to cover the west wall
- Spare tubing and a few fittings for the pump lines
- A spare level sensor and probe wipes
- Test kits for water quality
- A small timer for the pump trial
- Notebook and waterproof pen for readings

Before each test I check the supplies against the plan, because running out halfway through ruins the comparison. The spare gear is stored in the shed, and I record what I take out so the stock count stays right. If the solar tests go well, I will add the charger and a small battery to this list, but I will wait for the results first.
