---
type: drivers
status: active
project: gonvus-automation
area: aquaponics
---

# Drivers of Gonvus automation

## Risks

The main risks to Gonvus automation are listed here so I can check them at each review. The project is an automation project in the aquaponics area. It started in autumn 2023 and the lead is the mentor.

- **Power loss.** Automation depends on mains power. If the pump controller loses power during a cold night, the grow beds stop flooding and the fish tank loses its circulation. A battery backup for the controller and one air pump is the minimum.
- **Sensor drift.** Cheap probes for pH and temperature drift over weeks. If I trust a drifting probe, the automation may dose or switch on the wrong thing. I calibrate on a fixed schedule and compare against a manual reading.
- **Over-automation.** If every task is automated, I stop looking at the system. Fish problems then show up late. I keep a daily visual check even when everything reads normal.
- **Clogged plumbing.** Solids can block the siphon or the valve. An automated valve that cannot close or open fully is worse than a manual one.
- **Software mistakes.** A wrong threshold in the controller can run a pump dry. Every rule has a hard limit that cannot be overridden by the logic above it.
- **Single person knowledge.** The mentor leads and I do the hands-on work. If only one of us understands the wiring, a absence stalls the project. I keep the notes current for that reason.
- **Scope creep.** New ideas appear every week in autumn when the system is quiet. I only add them after the core goals are met.

## Background

Gonvus automation is the project name I use for making the small aquaponics system run with less daily manual work. The goal is automation, the area is aquaponics, the start year is 2023, the season of the start is autumn, and the lead is the mentor.

The system is a modest recirculating setup: one fish tank, a sump, and two grow beds on a shared frame. Water is pumped from the sump to the beds, drains by a bell siphon, and returns to the fish tank. Before this project, I did everything by hand: switching the pump on a timer plug, checking temperature with a hand thermometer, topping up water from a bucket, and testing pH with drops.

The reason for starting in autumn is practical. Temperatures start to fall, the plants need less water and nutrients, and the fish eat less. It is a gentler time to change things than in midsummer, when a failure can kill the fish within hours. It also gives a full cold season to learn how the system behaves before spring growth.

The mentor suggested the following order, and I have kept to it:

1. Measure first, without controlling anything.
2. Add alarms that tell me something is wrong.
3. Automate only the simple, safe actions, such as the pump schedule and top-up water.
4. Leave the risky actions, such as pH correction, manual until I trust the data.

This order is the main driver of the whole plan. It means the early months produce logs and alarms rather than fancy control, and I accept that.

## Supplies

The supplies are chosen to be cheap, replaceable and easy to get. I avoid anything that needs a special order, since a long wait for a part leaves the system in a half-automated state.

- A small single-board controller with network access, plus a spare of the same type.
- A relay board with enough channels for the pump, the air pump, a heater and a top-up valve.
- Waterproof temperature probes, two in the fish tank and one in the sump.
- A pH probe with its calibration solutions and a storage bottle.
- A float switch for the sump low level and another for the high level.
- A small solenoid valve for the top-up line.
- A flow sensor on the return line, to confirm that the pump is actually moving water.
- A battery backup for the controller and the air pump.
- Waterproof enclosure, cable glands, strain relief, and fused power distribution.
- Food-safe tubing and fittings.
- Labels and a marker. Labelling every cable saves me more time than any other single item.

I keep the spare parts in one box near the system, with a list taped inside the lid. When I use a spare, I reorder it the same week.

## Checklist

This is the checklist I use at each visit. It is short on purpose, so that I actually do it.

- Look at the fish: are they eating, and do they swim normally?
- Look at the water: is it clear, and does it smell normal?
- Check that the pump is running and the beds are flooding and draining.
- Read the dashboard values and compare temperature with the hand thermometer.
- Check the alarm log since the last visit.
- Check that the backup battery shows as charged.
- Look under the frame for leaks or damp cables.
- Wipe condensation from the enclosure and check that the lid is closed.

Monthly additions:

- Calibrate the pH probe and write down the result.
- Clean the flow sensor and the float switches.
- Test the alarm by simulating a low water level.
- Pull the power on purpose and confirm that the backup takes over.

## Tools

The tools are ordinary and I keep them together.

- Small screwdrivers and a wire stripper.
- A multimeter, used mostly to check that supply voltage is steady and that relays click and connect.
- A hand thermometer that I treat as the reference.
- A liquid test kit for pH, ammonia, nitrite and nitrate, used to cross-check the probes.
- A laptop for configuring and reading logs.
- A label maker or tape and pen.
- A bucket and a small siphon hose for emergencies.
- A headlamp, because the system sits in a dim corner.

For software I keep the control program as a small set of plain text files, with a configuration file separate from the logic. That way I can change a threshold without editing code. A sample of the configuration is below. The values are the ones I chose as starting points, and I adjust them after watching the logs.

```yaml
system: gonvus-automation
area: aquaponics
controller:
  log_interval_minutes: 5
  alarm_repeat_minutes: 30
pump:
  mode: schedule
  on_minutes: 15
  off_minutes: 45
  require_flow: true
water_level:
  low_float: sump_low
  high_float: sump_high
  topup_max_minutes: 10
temperature:
  fish_tank_min_c: 14
  fish_tank_max_c: 26
  heater_enabled: true
ph:
  min: 6
  max: 7
  auto_correct: false
alarms:
  channel: email
  recipients: lead_and_me
```

The key lines are `require_flow` and `auto_correct`. The first stops the system from reporting success when the pump is running but no water moves. The second stays false, following the plan to keep pH correction manual.

## Maintenance

Maintenance is part of the project and not an afterthought. Automation that is not maintained becomes a hazard faster than a manual system, because I stop paying attention.

Weekly I clean the filter screen on the sump, wipe the probes with a soft cloth, and check that tubing has not kinked. Monthly I do the calibration and the alarm test from the checklist. Each season I open the enclosure, look for corrosion, check terminal tightness, and replace any cable that shows wear.

I keep a short maintenance log with the date, what I did, and anything odd. The log also records software changes, with a one-line reason. If something breaks, the first question is always what changed last.

Probes have a limited life. The pH probe in particular tends to become slow and inaccurate after a year or so of continuous use. I treat a slow response as a sign to replace it, not to recalibrate harder.

Backups matter too. I copy the configuration files and the log to a second location after every change. If the controller dies, a spare loaded with the saved files should be running within an hour.

## Observations

These are the things I have noticed so far.

- The system is calmer than I expected in autumn. Temperature changes slowly, and the main daily swing is between day and night.
- The sump level drops steadily through evaporation and plant uptake, so the top-up valve opens briefly most days.
- The bell siphon is sensitive to the pump flow. When the flow dips, the siphon sometimes fails to break and the bed stays flooded. The flow sensor helps me detect this.
- Probes in the fish tank pick up electrical noise when the heater switches. I fixed most of it by moving cables and adding a short averaging step in the software.
- The temperature probes agree with the hand thermometer within a small margin, but the pH probe needs more attention.
- Alarms that fire too often get ignored. I raised the repeat interval and merged several related alarms into one message.
- The mentor reviews the logs more often than I expected and usually spots patterns that I miss, such as a slow nightly temperature drop that pointed to a heater thermostat issue.

## Open questions

- How much automation is enough? I want a stopping rule so the project does not continue forever.
- Should pH correction ever be automated, or is a good alarm and a manual response safer for a system this small?
- Is a second controller worth it as a hot standby, or is a cold spare enough?
- Can the flow sensor be trusted over the long term in water with plant debris?
- What is the best way to test a failure of the heater without risking the fish?
- Should the dashboard be reachable from outside my home network, and if so, how do I do that safely?
- How should I record feeding, so that the data can be linked with water quality?

## Budget

The budget for Gonvus automation is 20142.18 EUR.

This figure is the ceiling for the whole project, and it is one of the main drivers. I split it roughly into groups rather than tracking each item against a fixed number, because prices and needs change over the season.

- Controllers, relays and wiring.
- Probes and sensors, including replacements over the project life.
- Power protection and the battery backup.
- Plumbing parts, valves and fittings.
- Enclosures and mounting.
- A reserve for failures and for ideas that prove worthwhile.

I keep a reserve because something always breaks or turns out to be the wrong size. I do not spend the reserve on new features until the core goals are met. Any purchase that would use a large part of the reserve is discussed with the mentor first.

Time is not in the budget figure. My hours are unpaid, but I note them, because they show whether the project is reasonable for a personal effort.

## Setup

The physical setup follows the water path. The pump sits in the sump and lifts water to the two grow beds. The beds drain through bell siphons back to the fish tank, and the fish tank overflows to the sump. The flow sensor is on the pump outlet line, before the split to the beds.

The controller and relay board live in a waterproof enclosure mounted above the frame, higher than any possible water level. Cables enter from below through glands with drip loops, so water running down a cable drops off before reaching the box. Mains and low voltage wiring are kept apart inside the enclosure, and each mains circuit has its own fuse.

The probes are placed away from the heater and the inlet, where the water is mixed but not turbulent. The float switches in the sump are set at two heights: the low one stops the pump and the top-up valve opens, and the high one closes the valve. A second, independent high float cuts the valve power directly, so a software fault cannot cause a flood.

Success is measured by results that I can check, not by how much hardware is installed. The measures are:

- The system runs a full season with no fish loss caused by equipment.
- Daily manual tasks are reduced to the visual check and feeding.
- Every alarm that fires corresponds to a real condition, and every real problem produces an alarm.
- The project stays inside the stated budget.
- Someone other than me can follow the notes and keep the system safe for a few days.

## Overview

Gonvus automation is a project in the aquaponics area. Its goal is automation, it started in autumn 2023, and the mentor leads it.

The drivers can be summed up this way. The goal is to reduce daily manual work on a small aquaponics system without making it less safe. The constraints are a fixed budget, a small physical space, parts that are easy to replace, and the limited time I have to spend. The budget is stated in its own section. Success is measured by a full season without equipment-related fish loss, fewer routine tasks, trustworthy alarms, staying within budget, and notes that someone else can use.

The sequence is deliberate: measure, alarm, automate the safe actions, and only then consider the risky ones. This sequence protects the fish while I learn how the system behaves. The mentor's role is to review the logs, challenge my assumptions, and approve larger purchases.

If I ever need to decide quickly whether a new idea belongs in the project, I ask three questions. Does it reduce a real manual task? Does it keep or improve safety? Does it fit in the remaining budget? If the answer to any of them is no, the idea waits.

## References

These are the sources I rely on, described in general terms because they are my own working materials.

- My own maintenance log and the controller logs.
- The wiring sketch I drew for the enclosure, kept with the spare parts box.
- The handbooks that came with the probes and the relay board, mainly for calibration steps and wiring limits.
- The notes from review sessions with the mentor.
- The test kit instructions, for the reference water tests.
- A short written summary of the fish species I keep, with their comfortable temperature and pH ranges.

Whenever I change a threshold in the configuration, I add a note about why, so that the reasoning is easy to find later.

## Safety

Safety covers people and fish.

For people: mains power and water are a dangerous mix. All mains outlets near the system are protected by a residual current device. The enclosure is mounted above water level, cables have drip loops, and I switch off the supply before working inside. I do not work on live wiring, and I do not handle mains parts with wet hands. Low voltage parts are kept separate from mains parts and labelled.

For fish: the worst events are a pump stop, a heater failure that overheats or chills the water, and a flood or drain-down that empties the tank. The design answers each one. The flow requirement catches a stopped pump, temperature limits trigger the heater and alarms, and independent float switches limit the top-up. The battery backup keeps air flowing during a short power cut.

Chemical safety is simple: calibration solutions are stored closed and labelled, away from the fish area. I never add anything to the water that I have not checked against the fish and plants.

If an alarm fires and I cannot reach the system quickly, the mentor is the second contact. We agreed that either of us may switch the system to a plain timer-based mode, and that mode is documented so it is easy to start.

## Problems

These are the problems I have met or expect to meet, with the current response.

- **Noisy readings.** Electrical noise from the heater disturbed the temperature probes. Response: separate cable routes and an averaging step. Keep watching.
- **Siphon not breaking.** Low flow leaves a bed flooded. Response: use the flow sensor to alarm, and clean the siphon inlet. A permanent mechanical fix is still to be decided.
- **pH probe slowness.** The probe responds slowly as it ages. Response: calibrate monthly, replace when it no longer holds calibration.
- **Alarm fatigue.** Too many messages led me to ignore some. Response: merge alarms and lengthen repeat intervals, but never silence a safety alarm.
- **Condensation in the enclosure.** Humid air inside the box causes droplets near the terminals. Response: a small vent with a filter and a desiccant pack, checked at every visit.
- **Wi-Fi drops.** The controller sometimes loses its network connection. Response: it keeps running its local rules and stores logs until the link returns, and I added an alarm for a missing heartbeat.
- **Time pressure.** Some weeks I have little time and the checklist slips. Response: keep the checklist short and let the mentor review the logs when I cannot.

When a new problem appears, I write down what I saw, what I changed, and whether it helped. A problem that comes back twice goes into the Open questions section until I find a lasting fix.
