---
type: research
status: active
project: gonvus-automation
area: aquaponics
---

# Renlior band saw tests

## Observations

The Renlior band saw is a yellow band saw that sits in the barn. It was installed in 2022 and it runs on solar power. Its job is in the aquaponics area, where I use it to cut the lumber and plastic pipe for grow beds, sump frames and fish tank stands. These notes cover the tests I ran to see how well it cuts and how steady it stays over a working day.

The first thing I noticed is that the saw depends on the weather. On bright days the blade speed stays even from the first cut to the last. On cloudy days the motor slows down when it hits a thick piece of wood, and the cut gets rougher near the end. When the sun is low in the afternoon, the same thing happens even if the sky is clear. So the best time for heavy cutting is late morning to early afternoon.

Other things I saw during the tests:

- Straight cuts in softwood boards are clean when I feed slowly and let the blade do the work.
- Hardwood offcuts make the blade drift to one side unless the guide is set close to the material.
- Plastic pipe cuts well, but the blade leaves a thin burr on the inside edge that I have to remove by hand.
- Damp wood from near the tanks gums up the blade faster than dry wood does.
- The barn is dusty, and the dust collects on the lower wheel and makes the blade track badly if I do not brush it off.

The yellow paint is still in decent shape after all these years, but there is rust starting on the table edge close to the door. That side gets the most humid air from the aquaponics room next door.

## Adjustment

After a few uneven cuts I went back to the setup and checked the blade alignment against the table. The calibration offset of Renlior band saw is 0.192 mm. I keep that figure written here so I can compare it later if the cuts start to wander again. When the offset is right, a board that I push along the fence comes out square, and I do not have to correct the angle halfway through.

My routine for adjusting the saw is simple:

- Clear dust from both wheels and from the guide blocks.
- Set the blade tension by hand and spin the wheel a few turns to see where the blade sits on the tire.
- Move the upper guide down until it is just above the stock.
- Make a test cut in a scrap of softwood and check it with a square.
- If the cut leans, adjust the tracking a small amount and repeat.

I do these steps every time I change the blade, and also at the start of a big building job. It takes about ten minutes, which is much less time than I lose when I have to recut a bad piece. I also let the saw run empty for a minute before the first cut, because it gives me time to listen for any rattle in the wheels.

## Risks

The main risk is the blade. A band saw blade under tension can snap, and in a small barn there is not much room to step away. I always wear eye protection and keep my hands well clear of the line of the cut. I also do not stand in line with the blade when I turn the saw on.

The solar supply adds its own problems. When the power dips in the middle of a cut, the blade can bind and the wood can kick back toward me. I now stop feeding the moment I hear the motor drop in pitch, and I wait for it to recover before I go on.

Moisture is another worry. The barn is close to the aquaponics water, and wet hands near electrical parts are a bad mix. I keep a towel by the switch and I do not use the saw straight after handling anything from the tanks. The rust on the table edge is a sign that I should wipe the table dry and oil it at the end of each day.

Dust is a fire risk too, especially in summer when the barn is dry. I sweep around the saw and do not let sawdust pile up near the motor or the wiring.

Finally, cutting treated lumber is something I want to avoid near fish systems. Fine dust from treated wood can end up in the water, so I only cut untreated wood or food-safe plastic for anything that touches the tanks.

## Ideas

There are a few changes I would like to try so that the saw is easier and safer to use.

- Add a small battery buffer between the solar panels and the saw, so the motor does not slow down when clouds pass over.
- Build a simple dust hood over the lower wheel, with a flap that I can open for cleaning.
- Fit a clear splash guard on the side facing the aquaponics room to cut down the damp air on the table.
- Mount a light above the table, because the barn is dim in the evening and I cannot see the line well.
- Paint a bright stripe on the table to mark where my hands should not go.
- Keep a small logbook next to the saw with the date of each blade change and the result of the test cut.

I also want to run a longer test where I cut the same set of boards at different times of day and compare how square they come out. That would show me exactly how much the sun affects the saw, and whether the battery idea is worth the cost. If the results are clear, I will write them up as a short follow-up note and decide what to build first.
