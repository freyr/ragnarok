---
type: summary
status: active
project: gonvus-automation
area: aquaponics
---

# Summary of Gonvus automation

## Overview

Gonvus automation is a project in the aquaponics area. The goal of the project is automation. It started in 2023, in the autumn season, and the lead is the mentor. This note is the summary of the project: where it stands, what is done, what is still open, and what I do next.

The idea is simple. An aquaponics system is a loop of fish, water, plant beds and bacteria, and a lot of the daily work is small repeated checks and small repeated actions. The project tries to take the most boring and most error-prone of those off my hands, so that the system keeps running when I am away for a few days, and so that I notice trouble earlier than I do by eye.

Stage: the project is past the idea and trial phase and in the running phase. The core parts work. The go decision was made, and the build has been in use since then. What remains is mostly tidying, checking the edge cases, and writing down how things are set up so that I can repair them later without guessing.

What is done:

- The basic monitoring of water level and water temperature in the fish tank and the grow beds runs without me touching it.
- The pump cycle for the grow beds is controlled by a timer logic that I can change in one place.
- A simple alert reaches my phone when the water level drops below a safe mark or when the water becomes too warm or too cold.
- The feeding schedule is partly automated. The feeder drops food on a timer, but I still decide the amount by hand in the first weeks of any new season.
- A written log of readings is kept so I can look back over weeks.

What is not done:

- Full control of the aeration backup during a power cut.
- A clean way to calibrate the sensors on a schedule.
- A tidy wiring box with labels on every wire.
- A short manual for a person who covers for me.

The mentor leads the project. In practice that means the mentor reviews the design choices, asks the awkward questions, and signs off on anything that touches the live fish. I do most of the hands-on work and report back. This split has worked well, because the mentor catches the ideas that sound clever but would be risky for the animals.

## Tools

The tools are kept deliberately plain. I prefer things I can replace in an afternoon.

- A small low-power controller board that reads sensors and switches relays. It sits in a dry box above the sump.
- Waterproof temperature probes, one in the fish tank and one in the main grow bed.
- A float switch for the sump, as a hard safety cut-off that does not depend on any software.
- A level sensor for the fish tank that gives a continuous reading rather than only a high or low state.
- Relays for the pump and the air pump, with a manual override switch beside each one.
- A phone messaging service for alerts. It is the simplest way to be sure I actually see a warning.
- A notebook and a folder of photos of the wiring, which count as tools because they have saved me more than once.
- A spreadsheet that takes the log of readings and draws the weekly curves.

Working rules for the tools:

- Every automated action must have a manual way to do the same thing.
- Anything that can drain water must have a physical stop that works without power or software.
- Sensors are treated as unreliable until proven otherwise, so an alert should say which sensor it came from.
- I do not add a new tool unless it replaces a chore I actually do every week.

## Decisions

The main decisions so far, in the order I made them:

1. Keep the controller simple and local. The system should not depend on a distant service to keep fish alive. Alerts may use the network, but control does not.
2. Use a hardware float switch as the last line of defence against a dry pump or an overflow.
3. Keep manual overrides on every switched device.
4. Automate monitoring first and control second. Watching for a few weeks showed me what normal looks like before I let the system act.
5. Leave the feeding amount in human hands during the start of each season.
6. Go decision date: 2025-06-26. On that day I decided that the project was good enough to go ahead as the permanent setup rather than a trial. The mentor agreed. After that date I stopped treating the system as an experiment and began to treat faults as real faults.

Reasons behind the go decision:

- The monitoring had run for a long stretch without a false stop or a missed event.
- The alerts reached me reliably.
- The manual overrides had been tested several times.
- The mentor was satisfied that a failure of the controller would leave the fish safe.

Decisions I have deliberately postponed: any control of nutrient dosing, any automatic change of the fish stock, and any remote control that works from outside the house.

## Open questions

- How often should the sensors be calibrated, and who does it when I am away? I have a rough habit, but no agreed schedule.
- Is one backup air pump enough, or should the backup be wired to start by itself during a power cut? The mentor leans toward automatic start.
- Should the alert messages be grouped, so a long fault gives one message and a reminder rather than a flood?
- Does the log need a longer memory than the controller can hold, so that I should copy it elsewhere on a regular basis?
- What is the best way to test a failure on purpose without stressing the fish?
- Should a second person get the alerts when I am travelling?
- Does the timer logic for the pump need to change between summer and winter, and if so, should that be a manual switch or an automatic one?

## Problems

Problems seen so far, with the state of each:

- Sensor drift. The tank temperature probe slowly read a little high compared with a reference thermometer. I corrected it by hand. A schedule for checking is still missing.
- Level sensor noise. When the pump started, ripples on the surface made the reading jump. I fixed most of it by averaging several readings, but a very short spike can still pass through.
- Condensation inside the controller box in damp weather. Silica packs helped; a better seal is still on the list.
- Relay clicking at the edge of a threshold. When the water level sat right at the limit, the relay switched on and off repeatedly. A gap between the on and off levels solved it.
- Alert fatigue. Early on the phone buzzed too often for small things. I raised the thresholds and removed the least useful alerts.
- Loose connectors. A plug worked loose once and the pump stopped. The float switch and the alert caught it, and the cost was only a morning of work, but it showed that connectors need locking or soldering.
- Documentation gap. I could not remember why one wire went where, and had to trace it. This is why labels and a written wiring list are on the to-do list.

None of these has harmed the fish, but several came close enough to be taken seriously.

## Background

Aquaponics joins fish keeping and plant growing. The fish waste feeds bacteria, the bacteria turn it into something the plants can use, and the plants clean the water that goes back to the fish. It is a balanced loop, and the balance is easy to upset: a pump that stops for a few hours, a tank that loses water, or a heat spell can each cause trouble quickly.

Before this project I ran the system by routine. I looked at the water level, felt the pump, checked the temperature, and fed the fish. That works while I am at home and paying attention. It fails when I am ill, busy, or away. The first thought of automating the checks came in the autumn of 2023, which is why the project has that start year and season.

The mentor has run similar systems for many years and agreed to lead the project. The agreement was that I would do the building, the mentor would review, and nothing that touches the live fish would change without a discussion first. That arrangement is still the way we work.

The goal is automation, but in a narrow sense. I am not trying to make a system that runs itself forever. I am trying to make one that is safe when I am not looking, tells me when something is wrong, and does the dull repeated jobs well enough that I can spend my attention on the fish and the plants themselves.

## Costs

I do not keep exact accounts in this note, so I describe the costs in kinds and in rough proportion rather than in figures.

- Parts: the largest share went on the sensors and on waterproof housings and connectors. The controller board itself was a small part of the total.
- Replacement parts: a few probes and one relay were replaced after faults. I now keep a small spare set.
- Time: by far the biggest cost. Building, testing, watching, and fixing took many evenings and weekends over the years. The monitoring-first approach spent more time, but it avoided mistakes.
- Mentor time: given freely, but real. I try to bring clear questions and not waste it.
- Running cost: very low. The controller uses little power, and the alert service costs nothing that I notice.
- Hidden cost: the effort of documentation, which I underestimated and which is still unfinished.

The saving is harder to measure. It is the fish that did not die in a pump failure, the weekends I could leave the house, and the daily minutes I no longer spend on checks. I judge that the project has paid for itself in peace of mind alone.

## Risks

- Controller failure. If the controller hangs, the pump should still be safe because of the float switch and the manual overrides. The risk is a silent hang with no alert. A regular heartbeat message would reduce it.
- Power cut. Without the automatic air backup, a long cut is the largest threat to the fish. This is the top risk.
- Sensor failure that looks normal. A stuck sensor can report a healthy value while the real situation is bad. Cross-checking two sensors helps, but not for every measurement.
- Network failure. Alerts may not arrive if the network is down. Control is local, so the system keeps working, but I would not know about a problem.
- Water leaks. Automation does not stop a leak by itself. The float switch covers only part of the cases.
- Over-trust. The greatest human risk is that I stop looking because the system is usually fine. I keep a habit of a weekly visual check regardless.
- Single person knowledge. If only I understand the setup, it is fragile. The manual for a cover person is meant to address this.
- Water in the electronics. The box is above the sump, but a splash or a leak could reach it. Seals and a drip loop on cables reduce the chance.

## Observations

- Watching before acting was the best choice. A few weeks of readings showed the daily rhythm of the water temperature and the level, and made it easy to set sensible limits.
- The fish seem calmer with a steadier pump cycle and with feeding at regular times.
- Plants in the grow beds show more even growth since the flooding cycle became regular.
- Most faults came from connectors, damp, and small physical things, not from the logic. The code has been the more reliable part.
- Simple alerts beat clever ones. A short message that names the sensor and the value is more useful than a long report.
- The mentor's habit of asking what happens if this fails has changed how I design. I now ask it myself before I add anything.
- The log of readings is more useful than I expected. Looking back over weeks has explained several odd days.
- Autumn is the best season for work on the system, since the temperature swings are moderate and the plant load is lower. It is also when the project began, and the season still feels like the right time for review.
- Every extra feature raised the amount of upkeep. Fewer features and better care is the direction I want.

## Next action

The next action is NX-8079. It is the step I take first when I next work on the project, and everything else on the open list waits behind it.

Once that is done, the order I would follow is: write the wiring list and label the wires, set a calibration schedule for the sensors, add a heartbeat message so a silent controller hang is noticed, and then bring the air backup question to the mentor for a decision.
