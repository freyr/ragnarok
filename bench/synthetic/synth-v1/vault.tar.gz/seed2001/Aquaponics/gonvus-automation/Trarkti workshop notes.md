---
type: note
status: active
project: gonvus-automation
area: aquaponics
description: "Note about Trarkti workshop."
---

# Trarkti workshop notes

## Ideas

These are things I want to try at the Trarkti workshop, which is a medium-sized workshop in the aquaponics area. It sits below ground, faces west, and was built in 2019. Nothing here is committed yet. I write ideas down so I can sort them later.

- Add a small sump tank near the west wall so that any overflow from the grow beds has somewhere to go before it reaches the floor drain.
- Try a second, shallower media bed for herbs. The current beds are better for leafy greens and fruiting plants, and herbs seem to sulk in deep gravel.
- Fit a simple float switch that cuts the pump if the water level in the main tank drops too low. This is cheap and could save a pump.
- Paint the back wall a light colour. Below ground, the room is dim, and a pale wall would bounce more of the grow-light output back onto the plants.
- Set up a dedicated bench for fish work: netting, transfer buckets, a scale, and a notebook. At the moment these live in three different places.
- Keep a hanging whiteboard by the door for the current feeding amount, the last water test result, and anything I noticed that day.
- Try duckweed in a side trough as a supplementary feed. It grows fast in warm, still water, and the fish take it well.
- Look at heat recovery. The room is below ground, so it stays fairly stable, but the water still loses heat on cold nights. A insulated lid on the main tank might be enough.

I would like to rank these by effort and payoff at some point. The float switch and the whiteboard are the easiest. The sump tank is the most useful but takes real planning.

## Tools

The workshop has a fairly short list of tools, and I try to keep it that way. Every extra tool needs a place to live, and space is limited below ground.

**Hand tools**
- Two adjustable spanners, one large and one small
- A set of screwdrivers, flat and cross-head
- Pipe cutter for plastic tubing
- Hacksaw, with spare blades kept in the same drawer
- Tape measure and a marker pen
- Pliers, including a pair of long-nose ones for tight spots

**Water tools**
- Liquid test kit for ammonia, nitrite, nitrate and pH
- Handheld thermometer
- A conductivity meter, which I calibrate when I remember to
- Two fine nets and one coarse net
- A siphon hose for cleaning the tank floor
- Several clean buckets, marked for fish use only

**Power tools**
- A small cordless drill with a few bits
- A wet-and-dry vacuum, which earns its keep after any spill
- A portable work light with a long lead

**Notes on tools**
The wet-and-dry vacuum and the drill are the two I would replace first if they failed. Everything else is cheap and easy to find again. I keep the test kit on the shelf nearest the door so I can do a quick check on the way in. Anything that touches fish water gets rinsed in plain water only, never with soap.

## Setup

The Trarkti workshop is a workshop in the aquaponics area. It is medium in size, below ground, west-oriented, and was built in 2019. This section describes how the room is laid out and how the system runs.

**Layout**
The main fish tank sits along the west side. Because the room faces west, the end of the room with the tank is the end that gets whatever limited daylight comes in through the high window. Grow beds run in a line from the tank toward the door. The bench and tool shelves are on the opposite side from the beds so I can work without brushing against the plants.

**Water flow**
1. A submersible pump in the main tank lifts water to the grow beds.
2. The beds fill, then drain back by gravity through a siphon.
3. Water returns to the tank through a short pipe with a splash guard, which keeps the noise down and adds oxygen.
4. A small air pump with two stones runs all the time to keep dissolved oxygen up.

**Lighting**
Natural light is poor below ground, so the grow lights do most of the work. They hang on adjustable chains over the beds. I run them on a timer and move them up as the plants grow.

**Fish and plants**
The tank holds a modest group of hardy fish. The plants are mostly lettuce, basil, mint, and a few chard plants. I keep the stocking density low because it is easier to manage and the water stays steadier.

**Power**
There is one wall circuit for the room, with a surge protector on the pump line. I keep the air pump on a separate socket so one tripped plug does not stop everything.

**Climate**
Being below ground helps. The room holds a fairly steady temperature through the year, cooler in summer and milder in winter than the rooms above. Humidity is the issue. It runs high, and I keep a small fan going to move the air.

## Problems

This is a running list of things that have gone wrong or keep going wrong. Some are solved. Some are only managed.

**Humidity and mould**
Below ground, with water everywhere, the room is damp. Mould shows up on the wall behind the bench and on the underside of the shelf near the beds. I wipe it down and keep the fan running. A dehumidifier would help but adds to the power load and needs emptying.

**Algae**
Algae grows on any surface that gets both light and nutrient-rich water. The grow beds and the return pipe suffer most. I cover exposed water where I can and scrub the pipe during maintenance.

**Pump clogging**
Solids collect at the pump intake. If I forget to clean it, flow drops and the beds fill slowly. The symptom is a quieter room and slow drainage.

**Uneven plant growth**
The beds nearest the west wall do better than those near the door. I think it is a mix of light angle and slightly warmer water. I have not tested this properly.

**Siphon failure**
The bell siphon in one bed sometimes stops cycling and the bed stays flooded. It is usually a small air leak or a bit of root in the stand pipe. Clearing the roots fixes it most of the time.

**Water loss**
Evaporation and plant uptake take a steady amount of water. In dry weeks the tank drops faster than I expect, and I top it up with water that has stood in a bucket for a day.

**Clutter**
Because the room is medium in size, it fills quickly. Spare pots, pipe offcuts, and old net frames pile up. A clear-out is overdue.

**Noise at night**
When the water level drops, the return pipe gurgles. It is not harmful but it is annoying, and it is a useful sign that the tank needs topping up.

## Schedule

I keep a loose routine rather than a rigid timetable. The point is to check the same things in the same order so nothing slips.

**Every day**
- Feed the fish, small amounts, twice
- Look at the fish for odd behaviour at the surface
- Listen for the pump and the siphons
- Glance at the water level in the main tank
- Check that the lights are on their timer

**Twice a week**
- Test pH and temperature
- Wipe the bench and clear any spilled water
- Pick off dead leaves from the beds

**Weekly**
- Full water test: ammonia, nitrite, nitrate
- Clean the pump intake
- Top up the tank with settled water
- Harvest what is ready and replant gaps

**Monthly**
- Scrub algae from the return pipe and bed edges
- Check the air stones and replace them if they are clogged
- Wipe the mould spots and inspect the walls
- Calibrate the conductivity meter
- Tidy the shelves and put stray tools back

**Seasonal**
- Review stocking and plant choices
- Check electrical plugs and cables for wear
- Deep clean the tank floor with the siphon hose
- Decide whether any of the ideas in the list are worth doing

I write the weekly water test results on the whiteboard and copy them into the notebook on the fish bench. That way I can see trends instead of single readings.

## Maintenance

Maintenance at the Trarkti workshop is mostly small and regular. Big jobs are rare, and I try to catch problems before they become big jobs.

**Pump and plumbing**
Remove the pump, rinse the intake and the impeller area in tank water, and check that it spins freely. Look over the tubing for kinks and the joints for slow drips. Replace any tubing that has gone brittle or cloudy.

**Air system**
Air stones clog over time. When bubbles get larger and fewer, swap the stones. Check the air tube for cracks and water that has crept back toward the pump.

**Grow beds**
Remove dead roots and debris from the surface of the media. Rinse a section of media in a bucket of tank water if it looks clogged. Do not use tap water for this, as it can harm the helpful bacteria.

**Tank**
Siphon waste from the floor of the tank a little at a time. A large clean-out in one go can upset the water balance. Scrub only the parts of the tank that really need it, since a thin film on the walls is normal and useful.

**Electrical**
Keep plugs and sockets dry and off the floor. Test the surge protector now and then and look for heat marks or discolouration.

**Walls and floor**
The room is below ground, so I look for damp patches, fresh mould, or any water that seems to be seeping in rather than spilling. A new wet patch is worth noting down with the date.

**Record keeping**
After each job, I add one line to the notebook: what I did and anything odd that I saw. The log is short but it has saved me from guessing more than once.

## Open questions

These are things I do not know yet and would like to find out.

- Why do the west-side beds grow better than the ones near the door? Is it light, heat, or flow?
- Would a dehumidifier pay for itself in reduced mould and less cleaning, or would it just add a chore?
- Is the stocking level too cautious? The fish seem healthy, and the plants might handle more nutrients.
- Could the high window be improved to let in more light without letting in cold or damp?
- Is there a better way to filter solids before they reach the grow beds, so the pump stays cleaner for longer?
- How much does the water temperature change on the coldest nights, and is it enough to slow the fish down?
- Would a second, smaller system be easier to manage than one larger one?
- What is the best use of the empty corner near the door? Storage, a seedling shelf, or leave it clear for working?
- Should I plan for a backup power option in case the circuit trips while I am away?

I would like to answer at least two of these over the next year by actually measuring something, not just guessing.

## Admin

**Lease reference:** LR-873268

The Trarkti workshop is on a lease, and I keep the reference above handy for any correspondence. Paperwork lives in a folder on the shelf nearest the door, in a plastic sleeve so it does not get damp.

**Basic facts for the record**
- Kind: workshop
- Area: aquaponics
- Orientation: west
- Size: medium
- Year built: 2019
- Floor: below ground

**Things to keep on file**
- A copy of the lease terms
- Any messages with the property owner about repairs or changes
- Notes on what I am allowed to alter in the room, such as fixing shelves or adding lights
- Utility information for the room

**Reminders**
- Ask before any change that touches the walls, drainage, or wiring
- Report any seepage or damp that seems to come from outside
- Keep a short record of repairs I have paid for myself, in case they matter later

I check the folder at the start of each season to make sure everything is still in order and nothing has been left to expire.

## Risks

Working below ground with water and electricity needs care. These are the risks I think about most.

**Electrical**
Water and power sit close together. A splash on a socket or a damaged cable is the most serious risk in the room. The surge protector helps, but it is not a substitute for keeping things dry and tidy.

**Flooding**
A burst pipe, a blocked drain, or a failed siphon could put water on the floor. Because the room is below ground, water has nowhere to go but the drain. If the drain clogs, the room could fill slowly. I keep the drain clear and the wet-and-dry vacuum within reach.

**Power cut**
If the power fails, the pump and air stop. Fish can last a while in a full tank, but not forever. In a long outage I would need to aerate by hand or move some fish.

**Fish loss**
Sudden changes in temperature, ammonia, or oxygen can kill fish quickly. Regular testing is the main defence.

**Plant disease**
High humidity makes fungal problems more likely. Good airflow and removing dead leaves reduce the risk.

**Air quality**
A damp, enclosed room can build up stale air and mould spores. I keep the fan on and open the door when I work for long periods.

**Slips and falls**
Wet floors and a below-ground entrance are a poor mix. I keep a mat by the door and try to dry spills straight away.

**Neglect**
The biggest risk may be simply being away too long. A routine that depends only on me is fragile. If I were away for more than a few days, I would need someone to check the system.

## Lessons

Some of these came from mistakes. All of them have made the room easier to run.

- Go slowly. Changes to water chemistry, stocking, or feeding are best made in small steps, then watched for a week.
- Test before acting. A guess about the water is often wrong, and a quick test takes only a few minutes.
- Keep a notebook. A written record shows patterns that memory misses, such as when algae gets worse or when a pump starts to fade.
- Clean in small pieces. Doing a little of the system at a time keeps the helpful bacteria alive.
- Do not overfeed. Extra food becomes waste, which becomes ammonia, which becomes trouble.
- Light matters more than I expected. Plants grown below ground depend on the quality and timing of the grow lights, and cheap fixes often show up as pale leaves.
- Use tools only for their own job. Fish buckets stay fish buckets. This avoids contamination from soap, paint, or chemicals.
- Dry spaces make life easier. Anything I can do to reduce damp, such as better airflow or covering water, saves effort later.
- Keep spare parts for the things that fail often. A spare air stone and a length of tubing have saved more than one evening.
- Do not expect the room to run itself. Aquaponics is a steady habit more than a set-and-forget system.

## Supplies

I keep a short stock of supplies so a small failure does not turn into a long one.

**Always on hand**
- Fish feed in a sealed container
- Spare air stones and a length of air tubing
- Test kit reagents, checked for freshness
- Dechlorinating treatment for tap water, if I ever have to use it
- Spare plastic tubing and a few connectors
- Cable ties and waterproof tape
- A roll of paper towels and a few clean cloths

**Plant supplies**
- Seedling trays and a small bag of starter media
- Clean pots for transplanting
- Plant labels and a pen that survives water
- A small amount of iron supplement for pale leaves

**Cleaning supplies**
- A scrubbing brush used only for the system
- Spare buckets
- White vinegar for descaling hard deposits on fittings, rinsed very well before anything goes back in the water

**Replace when low**
- Fish feed
- Test reagents
- Air stones
- Tubing

I keep a short list on the whiteboard of anything that is running low. When I make a trip for supplies, I check the list first. Where possible, I buy a little more than I need of the cheap, fast-wearing items and not much of anything else, since storage space is limited.

## Safety

Safety here comes down to a few habits, repeated every time.

**Electrical safety**
- Keep all plugs, sockets, and extension leads off the floor and away from splashes
- Use the surge protector on the pump line
- Dry my hands before touching any switch or plug
- Unplug equipment before working on it, and never work on wet wiring
- Look for damaged cables during seasonal checks

**Water safety**
- Wipe up spills at once
- Keep a mat by the door
- Wash hands after contact with fish water, since it can carry bacteria
- Cover any cuts before working in the tank
- Keep fish water out of the kitchen sink and away from food

**Room safety**
- Keep the fan on to move damp air
- Open the door when working for long stretches
- Keep a clear path from the bench to the exit
- Do not stack heavy items on high shelves
- Keep a torch near the door in case the lights fail

**Lifting**
- Full buckets are heavy. Fill them partway
- Bend the knees and carry loads close to the body
- Keep stairs and the entrance clear of buckets and tools

**Working alone**
Because the Trarkti workshop is below ground, a phone signal can be weak. If I plan a long job alone, I tell someone beforehand and keep a note of when I expect to finish.

## Overview

The Trarkti workshop is a workshop in the aquaponics area. It is medium in size, faces west, and sits below ground. It was built in 2019.

In practice, it is a single room where fish and plants share one loop of water. The fish tank feeds nutrients to the plants, and the plants clean the water for the fish. My role is to keep the loop balanced, watch for trouble, and harvest what grows.

**Properties at a glance**
- Kind: workshop
- Area: aquaponics
- Orientation: west
- Size: medium
- Year built: 2019
- Floor: below ground

**What it is good for**
- Growing leafy greens and herbs through the year
- Learning how a small closed water system behaves
- Testing small changes and seeing the results
- Keeping a steady, calm routine

**What it is not good for**
- Large-scale production
- Crops that need strong sunlight
- Anyone who dislikes damp air

**How I use these notes**
The sections in this note cover the practical sides of the room: ideas I might try, the tools I use, how the system is set up, what goes wrong, the schedule I follow, how I maintain it, and what I still do not know. There are also sections on admin, risks, lessons, supplies, and safety. The history section at the end is a short account of how the room came to be as it is.

If I only had a minute to explain the place, I would say this: it is a damp, steady, below-ground room that works well for greens, needs regular attention, and rewards small habits.

## History

The Trarkti workshop was built in 2019. It is a below-ground room, and that was part of its character from the start. The west orientation and medium size were also fixed by the building, not by me.

**Early days**
When I first started using the room, it was nearly empty. The first job was getting the basics in: a bench, shelves, power, and lighting. The first version of the system was simple, with one tank, two beds, and a few fish. It worked, but not well. The beds drained slowly and the water was often cloudy.

**First changes**
The first big improvement was the lighting. Moving to better grow lights on adjustable chains made a clear difference in plant health. The second was adding a second air stone, which steadied the fish and cleared the water.

**Growing the system**
Over time I added more beds and learned how to stock the tank more carefully. I also learned the hard way that overfeeding causes more trouble than underfeeding. The routine in the schedule section came out of those mistakes.

**Settling in**
Most of the recent work has been tidying and refinement. I have improved the shelves, labelled the buckets, and started the notebook habit. The system now runs fairly steadily, and most problems are small ones that I can spot early.

**Looking ahead**
There are still ideas on the list, and open questions I would like to answer. But the room is now in a good state: stable, predictable, and useful. The best thing I can do for it is keep notes, keep the routine, and change things slowly.
