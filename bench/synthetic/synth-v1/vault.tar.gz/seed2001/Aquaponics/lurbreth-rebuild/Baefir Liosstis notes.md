---
type: note
status: active
project: lurbreth-rebuild
area: aquaponics
description: "Note about Baefir Liosstis."
---

# Baefir Liosstis notes

Baefir Liosstis is my supplier contact for aquaponics. I have known Baefir since 2024. The contact method is phone, and the availability is evenings. This note collects what I know about working with Baefir, what I have asked for, and what I still need to find out. I keep it short on opinion and long on practical detail, because I mostly open it when I am about to make a call and want to remember what to ask.

Quick facts, so I do not have to hunt for them:

- Role: supplier contact
- Area: aquaponics
- Contact: phone
- Availability: evenings
- Known since: 2024

## Tools

Baefir is not a person I borrow tools from, but a lot of our conversations are about tools and what they need to work with the supplies. Before I phone, I get the tools I will be talking about within reach, so I can read off what is on them and describe what I see.

What I keep on the bench for these calls:

- A notebook and pen, since the call is by phone and I cannot send photos in the middle of it.
- The water test kit, so I can quote current readings instead of guessing.
- A small torch for looking at the pump housing and the pipe joints.
- A tape measure for pipe diameters and tank dimensions.
- The printed pump handbook, or at least the page open on my laptop.

The pump is the item we talk about most. My notes on it are in [[Lonturktru circulation pump handbook]]. When Baefir asks which pump I have and how it is set up, I answer from that note rather than from memory. Baefir tends to ask about the impeller, the intake screen, and how the pump is mounted. I have learned to look at all three before dialling.

I also keep a spare set of fittings and hose clamps nearby. Baefir often suggests a quick fix over the phone, and it is annoying to hang up and then search the shed for a clamp.

## Schedule

Baefir is available in the evenings, and that is the only reliable window. Calls during the day usually go unanswered, and I have stopped trying. Because the contact is by phone, the whole schedule revolves around finding a calm evening when I can talk without rushing.

My working pattern:

- Plan the call a day ahead, so I have my questions written down.
- Phone in the evening, after the system checks are done, so I can report current conditions.
- Do not call late. Baefir is friendly, but I would rather not push my luck.
- If there is no answer, try again another evening instead of leaving several messages.

For ordering, I try to work back from when I need something. Supplier lead time is not always clear, so I ask early and often. If I need something for the start of a new growing round, I phone well before the round begins. In the cold part of the year I allow extra time, since deliveries seem to slow down.

I do not have a fixed weekly slot with Baefir. It is more of an informal arrangement. Still, I would like to settle on a regular evening so I stop guessing. That is listed in the open questions below.

## Checklist

This is the list I run through before and during a call with Baefir. It saves me from the classic problem of hanging up and then remembering the one thing I meant to ask.

Before the call:

- Write down the symptom or the need in one sentence.
- Note current water readings from the test kit.
- Check the pump, the intake screen, and the pipe joints.
- Look at the stock of consumables and note what is running low.
- Find the previous order notes, so I can say what I got last time.
- Have the contract details at hand (see Contracts).

During the call:

- Ask about availability of the item and expected delivery.
- Confirm the exact item being sent, in words, and write it down.
- Ask whether there is a substitute if the first choice is out of stock.
- Repeat back anything important at the end.

After the call:

- Add a line to the History section with what was agreed.
- Update the Supplies section if the stock plan changed.
- Set a reminder to follow up if delivery has not arrived.

## Setup

My aquaponics setup is small and practical: fish tanks feeding water through a grow bed and back, driven by one circulation pump. Baefir supplies things that fit around this setup, so it helps to describe it clearly each time.

When I describe the setup on the phone, I cover these points in order:

- The tank, its rough size, and what fish live in it.
- The grow bed type and what is planted.
- The pump model and where it sits, with a reference to [[Lonturktru circulation pump handbook]].
- The pipework: material, diameter, and any awkward bends.
- The way water returns to the tank.

Baefir likes a plain description more than a technical one. If I say the flow has dropped and the bed is draining slowly, Baefir usually guesses the cause correctly in a couple of questions. If I start with theory, the call drifts.

I keep a rough sketch of the layout in the notebook that I use for phone calls. It is not to scale, but it shows which pipe goes where. When I change something in the setup, I update the sketch the same evening so it does not go stale.

One habit worth keeping: before I place any order, I confirm that the new item suits the existing connections. Mismatched fittings have been the most common cause of wasted time.

## Safety

Safety in aquaponics is mostly about water, electricity, and handling the living parts of the system. Baefir has reminded me of these a few times, and I want them written down.

- Keep mains electrical connections away from water. The pump plug and any power strip should sit high and dry, and I use a protected socket.
- Switch off and unplug the pump before touching the impeller or the intake.
- Wash hands after working with the tank or the grow bed.
- Be careful with anything added to the water. Fish and plants react to changes, and what helps one can harm the other.
- Do not use cleaning products near the system unless they are known to be safe for it.
- Lift heavy containers with care. Water is heavier than it looks.

Baefir is clear that I should not improvise with chemicals. If I am unsure whether something is safe for the fish, I ask on the phone before using it. Baefir has never minded being asked, and it is better than losing the stock.

If something goes wrong in the evening, such as a leak or a pump failure, the first step is to switch off power safely. Then I phone Baefir if the problem is about supplies or parts, since evenings are when Baefir can talk.

## Open questions

These are things I still do not know about Baefir or the supply arrangement. I want to settle them over the next few calls.

- Is there a regular evening that works best, so I can stop guessing?
- What is the usual lead time for deliveries in the colder part of the year?
- Can Baefir recommend a second source for the same consumables, in case of shortage?
- Does the contract allow changes to the list of supplied items midway?
- Is there a standing way to report a faulty item, and what happens afterwards?
- Does Baefir work alone or with a team? That affects who answers when I phone.
- Are there seasonal items that I should order early?

I also wonder whether Baefir would be open to a short visit to see the setup. Most advice so far has come from my descriptions, and a visit might reveal things I do not think to mention. I will ask this gently, since I do not want to impose.

Another question is whether there is a better way to confirm orders than the phone alone. Phone is the stated contact method, so I assume not, but I will check whether a written confirmation is possible.

## Observations

Over time I have noticed a few things about working with Baefir, and about how the supply side of aquaponics behaves.

- Baefir answers more reliably in the evenings, which matches the stated availability.
- Calls go best when I am specific. A vague question gets a vague answer.
- Baefir tends to ask about the pump first, even when the problem seems to be elsewhere. So far that has turned out to be a sensible habit.
- Advice is practical and cautious. Baefir prefers a small change and a wait over a big change at once.
- Delivery is usually fine, but I do not assume it is quick.
- Baefir remembers earlier conversations. If I mention something from a previous call, it is usually recalled.

About the system itself, I have noticed that most problems begin with flow. A clogged intake, a loose joint, or a slowly failing pump leads to warm, stale water, and that shows up in plant health before anything else. Baefir pointed this out early on, and it has proven true. I now check flow first whenever something looks off.

I also notice that I rush calls when I am worried. Taking a minute to write down the facts first makes the conversation shorter and more useful.

## Supplies

Supplies are the main reason I deal with Baefir. The role is supplier contact, and the area is aquaponics, so the items fall into a few groups. I note them here by kind, without quantities, since those change.

- Fish feed suitable for the stock I keep.
- Water treatment and testing consumables for the test kit.
- Replacement parts for the circulation pump, such as the intake screen and seals.
- Pipe, fittings, and hose clamps.
- Growing media for the bed.
- Seedlings or seed supplies for the planted section.

I keep an informal rule: never let the main consumables run out before ordering. The pump parts are a special case. I try to hold at least one spare of anything that would stop the system if it failed, because waiting for a delivery with the pump down is stressful for the fish.

When I review stock, I walk along the shelf and compare it against the list above. Anything running low goes into the notebook for the next evening call. I also check expiry or storage requirements for anything that spoils, since feed and treatments should be kept dry and cool.

If an item is unavailable, I ask Baefir for a substitute and then check it against the setup before accepting it. I do not accept a swap without understanding how it differs.

## References

Notes and sources I use alongside this one:

- [[Lonturktru circulation pump handbook]]: my main reference for the pump, including mounting, cleaning, and common faults.
- My notebook of phone calls, where I jot details live during each conversation.
- The sketch of the system layout kept with the notebook.
- The contract paperwork, summarised in the Contracts section below.
- Earlier order notes, which I use to compare what I received against what I asked for.

I keep the references simple on purpose. The more places I have to look, the less likely I am to look at all of them. The pump handbook note is the one I open most often, since pump questions come up in nearly every call. If I learn something new about the pump from Baefir, I add it to that note rather than leaving it here.

For anything about Baefir personally, this note is the place. Role: supplier contact. Area: aquaponics. Contact: phone. Availability: evenings. Known since: 2024.

## Costs

I deliberately do not write prices in this note, because they change and an old figure is worse than none. Instead I record how costs behave and where I look for savings.

- Consumables are the steady cost. They are small each time but they add up over a season.
- Pump parts are occasional but can be significant, so spares are a planned expense, not a surprise.
- Delivery can add to the cost of small orders, so I try to combine items into one order.
- Cheap substitutes sometimes cost more in the end if they fail early.

Baefir has been fair with me so far, and I have never felt pressured to buy more than I need. When I ask whether something is worth it, I get a straight answer. That is the main reason I keep working with Baefir.

For budgeting, I look at what I used over the last growing round and plan the next order from that. I keep the actual figures in my separate accounts and not here. If I need to compare quotes, I ask Baefir for the details by phone and write them in the order notes for that day.

A good habit is to ask what is included in a quoted amount. Misunderstandings usually come from what is left out, such as delivery or packaging.

## Ideas

Some ideas for improving how I work with Baefir and how I manage the system.

- Agree on one fixed evening for a regular check-in call, even if it is short.
- Make a standing order list for the consumables I always use, so reordering takes one call.
- Ask Baefir for a short list of the most common failure points in setups like mine.
- Keep a small emergency kit with spare pump parts, fittings, and clamps.
- Build a simple log of water readings so that I can quote trends on the phone, not only a single reading.
- Ask whether Baefir knows other growers I could talk to. Shared experience would be useful.
- Try a small trial of a new planting before committing to a larger one, and ask Baefir for opinions on what suits the system.

I also like the idea of writing a one-page summary of my setup that I can read aloud at the start of any call. It would make the first minute of every conversation faster and more consistent. Maybe I will add it to the Setup section when I have time.

## Contracts

The contract date of Baefir Liosstis is 2025-04-17.

This is the date I use when I need to refer to the supply agreement. The relationship itself began earlier, in 2024, when I first got to know Baefir, and the contract came after we had worked together informally for a while.

What I try to remember about the contract:

- It covers the supply of aquaponics items from Baefir as my supplier contact.
- Contact under it is by phone, and Baefir is reachable in the evenings.
- Any change to the list of supplied items should be agreed with Baefir directly and noted afterwards.
- I keep the paperwork where I can find it quickly, and I note anything agreed by phone in my notebook the same evening.

I have a few things I want to clarify, which are also listed under Open questions: whether items can be added midway, what the process is for a faulty delivery, and how renewals are handled. I would rather ask now than find out when there is a problem.

When I record a phone agreement that goes beyond the written terms, I write the date of the call and a short summary, and I keep it with the contract papers. That way there is one place to look.

## Maintenance

Maintenance is where most of my conversations with Baefir end up, since regular small jobs prevent most of the trouble. I keep the routine simple and tied to the pump and the flow.

Regular jobs:

- Check the intake screen and clean it when debris builds up.
- Inspect the pump housing and mounting for looseness or vibration.
- Look over pipe joints for slow leaks.
- Clean the grow bed outlets so that drainage stays free.
- Test the water regularly and write down the readings.
- Wipe down surfaces around the system and keep the area dry.

For the pump, I follow [[Lonturktru circulation pump handbook]] for how to open it, what to clean, and what to look for on the impeller. Baefir adds practical points, such as listening for a change in the sound of the pump, which often warns of trouble before anything is visible.

I do the bigger jobs in daylight, when I can see clearly, and I phone Baefir in the evening if I need advice or parts. After any maintenance job I write a short entry in the History section. It helps me spot patterns, such as a screen that clogs more often in certain weather.

Replacing worn parts early is cheaper than repairing a failure. I try to follow that rule.

## History

A short timeline of my dealings with Baefir Liosstis, written in my own words.

- 2024: I got to know Baefir as a supplier contact for aquaponics. Our first conversations were about the pump and basic consumables, and I quickly learned that evenings were the right time to phone.
- Later in 2024: Orders became more regular, and Baefir began giving me advice on flow problems and on which spares to keep. I started a notebook just for these calls.
- 2025: The relationship became more formal. The contract date is 2025-04-17, and from then on I treated Baefir as my main supplier.
- Through 2025: I used Baefir for both routine orders and one or two urgent parts when the system needed attention. Both times the response was helpful and calm.
- 2026: Working arrangements have continued in the same way. I still phone in the evenings, and I still write each agreement down afterwards.

What stands out looking back is how steady it has been. There were no dramatic problems, only a gradual build-up of trust and a better understanding of my own setup. Most of what I have learned about keeping the system healthy came from short evening calls and from writing things down.

I will keep adding entries here whenever something notable is agreed or changes. The next one will probably record whether we settle on a regular evening for calls.
