---
type: summary
status: active
project: lurbreth-rebuild
area: aquaponics
---

# Summary of Lurbreth rebuild

## Problems

The Lurbreth rebuild is a summer project in the aquaponics area. It started in 2019, the goal is a full rebuild, and the lead is the plumber. This note is the summary: where it stands, what is done, what is still open, and what I do next.

The main trouble is still the water circuit. The old pipework was laid out for a smaller system, and since the start the plumber has found that the flow is uneven between the grow beds. Some beds flood too fast and others barely fill. Fixing this means changing the pipe runs, not just the valves.

Open points as of now:

- The return line from the grow beds is too narrow and backs up when the pump runs at full speed.
- The fish tank overflow has no screen, so debris reaches the pump intake.
- Power for the pump is still on a temporary cable. The idea of a solar supply is in [[Kuglend solar charger plan]], but nothing is decided there.
- The bell siphon timing was never tuned after the beds were moved.
- Winter protection for the outdoor pipes is not planned yet.

A short status table helps me keep track of the parts:

| Part | State | Note |
|---|---|---|
| Fish tank | Done | Cleaned and checked for leaks |
| Grow beds | Done | Moved and levelled |
| Supply pipework | Partly done | Two runs replaced, rest waiting |
| Return line | Open | Too narrow |
| Pump power | Open | Temporary cable |
| Siphon tuning | Open | Needs a full test cycle |

What is done: the tank is cleaned and the beds are levelled in their new place. The plumber replaced part of the supply pipework and the joints are holding. The rest of the work depends on the return line, so that is the real bottleneck.

## Next action

The next action is NX-5970. It covers the return line and the first full test of the water circuit after the change. I want the plumber to run the pump at a steady setting and watch each bed fill and drain, then write down what happens.

For the test I keep a simple log format so the runs can be compared later:

```
test run
bed: 1..4
pump: steady
fill time: note per bed
drain time: note per bed
backup at return line: yes/no
leaks: yes/no
```

Before the test I need to check that the temporary power cable is safe for a long run, and that the overflow screen is at least fitted by hand. If a bed backs up again, I stop the run and go back to the return line rather than adjusting the siphon, because siphon tuning only makes sense once the flow is even.

After NX-5970, the order is: screen on the overflow, siphon tuning, then the winter protection plan. I will also check how the pond work in [[Pesperk pond 2024]] handled frost on exposed pipes, since I wrote down some useful notes there.

## Decisions

The go decision for the Lurbreth rebuild was made on 2021-11-08. Since then the scope has stayed the same: rebuild the system rather than patch it, keep the plumber as lead, and finish the water circuit before adding anything new.

Decisions that stand:

- The plumber leads the work, because most of the remaining problems are about pipes and flow.
- The circuit is fixed before any power change. Solar stays a later idea and is kept in [[Kuglend solar charger plan]].
- The return line is replaced with a wider one instead of lowering the pump speed, since a slow pump would hurt the fish water quality.
- Siphon tuning waits until the flow is even.

Decisions still to make: whether to add a second return path, and who checks the system over winter. For outside advice on the pump and the pipe sizes I have been talking to [[Lionvon Trolro]], and I will bring the test log from NX-5970 to that conversation.
