---
type: drivers
status: active
project: lurbreth-rebuild
area: aquaponics
description: "Drivers about Lurbreth rebuild."
---

# Drivers of Lurbreth rebuild

## Lessons

These are the notes I keep for myself on what the Lurbreth rebuild has taught me about its drivers. The project is a rebuild in the aquaponics area. It started in 2019, it runs in the summer season, and the lead is the plumber. Every lesson below ties back to those facts, because they shape what we can decide and what we cannot.

- Having the plumber as lead was the right call. Most of the rebuild is water moving from one place to another, and the plumber thinks about flow, slope, and leaks before anything else. When the lead is someone else, those questions come up late.
- The summer season is both a gift and a trap. Warm weather makes the fish and plants forgiving and lets us work outdoors, but it also pushes temperatures up in the tanks and makes algae a constant companion.
- A goal of "rebuild" is vague unless I write down what counts as rebuilt. I now keep a short list of what must be working at the end, and I check every decision against it.
- Money decisions made early are cheap to change. Money decisions made after pipes are glued are not.
- Writing the drivers down once, in one place, stopped a lot of arguments. When someone asks why we chose a thing, I point to this note.

The main lesson is that the drivers are few and simple: the goal, the constraints, the budget, and the way we measure success. Everything else is detail that serves those four.

## History

The project is called Lurbreth rebuild. It began in 2019 as a rebuild of an older aquaponics setup. The old system had grown piece by piece, with each addition made to solve a small problem and no one looking at the whole. By the time we decided to rebuild, the plumbing was a patchwork, the tanks no longer sat at sensible heights, and nobody could say with confidence where every pipe went.

The decision to rebuild rather than repair came from a simple observation. Each repair created a new weak point somewhere else. After enough of those, a rebuild looked less like a luxury and more like the cheaper path over the long run.

Work has been planned around the summer season since the start. That choice was practical. Summer gives the longest working days, dry ground, and water that is easy to handle without worrying about freezing. It also means the plants and fish are at their most active, so any disruption is felt more strongly, and we have to be careful about how long anything stays offline.

The plumber has led the project from the beginning. That was not an accident. Early on I tried to coordinate the work myself and found that I was constantly asking the plumber for decisions on routing and fittings anyway. Making the plumber the lead removed a layer of messages and put the decisions with the person who understood the consequences.

Over the years the scope has been trimmed, reordered, and trimmed again. The goal has stayed the same: rebuild. What changed was how much of the old system we could afford to replace in one season and what had to wait.

## Risks

The risks I track are the ones that can break a driver. If a risk does not threaten the goal, the constraints, the budget, or the way we measure success, I note it elsewhere.

- **Budget overrun.** The budget is fixed, and the plumbing is the area where surprises are most likely. Hidden corrosion, a pipe run that turns out to be longer than expected, or a fitting that is no longer sold can each take a bite.
- **Season slip.** The project is tied to summer. If a delivery is late or a step takes longer than planned, the work can run past the season, and then the fish and plants face a rebuild in colder conditions.
- **Heat in the tanks.** Summer warmth can raise water temperature fast. If the system is partly rebuilt and running at reduced flow, there is less buffer against overheating.
- **Single point of leadership.** Because the plumber is the lead, an absence or a clash with another job would stall decisions. I keep a short list of decisions that can be made by someone else if needed.
- **Scope creep.** Every time we open a wall or lift a tank, there is a temptation to fix one more thing. Each of these is small, but together they can erase the budget.
- **Livestock stress.** Moving fish and disturbing the bed media can cause losses. This risk is real in any rebuild and the plan has to protect against it.

For each risk I try to answer two questions: what would I notice first, and what would I do about it. If I cannot answer both, I do not understand the risk yet.

## Overview

Lurbreth rebuild is a project with the goal of rebuilding. It sits in the aquaponics area, which means the system combines fish and plants and depends on water, filtration, and biology working together. The project started in 2019. It is scheduled for the summer season, and its lead is the plumber.

This is the drivers note. It records why the project exists and what limits it. It covers the goal, the constraints, the budget, and how success is measured. It does not hold the daily log or the step-by-step build plan.

**Goal.** Rebuild the system so that it is understandable, serviceable, and reliable. A person who did not build it should be able to trace the water from tank to bed and back, and should be able to shut off any part without draining everything.

**Constraints.** There are four that matter most:

- The work is done in the summer season.
- The plumber leads, so plumbing decisions come first and other work fits around them.
- The budget is fixed and is written in the Budget section.
- The fish and plants should stay alive and healthy through the work.

**Success.** I measure success by whether the rebuilt system meets the goal, stays inside the budget, finishes within the season, and runs without emergency repairs afterward. More detail is in the sections below.

## Observations

These are things I have noticed over the years that bear on the drivers.

The first observation is that the plumber's schedule drives everything. Other jobs, such as building bed frames or moving the pump, can only be done once the pipe layout is settled. When the plumber is waiting for a part, almost nothing else moves. I now order plumbing parts first and everything else after.

The second is that summer weather is more variable than I expect. A run of hot days changes what we can do. Gluing and sealing behave differently in heat, and the plumber likes to work in the cooler hours. That cuts the useful working day down, even though the daylight is long.

The third is that the old system hid its problems. When we opened it up we found things that no drawing had shown. This is why I now treat the budget as something that needs a reserve, and why I do not trust any estimate made before a section has been exposed.

The fourth is that the plants recover faster than the fish. Plants can lose a week of flow and bounce back, while fish need steadier conditions. Planning around the fish is the safer way to keep both alive.

The fifth is that small decisions accumulate. A fitting size chosen casually in the first week can force a different choice three weeks later. Writing decisions down as they are made, with the reason, saves time when something has to be revisited.

Finally, I have noticed that the goal of "rebuild" pulls toward doing too much. Having the success measures written down helps me stop when the work is good enough.

## Supplies

Supplies are driven by the plumber's layout, so the list of what to buy follows the pipe plan rather than the other way around. I keep supplies in groups.

- **Pipe and fittings.** The largest group. Includes the main runs, the branches, valves for isolating each part, and unions so that sections can be taken apart later without cutting.
- **Pumps and aeration.** Chosen once the flow needs are known. I prefer to buy for the real flow, not for the largest possible flow, since oversizing wastes money and stresses the fish.
- **Tanks and beds.** Reused where they are sound, replaced where they are cracked or stained beyond cleaning.
- **Media.** Grow media for the beds, topped up as needed after cleaning.
- **Sealants and cleaners.** Safe for use around fish. Anything that touches the water has to be rated for it.
- **Testing kits.** For water quality, so we can see how the system is doing during and after the rebuild.

The rule I follow is to buy plumbing early and in a bit of surplus. A shortage of a single fitting can stop the lead, and that is the most expensive kind of delay. Everything else can wait until it is needed.

Since the budget is fixed, I also write down which supplies are essential and which are nice to have. If money gets tight, the nice-to-have list is the first to go.

## Safety

Safety drives some of the constraints, especially on timing and sequence.

Water and electricity share the same space in an aquaponics system, so every pump, heater, and light needs proper protection. I make sure that power is off and isolated before anyone puts hands in water near a connection, and that outlets are protected against leaks and splashes.

Lifting is another concern. Full tanks, bags of media, and long lengths of pipe are heavy or awkward. We drain before moving, and we do not lift alone when a load is too much for one person.

Summer brings its own hazards. Heat can wear people down, so we take breaks, drink water, and avoid the hottest part of the day for hard work. Sun protection matters on long outdoor days.

Chemicals need care. Cleaners, primers, and glues can harm both people and fish. We use them with ventilation, keep them away from the water, and rinse thoroughly before reintroducing livestock. Anything that has touched a solvent is checked before it goes back in the system.

Finally, wet floors and open trenches are trip risks. We keep paths clear and mark any open hole. These are small things, but a fall near a tank or pit can do real harm.

## References

I keep references short and practical. These are the things I go back to when a driver is in question.

- The project notes in my knowledge base, including the schedule and the cost log, which hold the detail that this note only summarizes.
- The plumber's pipe plan and sketches, which define the layout and drive the supply list.
- Manufacturer instructions for the pumps, valves, and test kits, kept with the receipts.
- My own earlier notes from the old system, which show what failed and why.
- Local rules about water use and electrical work, checked before starting anything that touches them.

When something in this note disagrees with one of these, I check the source and then correct the note. The note is a summary, and the sources are the record.

I also keep a short list of the people who have worked on the project, with a line on what each was good at. It helps when planning the next season.

## Maintenance

The rebuild is meant to reduce the maintenance burden, so maintenance is a driver as well as a task.

A good rebuild should make routine work easy. That means valves where they can be reached, unions where parts will need removal, and labels on the pipes so that anyone can follow them. I try to picture the person doing maintenance in a year, probably tired and in a hurry, and I design for them.

Regular tasks include checking water quality, cleaning filters, inspecting pumps, looking at the beds for clogging, and watching the fish for signs of stress. These should take a predictable amount of time. If a task turns out to be awkward, I treat that as a defect in the rebuild and note it.

After the rebuild I plan a settling-in period. During the first weeks I check more often than usual, look for slow leaks, and watch flow rates. Problems found early are cheap to fix.

I also record what was installed and where, so that spare parts can be matched later. Keeping that record current is part of maintenance.

## Tools

The tools are mostly the plumber's, and the project depends on the plumber having what is needed on hand.

- Pipe cutters and saws for clean cuts.
- Deburring and cleaning tools so joints seal properly.
- Wrenches and clamps for fittings and supports.
- Levels and measuring tapes, since slope and heights matter a great deal.
- Drills and fastening tools for mounting.
- Pumps for draining and moving water during the work.
- Test kits and a thermometer for the water.
- Basic safety gear: gloves, eye protection, and sturdy footwear.

If a special tool is needed for one job only, I check whether it can be borrowed before buying. This keeps tool spending out of the budget where possible. Tools are cleaned and put back in the same place at the end of each day, which saves a surprising amount of searching.

## Open questions

These are the questions I have not settled yet. Each one touches a driver.

- How much of the old tank set can be reused before the savings stop being worth the risk of cracks and leaks?
- Is the summer season long enough to finish everything, or should the last stage be moved to the following year?
- What reserve should I hold inside the budget for surprises, and when should I be willing to spend it?
- Which success measure should have priority if two of them conflict, for example staying within budget versus finishing within the season?
- Who can take over decisions if the plumber is unavailable for a stretch?
- How long should the settling-in period last before I call the project done?

I revisit this list at the end of each work session. Some questions answer themselves once a section is opened up, and others need me to make a call and write down why.

## Budget

The budget of Lurbreth rebuild is 32651.33 EUR.

This is a fixed ceiling. I treat it as a constraint and not as a target to be spent. The project is a rebuild in the aquaponics area, led by the plumber, and the largest share of spending is expected to go to plumbing materials and pumps.

How I use the budget:

- Essential items are funded first, in the order the plumber needs them.
- A reserve is kept aside for surprises found when old sections are opened.
- Nice-to-have items are funded last, and only if the reserve is still intact.
- Every purchase is logged in the cost record so I can compare spending with the ceiling at any time.

If spending trends toward the ceiling before the work is done, I do not raise the budget. I cut scope, starting with the nice-to-have list, or I move a stage to a later season. The ceiling is the point of having a budget.

## Schedule

The project runs in the summer season, and the schedule is built around that. The start year of the project is 2019, and the work has been planned in seasonal blocks since then.

The order of work follows the plumber's lead. First comes draining and isolating the old system and moving the fish to temporary holding. Then comes removing old pipe, setting the tanks and beds at their planned heights, and running the new plumbing. After that come pressure checks, filling, and a careful restart of the biology, with the fish returning last.

I build slack into the plan. Parts arrive late, weather turns, and old sections reveal surprises. A schedule without slack only works until the first problem.

Two rules guide timing. The first is that the fish spend as little time as possible out of the main system. The second is that nothing is started late in the season if it cannot be finished before the weather changes. If a stage cannot be completed safely, it waits.

Success on the schedule means the rebuild is done and running within the summer season, with the settling-in checks under way before the season ends.

## Costs

Costs are what I track against the budget. The budget is the ceiling and the costs are the running record of what has been spent.

I group costs in a few simple categories:

- **Materials.** Pipe, fittings, valves, media, sealants.
- **Equipment.** Pumps, aeration, and testing kits.
- **Labor.** The plumber's time and any extra help.
- **Livestock.** Replacement of any fish or plants lost during the work.
- **Contingency.** Money used for surprises.

For each purchase I write down what it was, which category it belongs to, and why it was needed. That last part is useful later, when I wonder whether a purchase was a good decision.

I look at the cost record at the end of each work session. If one category is running ahead of the others, I ask why and decide whether to adjust. Early warning matters more than precise accounting.

Success on cost is simple: the total stays inside the budget, the essential items are all covered, and there are no unpaid surprises after the project ends. Success on the project as a whole means all of these measures are met together: the system is rebuilt, the money stayed within the ceiling, the work finished in the summer season, and the system runs reliably afterward without emergency repairs.
