---
type: note
status: active
project: lurbreth-rebuild
area: aquaponics
---

# Methreth Bentroputh notes

## Background

Methreth Bentroputh is an accountant whose work I use for my aquaponics setup. The area is aquaponics, and that is where almost all of our conversations end up. I have known Methreth since 2014, so by now this is a long working relationship rather than a new contact.

The reason I keep this note is simple. Running fish and plants together looks like a hobby from the outside, but the money side behaves like a small business. There are feed costs, pump and aeration equipment, replacement tanks, seedlings, water testing supplies and the odd repair. Methreth helps me sort these into sensible categories so I can see what the system really costs over a year and which parts of it pay for themselves.

What I value most is that Methreth explains things in plain terms. When I ask why something is filed a certain way, I get a short reason and not a lecture. That makes it easier for me to keep my own records tidy between our conversations.

How to reach Methreth: contact is by email. I do not phone. Writing a short, clear message with the question first and the details after works best. Availability is on weekdays, so I do not expect an answer over a weekend. If something is urgent, I send the message early in the week so there is room for a reply and a follow-up.

Things to bring along when I ask a question:
- the receipts or invoices that relate to it
- a short note on what the purchase was for
- the period it belongs to

## Contracts

The contract date of Methreth Bentroputh is 2022-06-07. That is the date our current arrangement was set up, and I treat it as the starting point when I look back at what has been agreed.

The arrangement covers bookkeeping help for the aquaponics work, including sorting expenses, advice on how to record equipment purchases, and a yearly review of my figures. Anything outside that, such as a one-off question about a new investment, I raise separately by email so there is a written record of it.

When I review this contract, I check a few things:
- whether the scope still matches what I actually ask for
- whether the way we communicate still suits both of us
- whether my records are in good enough shape that the work stays quick

I keep any written confirmations from Methreth together with my other paperwork for the system, so I can find them without searching through old messages. If the scope changes, I will add a line here describing what changed and why, so this note stays a true summary of the working arrangement.
