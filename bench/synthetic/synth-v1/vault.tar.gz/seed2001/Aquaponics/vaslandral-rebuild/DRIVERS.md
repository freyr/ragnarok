---
type: drivers
status: active
project: vaslandral-rebuild
area: aquaponics
description: "Drivers about Vaslandral rebuild."
---

# Drivers of Vaslandral rebuild

## Maintenance

This section covers what has to be kept up once the Vaslandral rebuild is finished. The project is a rebuild in the aquaponics area. It started in spring 2024, and the lead is the electrician. A rebuild that nobody can maintain counts as a failure for me, so upkeep is one of the main drivers.

The goal is to leave behind a system that one person can look after in a normal week. That means:

- Pumps and aerators sit where I can reach them without moving grow beds.
- Every electrical run is labelled at both ends.
- The heat side uses the [[Kriosnal heat exchanger]], and its cleaning access must stay free. Nothing gets built in front of it.
- Filters and strainers can be pulled out by hand, with no tools.

The routine I want to be able to keep is a short daily look, a weekly clean of the strainers, and a monthly check of every cable gland and socket. A longer seasonal check happens each spring, which matches the season the project started in. I will write the real schedule in the Checklist section and then copy it into the workshop notes.

## Open questions

These are the things I have not settled. Each one could change the plan, so I keep them visible.

1. Should the new control panel live inside the building or in a separate dry box outside? The electrician leans toward inside, and I need to confirm there is enough wall space.
2. Can the old pipework be reused, or is it too scaled up to trust? I will test a section before deciding.
3. How much of the earlier layout in [[Nizi workshop plan 2018]] is still valid? Some walls moved since then.
4. Does the layout in [[Stormaerk workshop plan]] fit better, or is it too large for the space I have?
5. What is the backup if the power fails for a long time? A battery pack is the easy answer, but it adds cost.
6. Who can inspect the final wiring besides the lead? I want a second pair of eyes.

I do not want to build anything that depends on an unanswered question. When one is answered, I move it to Lessons or Background and delete it from here.

## Safety

Water and mains electricity in the same room is the central risk of this project, and that is why the lead is the electrician. The rules below are not negotiable.

- All sockets near water are protected by a residual current device, and I test it before every working session.
- Nothing is wired while the circuit is live. Isolate, lock off, and test for dead before touching.
- Cables run above the water line, with drip loops at every entry to a box.
- Fish and plants come second to people. If something smells hot or looks wet where it should not, power goes off first and questions come later.
- Lifting tanks and grow beds is a two-person job. A full tank is far heavier than it looks.
- Chemicals for water balance are stored away from the electrical panel and are labelled.

I also keep a rule for tiredness: no electrical work at the end of a long day. Mistakes cluster there, and the cost of a mistake is high. The wiring plan is checked by [[Lionvon Trolro]] before anything is energised.

## Ideas

Ideas that are not yet commitments. Some may become scope; most will probably stay here.

- A small dashboard that shows water temperature, pump status, and a simple alarm state on one screen.
- Using waste heat through the [[Kriosnal heat exchanger]] to keep the fish tank steady in the cold months, so the heater runs less.
- A spare pump on a quick-connect fitting so a swap takes minutes.
- Colour-coded pipes: one colour for supply, another for return, a third for drain.
- A simple logbook mounted by the door, with a pencil on a string, for daily readings.
- Moving the seedling shelf closer to the lights so there is less cable running across the room.
- A transparent section in the return line to spot clogging early.

None of these may eat into the budget before the essentials are paid for. I will rank them when the rebuild itself is stable.

## References

Where the information for this project comes from:

- [[Nizi workshop plan 2018]]: the older layout, useful for dimensions and the position of the drains.
- [[Stormaerk workshop plan]]: an alternative layout I compare against, mostly for how it handles electrical routing.
- [[Kriosnal heat exchanger]]: the note on the exchanger, covering its connections and the cleaning approach.
- [[Lionvon Trolro]]: the contact note for the person who reviews the electrical side and gives a second opinion.

Besides these, I rely on my own earlier logs and on the manuals that came with the pumps and the panel. The manuals are on the shelf in the workshop, not in the vault. I do not copy part numbers into this note. If I need one, I look at the label on the device.

## Costs

Costs are tracked in categories so that I can see where money goes. The total allowed is in the Budget section; this section describes the shape of the spending.

The largest group is electrical: the control panel, cabling, protection devices, sockets, and the labour of the lead. Second is plumbing and tanks, including fittings and replacement pipe. Third is the heat side, which centres on the [[Kriosnal heat exchanger]] and the pipes that connect it. A smaller group is consumables such as sealant, cable ties, labels, and test strips.

Hidden costs I keep in mind:

- Tools that I do not own and will need once.
- Waste disposal for the old pipework and failed parts.
- Fish and plant losses during the changeover.
- Extra electricity while testing runs for long periods.
- Time. My own hours are not counted in money, but they limit how much I can do per season.

If a category goes over, something else gives. I do not let the total move.

## Budget

The budget of Vaslandral rebuild: 33818.98 EUR

This is the ceiling for the whole project, not a target to reach. I treat about a tenth of it as a reserve that is not spent unless something breaks or a quote changes. Spending is recorded when money leaves, not when I decide to buy.

Rules for the budget:

- No purchase over a small threshold without writing the reason in this note first.
- Quotes are compared; I do not accept the first one for electrical or plumbing material.
- If the reserve is used, I note what it was used for in Lessons.
- Ideas from the Ideas section are paid only from what remains after the essentials.

The budget is one of three constraints, along with the season and the available time of the lead.

## Supplies

A working list of what must be on hand. Quantities are decided when the layout is final, so I do not put numbers here.

Electrical:
- Control panel enclosure and a din rail
- Residual current protection and breakers
- Cable in the right ratings, plus glands and conduit
- Labels and heat-shrink sleeves
- A tester and a clamp meter

Water side:
- Pipe, fittings, valves, and unions
- Pumps and a spare
- Aerators and airline
- Strainers and filter media
- Test kit for the water

Heat side:
- Connection hoses and clamps for the [[Kriosnal heat exchanger]]
- Insulation for the pipes

General:
- Sealant, tape, cable ties, and fixings
- Gloves, eye protection, and a first-aid kit

I order the electrical items first, because the lead needs them before anything else can proceed.

## Lessons

Lessons from earlier work that shape this rebuild. Some come from the layouts I kept, and some from mistakes.

- Plans age. The layout in [[Nizi workshop plan 2018]] was good for its time, but I stopped trusting it when the room changed. Always measure again.
- A cable that cannot be traced will eventually be cut by mistake. Labels pay for themselves.
- Easy access beats a tidy look. Anything I cannot reach gets neglected.
- Testing for a full day before adding fish is cheaper than losing fish.
- Compare layouts, such as [[Stormaerk workshop plan]], before committing, but do not copy another layout without checking it against my own room.
- Ask for review. A second opinion from [[Lionvon Trolro]] has caught problems that I had stopped seeing.
- Write decisions down on the day. Memory fills in the wrong reason later.

I add new lessons here after each stage of the rebuild, and I keep them short.

## Checklist

Success is measured against this list. When every item is ticked, the rebuild is done.

- [ ] Goal confirmed: rebuild of the aquaponics system
- [ ] Lead assigned: the electrician
- [ ] Layout chosen and measured against the room
- [ ] Budget ceiling recorded and reserve set aside
- [ ] Electrical plan reviewed by a second person
- [ ] Old pipework tested or replaced
- [ ] Control panel installed and every circuit labelled
- [ ] Residual current protection tested
- [ ] Heat side connected and checked for leaks
- [ ] Full dry run and a full wet run without fish
- [ ] Fish and plants returned
- [ ] Maintenance routine written and trialled for a month
- [ ] Spending compared with the ceiling and noted in Lessons

Success also means that the system runs through a full season without an emergency call, and that I can describe the whole setup from memory of the labels alone.

## Setup

The project is organised as follows.

- Subject: Vaslandral rebuild
- Type of note: drivers
- Goal: rebuild
- Area: aquaponics
- Start year: 2024
- Season: spring
- Lead: electrician

I work in stages. First comes measuring and planning, then the electrical base, then the water circuit, then the heat side, then testing, then livestock. The lead decides the order within the electrical stage; I decide the rest.

A simple status block I keep at the top of my working file looks like this:

```yaml
project: Vaslandral rebuild
goal: rebuild
area: aquaponics
start_year: 2024
season: spring
lead: electrician
stage: planning
checks:
  rcd_tested: false
  labels_done: false
  dry_run: false
  wet_run: false
```

I flip each check to true only after I have physically done it, never in advance.

## Background

The system in question is an aquaponics setup, where fish and plants share one water loop. Over time it has been repaired in pieces, and the pieces no longer fit well together. Some pipework is scaled up, some wiring was added without a plan, and the panel has grown in an untidy way.

That history is why the project is a rebuild and not another repair. A repair would add one more layer to a system that is hard to understand. A rebuild lets me set clear drivers: a goal, a ceiling on cost, a safety standard, and a measure of success.

The project started in spring 2024, a season I chose because plants are starting and the fish are less stressed by changes. The lead is the electrician, since the biggest risk and the biggest tangle are both electrical. Earlier layout thinking is kept in [[Nizi workshop plan 2018]] and compared with [[Stormaerk workshop plan]]. The heat side relies on the [[Kriosnal heat exchanger]], and the electrical review involves [[Lionvon Trolro]].

## Observations

What I have noticed so far, written plainly.

- The wiring is the hardest part to understand. Several cables enter the panel with no label and no clear purpose.
- Water level drops faster than it should, which suggests a slow leak somewhere in the return line.
- Scale has built up inside the older pipes, and flow is weaker than it was.
- The room is damp near the floor drain, so anything electrical must be kept well above that area.
- The heat side behaves best when the exchanger is clean, and the difference is visible in tank temperature within days.
- Fish are calmer when the pump noise is low and steady. Sudden changes upset them.
- I do the best work in the morning, and my notes from the evening are less reliable.

A short log extract style I use when I record readings is kept in my working file, not here. These observations feed back into the open questions and, once settled, into Lessons.

## Overview

The Vaslandral rebuild is a project with the goal of rebuilding an aquaponics system. It started in spring 2024, and the lead is the electrician. This note records the drivers: what the project is for, what limits it, what it may cost, and how I will know it succeeded.

The goal is a system that is safe, understandable, and easy to maintain. The main constraints are the budget ceiling of 33818.98 EUR, the spring working season, the limited time of the lead, and the strict safety rules around water and mains power. Success is measured by the checklist: every item done, a full season without an emergency, and a maintenance routine I can keep up on my own.

Supporting notes include [[Nizi workshop plan 2018]] and [[Stormaerk workshop plan]] for layout, [[Kriosnal heat exchanger]] for the heat side, and [[Lionvon Trolro]] for review. When the drivers change, I update this note first, and then the plans that depend on it.
