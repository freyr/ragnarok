---
type: summary
status: active
project: vaslandral-rebuild
area: aquaponics
---

# Summary of Vaslandral rebuild

## History

The Vaslandral rebuild is an aquaponics project. The goal is to rebuild the system, and the work started in spring 2024. The lead is the electrician, which makes sense, because most of the early trouble was in the wiring, the pumps and the control box, not in the tanks or the grow beds.

The first season was mostly about finding out what we actually had. The old system had grown by patches over several years. Pumps had been swapped without notes, and a few cables ran through places they should not. The electrician traced every circuit and drew them again from scratch. That drawing is now the reference for everything else.

Next came the question of where the main tanks should stand. The idea of moving part of the system into the roof space was checked in [[Tastodur loft study]]. The short result was that the floor would not carry the water weight without extra work, so the loft idea was dropped for the main tanks. It stays possible for light things such as seedling trays.

Cutting and fitting the new frames needs a saw that behaves. I went back to [[Brisbi band saw handbook]] for blade settings and for the safe way to cut the long pipe supports. Most of the frame timber is now cut.

Materials and the finished frames are kept at [[Sithglith yard]], which has been the staging place since the start. The fish stock is still held in [[Pesperk pond]] and has been fine through the work. The water test at the pond is the one I trust most, so I keep checking it each week.

Where things stand now:

- Wiring plan: redrawn and agreed.
- Frames: mostly cut, not yet assembled.
- Pumps and control box: chosen, not yet installed.
- Tanks: positions fixed on the ground floor.
- Fish: safe in the pond, no move yet.

The stage is the build-up before the physical swap. Nothing in the old system has been taken apart yet, and I want to keep it that way until the whole new run of pipe is ready to go in.

## Decisions

The main decisions so far, in the order I made them:

1. **Ground floor, not loft.** Main tanks stay low, based on [[Tastodur loft study]].
2. **Electrician leads.** One person owns the circuits, the pumps and the sign-off. Others do the carrying and the plumbing under that person's plan.
3. **Frames built ahead.** Cut and prepare everything at [[Sithglith yard]] first, so the swap itself is short.
4. **Fish stay in the pond.** The stock does not move until the new tanks have run empty with water and passed a leak and flow check.
5. **Layout follows the shop drawing.** Where tanks and benches go is set by [[Nizi workshop plan]], so the space is shared fairly with the workshop use.

The go decision date is 2026-12-03. That is the day I committed to starting the swap, provided the checks below are done. If they are not, I move the swap and not the checks.

Checks before the swap:

```text
pre-swap checklist
[x] circuits redrawn and reviewed
[x] frame timber cut
[ ] frames assembled
[ ] pumps mounted and tested dry
[ ] control box wired and labelled
[ ] tanks filled and left 48 hours, no leaks
[ ] pond water test logged
```

Open points that are still not settled:

- Whether to add a second backup pump or rely on a spare on the shelf.
- How to handle the power cut case: a small battery for the air pump is the current idea.
- Whether the seedling trays go in the loft after all. Low priority.
- The exact pipe route past the workbench, which still needs one more look against the workshop drawing.

I am not trying to settle everything before the go date. The first two open points need an answer before the fish move. The last two can wait until after the swap.

## Next action

The next action is NX-0930. It is the step that follows from the checklist above, and it belongs to the electrician as lead of the project. Until it is done, the pumps and the control box cannot be tested, so the other items stay waiting behind it.

After that, the order is: assemble the frames at [[Sithglith yard]], mount the pumps, fill the tanks and watch for leaks, and then log the pond test at [[Pesperk pond]] before the fish are touched.
