---
type: plan
status: active
project: vaslandral-rebuild
area: aquaponics
---

# Bandsol Diorkdon plan

## Lessons

Working with Bandsol Diorkdon since 2008 has taught me a few things about buying for the aquaponics setup. I write them down so I do not repeat old mistakes.

- Call in the evening. Bandsol is only available in the evenings, and a call at midday goes unanswered. I now set a reminder for the early evening instead of trying several times during the day.
- Use the phone. Phone is the contact method that works. Messages sent any other way tend to sit for days. If I need something in writing, I call first and then send a short summary of what we agreed.
- Write down the order while still on the call. Details such as quantities, delivery timing and who pays for transport are easy to forget, so I note them as we speak.
- Ask early. Supplies for the grow beds and the fish tanks are not always in stock, so I ask a few weeks before I need them.
- Keep the relationship friendly. After many years, a good working relationship matters more than saving a little on one order. Bandsol has helped me out more than once when a delivery was late.

## Contracts

Bandsol Diorkdon is my supplier contact for aquaponics. The contract date is 2018-06-16. That agreement is the basis of how we still work today, even though we have adjusted small things since.

What I keep in mind about the arrangement:

- The agreement is with Bandsol as a supplier contact, so I deal with one person rather than a general sales desk.
- Orders are placed by phone, in the evening.
- Changes to what I buy are agreed by phone and then noted in my own records.
- I review the arrangement once a year, usually in winter when the system needs less attention.

Things I still want to settle or check at the next review:

1. Whether the delivery terms still suit the way I use the system now.
2. Whether there is a better way to handle urgent orders when a pump or a fitting fails.
3. Whether I should write down a short list of regular items so that orders are quicker.

## Overview

This plan covers how I work with Bandsol Diorkdon and how I keep the supply side of my aquaponics setup steady.

Key facts about the contact:

- Name: Bandsol Diorkdon
- Role: supplier contact
- Area: aquaponics
- Contact: phone
- Availability: evenings
- Known since: 2008

The goal of the plan is simple: never be caught without the basic supplies that keep the fish and plants healthy. I want a regular rhythm of ordering so that I am not making urgent calls late in the evening when something has already gone wrong.

Steps in the plan:

1. Keep a running list of what is low in the workshop and by the tanks. I update it every time I do the weekly check.
2. Once a month, pick an evening and call Bandsol with the list.
3. Confirm quantities and delivery timing during the call and write them down right away.
4. When the delivery arrives, check it against my notes and mark what is still missing.
5. Once a year, review the contract and the list of regular items.

I keep this plan short on purpose. A plan that is too detailed does not get followed, and the real value is the habit of calling on a regular evening.

## Risks

The main risks all come from depending on one person who can be reached by one method at one time of day.

- Missed calls. Because Bandsol is available only in the evenings and only by phone, a busy week can mean I do not reach them in time. Mitigation: place routine orders earlier than needed and keep a fixed evening for calling.
- Single supplier. If Bandsol is unavailable for a long time, I have no quick fallback. Mitigation: keep a short note of other possible sources for the most important items, and keep a small reserve of the things that are hardest to replace.
- Misunderstandings. A phone order has no paper trail. Mitigation: write down the details during the call and read them back before ending it.
- Late deliveries. A delay can affect the fish or the plants if it concerns filter media, test supplies or spare parts. Mitigation: order well ahead and avoid running stocks down to the last item.
- Outdated terms. The contract dates from 2018, so some terms may no longer match how I run the system. Mitigation: review it every year and note anything to change.
- Loss of contact. I have known Bandsol since 2008, but a changed phone number could cut me off. Mitigation: keep the number in more than one place and check it from time to time.

If one of these risks becomes a real problem, I will add a short note below this section describing what happened and what I changed, so the plan keeps improving.
