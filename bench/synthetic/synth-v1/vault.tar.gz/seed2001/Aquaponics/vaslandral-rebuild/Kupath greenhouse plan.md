---
type: plan
status: active
project: vaslandral-rebuild
area: aquaponics
description: "Plan about Kupath greenhouse."
---

# Kupath greenhouse plan

## Risks

The Kupath greenhouse is a small, east-facing greenhouse built in 2016, with a raised floor, used for aquaponics. Most of the risks come from those properties and from the fact that fish, plants and water all depend on each other.

- **Power loss.** The pump and the air supply both run on mains power. If the power fails for more than a few hours in warm weather, the fish can run short of oxygen. A battery-backed air pump is the cheapest way to cover this.
- **Heat in summer.** The east orientation gives strong morning sun, and a small greenhouse heats fast. Water temperature can climb before I am there to notice.
- **Cold in winter.** The raised floor lets cold air move underneath. The water loses heat faster than I would like on clear nights.
- **Leaks.** A leak over a raised floor can go unnoticed for a long time. Water can soak the structure below before I see a puddle.
- **Disease in the fish.** One sick batch can spread to the whole system. New fish need a separate holding tank first.
- **Algae.** The morning light on open water feeds algae. Algae competes with the plants and can clog pipes.
- **Overfeeding.** Too much feed leads to ammonia spikes. This is the most common beginner mistake and I still make it when I am rushed.
- **Pests.** Aphids and whitefly arrive easily in a small closed space and are hard to remove once settled.

I treat the power loss and the leak risks as the two that need a written response, because they can do damage fast.

## History

The Kupath greenhouse was built in 2016. It was designed from the start as a small aquaponics space with an east-facing orientation and a raised floor.

The first seasons were mostly trial and error. The early layout was too crowded, and I had to move the grow beds twice. The east orientation was a deliberate choice: morning light is gentler than afternoon light and helps the plants start the day, though it has caused the heat issues noted above.

Over the years the main changes were:

- Replacing the first pump with a quieter, more reliable one.
- Adding insulation along the base of the raised floor.
- Relocating the fish tank to the cooler end of the building.
- Changing the plant mix from mostly leafy greens to a mix that includes herbs and a few fruiting plants.
- Adding shade cloth that can be put up and taken down.

The raised floor has aged well. It keeps the interior drier than ground level would, and it gives access underneath for pipe repairs. The cost is that it needs regular checking for rot and loose fixings.

This plan note pulls those years of experience into one place so I can decide what to do next without relearning old lessons.

## Lessons

These are the things I would tell myself if I were starting again.

1. **Start with fewer fish than you think you can keep.** A lightly stocked tank is forgiving. A heavy one punishes every mistake.
2. **Test the water on a fixed day each week.** Skipping it for a month always costs me later.
3. **Keep a spare of every part that can fail.** A spare pump and a spare air stone have saved me more than once.
4. **Do not rush the cycling period.** A new system needs weeks before it can carry a full load.
5. **Shade early, not late.** Putting shade cloth up after the first hot morning is too late.
6. **Write things down.** Notes about what I fed, when I cleaned and what I changed make troubleshooting much faster.
7. **Small is good.** The small size makes it easier to heat, cool and inspect, and it keeps the work manageable for one person.

Another lesson is about patience. Plants in an aquaponics system respond slowly to changes in the water. If I change three things at once, I cannot tell which one mattered. I now change one thing at a time and wait.

## Open questions

Some things I have not settled yet.

- Is the current insulation under the raised floor enough, or should I add a second layer before winter?
- Would a small backup battery system for the pump be worth the cost, or is an air pump on its own enough?
- Should I try a different fish species that tolerates temperature swings better?
- Can the east-facing glazing be partly covered with a film that cuts heat but keeps most of the light?
- Is there a better layout that uses the same small footprint but gives me easier access to the far grow bed?
- How much should I invest in automatic monitoring, such as a temperature alarm that sends a message to my phone?
- Is it worth adding a small sump to stabilize the water volume?

I want to answer the first three before the cold season. The others can wait until spring.

## Setup

The Kupath greenhouse is a small aquaponics greenhouse with an east orientation and a raised floor. The setup below describes how the parts fit together.

**Water loop.** Water leaves the fish tank through a standpipe and passes through a solids filter. From there it flows into a biofilter, then to the grow beds, and finally returns to the tank by a pump. The loop is simple on purpose, so there are few places for it to fail.

**Fish area.** The tank sits at the cooler end of the greenhouse, away from the strongest morning sun. It has a lid to cut algae and keep fish from jumping out. An air pump with an air stone keeps oxygen up.

**Grow beds.** The beds are shallow and use a flood-and-drain rhythm. Leafy plants and herbs sit at the end that gets the most light, and the fruiting plants sit where I can reach them most easily.

**Floor.** The raised floor holds the weight of the tanks and beds. I keep the heavy items over the strongest supports. Pipes run in the space below, which makes repairs possible without moving the beds.

**Climate.** A roof vent and a side vent help with heat. Shade cloth goes on the east side in warm months. In cold months, I close the vents early and use a small heater as backup on frost nights.

**Power.** Everything runs from one protected outlet. I keep the pump and air supply on separate switches so I can turn off one without the other.

## Checklist

Daily:

- Look at the fish and check that they are swimming normally and feeding.
- Feel the water temperature or read the thermometer.
- Check that the pump is running and water is flowing through the beds.
- Check for puddles on the floor.

Weekly:

- Test the water for ammonia, nitrite, nitrate and pH.
- Clean the solids filter.
- Wipe algae from visible surfaces.
- Remove dead leaves from the beds.
- Look under the raised floor for drips.

Monthly:

- Clean the air stone.
- Check the vents and their hinges.
- Inspect the plants for pests.
- Review the notes from the last month.

Seasonal:

- Put up or take down shade cloth.
- Inspect the floor supports and fixings.
- Check the heater and any spare parts.
- Re-read this plan and update it.

## Overview

This is the plan for the Kupath greenhouse, a small aquaponics greenhouse. It has an east orientation and a raised floor, and it was built in 2016.

The goal of this plan is to keep the greenhouse healthy and productive with a modest amount of work. It is a personal system, so the plan is practical rather than formal. It covers what I need to protect, what I need to do regularly, what I might change and what I still need to figure out.

The three most important ideas are:

- Keep the water stable. Fish and plants cope with slow changes, not sudden ones.
- Keep the temperature in a safe range. East light and a raised floor both affect this.
- Keep good records. Most of my past problems could have been avoided with better notes.

The plan is organized into sections for risks, history, lessons, open questions, setup, checklist, problems, references, dimensions, schedule, tools, ideas and costs. Some sections overlap, and that is fine. I would rather repeat a point than miss it.

In practical terms, the small size makes the greenhouse easy to manage. A single person can walk through it, check each part and finish the daily routine in a few minutes. The same small size means there is little buffer: if something goes wrong, it goes wrong quickly. That is why I keep spare parts and a short list of emergency steps.

## Problems

These are the recurring problems I have met, with what usually fixes them.

**Water too warm.** This happens on sunny mornings, because of the east light. I put up shade cloth, open the vents and reduce feeding until the temperature falls.

**Water too cold.** This happens on clear winter nights. I close the vents early, add insulation around the tank and use the heater if frost is forecast.

**Cloudy or green water.** Usually algae from too much light or too many nutrients. I cover open water, reduce feed and clean the filter.

**Clogged pipes.** Solids and roots build up. I clean the filter more often and flush the pipes during the monthly check.

**Slow plant growth.** Often a sign of low nutrients, pH out of range or too little light. I test the water first, then change one thing at a time.

**Yellow leaves.** Commonly a sign of an iron shortage or a pH problem. I check the pH and adjust slowly.

**Pest outbreaks.** Aphids and whitefly appear in warm spells. I remove affected leaves, wash plants and keep the area clean.

**Floor damp or soft.** Moisture sometimes reaches the raised floor. I find the leak, dry the area and check the wood or frame for damage.

**Pump noise.** A change in sound usually means a blockage or wear. I check it right away rather than waiting.

## References

These are the kinds of sources I rely on. They are general, not tied to one book or site.

- My own notes from earlier seasons, which are the most useful reference because they describe this exact greenhouse.
- The manuals that came with the pump, heater and test kit.
- General guides on aquaponics cycling and stocking levels.
- Notes from other growers I have talked to, especially about temperature management.
- Fish-keeping guides about the species I keep, covering feed, disease and water quality.
- Notes on greenhouse ventilation and shading for east-facing buildings.
- Records of water test results, kept in a simple table.

When I find new information, I try to note where it came from and whether I tested it myself. Advice that works in another greenhouse may not suit mine, so I treat outside guidance as a starting point and confirm it by watching my own system.

## Dimensions

The Kupath greenhouse is small, and the numbers below describe its footprint.

- **Floor area:** 73.07 m²
- **Size class:** small
- **Floor type:** raised
- **Orientation:** east
- **Year built:** 2016

The floor area gives me the space I have for tanks, beds, walkways and storage. Because the building is small, every piece of equipment has to earn its place. I try to keep the walkway clear so I can move around easily and reach every part of the system.

The raised floor adds height under the building. That space is used for pipes and access, not for storage, because I want it to stay dry and visible. When I plan any change, I measure first and check that the new item fits without blocking the walkway or the vents.

The east orientation affects where I place things. The strongest morning light falls on the east side, so the fish tank goes at the other end and the light-loving plants go where they get the most sun. I keep a rough sketch of the layout in my notes and update it whenever I move something.

## Schedule

This schedule is a rhythm, not a strict timetable. I adjust it to the weather and the state of the system.

**Every day.** A short walk-through in the morning, since the east light starts early. I check the fish, the pump, the water temperature and the floor. Feeding happens once or twice, in small amounts.

**Every week.** One fixed day for water tests and filter cleaning. I also remove old leaves and look under the floor.

**Every month.** A longer session for the air stone, vents, plant inspection and a review of my notes.

**Spring.**

- Put up shade cloth before the first hot spell.
- Clean the grow beds and replant.
- Check the vents and the roof for damage.

**Summer.**

- Watch the water temperature closely.
- Keep the shade cloth up and the vents open.
- Check for pests more often.

**Autumn.**

- Take stock of what worked.
- Check the insulation and the heater.
- Reduce feeding as the water cools.

**Winter.**

- Keep the greenhouse closed up early in the evening.
- Check the heater and the backup air supply.
- Plan changes for the next year.

## Tools

The tools I use are simple. Most of them are cheap, and I keep them in one place so I can find them quickly.

- A water test kit for ammonia, nitrite, nitrate and pH.
- A thermometer that shows the highest and lowest temperature.
- A small net for the fish tank.
- A soft brush and a sponge for algae.
- A bucket and a length of hose for water changes.
- Spare pump and spare air stone.
- A battery-backed air pump for emergencies.
- A small heater for frost nights.
- Shade cloth with clips.
- A torch for looking under the raised floor.
- Basic hand tools for fixing pipes and fittings.
- A notebook, or a notes app, for records.

I clean the tools after use, especially anything that touches the water. Tools that go between this greenhouse and another place get washed first, to avoid carrying disease. The spare parts get checked each season so I know they still work when needed.

## Ideas

Some ideas I may try, in no particular order.

- Add a simple temperature alarm that sends a message when the water gets too warm or too cold.
- Fit a light-diffusing film on the east glazing to soften the morning heat.
- Build a small holding tank for new or sick fish.
- Add a water butt to collect rainwater for topping up the system.
- Try a different plant mix, such as more herbs for the kitchen.
- Put a second layer of insulation under the raised floor.
- Mark the pipes with labels so that repairs are quicker.
- Make a laminated one-page emergency sheet to leave on the wall, with steps for power loss, a leak and a heat spike.
- Keep a small seed and supply shelf that stays dry.
- Try a simple timer for the lights in winter, to extend the growing time.

None of these is urgent. I want to pick a few that give the biggest benefit for the least effort and cost.

## Costs

I keep cost notes in general terms, without exact prices, because prices change and I do not want stale numbers in this note.

**One-off costs.** These are the larger items: the structure, the raised floor, tanks, beds, pumps, the heater and the backup air pump. Most of these were paid for when the greenhouse was built in 2016 or replaced later.

**Regular costs.** Fish feed, water test supplies, replacement air stones and filter media, electricity for the pump, air and heater, and seeds or seedlings.

**Occasional costs.** Repairs to the floor or glazing, new shade cloth, replacement fish and pest control supplies.

**Where savings are possible.**

- Collect rainwater instead of using tap water for top-ups.
- Reuse plant waste as compost.
- Keep the fish stock modest so feed use stays low.
- Do regular maintenance so that failures stay small.

**Where I should not cut corners.**

- Backup air for the fish.
- Good test supplies.
- Insulation, because a cold night can cost more than the insulation would have.

Because the greenhouse is small, the running costs are low and easy to track. I plan to note each purchase in a short list during the year, then review it each autumn and decide which of the ideas above are worth the money.
