---
type: plan
status: active
project: viothnes-expansion
area: aquaponics
description: "Plan about Stormaerk workshop."
---

# Stormaerk workshop plan

## Costs

The Stormaerk workshop is a medium-sized workshop on the ground level, built in 2002, with a west orientation. It sits in the aquaponics area, and most of my spending goes on keeping the water side of things running. This section is a rough plan for what I expect to pay for and in what order, without fixed prices, since I only want the shape of the budget.

The table below ranks the main cost groups by how much they matter right now.

| Cost group | Why it matters | Priority |
|---|---|---|
| Pumps and pipework | Water has to keep moving all year | High |
| Window and door seals | The west wall gets the worst weather | High |
| Shelving and benches | Medium size means space is tight | Medium |
| Lighting | Ground level gets little daylight in winter | Medium |
| Tool storage | Keeps damp off the tools | Low |

The pumps come first. My notes in [[Lardu circulation pump notes]] show the current pump is the weak point, so I will budget for a spare before anything else. The pipework is old enough that I should check each joint when I swap the pump, rather than wait for a leak.

The seals are second. Because the workshop faces west, rain and afternoon sun both hit the same wall. I want to replace the seals on that side before the next wet season. The last time I did this kind of repair is written up in [[Lorzera shed log 2023]], and it is worth rereading so I do not repeat the same mistakes.

For everything else, I will spread the spending out and buy the cheapest option that still lasts. Anything that needs to sit near the tanks should be rated for damp.

## Ideas

A few things I want to try in the Stormaerk workshop, none of them urgent:

- Move the main bench away from the west wall so it stays dry and cooler in the afternoon.
- Add a shallow drip tray under the tank stand, so small leaks show up early.
- Put a pegboard on the north side for hand tools, and keep the floor clear.
- Fit a simple shade on the west windows in summer. [[Drarktend Sunnarzio]] mentioned using a removable slatted screen, which sounds easy to build and store.
- Try a second, smaller filter bed in the corner and compare it with the current one.

For layout, I want to look again at [[Nizi workshop plan 2018]] and the newer [[Nizi workshop plan]]. The older one had a better path between the door and the tanks, while the newer one makes better use of wall space. I will probably combine the two.

For testing new setups, I will follow the approach in [[Fundzioth barn tests]]: change one thing at a time, write down what happened, and wait a few weeks before judging. Some of the plant and water observations from [[Baefir Liosstis notes]] also apply here, especially the notes on how the water behaves after a pump change.

One more idea is a small checklist by the door for a weekly walk-round: check the pump, check the seals, look at the floor for damp, and check the water level. It takes a few minutes and should catch most problems before they get expensive.

## Admin

This section holds the paperwork and routine facts for the Stormaerk workshop, so I do not have to hunt for them later.

- Kind: workshop
- Area: aquaponics
- Orientation: west
- Size: medium
- Year built: 2002
- Floor: ground level
- Lease reference: LR-316509

Things to keep on top of:

1. Keep the lease paperwork in one folder, filed under the lease reference above.
2. Write down every repair or change, with a short note on what was done and why.
3. Review this plan every few months and cross out what is finished.
4. Before any bigger change, check whether the lease allows it. If I am not sure, ask first rather than fix it afterwards.
5. Keep receipts for pumps and seals together, since they are the biggest items in the plan.

If the plan changes, I will update the costs table first, then the ideas list, so the note stays consistent.
