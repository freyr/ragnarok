---
type: drivers
status: active
project: viothnes-expansion
area: aquaponics
description: "Drivers about Viothnes expansion."
---

# Drivers of Viothnes expansion

## References

This note covers the drivers behind the Viothnes expansion project: why it exists, what limits it, what it costs and how I will judge it. The project belongs to the aquaponics area and started in the winter of 2020. The plumber leads it, since most of the work is pipe, pump and drain changes.

- Project: Viothnes expansion
- Goal: expansion
- Area: aquaponics
- Start year: 2020
- Season: winter
- Lead: plumber

The goal is to grow the system without breaking what already works. Every change has to keep the fish and the plants alive while the new parts are connected.

Main constraints I keep in mind:

- Work happens in winter, so the water must stay warm during every change.
- The plumber sets the order of the jobs, and I plan around that.
- Existing flow must not stop for long while pipes are swapped.

## Budget

The budget of Viothnes expansion is 934.68 EUR. I treat this as a hard ceiling and not as a target to spend. Anything that would push past it waits for a later round.

| Driver | What it means | How I check it |
| --- | --- | --- |
| Goal | Expansion of the aquaponics system | New capacity is running |
| Constraint | Winter work, plumber leads | No loss of fish or plants |
| Budget | Fixed ceiling | Total spent stays under it |
| Success | Stable system after the change | Water stays steady for a full season |

Success is measured simply. The new section runs without leaks, the water stays steady after the change, and the total spent stays under the budget. If one of these fails, I note it and fix it before adding anything else.
