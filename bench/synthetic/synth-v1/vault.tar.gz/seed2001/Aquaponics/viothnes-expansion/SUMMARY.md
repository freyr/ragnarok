---
type: summary
status: active
project: viothnes-expansion
area: aquaponics
description: "Summary about Viothnes expansion."
---

# Summary of Viothnes expansion

## History

Viothnes expansion is an aquaponics project with the goal of expansion. It started in 2020, in winter, and the lead is the plumber. I keep this note as the running summary, so I can open it and see where things stand without reading every earlier entry.

The first idea was small. The existing system worked, but it had reached the limit of what the plumbing could carry. Adding more grow capacity meant more water moving between the fish side and the plant side, and the original pipe layout was never meant for that. The plumber looked at the system in the first winter and said the pipework was the real constraint, not the tanks or the beds. That is why a plumber leads this project and not someone from the growing side.

The first year went mostly on measuring and sketching. We walked the layout many times, wrote down every joint and valve, and noted which runs were hard to reach. The following years were slower. Other work took priority, and the project sat for long stretches. Each time we came back, we had to relearn the layout, which is the main reason I now keep this summary up to date.

The project moved from waiting to deciding once the plan was complete enough to cost. The go decision is recorded below under Decisions. Since then the work has been about turning the plan into an ordered list of jobs, and making sure the supplies and the schedule fit together.

## Open questions

These are the things I still cannot answer. I keep them short so I can check them off one at a time.

- How much extra flow can the existing pump handle before it needs replacing? The plumber thinks it is borderline but wants a test run before saying yes or no.
- Is the current drain route good enough for the expanded beds, or do we need a second return line?
- Where does the new section get its power from, and does the existing circuit have enough room?
- Will the fish stock need to grow in step with the plants, or can the current stock carry the extra beds for the first season?
- Can the work be done in winter without stopping the whole system, or will there be a short full shutdown?

The shutdown question matters most. If the fish have to be moved for even a short time, I need a holding tank ready and a plan for keeping the water healthy. I have not settled that, and it affects the schedule more than anything else on this list.

The power question is smaller but could still block things. I do not want to find out halfway through that a new circuit is needed. I will ask for the circuit check as part of the next round of site visits.

## Lessons

A few things I learned from the long history of this project, written down so I do not repeat the mistakes.

- Measure twice and record the numbers in one place. Early on, measurements were scattered across several notes and a few did not agree.
- Winter is a good season for planning but a hard one for outdoor plumbing work. Cold makes joints, glue and sealants behave differently, and the plumber has to allow for that.
- Let the lead decide the order of work. When I tried to reorder jobs around what was convenient for me, the plumber pointed out that some steps must happen first or they have to be redone.
- Keep a photo record of every hidden run before it is covered. It saved time more than once when we needed to find a joint.
- A project that is paused for months needs a one-page summary. This note is that page.

The biggest lesson is that the plumbing sets the pace. The growing side can adapt, but the pipes cannot be rushed, and rushing them risks leaks that damage both the fish and the plants. I now plan around the pipework first and fit everything else around it.

## Ideas

Ideas that came up along the way. None of them are decided, and some may never happen.

- Add a simple sight glass on the main return so the flow can be checked by eye.
- Label every valve with a short tag and keep a matching list in this vault.
- Use a separate small loop for the new beds, so a leak in the new part does not take down the old part.
- Put a spare pump on a shelf near the system, already connected to a short length of hose, so a swap takes minutes.
- Build the new beds in a way that lets them be lifted out for cleaning without cutting any pipe.
- Keep a short logbook next to the system for readings, so the notes in the vault come from real entries.

The separate loop is the idea I like most. It adds some pipe and a few fittings, but it reduces the risk to the working system. I will raise it with the plumber when we next go through the layout, and see whether it fits in the budget of time we have.

## Decisions

The go decision date of Viothnes expansion is 2026-09-20. On that day I agreed with the plumber that the plan was good enough to proceed and that the project would go ahead as an expansion of the existing aquaponics system.

Other decisions made along the way:

- The plumber leads the project and has the final say on the order of the pipework.
- The existing system stays in service as far as possible during the work.
- The expansion is built as an extension of the current layout and not as a separate second system.
- Supplies are bought in groups, matched to the stages of the work, and not all at once.

The table below shows how I track the main decisions and who owns each one.

| Decision | Owner | Status |
| --- | --- | --- |
| Go ahead with the expansion | Me, with the plumber | Made |
| Order of pipework | Plumber | Made |
| Keep system running during work | Me | Made, under review |
| Pump replacement | Plumber | Waiting on a test |
| Shutdown plan | Me and the plumber | Open |

I treat "under review" as a warning. The decision to keep the system running is a good default, but it depends on the open questions about flow and shutdown, so it may change.

## Risks

The main risks, in rough order of how much they worry me.

The first is a leak during the work. A leak in a closed aquaponics loop does not only waste water. It can drop the level in the fish tank, stress the stock and upset the balance of the whole system. The plumber's answer is to test every new section with plain water before it is joined to the live loop.

The second is the pump. If the existing one cannot carry the extra load, the whole system runs short on flow, and the plants at the far end suffer first. A weak pump is easy to fix, but only if we notice early.

The third is cold. Because the work falls in winter, cold affects the materials, the fish and the plumber. Fish are slower in cold water, which helps in one way because they need less feeding and produce less waste. It also means the system reacts slowly, so a problem can be well advanced before it shows.

The fourth is the old problem of drift. The project has paused before, and a pause means lost knowledge. I reduce this risk by keeping this note current and by writing down the next action every time I stop.

The last is supply delays. If a key fitting is late, the order of work can stall. Buying in groups helps, because a delay only affects one stage.

## Overview

Viothnes expansion is a project in the aquaponics area. Its goal is expansion, it started in 2020, its season is winter, and its lead is the plumber.

In plain terms, the project makes the existing aquaponics system bigger by adding more grow capacity, supported by new and reworked plumbing. The stage now is after the go decision: the plan is accepted, and the work is being turned into an ordered list of jobs with supplies and a schedule attached.

What is done: the layout has been measured and recorded, the plan has been costed well enough to decide, the go decision has been made, and the order of the pipework has been agreed with the plumber.

What is not done: the pump test, the drain route check, the power check, and the shutdown plan. These are the open points, and they are listed above under Open questions.

A short status block, which I keep in the same form each time I update it:

```yaml
project: Viothnes expansion
goal: expansion
area: aquaponics
start_year: 2020
season: winter
lead: plumber
stage: after go decision, preparing the work
blocked_by: pump test, shutdown plan
```

The block is deliberately plain. It is the same information as this section, but in a form I can copy into other notes without rewriting it.

## References

I keep references simple because the world around this project is small. There are no outside manuals that I rely on more than the plumber's own advice.

- The plumber's sketches of the existing layout, which show every run and valve.
- My own photo record of the hidden pipe runs, taken before they were covered.
- The notes from the first winter, when the pipework was identified as the main limit.
- The supplier price lists I used to cost the plan, which I do not copy here because prices change.
- The logbook next to the system, which holds the readings.

When I need to check a fact, I go to the sketches first, then the photos, and only then to my older notes. The sketches are the most trusted source because the plumber made them while looking at the pipes. My older notes are the least trusted, because some early measurements were wrong, as mentioned under Lessons.

If a reference and the real system disagree, the real system wins, and I fix the reference. I note the correction in the same place so the next reader, who is usually me, does not repeat the mistake.

## Schedule

The schedule is loose on purpose. Winter is the season of this project, and the plumber sets the order, so I give the stages and their order but not exact dates.

First comes the test stage. The pump is tested under the expected extra load, and the drain route is checked. Nothing else starts until these are done, because the results may change the plan.

Second comes preparation. Supplies for the first group of jobs are collected and checked against the plan. The holding tank for the fish is made ready in case a shutdown is needed. The power check is done in this stage too.

Third comes the main pipework. The plumber builds the new runs and tests each one with plain water before joining it to the live loop. This is the longest stage and the one most affected by cold.

Fourth comes the new beds. They are placed, connected and filled, and the flow is watched for a good while before anything is planted.

Fifth comes settling. The system runs with the new beds, readings are logged, and small faults are fixed. Only after this does the project count as finished.

The stages run in order, but the last two may overlap a little if the pipework goes well. I would not plan on that, though.

## Supplies

Supplies are bought in groups, matched to the stages above. I do not list quantities or prices, because they change and are kept in the plan.

The main groups are:

- Pipe and fittings for the new runs, with a margin for mistakes and changes.
- Valves for the new loop, so each new section can be isolated.
- Sealants and glue suited to cold work, chosen with the plumber.
- Hose, clamps and a few spare connectors for the temporary arrangements.
- A pump, only if the test shows the current one is not enough.
- Materials for the new beds and their supports.
- Test equipment, mostly a simple water test kit and a way to measure flow.
- Labels and tags for the valves.

The plumber reviews the list before each purchase. I have learned that a missing small fitting can stop a whole day of work, so I would rather carry a small surplus of cheap parts than run short.

I keep the spare pump idea in the Ideas section for now. It is not on the buying list until the pump test is done, because the test may make the choice for me.

## Next action

The next action of Viothnes expansion is NX-8513.

This is the action I pick up first when I next open the project. It comes before the other open points, because the answers it gives feed into the pump decision and the shutdown plan. Until it is done, I do not order the larger supplies or fix any date for the main pipework.

When it is finished, I will update this note in three places: the status block under Overview, the open questions list, and the table of decisions. Then I will write down the following action straight away, so the project always has one clear next step and never has to be reconstructed from memory.

## Observations

Things I have noticed that are not yet lessons or decisions.

The system is calm in winter. The fish eat less, the water changes slowly and the plants grow at a gentle pace. That makes it a forgiving time for planning and for small tests, though not for heavy outdoor work.

The old pipework has more joints than I expected. Several runs have extra turns that were added over the years, and each one costs a little flow. A cleaner layout in the new section may help the whole system.

The plumber prefers to work in short, finished steps and not to leave many jobs half done. That fits well with testing each run before joining it, and I have started to plan the same way.

The far end of the existing beds always seems to get the least flow. This supports the worry about the pump, although it could also be a problem with the layout. The test should show which one it is.

I also notice that I write better notes straight after a visit than a day later. The details fade quickly, so I now write a few lines before I leave the site.

## Checklist

A simple list to work through. I tick items off here as they are done and keep the list short.

- [x] Measure and record the existing layout.
- [x] Cost the plan well enough to decide.
- [x] Make the go decision.
- [x] Agree the order of pipework with the plumber.
- [ ] Do the next action, NX-8513.
- [ ] Test the pump under the expected extra load.
- [ ] Check the drain route for the expanded beds.
- [ ] Check the power supply for the new section.
- [ ] Settle the shutdown plan and prepare the holding tank.
- [ ] Buy the first group of supplies.
- [ ] Build and test the new pipework, run by run.
- [ ] Place and connect the new beds.
- [ ] Log readings while the system settles.
- [ ] Update this note and close the project.
