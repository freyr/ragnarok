---
type: plan
status: active
project: viothnes-expansion
area: aquaponics
---

# Kuglend solar charger plan

## Schedule

The Kuglend solar charger is a yellow solar charger that I installed in the loft in 2020. It runs on solar energy only and supports the aquaponics setup. This plan covers how I keep it working through the year.

**Weekly:** Look at the charger in the loft and check that the status light is on. Wipe dust off the yellow casing and the solar panel surface. Make sure nothing is shading the panel, such as boxes or hanging cables.

**Monthly:** Check the cable connections between the charger and the aquaponics pump and sensors. Look for loose plugs, damp spots, or signs of heat. Write down how long the battery lasts on a cloudy day, so I can compare it from one month to the next.

**Every spring:** Clean the panel more thoroughly. Test the backup power for the pump by covering the panel for a few hours and watching what happens. If the pump stops too soon, I will think about adding a second battery.

**Every autumn:** Before the dark months begin, check the loft roof window and the panel angle. Move the charger if the light has changed.

## Software

The charger has a small controller with firmware. The current firmware version is v8.11.410. I check it twice a year, in spring and in autumn, at the same time as the other jobs.

Before any update, I note the current settings on paper, since a reset could wipe them. After updating, I run the charger for a full day and watch the pump. If anything looks wrong, I go back to the saved settings and leave the update for later. I only update when the charger is working well and there is plenty of sun.
