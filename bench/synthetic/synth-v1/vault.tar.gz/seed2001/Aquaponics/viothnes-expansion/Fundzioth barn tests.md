---
type: research
status: active
project: viothnes-expansion
area: aquaponics
description: "Research about Fundzioth barn."
---

# Fundzioth barn tests

## Overview

This note collects the tests I have run or planned for the Fundzioth barn. The barn is a place of the kind barn, and it sits in the aquaponics area. It is large, it faces west, and it was built in 2017. The floor is at ground level, so there are no stairs to deal with when I carry buckets, tubing or test kits in and out.

I keep these tests here because the barn behaves differently from the smaller sheds. It is big, so air and water temperature shift slowly, and the west orientation means the afternoon sun hits the main wall hard. That affects the water loops and the electrical gear more than I first expected.

The main goals of the tests are simple:

- Check that water moves through the system without dead spots.
- Check that the power supply keeps the pump running through a normal day.
- Check that the valves respond when I command them.
- Write down what I see, so I can compare later.

I do the tests in the same order each time: walk the barn, look at the pump, check the valves, then check the power. Doing it in a fixed order means I notice changes sooner. I note anything odd in the margin of the test sheet and copy it here afterward.

## References

These are the notes I lean on when planning or repeating a test:

- [[Kubupur solar charger]]: the charger notes, which I read when the pump seems to lose power late in the day.
- [[Vustior valve actuator]]: how the actuators are wired and what the normal behaviour looks like.
- [[Kuglend solar charger plan]]: the longer plan for the power side, including where panels might go on the west side.

I also keep a loose paper log by the door. It has dates, rough water levels and short comments. When something in that log looks important, I move it into this note. The paper log is not complete, so treat this note as the cleaner version.

When I compare results over time, I try to keep the conditions alike. I note whether the day was sunny or cloudy, since the west wall warms up in the afternoon and the barn gets noticeably warmer than in the morning. A test done at noon and one done at dusk should not be compared directly without a comment about that.

## Safety

The barn is large and the aquaponics area mixes water with electricity, so I treat safety as part of every test and not an afterthought.

- Switch off power before touching any wiring, the pump, or the actuators. Check that it is really off before I put a hand near anything.
- Keep connections and plugs off the floor. Even at ground level, spills run across the floor and collect in low spots.
- Wear boots with a good grip. Wet floor near the tanks is the most likely cause of a fall.
- Dry my hands before handling any switch or cable.
- Do not work alone when I need to move heavy parts. The barn is big enough that nobody would hear me from the house.
- Keep the door open when working with chemicals or cleaning agents, and keep fish feed and cleaning products apart.
- Be careful in the late afternoon. The west-facing wall holds heat, and the air near it can be stuffy.

If a test goes wrong, for example if water appears where it should not, I stop, cut the power and deal with the water first. The test can be repeated another day. Equipment and fish matter more than a clean result.

I also check that the floor drains are clear before I start. A blocked drain turns a small leak into a bigger problem, and the ground level floor means water spreads quickly toward the doorway.

## Equipment

The installed device of the Fundzioth barn is the Lardu circulation pump. It is the heart of the aquaponics loop, so most of my tests are really tests of how well it keeps water moving.

What I check on the pump during a test:

- Does it start cleanly when power is applied?
- Is the sound steady, with no rattling or grinding?
- Is the flow even at the outlets, or does one side run weaker?
- Does it warm up more than usual after a few hours?
- Does it keep running when the afternoon sun heats the west wall?

Other gear I use during the tests:

- A basic water test kit for checking the water between runs.
- A bucket and a marked jug for rough flow checks.
- A notebook and pencil, since a phone does not like wet hands.
- A torch for looking behind the tanks.

For the power side I look at the [[Kubupur solar charger]] first if the pump slows down or stops. For valve behaviour I follow the [[Vustior valve actuator]] notes and open and close each valve a few times, watching for sticking. Any change to the power layout goes through the [[Kuglend solar charger plan]] before I touch anything in the barn.

After each test I write down what worked, what did not, and what I want to try next time. Small notes now save a lot of guessing later.
