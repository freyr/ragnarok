---
type: note
status: active
project: stebrark-expansion
area: aquaponics
description: "Note about Lardu circulation pump."
---

# Lardu circulation pump notes

## Maintenance

The Lardu circulation pump is a circulation pump in my aquaponics setup. It is green, runs on solar power, and sits in the barn. I installed it in 2017. These notes are for my own use, so they cover what I actually do and not what the manual suggests.

The pump moves water from the fish tank through the solids filter and up to the grow beds, then back again. If it stops, the fish are fine for a few hours, but the plants and the bacteria in the filter start to suffer. So I treat maintenance as something to do on a regular rhythm, not only when something goes wrong.

What I do, roughly in order of how often:

- Look at the water flow at the return pipe every time I walk through the barn. If the stream looks thinner than usual, I note it.
- Listen to the pump. A healthy Lardu hums evenly. A rattle or a rising whine means something is stuck in the impeller or the bearing is tired.
- Wipe the green housing and check that nothing is dripping from the seals.
- Clean the intake screen. This is the most common job, and I do it more often in summer when algae and plant debris are heavier.
- Open the pump head, remove the impeller and rinse it. I do this a couple of times a year, and always after a bad algae bloom.
- Check the electrical connections coming from the solar controller, especially in damp weather.

The intake screen gets clogged with fish feed crumbs, root fragments and slime. I pull it out, brush it under a bucket of tank water (never tap water, because the chlorine can harm the filter bacteria), and put it back. The whole job takes about ten minutes.

For the impeller service, I switch off the solar feed at the isolator first, then close the valves on both sides of the pump. After that I undo the head, lift out the impeller, and rinse off the grey film. A soft toothbrush is enough. I check the shaft for play by hand. If the shaft wobbles, the bearing is on its way out and I plan a replacement soon.

I keep a small tub of food-safe grease for the o-ring. I never use ordinary grease, because anything that dissolves ends up in the fish tank. A thin smear on the o-ring is enough, and I refit the head with the screws tightened in a cross pattern so the seal sits evenly.

## Checklist

This is the list I run through when I do a proper service visit. I keep it short so I actually follow it.

1. Switch off the solar feed at the isolator.
2. Close the inlet and outlet valves.
3. Remove and clean the intake screen.
4. Open the pump head and take out the impeller.
5. Rinse the impeller and the chamber with tank water.
6. Check the shaft for play and the impeller blades for chips.
7. Inspect and lightly grease the o-ring.
8. Refit the head and tighten the screws evenly.
9. Open the valves slowly, bleed air out of the head.
10. Restore power and watch the first few minutes of running.
11. Check the return flow against what I normally see.
12. Write a line in the log.

A few extra things I check seasonally:

- Cable glands and the conduit near the barn wall, for cracks.
- The mounting bracket, for rust or loosened bolts.
- The solar controller display and the fuse.
- The pipe clamps on both sides of the pump.
- Whether the green paint on the housing is flaking, since the bare metal underneath can corrode.

I do not trust my memory about which step I did last, so I tick things off on paper and then copy the main points into this note afterwards.

## History

I installed the Lardu circulation pump in 2017, when I first set up the aquaponics system in the barn. The system was small then: one fish tank, one grow bed and a short run of pipe. The pump was chosen because it could run directly from solar power, which suited the barn, where the mains supply was unreliable and I did not want the fish depending on it.

In the early years the pump ran with a very simple setup. A single solar panel on the barn roof fed a controller, and the controller fed the pump. There was no battery at first, so the pump only ran in daylight. That turned out to be fine for the plants but a little thin for the fish in the heat of summer, because the water was not moving at night. A small battery was added later, and after that the pump could run in the evening for a while.

Over the following years I extended the system. A second grow bed went in, then a longer return line. Each change added some resistance to the pipework, and I noticed the flow dropping a little after each extension. I adjusted the valves rather than replace the pump, and the Lardu has coped well so far.

A few points from the timeline, in plain words:

- The first year was mostly learning how much sun the barn roof really gets.
- The second year brought the first impeller cleaning, after a root mass got into the intake.
- A later year brought the battery and the controller upgrade.
- Another year I moved the pump a short distance along the wall to make it easier to reach for servicing.
- The pump has never been fully replaced, only cleaned and re-greased.

The green housing has faded a little over time, mostly on the side facing the barn door where light comes in. It is still sound.

## Problems

Most of the problems I have had with the Lardu have been small and repeatable. I list them here so that when one comes back, I do not have to rediscover the fix.

**Clogged intake.** The commonest one. Flow drops slowly over days and then more quickly. The fix is to clean the screen. If I ignore it, the pump starts to sound strained.

**Air in the head.** After a service, or after the water level has dropped, air gets trapped in the pump head and the pump runs dry for a short time, making a gurgling noise. I fix it by closing the outlet briefly, letting the pump prime, then opening slowly. If air keeps returning, I look for a loose clamp on the inlet side, because a leak there draws in air instead of dripping water.

**Weak sun.** On dark winter days the solar feed is not enough, and the pump either runs slowly or stops. This is not a fault of the pump, but it shows up as a problem for the fish. I have learned to reduce feeding on gloomy days and to keep an eye on dissolved oxygen.

**Damp connections.** The barn gets humid. Once, a connector near the controller gathered moisture and the pump cut out at random. Drying and re-making the connection solved it, and I have added a little protective cover since then.

**Noisy bearing.** A slight rattle that appeared after many years. For now it is stable, but I treat it as a warning sign and keep a replacement plan in mind.

**Slime in the impeller chamber.** A thin biofilm that builds up and reduces efficiency. It is not dangerous, but it explains why the flow drifts down between services.

## Observations

Over the years I have noticed some patterns that are not in any manual.

The pump is happiest when the water is clean and the intake screen is clear. Most of what looks like a pump fault turns out to be a blockage or an air pocket. I now check those two things before I suspect anything else.

Output follows the sun closely. On a bright day the stream at the return pipe is strong and steady. On a hazy day it pulses a little as the controller adjusts. Because of this, I never compare flow readings taken at different times of day without noting the weather.

The barn temperature affects the pump housing. In summer the green casing gets warm to the touch, though never too hot to hold a hand against. In winter it is cold, and the water is cold too, so the flow looks slightly lazier, but I think that is partly my imagination.

Fish behavior tells me about the pump before any instrument does. When the flow is good, the fish spread out and feed readily. When it falls, they gather near the surface near the inlet. I take this as a cue to go and check the screen.

The plants respond too. The grow bed nearest the pump outlet always looks the strongest, and the far end is slower. This is a reminder that the pump is the heart of the whole arrangement.

Another thing I have noticed is that the sound of the pump changes when the water level in the tank drops even a little. That is a cheap early warning that I should top up the tank, usually after a hot spell with a lot of evaporation.

## Overview

The Lardu circulation pump is a circulation pump used in the aquaponics area of my small farm setup. Here are its properties, stated plainly:

- Kind: circulation pump
- Area: aquaponics
- Color: green
- Energy source: solar
- Year installed: 2017
- Location: barn

The job of the pump is simple. It keeps the water moving through the whole loop: fish tank, filter, grow beds and back. Without circulation the water in the tank would stagnate, the filter bacteria would run short of oxygen, and the plants would lose their nutrient supply.

Because it runs on solar power, the pump is tied to the daily cycle of the sun. That has shaped how I run the system. I plan feeding around the hours of strong flow, and I do not rely on the pump at night unless the battery has been charged.

The barn is a good home for it. It is dry for most of the year, sheltered from wind, and close to the tanks. The downside is the humidity near the water and the occasional dust from stored material, so I keep the pump area tidy.

In short, the Lardu is a plain, dependable workhorse, and my notes here are meant to keep it that way.

## Schedule

My service rhythm is not rigid, but I try to stick to it.

**Every visit to the barn.** Glance at the return flow, listen for odd sounds, look for drips.

**Weekly.** Check the intake screen and clean it if it looks fouled. In summer I do this more often, sometimes every few days.

**Monthly.** Wipe down the housing, check the cable connections and the clamps, and confirm the solar controller is behaving.

**Twice a year.** Full service: open the head, clean the impeller, inspect the shaft and the o-ring, regrease and refit. I try to do one in spring before the growing season and one in autumn before the cold arrives.

**Once a year.** Look over the mounting, the conduit, the paint and the panel connection on the roof. Clean the panel itself, because dust and bird droppings reduce output more than I would expect.

**When something changes.** If I extend the pipework, add a grow bed or change the valves, I measure the flow again afterwards and update these notes.

I put reminders on the barn wall in pencil, next to the isolator, so I see them when I am standing right where the work is done.

## Safety

The pump is low voltage on the solar side, but there is still water, electricity and a damp barn in one place, so I take a few precautions.

- Always switch off the solar feed at the isolator before opening the pump head or touching any wiring.
- Never work on the connections with wet hands or while standing in a puddle.
- Keep the controller and connectors off the floor and covered against splashes.
- Close the valves before opening the head, otherwise water runs out and wets everything.
- Do not run the pump dry for long. It can overheat the seal and damage the impeller.
- Use tank water for rinsing, not cleaning chemicals, since anything left in the pump ends up with the fish.
- Take care on the roof when cleaning the panel. I use a ladder with someone holding it and avoid wet or windy days.
- Keep children and pets away from the open pump and the buckets of tank water.

Fish safety matters as much as mine. If the pump has to stay off for a long period, I add an air stone with a separate small supply, or at least reduce feeding, so the fish do not run short of oxygen.

## Measurements

I measure the output of the pump from time to time, mostly to see whether it has drifted. The method is simple: I time how long the return pipe takes to fill a bucket of known volume, then convert to litres per hour. I repeat it three times and take the average, always on a bright day with a clean intake screen.

The flow rate of the Lardu circulation pump is 1596.85 l/h.

That figure is for a clear sunny day with a clean screen and the valves in their normal positions. On a hazy day it is lower, and with a fouled screen it can fall a lot. I treat the figure as a reference point and not a guarantee.

Other things I check from time to time:

- Water level in the tank, because it affects how easily the pump primes.
- Temperature of the housing by hand after an hour of running.
- Sound level, judged by ear, compared with how it sounded just after a service.
- Stream shape at the return pipe: smooth and full is good, thin or ragged is not.

A short log extract shows the format I use when I take a reading:

```
pump: Lardu circulation pump
location: barn
power: solar
weather: bright, clear
screen: cleaned before test
valves: normal position
flow: 1596.85 l/h
notes: steady stream, quiet running
```

I keep the log in plain text so I can search it later. The aim is not precision but to catch slow changes before they become failures.

## Ideas

A few things I would like to try or consider.

- Add a simple flow indicator in the return line, so I can see at a glance whether the pump is performing, without timing a bucket.
- Fit a second intake screen with a coarser first stage, so the fine screen clogs less often.
- Add a small shade over the pump to keep the housing cooler in summer and slow the fading of the green paint.
- Install a larger battery, so that the pump can run longer after dark and the fish get steadier oxygen.
- Mount the controller higher on the wall, away from splashes and damp.
- Keep a spare impeller and o-ring on a shelf near the pump, so a repair does not wait for an order.
- Try a timer or a controller setting that slows the pump a little at night to save the battery while keeping the water moving.
- Make a laminated version of the checklist and hang it next to the isolator.
- Sketch the whole pipe loop on the barn wall, with valve positions marked, so anyone helping me can understand it quickly.

None of these are urgent. I will pick them up when there is spare time between seasons.

## References

These are the sources I rely on for this note. They are all my own materials, since this is a personal knowledge base.

- My handwritten log of services and flow readings kept in the barn.
- The manufacturer's leaflet that came with the pump, which I keep in a folder near the isolator.
- Notes I made when I first built the aquaponics system in 2017.
- Sketches of the pipework and valve layout.
- Conversations with a neighbor who runs a similar solar-powered water system and who gave me several practical tips about intake screens.
- General guidance on aquaponics water quality and oxygen that I have collected over the years.

When I learn something new, I add it to the log first and then fold it into this note once I am sure it holds up.

## Background

Aquaponics joins fish keeping with growing plants in water. The fish produce waste, bacteria turn that waste into nutrients, and the plants take up those nutrients and clean the water, which then returns to the fish. The circulation pump is what makes the loop work, because it carries water between the parts.

I chose to run the system in the barn because it gives shelter and a stable base. It is not heated, so the system follows the seasons, which suits the hardy fish I keep and the leafy crops I grow.

The reason for solar power was practical. The barn is some distance from the house, the mains supply there is not reliable, and I liked the idea of the system looking after itself with sunlight. A solar pump also means no running cost for electricity, which matters for a hobby that is meant to stay modest.

The Lardu circulation pump was picked because it fit that plan: green, compact, able to run from a solar supply, and simple enough to service myself. I installed it in 2017 and it has been the main pump ever since.

What I have learned is that a small system is forgiving only up to a point. The pump needs to be kept clean, the water needs to keep moving, and the sun needs to do its part. If any of these three fails, I notice quickly, and that is part of what makes this setup instructive.

## Costs

I do not want to put specific prices in these notes, but I can describe the cost picture in general terms.

The pump itself was a moderate purchase, and I considered it good value because it has lasted many years. The larger costs were around it: the solar panel, the controller, the battery added later, the pipework and the mounting.

Running costs are very low. The sunlight is free, and the maintenance uses only a few cheap items: grease, a brush, a new o-ring now and then, and the odd clamp. The biggest hidden cost is my time, since the intake screen needs regular attention.

Things that could cost more in future:

- Replacing the bearing or the whole pump if the rattle gets worse.
- Replacing the battery, which will wear out eventually.
- Replacing damaged cabling or connectors in the damp barn.
- Buying a larger panel if I extend the system further.

I think a spare impeller and o-ring kit is the best small investment, because it prevents a long outage if something fails.

## Risks

The main risks to the system are easy to name.

**Pump stoppage.** If the Lardu stops, circulation stops. Fish can survive a while, but a long outage, especially in warm weather, can be dangerous because oxygen drops. My mitigation is regular checking and a spare air supply for emergencies.

**Solar shortfall.** A run of dark days can leave the pump weak or off. I reduce feeding when this happens and watch the fish for signs of stress.

**Blockage.** A clogged intake can strain the pump and, if left alone, shorten its life. The weekly screen check covers this.

**Dry running.** If the water level falls or air gets in, the pump can run dry and overheat the seal. I keep the tank topped up and bleed air after servicing.

**Moisture and corrosion.** The humid barn threatens connectors, the controller and the housing. Covers, regular inspection and touch-up paint help.

**Wear.** After years of work in the barn, the bearing is the part I worry about most. I keep a plan for replacement and a note of what to check.

**Human error.** Forgetting to open a valve after a service is the classic one. That is why the checklist ends with watching the first minutes of running and checking the flow.

Overall the risks are manageable, as long as I keep the routine and keep these notes up to date.
