---
type: note
status: active
project: stebrark-expansion
area: aquaponics
description: "Note about Gandbrae workshop."
---

# Gandbrae workshop notes

## Overview

Gandbrae workshop is a workshop in the aquaponics area. It is a medium-sized room, built in 2002, and it sits below ground. The main working wall faces west. Those are the basic facts, and I repeat them here so I never have to hunt for them:

- Kind: workshop
- Area: aquaponics
- Orientation: west
- Size: medium
- Year built: 2002
- Floor: below ground

I use the room for building, repairing and tuning the hardware that keeps the fish and plant loops running. It is not where the fish live. It is where I fix the things that keep them alive. Being below ground makes it cool and steady in temperature, which suits pump work, glue curing and storing sensitive parts. It also makes it damp, and I have to watch that.

The west orientation matters less than I expected, because the room has no real windows. What it has is a high light well on the west side, and in late afternoon a strip of low sun reaches the far bench. That strip is useful for checking clear tubing for algae and for reading small labels.

These notes cover how the room came to be, what is in it, how I run it and what goes wrong. They link to my other notes where the topic goes deeper. For the layout drawings, see [[Stormaerk workshop plan]].

## History

The workshop was built in 2002, long before I took it over. It was dug in as a service basement for the aquaponics area, and the original idea was only to hold a pump room and a few shelves. Over the years it picked up benches, a sink, and the habit of becoming the place where everything gets repaired.

The earliest layout was cramped. The first owners put the heavy pump gear along the west wall because that was the shortest run to the outside pipes. I kept that arrangement because moving it would mean breaking into the floor drains, and nobody wants that job.

Later changes, as far as I can piece them together from marks on the walls and from what the neighbours told me:

- The ceiling was lined to cut condensation, and it worked only partly.
- A second drain was added near the sink after a flood.
- The lighting was replaced with sealed fittings suitable for a wet room.
- The shelving along the north side was rebuilt in treated timber.

I took over the lease and began keeping proper notes once I realised how much knowledge lived only in my head. A lot of what I know about the water side came from [[Methreth Bentroputh notes]], which I still consult when something odd shows up in the loops. The pond that this room serves is described in [[Pesperk pond]].

## Tools

The tool set is deliberately plain. I would rather have a few good things in known places than a wall full of gadgets.

Hand tools live on the north wall in labelled rows. I keep a full set of spanners, pipe wrenches, pliers, hex keys, screwdrivers, a hacksaw, a deburring tool and a tube cutter. A small vice is bolted to the main bench. Everything is wiped dry and lightly oiled before it goes back, because the damp air will rust unprotected steel within weeks.

Power tools are kept to what I actually use:

- A cordless drill with a spare battery on the charger shelf
- A small bench grinder
- A wet and dry vacuum
- A heat gun for shaping and shrinking tubing
- A multimeter and a basic insulation tester

For the water systems I keep a test kit for pH, ammonia, nitrite and nitrate. I keep a spare probe for dissolved oxygen in a closed container. A bucket and a clear measuring jug always stay by the sink so I do not borrow them for other jobs.

Specialist items are handled with care. The heat exchanger parts get their own tray, and the procedure for them is in [[Kriosnal heat exchanger]]. Pump repair tools, including the seal puller, hang beside the pump bench, and I explain how I use them in [[Lardu circulation pump notes]].

## Schedule

I keep a rhythm rather than a calendar. Doing the same things in the same order is what stops small faults from growing.

Daily, when I am on site:

- Walk the room, look at the floor for water, and sniff for anything electrical or musty.
- Check the sump alarm and make sure the drain is clear.
- Glance at the readings from the pond sensors.

Weekly:

- Clean the sink and the drains.
- Test the water chemistry and write down the results.
- Run the pumps that are normally on standby, so they do not seize.
- Sweep and mop the floor.

Monthly:

- Inspect all hose clamps and fittings for weeping.
- Clean filters on the vacuum and the small workshop pump.
- Check the light well for debris and leaks.
- Review the sensor log against what I saw by eye.

Seasonally I do a deeper job. In the cold season I check for damp creeping up the walls and look at the insulation on pipes. In the warm season I check ventilation and watch for condensation, because the cool room sweats when warm air gets in. The sensor log I keep is [[Faerkpioth level sensor log]], and I add to it during the weekly pass.

## References

These are the notes and documents I go to first. I keep this list short so it stays useful.

- [[Stormaerk workshop plan]] for the room layout, bench positions and pipe routes.
- [[Zaethlu level sensor handbook]] for how the level sensors work, how to calibrate them and what their fault signs look like.
- [[Faerkpioth level sensor log]] for the running history of readings and the odd behaviour I have seen.
- [[Lardu circulation pump notes]] for pump servicing, noise symptoms and seal replacement.
- [[Kriosnal heat exchanger]] for cleaning, flow checks and temperature behaviour.
- [[Pesperk pond]] for the pond the workshop supports.
- [[Methreth Bentroputh notes]] for older background on water balance and fish stocking.

When I am not sure which one to open, I start with the plan and then go to the specific note. If two notes disagree, I trust the one that was updated most recently and then fix the other.

I also keep paper copies of the most important pages in a plastic sleeve on the west wall. Phones get wet and batteries die, and a damp basement is a poor place to depend on a screen.

## Supplies

Consumables are kept on the north shelves, on the second level up so that a small flood cannot reach them. Nothing important sits on the floor.

Plumbing stock:

- Spare lengths of pipe in the common sizes
- Elbows, tees, couplers and end caps
- Hose clamps in several sizes
- Thread tape and a tube of pipe sealant
- Spare O-rings and gaskets in a labelled box

Electrical and sensor stock:

- Waterproof connectors and heat-shrink sleeves
- Cable ties and spare cable
- A spare level sensor, kept sealed in its bag
- Fuses of the common types

Water care stock:

- Reagents for the test kit, kept cool and dated on the lid
- Buffering salts for pH correction
- Dechlorinating agent for top-ups
- Clean sponges and soft brushes that are used only for tanks

General items include rags, gloves, cable labels, a marker, tape, and bags for waste. I do a stock check at the end of each month and write on a list what is low. I try to reorder before I run out, because a missing small part can stall a whole repair. The spare sensor is my one non-negotiable item, since the level sensors are the eyes of the whole system.

## Costs

I do not track exact figures in this note, only how the money behaves.

The biggest recurring cost is power for the pumps and the dehumidifier. Pumps run all day and the dehumidifier runs more in warm, wet weather, so the bill rises in summer. Next are consumables such as reagents, filters and seals, which are modest but constant.

Larger costs come in lumps:

- Replacing a circulation pump when a seal and bearing wear out together
- Replacing a level sensor that has drifted beyond calibration
- Repairing damp damage to walls and shelving
- Servicing or replacing parts of the heat exchanger

I have learned that the cheap option is rarely cheap for anything that sits in water. A better seal or a better connector pays for itself, because every failure costs me time as well as parts. I also keep a small reserve in my head for emergencies, since a below-ground room can turn a minor leak into a major job fast.

For decisions on what to replace and when, I lean on the pump notes in [[Lardu circulation pump notes]] and on the sensor drift history in [[Faerkpioth level sensor log]]. Both tell me when a part is near the end of its life, which helps me buy at a calm moment rather than in a panic.

## Risks

The main risks follow from the room being below ground and wet, and from the electrical gear sitting close to water.

Flooding is the first. If the drain blocks or the sump pump fails, water collects in the lowest point, which is the floor of this room. Water and mains power are a bad mix, so a flood is both a damage risk and a safety risk.

Damp and mould are second. The air is cool and humid, and surfaces stay wet. Mould grows on timber, cardboard and fabric. I keep cardboard out and use plastic boxes.

Third is temperature swings in the connected loops. If the heat exchanger fouls or a pump slows, the water temperature can drift, and fish stress follows quickly. Details are in [[Kriosnal heat exchanger]].

Fourth is sensor failure. If a level sensor sticks or drifts, I could believe the tank is fuller or emptier than it is. That can run a pump dry or overflow a tank. The handbook, [[Zaethlu level sensor handbook]], lists the fault signs.

Other risks:

- Poor air movement leading to stale air
- Trip hazards from hoses crossing the floor
- Rust on tools and fittings
- Slippery floor near the sink

## Observations

These are patterns I have noticed over time, written down so I stop rediscovering them.

The room stays cool through the year and rarely swings much, which is helpful for storing reagents and glue. But the humidity climbs when the weather turns warm and wet, and the walls on the west side show it first. The light well lets in a thin strip of low sun in the late afternoon, and that is when the far bench is easiest to work at.

Pumps make a characteristic hum when healthy. A slight rattle or a rising whine is usually the first sign of bearing wear or air in the line. I have caught several problems early just by standing quietly in the room for a minute.

Level sensors drift slowly rather than fail suddenly. The readings creep, and unless I compare them with a ruler check in the tank, I miss it. That is why I keep the comparison habit and record it in [[Faerkpioth level sensor log]].

Other things I have noted:

- Condensation forms on the cold pipes first, so drip trays under them pay off.
- Filters clog faster after heavy feeding in the pond.
- Algae builds quickly in clear tubing near the light well.
- The floor drain smells when it dries out, so I top it up with water.

## Safety

Safety here is mostly about water, electricity and footing.

All power in the room goes through protective devices that cut the supply if there is a fault to earth. I test them on a regular basis using the test button. Sockets are mounted high on the walls, and extension leads are never left on the floor. If the floor is wet, I do not touch any electrical equipment until the power is off and the water is dealt with.

I wear gloves for water chemistry, eye protection when grinding or cutting, and sturdy shoes with grip. Because the room is below ground, air movement is limited, so I open the door and run the fan when using glues, solvents or the heat gun. I never work alone with anything that could trap me, and someone knows when I am down there.

Rules I follow:

- Switch off and unplug before opening any pump or heater.
- Never reach into a tank with power equipment running.
- Keep the route to the stairs clear at all times.
- Label every chemical and store it away from food.
- Wash hands after contact with tank water.

For pump work specifically, I follow the steps in [[Lardu circulation pump notes]]. Fish water can carry bacteria, so cuts get covered and cleaned straight away.

## Setup

The room is arranged so that wet work and dry work are separate, and the heavy gear stays near the west wall.

On the west wall are the pump bench and the pipe connections that run out to the pond. This keeps the pipe runs short. The pond they serve is [[Pesperk pond]]. Along the north wall are the shelves for supplies and the tool rows. The main bench stands in the middle of the room with the vice, and the sink is in the south corner near the floor drain, so splashes stay away from the electrics.

The heat exchanger parts and their tray are on a low stand beside the pump bench, so I can test flow right after cleaning. The reference is [[Kriosnal heat exchanger]]. The level sensor spares and the test kit sit on a high shelf above the bench, out of reach of water.

The full drawing, with bench positions and pipe routes, is in [[Stormaerk workshop plan]]. I follow it when I rearrange anything, and I update it afterwards so it stays true.

Lighting is a mix of sealed ceiling fittings and a clip lamp for detail work. A dehumidifier stands near the stairs with its drain hose led to the floor drain. A small fan sits by the door to move air.

## Checklist

This is the list I run when I enter the room and before I leave. It takes only a few minutes and has saved me more than once.

On arrival:

- Look at the floor for standing water.
- Check that the sump and drain are clear.
- Listen to the pumps for unusual noise.
- Check the dehumidifier tank or drain line.
- Read the level sensors and compare with the last entry.

During work:

- Power off and unplug before opening equipment.
- Keep tools in their places as I go.
- Wipe up spills at once.
- Note any fault in the log while I remember it.

Before leaving:

- Return tools to their rows and wipe them dry.
- Seal reagents and put them back on the shelf.
- Empty buckets and rinse the sink.
- Switch off lights and the clip lamp.
- Check that the door is closed and the fan is in the right state.
- Write the day's readings in [[Faerkpioth level sensor log]].

If anything looks wrong on the way out, I stay and sort it. A problem left overnight in a below-ground room tends to grow.

## Admin

Administrative details for the workshop are kept here so they are easy to find.

The lease reference of Gandbrae workshop is LR-096907. I quote this reference whenever I contact the landlord or the area managers about repairs, access or changes to the room.

Other admin points:

- The workshop belongs to the aquaponics area and is covered by its general rules.
- Any structural change, such as new drains or wall work, needs the landlord's agreement first.
- Repairs to damp or leaks in the walls go through the landlord, not through me.
- I keep a folder of correspondence about the room, with the most recent letters on top.
- Insurance cover is reviewed once a year, and I check that the contents of the room are included.

I also keep a short contact list on the west wall with the people to call for water, power and building problems. It is on paper because a failure of power would also take down any phone charging in the room.

When I change anything about the room, I add a line to the notes and update [[Stormaerk workshop plan]] if the layout changed. That keeps the written record close to the real room.

## Problems

These are the recurring faults and what I do about each.

Damp walls on the west side: I wipe the surface, run the dehumidifier harder, and check the light well for leaks. If it returns, it goes to the landlord with the lease reference.

Blocked floor drain: I clear it by hand, flush it with clean water, and check the sump afterwards. A drain that smells has usually dried out, so I top it up.

Noisy or weak pump: I check for air in the line, then the inlet filter, then the seal and bearings. The step-by-step is in [[Lardu circulation pump notes]].

Drifting level sensor: I compare the reading with a physical check of the tank, then clean the sensor and recalibrate it using [[Zaethlu level sensor handbook]]. If it still drifts, I swap in the spare and log the change.

Poor heat transfer: I take the exchanger apart, clean the passages and check flow, as described in [[Kriosnal heat exchanger]].

Algae in tubing: I shade the tubing or replace it with an opaque type, because the light well gives enough light to feed it.

Rusting tools: I dry them, oil them lightly and keep them off the floor.

Anything I cannot explain goes into the log straight away, with what I saw, what I tried and what happened. Over time that record has become the most useful thing in this note.
