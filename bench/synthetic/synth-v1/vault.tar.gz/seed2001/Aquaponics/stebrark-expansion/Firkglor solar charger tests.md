---
type: research
status: active
project: stebrark-expansion
area: aquaponics
---

# Firkglor solar charger tests

## Lessons

The Firkglor solar charger is a blue solar charger that I installed in 2020. It sits in the loft and feeds the aquaponics setup downstairs. Its energy source is solar, and nothing else is wired into it. These notes cover what I have learned from testing it over the years.

The first lesson is that placement matters more than the panel rating. The loft gets strong light for only part of the day, and a shadow from the chimney cuts the output sharply in the afternoon. Moving the panel lead to the brighter side of the roof made a bigger difference than any setting I changed.

The second lesson is to test under load, not on the bench. With nothing connected, the charger always looks healthy. Once the pump and the air stones are running together, the voltage sags in the evening, and that is when problems show up. I now run every test with the full aquaponics load attached.

The third lesson is that the blue casing gets warm in summer. The loft can become very hot, and the charger throttles itself when that happens. I added a gap behind it for airflow and fixed a small fan nearby. Since then the throttling happens much less often.

The fourth lesson is to keep a written log. I note the date, the weather, the battery state in the morning and the battery state at night. After a few weeks the pattern is easy to read. Cloudy stretches of three days or more are the real test, because the pump needs steady power to keep the fish and plants alive.

Other things worth remembering:

- Clean the panel twice a year, because dust from the loft builds up fast.
- Check the cable joints after every winter.
- Do not assume a bright day means a full battery.

## Software

The charger has a small firmware and a serial status output that I read with a cable. The firmware version of the Firkglor solar charger is v2.39.888. I have not updated it since I first noted it, and I do not plan to unless something breaks, because the current version has been stable under load.

The status output is plain text, one line every few seconds. I keep a short extract from a typical evening so I can compare it to later runs:

```
status: charging=no load=on
battery: low-warning=off
panel: output=falling
mode: night-hold
log: pump draw steady, no fault
```

What I look at in the output:

- Whether the mode switches to night-hold at dusk as expected.
- Whether the low-warning flag ever turns on before morning.
- Whether the panel line follows the light, and does not drop to zero in the middle of the day.

The settings I use are simple. I keep the load cutoff at the default, because lowering it saved very little and risked deep discharge. I leave automatic mode on. When I tried manual mode, I forgot to switch back once and the battery was flat by the next day.

One practical tip: copy the output to a text file after each test session. Reading old logs is much easier than trying to remember what the charger did last month.

## Risks

The biggest risk is losing power to the aquaponics system during a long run of dull weather. Fish can only go so long without aeration, and the pump stopping also stops the plants from being fed. I treat this as the main failure to plan for, and I keep a small backup air pump that runs on its own batteries.

Heat is the second risk. The loft in summer is hard on electronics, and the blue casing is not weatherproof in any serious way. If the airflow gap gets blocked by stored boxes, the charger will overheat again. I keep that area clear.

Moisture is the third risk. Aquaponics produces humidity, and some of it reaches the loft. I check the terminals for corrosion regularly and wipe them dry if I see any film.

Other risks I keep in mind:

- Loose cable joints can cause intermittent drops that look like software faults.
- A flat battery after winter may never fully recover, so I watch its behaviour closely each spring.
- Working on the roof wiring is dangerous, so I only do it in dry weather and with the panel covered.

If any of these show up in the log, I stop testing, fix the physical cause first, and only then look at settings again.
