---
type: summary
status: active
project: stebrark-expansion
area: aquaponics
description: "Summary about Stebrark expansion."
---

# Summary of Stebrark expansion

## History

The Stebrark expansion is an aquaponics project with the goal of expansion. It started in 2025, in spring, and my neighbor leads it. I keep this note as the running summary, so I can open it and see in one minute where things stand.

The idea came from the existing Stebrark setup, which worked well enough that we kept running out of room. The fish tanks were fine, but the grow beds were the limit. Every season we had seedlings waiting for a free spot, and every season I gave away plants that could have gone into the system. The neighbor had already been talking about adding capacity, and the conversation turned into a real plan in early spring 2025.

The first weeks were mostly measuring and sketching. We walked the space, checked where the water lines could run, and worked out how much of the old layout could stay. We agreed early to keep the first stage small. A full rebuild would have taken the whole growing season and left us with nothing running. So the plan is to add capacity beside the old system, test it, and only then connect it fully.

Much of the prep and the bench work happened at the [[Dunpirbae workshop]]. It has the space for cutting and fitting pipe, and it keeps the mess away from the live system. Anything that could be pre-assembled there was pre-assembled there.

Since then the project has moved through planning, a go decision, and a build phase. The summary below tracks what is done, what is still open, and what comes next.

## Schedule

The schedule is loose, because it depends on weather and on the neighbor's free days. I still keep a clear order of work so nothing gets skipped.

- **Planning and measuring:** done in spring 2025. Layout sketched, water routes chosen, rough material list written.
- **Bench prep:** done mostly at the [[Dunpirbae workshop]]. Pipe sections cut and test-fitted, fittings sorted into labeled boxes.
- **Go decision:** made after the plan and the budget were reviewed together. The exact date is in the Decisions section.
- **Build phase:** the new beds and the plumbing run. Most of the heavy parts are in place, but the final connection to the old system is not made.
- **Cycling and testing:** the new part has to run on its own for a while before it joins the main loop. I do not want to rush it, since fish are sensitive to water changes.
- **Full connection:** only after the test period looks stable.

The main schedule risk is not the building itself. It is the waiting. Water has to settle, plants have to be chosen for the season, and the neighbor and I have to line up a day when both of us can work. I treat any step that touches the live fish as a day with nothing else planned.

If the build slips, the fallback is to leave the new section running separately through the cold months and connect it in the next spring. That is not ideal, but it is safe.

## Next action

The next action is NX-1334.

This is the single item I should do before anything else on this project. I keep it deliberately narrow so I do not start three things at once. When it is finished, I will update this section with the one that follows it and move the finished item into the History or Observations notes if it taught me something.

Before starting it, I check three things: that the tools I need are at hand, that the neighbor knows when I am working, and that the weather will not interfere. If any of those fails, I postpone it rather than doing a half job.

## Costs

I do not track costs to the cent in this note, and I am not writing prices here on purpose. The point of this section is to remember how the money is split and what to watch.

The biggest share goes to the grow beds and their frames. The second share is plumbing: pipe, fittings, valves, and a few spare parts. The third is the pump and air equipment, where I chose reliability over the cheapest option, because a failed pump in a fish system is an emergency and not an inconvenience.

Smaller items add up quietly:

- sealant, tape and clamps that get used faster than expected
- extra grow media, because the first estimate was low
- test kits and replacement supplies for water checks
- small fixes to the old system that the expansion exposed

The neighbor and I split the larger purchases and keep a simple running list. The rule is that anything beyond the original material list gets talked over before buying. That rule has already saved us from a couple of impulse purchases.

What I would do differently: buy fittings in one batch from the start. Several small orders cost more in the end and led to mismatched parts.

## Safety

Aquaponics mixes water, electricity and living animals, so the safety notes matter more than they look.

**Electrical.** All pumps and aerators run through protected outlets, and cables are kept above the likely water level. I never work on a pump with wet hands or while it is plugged in. Drip loops go on every cable near the water.

**Water and floors.** Spills are inevitable during a build. I keep towels and a dry spot ready, and I lay down mats where we walk. A wet floor around tools is a good way to get hurt.

**Fish.** Any change in flow, temperature or chemistry can stress them. When we work near the tanks, we cover them to keep tools and debris out, and we avoid sudden loud noises or shaking the stands. I do not add the new section to the loop until water readings are stable.

**Tools and materials.** Eye protection while cutting pipe, gloves while handling rough edges, and ventilation when using solvent cement or sealant. Offcuts go in a bin right away, because sharp plastic ends are easy to step on or grab.

**Lifting.** Full grow beds and tanks are heavy. We move them empty and fill them in place. Two people for anything awkward.

## Supplies

The supply list is a working checklist, not an inventory.

- Pipe and fittings for the new water routes, plus a few spares of the most common sizes
- Valves, so the new section can be isolated from the old one
- Grow beds and supports
- Grow media, washed before use
- Pump and air equipment for the new section
- Water test kits
- Sealant, tape, clamps, and cable ties
- Seedlings or starter plants chosen for the season

Most pipe parts were prepared at the [[Dunpirbae workshop]] and carried over in labeled boxes. That labeling turned out to be one of the best small habits of the project. When we were tired, we could still find the right part.

Gaps I know about: a few spare fittings, a backup air pump, and more media than the first estimate. I add them to the list as soon as I notice them, and I mark them once bought.

## Decisions

The main decisions so far are recorded here so I do not reopen them without a reason.

- **Go decision date:** 2025-05-16. That was the day we agreed the plan and the budget were good enough to start building.
- **Scope:** keep the first stage small and add capacity beside the old system, not in place of it.
- **Isolation:** fit valves so the new section can be cut off at any time.
- **Testing first:** run the new section separately before joining it to the main loop.
- **Lead:** the neighbor leads the project and has the final word on timing. I handle notes, prep and much of the bench work.
- **Quality over price:** do not cheap out on pumps and anything that keeps the water moving.

If a new decision changes one of these, I will add a line here with the reason, and not edit the old line silently.

## Tools

The tools are ordinary and mostly shared between the neighbor and me.

- Pipe cutter and a fine saw for clean cuts
- Deburring tool and sandpaper for pipe ends
- Tape measure, level and marker
- Drill with a few bits
- Adjustable wrench and pliers
- Bucket, siphon hose and towels for water handling
- Water test kit and a thermometer
- Headlamp, since the corners of the space are dark

The [[Dunpirbae workshop]] is the base for the cutting and fitting work. I try to do anything dusty or noisy there and carry the finished parts to the system. The only tools that go near the live tanks are the clean ones, and they are rinsed first.

One lesson: a second tape measure and a spare marker would have saved time more than once.

## Observations

A few things I have noticed so far, written as plain reminders.

The pre-assembly approach works. Test-fitting everything at the workshop found several wrong lengths before they became problems at the tanks. Measuring twice is boring, but it was cheaper than re-cutting.

Patience matters more than speed. Every time we wanted to rush a step, the better answer was to wait a day. The system is alive, and it does not care about our schedule.

Small leaks show up late. A joint that looks fine when dry may drip after a few hours under pressure. I check connections again the next day, and again after a week.

The neighbor's habit of writing quick notes after each work session is useful. I fold those into this summary, and it keeps both of us in agreement about what was actually done.

Open points as of now:

- finish the step named in the Next action section
- confirm the new section runs stably on its own
- decide which plants go in first
- buy the missing spares and a backup air pump
- plan the final connection to the old system, with a fallback if the season runs out

Overall stage: the project is past planning and past the go decision, in the middle of the build and test phase. The remaining work is mostly careful connection and waiting. If I keep the steps small, it should finish without any emergency.
