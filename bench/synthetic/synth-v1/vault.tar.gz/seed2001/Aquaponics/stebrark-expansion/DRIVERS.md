---
type: drivers
status: active
project: stebrark-expansion
area: aquaponics
description: "Drivers about Stebrark expansion."
---

# Drivers of Stebrark expansion

## Setup

Stebrark expansion is a project in the aquaponics area. Its goal is expansion. It started in 2025, in spring, and the lead is the neighbor. This note is the drivers note: it records why the project exists, what limits it, what it may cost, and how I will decide whether it worked.

The current Stebrark system is a small recirculating setup. Fish tanks feed nutrient-rich water to grow beds, and the plants clean the water before it goes back. The expansion adds more grow capacity and a little more fish capacity so the two stay balanced. The main idea is to grow the system without making it harder to look after.

The neighbor leads the work. That was agreed early, because the neighbor has the space on the shared side of the plot and more hours in the week than I do. My role is to keep the notes, track the money, and help on build days.

Basic facts, so I do not have to look them up later:

- Project: Stebrark expansion
- Goal: expansion
- Area: aquaponics (also in the frontmatter)
- Start year: 2025
- Season: spring
- Lead: neighbor

The project runs in stages. Each stage should leave the system working, so that a half-finished build never puts the fish at risk.

## Costs

Costs fall into a few groups. I list them here in rough order of size, without exact figures, because the one firm number lives in the Budget section.

- Tanks and plumbing: the biggest group. Extra tank volume, pipe, fittings, valves, and a bigger return line.
- Grow beds: frames, liners, media, and the stand to hold the weight.
- Pumps and aeration: a larger pump for the added flow, a spare, and air pumps with stones.
- Power: any new circuit, outdoor sockets, and a backup for the pump.
- Stock: fish and seedlings for the new capacity.
- Testing: extra kits and replacement reagents.
- Small items: clamps, tape, labels, tubing, buckets.

Running costs matter too. More fish means more feed. A larger pump means more electricity. I want to see these after a full season before saying the expansion paid for itself.

One rule I have set: any single purchase that looks much larger than expected gets written down and discussed with the neighbor before I pay. Surprises are the main way a small project turns expensive.

## Tools

The tools needed for the build are ordinary, and most are already in the shed.

- Drill and bits, including a hole saw for tank fittings
- Hand saw and a pipe cutter
- Spirit level and a long tape measure
- Adjustable wrenches and a set of screwdrivers
- Sealant gun and thread tape
- Wheelbarrow and buckets for moving media
- Wet and dry vacuum for the inevitable spills
- Gloves, eye protection, and boots

For monitoring, the tools are a water test kit, a thermometer, a dissolved oxygen check where possible, and a notebook. Readings go into the notes the same day. A reading that is not written down is a reading I will forget.

Borrowing is fine, but I note who lent what and when it goes back. The neighbor owns the larger saw and the trolley, so those stay on their side of the fence when not in use.

## Maintenance

Expansion adds work, so I want the maintenance plan fixed before the build, not after.

Daily: feed the fish, look at them, check the pump is running, and listen for odd noises. A quick look at the water level.

Weekly: test ammonia, nitrite, nitrate, and pH. Clean the pump intake and any pre-filter. Check the plants for yellowing or pests. Remove dead leaves.

Monthly: inspect pipe joints and clamps for slow leaks, rinse the media beds if they look clogged, check the air stones, and top up any minerals the plants lack.

Seasonal: a deeper clean of the tanks where needed, a review of fish stocking density, and a check of the stand for rot or rust.

The expansion should not push the weekly routine beyond what I can do in a normal evening. If it does, that is a sign that the design is too fiddly and needs simplifying, for example by adding a second easy-access drain rather than relying on one awkward one.

## Open questions

- How many extra fish can the biofilter really carry before the water quality slips?
- Is the current pump big enough for the added flow, or does it need replacing outright?
- Should the new beds run on the same timing as the old ones, or on a separate cycle?
- Where does the extra weight sit, and is the ground firm enough without more preparation?
- What happens to the system during a power cut, and is the backup enough for the larger volume?
- Can the neighbor and I agree on who handles the daily feeding when one of us is away?
- Will shade from the neighbor's side reduce light for the new beds in summer?
- Which crops are worth the new space, and which just look good in the plan?

I will answer these as I go and move the answers into the relevant sections.

## Schedule

The project began in spring 2025, and the plan follows the growing season so that planting lines up with warm weather.

Rough order of work:

1. Plan and measure. Confirm the layout, the position of the new beds, and the plumbing route.
2. Order materials. Do this early, since some items take time to arrive.
3. Prepare the ground and the stand. Level, firm, and check drainage.
4. Install tanks and plumbing. Test with plain water first and leave it running for a few days to find leaks.
5. Fill and cycle. Let the biofilter settle before adding fish.
6. Add fish gradually, then seedlings.
7. Observe and adjust over the following weeks.

Each step has a gate. I do not move on until the previous step has been tested and written down. Build days are set with the neighbor, usually at weekends, with a spare day kept free in case weather or a delivery delays things.

## Background

Stebrark began as a small system meant to teach me how aquaponics works. It did that well. After a season, the plants grew faster than I could use them in some beds, while other beds stayed underfilled, and the fish tank sat close to its limit. That pointed to a design that was balanced but small.

The neighbor was interested from the start and often helped with repairs. When I mentioned adding capacity, they offered space and took over the lead. That changed the project from a one-person hobby into a shared one, which affects decisions about layout, access, and who does what.

The reasons for expanding are practical:

- More produce for both households
- A chance to try crops the small system could not support
- Better stability, since a larger water volume changes temperature and chemistry more slowly
- Learning how the system behaves when scaled

The constraints come from the plot, the weather, the time we have, and the money. The goal is expansion, not perfection, so a working larger system beats an ambitious design that never gets finished.

## Problems

Problems I expect, or have already seen:

- Leaks at fittings. Almost always from rushed sealing. Fix: test with water before fish.
- Pump failure. A single pump is a single point of failure. Fix: keep a spare and an air backup.
- Algae. Light on exposed water. Fix: cover tanks and channels.
- Nutrient imbalance. Plants pale if iron or potassium runs low. Fix: test and supplement carefully.
- Pests. Aphids and slugs on the new beds. Fix: inspect weekly and use gentle controls that are safe for fish.
- Temperature swings. Hot afternoons and cold nights. Fix: shade, insulation, and a larger volume.
- Coordination. Two people, one system. Fix: a shared notebook and clear roles.

When something goes wrong I write down what happened, what I did, and whether it worked. Over time this becomes the most useful part of the notes.

Success is measured in a few simple ways. The system runs stably with water readings in the safe range for the fish. Fish survive and grow. The new beds produce a harvest we actually use. The weekly maintenance stays manageable. And the total spend stays within the budget below.

## Checklist

Before building:

- [ ] Layout measured and agreed with the neighbor
- [ ] Ground checked for level and firmness
- [ ] Materials list written and priced
- [ ] Spare pump and air backup planned
- [ ] Power supply checked

During building:

- [ ] Stand level and stable
- [ ] Plumbing tested with plain water
- [ ] No leaks after several days
- [ ] Tanks covered against light
- [ ] Biofilter cycled

After building:

- [ ] Fish added gradually
- [ ] Seedlings planted
- [ ] Weekly tests logged
- [ ] Spending compared with the budget
- [ ] Notes updated with lessons learned

## References

These are my own sources, kept as plain descriptions rather than links.

- My earlier notes on the first Stebrark system, including water test logs and stocking records
- The neighbor's sketches of the new layout
- Receipts and order confirmations, stored in one folder
- A general aquaponics handbook I own, used for stocking and ratio guidance
- Photos taken at each stage of the build
- A notebook with handwritten readings, copied into the notes weekly

When I learn something from a supplier or a conversation, I add a line saying who said it and when, so I can judge later whether it was reliable.

## Overview

Stebrark expansion is an aquaponics project with the goal of expansion. It started in spring 2025 and is led by the neighbor. The aim is to enlarge a small, working system into one that produces more, runs more steadily, and still fits into ordinary evenings and weekends.

The drivers, in short:

- Goal: grow capacity for fish and plants together
- Constraints: limited space, a shared plot, limited time, and a fixed budget
- Budget: set out in its own section below
- Success: stable water, healthy fish, a useful harvest, manageable upkeep, and spending within the budget

Everything else in this note supports those points. If a decision comes up that this note does not cover, I ask whether it serves the goal, respects the constraints, and keeps the cost in check.

## Supplies

A working list of supplies, grouped by use.

Water system:
- Tanks or larger containers, food-safe
- Pipe, elbows, tees, unions, and valves
- Bulkhead fittings and sealant
- Pump, spare pump, and tubing
- Air pump, air stones, and airline

Grow beds:
- Frames or troughs and pond liner
- Growing media such as clay pebbles or gravel
- Stand materials, treated timber or steel
- Net pots and supports

Living stock:
- Fish, chosen to match the existing ones
- Seedlings and seeds

Testing and care:
- Test kits and reagents
- Dechlorinating treatment if tap water is used
- Netting, shade cloth, and covers
- Feed

Spare small parts matter more than they seem. A missing clamp on a Saturday can stop the whole day, so I keep a small box of extras.

## Ideas

Ideas I may try if time and money allow:

- A second, smaller grow bed for herbs near the house
- A simple float switch to protect the pump from running dry
- Rain collection to top up the system
- A shade frame that doubles as a trellis for climbing crops
- A timer for the lights if we add a seedling shelf
- A small sump to make water level more stable
- A shared harvest board so both households see what is ready
- A short written guide for whoever feeds the fish while we are away

None of these are required. They sit here so they do not clutter the main plan, and I review them once the core build is done.

## Budget

The budget of Stebrark expansion is 27405.49 EUR.

This covers tanks, plumbing, grow beds, pumps, power work, stock, testing supplies, and small items. It is the ceiling for the project, not a target to reach. If the build comes in under it, the difference is kept as a reserve for repairs and the first season of running costs.

How I will manage it:

- Keep every receipt and log each purchase the day it is made.
- Compare actual spending with the plan at the end of each stage.
- Write down any purchase that is much larger than expected, and talk it over with the neighbor first.
- Spend on the parts where failure is costly, such as pumps and backup, before the parts that are only nice to have.
- Leave the ideas list until the core system is running.

Success is measured against this figure alongside the other measures: stable water, healthy fish, a useful harvest, and upkeep that stays manageable. If spending is on budget but the system is unreliable, the project has not succeeded. If the system is excellent but the budget was far exceeded, that also counts as a miss, and I will note why it happened.
