---
type: summary
status: active
project: mirke-retrofit
area: aquaponics
description: "Summary about Mirke retrofit."
---

# Summary of Mirke retrofit

## History

Mirke retrofit is a project I started in autumn 2021. The goal was a retrofit of the existing aquaponics setup, and the work has run under the aquaponics area ever since. The plumber leads it, which fits, because most of the early work was pipes, fittings and flow routes rather than fish or plants.

The first season was mostly walking the system and writing down what was there. I listed the tanks, the grow beds, the pump runs and the drain lines. I marked which parts were original and which had been patched over the years. That list became the base for everything after it.

After that the project moved slowly. Winter work was limited to small repairs and measuring. Real changes had to wait for warmer months, since I did not want to drain the system while the fish were stressed. Several times the project sat idle for a long stretch, then restarted when the plumber had time.

A short timeline of the stages so far:

| Stage | Year | What happened |
|---|---|---|
| Survey | 2021 | Walked the system, listed tanks, beds and pipe runs |
| Planning | 2022 | Sketched the new layout and the order of work |
| Pause | 2023 | Mostly idle, only small repairs |
| Restart | 2024 | Plumber re-checked the plan and the parts list |
| Go | 2025 | Decision to proceed with the retrofit |

## Background

The key facts about the project, kept in one place so I do not have to hunt for them:

- **Name:** Mirke retrofit
- **Type:** project
- **Goal:** retrofit
- **Area:** aquaponics
- **Start year:** 2021
- **Season:** autumn
- **Lead:** plumber

The reason for the retrofit is simple. The old system works, but it was built in pieces, and the plumbing shows it. Some runs are longer than they need to be, some joints are awkward to reach, and a few valves are in places where I cannot shut off one bed without affecting another. The retrofit is meant to tidy this up without changing the basic idea of the system.

Current stage: the work is in the execution phase. The go decision has been made, the plan is settled, and what remains is carrying out the plumbing changes in a sensible order.

What is done:

- Survey of the whole system, with a written list of parts
- Layout of the new pipe routes
- Agreement with the plumber on the order of work
- Go decision recorded

Open points:

- Confirming that each bed can be isolated on its own once the new valves are in
- Deciding how long the system can be down before the fish need extra care
- Checking that the pump has enough margin for the shorter runs
- Writing down the final layout so future repairs are easier

I keep the open points short on purpose. If a point stays open for more than one season, it usually means I am avoiding a choice, and then I need to make it rather than leave it.

## Next action

The next action is tracked under the reference NX-7838. It is the single step I want to see finished before anything else is started, so I do not spread the work across too many fronts at once.

When it is done, I will update this summary, move the finished item into the history, and pick the next step from the open points above. The plumber leads, so the timing depends on their schedule, but I will prepare the site beforehand: clear access to the pipes, have a place to hold the fish if needed, and keep the tools and fittings in one spot.

## Decisions

The main decision so far is the go decision. The go decision date is 2025-05-05. From that point the project was treated as approved and moved from planning into execution.

Other decisions worth remembering:

- **Keep the basic design.** The retrofit changes the plumbing, not the concept of the system.
- **Plumber leads.** One person coordinates the order of work, so the plan does not drift.
- **Work in warm months.** Larger changes are done when the fish can tolerate disturbance.
- **Isolate beds individually.** New valves are placed so one bed can be shut off without touching the others.
- **Write it down.** The final layout gets documented once the work is complete.

If any of these change, I will note the reason here next to the original choice, rather than overwrite it. That way I can see later why something was done a certain way, which is the main reason I keep this summary at all.
