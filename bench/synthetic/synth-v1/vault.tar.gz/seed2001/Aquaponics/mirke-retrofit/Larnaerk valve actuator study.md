---
type: research
status: active
project: mirke-retrofit
area: aquaponics
---

# Larnaerk valve actuator study

## Overview

The Larnaerk valve actuator is a valve actuator that I use in the aquaponics setup. It is red, which makes it easy to spot among the grey pipes and green plant trays. It runs on a battery, so there is no mains cable to route through a wet area. It was installed in 2016 and it sits in the greenhouse, close to the point where the water line splits toward the grow beds.

This note is the first part of a longer study. I wrote it to keep track of what the device is, what can go wrong with it, and how I got it running. The later parts go into measurements and routine care. Here I only set the ground.

The summary of its properties, as I keep them:

- Kind: valve actuator
- Area: aquaponics
- Color: red
- Energy source: battery
- Year installed: 2016
- Location: greenhouse

The actuator turns a valve handle on its own, so I do not have to walk into the greenhouse every time the water needs to be redirected. In an aquaponics system the water carries fish waste to the plants and then returns cleaned to the fish. If the flow stops or goes to the wrong place, things go bad quickly. A valve that moves on command is therefore a small but important part of the whole loop.

I chose a battery-powered unit on purpose. The greenhouse has damp air most of the year, and I did not want extra mains wiring near the tanks. The trade-off is that I have to watch the battery and plan for replacement. I come back to that in the risks.

The red color is not only cosmetic. In the greenhouse I use color to tell devices apart at a glance. Red marks things that control water flow, so if I see something red I know it matters and I should be careful around it.

### What it does in practice

On a normal day the actuator does very little. It holds the valve in one position for hours. Several times a day it moves the valve to change where the water goes, then it holds again. Most of its battery life is spent waiting, and only a short part is spent moving.

I think of its work in three simple states:

1. Holding: the valve stays where it is and the actuator draws almost nothing.
2. Moving: the motor turns the handle, and this is where most of the energy goes.
3. Stuck or stalled: the motor tries to move but the valve resists, which drains the battery and can damage parts.

The third state is the one I worry about, and it leads straight to the risks.

### Why I am studying it

The unit has been in the greenhouse since 2016, which is a long time for a device in a humid place. I want to know how much life it has left and whether I should replace it before it fails at a bad moment. I also want a written record of how it is set up, because I had to work this out from memory more than once after a repair. This study is meant to replace that memory.

My questions are simple:

- How reliable is it after so many years in the greenhouse?
- How often does the battery need attention?
- What are the signs that it is about to fail?
- What is the safest way to set it up so a failure does no harm to the fish?

## Risks

The main risks come from three things: the battery, the damp air, and the fish that depend on the water flow. I list them in the order I worry about them.

### Battery running low

Because the actuator uses a battery, the most likely failure is a flat battery. When the battery gets weak, the motor may not have enough strength to turn the valve all the way. The valve then stops halfway, which is worse than a clean failure because the water goes partly to both places.

What I do about it:

- I check the battery on a fixed day each month and write down the result.
- I replace the battery before it is empty, not after.
- I keep a spare battery in the shed, in a dry box, so I never wait for a delivery while the system is half open.

A weak battery can also give odd behavior. The actuator may move slowly, click without finishing, or stop partway. If I see any of these, I treat the battery as the first suspect before I look at anything else.

### Moisture and corrosion

The greenhouse is warm and humid, and the actuator has been there since 2016. Moisture is a slow enemy. It gets into the battery contacts and the housing, and it can leave a white or green crust on metal parts. A crusty contact gives a poor connection, and a poor connection looks just like a weak battery.

What I do about it:

- I open the battery compartment during each battery check and look for crust or dampness.
- I wipe the contacts dry and keep them clean.
- I make sure the actuator is not directly under a drip from the roof or from a plant tray.
- I do not spray water near it when I clean the beds.

### Valve stiffness

Over the years the valve itself can get stiff. Mineral deposits build up inside, and algae can grow in the damp spots. A stiff valve makes the actuator work harder, which drains the battery faster and can strain the gears. If the battery seems to die sooner than before, I check the valve by hand before I blame the battery.

Signs of a stiff valve:

- The handle is hard to turn by hand when the actuator is released.
- The motor sounds strained or slow.
- The battery life gets shorter without any other change.

### Wrong position at a bad time

The worst result is the valve ending up in the wrong position. If it sends water away from the fish tank, the pump may run dry or the water level in the tank may drop. If it sends too much water to the grow beds, a bed may overflow onto the greenhouse floor. Either way, the fish are the ones at risk, because they need steady water and oxygen.

To reduce this risk, I follow a few rules:

- The system must be safe if the valve stops in any position. I set the pipes and the overflow so that no position is fatal.
- I never leave for a long trip without checking the valve position and the battery the day before.
- I keep a manual way to turn the valve, so I can fix the position by hand when the actuator fails.

### Failure that I cannot see

A quiet failure is dangerous because I might not notice for days. The actuator gives no loud warning when it stops working. I only find out when the water level or the plants show a problem. To catch this early, I look at the valve position during my regular walk through the greenhouse, and I compare it with what it should be at that time of day.

### Risk summary

| Risk | How likely | How bad | My main defense |
| --- | --- | --- | --- |
| Flat battery | High | Medium | Monthly check and spare battery |
| Moisture and corrosion | Medium | Medium | Dry contacts and good placement |
| Stiff valve | Medium | Medium | Hand test of the valve |
| Wrong position | Low | High | Safe pipe layout and manual override |
| Unnoticed failure | Medium | High | Regular walk and position check |

The two items I treat most seriously are the last two, because they can hurt the fish. The first three are mostly maintenance problems that I can control with a routine.

## Setup

This section records how the actuator is set up, so I can rebuild it after a repair without guessing. I describe the physical placement first, then the battery, then the steps I follow when I set it up again.

### Placement

The actuator sits in the greenhouse, mounted on the valve at the point where the water line splits toward the grow beds. I picked this spot for these reasons:

- It is close to the pump, so a short pipe run keeps the flow steady.
- It is easy to reach, so I can turn the valve by hand without climbing over trays.
- It is away from the main watering area, which keeps splashes off the housing.
- It is visible from the door, so I can see the red body and check the position quickly.

The red color helps here. From the greenhouse door I can see the actuator and tell if the handle has turned.

### Battery

The energy source is a battery. I keep the battery in the compartment of the actuator and note the date of each change in my notebook. I do not rely on memory for this, because the days run together in the greenhouse.

My battery habits:

- Use the same type of battery every time, so behavior stays predictable.
- Replace the battery in the cooler part of the year if possible, because the work is easier when the greenhouse is not hot and wet.
- Dispose of old batteries properly and never leave them in the greenhouse.
- Keep the spare battery dry and out of the sun.

### Steps for setting it up again

When I need to remove and refit the actuator, I follow this order. It keeps me from making mistakes with the water running.

1. Switch off the pump so that no water is moving through the line.
2. Turn the valve by hand to the position I want as the starting point, usually the one that sends water to the fish tank side.
3. Take out the battery from the actuator, if it is still in place.
4. Remove the actuator from the valve handle and clean the mounting surface.
5. Check the valve by hand through its whole range. It should move smoothly, with no grinding.
6. Refit the actuator on the handle so that its position matches the valve position.
7. Insert a good battery, checking that the contacts are clean and dry.
8. Run the actuator through one full movement with the pump still off, and watch that it reaches both ends.
9. Switch the pump on and watch the first few cycles carefully.
10. Check for leaks around the valve and the pipes.
11. Write the date and any notes in my log.

### Things I check after setup

After I finish, I do a short test round before I trust it again:

- The valve reaches both end positions and does not stop halfway.
- The motor sounds smooth, with no straining.
- The water level in the fish tank stays steady for the next hour.
- The grow beds fill and drain as expected.
- There is no dampness near the battery compartment.

If everything looks right, I leave it. If anything looks wrong, I switch the pump off, go back to the steps above, and look at the battery and the valve first.

### Manual backup

I always keep the means to turn the valve by hand. When the actuator is fitted, I make sure I know how to release it from the handle without tools, or with one simple tool that I keep nearby. In an emergency I do not want to search for equipment while the water level drops.

My backup routine is short:

- Release the actuator from the handle.
- Turn the valve by hand to the safe position, which is the one that keeps water going to the fish tank.
- Switch off the pump if the situation is unclear.
- Look for the cause only after the fish are safe.

### Notes for the next part

The next part of this study looks at how the actuator behaves over time. I plan to record how long a battery lasts and how the valve feels each month. With those numbers I should be able to decide whether this unit, installed in 2016, can stay in the greenhouse or should be replaced.

## Supplies

This section lists what I keep on hand for working on the Larnaerk valve actuator. It is a valve actuator, it is red, and it has run on battery power since I installed it in 2016. It sits in the greenhouse, and it belongs to the aquaponics setup, where it opens and closes the valve that sends water from the fish tank toward the grow beds.

The kit is small. I keep everything in one plastic box on the shelf by the greenhouse door, so I never have to walk back to the house.

- A spare battery set, charged and labeled with the month I charged it. The actuator runs on battery, so this is the item I reach for most often.
- A small multimeter for checking battery voltage and for confirming that the motor leads are not broken.
- A soft brush and a dry cloth. Humidity in the greenhouse leaves a film on the red housing, and the brush gets dust out of the seams.
- A tube of silicone grease that is safe around fish water. I use it only on the stem seal, and only a little.
- Spare cable ties and a roll of self-sealing tape for the lead wires.
- A notebook and pencil. A phone is awkward with wet hands, and paper survives the damp.
- Two spare O-rings in a labeled bag. They are not original, but they fit well enough for a stop-gap.
- A flat screwdriver and a small hex key set for the cover and the mounting bracket.

I do not stock a full replacement actuator. When I thought about it, the cost seemed too high for something that has behaved well, and a second unit would sit unused in a hot, humid room. If the motor ever fails for good, I will treat that as the point to rethink the design instead of simply swapping the part.

One more supply is not a physical item: a quiet hour. The actuator needs the water flow stopped before I open anything, and I want the tank pump off for the whole job. I plan the work for a day when the fish have been fed early, so nothing is stressed while the flow is paused.

## Lessons

These are the things I learned from living with the Larnaerk valve actuator in the greenhouse since 2016. Most came from small mistakes, not from planning.

**Battery power is a strength and a chore.** Because the energy source is battery, the actuator keeps working during a power cut, which matters for aquaponics because the fish cannot wait. The cost is that I have to remember the battery. My early habit was to wait until the valve moved slowly, but a weak battery can stall the valve halfway, and a half-open valve upsets the water balance in the grow beds. Now I swap the battery on a schedule, before it shows any weakness, and I write the swap in the notebook.

**Heat and damp are the real enemies.** The greenhouse gets hot on sunny afternoons and wet at night. The housing is red, and it fades slightly in strong sun, though the fading is only cosmetic. The damp is the bigger problem. Moisture gets into the cover seam and leaves a light corrosion on the battery contacts. A cloth wipe and a thin coat of grease on the contacts have solved this almost entirely.

**Mounting matters more than I expected.** In the first year, I fixed the actuator with the bracket slightly off line with the valve stem. It worked, but the motor strained, and the battery drained faster than it should have. Once I realigned the bracket so the stem turned freely by hand, the draw dropped and the battery lasted noticeably longer. The lesson is to always turn the valve by hand before trusting the motor to do it.

**Do not over-grease.** I once put on too much silicone grease, and it collected dust and fine plant debris. Within weeks the stem felt gritty. A very thin layer, wiped with a cloth, is enough.

**Keep the lead wires off the floor.** Water splashes during tank cleaning. I now tie the leads up high with cable ties, and I leave a small drip loop so water runs off the wire before it reaches the connector.

**Write things down.** The most useful notes are the plain ones: when I changed the battery, what the valve sounded like, and whether the water level in the beds looked right afterward. Over many seasons, those short entries showed me patterns I would never have remembered, such as the motor being slower in winter.

**Test after every change.** After any work, I cycle the valve open and closed several times while I watch it. I do this before I walk away, not after.

## Observations

These are my plain observations of how the Larnaerk valve actuator behaves in daily use. It is a red valve actuator in the greenhouse, part of the aquaponics system, installed in 2016, powered by battery.

The first thing I notice is the sound. When the battery is healthy, the motor makes a short, even hum and the valve settles with a soft stop. When the battery is getting weak, the hum becomes uneven and it takes longer to finish. I treat that sound change as my early warning, though I try to swap the battery before I ever hear it.

The second observation is about seasons. In summer the valve responds quickly, probably because the grease is looser and the battery performs better in warmth. In winter the movement is slower, and I have learned not to worry unless it fails to complete a full turn. Cold nights seem to affect the battery more than the motor.

The red housing is easy to see among the green plants, and that has been a small practical benefit. I can spot it from the door and check at a glance that nothing is hanging on it or blocking it. Leaves sometimes grow against it, and I trim them back when I walk past.

Water quality has not been affected by the actuator in any way I could notice. The fish behave normally after a valve cycle, and the grow beds fill and drain as expected. The only time I saw a problem was when the valve stopped halfway because of a weak battery, and the bed stayed too full for a few hours. That was a clear reminder that the battery is the weak link, not the mechanism.

Wear on the unit has been modest for a device that has been in the same place since 2016. The stem seal shows slight softening, the cover has a few faint marks, and the bracket has a little surface rust that I keep wiped. The motor itself has never needed replacement.

A few open questions remain for later study:

- How much longer a battery lasts if I keep the cover seam sealed with fresh tape.
- Whether a small shade cloth over the housing would reduce fading and heat stress.
- Whether the slower winter movement is the battery, the grease, or both.
- Whether a simple voltage check each month would be enough to replace my fixed swap schedule.

For now, my routine is simple: look at it every time I pass, listen to it when it moves, wipe it down regularly, and change the battery before it complains. That routine has kept the actuator reliable, and I plan to keep following it unless the notes begin to show something different.

## Background

The Larnaerk valve actuator is a red, battery-powered valve actuator that I installed in the greenhouse in 2016. It belongs to the aquaponics side of my setup, and its job is to open and close a water valve so the flow between the fish tank and the grow beds can be controlled without me standing there with a wrench. This part of the study covers the practical side: how I keep it working, and how I keep myself and the plants safe around it.

I chose a battery-powered unit on purpose. The greenhouse has damp air, and I never liked the idea of mains wiring running close to standing water. A battery removes that worry, but it creates a different one, which is that the actuator can stop without any warning when the cells run low. Most of what follows comes from that trade-off.

Over the years the Larnaerk has become one of those devices I stop noticing until something goes wrong. That is a good sign, but it also means I have to force myself to check it on a schedule. The notes below are the schedule I settled on, plus the reasons behind each step, so that I do not have to rediscover them.

A few facts I keep in mind for every task:

- The device is a valve actuator, so it turns a valve stem and nothing else.
- Its colour is red, which helps me spot it among the pipes and black tubing.
- It runs on a battery, so there is no cable to trip over and no mains socket to keep dry.
- It has been in the greenhouse since 2016, so it has seen a lot of humidity and temperature swings.
- It is part of the aquaponics system, so a failure affects both fish and plants.

## Maintenance

I do maintenance in short, regular rounds rather than one big annual overhaul. Small checks catch problems early, and the greenhouse is a harsh place for any equipment. The rounds below are listed from most frequent to least frequent.

### Weekly look

Once a week, when I do my normal walk through the greenhouse, I look at the actuator without touching it. I am checking for:

- Water drops or a wet film on the casing. Condensation on the outside is normal; water that seems to come from a seam is not.
- Any change in how the valve sits. If the position looks different from what I expect for the time of day, the actuator may have missed a command or stalled.
- Algae or mineral crust building up around the stem. A crust can add drag and make the motor work harder, which drains the battery faster.
- The colour of the casing. Red plastic fades and gets chalky in strong sun, and a chalky surface is often the first sign that the material is getting brittle.

If everything looks normal I write a single line in my log and move on. A log with nothing in it is useless, so even a boring entry is worth the ten seconds.

### Monthly check

Once a month I do a hands-on check. I close the valve by hand if the design allows it, or I shut the supply upstream, so the fish are never left without circulation while I work.

1. Wipe the casing with a damp cloth. No solvents, because they craze the plastic.
2. Move the valve through its full travel and listen. A smooth, even sound is what I want. Grinding, clicking or a sound that changes halfway through the stroke means something is wrong.
3. Time the stroke roughly, with the second hand on my watch. I do not need a precise figure, only a feeling for whether it has become slower than it used to be. A slow stroke is the earliest hint of a weak battery.
4. Check the battery compartment seal. I look at the rubber for cracks and for any flattening. A seal that has taken a permanent set will not keep out the damp.
5. Look at the mounting. Vibration and thermal cycling can loosen fasteners, and a loose actuator can twist the valve stem sideways.

### Battery care

The battery is the weak point, so it gets its own routine. I replace the cells before they fail, not after. Because the actuator has been running since 2016, I no longer trust any cell to last as long as the previous one did; each swap is a new experiment, and I note how long the set lasted.

- Write the date of installation on a piece of tape inside the battery cover, so I never have to guess.
- Replace all cells together. Mixing old and new cells leads to the old ones draining first and sometimes leaking.
- Check the contacts every time. Greenhouse humidity causes a green or white film on metal, and a thin film is enough to cause intermittent faults that are very hard to trace.
- Clean contacts with a dry cotton swab, and if there is a film, a swab with a little isopropyl alcohol, left to dry fully before the cells go back in.
- Dispose of old cells properly. They do not go in the compost, and certainly not anywhere near the water that feeds the fish.

When a battery is nearly flat, the actuator can behave strangely before it stops: the valve may move partway, or move slowly, or work in one direction and not the other. If I see this, I assume the battery and not the mechanism, and I swap the cells before I start taking things apart. That has saved me a lot of wasted effort.

### Seasonal tasks

Twice a year, at the change between the warm and cold seasons, I go further.

- Exercise the valve several times through its whole range. A valve left in one position for months can seize with scale, and the actuator then has to fight it.
- Inspect the stem and any visible seals for scale, wear and leaks.
- Check that the manual override, if I need it in an emergency, still moves freely. An override that has never been used is likely to be stuck on the day I need it.
- Take a photo of the setup. Comparing photos from different seasons shows slow changes, such as a leaning mount or a sagging pipe, that I would not notice by eye.

### Records

I keep a short record of every action: what I did, what I found, and what I changed. The record is just plain lines in a text file. The most useful items turned out to be the battery change dates and any odd behaviour I noticed beforehand. After a few cycles, the pattern in those notes tells me when to replace the cells without waiting for a warning.

## Safety

The Larnaerk does not carry mains voltage, which removes the worst electrical hazard in a wet greenhouse. That does not make it harmless. The risks are mostly about water, movement and sudden failure.

### Before touching it

- Isolate the water flow first. If the actuator is holding a valve open or shut, I decide which position is safest for the fish and the plants before I disturb anything.
- Remember that a valve can move on its own. Even a battery unit can start a stroke suddenly if a command arrives while my fingers are near the stem. I take the battery out before I put my hand anywhere near the moving parts.
- Dry my hands and the work area. Wet hands slip, and a dropped actuator can crack its casing or the pipe fitting beneath it.

### Risks to the fish and plants

The most serious consequence of a failure is not to me but to the living system. A valve stuck closed can starve the grow beds of water and let the roots dry out. A valve stuck open can drain a tank, and fish can die within hours when the level drops or the water quality changes. For that reason I treat the actuator as a critical part of the aquaponics system rather than a convenience.

- Keep a spare set of cells close to the greenhouse, in a dry container.
- Know where the manual valve handle or override is, and make sure nothing blocks it.
- Have a simple fallback plan, such as a hand-operated bypass, so circulation can continue while I repair the actuator.
- Check the water level and the fish after any repair, not just the valve.

### Battery hazards

Cells in a warm, damp greenhouse can swell, leak or overheat if they are damaged or mixed with different types. I handle them as follows:

- Never short the terminals, and never carry loose cells in a pocket with keys or coins.
- If a cell has leaked, wear gloves, wipe the compartment with a dry cloth, and wash my hands afterwards. I keep leaked residue away from the water and the plants.
- Store spare cells in a cool, dry place out of direct sun, because the greenhouse can get very hot on a bright day.
- Do not try to recharge cells that are not designed for it.

### Working in the greenhouse

- Watch the floor. Wet paths, hoses and pipes make trips and slips likely, and the actuator sits near pipes at about knee height, which is awkward to reach.
- Use good light. The red casing blends into some backgrounds in dim conditions, and I do not want to knock it by accident.
- Do not work alone on a long job if I can avoid it. At the very least, I tell someone where I am and how long I expect to be.
- Keep a small first-aid kit nearby for cuts from fittings or broken plastic.

### When to stop and replace

I stop using the actuator and replace it if the casing is cracked, if water gets inside more than once after resealing, if the motor has a burning smell, or if the stroke becomes unreliable even with fresh cells. After so many years of service, I accept that a replacement will eventually be needed, and I would rather plan it than be forced into it during an emergency. Until then, the routine above keeps the Larnaerk dependable, and keeps the fish, the plants and me out of trouble.

## Tools

This part lists what I use to study the Larnaerk valve actuator. It is a valve actuator in the aquaponics area, installed in 2016 in the greenhouse. It is red and runs on a battery. Most of my tool choices follow from those facts. The greenhouse is damp and warm, the unit is small, and the battery is the part most likely to cause trouble.

**For observation**

- A paper logbook that stays in a zip bag on the shelf by the greenhouse door. Phones and tablets do badly in the humidity, so I write there first and copy into Obsidian later.
- A phone camera for photographs of the actuator body, the cable entry and the mounting bracket. The red housing shows condensation and dust clearly, which helps. I take each photo from the same spot so I can compare them over time.
- A small waterproof torch, because the actuator sits low behind the grow beds and the light is poor there.
- A cheap thermometer and humidity card left near the actuator. I want to know whether the greenhouse air affects the battery, so I need a local reading and not a guess.

**For measuring the battery**

- A basic multimeter, used to read battery voltage at rest and while the valve moves. The rest reading tells me about the state of the cells. The reading under load tells me whether the battery can still drive the valve.
- A spare battery of the same type, kept charged, so I can swap one in without leaving the water loop stuck in one position.
- A small label printer for marking each battery with the day it went in. I write the day in the logbook as well.

**For testing the valve action**

- A kitchen timer and a stopwatch to time how long the valve takes to open and to close.
- A bucket and a jug to collect water when I open a fitting.
- A marker pen to draw a line across the valve stem and the housing, so I can see by eye if the position drifts.

**For keeping notes**

- Obsidian, with one daily entry per visit and this note as the summary of everything.
- A simple table in each entry with the same columns every time: battery reading, open time, close time, position mark, and remarks. Keeping the format fixed lets me compare visits without rereading everything.

**What I decided not to use**

I thought about a data logger fixed to the actuator. It would give continuous readings, but it adds another battery, another thing to keep dry, and another cost in a project that has no budget. I will reconsider it if the manual readings turn out too sparse to show a pattern.

## Schedule

This is the plan for the study, written as a routine and not as dates. I will do the work around the normal chores in the greenhouse so it does not become a separate project that I abandon. The actuator has been in service since 2016, so I am not trying to commission it. I am trying to understand how a battery-powered unit behaves after this long in a humid place.

**Every visit to the greenhouse (about twice a week)**

1. Look at the red actuator housing and check for water inside the cable entry, for corrosion at the terminals, and for any crack in the case.
2. Check the position mark. If the line on the stem and the housing no longer meet, note the offset in the logbook.
3. Read the battery voltage at rest with the multimeter.
4. Read the thermometer and humidity card.
5. Write one line in the daily entry, even if nothing changed. A blank day is still information.

**Once a week**

1. Run a full open and close cycle by hand command and time both movements with the stopwatch.
2. Read the battery voltage during the movement, if I can hold the probes safely. If I cannot, I read it immediately after.
3. Take the standard photographs from the fixed spot.
4. Compare the timing with the previous week and write down whether it is slower, faster or the same.

**Once a month**

1. Swap in the spare battery, test the actuator on it and compare its timing with the old one. This separates a weak battery from a worn mechanism.
2. Charge or replace the removed battery and label it.
3. Wipe the housing and the bracket, and look for rust on the fixings.
4. Read back through the month of entries and write a short summary at the bottom of this note.

**Once per season**

1. Think about how the greenhouse conditions have changed. Summer heat and winter damp should affect the battery differently.
2. Check whether the aquaponics flow, meaning the water going to the grow beds, matches what the valve position says it should be. If the valve moves but the flow does not change, the fault is downstream and not in the actuator.
3. Decide whether to continue, tighten or loosen the schedule.

**Order of work**

The first stretch is only observation. I do not change anything on the unit. I want a clear picture of normal behaviour before I make a comparison. The second stretch adds the battery swap test. The third stretch is for any repair or replacement idea, and only if the earlier notes support it. I would rather be slow here than disturb a working system and lose the baseline.

**Rules for myself**

- Never leave the valve in an unknown position after a test. I always note the position before and after.
- Never work on the actuator while the water loop is in a state where fish could be stressed by a sudden flow change. I check the tanks first.
- If a reading looks strange, I repeat it before I write it down as a result.
- If I skip a visit, I write that I skipped it, so gaps do not look like stable periods.

## Open questions

These are the things I do not know yet. I list them so that each visit has a purpose, and I cross them out as they are answered.

**About the battery**

- How long does one battery last in this greenhouse? The unit is battery powered and has been in place since 2016, but I do not know how many batteries it has gone through, or whether the original type is still the one in use.
- Does the voltage under load drop faster in summer heat or in winter damp? I suspect heat, but I have no readings yet.
- Is there a voltage below which the valve moves slowly or stops partway? If so, I want to find that point on a spare battery in a safe test, away from the live loop.
- Would a different battery chemistry be more stable here? I do not want to change it before I understand the current one.

**About the mechanism**

- Has the red housing kept the moisture out for all these years, or has some water already got in? A faint mark near the cable entry makes me unsure.
- Does the position drift over time without any command? The marker line should answer this, but only after several weeks.
- Is the movement time the same in both directions? If opening is slower than closing, that might point to wear or to water pressure and not to the battery.
- Are there any parts of the actuator that I can service myself, or is it sealed? I have not opened it and will not until the baseline is complete.

**About the setting**

- Does the position of the actuator in the greenhouse, low and behind the beds, cause problems that a different spot would avoid? Splashing, shade and dust all come into this.
- How much does the aquaponics water temperature change the valve behaviour, if at all? The valve stem may be affected by cold water more than the battery is affected by air.
- Is the unit still the right size for the flow it controls, after the system has changed a little since 2016?

**About the study itself**

- Is twice a week too often? It gives good detail but takes time. If the readings are all the same for a couple of months, I may reduce it.
- Do I need a data logger after all? The manual readings only show moments. A short fault between visits would be missed.
- What would count as an answer? I think a simple rule is enough: a battery life figure in weeks from my own notes, a note on whether the timing changes, and a clear yes or no on whether the actuator needs replacing.
- Should I write a one-page maintenance routine at the end, so that the habit continues after the study is over? I think yes, and it can be built from the weekly and monthly lists above.

## History

The Larnaerk valve actuator is a red, battery-powered valve actuator. It was installed in 2016 in the greenhouse, and it has worked in the aquaponics system there ever since. I am writing down what I remember and what my old notes say, because the story is spread across several notebooks and I keep losing track of it.

The reason for buying it was simple. Before 2016 I opened and closed the main water valve by hand every morning and evening. That valve sends water from the fish tank to the grow beds. It worked fine until I was away for a few days and the beds were either flooded or dry. I wanted something that would turn the valve on a schedule without a mains cable, because the greenhouse had only a couple of weak outlets, and those were already used by the pump and the aerator.

The battery supply was the deciding point. The Larnaerk valve actuator runs on a battery, so I could mount it right at the valve. I did not need to run a cable through the wet part of the greenhouse. In an aquaponics setup, water and electricity in the same corner make me nervous, and the battery version removed most of that worry.

The red color turned out to be useful as well. The body is bright red, so I can see it from the door even when the plants are tall and the light is poor. Visitors always ask what the red box is. When the glass fogs up in the morning, it is still the first thing I notice, and a quick look tells me whether it is sitting in the open or closed position.

The first year went well. I mounted it on the valve with a simple bracket and tested it dry before connecting it to the water line. Once it was running I checked it daily for a week, then weekly. In my notes from that first season I wrote that it was quiet, slow and steady, and that the valve handle did not slip. I was pleased and mostly forgot about it, which is the best thing I can say about any device in the greenhouse.

In the following years the system around it changed more than the actuator did. I added a second grow bed, replaced the old pump with a stronger one, and rearranged the pipes twice. Each time I had to check that the Larnaerk valve actuator could still turn the valve against the new flow. It always managed, but the sound of the motor changed a little after the stronger pump went in. That was the first small sign that the load on it was higher than at the start.

Battery changes became a routine task. I swap the battery at the start of the warm season and again in the middle of the cold season, which has been a safe rhythm. I once tried to stretch a battery through an entire winter. It failed in the coldest week, and the valve stayed half open overnight. Nothing was lost, but I learned from it.

I still consider this one of the better purchases I made for the greenhouse. It is not fancy, and that is part of why it has lasted.

## Problems

None of the problems has been dramatic, but several come back every year, so I want them listed in one place.

**Battery drain in the cold.** The most common problem is the battery. The greenhouse gets cold at night in winter, and the battery loses strength faster than it does in summer. The actuator then moves more slowly, and sometimes it stops before the valve is fully open or fully closed. Because the Larnaerk valve actuator has no mains backup, a weak battery means a weak result. I have learned to treat slow movement as a warning rather than wait for a full failure.

**Humidity.** A greenhouse with fish tanks is damp all the time. The red casing has stood up well, but I have seen moisture collect near the battery compartment. Once I found a thin film of corrosion on a contact. I cleaned it and the problem went away, but it shows that the damp air is slowly working on the device. I now check the contacts every time I change the battery.

**Mounting play.** After years of turning, the bracket that holds the actuator to the valve has loosened a little. The result is a small amount of play, so the actuator turns but the valve does not always turn by the same amount. I tightened the bracket and added a locking washer. It helped, though not completely. I think the real fix is a better coupling.

**No clear feedback.** The device does not tell me from far away whether it did its job. I have to look at it. Since it is red and easy to see, that is not hard in the greenhouse, but when I am away I have no idea if the valve is in the right place. This was acceptable when the system was simple. It matters more now that the system is bigger and a wrong valve position could starve a bed or stress the fish.

**Slow response to changes.** The actuator is slow. That is fine for a daily schedule but not good if I need to close the valve quickly, for example when a pipe leaks. In that case I still have to run over and shut the valve by hand, so the old manual habit never fully disappeared.

**Dependence on my memory.** The battery schedule exists only in my head and in these notes. Twice I have been late changing it, and both times the problems followed within days. A device that depends on my attention is only partly automatic.

**Ageing.** Since it was installed in 2016, the actuator has been in use for many seasons. The plastic parts show some fading, and the motor sounds rougher than it did. I do not know how much life is left, and I do not have a spare. That is a risk I should deal with before the system fails at a bad time.

## Ideas

These are things I want to try or think about. None is urgent, and I will do them roughly in the order I wrote them.

**Buy a spare.** The first idea is the easiest. I should have a second unit, or at least a spare part set, on the shelf. If the Larnaerk valve actuator dies in the middle of the growing season, I do not want to wait for a delivery while the beds suffer. A spare would also let me compare the old unit with a new one and see how much it has worn.

**Set a battery calendar.** I want a fixed reminder for the battery change, written on a card and hung next to the valve. Better still, I would date each new battery with a marker so I can see its age at a glance. This costs almost nothing and would fix one of the most common problems.

**Insulate the battery compartment.** Since the cold is the main enemy of the battery, a small insulating cover around the compartment might help. I could also move the battery to a warmer spot with a short lead, though that adds wiring in a damp area, which I want to avoid. A simple foam wrap and a waterproof cover is the first thing to test.

**Improve the coupling.** To deal with the play, I would like to make a better connection between the actuator and the valve stem. A metal sleeve with a set screw could replace the current bracket arrangement. I should measure carefully first and make a paper template.

**Add a position marker.** A cheap way to solve the feedback problem is a painted line or a small flag on the valve that shows its position clearly. It would be easy to read from the door. Later I could add a simple sensor, but a visual mark is a good first step.

**Add a manual override plan.** I want a clear, quick way to shut the valve by hand in an emergency. At the moment the actuator makes this awkward. A release lever or a coupling that can be disengaged quickly would take away the worry about leaks.

**Log performance.** For a season, I could write down each week how fast the valve moves and how the battery behaves. With a record, I could judge when the actuator is truly wearing out instead of guessing. Even a few lines per week would be enough.

**Think about replacement.** In the long run I should decide whether to keep this actuator or move to something else. The red, battery-powered design has suited the greenhouse well, and I would want any replacement to keep the same strengths: no mains cable, easy to see, and simple to service. If I replace it, I would like one that reports its position, and I would keep the old unit as the spare.

## Checklist

This is the checklist I use when I go over the Larnaerk valve actuator. It is a valve actuator used in aquaponics. It is red, runs on a battery, and has been installed in the greenhouse since 2016. I keep those basic facts at the top of the list because they decide most of the routine steps below.

### Identify the unit

- Confirm that the red actuator body is the one I am working on. The greenhouse has other fittings nearby, but the Larnaerk valve actuator is the only red one on the water line.
- Check that it is still in the greenhouse location I have on record, mounted on the valve it was installed on in 2016.
- Look at the label and make sure it is still readable. If the label fades, I rewrite my own tag next to it rather than guess later.
- Note anything that looks different from my last visit: a new cable tie, a shifted bracket, a different angle of the body.

### Before touching anything

- Check the state of the system. In aquaponics the water is part of a living loop, so I never move the valve without knowing where the water will go.
- Look at the fish tank level and the grow bed level. If either is already low or high, I deal with that first.
- Make sure the pump is off, or that I know exactly what it does when the valve changes position.
- Put a bucket and a towel within reach. The greenhouse is humid, and the floor near the valve is often wet.
- Dry my hands. The actuator is battery powered, but moisture around the contacts is still a problem.

### Physical inspection

- Look over the red housing for cracks, chalky patches, or sun damage. The greenhouse gets strong light, and plastic ages faster there than indoors.
- Check for mineral crust or green film on the body. In this environment, algae grows wherever there is water and light.
- Press gently on the actuator to see if it is loose on the valve stem. It should not rock.
- Check the coupling between the actuator and the valve. A worn coupling makes the valve look like it is moving when it is not fully turning.
- Follow the cable, if any, and look for rubbing, kinks, or water running along it toward the housing.
- Check that the seal around the lid or cover is seated evenly.

### Battery

The energy source is a battery, so this part of the checklist matters most to me.

- Open the battery compartment only when the area around it is dry.
- Look for corrosion, white powder, or any swelling on the cells.
- Check that the contacts are bright and the cells sit firmly.
- Replace the battery on a schedule rather than waiting for it to fail. A dead battery at the wrong moment can leave the valve stuck open or closed.
- After replacing the battery, cycle the valve once and watch the full movement.
- Write the replacement date in the paper logbook kept in the greenhouse, not in this note.
- Keep spare batteries in a dry box away from the grow beds.

### Function test

- Command the valve to open and watch it go all the way. Then command it to close and watch again.
- Listen for grinding, clicking, or a motor that strains. A smooth sound is normal.
- Watch the water flow change. If the actuator says it moved but the flow stays the same, the problem is mechanical.
- Check for leaks at the valve body while it is in each position.
- Time the movement roughly by eye. If it gets noticeably slower between visits, the battery is probably weakening.
- Return the valve to its normal working position before leaving.

### After the visit

- Wipe down the actuator and the area around it.
- Put tools and spare parts back where they belong.
- Record what I found and what I changed.
- If I found a fault I could not fix, mark the actuator with a tag so I do not forget it.
- Check the water levels one more time before leaving the greenhouse.

### Things I have learned to watch for

- Humidity is the main enemy. Anything that lets moisture into the red housing shortens its life.
- Warm afternoons in the greenhouse make the battery work harder, and its strength can look different in the morning than in the afternoon.
- Algae and scale around the stem can slow the valve even when the actuator itself is healthy.
- A valve that moves fine by hand but not under power points at the battery or the motor, not at the valve.
- I should never assume a quiet actuator is a working one. I always watch the flow.

## Software

The Larnaerk valve actuator has a small amount of software on it. It is not a computer in the usual sense, but it does have firmware that controls the movement, the position logic, and the way it behaves when the battery is low. The firmware version of the Larnaerk valve actuator is v6.15.669.

I write that version down because it is the first thing I need if something behaves strangely. When I compare notes from different visits, I want to know whether the behavior came from the hardware, the battery, or the firmware.

### What the firmware does

- It moves the valve between its end positions and stops the motor at the right point.
- It keeps track of where the valve is, so I do not have to guess from the outside.
- It reacts to a falling battery level, usually by slowing down or refusing a move instead of stopping halfway.
- It handles the commands that tell the valve to open or close.

### How I treat the firmware

- I do not update it casually. The actuator has worked in the greenhouse since 2016, and a stable setup is worth more to me than a new feature.
- Before any update, I would replace the battery with a fresh one. Updating on a weak battery is a bad way to end up with a broken device.
- I would also make sure the valve is in a safe position first, so a failed update does not leave the water loop in a bad state.
- After any change, I would repeat the full function test from the checklist.
- I would write down the old and new version in the greenhouse logbook before and after.

### Checking the version

- Read the version when the actuator is awake and the battery is healthy.
- Compare it with v6.15.669. If it shows something else, I treat that as a change that needs an explanation.
- If the version cannot be read at all, I check the battery first. A low battery is the most common reason for a silent or confusing device.

### Common software-looking problems

- The valve does not respond: check the battery and the contacts before blaming the firmware.
- The valve stops short of its end position: check for mineral scale on the stem, then the coupling, then the battery, and only then the firmware.
- The position it reports does not match what I see: close and open it once to let it find its end stops again.
- The valve behaves differently after a battery change: give it a full cycle before drawing any conclusion.
- The valve works in the morning but struggles later: think about heat in the greenhouse and battery strength.

### Notes to myself

- Keep the firmware version in this note and nowhere else, so there is one place to check.
- If I ever change it, edit this section and add a short line about why.
- Keep the physical checklist and the software notes together. In practice, most faults I have seen on a battery-powered red actuator in a wet greenhouse have been physical or power related, and the firmware is the last thing I suspect.
- Do not rely on memory for what the valve should do in each position. Write down which position is normal for the aquaponics loop and check against that.

### Ideas for later

- Make a small card with the firmware version and the normal valve position and keep it near the actuator.
- Keep a short list of symptoms and the order in which I check causes: battery, contacts, coupling, stem, then firmware.
- Compare how the actuator behaves in different seasons, since the greenhouse temperature changes a lot and affects the battery.
