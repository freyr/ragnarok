---
type: drivers
status: active
project: mirke-retrofit
area: aquaponics
description: "Drivers about Mirke retrofit."
---

# Drivers of Mirke retrofit

## Costs

Mirke retrofit is a project in the aquaponics area. Its goal is retrofit: the existing system gets reworked rather than rebuilt from scratch. It started in autumn 2021, and the plumber leads it.

The main cost drivers are the ones that touch water. Pipework is the biggest item, because the old runs between the fish tanks, the filter and the grow beds need to be replaced or rerouted. Fittings, valves and pump parts come next. Anything that has to be bought twice because of a wrong size counts as waste, so I measure the existing lines before ordering.

Labour is mostly the plumber's own time, which I treat as part of the cost even when it is not billed. Smaller costs are sealant, clamps, spare tubing and testing the system before fish go back in.

The constraint I watch most is downtime. The longer the system sits idle, the greater the risk to the fish and the plants, so cheaper work that takes much longer is not really cheaper.

## Budget

The budget of Mirke retrofit is 4702.32 EUR. It has to cover materials, tools I do not already own and a small reserve for surprises found once the old pipes are opened up.

Success is measured simply. The retrofit is done within budget, the system runs without leaks, and water flow and fish health are steady after the restart. I check the spending against the budget at each stage and stop to reconsider if the reserve is used up early.
