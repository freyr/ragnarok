---
type: research
status: active
project: mirke-retrofit
area: aquaponics
description: "Research about Bethmiork radio receiver."
---

# Bethmiork radio receiver study

## Supplies

This part of the study is about what I need on the bench before I start taking the Bethmiork radio receiver apart and testing it. The receiver is a green radio receiver that runs on battery power. It was installed in 2023 and it sits in the workshop, where it is used alongside the aquaponics setup. I want to keep those basic facts in front of me, because every supply choice below follows from them.

### Tools

- A small precision screwdriver set. The casing is held shut with small screws, and I do not want to strip them.
- A plastic opening tool, so I do not scratch the green casing when I pry the panels apart.
- A multimeter that can read low direct current voltage and continuity. Because the receiver runs on battery, most of my checks will be about voltage drop and current draw.
- A soft brush and a can of compressed air for dust. The workshop is dusty, and I suspect dust is part of the story.
- A headlamp. The corner of the workshop where the receiver sits is dim, and shadows make it hard to read the markings inside.
- A notebook and a pencil for quick readings, plus the phone camera for photos of anything I might need to reassemble later.

### Power items

- Spare batteries of the same type the receiver uses now. I want fresh ones for baseline tests, and I want to compare them against the ones currently installed.
- A battery tester, to see how worn the installed cells are before I blame the receiver.
- A set of clip leads, so I can power the receiver from a bench source if I decide to rule out the battery completely.
- A small container to keep removed batteries separate and labelled, so used and fresh cells never get mixed.

### Cleaning and protection

- Isopropyl alcohol and cotton swabs for contacts in the battery compartment.
- A dry cloth, and a second cloth that I allow to be a little damp, for the outside of the case.
- A few zip bags for screws, so each group of screws is stored by where it came from.
- A tray with a rim, so nothing rolls off the bench.
- A plastic sheet to keep splashes away from the receiver. The aquaponics tanks are not far from the bench, and humidity is a real concern for any electronics in the workshop.

### Reference material

- The paper notes I made when I installed the receiver in 2023. They are thin, but they record where I mounted it and which way the antenna faced.
- My own photos of the workshop shelf from that time, which help me remember the original layout.
- A blank page where I will draw the signal path as I trace it, from antenna to speaker.

### What I decided not to buy

I considered buying a new antenna and a replacement speaker. I decided against it for now, because I do not yet know whether either one is at fault. Buying parts before I have a diagnosis is how I end up with a drawer full of things I never use. The plan is to test first and only then list purchases.

## Schedule

I want this study to run in small steps, so that a single evening of work never turns into a mess that I have to leave half done on the bench. The receiver is part of how I keep an ear on things while I work in the workshop near the aquaponics system, so I also want it to be out of service for as short a time as possible. Each step has a clear stopping point.

### Step one: observation without touching

Before any tools come out, I will simply listen. I will switch the green receiver on in its usual place in the workshop and note how it behaves over a normal working session. I will write down how clear the sound is, whether it drifts, and whether the volume changes by itself. I will also note whether the pump and the lights nearby seem to affect the reception. This step costs nothing and may point to interference rather than a fault in the receiver.

### Step two: battery check

Next I will test the installed batteries with the battery tester and the multimeter. The receiver is battery powered, so weak cells are the most likely cause of any trouble. I will then swap in fresh batteries and repeat the listening session from step one. If the sound improves, the study may be close to finished, and the remaining steps become optional.

### Step three: external inspection

If the battery is not the cause, I will look closely at the outside. I will check the antenna, the tuning control, the volume control and the battery door. I will look for corrosion, moisture marks, cracks in the green casing, and anything that suggests the workshop environment has been rough on it since 2023.

### Step four: opening the case

Only after the first three steps will I open the case. I will photograph each layer before moving anything. I will clean the battery contacts, brush out dust, and look for loose wires or signs of damp. I will keep the screws in labelled bags and keep the work to a single sitting, so I never leave the receiver open overnight.

### Step five: bench measurements

With the case open and fresh batteries in, I will take voltage readings at a few accessible points and record them in the notebook. I am not trying to build a full diagnosis of the circuit. I only want to see whether the voltages look sensible and steady, and whether they sag when the volume goes up.

### Step six: reassembly and a long listen

I will close the receiver, put it back in the workshop, and let it run for a few working days. I will write down any change. If the sound is stable, I will mark the study as resolved. If not, I will move to the shopping list and decide what to replace.

### Pacing

I plan to work in short sessions, one step at a time, and to leave a day between steps three and four so that I can think about what I saw. If the aquaponics setup needs attention, that always comes first, and the receiver study waits.

## Open questions

These are the things I do not know yet. I am listing them now so that I can come back and cross them off as the study goes on.

1. **Is the battery the real problem?** The receiver is powered by battery, and I do not remember when I last replaced the cells. If a fresh set clears up everything, then the rest of the study is mostly about how to avoid a repeat.
2. **How much does the workshop environment matter?** The receiver has been in the workshop since 2023, close to an aquaponics system that adds humidity. I do not know if damp air has touched the inside of the case. I also do not know whether the pump or other equipment adds electrical noise.
3. **Is the location right?** The receiver sits where I put it when I installed it, but I never tested other spots. A different shelf might give better reception, or might protect it better from moisture.
4. **Does the green casing hide wear?** The colour makes dirt and stains hard to see in the dim light. I want to find out whether there are marks that I have simply been missing.
5. **How long should the batteries last?** I have never measured how long a set lasts in daily use. I would like to keep a simple log, so I can plan replacements instead of reacting to failures.
6. **Is it worth keeping the receiver in its current role?** If the study shows that it needs a lot of repair, I should ask whether a different receiver would suit the workshop better. I am not ready to answer that yet.
7. **What should I record for the future?** My notes from the installation in 2023 were thin. I want to decide what to write down this time, so that a later version of me does not face the same gaps.

I will keep this list short and update it after each step in the schedule above.

## Ideas

The Bethmiork radio receiver is a green radio receiver that has sat in my workshop since 2023, and it runs on battery. Most of my ideas about it come from one question: can a small, cheap, battery-powered radio be a useful tool for an aquaponics setup, rather than just background noise while I work?

The first idea is to use it as an audible alarm channel. My aquaponics system depends on a pump, an air supply and a steady water level. If I build a small transmitter that sends a simple tone when the pump flow drops, the receiver in the workshop could carry that tone. I would hear a problem even when I am away from the tanks and my phone is in another room. The receiver would not need to be smart. It would only need to be tuned and loud enough.

The second idea is to treat the receiver as a test bench for interference. Aquaponics gear is full of small motors, switching power supplies and cheap timers. All of these make radio noise. With the receiver tuned to an empty spot on the dial, I can walk along the bench and listen. A rise in hiss or buzz tells me which device is noisy. That is a crude method, but it costs nothing and it is quick.

The third idea is about weather and local information. If I can pick up regular forecasts, I can plan around cold nights, which matter because water temperature affects both fish and plants. The receiver is battery-powered, so it would keep working during a power cut, which is exactly when I would want a forecast most.

The fourth idea is to keep a short log of what I hear. Over a few months, I could note which stations come in clearly at which times of day, and how the green case sits in different spots in the workshop. The aim is to find the best place for the antenna and to see whether the damp air near the tanks changes reception.

Some smaller ideas I want to keep on the list:

- Mark the dial with tape at the stations I actually use, so I do not have to hunt.
- Keep a spare set of batteries in a labelled bag next to the receiver.
- Try a longer wire antenna along the window frame and compare it with the built-in one.
- Check whether the receiver can be moved to the tank area for a day without trouble from moisture.
- Write down the volume setting that is loud enough to hear over the pump but not so loud that it annoys me.

Ideas I have decided against for now: wiring the receiver into the water system directly, and using it to control anything. It is a receiver, and it should stay a receiver. Mixing mains-powered pumps with a small radio in a wet room is not a project I want to start with.

## Setup

The receiver is installed in the workshop, and the year of installation was 2023. It is green, which makes it easy to spot on a shelf full of grey and black equipment. Its energy source is battery, so there is no power cord to route and no outlet to share with the pump timers.

My current arrangement is simple. The receiver sits on a shelf at about chest height, away from the floor where splashes happen, and about two metres from the nearest tank. I chose that distance on purpose. It is close enough to hear alarms, and far enough to stay out of the spray and the humid air. The shelf is wood, not metal, because metal shelves seemed to change the reception.

Steps I follow when I set it up or reset it:

1. Put in fresh batteries and check the polarity twice.
2. Extend the antenna fully and point it upward.
3. Tune to a known strong station first, to confirm the receiver is working.
4. Move to the empty spot on the dial that I use for interference checks.
5. Set the volume and note the position.
6. Wipe the case with a dry cloth to remove dust and any moisture.

For the alarm idea, the plan is to build the transmitter separately and test it on the bench before it goes anywhere near the tanks. I would keep the transmitter weak and legal, and I would check local rules before I broadcast anything. If the rules make that awkward, I will drop the transmitter and use the receiver only for listening and for interference checks.

I keep a small notebook beside the receiver. Each entry has the day, the station, the reception quality on a scale of one to five, and any change I made to the antenna or position. After a few weeks, patterns become visible. For example, reception drops when the large workshop fan runs, and it improves a little when the door is closed.

Battery handling is the most practical part of the setup. Because the receiver relies on batteries, I treat them as a maintenance item, like filters. I check them at the start of each month, remove them if the receiver will be unused for a long period, and keep the contacts clean. If I see any white residue, I clean the contacts at once with a dry swab. Rechargeable cells are an option, but I want to confirm that the receiver works well on their slightly lower voltage before I switch.

What I still need to do:

- Build a simple shelf lip so the receiver cannot slide off.
- Put a small bag of drying material in the shelf corner to cut humidity.
- Test reception with the pump running and with it off, and record both.
- Decide whether the antenna wire along the window is worth keeping.

## Risks

The main risk is moisture. Aquaponics creates humid air, and a battery-powered radio in a workshop near the tanks can corrode over time. Corrosion on the battery contacts is the most likely failure. I reduce the risk by keeping the receiver on a high shelf, wiping it down, and checking the contacts each month.

The second risk is battery failure at the wrong moment. If I rely on the receiver for forecasts or alarms and the batteries run flat, I get silence, and silence looks the same as "everything is fine." This is the dangerous part of the alarm idea. I need a way to tell a quiet system from a dead receiver. One fix is a regular test tone at a fixed time each day. If I do not hear it, I know something is wrong with the receiver or the transmitter, not with the fish.

The third risk is interference working against me. The same motors and power supplies that I want to detect can also drown out a weak alarm signal. If the pump itself creates noise on the channel I chose, the alarm may be masked exactly when the pump is struggling. I should test the alarm with the pump running under different loads before I trust it.

The fourth risk is false confidence. A cheap receiver is not a certified safety device. If the fish stock matters, I should not let a hobby radio be the only warning. A float switch, a simple water level alarm or a plain visual check each day should remain in place. The receiver is an extra layer, not the main one.

The fifth risk concerns legal and practical limits on transmitting. Even a low-power transmitter may be restricted in my area. I have not confirmed the rules, so I treat the transmitter idea as unconfirmed. Until I do, the receiver stays in listen-only use.

Other risks, in short:

- Dropping the green case on the workshop floor and cracking the housing or the antenna joint.
- Leaving old batteries inside until they leak.
- Mixing old and new batteries, which shortens life and raises the leak chance.
- Spilling water or nutrient solution on the receiver while working at the tanks.
- Dust from workshop jobs getting into the dial and volume control.
- Forgetting to note changes in the notebook, which makes later comparisons useless.

How I plan to manage these risks:

1. Keep the receiver on its shelf, with a lip, and away from the splash zone.
2. Replace batteries on a schedule, not only when they fail.
3. Run a daily test tone if I ever build the alarm.
4. Keep the independent water level alarm as the real safeguard.
5. Review the notebook every few weeks and adjust the placement.

If the receiver proves unreliable in this humid setting, the fallback is simple: move it to a drier corner of the workshop and use it only for forecasts and interference checks. That would still give me value from a device that has been in the workshop since 2023, and it would remove the risk of relying on it for anything important.

## Tools

This section lists what I use when I work on the Bethmiork radio receiver. It is a green radio receiver, powered by a battery, installed in the workshop in 2023. It belongs to the aquaponics area of my notes, because it sits near the fish tanks and grow beds and I listen to it while I work there.

### Basic hand tools

I keep a small set of tools in a tray under the workshop bench, so I do not have to hunt for them when the receiver acts up.

- A small cross-head screwdriver and a small flat screwdriver for the case screws and the battery cover.
- A pair of fine tweezers for pulling out loose wire ends and fishing out dropped screws.
- A soft brush, the kind used for painting, for dusting the dial and the speaker grille.
- A dry cloth and a slightly damp cloth. The workshop is humid because of the aquaponics setup, so the case gets a film on it.
- A plastic spudger, or failing that an old guitar pick, for opening the green case without scratching the paint.

### Measuring tools

A cheap multimeter is the most useful thing I own for this receiver. I use it for three jobs:

1. Checking the battery voltage under load, not only when the receiver is resting.
2. Checking continuity in the battery contacts, which are the most common point of failure.
3. Checking that the speaker connection is intact when the sound crackles.

I also keep a second, small battery-powered radio nearby. It is a reference. If the Bethmiork is quiet on a station and the reference plays it clearly, the problem is the receiver or its antenna, not the broadcast.

### Cleaning supplies

- Contact cleaner, used sparingly on the battery terminals and the tuning knob.
- Cotton swabs, which I cut short so they reach into the battery compartment.
- A small tub of petroleum jelly, a very thin smear on the battery contacts to slow corrosion in damp air.

### Notebook and labels

I keep a paper notebook in the same tray. Each time I change the battery or clean the contacts, I write down the day and what I did. I also keep a roll of masking tape and a pen, for labelling any loose part before I take something apart. Since the receiver is battery-powered, the log of battery changes tells me quickly whether a drop in performance is a normal end of charge or a new fault.

### Working habits

A few rules I follow every time:

- Remove the battery before opening the case. I do this even for a quick look.
- Work on a tray so screws do not roll away under the bench.
- Take a photo of the inside before touching anything.
- Put the case screws back in the same holes, because the plastic is soft and the threads wear.
- Do not use water near the electronics. A damp cloth is only for the outer shell.

### What I do not own

I have no oscilloscope, no signal generator and no soldering station dedicated to this job. I use the soldering iron from the main workbench when I need it, but I try to avoid soldering the receiver. If a repair needs more than basic cleaning and contact work, I note it as a project for later instead of improvising.

## Costs

I do not record exact prices in this note. The costs below are described by kind and by how often they come up, which is enough for planning.

### Purchase and installation

The receiver was installed in 2023. The cost of buying it was a one-time expense, and it was modest compared with the rest of the aquaponics equipment in the workshop. Installation cost almost nothing. Because the energy source is a battery, there was no wiring job, no extra socket and no cable run along the wall. I put it on a shelf, switched it on and tuned it. That is one of the main reasons I chose it for a damp workshop: no mains lead is near the water.

### Running costs

The only ongoing cost is the battery. Over the years this has been the largest cost by far, and it is worth thinking about in three parts.

- **Replacement batteries.** I buy them in multi-packs, which works out cheaper per battery than single ones. I keep a spare set on the shelf next to the receiver.
- **Rechargeable option.** Rechargeable batteries cost more at the start but pay back if the receiver is on for many hours a day. I have tried them. They lose charge slowly while sitting, so for a radio that is sometimes left off for days, ordinary batteries are less fuss.
- **Listening habits.** Volume and hours of use change battery life a lot. Turning the volume down when I am working alone in the workshop saves more than any other trick.

### Maintenance costs

Maintenance is cheap because I do it myself with the tools above. The items I have to replenish are small:

- Contact cleaner, which lasts a long time because I use so little.
- Cotton swabs and cloths.
- Petroleum jelly for the battery contacts.
- The occasional replacement battery cover or spring contact, if one breaks.

I have not paid for any professional repair. If the receiver failed in a way I could not fix with cleaning, I would weigh the repair against the cost of a replacement, and with a simple receiver like this one replacement would probably win.

### Hidden costs

There are a few costs that do not show up on a receipt.

- **Time.** Cleaning the contacts and checking the battery takes a few minutes each time, but I do it often because of the humidity.
- **Humidity damage.** The workshop air is damp from the aquaponics system. If I neglect the receiver, corrosion on the battery contacts could ruin it, and that would be the biggest cost of all. The cheap precautions are what protect the larger investment.
- **Disposal.** Used batteries have to be taken to a collection point, not thrown away. That costs me a short trip, not money.

### Cost summary

In plain terms: a low purchase cost, no installation cost, and a small steady cost in batteries. Everything else is minor. The best way to keep costs down is to keep the contacts clean, keep the volume reasonable and keep the receiver away from splashes.

## Background

### What the device is

The Bethmiork is a radio receiver. It only receives broadcasts; it cannot transmit. Its case is green, which makes it easy to find among the grey and black items in the workshop. It runs on a battery, and it has been installed in the workshop since 2023. In my notes it falls under the aquaponics area, because that is the work I do in the room where it sits.

### Why it is in the workshop

The workshop holds the pumps, the tubing, the test kits and the other items I use to look after the fish and the plants. Many jobs there are slow and repetitive: testing the water, cleaning filters, trimming plants and checking flow. A radio makes those jobs more pleasant. I wanted a receiver that was independent of the mains for two reasons.

- The workshop has water around, and I prefer to keep mains-powered equipment away from it where I can.
- A battery set can be moved. I can carry it to a different bench or to the grow beds if I need to.

### Why battery power matters here

The energy source shapes almost everything about how I use the device. If the power goes out, the receiver keeps working, which is useful because the pumps and aerators matter most during an outage and I like to hear local news then. On the other side, the battery sets a limit on how long I can listen, and it makes me responsible for keeping fresh batteries on hand.

### How I use it

I mostly use it for background listening while I work. I tune it to a few stations and leave it. It is not an instrument for measurements, and I do not treat it as one. Its job is simple: receive a clear signal and play it through the speaker without hiss.

### Known behaviour

Over the years I have noticed a few patterns.

- Reception is better near the window than at the back of the room.
- Large metal items, such as tanks and shelving, change the signal if I move the receiver close to them.
- When the battery runs low, the sound gets weak and distorted before it stops completely.
- Damp air is the main enemy. Contacts that were clean last month can be dull and green-white this month.

### Purpose of this study

I wrote this note to keep everything about the receiver in one place: what I use to look after it, what it costs me to run, and why it is where it is. The note is for my own reference, so that if the receiver stops working or I want to replace it, I know what I did before and what to check first. The other parts of the note cover the remaining sections of the study.

## History

The Bethmiork radio receiver came into my workshop in 2023, and that is the year I count as its installation. It is a green radio receiver, powered by battery, and it sits on the shelf above the bench in the workshop. I bought it for one narrow purpose: I wanted a simple way to hear weather and local talk while I worked on the aquaponics tanks, without running a mains cable near the water.

Before the Bethmiork I used an old kitchen radio. It worked, but the plug and the extension lead sat too close to the grow beds, and after one splash too many I decided that I did not want mains power anywhere near the fish. The battery design of the Bethmiork solved that at once. I never had to think about a wet socket again.

The first weeks were mostly about placement. I tried it on the windowsill, on the pump cabinet, and on the bench. The windowsill gave the best signal but too much sun and too much damp from the tank room next door. The pump cabinet was convenient but the motors added a faint buzz to the reception. I settled on the shelf, which is dry, a little higher than the splash zone, and far enough from the pumps.

During the first year I kept a loose log in a paper notebook. The entries are short: how long a set of batteries lasted, which stations came in clearly, what the weather was like when reception dropped. Reading the log back, I can see a few patterns. Reception is better in the morning than in the late afternoon. It is worse when the workshop door is shut and the grow lights are on. Batteries last longest when I keep the volume low and turn the set off at night instead of leaving it on standby.

In the second year I started to treat it as part of the system rather than a gadget. I listened for the forecast before deciding whether to open the greenhouse vents, and I used the morning news as a timer for feeding the fish. That sounds silly, but it worked. The set became a small routine: switch on, check the tanks, listen to the forecast, feed.

By 2025 the receiver had a few marks on it. The green case has a scuff on one corner where it fell from the shelf once, and the tuning knob is a bit looser than it was. None of this stopped it working. I wrapped a strip of tape around the battery cover after the lid started to pop open when I knocked the shelf.

I want to record what I have learned so that I can decide later whether to keep it, repair it, or replace it. The notes below are practical. They are about what actually went wrong, what I did, and what I still do not know.

## Problems

The problems are small, but they repeat, so I list them in order of how much they annoyed me.

**Battery drain.** The main running cost is batteries. Because the receiver runs on battery, every hour of listening has a price. In the first months I changed the batteries far too often. I was leaving the set on all day, including when I was away from the workshop. Once I began turning it off whenever I left the room, the interval between changes grew a lot. I also learned that cheap batteries die early and sometimes leak. Rechargeable cells work, but they hold a lower charge and the set sounds weaker near the end of each cycle. I now keep a spare set charged on the bench so a flat set never leaves me without sound in the middle of a job.

**Battery cover.** The cover is the weakest mechanical part. It pops open if the set is knocked, and then the sound cuts out. The tape fix works, but it is ugly and it makes changing batteries slower. If I replace anything, it will be this cover or the clip that holds it.

**Interference from pumps and lights.** The water pumps and the grow lights both add noise. The pumps cause a low buzz that rises and falls when they start. The grow lights cause a hiss, mostly on weaker stations. Moving the set to the shelf helped with the pumps. For the lights, the only real cure is distance and angle. If I turn the receiver so the antenna points away from the light rack, the hiss drops. I do not know the exact cause, and I have not measured anything. This is just what I noticed.

**Humidity.** The workshop is next to the tank room, so the air is damp, especially in summer. Moisture is the biggest long-term risk for any electronics in an aquaponics setup. I have seen a little condensation on the inside of the battery cover after a humid night. So far the contacts have stayed clean, but I check them every few months. A small bag of silica gel in a box on the shelf helps, and I replace it when it stops absorbing. I do not leave the receiver near open tank surfaces.

**Tuning drift.** The tuning knob has become loose, and the station sometimes drifts slightly after I touch the shelf or when the room warms up. It is not dramatic, but it is irritating when I am in the middle of a forecast. I now set the station, then leave the knob alone. A small piece of foam under the knob area might help, but I have not tried it.

**Weak signal indoors.** Reception inside the workshop is mediocre because of the metal shelving and the walls. The antenna works best when fully extended and held away from metal. I once tried a long wire clipped to the antenna, and it gave a better signal but looked messy, and I never made it permanent.

**Handling and drops.** The case has survived one fall, but I do not trust it to survive a second. The corner scuff is cosmetic. I added a thin strip of non-slip mat under the receiver so it does not slide when I bump the shelf.

**Things I have not solved.**
- I do not know whether the interference comes from the pumps' power supply or from the motors themselves.
- I do not know how much of the signal loss comes from the building and how much from the receiver.
- I have no fixed rule for when to retire the receiver. For now I will keep it until it stops being practical.

When something goes wrong, my order of checks is simple:
1. Check the batteries and the cover.
2. Check the antenna and its position.
3. Move the set away from pumps and lights.
4. Check the contacts for damp or corrosion.
5. Retune and leave the knob alone.

Most faults are solved by the first two steps.

## Overview

This section is the short summary of what the Bethmiork radio receiver is and how it fits in my work, written so I can find the facts quickly later.

**What it is.** The Bethmiork is a radio receiver. It is green. It runs on battery, not on mains power. It was installed in 2023, and its location is the workshop. Its area of use is aquaponics, which means it supports the work around my fish and plant system rather than being part of the water system itself.

**Role in the system.** The receiver does not control anything. It does not measure water, switch pumps, or feed fish. Its role is to give me information and a sense of time while I work. I use it for the weather forecast, which affects greenhouse venting and temperature, and for the regular programme that I use as a feeding reminder.

**Why battery power matters.** In an aquaponics space, water and electricity are a risk. Using a battery-powered set means there is no mains lead near the tanks. The cost is regular battery changes, and I accept that. For a workshop that sits beside wet areas, I think it is the right trade.

**Why the workshop location matters.** The workshop is dry enough for electronics but close enough to the tanks that I can hear what is going on and reach the beds quickly. Its drawbacks are damp air, metal shelves, and nearby pumps and lights. Most of my practical problems come from this position.

**What works well.**
- The set is simple. There is nothing to configure.
- The battery design keeps mains power away from the water.
- The green case is easy to spot on the shelf.
- Morning reception is reliable.
- It has lasted since 2023 with only minor wear.

**What works less well.**
- The battery cover opens when knocked.
- The tuning knob is loose and drifts.
- Pumps and grow lights add noise.
- Damp air is a constant concern.
- Battery cost adds up if I leave it on.

**Habits that help.**
- Turn it off when I leave the room.
- Keep a spare set of batteries charged.
- Keep the antenna extended and clear of metal.
- Keep the receiver on the dry shelf, away from open water.
- Check the contacts and the silica gel every few months.
- Set the station once and leave the knob alone.

**Summary of properties.**
- Device: Bethmiork radio receiver
- Kind: radio receiver
- Area: aquaponics
- Color: green
- Energy source: battery
- Year installed: 2023
- Location: workshop

**My current view.** The Bethmiork is a modest, useful tool that does its job. It is not precise, and it is not perfect, but it fits the place and the work. I would keep it in service, fix the battery cover first, and watch the damp. If the contacts corrode or the tuning becomes unreliable, I will replace it with another battery-powered set and keep the same placement rules, because those rules matter more than the particular model.

**Open questions for later.**
- Would a better antenna position fix the grow light hiss?
- Would a small sealed box protect it from humidity without hurting reception?
- How many months of use do I get from a set of rechargeable cells compared with ordinary ones?
- Is it worth adding a simple shelf lip so that the set cannot be knocked off?

I will answer these with small tests over the next year and add the results to my notes, keeping each test short and practical so that I actually do it.

## References

These are the sources I used for this study of the Bethmiork radio receiver. Most are my own papers and notes, because there is very little published material on this unit. A short description of the device comes first, so the list makes sense on its own.

The Bethmiork is a radio receiver. It works in the aquaponics area of my setup. The case is green. It runs on battery power, and it was installed in 2023. It sits in the workshop, on the shelf above the bench, near the window.

**Primary sources**

- The paper leaflet that came in the box. It has a plain wiring sketch, a list of the controls, and a short paragraph on battery care. It says nothing about damp air, which is the main problem in my case.
- My installation sheet from 2023. I wrote it the day the receiver went onto the shelf. It records where the antenna wire runs, which battery type I chose, and why I picked the workshop instead of the grow room.
- My running logbook, the paper one that hangs by the bench. It holds battery swaps, cleaning days, and odd noises in the order they happened.
- Photographs I took of the inside of the case during the first cleaning. They are my only record of how the board and battery clips are laid out.

**Secondary sources**

- Notes from a conversation with a neighbour who keeps fish and herbs in a similar closed system. He told me that condensation, not electrical faults, ends most small electronics near tanks.
- A few pages of a general handbook on small radios, which I used to understand tuning drift and why a weak battery makes reception hiss.
- My own earlier notes on the pump timer and the water-level alarm in the same workshop. They matter because those devices share the same shelf area and the same damp conditions.

**How I rate these sources**

I trust the logbook most, because I wrote each entry while looking at the device. I trust the leaflet for the controls and not for anything about the environment. The neighbour's advice is useful but anecdotal, so I treat it as a hint to test rather than a rule. The handbook is good for theory and weak on this model.

**Gaps**

- I have no manufacturer statement on how long the battery should last in cold conditions.
- I have no information on whether the green coating is meant to resist moisture or is only paint.
- I have no record of how the receiver behaved before 2023, since I did not own it then.

I may try to fill these gaps with small tests, and I will note any results under Observations.

## Maintenance

This section is the routine I follow for the Bethmiork. It is practical and meant for me to read again in a few months, so it is written as steps and reasons.

**Power and battery**

The receiver is battery powered, and the battery is the part that needs the most attention. I check it on a regular rhythm, roughly whenever I do the weekly tank round. A weak battery does not make the radio stop at once. First the sound gets thin and hissy, then the tuning wanders, and only later does it go quiet. If I notice hiss, I change the battery before I touch anything else. Chasing a fault that is only a tired battery wastes an afternoon.

When I change the battery I do the following:

1. Switch the receiver off and take it down from the shelf.
2. Open the battery compartment and look at the contacts for dullness, white powder, or green crust.
3. Wipe the contacts with a dry cotton swab. If there is corrosion, I use a swab barely dampened with vinegar, then dry it fully with a clean one.
4. Fit the new battery, checking the direction twice.
5. Close the compartment, switch on, and listen to one familiar station for a minute before putting it back.

I never leave a dead battery inside. Leakage in a damp workshop spreads fast and ruins the clips.

**Moisture control**

The workshop is next to the aquaponics system, so the air carries humidity from the tanks and grow beds. This is the main long-term risk to the radio. My habits are:

- Keep the receiver on the high shelf, away from splashes and well above the water line of any tank.
- Wipe the green case with a barely damp cloth, then a dry one. I do not spray cleaner on it.
- Open the workshop window on dry days so the air moves.
- Check the inside of the case for misting whenever I open it. If I see any, I leave the case open in a dry room for a day before closing it.

**Antenna and controls**

The antenna wire gets knocked when I work at the bench. I run my fingers along it and check that it is not kinked and that the connection point is firm. A loose wire causes crackling that looks like an electrical fault but is only mechanical.

The tuning knob and volume dial collect dust and fine spray. I turn each one through its full range a few times during every cleaning. This clears the contact and shows me whether any crackle is present. If a dial is scratchy, I note it in the logbook and watch whether it gets worse before deciding on anything stronger.

**What I do not do**

- I do not open the sealed parts of the board. I have no schematic, and my photographs are not enough to rebuild anything.
- I do not use oil or contact spray on the dials. The residue attracts dust and I cannot judge how it affects the plastic.
- I do not leave the receiver running unattended for days on a nearly empty battery.

**Rhythm**

- Each weekly round: look at the case, listen for hiss, check the antenna wire.
- Each battery change: clean the contacts and exercise the dials.
- Twice a year: a fuller clean, open the case, check for moisture or dust, and compare with the photographs from the first cleaning.

If a fault goes beyond these steps, I will stop and note the symptoms before doing anything else. I would rather have a clear description than a repair that hides the cause.

## Observations

These are the things I have noticed while using the Bethmiork radio receiver in the workshop since 2023. They are my own impressions and should be read as that, not as measurements.

**Reception**

Reception is generally steady in the workshop. The location helps, since the shelf is high and the antenna wire has a clear run along the wall. Reception gets worse when the pump motors and the lights are running at the same time, which suggests interference from nearby equipment. It is not a fault in the receiver itself. When I move the antenna wire a short distance away from the pump cable, most of that noise fades.

**Battery behaviour**

Because the receiver runs on battery, I pay close attention to how it ages. The first sign of a tired battery is always the same: a thin, hissing tone, followed by drift in the tuning. This has been consistent enough that I now treat it as a reliable early warning. Cold mornings in the workshop seem to bring the symptom on sooner. I have not tested this properly, so it stays an impression for now.

**Effect of the environment**

The aquaponics area is humid, and the receiver shows it in small ways. I have seen a light film of moisture on the inside of the case after a very damp spell. The green finish still looks even, but the edges around the dials have dulled a little. I have seen no rust on the battery clips since I started wiping them during each change, but I keep looking.

**Sound and handling**

The sound is clear enough for talk and music at the volume I use while working. The controls are easy to use with dirty hands, which matters in a workshop. The green case is easy to spot on the shelf, which is a small but real advantage when I am looking for it among tools and tank equipment.

**Open questions**

- Does the cold in the workshop shorten battery life, or is it only the damp?
- Is the interference from the pumps constant, or does it depend on which pump runs?
- Would a small bag of drying material near the shelf reduce the misting inside the case?
- How much has the dulling around the dials changed since the first cleaning?

**Next small tests**

I plan to keep a simple tally in the logbook of how long each battery lasts and what the weather was like. After a few changes I should be able to see a pattern. I also want to try the drying material idea for one season and compare the case interior against my photographs. If the interference question stays open, I will note which pump is running whenever the hiss appears.

**Overall impression**

The Bethmiork has been a dependable radio receiver for the workshop. Most problems come from battery state, moisture, or a disturbed antenna wire, and all three are cheap to check. For now the routine in the maintenance section seems enough to keep it working well.

## Safety

This section covers the risks I have noted for the Bethmiork radio receiver. It is a green radio receiver that runs on a battery. It was installed in 2023 and sits in the workshop, which is next to the aquaponics area. Aquaponics means water, fish and plants, and that is the main safety concern around a small electronic device.

### Water and moisture

The workshop is not a dry room. Air near the aquaponics tanks carries moisture, and splashes happen when I move pipes or net pots. The receiver is not sealed, so I treat it as a device that must stay away from water.

- Keep the receiver on the high shelf, never on the bench edge nearest the tanks.
- Wipe wet hands before touching the receiver or its battery.
- If water gets into the case, remove the battery first, then dry everything.
- Do not switch it on again until it has dried for a full day in a warm, airy spot.

The green casing hides water stains, so a quick glance does not tell me whether the case is damp. I check by touch and by looking at the seams around the battery door.

### Battery handling

The energy source is a battery, and that is a real advantage here. There is no mains cable near the water, so the risk of electric shock is very low. The battery brings its own risks.

- Do not leave a dead battery inside the receiver. Leaking cells corrode the contacts.
- Never mix old and fresh cells, and never mix different types.
- Do not short the terminals with metal tools. The workshop has plenty of loose screws and wire offcuts, so I keep the battery compartment closed.
- Do not charge a battery that is not meant to be recharged.
- Store spare batteries in a small plastic box, away from the damp area and away from metal objects.
- Take used batteries to a proper collection point. They must not go into the general bin or near the tanks.

If a battery swells, gets hot, or smells strange, I remove it with gloves, put it on a non-flammable surface outdoors, and do not use it again.

### Chemical and fish safety

Anything that falls into the system water can harm the fish, and fish water can harm the electronics. A leaking battery near the tanks is the worst combination. For that reason the receiver never goes on the tank frame, and I never place a spare battery near the water.

I also avoid using cleaning spray close to the receiver. Solvents can cloud the plastic and get into the speaker grille. A slightly damp cloth, wrung out well, is enough for the case.

### Audio level and hearing

Working in a workshop already means noise from tools. I keep the volume at a level where I can still hear a pump alarm or someone calling me. Turning the radio up to cover pump noise is a bad habit, because a failing pump often changes its sound first. The radio should never hide that warning.

### Workshop habits

- Switch the receiver off when I leave the workshop for the day. That saves the battery and removes one thing that could go wrong unattended.
- Keep the aerial or any wire away from the pump power cables, so no one pulls on it by mistake.
- Keep the area around the receiver clear of dust and sawdust. Fine dust in the controls makes them scratchy.
- Do not open the case while standing in a wet spot or while a hose is running.

### Quick checklist before use

1. Hands dry, floor around me dry.
2. Case dry, battery door closed.
3. Battery fitted the right way round.
4. Volume low at switch-on.
5. No cables lying across the walkway.

### What to do if something goes wrong

If I see smoke, smell burning or feel heat from the receiver, I take out the battery straight away if it is safe to do so. I then move the unit away from anything flammable. I do not put water on a burning battery. I check the aquaponics pumps afterwards, because a problem in one place often means someone was distracted in another.

## Parts

This section lists the parts of the Bethmiork radio receiver and what I have noted about each of them. The part number of the Bethmiork radio receiver is QU-7058-W. I use that number whenever I look for a manual, a spare, or a replacement unit, so I keep it here and on the inside of the workshop cupboard door.

### The unit as a whole

The Bethmiork is a radio receiver, green in colour, powered by a battery. I installed it in 2023 in the workshop. It supports my work in the aquaponics area by giving me background sound and the occasional weather report while I work. It is a simple device, and almost everything I need to know about its parts fits in a few categories.

### Main parts

- **Case.** Green plastic shell with a removable back. The colour is even and fades slightly where sunlight reaches it through the workshop window. The seams are the weak spot for moisture.
- **Battery compartment.** Sits behind a small door on the back. The contacts are metal springs and a flat plate. These are the first things to corrode if a battery leaks.
- **Tuning control.** A dial that moves across the band. It feels smooth when clean and gritty when dusty.
- **Volume control.** A rotary knob, also the power switch in the first part of its turn. I check it for scratchiness every season.
- **Speaker and grille.** The speaker sits behind the front grille. The grille collects dust and workshop debris, so it is the part I clean most often.
- **Aerial.** A telescopic rod that folds into the case. I keep it extended only while listening, which protects it from knocks.
- **Internal circuit board.** I have not modified it. I only look at it through the open back when I check for corrosion or loose connections.

### Wear points

From my use so far, the parts most likely to need attention are these:

1. The battery contacts, because of moisture and the chance of leakage.
2. The volume and tuning controls, because of dust.
3. The aerial joints, because of repeated extending and folding.
4. The speaker grille, because of dirt build-up.

The case and the circuit board have given no trouble so far.

### Maintenance routine

- Open the battery door and look at the contacts. If there is any white or green crust, clean it gently with a dry cotton swab, then a slightly damp one, then let it dry.
- Use a soft brush on the grille and the control gaps.
- Slide the aerial out and in a few times to check that it moves freely.
- Check the seam around the back for any sign of moisture, particularly after a humid spell.
- Note any change in sound quality. A crackle usually means a dirty control or a weak battery, not a broken part.

### Replacement notes

When I order anything, I quote the part number QU-7058-W and describe the part I need. Small items such as the battery door, the aerial or a knob may be sold separately, so I write the name of the exact piece in the order message. I keep spare batteries of the right type in the plastic box mentioned in the safety section, and I do not store them in the receiver.

If the receiver ever fails beyond simple cleaning, I will decide between repair and replacement. Because it is a low-cost device with a simple layout, replacement of the whole unit may make more sense than a repair, unless the fault is only in the battery compartment.

### Notes for my own future reference

- Keep the original packaging contents together, including any paper that shows the part number QU-7058-W.
- Write down any change I make to the unit, however small.
- Keep the receiver green and plain. I do not want to paint it, since paint could block the seams or the controls.
- Check again each year in the same month as installation, since it was installed in 2023, and record how the parts are holding up.
