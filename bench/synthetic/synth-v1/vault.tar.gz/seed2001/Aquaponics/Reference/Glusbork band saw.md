---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Glusbork band saw."
---

# Glusbork band saw

## Setup

The Glusbork band saw is a yellow band saw that I installed in 2022. It lives in the shed, on the bench along the back wall, close to the door so I can push long stock through without hitting anything. It is used for the aquaponics area: cutting pipe, plank offcuts, grow-bed frames, and the odd piece of plastic tank lid.

Key properties, so I do not have to look them up again:

- Kind: band saw
- Area: aquaponics
- Color: yellow
- Energy source: solar
- Year installed: 2022
- Location: shed

Power comes from the solar system that feeds the shed. There is no mains backup on this circuit, so the saw only runs well when the batteries are healthy. On a grey day I do the cutting in the late morning, when the panels give the most. If the lights in the shed dim when the motor starts, I stop and wait. A weak supply makes the blade stall in thick material, and a stalled blade is how things go wrong.

The saw is bolted to the bench with four bolts. I check them each season because the vibration loosens them slowly. The bench itself is level, which I checked with a spirit level across both directions. Under the saw there is a small tray to catch sawdust and plastic swarf, and I empty it after every session.

Basic first-run routine after a long break:

1. Look over the blade for cracks or missing teeth.
2. Turn the wheel by hand once around to make sure the blade tracks in the middle of the tyre.
3. Check the guides are close to the blade but not touching it.
4. Switch on and let it run a few seconds before cutting.
5. Listen for any rattle, and stop if there is one.

I learned most of the practical tips from [[Drarktend Sunnarzio]], who showed me how to tension the blade by feel and how to read the sound of a saw that is cutting well. His advice about feeding slowly and letting the blade do the work is the rule I follow most.

## Adjustment

The saw needs a small correction so the cut comes out square to the table. After the last full tune-up I wrote down the calibration offset of Glusbork band saw: 1.998 mm. I use this value when I set the fence and the stop against the blade, because the blade sits slightly off the scale marked on the table.

How I apply it:

1. Unplug or switch off the supply, and make sure the blade has stopped.
2. Set the fence to the mark I want on the scale.
3. Shift the fence by the offset, in the direction away from the blade, so the real distance matches the scale.
4. Lock the fence and make a test cut in scrap.
5. Measure the scrap with calipers. If it is wrong, repeat with a tiny nudge.

Here is the small note that I keep taped inside the shed cupboard, copied here as a config-style reminder:

```
# glusbork band saw - setup card
blade_tension: firm, test by feel
guide_gap: about a paper thickness
calibration_offset: 1.998 mm
fence_lock: tight before every cut
test_cut: always on scrap first
```

Other adjustments I make from time to time:

- **Blade tracking:** turn the small knob at the back while rotating the wheel by hand until the blade runs centred on the tyre.
- **Guide height:** lower the upper guide until it is just above the stock. A big gap leaves too much blade exposed and makes cuts wander.
- **Tension:** too loose and the cut curves; too tight and the blade snaps early. I release the tension when the saw will sit unused for more than a week.
- **Table square:** check with a small square against the blade. If it has drifted, correct it before touching the offset.

If the offset seems wrong, I do not change the number straight away. First I check the tracking and the table, because those are the usual cause. Only if both are fine do I redo the offset measurement and update the card.

## Supplies

Things I keep in stock for the saw, all stored in the shed in a labelled box:

- **Spare blades:** at least two, in the width I use most. A fine-tooth blade is for pipe and plastic, and a coarser one is for wood. I coil them carefully and keep them in cardboard so the teeth do not catch anything.
- **Lubricant:** a light oil for the guides and a dry wax stick for the blade when cutting plastic.
- **Cleaning brush and rag:** the brush clears the wheels and the table slot, and the rag wipes resin and damp off the blade.
- **Push sticks:** several, in different lengths. I make them from offcuts.
- **Safety gear:** goggles, ear protection, and a dust mask. Gloves stay in the box but I do not wear them near the blade.
- **Calipers and a small square:** for testing cuts and checking the table.
- **Marker and masking tape:** for marking cut lines on pipe and for labelling pieces.
- **Spare bolts and washers:** matching the four bench bolts.

Consumables get checked when I do the seasonal review. If I am down to one blade, I reorder before I use the last. Waiting for a blade in the middle of a build, especially when a grow-bed is half framed, is annoying and avoidable.

Because the saw is solar powered, I also keep a headlamp and a small spare battery pack in the box. They are not for the saw itself, but they let me finish safely and put things away if the power drops while I am in the middle of a task.

## Risks

The main dangers are the blade, the dust, the damp, and the power supply.

- **Blade contact:** keep hands well clear of the cutting line. Use push sticks for small or narrow pieces. Never reach behind the blade while it is moving.
- **Blade breakage:** a snapping blade can whip. Replace any blade that shows cracks, and release tension when the saw is idle for a long time. Stand slightly to the side while starting up.
- **Round stock:** pipe can roll and grab. I clamp it or use a V-block, and never cut a round piece freehand.
- **Wet material:** aquaponics parts are often damp. Wet pieces slip, and water near electrics is a bad mix. I dry everything before cutting, and I do not stand in puddles in the shed.
- **Dust and swarf:** plastic shavings and sawdust get everywhere, and fine dust is bad to breathe. I wear a mask and sweep after each session.
- **Power dips:** because the energy source is solar, voltage can sag when the batteries are low. A stall mid-cut can jam the blade. I switch off at the first sign of slowing, back the piece out, and wait for better light or a recharge.
- **Fire:** fine dust and a hot blade is a small but real risk in a wooden shed. I keep a fire extinguisher by the door and do not leave the saw running unattended.
- **Distraction:** I do not cut when tired or in a hurry. Most close calls in my notes happened when I was rushing.

Before leaving the shed I switch the saw off at the isolator, check the blade has stopped, and brush the table clean.

## Costs

The saw was a one-time purchase when I installed it in 2022, and since then the running costs have been small, mostly because the energy source is solar. Running it costs me nothing at the point of use, though it does draw on the shared battery capacity, so I count it as a small share of the solar system upkeep.

Recurring costs:

- **Blades:** the main ongoing expense. Cutting plastic and damp wood dulls them faster than I expected, so I budget for a few per year.
- **Lubricant and wax:** low, a small tin lasts a long time.
- **Bolts and small parts:** rarely needed, only when something is lost or worn.
- **Safety gear:** replaced when worn, for example a mask that no longer seals or goggles that are scratched.

One-off costs that came up:

- A sturdier bench, because the first one flexed under vibration.
- The dust tray beneath the saw, which I built from scrap.
- A set of calipers, needed to confirm the offset and test cuts.

Time is also a cost. A tune-up with the fence offset and a test cut takes about an hour, and I do it each season or after any knock to the saw. I think the time is worth it, since a well set saw wastes less material and saves rebuilding frames that came out crooked.

If I ever need to replace the saw, the things I want to keep are the yellow colour, because it is easy to see in the shed, and a motor that tolerates the solar supply without stalling. I should also write down the offset again after any change, so the card in the cupboard stays correct.
