---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Sithglith yard."
---

# Sithglith yard

## References

Sithglith yard is a yard in the aquaponics area. It was built in 2017 and has a raised floor. The yard is large and faces north.

I keep this note as a quick reference for the basic facts about the place. When I need to check what kind of space it is, where it sits, or how it is built, I look here first.

Summary of properties:

- Kind: yard
- Area: aquaponics
- Orientation: north
- Size: large
- Year built: 2017
- Floor: raised

## Dimensions

The floor area of Sithglith yard is 44.97 m². The yard is classed as large, and the floor is raised, so the usable surface sits above the ground level around it.

The north orientation matters when planning what to place on the floor, since the yard gets less direct sun than a south-facing space would. I use the floor area figure whenever I need to work out how much room is available for equipment or storage.
