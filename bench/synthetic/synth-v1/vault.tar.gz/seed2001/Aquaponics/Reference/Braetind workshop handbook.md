---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Braetind workshop."
---

# Braetind workshop handbook

## Problems

This part of the handbook covers the Braetind workshop, a workshop built in 2013 for aquaponics work. It is a medium-sized building with a north orientation and a raised floor. I keep these facts at the top because most of the trouble I have had here comes from one of them: the north orientation, the raised floor, or the age of the building.

The properties as I record them:

- Kind: workshop
- Area: aquaponics
- Orientation: north
- Size: medium
- Year built: 2013
- Floor: raised

### Light and cold from the north side

The workshop faces north, so it gets very little direct sun. In summer this is a mild blessing, since the room stays cool and the water in the small bench tanks does not overheat. In the cold months it is a steady problem. The room loses heat quickly, and the bench near the north wall is always the coldest spot. Seedlings started there grow slowly and lean toward the one window. I now keep seedling trays on the opposite side of the room and use a grow lamp on a timer instead of trusting the daylight.

Things I have learned about the cold:

- Check the water temperature at the coldest bench first, not at the warmest.
- Pipes along the north wall are the first to get sluggish and the first to grow algae when the light changes.
- A heater in the sump works better than trying to warm the whole room.
- Do not leave a pump running dry on a cold morning; the water in the lines may be thicker with chill than it looks.

### The raised floor

The floor is raised, meaning there is an air gap under the boards. This was a good choice for keeping the room dry and for running drain lines underneath, but it has its own faults. Cold air moves under the floor and the boards feel icy in winter. Spilled water finds its way through the gaps between boards and ends up somewhere I cannot see. A slow leak can go unnoticed for a long time because nothing shows on the surface.

My routine for the floor:

- Lift the access panel near the sump and look underneath at the start of each season.
- Wipe up spills straight away instead of letting them dry on their own.
- Keep a shallow tray under any fitting I have just adjusted.
- Watch for a musty smell, which is the first sign of damp below.

The raised floor also carries the weight of the tanks, and a medium-sized room fills up faster than I expect. Full tanks are heavy, so I place the biggest ones over the beams and not in the middle of a span. If the floor flexes when I walk past a tank, I move the tank.

### Water quality swings

In an aquaponics setup the fish and plants depend on each other, and this workshop is where I test, fix and prepare the parts. The common problems come back every year:

- Water that turns cloudy after a heavy feeding.
- Plant leaves going pale, which usually means a shortage of iron or another trace nutrient.
- A drop in the fish's appetite when the water cools down.
- A pump that hums but moves very little water, nearly always because of a blocked intake.

When something goes wrong I change one thing at a time and write down what I did. If I change several things together, I never find out which one worked. The notes in this handbook exist because I forgot that more than once.

### Space in a medium room

The workshop is medium in size, which sounds like plenty until the work piles up. Bench space disappears under spare tubing, net pots, and half-finished repairs. A few habits keep it usable:

- Every tool has one place, and it goes back there after use.
- Spare tubing hangs on hooks along the wall, sorted by thickness.
- Wet jobs happen at one end of the room, dry jobs at the other.
- Nothing is stored on the floor in front of the access panel.

### Age of the building

The building dates from 2013, and the years show. Some of the original fittings have gone brittle. Seals around the window have shrunk, which adds to the cold draught from the north. Wiring that was fine for a few lights is now asked to run pumps, heaters and lamps together, so I spread the load over different outlets and never chain extension leads. If a fitting looks cracked or stained, I replace it before the next season rather than waiting for it to fail with water in the tanks.

### Pests and plant troubles

Even in a closed system, pests find a way in. Small flying insects come in through the window gap and settle on seedlings. Fungus gnats like the damp media in the starter trays. I do not use sprays near the fish. Instead I use sticky traps above the trays, keep the media from staying soggy, and remove any plant that looks sick before it spreads. Mould on the damp north wall is a separate nuisance and needs a dry cloth and good airflow, not a chemical.

## Supplies

This is the list of things I keep in the workshop so a small failure does not turn into a big one. I check it at the change of each season and replace anything used up.

### Water testing

- A liquid test kit for acidity, ammonia, nitrite and nitrate
- A spare bottle of each reagent, because they run out at the wrong moment
- A thermometer for the tanks and a second one for the room
- Clean jars and a marker for taking water samples
- A notebook kept beside the bench, used for every reading

### Plumbing and pumps

- Spare pumps, one small and one larger, in case a main pump dies
- Flexible tubing in the common thicknesses
- Hose clamps, elbows, tees and unions
- Thread tape and a small tube of food-safe lubricant
- Mesh for covering intakes
- A hand siphon for emergencies

### Heating and lighting

- A tank heater with its own thermostat
- A spare grow lamp and a plug-in timer
- A basic room thermometer near the north wall
- Insulating foam for pipes that run along the cold side
- Draught strip for the window

### Plants and fish

- Net pots and clay pebbles for the grow beds
- Seed trays and starter plugs
- Fish feed, kept in a sealed tub away from damp
- A small net and a lidded bucket for moving fish
- Trace nutrient supplement, used with care and in small amounts

### Repair and cleaning

- A soft brush and a stiff brush, kept separate
- Cloths and a mop bucket that never touches the fish tanks
- Spare fuses and a basic electrical tester
- Gloves, a headlamp and a small mirror for looking under the raised floor
- Shallow trays to catch drips under fittings
- A roll of waterproof tape for temporary fixes

### Storage notes

Because the room is medium in size, I store the bulky items in labelled tubs on the shelf above the bench. Anything that must stay dry goes on the high shelf, not near the floor. Anything with a battery comes out of its device when I am not using it for a long time. I keep the heaviest items, such as bags of media and full buckets, close to the beams under the raised floor so the boards are not stressed.

A short rule I follow: if I have used something twice in a season and it is not on this list, it goes on the list. If I have not touched something in a year, I question whether it should stay.

## References

These are the sources I rely on when I work in the workshop. They are my own notes and the paper material I keep on the shelf, not outside links.

- My bench logbook, which holds the dated water readings and the record of every change I make to the system
- The hand-drawn plan of the room, showing the north window, the access panel in the raised floor and the position of each tank
- The pump and heater manuals, filed together in one folder near the door
- A seasonal checklist that I rewrite each year after I find out what I missed
- A folder of photographs of the plumbing under the floor, taken before the boards were last closed up
- A short list of the plants that grew well in the cool north light and those that did not

The details in this handbook come from working in the building since it was set up in 2013. Where the notes disagree with the manuals, I trust the notes, because they describe this room, this floor and this water.

## Safety

The Braetind workshop is a medium-sized workshop built in 2013, and its main hazard is the mix of water and electricity. It sits in the aquaponics area, and everything that follows assumes that the floor may be wet at any time. The floor is raised, which helps in some ways and hurts in others. Water drains away from the working surface, but the boards can become slick, and a fall from the edge is longer than people expect.

**Water and power**

- Every socket in the workshop must be on a residual current device. I test the device by pressing its test button at the start of each season, and I replace it if it ever fails to trip.
- Pumps, heaters and air units are plugged in only through drip loops. The cable dips below the socket before rising to it, so water runs off the loop and not into the outlet.
- I never handle a plug with wet hands. I dry my hands on the towel by the door first, even for a quick job.
- Extension leads stay off the floor. They hang from the hooks on the beam above the benches.
- Before I put my hands in any tank, I switch off the pumps and heaters on that circuit.

**Footing and the raised floor**

The raised floor lets the air move underneath, which keeps the timber from rotting. The price is that the boards are higher than the ground outside, so the step at the door is a real hazard. I keep a non-slip mat at the top of the step and another at the bottom. I sweep spilled water toward the gaps between boards straight away and do not wait for it to dry. Any board that feels soft underfoot gets marked with tape and checked that week.

**Light, air and the north side**

The workshop faces north, so it gets little direct sun and stays cool and damp. That is pleasant in summer, but it means mould and algae grow on surfaces I rarely touch. I wear a dust mask when I scrub dry mould off the north wall, because the spores are easy to breathe in. In winter the cold makes hands clumsy, so I do not use sharp tools until I have warmed up.

**Chemicals and fish**

Any cleaner that reaches the system can harm the fish and the plants. I use only plain scrubbing and clean water on tank surfaces. Pest sprays and disinfectants stay in the locked cupboard, far from the tanks. If I do use a strong cleaner on a tool, I rinse the tool well and let it dry fully before it goes near the water.

## Lessons

These are the things I learned the slow way. I keep them here so that I stop repeating them.

**The raised floor was worth it**

When I first planned the space I doubted that a raised floor was needed. After a few seasons I am sure it was a good choice. Leaks that would have pooled on a solid slab drain through the gaps, and I can see most problems from underneath with a torch. The lesson is to keep the underside accessible. I once stacked crates under the benches, and a slow leak went unnoticed for weeks.

**Medium size is a compromise**

A medium workshop is large enough for two tanks, a bench and a shelf, but it fills up fast. Each time I bring in a new piece of equipment, something else has to leave. I now follow a simple rule: nothing new enters until I decide what goes out. That has kept the walkways clear, which also helps with safety.

**North light is steady but weak**

Because the building faces north, the light is even and has no harsh glare, which is good for close work and for reading labels. It is poor for plant growth, so anything that needs strong light has to sit by the window or under a lamp. I stopped trying to grow light-hungry seedlings on the shelf at the back. They always became leggy and pale.

**Habits that paid off**

- Keep a notebook by the door and write down anything unusual: a smell, a noise, a change in the water. Small notes help me find patterns later.
- Do one slow walk around the workshop each day before touching anything. Many problems show up this way before they become urgent.
- Label every switch, valve and cable end. In a rush I once turned off the wrong pump because two switches looked the same.
- Keep spare fittings and a few basic seals in a labelled box so that a small failure does not stop work for days.
- Change one thing at a time. When I adjusted the flow and the feeding together, I could not tell which change had upset the fish.

**Mistakes I would not repeat**

I used to leave tools lying on the benches overnight, and damp air left rust spots on the blades. I now wipe each tool and hang it in its place. I also once skipped the weekly check because the system looked fine, and a clogged intake went unseen until the water turned cloudy. Looking fine is not the same as being checked.

**Patience with the system**

Aquaponics is slow. Water quality, plant growth and fish health all change gradually, and rushing a fix usually makes things worse. When something is wrong, I wait, observe and adjust in small steps. Most of my worst days in the workshop came from large corrections made in a panic.

## Maintenance

Maintenance in the Braetind workshop follows a routine of daily, weekly and seasonal jobs. I keep the routine short so that I will actually do it.

**Daily**

- Walk around and look at the tanks, pipes and floor for leaks or damp patches.
- Check that the pumps are running and that the water is moving.
- Look at the fish and note whether they feed normally.
- Wipe up any water on the raised floor and dry the step at the door.

**Weekly**

- Clean the pump intakes and any visible filters. A little blockage becomes a big one quickly.
- Test the water and write the results in the notebook.
- Scrub algae from the surfaces that catch the little light the north side provides. They grow fastest where the water splashes.
- Inspect the cable hooks and drip loops to be sure nothing has slipped to the floor.
- Return tools to their places and wipe them dry.

**Seasonal**

At the change of each season I do a longer inspection. I press the test button on the residual current device and confirm it trips. I crawl or reach under the raised floor with a torch and look for damp timber, rot, pests and loose supports. I press along the boards to find soft spots, then mark and repair them. I also clear the gaps between boards of debris so that water can still drain.

**The building itself**

The workshop dates from 2013, so it is no longer new, and the timber and fixings show their age. Each year I look at the following:

- The door seal and step, which take the most wear.
- The north wall, where damp and mould collect first.
- The underside of the floor, where moisture can sit unseen.
- Metal fittings and brackets, which rust in the humid air.

When I find rust, I scrape it, treat it and repaint the spot. When I find mould, I scrub it off with plain water and a stiff brush, and I wear a mask while doing so.

**Keeping records**

I write down what I repair and when, in plain words, so that I can look back and see whether a problem keeps returning. If the same joint leaks twice, I replace it instead of patching it a third time. A short record also helps when I forget whether a job was done last week or last month.

**When to stop and call for help**

I fix small things myself, but I stop if the problem involves mains wiring, a failed residual current device, or structural damage to the raised floor. These jobs are not worth the risk, and I would rather pay a qualified person than gamble with water and electricity in a wet room.

## Risks

The Braetind workshop is a medium workshop built for aquaponics, and most of its risks come from mixing water, electricity and a raised floor. This section lists what I watch for. It is a working list, not a safety certificate.

**Water on the floor.** The floor is raised, so a spill does not pool at the door, but it finds its way through the boards. Water that gets under the floor stays there a long time, because the space is shaded and the air barely moves. Over the years this is the most likely way for the structure to rot. I check under the boards after any big leak, not only when I see a wet patch above.

**Electricity near water.** Pumps, aerators, heaters and lights all run in a room where hands are often wet. The rules I keep:

- Every socket in the work area sits above the splash line and is protected by a residual current device.
- Drip loops go in every cable before it reaches a socket.
- I never replace a pump while it is plugged in, even for a quick job.
- Extension leads stay off the floor, and none are allowed under the tank frames.

**Cold and the north side.** The workshop faces north, so it gets little direct sun. In winter the water temperature falls faster than I expect, and fish stress shows up before the air feels very cold. A heater failure overnight is the risk I take most seriously. In summer the north orientation helps, because the room stays cooler and algae grow more slowly.

**Weight on a raised floor.** A medium room with full tanks carries a lot of weight. Water is heavy, and the load sits on a few points at the legs of each stand. I keep the largest tanks over the strongest support lines and do not move them without checking the joists below. If a board gives slightly underfoot near a tank, I treat it as a warning and stop adding load there.

**Slippery surfaces.** Algae film and fish feed dust make the boards and the access steps slick. A fall while carrying a bucket is a real danger, so I keep a stiff brush and a non-slip mat near the entrance.

**Biological and chemical risks.**

- Ammonia and nitrite spikes after a pump failure or overfeeding can kill a tank's fish within a day.
- Stagnant water can grow bacteria, so I wash my hands after any work with the water and keep food and drink out of the room.
- Cleaning products and plant treatments can poison the fish. I use only things I have checked and never spray near an open tank.

**Pests.** The raised floor leaves a gap that mice and rats like. A gap also lets cold air in. I keep the skirting closed and check the mesh at the edges each season.

**Power cuts.** A cut stops the pumps, and oxygen in the water drops quickly in a warm tank. I keep a battery air pump ready and test it from time to time. A hand-held torch hangs by the door, because the room is dark when the lights fail.

**Single points of failure.** The workshop depends on one main circulation pump, one heater loop and one timer set. A spare of each is kept in the cupboard. If something is not on that shelf, I assume the failure will happen at the worst time.

## Background

The workshop was built in 2013. It is a workshop in the aquaponics area, meaning a place where fish and plants share a recirculating water system, and where I do the building, repair and testing that go with it. Its size is medium: big enough for several tanks, a grow bench and a workbench, but small enough that one person can reach everything in a few steps. The orientation is north, and the floor is raised.

**Why it was built this way.** The raised floor was a deliberate choice. Lifting the floor keeps the structure off damp ground, lets air flow beneath and gives room to run pipes and drains where they can be reached from below. The price is the extra weight care and the gap that invites pests, both noted above. The north orientation was chosen to reduce heat and glare. A room that does not bake in the afternoon is easier on fish, and shade keeps algae down in the tanks. The cost is weaker winter light for the plants, which I make up for with lamps.

**How it has been used.** In the early years the workshop was mostly a place for testing small systems: a single tank with a grow bed above it, adjusting flow and watching how the water changed over weeks. Later it became a working space for larger builds, where I assemble frames, cut pipe and tune pumps before anything goes into a live system. It is still half laboratory and half workshop, and the notes reflect that mix.

**Layout in brief.** The tanks sit along the longest wall, with the grow bench opposite. The workbench is near the door, so that dirty work happens before the clean area. Plumbing runs under the raised floor, with access hatches in the boards. A cupboard holds spare parts, test kits and the emergency air pump.

**What changed over time.**

- The first lighting was replaced after it proved too weak for the north-facing room.
- Insulation was added to the walls after the first cold winter.
- The hatches in the floor were enlarged so I could reach the drains without lifting the boards.
- The electrical layout was reworked so every socket is above the splash line.

**Properties at a glance.** For quick reference, these are the facts that define the place:

- Kind: workshop
- Area: aquaponics
- Orientation: north
- Size: medium
- Year built: 2013
- Floor: raised

**Lessons so far.** Almost everything that has gone wrong here traced back to water finding somewhere unexpected to go, or to a single part failing without a spare. The design helps with the first and my habits have to handle the second. Writing the risks and the history in one handbook is meant to keep me honest about both.

## Costs

I do not record exact prices here. Prices change, and old figures mislead. This section describes where the money goes and how I think about it, so I can plan without a number that has gone stale.

**Main cost groups.** The workshop spends money in a few steady places:

- **Structure and floor.** The raised floor needs periodic checks and occasional replacement of boards or supports. This is slow and cheap in good years and expensive when rot has set in, which is why I inspect early.
- **Energy.** Pumps run all day, and the heater and lamps add to the bill. The north orientation lowers summer cooling needs but raises winter heating and lighting costs.
- **Water and supplies.** Top-up water, fish feed, plant nutrients, test reagents and filter media are small separately but add up across a year.
- **Livestock and plants.** Fish and seedlings are replaced from time to time. Losses from a bad night cost more than any single part.
- **Spare parts.** A spare pump, heater, timer and air pump sit on the shelf. They are an upfront cost that I treat as insurance.

**Where money is saved.** Reusing frames, pipe and containers keeps build costs low. Doing my own repairs saves labour. The medium size means I do not heat or light more space than I use. Good insulation, once added, paid for itself in lower winter energy use.

**Where I should not save.** I do not cut corners on electrical safety devices, on the supports under heavy tanks, or on the backup air pump. A cheap failure here can cost the whole system, and a person can be hurt.

**Planning approach.** I split costs into three kinds. Running costs happen all year and need a steady budget. Maintenance costs come in cycles and I set aside money for them each season. Emergency costs are the surprises, and the spare shelf is my main defence against them. When I add a new tank or bench, I count its energy and upkeep, not only the purchase.

**Hidden costs.** Time is the biggest one that does not appear on a bill. A weekly round of checks, a monthly deep clean and a seasonal look under the floor all take hours. Skipping them is the cheapest option until the day it becomes the most expensive.

**Review habit.** Each season I look at what I replaced, what failed and what I bought twice. Anything bought twice gets a note about a better choice. Over time this has cut waste more than any single clever purchase.

## History

Braetind workshop is a medium-sized workshop built in 2013. It was put up for aquaponics work, and that has stayed its purpose the whole time. The building faces north, and the floor is raised off the ground. I note these three facts first because almost every other decision about the place follows from them.

The raised floor was a deliberate choice at the start. The ground around the site stays wet for long stretches, and a floor sitting on the soil would have been damp all winter. With the floor lifted, air moves underneath, spills drain away, and I can crawl under to check pipework when something drips. The cost is that everything heavy has to be carried up, and the floor has to be strong enough for full tanks. In the first seasons I learned which spots can take a loaded grow bed and which spots flex.

The north orientation was less a choice than a result of the plot. The long wall faces north, so direct sun hardly ever reaches the working bench. For a workshop this is pleasant, because the light is even and the room does not overheat in summer. For aquaponics it is a limitation, because plants want light. Over the years I settled on a split: the workshop handles the tanks, pumps, plumbing, repairs and preparation, while the sun-hungry plants are grown elsewhere or under lamps. The north light suits fish tanks well, since algae grows slowly where the water is not hit by the sun.

The early years, from 2013 onward, were mostly trial and error. A short summary of how the workshop developed:

- The first setup was a single tank with one grow bed and a hand-adjusted pump. It worked, but it needed attention every day.
- Over time I added a second bed and a better way of draining, so that I could take one part offline without stopping everything.
- The bench was moved twice before I found a position where I could work and still hear the pump.
- Storage was built up along the inner walls, away from the damp corners.
- Lamps were added later, once I accepted that the north side would never give enough light for fruiting plants.

The medium size turned out to be about right. A smaller room would have meant constant shuffling of equipment, and a larger one would have been hard to keep warm and tidy. At this size I can reach every tank and every valve within a few steps, and there is still space to lay out a full repair job on the bench without clearing everything else away.

I keep this handbook because the workshop is easy to misjudge. It looks like an ordinary shed on legs, but the water, the floor and the light all behave in particular ways. Writing down what I learned saves me from relearning it each year.

## Observations

These are the things I have noticed about the workshop as it stands, grouped by what I actually deal with. Each one ties back to a property of the place: workshop, aquaponics, north, medium, built in 2013, raised floor.

**Light and temperature.** Because the building faces north, the light is soft and steady. The bench is never in glare, which is good for close work such as cutting fittings or reading small markings. The room stays cooler than the garden in summer. In winter it loses heat steadily, since no low sun comes in to help. I treat the cold season as the hard part of the year and prepare for it early, rather than waiting for the first frost.

**The raised floor.** The gap under the floor is the best feature for maintenance. A leak shows itself as a drip or a wet patch below, and I can deal with it without moving equipment. The same gap lets cold air reach the floor from beneath, so the boards feel cold in winter. A thick mat in front of the bench makes standing there much more comfortable. I also watch the underside of the floor for damp, because the structure is wood and the surrounding ground stays wet.

**Floor strength.** A full tank is heavy, and the floor has to carry it. I keep the heaviest tanks over the strongest supports and have never put a loaded bed in the middle of a span. If a board feels springy under a new load, I move the load and add a support before using it.

**Water behavior.** In a workshop built for aquaponics, water is the main hazard. Spills are normal, so I keep towels and a small bucket near each tank. Because the floor is raised, a spill usually drains through the gaps rather than pooling, but I still wipe it up, since fish water left on wood smells and stains. Electrical sockets are kept high and away from the tanks, and the pump cables have a loop so that water runs off the cable instead of into the socket.

**Medium size in practice.** The room feels full when two tanks are running and the bench is in use. There is enough space to work, but not enough to leave things lying around. I have learned to put each tool back after use, because a missing tool in a medium room usually means it is buried under something.

**What tends to go wrong.** From experience, the problems come back in the same few places:

- Pumps clog when debris builds up, mostly in the warm months.
- Fittings loosen slowly because of vibration and temperature changes.
- Algae appears in any spot that catches some light, even in a north-facing room.
- The cold end of the room is where pipes are most at risk in winter.
- Damp collects in the corners farthest from the door.

**What works well.** The north light makes the room calm to work in. The raised floor keeps the structure dry enough and makes repairs easy. The medium size keeps everything in reach. The age of the building, from 2013, means I know its habits well, and little about it surprises me now.

**A note on noise and smell.** The pump hum is constant and I have stopped hearing it, which is exactly why I listen for when it changes. A different sound usually means an air lock or a clog. A sharp or sour smell near the tanks means something in the water has gone wrong, and I check the fish and the filter before anything else.

## Schedule

This is the routine I follow. I keep it light, because a routine that is too heavy gets skipped. The tasks are arranged by how often they come up, and the order inside each group is the order I walk through the room.

**Every day**

- Look at the fish and check that they are active and feeding normally.
- Listen for the pump and confirm that water is moving through each bed.
- Glance under the raised floor near the tanks for any wet patch or drip.
- Wipe any spills from the boards so that damp does not settle in the wood.

**Every week**

- Clear the pump intake and the pre-filter of debris.
- Check the water level in each tank and top up if needed.
- Test the water and write the result in the logbook.
- Check that the lamps work and that their timers are still correct.
- Put tools back in their places and sweep the floor.

**Every month**

- Inspect the fittings and tighten any that have loosened.
- Look at the cables, plugs and sockets for damp or wear.
- Clean the grow beds where algae has built up.
- Walk under the floor and check the supports and the underside of the boards.
- Check the stock of spare parts, such as seals, fittings and tubing.

**Each season**

- In autumn, prepare for the cold: insulate exposed pipes, check the heater and test the backup for the pump.
- In winter, watch the cold end of the room closely and keep the mat in front of the bench.
- In spring, do the big clean: drain, scrub and refill what needs it, and review the lamp setup for the growing season.
- In summer, watch for warm-water problems and algae, and keep the pump intake clear more often.

**Once a year**

- Review the floor, the walls and the roof for damp, rot or gaps.
- Rebalance the load on the floor if tanks have been moved.
- Read this handbook and correct anything that has changed in the workshop.

I adjust this plan when something changes. If a new tank goes in, the daily and weekly lists grow. If a season is quiet, I shorten them. The point is to keep the north-facing workshop, with its raised floor and medium size, in the same dependable condition it has had since 2013.

## Open questions

These are the things I have not settled about the Braetind workshop. I keep them here so I stop re-deciding them every few months.

- **North light and winter temperature.** The workshop faces north, which gives even, glare-free light for bench work and reading gauges. It also means the room gets little direct sun. I still do not know how much the cold side costs me in heating during the dark months. I want to log the air temperature at bench height and at the floor for a full winter before I decide whether to add insulation to the north wall.
- **Medium size and the next tank.** The workshop is medium sized. It holds the grow beds, the sump, the fish tank and the bench, but the aisle is tight when two people are inside. I have not decided whether a second fish tank would fit without giving up the bench. The alternative is to move the bench outside and keep the whole interior for water.
- **Raised floor and the weight of water.** The floor is raised, which keeps the room off damp ground and lets air move underneath. It was a good choice for a building from 2013, but I have never checked how the floor behaves under a full tank. I want to look for sagging, soft spots, or slow moisture marks on the underside, and I want to find out who built the supports so I can ask what load they were meant for.
- **Age of the building.** The workshop was built in 2013. I am not sure which fittings are original and which were replaced. The pipework, the pump housing and the electrical box all need a note saying what they are and when they were last touched.
- **Aquaponics balance.** The area of the workshop is aquaponics, and I still have no steady rule for how many fish the beds can support. I have been guessing by eye and by how green the leaves look. A written feeding and stocking rule would be better than my memory.
- **Spill and leak routing.** If the sump overflows, I am not certain where the water goes first. I believe it runs toward the door, but the raised floor may send it somewhere less convenient. I want to test with a bucket of water and watch.
- **Power backup.** If the pump stops, the fish have only a short time before oxygen drops. I have not decided between a battery air pump and a small generator, or whether to rely on a neighbour to check in.
- **Record keeping.** I write readings on paper by the door. I would like them in one place, but I have not decided whether to type them up weekly or keep a single sheet that I photograph.

## Checklist

I use these lists when I walk into the workshop. They are in the order I do them. I do not skip steps just because the water looks fine.

### Every visit

- Look at the fish before anything else. Check that they are swimming normally and coming up to feed.
- Listen for the pump. A change in its sound usually means a blockage or a low water level.
- Check the water level in the fish tank and the sump. Top up with water that has stood for a day.
- Touch the pipework at the joints and feel for damp.
- Check the floor around the tank for wet marks. The floor is raised, so also look at the edge where it meets the wall, because water can disappear underneath.
- Glance at the grow beds for dry patches, yellow leaves, or pooled water.
- Write down the water temperature.

### Weekly

- Test the water for ammonia, nitrite, nitrate and pH, and record the results.
- Clean the pump intake screen and any pre-filter.
- Remove dead leaves from the beds and wipe the bench.
- Check the feed stock and see that it is dry and sealed.
- Look at the north windows and wall for condensation. The room faces north and stays cool, so moisture collects there first.
- Check that the air stone is still producing a steady stream of bubbles.
- Sweep the floor and check that nothing is stored in the aisle.

### Monthly

- Rinse the media in one grow bed, rotating which bed I do so they are not all disturbed together.
- Inspect the electrical box and cables for damp, corrosion, or chewed insulation.
- Check the supports under the raised floor from the outside, and look for any new gaps or soft wood.
- Test the backup air supply and make sure the battery is charged.
- Review the fish count and growth, and adjust feeding if needed.
- Look over the tools and put each back in its place.

### Each season

- Before winter, check the seals on the doors and any gaps in the north wall, and decide whether the room needs extra warmth.
- Before summer, check shading and ventilation. North light is gentle, but a medium sized room still heats up when the pump and lights run.
- Drain and clean the sump completely, using water from the tank to rinse so the bacteria are not wiped out.
- Check the whole plumbing run for brittle or discoloured sections, since the workshop dates from 2013.
- Read through these notes and update anything that has changed.

### Before leaving

- Close the valves I opened and return hoses to their hooks.
- Make sure the feeder is set or the fish have been fed.
- Check the pump is running and the water is moving.
- Turn off the bench light and shut the door properly.

## Tools

This is what I keep in the Braetind workshop and what each item is for. Everything has a fixed place, because a missing tool is a problem when the water is running.

### Testing and measuring

- **Water test kit.** For ammonia, nitrite, nitrate and pH. I keep the reagents in a closed box away from the window and check that they have not gone stale.
- **Thermometer for the tank.** A floating or clip-on type, read at every visit.
- **Second thermometer for the room.** I keep it at bench height to learn how cold the north side gets.
- **Measuring jug and small scale.** For feed, salt, and any water treatment I add.
- **Spirit level.** For checking that the beds and the bench have not shifted, which matters on a raised floor.

### Plumbing and water

- **Spare lengths of pipe and a handful of fittings.** Elbows, connectors and clamps, kept in a labelled tray.
- **Pipe cutter and a fine file.** For clean cuts that do not leave burrs.
- **Sealing tape and a tube of sealant.** For minor weeps at joints.
- **Hand pump or siphon hose.** For emptying the sump and moving water between containers.
- **Fine net and a bucket with a lid.** For catching fish gently and moving them if I must.
- **Soft brush and sponge.** Used only on the tanks and never with soap.

### Bench work

- **Screwdrivers, pliers and an adjustable spanner.** The basic set for the pump housing and the frames.
- **Small saw and a hand drill.** For adjusting the bed frames and shelves.
- **Clamps.** Two or three are enough for holding parts while I fix them.
- **Work gloves and eye protection.** I wear these when cutting or handling anything sharp.
- **Head torch.** North light fades early, and the space under the raised floor is dark.

### Power and safety

- **Residual current plug.** Everything with a mains plug near water goes through it.
- **Spare air pump and air stone.** Ready to swap in at once if the main one fails.
- **Battery air pump.** The stopgap if the power goes out.
- **Fire blanket and a small extinguisher.** Kept by the door, where I can reach them without crossing the wet area.
- **First aid kit.** Also by the door.

### Cleaning and upkeep

- **Broom, dustpan and a squeegee.** The squeegee is for moving water on the floor toward the door.
- **Cloths and a towel stack.** For quick wipes when something spills.
- **Waste bin with a lid.** For dead leaves and plant trimmings.
- **Notebook and pencil.** Readings go in here first. Pencil works on damp paper better than pen.

### How I look after the tools

I rinse anything that touches the water and dry it before it goes back. Metal tools get a light wipe of oil each season. I check the cords on the power tools for damage during the monthly walk-through. If a tool is broken, I note it in the open questions list above instead of leaving it on the bench, so that I remember to replace it.

## Ideas

These are the changes and experiments I want to try at Braetind workshop. It is a medium-sized aquaponics workshop, built in 2013, with a north orientation and a raised floor. I keep the list here so I can pick items when I have a free weekend. Each idea notes why it fits the building as it is.

### Using the north orientation

The workshop faces north, so it gets very little direct sun. That is a drawback for plants, but it is a real benefit for the working space. The room stays cool in summer and the light is even, which suits fine work such as fitting small tubing, sorting seedlings and checking fish for signs of stress.

- Add a pale, matte wall finish on the inside of the north-facing side so the weak light bounces further into the room.
- Move the fiddly bench work to the window side and keep the heavy, messy jobs toward the back.
- Use grow lamps on a timer for the seedling shelf instead of trying to fight the lack of sun with reflectors alone.
- Keep a thermometer by the window, because the cold side of the room is where the water in exposed pipes is most at risk in winter.

### Making use of the raised floor

The floor is raised, which means there is a gap underneath. This helps with damp and with drainage, and it also gives me a place to run pipes and cables. The downside is that a raised floor has a limit on how much weight it can carry, and water tanks are heavy.

- Map where the floor joists run and mark them on a simple sketch, so tanks always sit over a joist and never in the middle of a span.
- Fit a shallow drip tray or sloped liner under the main tank area so a leak goes somewhere I can see it.
- Run the return line for the pump under the floor to clear the walkway and reduce trip hazards.
- Check the underside once a season for rot, pests and condensation. A raised floor only stays dry if the air under it keeps moving.
- Consider a small access hatch in the floor near the pump so I do not have to lift boards to reach the plumbing.

### Layout of the aquaponics system

Because the workshop is medium-sized, space is useful but not unlimited. I want a layout where water moves in one clear direction and I can follow it with my eyes from the fish tank to the plant beds and back.

- Keep the fish tank low and near the entrance, so feeding and checking are quick.
- Put the grow beds on a stepped frame, so water flows by gravity where possible and the pump only has to do one lift.
- Place the biofilter between the fish tank and the beds, with enough space around it for cleaning.
- Label every valve with a short tag that says what it does, so a visitor or a tired me can shut off the right line.
- Leave one clear path through the middle of the room and never block it with crates.

### Routine and record-keeping

A system like this is mostly about habits. I tend to remember the big tasks and forget the small ones, so I want a routine written down and kept near the door.

- A daily glance: fish behavior, water level, pump sound, and any damp patches on the floor.
- A weekly check: water tests, filter rinse, and a look at plant roots.
- A monthly job: clean the pump intake, check the air stones, and wipe down the benches.
- A seasonal job: inspect the underfloor space, check the roof and gutters, and review what grew well and what did not.

I would like to keep a small paper logbook on a hook rather than only digital notes, because the workshop is wet and I do not want to handle a phone with wet hands. I can copy the useful parts into the knowledge base later.

### Things to learn or test

- Whether a second, smaller fish tank would give me a safer backup if the main system has a problem.
- Whether a few shade-tolerant crops would do better on the north side than the leafy crops I have been trying so far.
- Whether a simple vent at each end of the underfloor space would keep the air moving enough to prevent damp.
- Whether a draft strip on the door would reduce the cold air that comes in during winter.
- Whether the benches should be raised a little so I can work standing without bending.

### Safety and upkeep ideas

Water and electricity share this room, so safety deserves its own thinking. I want every socket to be well above the floor and protected, and I want the pump and lights on a circuit with a residual-current device. A small first-aid kit and a clearly marked power switch near the door would also be sensible. I should also keep a towel and a bucket in a fixed place, since I will need them eventually.

## Measurements

This section collects the fixed facts and the readings I have taken for Braetind workshop. The fixed facts do not change, so I list them first. The readings are what I check against when something seems off.

### Fixed properties

- Kind: workshop
- Area: aquaponics
- Orientation: north
- Size: medium
- Year built: 2013
- Floor: raised

### Humidity

The measured humidity of Braetind workshop is 64.44 %. This is a comfortable level for most leafy plants, but it is on the high side for tools and for the wooden parts of the building. At this level, metal can start to show surface rust if it is left bare, and any cold surface may collect condensation, especially on the north side where the walls stay cooler.

Some notes on how to read this value:

- The reading is the humidity of the air inside the room, not the underfloor space, which may differ.
- Humidity in an aquaponics room is always going to be higher than in an ordinary workshop, because the open water surfaces release moisture all day.
- The raised floor helps the room breathe, but if the underfloor air is stagnant, damp can creep up into the boards.
- If the number climbs a lot, I should check the vents, the covers on the tanks and whether the door has been left open or shut for too long.

### What I record and how

When I take a reading, I stand in the middle of the room at about waist height, away from the tanks and away from the door, and let the meter settle for a few minutes. I note the time of day and whether the lights and pump were on. A reading taken straight after watering or cleaning is not representative, so I wait.

For each session I try to write down:

- humidity in the middle of the room
- humidity near the north window
- the temperature at the same two spots
- the water temperature in the fish tank
- anything unusual, such as condensation on the glass or a damp smell

### How the properties affect the readings

The north orientation keeps the room cool and steady, which means the temperature swings less during the day. That is good for the fish, but it also means that moisture does not dry out of the room quickly. Without strong sun, the walls and the floor warm up slowly, so condensation appears first on the coldest surfaces.

The medium size is large enough for a few separate zones but small enough that moisture spreads through the whole room. A change at the tanks shows up at the benches quite soon. This is helpful, because one meter in the middle gives a fair picture.

The raised floor separates the room from the ground, so rising damp is less of a problem than it would be in a floor laid straight on the earth. Still, the year of construction, 2013, means the building has had many seasons to settle, and small gaps may have opened where boards meet walls. I should check those for drafts and moisture from time to time.

### Practical use of the numbers

I use the humidity figure as a baseline. If a later reading is far from 64.44 %, that is a sign to look for a cause rather than to worry straight away. The things I look at first are the tank covers, the ventilation, recent weather and any new leak. If the figure stays high for a long time, I will run a small fan for part of the day and open the vents at both ends of the room.

I also want to compare the readings between seasons. In winter the cold north wall may make the room feel damper than the number suggests, and in summer the cool room may feel pleasant even when the humidity is high. Keeping the readings in one place lets me see the pattern over the year and decide whether any of the ideas above are worth the effort.

### Short checklist for a measuring day

- Let the meter adjust to the room before reading it.
- Take the reading away from the water and the door.
- Write down the humidity, temperature and time.
- Compare it with the baseline of 64.44 %.
- Add a line in the logbook about anything that looks different from last time.
- Copy the result into the knowledge base when I am back at a dry desk.
