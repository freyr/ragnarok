---
type: reference
status: active
project: reference
area: aquaponics
---

# Kathses dehumidifier

## Background

The Kathses dehumidifier is a blue dehumidifier that I installed in the barn in 2025. It runs on mains power. It belongs to the aquaponics area of my setup, which is why it gets its own reference note instead of sitting in a general barn list.

The barn holds the grow beds, the plumbing manifold, the pump cabinet and a shelf of seed trays. Water moves through all of it, and the air gets damp fast, especially in the mornings and after I clean the filters. Before the dehumidifier, I had condensation on the pump cabinet door, a film of moisture on the tool wall, and some surface mould on the timber near the fish tank lid. That was the reason for buying a unit and putting it in the barn.

I chose the device mainly because it is mains powered. I did not want to deal with batteries or a solar feed in a building where the power already reaches the pumps and lights. The blue casing is easy to spot in a dim barn, which turned out to be handy when I need to find the drain hose or check the tank by torchlight.

This note is a quick reference for myself. It records what the unit is, what I need to keep near it, how I adjusted it, and what I learned after the first seasons of use.

Summary of properties:

- Kind: dehumidifier
- Area: aquaponics
- Color: blue
- Energy source: mains
- Year installed: 2025
- Location: barn

## Supplies

Everything below is kept in a labelled box on the shelf next to the unit, so I do not have to hunt for it.

- A length of drain hose, long enough to reach the floor gutter without any sag where water could sit.
- A spare filter, or at least a clean one drying while the other is in use.
- A soft brush for dusting the intake grille.
- A small bucket, in case the hose is disconnected or blocked.
- A cheap hygrometer clipped to the wall, about head height, away from the unit's own exhaust.
- A short outdoor-rated extension lead, kept off the floor and clear of splashes.
- A roll of tape and a marker for labelling filter dates.
- A notebook page taped inside the box lid for logging readings.

I also keep a plastic tray under the unit. The hose should handle all drainage, but the tray catches the odd drip when I move the unit to clean behind it.

The mains socket for the unit sits on a circuit with a residual current device. I checked that it trips properly before the first winter. Because the barn is damp by nature, I do not plug the unit into anything that is not protected, and I do not run the lead across a walkway where water gets splashed.

## Adjustment

When I first set the unit up, the humidity reading on its display did not match my wall hygrometer. The unit read a few points higher, so it ran longer than needed and the barn felt dry and dusty near the seed trays. I decided to correct the difference with an offset instead of just ignoring the display.

My calibration offset for the Kathses dehumidifier is 1.862 mm. I use it when I set the sensor position on its mounting bracket, as the sensor sits further from the intake than the factory default and I compensate with that spacing. I measured it with a ruler and a small caliper and rechecked it after a month, when it had not shifted.

Steps I follow when I readjust:

1. Switch the unit off and unplug it.
2. Remove the front grille and dust the sensor area with the brush.
3. Loosen the bracket and set the sensor spacing to the offset above.
4. Refit the grille, plug in, and run for an hour.
5. Compare the display with the wall hygrometer and write both readings in the notebook.

A typical log extract from the notebook page looks like this:

```
unit: Kathses dehumidifier (barn)
target: 60 percent
check 1: display 62, wall 61
check 2: display 60, wall 60
note: filter clean, hose clear, offset unchanged
```

If the two readings differ by more than a few points after an hour, I look at the filter first, then the hose, and only then touch the bracket again. Most of the time the filter is the cause.

## Lessons

The biggest lesson is that placement matters more than settings. When the unit sat in a corner, it dried the corner and little else. Moving it toward the middle of the barn, with free space on all sides, gave a much more even result across the grow beds and the tool wall.

Other things I learned:

- Clean the filter on a schedule, not when I remember. A clogged filter makes the unit run longer and the barn never really dries.
- Do not trust the built-in display alone. A separate hygrometer on the wall is cheap and gives me a second opinion.
- Keep the drain hose downhill all the way. One shallow dip held water and eventually caused a blockage and a damp patch.
- Close the barn door while the unit runs. It sounds obvious, but I wasted several days drying the outdoor air.
- Expect the unit to work harder after water changes and filter cleaning, and plan the heavy jobs earlier in the day so the barn can recover.
- Do not set the target too low. Plants and seed trays do not like very dry air, and the extra running time just adds to the power use.

The mould on the timber near the fish tank lid has not returned since the unit settled into a routine. The pump cabinet door stays dry, and the tool wall no longer gets that cold film in the morning.

Things I still want to try: a timer so the unit runs mostly when the barn is closed up, and a second hygrometer near the seed shelf to see whether that zone behaves differently from the rest of the room.
