---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Pesperk pond."
---

# Pesperk pond

## Observations

Pesperk pond is a pond in the aquaponics area. It sits on the north side of the site, at ground level, so I can reach it without steps or a ladder. It was built in 1993, and it is the oldest water body I keep notes on. Its size is medium: big enough to hold a steady volume of water through a warm week, small enough that I can check the whole surface in a single walk around the edge.

What I usually notice on a visit:

- The water is calmer on the north side because the structures nearby block most of the wind.
- Algae tends to collect along the shaded edge first, then spreads slowly along the rim.
- The inlet area is the cleanest part. The far corner is where debris settles.
- After heavy rain the water level rises quickly and the colour turns slightly cloudy for a day or two.
- Because the pond is at ground level, leaves and dirt wash in easily. I rake the rim more often than I would like.

I have noticed that the age of the pond shows mostly in the edges. The lining and the border have been patched a few times since 1993, and I prefer to look at them in dry weather, when the marks are easier to see.

## Tools

I keep the tools for this pond in one crate near the north gate so I do not have to hunt for them. The list is short and practical.

- A long-handled net for skimming leaves and floating debris.
- A rake for the rim and the shallow edge.
- A hygrometer for the air reading above the water.
- A water test kit for the usual checks on the pond itself.
- A notebook and a pencil, because a phone does not like wet hands.
- A bucket for collecting debris and sludge before it goes to the compost.

When I log a reading, I append a line to a plain text file. The format is the same every time, so I can search it later. Here is an example of how an entry looks, using the humidity value from the last visit:

```
site: Pesperk pond
area: aquaponics
orientation: north
check: humidity
value: 56.24 %
notes: surface calm, edge clear
```

I try to keep the fields in this order. If I add a new field, I put it at the bottom so older entries still line up with newer ones.

## Overview

Pesperk pond is a reference point for the rest of the aquaponics area. Here are its properties in one place, so I do not have to look them up elsewhere:

- Kind: pond
- Area: aquaponics
- Orientation: north
- Size: medium
- Year built: 1993
- Floor: ground level

The pond has been in place since 1993, and the layout around it has changed several times while the pond itself has stayed where it is. That makes it a good fixed marker when I describe where other things are. Facing north puts it in cooler light for much of the day, which helps keep the water temperature steadier than in the more exposed parts of the area.

Being at ground level has good and bad sides. Access is easy, and I can carry a bucket or a net straight to the edge. On the other hand, runoff, leaves and small animals can enter without any barrier. I treat the border as part of the pond's upkeep, not as an extra job.

The medium size is a useful middle ground. A smaller pond would swing quickly with the weather, and a larger one would need more tools and more time. This one I can maintain in a short session, and the readings stay meaningful from one visit to the next.

## Measurements

The main reading I record here is air humidity above the water, taken with the hygrometer at the edge of the pond. The measured humidity of Pesperk pond is 56.24 %.

A few notes on how I take the reading, so that values from different days can be compared:

- I stand on the north side, near the inlet, and hold the hygrometer about at waist height.
- I wait a few minutes before reading, so the instrument can settle.
- I avoid taking it right after rain or right after I have disturbed the water with the net.
- I write down the value in the log file straight away, using the format shown in the Tools section.

The humidity figure tells me how damp the air around the pond is, and it helps me judge whether algae growth is likely to speed up. A single reading does not mean much on its own. I look at several visits together and watch for a steady drift in one direction. If the number moves a lot between two visits, I check the weather first, because that is usually the cause, and only then look at the pond itself.

I do not record other measurements in this note. If I start tracking something new, such as water level or temperature, I will add it here under the same heading and keep the method written down next to it.
