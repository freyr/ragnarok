---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Lonturktru circulation pump."
---

# Lonturktru circulation pump handbook

## References

This section lists where I look when something about the Lonturktru circulation pump needs checking. The pump is a circulation pump in the aquaponics area of my setup. It is grey, runs on battery power, and has been installed in the greenhouse since 2022. I keep those facts at the top because I forget them when I am standing in front of the wrong tank.

**Notes in this vault**

- [[Faerkpioth level sensor log]]: my running record of water level readings. I compare it against pump behaviour whenever flow looks odd. A slow drop in the log often shows up before I notice anything at the pump.
- [[Zaethlu level sensor handbook]]: the reference for the sensor that sits near the pump intake. I read it when the log and the actual water line disagree.
- [[Kalglon Dithsel]]: the person I go to for second opinions on plumbing and pump placement. Their advice shaped where the pump sits today, so I keep the link here as a reminder to ask before I move anything.

**Physical references**

- The paper tag taped inside the greenhouse cabinet. It names the pump and shows which hose goes where.
- The photo I took of the pump after the first full season, showing the grey housing, the battery compartment, and the hose clamps in their correct order.
- The small notebook by the door, where I scribble quick observations before they get written up here.

**How I use these**

When the pump misbehaves, I read the level sensor log first, then the sensor handbook, and only then touch the hardware. Most of my past mistakes came from skipping that order. The pump is rarely the real fault. A clogged intake, a low battery, or a drifting sensor reading is far more common.

I treat this note as the single entry point. Anything I learn about the pump gets added to the sections below instead of being scattered across other notes, and the other notes link back here.

## Lessons

These are the things I learned the hard way. None of them are clever. They are just the mistakes I do not want to repeat with a battery-powered circulation pump in a humid greenhouse.

**Battery behaviour matters more than I expected.** Because the energy source is battery, flow does not fail suddenly. It weakens first. The water in the grow beds moves more slowly, the surface film builds up, and only later does the pump stop. If I see the surface go still, I check the battery before anything else.

**Humidity is the quiet enemy.** The greenhouse is warm and wet most of the year. Condensation collects around the battery compartment and the hose connections. I now wipe the grey housing dry whenever I do a round, and I keep the compartment seal clean. A damp seal was the cause of one of my worst weeks with this pump.

**Do not trust a single reading.** Early on I reacted to one odd level reading and swapped parts that were fine. Now I compare at least a few readings in [[Faerkpioth level sensor log]] before deciding anything. A single outlier is usually the sensor, not the water. The [[Zaethlu level sensor handbook]] explains how that sensor drifts, which saved me from a pointless repair.

**Hose routing affects flow more than pump settings.** Sharp bends and sagging loops cost me more flow than any adjustment. Keep hoses short, supported, and gently curved. If flow drops after I have moved something, I suspect a kink before I suspect the pump.

**Keep the intake clear.** Algae and root fragments gather at the intake. A quick look each visit prevents a long cleaning session later. I wait for the pump to be off and the battery disconnected before touching it.

**Ask early.** When I could not decide where to relocate the pump, I talked to [[Kalglon Dithsel]] instead of experimenting. It saved me a lot of lifting and water spillage. Sometimes the best move is to ask before acting.

**Write it down immediately.** If I do not record a change the same day, I forget which setting I used. The notebook by the door exists for this reason. Entries get moved into this note once the situation is settled.

## Checklist

I run through this list on every visit to the greenhouse. It is short on purpose. A long list gets skipped, and a short one gets done.

**Quick look (every visit)**

- Is the water moving in the grow bed, or is the surface still?
- Is the grey housing dry and free of condensation?
- Is the battery compartment closed with the seal sitting flat?
- Are the hoses unkinked and still clamped where they should be?
- Does the water level look right compared with the last entry in [[Faerkpioth level sensor log]]?

**Battery check**

- Look at the battery state before anything else if flow seems weaker than usual.
- Swap or recharge the battery instead of waiting for the pump to stop on its own.
- Dry the contacts before putting a battery back in.
- Note in the notebook that I changed the battery, so I can see how long each one lasts.

**Intake and flow**

- Disconnect the battery before touching the intake.
- Clear algae, root bits, and debris from the intake.
- Rinse the intake screen in tank water, not tap water, so I do not shock anything living in the system.
- Reconnect the battery and watch the flow for a short while to confirm it settles.

**Sensor cross-check**

- Compare the physical water line with the sensor reading.
- If they disagree, open the [[Zaethlu level sensor handbook]] and follow its troubleshooting steps.
- Do not adjust the pump until I know which one is wrong.

**Before leaving**

- Close the cabinet.
- Make sure nothing is resting against the pump housing.
- Write any odd observation in the notebook.
- If I changed anything, add a line to this note the same day.

## Background

The Lonturktru is a circulation pump. In my system it works in the aquaponics area, moving water between the fish tank and the grow beds so that nutrients reach the plants and the water stays oxygenated. It is grey, which is useful in practice because the housing blends in with the cabinet and does not attract much algae on the outside, though I still wipe it down.

The pump runs on battery. That was a deliberate choice, not a convenience. The greenhouse sits some distance from the house, and running mains power out there was more trouble than I wanted. A battery-powered pump means I have to keep an eye on charge, but it also means the pump is not tied to a cable that could be damaged by moisture or by me moving things around.

I installed it in 2022. Since then it has been in the same greenhouse, running through several growing seasons. In that time I have learned its habits: it starts a little slowly when the battery is low, it is quiet enough that I notice only when it stops, and it tolerates the humidity well as long as the seal is kept clean.

The location in the greenhouse matters. It sits low and close to the tank, which keeps the intake submerged and shortens the hose run. That placement came after some discussion with [[Kalglon Dithsel]], who pointed out that a longer hose run would cost me flow and make the battery work harder. I moved it once after that conversation and have left it alone since.

The pump does not work in isolation. Water level is the main thing that affects it, so I pair it with a level sensor and record readings in [[Faerkpioth level sensor log]]. The sensor's quirks are described in the [[Zaethlu level sensor handbook]]. Together those two notes and this one form the small cluster I rely on for keeping the water moving.

In summary, the properties I keep coming back to are these: it is a circulation pump, used in aquaponics, grey in color, powered by battery, installed in 2022, and located in the greenhouse.

## Safety

Water, batteries, and a damp greenhouse are not a comfortable combination, so I take a few precautions seriously.

**Electrical and battery**

- Always disconnect the battery before touching the intake, the impeller area, or the hose connections. A pump that restarts unexpectedly while my hand is inside is a real injury risk.
- Keep the battery compartment dry. Moisture on the contacts can cause poor connections, heat, or corrosion.
- Do not charge or swap batteries with wet hands or while standing in standing water.
- If a battery looks swollen, smells odd, or feels unusually hot, stop using it and move it somewhere safe and non-flammable. Do not leave it in the greenhouse.
- Store spare batteries away from direct sun and away from the damp areas of the greenhouse.

**Water and fish**

- A sudden stop in circulation can reduce oxygen for the fish. If the pump stops, treat it as urgent, not as something to deal with later.
- Check the water level in [[Faerkpioth level sensor log]] against reality when the pump behaves strangely. Running a pump with the intake exposed can damage it and starve the system of flow.
- Rinse cleaning tools in tank water or leave them dry. Soap and chemicals have no place near the fish.

**Working in the greenhouse**

- Wet floors are slippery. I keep walkways clear and wipe up spills when I see them.
- Do not lift heavy tanks or the pump awkwardly. If something needs moving, I ask for help, and I think of [[Kalglon Dithsel]] as someone who has helped before.
- Keep hoses routed so I do not trip over them.
- Wear gloves when cleaning the intake. Algae and root debris can hide sharp bits.

**When something seems wrong**

If the pump is hot, noisy, or leaking near the battery, I switch it off, disconnect the battery, and leave it until I can inspect it calmly. I would rather lose a few hours of circulation than risk a short circuit. If the sensor reading seems to be the problem, I consult the [[Zaethlu level sensor handbook]] before assuming the pump is faulty.

## Maintenance

The Lonturktru circulation pump is a grey circulation pump that runs on battery power. It has sat in the greenhouse since 2022, and it moves water through the aquaponics loop. The loop is damp, warm and full of fish waste, so most of the upkeep is about keeping things clean and keeping the battery healthy. This section is the practical routine. The next section covers what the pump is.

### Before touching anything

- Switch the pump off at its own switch first. Do not rely on the battery being flat.
- Disconnect the battery lead before opening the housing. Water and a live battery in the same place is the main danger with this unit.
- Dry my hands and the work surface. The greenhouse floor is often wet, so I work on the potting bench.
- Keep a bucket of tank water nearby. Rinsing parts in tap water can upset the fish and the bacteria, so I rinse in water from the system.

### Cleaning the intake and impeller

The intake screen clogs first. Fish feed fragments, root hairs from the grow beds and a slimy film all collect on it. When the flow drops, the screen is the first thing I check.

1. Lift the pump out of the sump by its handle, not by the cable.
2. Pull off the intake screen and brush it under tank water with a soft brush.
3. Open the front cover and look at the impeller. Remove any hair-like roots wrapped around the shaft.
4. Spin the impeller by hand. It should turn freely with no grinding. A gritty feel usually means sand or a small snail shell is inside.
5. Wipe the inside of the housing with a damp cloth. I avoid soap, detergent and any cleaner with fragrance, because residue ends up in the fish tank.
6. Refit the cover and check the seal sits flat before closing it.

### Seals and the housing

The rubber seal around the cover is the part most likely to fail slowly. I look at it every time the cover is off. If it is flattened, cracked or sticky, I replace it rather than hoping. A weeping seal lets moisture reach the battery compartment, and that is how I would lose the pump.

The grey housing is plastic and goes chalky if scrubbed hard. A soft cloth is enough. Mineral scale from the greenhouse water shows as a pale crust, and I remove it with a cloth soaked in diluted vinegar, then rinse well in tank water before the pump goes back in.

### Battery care

Because the pump is battery powered, the battery is the single most important thing to look after.

- Keep the terminals clean and dry. A light wipe with a dry cloth is normally enough.
- Do not leave a flat battery in the pump. A deeply drained battery loses capacity quickly.
- Charge it in the house, not in the greenhouse. Humidity and charging do not mix well.
- Let the battery cool after a long run before charging.
- Swap in the spare battery when the first one starts to fade, then charge the faded one straight away.
- If a battery swells, leaks or smells odd, stop using it and take it out of the greenhouse at once.

I write the date of each battery swap on a strip of tape on the battery lid. That tells me at a glance which battery has been running longest.

### Signs something is wrong

| Sign | Likely cause | First thing to try |
| --- | --- | --- |
| Weak flow | Clogged intake screen | Clean the screen |
| Rattling noise | Debris near the impeller | Open the cover and clear it |
| Runs then stops | Battery low or loose lead | Check charge and connection |
| Water in the housing | Worn seal | Replace the seal, dry everything |
| Pump warm to touch | Blocked flow or tired battery | Stop it, clear the intake, check battery |
| No sound at all | Switch off or dead battery | Check switch, then swap battery |

## Overview

The Lonturktru circulation pump is the device that keeps water moving in my aquaponics setup. Here are its properties, written out so I do not have to search for them.

- **Kind:** circulation pump
- **Area:** aquaponics
- **Color:** grey
- **Energy source:** battery
- **Year installed:** 2022
- **Location:** greenhouse

### What it does

In an aquaponics system, fish water has to travel to the plant beds and come back clean. The pump is what makes that happen. It takes water from the sump and pushes it up to the grow beds, where it drains back by gravity. Without the pump the water stagnates, the fish run short of oxygen and the plants stop getting nutrients. So it is not a part I can ignore for long.

### Why battery power

The battery is unusual for this job. Most circulation pumps run from the mains. I chose a battery unit because the greenhouse had no safe socket near the sump when I installed it in 2022. The battery also gives some protection against a power cut, since the pump keeps running if the house goes dark. The price of that is that I have to look after the battery, which is why so much of the maintenance section is about it.

### Where it sits

The pump lives in the greenhouse, in the sump at the low end of the loop. The grey body is easy to spot against the darker tank liner, which helps when I am checking it. The cable runs along the edge of the tank and is tied up off the floor so it does not sit in puddles.

### How I think about it

I treat the pump as a small, steady worker. It does not need clever settings. It needs a clean intake, a sound seal and a charged battery. If those three are right, it mostly looks after itself. When I have a problem with the system, I check the pump early because everything else depends on the flow.

## Schedule

This is the routine I try to follow. I keep it loose, because the greenhouse gets busier in some seasons than others, but the order of priorities stays the same.

### Every day

- Listen to the pump when I enter the greenhouse. A steady hum is good. Any rattle or silence gets investigated straight away.
- Look at the water return in the grow beds. A good flow means the pump is fine.
- Glance at the fish. If they crowd at the surface, check the flow first.

### Every week

- Check the intake screen and wipe off any film.
- Look at the battery charge and swap batteries if needed.
- Check that the cable is still tied up and out of any water on the floor.
- Feel the pump body for unusual heat after it has been running.

### Every month

- Lift the pump out and open the cover.
- Clear the impeller and check it spins freely.
- Inspect the seal for cracks or flattening.
- Clean the battery terminals and the lead.
- Remove mineral crust from the housing if any has built up.

### Every season

- Do a full strip-down clean in tank water.
- Replace the seal if there is any doubt about it.
- Test how long a fully charged battery lasts under normal load, and compare with last season.
- Check the sump for sludge, since a dirty sump makes the pump work harder.

### Once a year

- Review the battery. If the run time has dropped a lot, plan a replacement.
- Think about whether the pump is still the right size for the loop, especially if I have added grow beds.
- Re-tie or replace any cable ties that have gone brittle in the greenhouse heat.

### Notes on timing

Summer is the hard time. The greenhouse is hot, algae grows faster, and the intake screen clogs more often. I move the weekly check to twice a week in the warmest part of the year. In winter the water is cooler and the film builds up more slowly, so the routine relaxes a little. The battery, though, may lose capacity faster in cold weather, so I watch the run time more closely then.

## History

### Installation

I put the Lonturktru circulation pump into the greenhouse in 2022. At that point the aquaponics system was fairly new and I was still learning how much flow the beds needed. The pump went into the sump, and I tied the cable along the tank edge. The first weeks were mostly adjustment, as I watched the water level in the beds and the way the return drained.

### The first year

The first year taught me the main lessons about this unit.

- The intake screen clogs far faster than I expected, so the weekly check came out of that.
- The battery runs well but does not last forever, so I bought a spare and began swapping.
- A damp morning showed me that the seal needs attention, because a little moisture had reached the edge of the cover.

### Changes since then

Over the years I have made a few small changes rather than anything big.

- I added a strip of tape on each battery lid to record swaps.
- I moved the charging station into the house after worrying about humidity.
- I raised the cable higher on the tank edge so it stays dry.
- I started cleaning with tank water only, after a rinse in tap water seemed to upset the fish for a day.

### Problems that have come up

- A few times the flow dropped because roots had wrapped around the impeller shaft.
- Once the pump stopped because the battery lead had worked loose, which was an easy fix but a scare at the time.
- A seal went soft and had to be replaced. Since then I inspect it every month.

### Overall record

The pump has done its job since 2022 with no major failure. Most of the trouble came from small things I could have caught sooner, not from the pump itself. That is why the routine above is built around frequent, short checks rather than occasional big overhauls.

## Open questions

These are things I have not settled. I am writing them down so I remember to look into them.

- **Battery lifespan.** How long should the battery really last in daily use? I notice the run time slowly shrinking, but I do not have clear records to say how fast. I should log run time at the same point each season.
- **Mains backup.** Would it be sensible to add a mains option now that a safe socket might be possible near the sump? It would remove the charging chore, but I would lose the protection against a power cut.
- **Flow rate.** Is the pump the right size for the loop as it is today? I have added growing space since 2022, and I have never measured the flow properly.
- **Seal material.** Is there a longer-lasting seal that is safe for fish? I would like to replace it less often, but I do not want to risk leaching anything into the water.
- **Heat in summer.** Does the greenhouse heat shorten the life of the battery or the plastic housing? The grey body looks fine, but I have not compared it with any shaded part.
- **Spare unit.** Should I keep a second pump on the shelf? If this one failed in a hot spell, the fish would be at risk within hours, so the answer is probably yes, but I have not decided which model.
- **Cleaning method.** Is vinegar the best way to deal with scale, or is there something gentler for the housing? So far it works, but the surface has gone slightly dull.
- **Monitoring.** Would a simple flow alarm be worth fitting, so I find out about a stopped pump without having to walk into the greenhouse?

## Costs

The Lonturktru circulation pump is a grey, battery-powered circulation pump that has run in the greenhouse since 2022. I don't keep exact prices in this note, because they go stale. I do keep a record of what kinds of money the pump has cost me, so I can judge whether it was a good choice for the aquaponics system.

The biggest cost was the purchase itself in 2022. Battery power made the pump more expensive than a mains pump of similar flow would have been. In return I got a pump that doesn't need a cable run through a wet greenhouse, and that was the reason I picked it.

The running cost is mostly batteries. The pump uses no mains electricity, so the greenhouse electricity bill didn't change. Every battery pack wears out, though, and replacing packs is the one cost that keeps coming back. I treat it as a consumable, like fish feed.

Smaller costs I have noticed over the years:

- Replacement tubing, because the original hose clouds with algae and gets stiff.
- A few spare clamps and seals, which I buy in small bundles.
- Cleaning materials, which cost almost nothing but need regular restocking.
- My time. A pump that needs a battery swap is a pump I must remember to visit, and this is a real cost in a busy week.

Costs I avoided: no electrician, no outdoor socket, no waterproof junction box. If I had chosen a mains pump, those would have added up. Costs I would watch for in future are a failed impeller and a battery pack that no longer holds charge. If either happens close together, I will compare repair against replacing the whole pump.

My rule of thumb is to review all of this once a year, in the quiet season, and write one line in this section about what changed.

## Supplies

These are the things I keep close to the pump so a battery swap or a cleaning takes minutes, not an afternoon.

**Power**
- Charged spare battery packs, labelled and stored indoors, away from the damp of the greenhouse.
- A charger kept in the house, not in the greenhouse.
- A small tin for the battery contacts, holding a cloth and a little protective grease.

**Water side**
- Spare lengths of tubing in the diameter the pump uses.
- A few hose clamps, plus spare sealing rings.
- Plain mesh for the intake, in case the original tears.
- A bucket kept just for pump work, never used for anything else.

**Cleaning**
- A soft brush for the impeller housing.
- Clean rags that leave no fluff.
- Mild vinegar solution for mineral scale. I rinse everything thoroughly afterward, since the fish and plants share this water.
- Gloves, because the tank water is slimy.

**Records**
- A waterproof notebook clipped near the tank, where I jot the date of every battery change.
- A roll of tape and a marker for labelling.

Things I do not keep near the pump: strong chemicals, soaps, anything scented. In an aquaponics system the fish, the bacteria and the plants all depend on the same water, so anything that touches the pump can end up in the loop. I stay with plain water, a brush and a little vinegar.

I check this list at the start of each season. If a spare is used, I replace it straight away, so the shelf is never empty when something fails. The spare battery packs are the item I replace first, since a dead pump means water stops moving through the grow beds and the fish tank.

## Tools

The pump is simple, so the tool list is short. I keep everything in one small box in the greenhouse.

**Basic hand tools**
- A small flat screwdriver and a small cross screwdriver, for the casing and the battery cover.
- Pliers, for clamps that have been tightened for a long time.
- A pair of scissors or a sharp knife to cut tubing cleanly.

**Cleaning tools**
- A soft brush with a narrow head, which reaches into the impeller chamber.
- An old toothbrush for the corners.
- A bucket and a jug, for rinsing parts with tank water or clean water.

**Checking tools**
- A basic multimeter, to test whether a battery pack still holds a proper charge. I check packs this way before I blame the pump.
- A bright torch, because the greenhouse gets dark in winter and the pump sits low.
- A measuring jug and a watch, to time how long the pump takes to fill a known volume. I use this as a rough flow check.

**Working habits**
1. Switch the pump off and remove the battery before touching anything.
2. Lay the parts on a clean cloth in the order I take them off.
3. Photograph the assembly before I take it apart. A phone photo has saved me more than once.
4. Rinse, reassemble, reconnect and watch the water move for a few minutes before leaving.

The grey casing hides dirt well, so I wipe it down and look for cracks, not just for grime. I also keep the tools dry and stored away from the tank. Damp tools rust, and rust flakes in an aquaponics system are the last thing I want near the fish.

## Ideas

These are things I might try with the pump. None are done yet, and some may never be worth the effort.

**Power**
- Add a small solar panel to top up the battery during the day. The greenhouse gets plenty of light, so this is the most obvious upgrade. I would need a way to stop overcharging.
- Rotate two battery packs on a fixed schedule, so one is always charging while the other works.
- Put a simple reminder in my phone for battery day, instead of relying on memory.

**Flow**
- Test a short timer cycle, so the pump runs in bursts. This could stretch battery life without hurting the plants, as long as the fish get enough oxygen.
- Try a slightly different outlet position in the grow bed to spread the water more evenly.
- Add a coarse pre-filter on the intake so the impeller stays cleaner for longer.

**Monitoring**
- Fit a cheap float or flow indicator so I can see at a glance that water is moving, even from the greenhouse door.
- Keep a simple chart of battery life per pack, to see when a pack is aging.
- Note the water temperature on cold mornings, to learn whether cold shortens battery life.

**Layout**
- Move the pump slightly so it is easier to reach without kneeling.
- Make a small shelf above water level for a spare battery during swaps.
- Paint a visible mark on the tank where the water level should sit.

I will pick one idea per season and write the result here. The solar top-up and the flow indicator are first, because they address the two things that worry me most: a flat battery and a silent failure.

## Setup

This section records how the Lonturktru circulation pump is set up, so I can rebuild it if I ever have to.

**Summary of the pump**
- Kind: circulation pump
- Area: aquaponics
- Color: grey
- Energy source: battery
- Year installed: 2022
- Location: greenhouse

**Position**
The pump sits low in the greenhouse, close to the fish tank, so the water it moves has a short path. It stays below the water line of the tank, which means it never has to draw air. The grey casing blends in with the other equipment, which helps me notice when something looks out of place.

**Water path**
Water leaves the tank through the pump and travels along the tubing to the grow beds. It then drains back to the tank by gravity. The pump is the only moving part in the loop, so if the water stops, I look at the pump first.

**Power**
The pump runs from a battery pack, so there is no mains cable in the damp part of the greenhouse. The pack sits in a dry spot and the contacts are kept clean and lightly greased. I swap the pack on a regular schedule and write the date in the notebook.

**Startup routine**
1. Check the tank level.
2. Check the tubing for kinks and the intake for debris.
3. Fit a charged battery pack.
4. Watch the water flow for a few minutes.
5. Look for leaks at every joint.

**Shutdown routine**
1. Remove the battery pack first.
2. Rinse the intake mesh.
3. Wipe the casing and dry the area around it.

Once a year I take the pump apart, clean the impeller chamber, and replace any worn tubing or seals. After that I run the startup routine again and note the date here.

## Problems

This section lists the faults I have seen on the Lonturktru circulation pump, the grey battery-powered unit I installed in the greenhouse in 2022. It moves water through the aquaponics loop, so any fault shows up quickly in the fish tank and in the grow beds. I write down what I saw, what caused it, and what fixed it.

### Flow drops slowly over a few weeks

This is the most common problem. The pump still runs and still makes its normal sound, but the water coming out of the grow bed outlet is thinner than it was. Nothing is broken. Fish waste and algae build up in the intake and in the impeller chamber.

What I do:

- Switch the pump off and disconnect the battery lead before touching anything.
- Lift the pump out of the water and rinse the outside under a tap.
- Remove the intake cover and clear out the slime with a soft brush. A toothbrush is about the right size.
- Look at the impeller. If a strand of root or a piece of plant matter is wrapped around the shaft, pull it free with tweezers.
- Spin the impeller by hand. It should turn easily and stop without grinding.

If the flow is still weak after cleaning, I check the hose for kinks and then the battery. A tired battery gives a weaker pump long before it gives a dead one.

### Pump stops after a short run

When the pump starts and then dies within an hour or so, the battery is almost always the cause. Because this pump runs on battery, the cold greenhouse nights hurt it. A battery that held a full day in summer may last only half a day in winter.

Things I have tried, in the order I try them:

1. Charge the battery fully and time how long the pump runs. Write the result down so I can compare later.
2. Check the battery terminals for white or green crust. Clean with a dry cloth and a little contact cleaner.
3. Move the battery to a shelf above the floor, where it stays a bit warmer. The cold floor of the greenhouse takes capacity out of it.
4. If the run time keeps getting shorter even with clean contacts, replace the battery.

I keep a spare charged battery in the house. Swapping takes only a minute and the fish never notice.

### Pump runs but no water moves

This happens when air is trapped in the pump body. It is common after I clean the unit or after the water level in the tank has dropped.

- Check that the water level covers the pump fully. Even a small gap at the top lets it draw air.
- Tilt the pump under the water and let the bubbles escape from the outlet.
- Shake it gently while it is submerged, then start it again.
- If it still sucks air, check the seal where the outlet pipe meets the housing. A loose pipe lets air in even when the water level is fine.

I once spent an hour on this before noticing the tank had dropped just enough to expose the top edge of the intake. Always check the water level first.

### Strange noise or vibration

A healthy pump hums quietly. A rattle, buzz, or rough grinding means something is wrong.

- A rattle usually means a small stone or a bit of gravel from the grow bed has got into the impeller chamber. Open the housing and remove it.
- A high buzz often means the pump is running dry or nearly dry. Stop it at once and refill the tank.
- A low grinding sound points to a worn bearing or shaft. This one does not get better by itself. I plan a replacement when I hear it.
- A pump that vibrates against the tank wall will make a loud knocking. I put a piece of foam under it, and that stopped the noise.

### Water leaking into the housing

If I find water inside the battery compartment, I stop using the pump straight away. Water and a battery do not mix, and corrosion can spread quickly.

What I check:

- The main housing seal for cracks, flattening, or dirt caught under it.
- The cable entry point, where the lead passes through the casing.
- The latch or screws that close the compartment. Over time they can loosen from vibration.

I dry everything with a cloth and leave the parts open overnight in a dry room. Then I reseat the seal, add a thin film of silicone grease, and close it again. If there are signs of corrosion on the contacts, I replace the affected parts rather than hope they last.

### Algae and scale on the grey casing

The grey casing shows green film and white scale very clearly. This is mostly cosmetic, but scale can also build up around the outlet and narrow the opening. Every few months I soak the pump in a weak vinegar solution for a short while, then rinse it well in clean water. I never use strong cleaners, because anything left on the pump goes straight into the fish tank.

### Fish and plant side effects

Sometimes the symptoms of a pump problem show up elsewhere first.

- Fish gather near the surface and breathe fast. This can mean the water is not moving enough and oxygen is low. Check the pump at once.
- Grow bed plants wilt at the tips even though the roots look fine. Low flow may mean the bed is not flooding as it should.
- The water smells sour. Stagnant zones have formed because circulation is weak.

When I see any of these, the pump is the first thing I look at, before I test the water or blame the feed.

### Quick checklist when something is wrong

1. Is the water level high enough to cover the pump?
2. Is the battery charged and are the contacts clean?
3. Is the intake clear?
4. Does the impeller spin freely?
5. Is there air trapped inside?
6. Are the hose and outlet clear of kinks and blockages?
7. Is there any water in the battery compartment?

Nine times out of ten the answer is in the first four questions.

## Parts

This section covers the parts of the Lonturktru circulation pump, what each one does, and what I replace and how often. The unit is a grey circulation pump in my greenhouse aquaponics setup, running on battery since I installed it in 2022.

The part number of the Lonturktru circulation pump is DE-9197-S. I quote this number when I look for spares or ask someone about compatible items, so I keep it here where I can find it.

### Main body and housing

The housing is the grey outer shell. It holds the motor, the impeller chamber, and the battery compartment. It is made of a tough plastic that has stood up well to humidity and sunlight in the greenhouse. The surface is smooth, which helps when I scrub off algae. Apart from the seal, I have never needed to replace anything in the housing itself.

### Impeller

The impeller is the small spinning part that pushes the water. It sits in a chamber at the front of the pump. It is the part that gets fouled most often, so I check it every time I clean the intake. A good impeller has straight, undamaged blades and spins freely. If a blade is chipped or bent, the pump loses flow and gets noisy. I would replace the whole impeller instead of trying to repair it.

### Shaft and bearing

The impeller turns on a thin shaft held in a bearing. Normally the bearing needs no attention. Grit is the enemy, because it wears the bearing and makes a grinding sound. I rinse the pump thoroughly after any work in the grow beds so that gravel does not get in. If the shaft wobbles when I hold the impeller, the bearing is worn and needs replacing.

### Intake cover

The intake cover is a grille that keeps out fish, snails, roots, and large debris. The slots are fairly narrow, which is good for protection but means they clog easily. I clean it with a soft brush. If the cover cracks, I replace it, because a damaged grille lets debris through into the impeller chamber.

### Outlet and pipe connector

The outlet is where the hose or pipe attaches. The connector must fit snugly, or the pump will leak at the joint and lose pressure. I use a hose clamp for extra security. Scale tends to collect at this point, so I look inside it when I do my regular soak in diluted vinegar.

### Battery and compartment

The battery is the energy source for this pump. It sits in its own sealed compartment inside the housing. Notes on how I treat it:

- I charge it fully before it goes back into service.
- I keep the contacts clean and dry.
- I keep one spare battery charged and ready.
- I expect to replace the battery sooner in a cold greenhouse than in a warm room.
- I never leave a flat battery in the pump for a long time, because that shortens its life.

The battery is the part that wears out first. Of all the spares, it is the one I make sure I always have.

### Seals and gaskets

The main seal keeps water out of the battery compartment. It is a rubber ring that sits in a groove around the lid. Over time it can flatten or harden. I inspect it whenever I open the compartment and wipe it with a clean cloth. A very thin layer of silicone grease helps it seat well. If the seal looks cracked, stretched, or permanently squashed, I replace it right away. This is a cheap part that protects an expensive one.

### Cable and lead

The lead connects the battery to the motor and passes through the casing at a sealed entry point. I check the insulation for cracks, especially where it bends. I also look at the connector for corrosion. A damaged lead is a reason to stop using the pump, because it may let water reach the electrical parts.

### Mounting and accessories

I keep the pump on a small foam pad at the bottom of the tank so it does not rattle against the walls. A few extras help in daily use:

- A spare hose clamp.
- A soft brush for the intake.
- Tweezers for removing roots from the impeller.
- A small tub of silicone grease.
- A cloth kept only for the pump.

### What I keep in stock

For this pump I try to hold the following spares at all times:

- One extra battery, fully charged.
- One spare seal.
- One spare impeller.
- A spare intake cover.

Those four items cover almost every repair I have needed since 2022. Anything more serious, such as a worn bearing or a damaged motor, I would handle by quoting the part number DE-9197-S to a supplier and asking what they can offer.

### Replacement rhythm

My rough rhythm is simple. I clean the intake and impeller whenever the flow drops, which is every few weeks. I check the seal every time I open the compartment. I replace the battery when run time falls noticeably, and I inspect the bearing and shaft once a year. I write each change in my notes so I can see how the pump ages from one season to the next.
