---
type: reference
status: active
project: reference
area: aquaponics
---

# Drogond pond

## Tools

Drogond pond is a large pond in the aquaponics area. It was built in 2022, faces west, and has a raised floor. These are the basics I check before I start any job there.

For routine work I keep a short kit near the pond so I don't have to walk back to the shed:

- A long-handled net for lifting out leaves, algae mats and any dead plant material from the surface.
- A small bucket for scooping debris and for moving water when I need to top up a nearby grow bed.
- A soft brush for scrubbing the edges and the inside of the pipe openings.
- A test kit for checking the water. I check it on the same day each week so the readings are easy to compare.
- A notebook, kept in a dry box, where I write down what I did and anything that looked odd.

Because the pond is large, I do the work in a fixed order: surface first, then edges, then the water test, then notes. That keeps me from missing a step. The west orientation means the late afternoon sun hits the water directly, so I try to do the cleaning in the morning, when the water is cooler and the algae is easier to see.

Since the floor is raised, I find it easier to work from the side than to lean over the rim. I keep my tools within reach of one spot rather than spreading them around.

## Equipment

The one installed device at Drogond pond is a Kubupur solar charger. It keeps the pond's small electrical parts powered without needing a cable run from the main building, which was useful because the pond sits some way out in the aquaponics area.

Because the pond faces west, the charger gets good light in the afternoon. I still wipe the panel surface clean whenever I do the weekly round, since dust and pollen build up and cut how much it collects.

My routine check on the charger is simple:

- Look at the panel for dirt, leaves or cracks.
- Check that the connections are tight and dry.
- Make sure the device is still fixed firmly in place.

If the pond equipment stops working, I check the charger first, because a power problem is the most likely cause. I note any change in how it behaves in the notebook so I can spot patterns over the seasons.
