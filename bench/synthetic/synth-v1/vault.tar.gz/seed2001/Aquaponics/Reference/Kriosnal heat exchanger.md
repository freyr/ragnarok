---
type: reference
status: active
project: reference
area: aquaponics
---

# Kriosnal heat exchanger

## Lessons

The Kriosnal heat exchanger is a red heat exchanger that I installed in the yard in 2024. It belongs to the aquaponics setup, and it runs on a battery. Most of what I have learned about it comes from the first two seasons of use, and I am writing it down so I do not repeat the same mistakes.

The first lesson is about the battery. Because the unit runs on a battery and not on mains power, it is easy to forget about until the water temperature drifts. I now treat the battery as the first thing to check whenever the fish tank water behaves oddly. A weak battery does not stop the unit all at once. It slows the circulation a little, and the effect looks like a slow change in the weather, not like a fault.

The second lesson is about the yard location. The exchanger sits outside, so leaves, dust and spiders all find it. A red housing gets warm in direct sun, and that warmth fools me when I read the surface by hand. I should not judge the heat transfer by touching the casing. I read the water temperatures at the inlet and outlet instead.

The third lesson is to change one thing at a time. Early on I adjusted the flow and the position together, and then I could not tell which change had helped. Now I make one change, wait a full day, and write down the result.

The fourth lesson is that small mechanical settings matter more than I expected. The calibration offset in particular made a visible difference, and I describe it in the Adjustment section.

## Schedule

I keep a simple routine for the device. It is not fancy, but it works because it is short enough that I actually do it.

- Every day: look at the exchanger when I feed the fish. Check that the water is moving and that nothing is blocking the intake.
- Every week: wipe the red housing, clear debris from around the base, and check the battery level.
- Every month: open the connections and look for mineral crust or green film. Rinse the intake screen.
- Every season: recheck the calibration offset, check the mounting in the yard, and look at the cables for sun damage.
- Once a year: do a full clean, charge the battery fully, and decide whether the battery needs replacing.

If the weather turns very hot or very cold, I move the weekly checks to every two or three days. In a cold snap I also look at whether the outdoor pipework is protected.

## Ideas

Some things I would like to try, in rough order of how useful I think they would be.

1. Add a small shade over the exchanger so the red housing does not take the full afternoon sun in the yard.
2. Put a waterproof label on the unit listing the weekly checks, so I do not need to open this note while standing outside.
3. Keep a spare battery charged and ready, so a swap takes minutes and the fish system is never left without circulation for long.
4. Add a simple logbook page with columns for date, inlet temperature, outlet temperature and battery state. A habit of writing three numbers is better than trying to remember.
5. Build a small cover for the base that keeps leaves out but still lets air move around the unit.
6. Think about a small solar charger for the battery, since the unit sits in the yard where there is plenty of light.

None of these are urgent. I will pick one per season and see whether it helps.

## Background

The Kriosnal heat exchanger is a device in the aquaponics area of my notes. Its kind is heat exchanger, which means its job is to move heat between two bodies of water without mixing them. In my system it helps keep the fish tank in a comfortable range, so that the fish and the plants both do well.

Here are its properties in one place:

- Kind: heat exchanger
- Area: aquaponics
- Color: red
- Energy source: battery
- Year installed: 2024
- Location: yard

I installed it in 2024. Before that, I managed water temperature by hand, adding or removing water and moving the tank cover. That worked in mild weather and failed in the extremes. The exchanger was meant to smooth out those extremes without needing me to be there all the time.

The battery supply was a deliberate choice. The yard is some distance from the nearest socket, and I did not want a cable running across the ground where I walk with buckets. The trade-off is that I have to look after the battery, which is the main reason the schedule above exists.

The red color is only cosmetic, but it does make the unit easy to spot among the green of the plants, and I can see from across the yard whether anything has fallen on it.

## Adjustment

The one setting I track carefully is the calibration offset. For the Kriosnal heat exchanger it is 1.821 mm. I set it when I installed the unit and I have kept it there since, after checking it each season.

What I do when I check it:

1. Switch the unit off and make sure the water is not moving through it.
2. Look at the adjustment point and confirm it still sits at the offset above. If it has crept, I put it back.
3. Switch the unit on again and watch the inlet and outlet temperatures for a while.
4. Write down what I saw, even if nothing changed.

Some practical notes. The offset can shift slightly if the unit is knocked or if the mounting settles in the yard soil after heavy rain. If the temperature difference between inlet and outlet looks smaller than usual and the battery is fine, the offset is the next thing I check. I do not change it by guesswork. If I think it needs to move, I change it a little, wait a day, and compare, in keeping with the lesson about one change at a time.

I also check that the mounting is level, because a tilted unit can mimic a bad offset. It is much quicker to fix the mounting than to chase the setting.

## References

These are the places I look when I need to remember something about the unit. They are my own notes and physical items, not outside sources.

- The paper tag that came with the exchanger, which I keep in the box in the shed.
- My logbook of inlet and outlet temperatures, kept alongside the aquaponics notes.
- Photos I took of the unit on installation day in 2024, showing how the connections were arranged.
- My general notes on the aquaponics system, including the layout of the tank, the grow beds and the pipework.
- My notes on battery care, which cover charging habits and when I replaced batteries in other devices.

When I change something about the unit, I add a line to the logbook first and update this note afterwards. That way the logbook is the full record and this note stays a summary.

## Open questions

- How long will the battery last before it needs replacing? I have a rough feeling but no real data, and the logbook should help answer this.
- Does the red housing make a measurable difference to how much heat the unit picks up in direct sun, or is the effect too small to matter?
- Would a shade over the unit change the temperature results enough to be worth building?
- Is the calibration offset still the best value, or did I settle on it too early? I have not tested other values in a controlled way.
- Would a solar charger keep the battery topped up through the winter, when the yard gets little light?
- Should I move the unit closer to the tank to shorten the pipework, or does the current position in the yard work well enough?

I will update this list as I find answers, and move the answers up into Lessons.
