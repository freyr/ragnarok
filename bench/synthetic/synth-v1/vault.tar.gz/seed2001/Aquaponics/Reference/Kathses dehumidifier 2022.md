---
type: reference
status: archived
project: reference
area: aquaponics
---

# Kathses dehumidifier 2022

## Costs

This section records what the dehumidifier cost me in running and upkeep, as I understood it in 2022. I have not written any prices here. The figures live in my [[Lorzera shed log]], and I do not trust my memory for them.

- Running cost: it draws from the mains, so it shows up on the normal electricity bill. It has no separate meter.
- Upkeep cost: only a little time. I empty and rinse the water tank and wipe the filter.
- Hidden cost: the barn is damp, so the unit runs for long stretches in wet weather.

The table below sums up where the money and effort go.

| Item | Where it goes | Note |
|---|---|---|
| Electricity | Mains supply | Heavier use in wet months |
| Filter care | My time | Wipe and dry, no spare parts needed |
| Tank emptying | My time | Daily when the air is very damp |
| Placement | Barn floor space | Keep clear of splashes |

## Overview

This note is archived. It records the state in 2022, and later notes replace its values. If a newer note disagrees with this one, the newer note wins.

The Kathses dehumidifier is a dehumidifier used for the aquaponics work. Its properties are:

- Kind: dehumidifier
- Area: aquaponics
- Color: blue
- Energy source: mains
- Year installed: 2025
- Location: barn

It stands in the barn, near the grow area, where moisture from the tanks and pipes lingers in the air. The blue casing is easy to spot among the grey tools and crates, so I rarely lose track of it when I am moving things around.

I run it from a normal mains socket. I do not use an extension reel, because the barn floor gets wet and I would rather keep every connection off the ground.

The barn also holds the workshop gear. Dust from cutting, such as work on the [[Turen band saw]], can clog the filter, so I try not to run the saw and the dehumidifier in the same hour. If I do, I check the filter afterwards.

For the wider layout of the barn and what sits where, see the [[Bandsol Diorkdon plan]]. For the planting side and how humidity affects the plants, see the [[Kupath greenhouse plan]].

## Adjustment

The unit has a small correction I set so that its humidity reading matches the reference meter I keep in the barn. Without it the display reads a bit off, and the unit switches on and off at the wrong times.

- Calibration offset of Kathses dehumidifier: 0.676 mm

The offset is written in millimetres because that is how I recorded it on the label, even though it is really a reading correction. I leave the label as it is so the note matches what is in the barn.

Steps I follow when I check the adjustment:

1. Let the unit run for a while so the air around it settles.
2. Put the reference meter beside it, at the same height.
3. Compare the two readings and look at the offset.
4. Change the offset only if the gap is clearly there on more than one day.

I keep a short entry in the [[Lorzera shed log]] each time I touch the setting, so I can see later what changed and why. Since this note is archived, any newer offset belongs in a later note, and I should not edit the value above.
