---
type: reference
status: active
project: reference
area: aquaponics
---

# Baethdris solar charger

## Tools

The Baethdris solar charger is a red solar charger for the aquaponics setup. It has been installed in the loft since 2020 and runs on solar energy only. It keeps the batteries topped up for the pumps and sensors downstairs.

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | aquaponics |
| Color | red |
| Energy source | solar |
| Year installed | 2020 |
| Location | loft |

Things I use when working on it:

- Small screwdriver set for the terminal covers
- Soft cloth for wiping dust off the panel
- Multimeter for checking battery output

The charger feeds the same battery bank that backs up the pump described in [[Lardu circulation pump notes]]. When I cut new mounting boards in the loft, I follow [[Brisbi band saw handbook]].

## Software

The firmware version of the Baethdris solar charger is v2.42.707. I have not updated it since the install, because it works fine.

- Check the status light on the charger after any power cut
- Note any odd behavior in [[Baefir Liosstis notes]]
- Compare winter charging results with what I logged in [[Pesperk pond 2024]]

If the charger ever acts up, I will check the firmware first and then the wiring.
