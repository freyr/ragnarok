---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Kubupur solar charger."
---

# Kubupur solar charger

The Kubupur solar charger is a grey solar charger installed at the pond in 2014 for the aquaponics setup. Despite the name, its energy source is mains. It does not run off a panel, and I keep forgetting that when I plan around it. This note is my working reference for it.

## Schedule

The charger has no timer of its own. I keep to a simple routine and write down anything that changes it.

- Weekly: look at the grey housing for water spray, algae film and insects. Wipe it down if needed.
- Monthly: check the mains lead along the whole run to the pond edge, including the point where it passes the pump bracket.
- Each season: unplug it, open the cover, look for damp and corrosion, and close it up again with the seal seated properly.
- Once a year: compare the power draw against the figure in the Measurements section and note any drift.

The seasonal check lines up with the other pond jobs. When I drain and clean the grow beds I do the charger the same day, so the pond area is only disturbed once. The general order of work is laid out in [[Nizi workshop plan]], and I follow it for anything that needs tools.

The charger was installed in 2014, so it has been in place for a long time. I treat the yearly check as non-negotiable because of that age.

## Costs

I do not keep exact prices in this note. The cost pattern is easy to describe, though.

- Purchase: paid once back in 2014. I no longer have a reliable figure, so I leave it out.
- Running cost: it draws from the mains, so it shows up on the normal electricity bill. It is small next to the pumps, but it runs all the time, so it adds up.
- Upkeep: seals, cable ties and the odd replacement lead. These are cheap, but I buy them in a batch so I do not have to stop work.
- Replacement: if the unit fails, I would not buy another one of the same kind without thinking. A plain mains charger would do the same job for less money, and a real solar setup would suit the pond better.

The main hidden cost is my time. A failure at the pond is awkward to reach, and I lose half a day each time. That is why I prefer routine checks to emergency repairs.

## Risks

The pond is the worst place for a mains device, so the risks are mostly about water and electricity.

1. **Electric shock.** The energy source is mains, and the unit sits at the pond. I always unplug it before touching the housing or anything in the water nearby.
2. **Water ingress.** Spray, rain and condensation can get in through the cover seal. Damp inside the grey housing is the most likely cause of failure.
3. **Cable damage.** The lead runs through a spot where it gets stepped on and tugged. A worn sheath is a real hazard.
4. **Wrong assumption about the source.** The name says solar, so a visitor might expect it to work without a mains connection, or might not realise it is live. I keep a note on the plug.
5. **Heat.** The housing is grey and sits in sun for much of the day. Heat build-up shortens the life of the internals.
6. **Interference with other kit.** Nearby sensors can pick up noise. I had this once with level sensing, and the fix is described in [[Zaethlu level sensor handbook]].

Humidity around the pond is a general problem for everything I keep there. I compared notes on moisture control in [[Kathses dehumidifier 2022]], although a dehumidifier is not practical outdoors. It was useful mostly for the indoor stores where spare parts live.

## Measurements

The only figure I trust is the measured power draw, taken with a plug-in meter while the charger was running normally. The rest of the table records the fixed properties so everything is in one place.

| Property | Value |
|---|---|
| Kind | solar charger |
| Area | aquaponics |
| Color | grey |
| Energy source | mains |
| Year installed | 2014 |
| Location | pond |
| Measured power draw | 282.31 W |

The measured power draw of Kubupur solar charger is 282.31 W. That is higher than I expected for something that is meant to be a small charger. I read it as a sign that the unit is not very efficient, or that some of the load is going to something I have not identified.

When I repeat the measurement I use the same meter, the same socket and the same conditions, so the numbers can be compared. I also write down whether the pond pump was running at the time, since that affects what else is on the circuit.

## Problems

These are the faults I have seen or suspect.

- **Name versus reality.** It is called a solar charger but runs from the mains. This confuses my own planning notes every time I reread them, so I now spell it out at the top.
- **High draw.** The measured figure is larger than I would like. I have not found the cause. Ideas so far: an old internal converter, a standby load, or a fault that wastes power as heat.
- **Damp.** I have found moisture under the cover more than once. Re-seating the seal helps for a while.
- **Awkward access.** The pond edge is uneven and often wet, which makes maintenance slow and a little unsafe.
- **Unclear history.** I never wrote down the original settings from 2014, so I cannot tell whether the current behaviour matches how it started out.

Some of the earlier trials with similar equipment, including how kit behaved under cold and damp, are written up in [[Fundzioth barn tests]]. Those results are the closest thing I have to a baseline for this sort of device. For the layout of the outdoor area and where cables run, see [[Sithglith yard]].

## Open questions

- Why is the draw so high for a charger of this kind, and does it change when nothing is connected to it?
- Should the unit be replaced with a plain mains charger, or moved to a real solar supply at the pond?
- Is there a safer place for it, further from the water and out of the sun, with the lead protected along its length?
- Would a switch or timer on the supply cut the running cost without harming whatever it is charging?
- What were the original settings from 2014, and does anything in [[Methreth Bentroputh notes]] mention them?
- Could the repair and testing be done in the [[Dunpirbae workshop]] on the bench, so I stop working in the wet?

Until I have answers, the routine in the Schedule section stays as it is, and I unplug the unit before doing anything near it.
