---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Zaethlu level sensor."
---

# Zaethlu level sensor handbook

## Overview

The Zaethlu level sensor is the device I use to watch the water height in my aquaponics setup. This handbook is my own reference for it. I wrote it so I do not have to rediscover the same facts every season. The handbook is long and split into several parts. This first part gives the plain description of the device, what I have noticed while living with it, and what I still do not know.

The sensor is a level sensor, and that is all it does. It does not measure temperature, acidity, or flow. It reports how high the water stands in the tank it watches, and I read that number and decide whether to top up, drain, or leave things alone. In an aquaponics system the water level matters more than people expect. Fish need enough depth to stay calm, and the pumps need enough water to avoid running dry. The plant beds depend on a steady cycle of filling and draining. A level sensor that I trust saves me from checking the tank by eye several times a day.

The sensor is green. I mention the colour because it is how I tell it apart from the other bits of kit on the shelf and along the wall. The casing was green when it arrived, and it is still green now, though the surface has dulled. When I say "the green sensor" in my other notes, this is the device I mean.

It runs on solar power. A small panel feeds it, and it has no mains lead and no battery that I ever swap by hand. This was the main reason I chose it. The place where it sits is awkward to reach with a cable, and I did not want a device that needed a regular errand just to keep it alive. Solar suits the job because the sensor draws very little and the barn gets decent light through the day.

I installed it in 2017. It has therefore been in service for a good many years, through several winters and a few rebuilds of the plumbing around it. It sits in the barn, close to the main tank, where the aquaponics system lives.

### Properties at a glance

The table lists every fixed property of the device in one place. If another note disagrees with this table, the table wins.

| Property | Value |
| --- | --- |
| Name | Zaethlu level sensor |
| Kind | level sensor |
| Area | aquaponics |
| Color | green |
| Energy source | solar |
| Year installed | 2017 |
| Location | barn |

### How I think about the device

I treat the sensor as one small part of a larger loop. Water leaves the fish tank, passes through the plant beds, and returns. Evaporation and the plants take water out of the loop, so the level slowly falls between top-ups. The sensor shows that slow fall. It also shows sudden drops, which usually mean a leak or a stuck valve. I care more about those sudden changes than about the exact number, because a sudden change is the thing I cannot spot easily by walking past.

I keep this handbook practical. It does not try to explain how level sensing works in theory. It records what I did, what I saw, and what I would do again.

## Observations

These are the things I have noticed from years of living with the device. Some are firm. Others are impressions that I have not checked properly, and I say so where that is the case.

### Power and light

Because the sensor is solar, its behaviour follows the light in the barn. On bright days it is steady and reports without trouble. In the dull months the supply is thinner, and I have seen it go quiet for stretches. It has always come back once the light improved, so I treat the quiet spells as a sign of low power and not as a fault. The panel needs to stay clean. A film of dust or a cobweb across the panel makes a noticeable difference, and a quick wipe is often all it takes to bring the sensor back to normal.

### Position and the barn

The barn is a mixed environment. It is damp near the tank and dry further away, and the temperature swings more than it would indoors. The sensor sits close to the water, so it sees the damp more than most things in the barn. The green casing has held up well against that. I have not seen corrosion on the body, though I would not claim the same for every fitting nearby. Condensation on cold mornings is the thing I watch for. It seems harmless so far.

### Readings in daily use

- The readings are smooth when the water is still and jumpy when the pump has just started. I wait a little after the pump switches on before I trust a number.
- A slow, steady fall over several days matches what I expect from evaporation and plant uptake. I top up when the fall reaches the mark I have set for myself.
- A fast fall in a short time has always meant something physical, such as a loose fitting or a valve left open. The sensor was right each time.
- A reading that does not move at all for a long period makes me suspicious. Twice that has meant the sensor itself was stuck, and once it meant the panel was covered.
- Readings after a full drain and refill settle back to my usual range within a short while, which tells me the sensor holds its reference well.

### Habits that help

I check the panel whenever I am in the barn for another reason. I do not move the sensor between jobs, because the readings only mean something if its position stays the same. I keep a plain note of the water height when I top up, so that I can compare the sensor against a real measurement. That habit has caught drift before it caused a problem.

### Things that have not been a problem

The sensor has not needed recalibration at any point that I recall, apart from the first setup after installation in 2017. It has not been disturbed by the fish. It has not been affected by algae on the nearby surfaces, though I keep that area reasonably clean regardless. The solar supply has never failed outright. It has only dipped.

### What I would do the same way

If I were installing it again, I would still choose the barn, close to the main tank, and I would still choose a solar supply. I would put the panel somewhere easier to reach for cleaning. That is my only real complaint about the original layout.

## Open questions

These are the things I have not settled. I list them so that later parts of this handbook, or later me, can come back and answer them.

- How much does the thin winter light really affect the sensor? I have only a loose impression that the quiet spells line up with the dullest weeks. I have never kept a proper record that sets the quiet periods beside the weather.
- Is the sensor drifting slowly over the years? My top-up notes suggest the readings still match the real water height, but I have not compared them in a careful, regular way since the early years after 2017.
- How long will the green casing last in the damp near the tank? It looks sound now, but I do not know how much longer it will stay that way, and I do not have a plan for replacing it.
- Would a second sensor at a different spot in the system be worth having? One sensor tells me about one tank. If the beds and the tank ever disagree about the level, I would not know.
- Could I add a simple warning for a sudden fall? At the moment I notice fast drops only when I look at the readings. A signal that reached me sooner might save water and stress for the fish.
- Is there a better place for the panel? A cleaner, brighter spot could remove most of the low-power trouble, but I have not yet tried moving it.

I will answer these as I gather evidence, and I will record each answer in the later parts of this handbook.

## Maintenance

The Zaethlu level sensor is a green solar-powered level sensor that has hung in the barn since 2017. It is part of the aquaponics system, and it has survived this long because I look after it on a fixed routine. Most of the work is cleaning and checking. I almost never replace anything.

### What goes wrong most often

Almost every problem comes from one of three things: algae film on the probe, dust on the small solar panel, or a loose cable gland where the cable enters the housing. The barn is humid and the fish tank sits close by, so the housing gets a thin wet film that dries into a crust. Wiping it off early costs me a minute. Ignoring it for a season costs me an afternoon.

### Routine

I keep the routine short so I actually do it. The cadence below is what I follow, and I adjust it only when something looks off.

| Task | How often | Notes |
|---|---|---|
| Wipe the green housing with a damp cloth | Every month | Removes crust before it spreads to the seals |
| Clean the solar panel | Every month | Soft cloth only, no scouring pads |
| Rinse the probe in tank water | Every season | Never use soap, because the fish and plants notice |
| Check the cable gland and cable | Every season | Look for cracks, pulled strands and damp |
| Compare the reading with a ruler | Twice a year | Catches slow drift early |
| Inspect the mounting bracket | Once a year | Tighten the screws, check for rust |

### Cleaning the probe

Cleaning the probe is the most delicate job. I switch the sensor off first, then lift it out slowly so it does not knock against the tank wall. I rinse it in a bucket of water taken from the tank, and I use a soft brush for any green film. Plain tap water is fine for the housing, but I keep it away from the probe tip because the chlorine can upset the biology in the system. After cleaning I let the probe drip dry for a few minutes before I put it back at the same depth.

### Power and the solar panel

The energy source is solar, so power problems nearly always mean light problems. The barn has one bright window, and in winter the sun barely reaches the sensor. When the readings start to stutter in the dark months, I do not assume the sensor is broken. I check whether the panel is dusty or shaded, and I look at whether someone stacked crates in front of the window. A clean panel in direct light fixes most of these issues.

If the sensor loses power for several days in a row, it comes back by itself once the panel charges again. I note the gap in my log so I do not mistake it for a real change in the water level.

### Signs it needs attention

- The reading jumps up and down while the water is calm.
- The reading stays flat even after I add or remove water.
- The housing feels damp or smells musty inside.
- The cable looks stiff, cracked or chewed.
- The panel is clean but power still fails in good light.

When I see any of these, I go through the routine in the table from the top before I suspect a deeper fault. If the problem survives a full cleaning and a cable check, I assume the fault is inside and I stop poking at it.

### Calibration check

Twice a year I do a plain sanity check. I hold a ruler against the tank wall, read the real water height, and compare it with what the sensor reports. I do not need great precision. I just want to know that the two agree within a small margin. If the gap grows between two checks, I write it down and clean the probe again. If it still grows, I treat it as drift and adjust the offset in the setup, which I describe further down.

## Ideas

These are things I might do with the sensor over time. None of them is urgent, and some will probably never happen. I keep them here so I do not forget them.

### Improvements to the hardware

- Add a small shade hood over the panel in summer, so the barn heat does not bake the housing.
- Fit a second bracket so the sensor cannot swing when someone bumps the tank.
- Replace the cable gland with a better sealed one, since that is the weakest point on the whole unit.
- Paint a small mark on the tank wall at the normal water height so I can check by eye.

### Improvements to the routine

- Print a short checklist and tape it inside the barn door, next to the feed bin.
- Keep a spare cloth and a small brush in a labeled tin next to the tank, so cleaning does not need a search.
- Write the date of each cleaning on a card, so I can see at a glance how long it has been.
- Photograph the sensor after each seasonal clean, to spot slow wear on the green housing.

### Bigger ideas

One idea is to add a second level sensor on the grow bed side of the aquaponics loop. Then I could compare the two tanks and notice a leak or a blocked pipe faster. Another is a simple alarm, such as a light or buzzer in the barn, that triggers when the level drops below a safe line. The fish are the real stake here, so a low-water warning is the most useful addition I can think of.

I also want to try a small backup power source, such as a rechargeable cell that carries the sensor through the dark weeks. The solar energy source works well for most of the year, but winter gaps in the data annoy me. I would need to check that the extra cell fits inside the housing before I buy anything.

### Things I decided against

I considered moving the sensor outside the barn for better light, but the weather would be harder on it than the humidity. I also thought about wiring it to mains power, and I dropped that because the solar setup is the reason the install was so simple in 2017. Keeping it solar keeps it independent.

## Setup

This section records how the sensor is set up, so I can rebuild it if I ever have to. It lists the basic properties first and then the practical details.

### Properties at a glance

- Name: Zaethlu level sensor
- Kind: level sensor
- Area: aquaponics
- Color: green
- Energy source: solar
- Year installed: 2017
- Location: barn

### Where it sits

The sensor lives in the barn, close to the aquaponics tank. The green housing is mounted on a bracket above the water, and the probe hangs down into the tank at a fixed depth. I chose the spot because it is near the window, which gives the solar panel enough light, and because I can reach it without leaning over the water. The cable runs along the wall and is held by small clips so it cannot dangle into the tank.

### Installation steps as I did them in 2017

1. Pick a wall position near the window where the panel gets the most light.
2. Fix the bracket firmly to the wall and tighten every screw.
3. Mount the green housing on the bracket and point the panel toward the window.
4. Lower the probe into the tank until it sits at the depth I want, then fix the cable so it cannot slip.
5. Seal the cable gland carefully so no moisture reaches the inside of the housing.
6. Let the panel charge in daylight, then switch the sensor on.
7. Compare the first reading with a ruler held against the tank wall.
8. Adjust the offset until the sensor and the ruler agree.

### Notes on the layout

The probe must never touch the tank wall, the pump intake or the plant roots. Any of these can give false readings, because they disturb the water around the tip. I keep a clear gap on every side. The fish are fed from the other end of the tank, so the splashing there does not reach the probe.

The housing faces the window, but not directly into the strongest afternoon sun. Too much heat in summer makes the inside of the housing uncomfortable for the electronics, which is why a shade hood is on my idea list.

### Settings I keep

I do not change many settings. The important one is the offset, which I use to line up the sensor with the real water height. I write the chosen offset in my log after every adjustment, together with the reason. This matters more than it sounds, because after a year I never remember why I picked it. The reading interval I leave at the default, since the water level in an aquaponics tank changes slowly and frequent readings would only use more solar energy.

### If I have to rebuild it

If the unit fails completely, I can follow the steps above with a replacement. The location in the barn, the bracket position and the probe depth all stay the same, so the new sensor reads the same way as the old one. The only thing I need to redo is the offset check against the ruler. After that, the routine in the Maintenance section applies again from the start.

## Tools

The Zaethlu level sensor is a green, solar-powered level sensor. It has hung in the barn since 2017 and watches the water level in the aquaponics system. Most jobs on it are small, and the tools fit in one shallow box that I keep on the shelf by the barn door. Everything in the box is there because I needed it at least once.

### What I keep in the box

- A soft brush, for dust on the solar cell and the housing.
- A microfiber cloth, slightly damp, for the green casing and the sensing face.
- A small flat screwdriver, for the terminal cover and the mounting bracket.
- A small cross-head screwdriver, for the bracket screws.
- A multimeter, for checking the battery and the solar cell output.
- A headlamp, because the corner of the barn where the sensor hangs is dim.
- A plastic ruler and a waterproof marker, for checking the reading against the real water level.
- A stepladder, kept folded beside the box.
- Nitrile gloves, since the tank water is not something I want on my hands.

### How I use them

The most useful check is the plain one. I put the ruler into the tank, read the real depth, and compare it with what the sensor reports. If the two agree, I leave everything alone. If they drift apart, I clean the sensing face first, because a film of algae or mineral scale causes most of the error. Only after cleaning do I look at wiring or power.

The multimeter comes out when the sensor goes quiet. Because the energy source is solar, a quiet sensor usually means the cell is shaded or dirty, or the stored charge has run low after a run of dark days. I measure the cell in daylight, then the battery, and I write both readings in my log. I do not write them here, since they change with the season.

### Quick reference table

| Property | Value |
|---|---|
| Device | Zaethlu level sensor |
| Kind | level sensor |
| Area | aquaponics |
| Color | green |
| Energy source | solar |
| Year installed | 2017 |
| Location | barn |

I keep this table because I sometimes forget which detail is which when I am standing on the ladder with a screwdriver in my teeth.

### Habits that save time

I always turn the sensor off, or cover the cell, before I touch the terminals. I take a photo of the wiring before I loosen anything. I put screws in the lid of the box, not in my pocket. I wipe the tools dry after use, because barn air is damp and the aquaponics tanks add to it.

I do not use solvents on the casing. Plain water and a cloth are enough, and harsher products have dulled the green finish on other devices I have owned. A dull finish is only cosmetic, but it also holds dirt more easily.

## History

I installed the Zaethlu level sensor in 2017. The barn was already the place where the aquaponics system lived, and I wanted a way to know the water level without walking over and looking into the tank every time. Mains power was the awkward part. The nearest socket was far from the tank, and running a cable across a wet floor did not appeal to me. A solar sensor solved that, and the barn has a bright wall that gets sun for much of the day.

### The early years

The first season was mostly learning where to hang it. My first spot was too low, and splashes from the return pipe left marks on the sensing face. I moved it higher and a little to the side, and the readings settled. The green casing was a small practical bonus: it is easy to spot against the grey wall, so I do not knock it when I carry buckets.

In the first winter I learned that the solar cell needs a clear view. A stack of crates built up in front of the window and the sensor started to lose power. Moving the crates fixed that completely. Since then I have kept the space in front of the window clear, and I made a note on the shelf so I would not forget.

### Changes over time

Over the years I have changed a few things, none of them large:

- I moved the sensor once, as described above, to get away from splashes.
- I added a short strip of tape around the terminal cover to keep out damp.
- I started cleaning the sensing face on a regular schedule, not only when readings looked wrong.
- I began writing down test readings against the ruler, so I could see slow drift.
- I replaced the mounting screws with ones that resist rust, after the originals started to stain the bracket.

### What the log shows

Looking back through my notes, the pattern is steady. The sensor has been reliable, and nearly every problem traced back to something simple: dirt, shade, or a loose connection. Real faults inside the unit have been rare. That is the main reason I still trust it after so many years in a damp building.

There was one stretch where the readings jumped around for several days. I suspected the electronics, but the cause turned out to be a spider web across the sensing face. It was a good reminder to look before I take anything apart.

### Where it stands now

The Zaethlu level sensor still hangs in the barn, still green, still running on solar power, and still serving the aquaponics setup. I treat it as a long-term fixture and keep the maintenance light but regular. If I ever replace it, I would want the same arrangement: no mains cable, a bright mounting spot, and a casing I can see from across the room.

## Supplies

Supplies for this sensor are cheap and boring, which is how I like it. I keep a small stock so that a routine fix does not turn into a trip to buy something. Most of the items are not specific to the Zaethlu level sensor at all.

### Consumables

- Clean cloths, several, because they get dirty and I do not want to reuse a gritty one on the sensing face.
- Clean water in a small bottle, for wiping scale and algae.
- Mild soap, a very small amount, for stubborn film on the casing.
- Waterproof tape, for the terminal cover and any cable that picks up damp.
- Spare rust-resistant screws, in a labeled pot, matched to the bracket.
- Cable ties, for keeping the wiring neat and off the wet floor.
- Silicone grease, a thin smear on the terminal cover seal, which keeps it flexible.

### Power-related items

Because the energy source is solar, the power side matters more than it would on a mains device. I keep a spare rechargeable battery of the type the sensor uses, charged and stored indoors, since a battery left in a cold barn ages faster. I also keep a soft cloth just for the solar cell so that I never wipe it with something that has touched tank water.

If the cell is shaded, no supply helps. The fix is to move whatever blocks the light. I mention it here because I once spent an afternoon looking for a replacement part when the real answer was a pile of crates.

### Supply checklist by task

| Task | What I need |
|---|---|
| Clean the sensing face | cloth, clean water, soft brush |
| Clean the solar cell | dry cloth, soft brush |
| Reseal the terminal cover | waterproof tape, silicone grease |
| Check the reading | plastic ruler, marker, notebook |
| Replace the battery | spare battery, small screwdriver |
| Tidy the wiring | cable ties, headlamp |

### Storage

I keep all of this in one plastic tub next to the tool box, on a shelf above floor level so that a spilled bucket cannot reach it. The tub has a lid, and I put a small packet of drying agent inside to fight the barn damp. Every so often I open it and check that nothing has gone stiff, rusty, or flat.

### Restocking rule

My rule is simple: when I use the last of something, I write it on the shelf note straight away. I buy the item the next time I am in town. That way I never discover an empty pot while standing on the ladder. For the Zaethlu level sensor in the barn, which has run since 2017, this small habit has done more for reliability than any single piece of equipment.

## Problems

The Zaethlu level sensor is a level sensor in the aquaponics area. It is green, runs on solar power, and has hung in the barn since 2017. Most of its problems come from those facts: a barn is damp and dusty, the sensor depends on daylight, and the water it watches is full of fish waste and algae.

### Problems I have actually seen

- **Drifting readings after a run of grey days.** The solar cell is small, and the barn windows face the wrong way for winter light. When the battery sags, the readings wander before the sensor stops reporting altogether. I treat a wandering reading as a power problem first, not a calibration problem.
- **Film on the probe.** Algae and a thin slime build up on the part that touches the water. The sensor then reports a level that is a little too high, because the film holds water against the probe after the level has dropped.
- **Condensation inside the housing.** The barn gets humid when the grow beds are busy. A little moisture gets in around the cable gland and shows up as fogging on the inside of the cover.
- **Dust on the solar cell.** Barn dust, mostly from feed and bedding, settles on the panel. A dusty panel looks fine to the eye but charges noticeably less.
- **Loose mounting.** The bracket has worked slightly loose over the years. A tilted sensor reads a different level from a straight one, so a bump to the bracket can look like a leak.
- **False alarms when the pump starts.** The water surface ripples when the pump kicks in, and the sensor sometimes catches a wave and reports a spike. It settles within a minute.

### Quick diagnosis table

| Symptom | Most likely cause | First thing to try |
|---|---|---|
| Readings wander, then stop | Low battery after dull weather | Clean the panel, move the sensor to better light if needed |
| Level reads too high | Slime on the probe | Wipe the probe with a soft cloth and clean water |
| Fogged cover | Moisture in the housing | Open it on a dry day, let it air, check the gland |
| Sudden spike that fades | Pump ripple | Wait and check again; do not adjust anything |
| Level looks wrong after a knock | Tilted bracket | Check that it hangs straight and tighten it |
| No data at all | Dead battery or cable fault | Check the panel first, then the cable |

### What not to do

- Do not use strong cleaners on the probe. The fish and the plants share this water, and anything left behind ends up in the system.
- Do not recalibrate in the middle of a problem. First fix the power, the film and the mounting, then judge whether the readings are still off.
- Do not trust one odd reading. Look at a few in a row before acting.

### A rule of thumb

If the sensor is wrong in a steady way, the cause is usually physical: slime, a tilt, or a dirty panel. If it is wrong in a jumpy way, the cause is usually water movement or power. Sorting the problem into steady or jumpy saves a lot of guessing.

## Schedule

The sensor is solar-powered, so there is no battery swap on a timetable. The schedule is about keeping the panel clear, the probe clean and the housing dry. I keep the rhythm simple so I actually do it.

### Routine

- **Every week:** Look at the reading against the water line in the tank. A quick glance is enough. Wipe the panel with a dry cloth if dust is visible.
- **Every two weeks:** Wipe the probe with a soft cloth dipped in clean tank water. Check that the bracket has not moved.
- **Every month:** Look at the inside of the cover for fog. Check the cable and the gland for wear or cracks.
- **Every season:** Check the light on the panel. Trim or move anything that now casts shade, such as hanging plants or stacked crates. Do a full check of the readings against a ruler held in the water.
- **Once a year:** Take the whole sensor down, clean everything, let it dry fully, and refit it. I do this in the dry part of the year, when the barn is least humid.

### Summary table

| Task | How often | Time it takes |
|---|---|---|
| Glance at reading versus water line | Weekly | A minute |
| Wipe the panel | Weekly, if dusty | A minute |
| Wipe the probe | Every two weeks | A few minutes |
| Check the bracket | Every two weeks | A minute |
| Check the housing for fog | Monthly | A few minutes |
| Check the cable and gland | Monthly | A few minutes |
| Compare with a ruler | Each season | Ten minutes |
| Full clean and refit | Yearly | Under an hour |

### Adjusting the schedule

In winter I look at the panel more often, because light is the limit. In the humid months I check the housing more often. After any heavy cleaning of the tank or beds, I check the probe the same day, since stirred-up waste coats it quickly.

If a visit finds nothing wrong three times in a row, I stretch that task a little. If it finds something, I shorten it. The schedule is a starting point, not a rule.

### Notes for the day I do the full clean

1. Turn off nothing else; the sensor can simply be lifted down.
2. Wipe the panel, the housing and the probe separately.
3. Leave the housing open to air before closing it.
4. Refit the sensor straight and tighten the bracket.
5. Compare the reading with a ruler in the water and write down any difference in my log.

## Background

The Zaethlu level sensor is a green level sensor in the aquaponics area. It has been installed in the barn since 2017 and runs on solar power. These are its properties in one place:

| Property | Value |
|---|---|
| Kind | level sensor |
| Area | aquaponics |
| Color | green |
| Energy source | solar |
| Year installed | 2017 |
| Location | barn |

### Why it is there

In an aquaponics setup the water level matters a great deal. Fish need enough water to stay healthy, the pump needs water to avoid running dry, and the grow beds rely on the cycle of filling and draining. A level sensor gives early warning when evaporation, a leak or a blocked line begins to change the level. Catching it early is much easier than rescuing a stressed tank.

### Why solar and why the barn

The barn is away from the house, and running mains cable to the sensor would have been awkward. Solar power avoided that. The sensor needs very little energy, so a small panel is enough in most weather. The weakness is a run of dull days, which is why so many entries in the problems section come back to light.

The barn is a good place to keep the system because it is sheltered from wind and frost, and it is close to the tanks and beds. The cost is humidity and dust, which are the other main sources of trouble.

### How I think about it

I treat the sensor as a helper and not as the last word. A reading is useful when it agrees with what I can see. When it disagrees, I walk over and look at the water. Over the years, the habit of checking the sensor against a ruler has told me more about how the system behaves than the sensor alone ever did.

### Things worth remembering

- The green color makes it easy to spot against the barn wall, which helps when I am checking the bracket.
- Because it is solar, its health follows the light. A sensor that is fine in summer may struggle in winter.
- Age matters. It has been in place since 2017, so seals, cable and bracket are older than the sensor's reputation suggests. I inspect those parts more than the electronics.
- Most faults I have seen were physical and cheap to fix: cleaning, drying, tightening.

### Lessons so far

1. Keep the panel clean and unshaded.
2. Keep the probe free of film.
3. Keep the housing dry and the bracket firm.
4. Compare with a ruler now and then.
5. Write down what changed, because memory is not reliable across seasons.

These notes are meant to be read when something looks wrong, so I have kept them short and ordered by what I check first.

## Checklist

This is the routine I run on the Zaethlu level sensor. It is a green level sensor, powered by solar energy, installed in 2017 and mounted in the barn. It serves the aquaponics system, so every check ties back to keeping the water level in the grow tanks and the fish tank honest. I go through the list in order and stop to fix anything that looks wrong before moving on.

### Before each visit

- Check the weather. If there has been a long stretch of cloud or heavy rain, expect the solar cell to be low and the readings to be late or missing.
- Bring a soft cloth, a small bucket of clean water, a flashlight, and the notebook where I log the readings.
- Note the water level by eye against the tank marks before touching the sensor, so I have a reference that does not depend on the device.

### At the sensor in the barn

- Look at the green housing for cracks, swelling, or condensation on the inside of the cover.
- Wipe dust and feathers off the solar cell. Barn dust builds up quickly and cuts the charge.
- Confirm the solar cell still faces the light that reaches the barn wall. Stacked crates or hanging tools sometimes block it.
- Check that the probe hangs free and is not touching the tank wall, a pipe, or a plant root.
- Wipe any algae or mineral film off the probe with the damp cloth. Never scrape it.
- Check the cable and its clips. Rodents like cables, and a nibbled sheath is an early warning.
- Compare the sensor reading with the marks on the tank. If the two disagree by more than a small margin, write it down and recalibrate.

### After the visit

- Log the date, the sensor reading, my own reading, and anything I cleaned or changed.
- Watch the next few readings to make sure the sensor reports on schedule again.
- If I moved anything near the sensor, record where it is now so I can put it back.

### Seasonal items

- Spring: clean the housing thoroughly after the winter dust and check the seals.
- Summer: look for heat damage on the housing, since the barn gets hot under the roof.
- Autumn: clear leaves and cobwebs from around the solar cell before the short days.
- Winter: check that the charge holds through the dark weeks and that no ice has formed around the probe.

## Risks

The main risks come from the combination of a solar supply, a barn setting, and a water-based system. The sensor has been in place since 2017, so age is a factor in nearly every item here. The table below lists the ones I have actually seen or think are likely, with what I do about each.

| Risk | What it looks like | Likelihood | What I do |
|---|---|---|---|
| Low solar charge | Missing or late readings after dull weather | High in winter | Clean the cell, move obstructions, keep a manual check habit |
| Probe fouling | Readings drift slowly upward or downward | High | Wipe the probe on a regular schedule |
| Moisture in the housing | Fog or droplets under the cover | Medium | Dry it out, replace the seal, move it away from spray |
| Cable damage | Dropouts, erratic jumps in the reading | Medium | Inspect the sheath, protect it with a tube |
| Heat in the barn | Warped housing, unstable readings | Medium in summer | Shade the unit, improve airflow |
| Age of the unit | Slow loss of accuracy since 2017 | Rising | Compare against the tank marks often |
| False sense of safety | I stop looking at the tanks myself | Medium | Keep the manual check in the routine |

### The risks that matter most

The worst outcome is a wrong reading that I trust. If the sensor says the tank is full while the level is dropping, the pump can run dry and the fish and plants suffer fast. If it says the tank is low when it is full, I might add water and cause an overflow onto the barn floor. Both errors are more likely than a clean failure, because a dead sensor is obvious and a drifting one is not.

Solar power adds a second problem. A sensor that runs on a small cell has little reserve. A few grey days can leave it silent, and silence can look like stable water. I treat a missing reading as a warning, never as good news.

### Smaller risks

- Dust and straw in the barn can cover the solar cell within a couple of weeks.
- Condensation forms when warm humid air from the tanks meets a cooler housing at night.
- Pests chew cables and nest behind the unit.
- Mineral scale from hard water crusts on the probe and changes how it reads.
- Knocks from moving feed, tools, or equipment can shift the probe position without anyone noticing.

### Habits that reduce the risk

- Keep a written baseline of what a normal day of readings looks like, so a flat line or a strange jump stands out.
- Never rely on this one device alone for anything that could harm the animals.
- Keep the tank marks clean and readable, because they are my independent check.
- Fix small problems the same day. A loose clip or a smeared cell is cheap to fix now and annoying later.

## Costs

I keep costs here as categories and effort, not exact amounts, since prices change and I do not want stale figures in a reference note. The Zaethlu level sensor has no fuel or mains bill, because its energy source is solar. That is the biggest saving of owning it in the barn, where running a power line to the tank area would have been awkward.

### Where the money and time go

- **Purchase and installation:** paid once, back in 2017. Mounting hardware and the cable run were part of that work.
- **Energy:** effectively nothing. The solar cell covers the supply as long as it stays clean and lit.
- **Cleaning supplies:** a cloth, a bucket, and some patience. This is the cheapest and most useful spending of all.
- **Spare parts:** seals, clips, cable protection, and possibly a replacement probe or cell as the unit ages.
- **Replacement of the whole unit:** the large cost to plan for, since the sensor has been working a long time.
- **My time:** the regular checklist visits, plus extra visits after bad weather.

### What drives cost up

- Letting fouling and moisture build until a part has to be replaced rather than just cleaned.
- Rodent damage to the cable, which means a new run rather than a quick repair.
- A failure during a crucial period, when the cost is not the sensor but lost fish or plants.
- Changing the barn layout so that the solar cell no longer gets enough light, which could mean relocating the unit.

### What keeps cost down

- Doing the checklist on schedule, so cleaning stays the main expense.
- Shading the unit and sealing the housing early, before heat or damp cause damage.
- Keeping a small stock of seals and clips so a repair does not wait.
- Logging every fix, so I can see whether the same part keeps failing and decide on replacement calmly instead of in a rush.

### How I judge repair against replacement

Since the sensor dates from 2017, I ask three questions each time something goes wrong. Is the fault in a cheap part, such as a clip, a seal, or the cable sheath? Has the same fault returned more than once? And can I still trust the readings after the fix, checked against the tank marks? If the answers point to a cheap part and a clean check, I repair. If faults repeat or the readings stay doubtful, I start planning a replacement, and I choose the time myself rather than waiting for a failure in the middle of a season.

Overall, the running cost is low and mostly made of my own attention. The real expense to avoid is a missed warning, so I spend small amounts of time often rather than large amounts after a failure.

## Lessons

These are the things I learned from keeping the Zaethlu level sensor running. It is a level sensor for the aquaponics area. It is green, powered by solar, and has been installed in the barn since 2017. I wrote the notes for myself, so they are blunt.

### What the device is, in one place

| Property | Value |
|---|---|
| Name | Zaethlu level sensor |
| Kind | level sensor |
| Area | aquaponics |
| Color | green |
| Energy source | solar |
| Year installed | 2017 |
| Location | barn |

The sensor watches the water level in the tank loop and reports it so I know when the system needs topping up or when a pump is running dry. Everything below follows from those facts: it is solar, it sits in a barn, and it works in a wet place.

### Lessons about the solar supply

The solar supply is the part that has taught me the most. A barn is a poor place for a panel unless you plan the light.

- The panel has to see the sky. In the first season I left it behind a beam, and the sensor ran flat every few cloudy days. Moving the panel to the sunny side of the roof fixed most of it.
- Dust and cobwebs matter more than I expected. A barn makes both in quantity. A quick wipe of the panel at the start of each season is now part of my routine.
- Winter is the weak time. Short days and low sun mean the sensor sleeps more and reports less often. I accept that, because the water level changes slowly in cold weather anyway.
- A solar device that loses power fully can come back in a confused state. After a long dark spell I now check that readings look sane before I trust them.

### Lessons about the barn

The barn is dry on the outside and damp on the inside, which is an odd mix. Aquaponics puts a lot of moisture into the air.

- Condensation forms inside any enclosure that is not sealed well. I keep the green housing closed tight and check the seal every spring.
- The green color helps me find the sensor quickly among pipes and cables, but it also fades slowly in the light from the roof windows. The color is cosmetic and has not affected anything.
- Mounting height matters. If the sensor sits too low, splashes reach it. If it is too high, the reading gets noisy because of the extra distance to the surface.
- Animals and the occasional visitor will bump things. A firm bracket is better than a clever one.

### Lessons about the water

- Algae and mineral scale build up on anything that touches the water. I clean the sensing part on a regular schedule instead of waiting for odd readings.
- Surface ripples from the pump make single readings jump. Averaging several readings is much better than trusting one.
- A level reading alone does not tell me if something is wrong. A slow drop could be evaporation, a leak, or plants drinking more. I compare with the weather and the season before I panic.
- The sensor should be placed away from the inlet, where the water churns.

### Lessons about maintenance

1. Check the panel and the housing seal at the start of each season.
2. Clean the sensing part and look for scale.
3. Compare the reported level against a ruler or a mark on the tank, to catch drift.
4. Read the notes in this handbook before changing any setting, and write down what I changed.

The biggest lesson is that I should write things down at once. Since 2017 I have forgotten why I did several things, and rediscovering a reason costs more than writing one line.

### Things I would do differently

If I installed it again, I would put the panel on a separate short cable so it can be moved without touching the sensor. I would also add a clear mark on the tank for the level I call full and the level I call low, so that a quick visual check is always possible. And I would keep a small spare kit nearby, with a cloth, a few seals, and a note about where the bracket screws go.

I would not change the choice of solar power. It saved me from running a cable across a wet floor, and after the early panel placement problems it has been dependable enough for a device that only needs to report slowly.

## Software

This section covers the firmware and the habits I use around it. The firmware version of the Zaethlu level sensor is v1.20.313. I record it here so I know what I am running when I read other notes or compare behavior across seasons.

### Firmware overview

The firmware does a small number of jobs:

- It wakes the sensor at intervals and takes a set of level readings.
- It combines the readings into one value, which smooths out ripples from the pump.
- It sends the value out and then goes back to sleep to save solar energy.
- It reports a low power state when the supply is weak, so I can tell a dark spell from a real fault.

Because the device is solar, the firmware is built around sleeping as much as possible. Most of what looks like odd behavior in winter is just longer sleep.

### Behavior I rely on

| Behavior | What I expect | Why it matters |
|---|---|---|
| Wake and read | Several readings per wake | Averages out ripples |
| Sleep | Longer when power is low | Protects the battery in dark weather |
| Report | One combined level value | Easy to log and compare |
| Low power flag | Raised when supply is weak | Separates dark spells from faults |

### How I treat updates

I treat the firmware like the rest of the barn equipment: if it works, leave it alone. The device has run in the barn since 2017, and the aquaponics loop does not need new features. When I do consider a change, I follow a few rules.

- I write down the current version, v1.20.313, before touching anything.
- I update on a bright day, never at the end of a dark spell, so the sensor has power to finish.
- I compare readings against the tank mark before and after, to confirm nothing shifted.
- I keep notes about any setting I change, with the reason.

### Checking that the software is healthy

A healthy sensor produces a steady level value that moves slowly. I look for these signs of trouble:

1. Readings that jump up and down with no change in the water. This usually points to ripples, a loose mount, or scale on the sensing part rather than software.
2. A long gap with no reports. First I check the panel and the weather, then the housing seal.
3. A level that drifts away from the tank mark over weeks. This calls for cleaning and a fresh comparison.
4. The low power flag showing in good weather. This suggests a dirty or shaded panel.

Most problems I have met were physical, not software. Dust, shade, damp, and scale caused far more trouble than the firmware ever did.

### Settings and habits

I keep the settings simple. The reading interval is the one I think about most, because it trades freshness against power. In summer I can afford more frequent reports. In winter I let it slow down. I never set it so fast that the sensor cannot recover between wakes on a cloudy day.

I also keep a short log in my own notes with three columns: what I changed, why, and what happened afterward. A line a month is enough. When something odd happens, the log usually tells me whether it is new or has happened before.

### If the software seems wrong

Before blaming the firmware, I go through the physical checklist from the lessons above: panel, seal, mount, sensing part. Only when all of those are fine do I look at the software side. If I decide a reset is needed, I do it in good light, wait for the sensor to report again, and compare the value to the tank mark. If the value agrees, I note the reset in the log and move on.

### Summary of the software facts

- Device: Zaethlu level sensor, a green level sensor for aquaponics.
- Energy source: solar.
- Location: barn, installed in 2017.
- Firmware version: v1.20.313.

Keeping that short list at the end of the handbook means I can find the version at a glance, and it reminds me that the software is only one small part of a device whose real challenges are light, damp, and water.
