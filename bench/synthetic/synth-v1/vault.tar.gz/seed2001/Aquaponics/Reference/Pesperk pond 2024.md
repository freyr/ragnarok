---
type: reference
status: archived
project: reference
area: aquaponics
---

# Pesperk pond 2024

## Costs

This note records the state of Pesperk pond in 2024. It is archived, and later notes replace the values written here.

Pesperk pond is a pond in the aquaponics area. It faces north, it is medium in size, and it sits at ground level. It was built in 1993. Running it costs money in a few steady ways, and I list them here so I can compare later years against this one.

The main costs in 2024 were these:

| Item | Type of cost | Notes |
| --- | --- | --- |
| Pump electricity | Running | The largest regular cost, because the pump runs all day |
| Fish feed | Running | Bought in large bags, a few times a year |
| Plant nutrients | Running | Only small top-ups, since the fish waste does most of the work |
| Netting and filter media | Replacement | Changed when worn or clogged |
| Repairs to the liner edge | Occasional | Done by hand with patch material |

I did not keep exact receipts for every small purchase, so I do not trust any total for the year. The table shows the order of size only. The pump is the cost I would cut first if I could. The feed is the cost I can least avoid, because the fish need it and the plants depend on the fish.

Labour is not counted. I do most of the work myself on weekends, and I treat that time as free in these notes.

## Supplies

The pond needs a short list of supplies to stay healthy. I keep most of them in the shed near the north edge, which is the closest dry place.

- Fish feed in a sealed bin, to keep damp and pests out.
- Spare pump seals and a spare impeller.
- Filter foam and a few lengths of mesh.
- Patch material for the liner.
- A water test kit with fresh reagents.
- Buckets, a long net, and a pair of waders.
- Plant nutrient mix for the grow beds that draw from the pond.
- Tubing and clamps in two common widths.

I try to hold enough feed for about two months and enough filter foam for one full change. Reagents go off, so I check their dates before each test and replace them when they are old. The waders are the item I forget most often, and I have been caught without them more than once.

The shed is cold in winter, and the test reagents must not freeze. In the cold months I keep them indoors and carry them out when needed.

## History

Pesperk pond was built in 1993. It was one of the first water features in the aquaponics area, and it was dug as a plain basin at ground level. The north-facing side was chosen because the bank on that side gives some shelter from the wind, though it also means the pond gets less direct sun than I would like.

Over the years the pond has been changed several times. The original edge was rough, and it was later reshaped so that it could be reached safely. The liner has been patched more than once. The pump has been replaced, and the pipework was reworked when the grow beds were added to the area.

By 2024 the pond had settled into a steady routine. Fish are fed daily in the warm months and less often in the cold ones. The water is circulated through the grow beds, and the plants pull nutrients from it before it returns. The pond is medium in size, large enough to hold a stable fish stock but small enough that I can clean it by hand in a day or two.

This note captures that 2024 state. If the pond is rebuilt or resized, a newer note should say so and take over from this one.

## Problems

The problems I dealt with in 2024 were small but repeated.

1. Algae grew fast in the warm months. The north orientation helps a little, because the shade slows it, but the shallow edges still turned green.
2. The pump intake clogged with leaves and plant debris. I cleaned it often, and it sometimes needed attention twice in one week.
3. The liner edge showed wear in a couple of places, and I patched it before it could leak.
4. Water level dropped in dry spells. Evaporation and a slow seep both played a part, and I could not always tell which one mattered more.
5. Moisture around the pond kept the ground soft after rain, which made the bank slippery.

None of these was serious on its own. Together they made the pond a steady source of small jobs. The intake and the algae were the two I worried about most, because a blocked pump can harm the fish quickly if it is left alone.

I also noticed that the grow beds sometimes drew down the water faster than expected, which made the level problem look worse than it was.

## Measurements

These are the values I recorded for the pond in 2024.

- Kind: pond
- Area: aquaponics
- Orientation: north
- Size: medium
- Year built: 1993
- Floor: ground level
- Measured humidity: 27.54 %

The humidity reading was taken near the pond, not over open water. It is a single reading, so I treat it as a rough guide and not as a typical value. Humidity near a pond changes with the weather and the time of day, and I did not log those details when I took the reading.

I did not write down other readings in a form I trust enough to keep here. Water temperature and the chemistry tests were done as quick checks and mostly judged by eye and by the fish. If I want a proper record in the future, I should take readings at the same time of day and keep them in a simple table.

## Ideas

Some ideas I have for the pond, none of them started as of 2024.

- Add a coarse pre-filter in front of the pump intake, so leaves are caught before they reach it. This should cut the cleaning work the most.
- Cover part of the shallow edge with floating plants to shade the water and slow the algae.
- Replace the worn section of the liner edge properly, instead of patching it again.
- Fit a simple water level marker, so I can see the drop without guessing.
- Lay gravel or stepping stones on the bank so it is less slippery after rain.
- Keep a regular log of readings, taken at the same time each visit.
- Look for a lower-power pump, since electricity is the largest running cost.

If I do any of these, the result belongs in a newer note. This one stays as the record of how Pesperk pond stood in 2024.
