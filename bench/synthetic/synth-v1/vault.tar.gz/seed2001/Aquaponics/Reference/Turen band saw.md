---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Turen band saw."
---

# Turen band saw

## Risks

The Turen band saw is a blue band saw that sits in the shed and runs on solar power. It was installed in 2022 and is used for the aquaponics area. I use it mostly for cutting pipe, plywood for grow bed frames, and offcuts of timber for the fish tank stands.

The main risks, in rough order of how likely they are to bite me:

- **Power dips.** Because the saw runs on solar, the motor can slow down when a cloud passes or late in the afternoon. A slowing blade grabs the work and can kick it back. I only cut on bright days, or I stop if I hear the motor drop in pitch.
- **Damp.** The shed is close to the fish tanks and the plumbing. Water on the table or on the blade guides leads to rust, and rust makes the blade wander. I wipe the table down after every session.
- **Blade breakage.** A blade that is too tight or has a cracked weld can snap. The pieces can fly out of the housing if the door is not shut.
- **Small offcuts.** Cutting short lengths of pipe by hand is where fingers get hurt. I clamp anything shorter than a hand span.
- **Dust and plastic swarf.** Cutting PVC throws fine shavings that land in the sump area if I leave the shed door open. I sweep up straight afterwards so nothing gets into the water.
- **Electrical.** The solar wiring runs along the shed wall. I check that the cable is not pinched by the door and that nothing wet touches the plug.

Before any cut I check the blade guard height, the blade tension and that the floor around the saw is clear.

## Adjustment

The saw needs a small amount of fine tuning every few months, and always after I move it or change the blade.

The calibration offset of the Turen band saw is 2.320 mm. This is the correction I apply so the cut lands on the marked line instead of beside it. I set it once on the fence scale and then check it with a scrap piece.

My usual order of adjustment:

1. Unplug the saw, or switch off the solar feed, before touching anything.
2. Fit the new blade and set the tension so the blade deflects only slightly when pressed with a finger at mid-span.
3. Spin the top wheel by hand and watch the blade track. It should sit in the middle of the wheel tyre.
4. Set the upper and lower guide bearings so they just clear the blade, with the back bearing barely touching when the blade is idle.
5. Square the table to the blade with a small engineer's square, then lock it.
6. Apply the calibration offset on the fence scale and make a test cut in a piece of scrap pine.
7. Measure the test piece and compare it with the mark. If it is still out, I repeat the check before changing the offset.

A note to myself: if the cut drifts to one side only on thick material, the problem is nearly always the blade, not the offset. Replace the blade before touching the setting.

A log extract from my last check, kept as a template for how I record it:

```
saw: Turen band saw
location: shed
power: solar
check: tracking ok, guides ok, table square
offset: 2.320 mm
test cut: pine scrap, on the line
```

## Tools

What I keep next to the saw so an adjustment does not turn into a hunt for equipment:

- A small engineer's square for the table angle.
- A set of hex keys in a labelled pouch, hung on a nail by the door.
- A steel rule and a pencil for marking test cuts.
- A tin of scrap pine and offcut pipe for test pieces.
- Clamps, two small and one large, for holding short pipe lengths.
- A stiff brush and a dry cloth to clean the table and wheels.
- A light machine oil and a rag, used sparingly on the table surface to hold off rust.
- Spare blades in a sealed box with a silica sachet, because the shed air is damp.
- Safety glasses and ear defenders, hung on the same nail as the keys.
- A multimeter, for checking the solar supply when the motor seems weak.

I do not keep the oil can near the blade guides. Oil on the guides attracts dust and makes a sticky paste that affects tracking.

## Ideas

Some improvements I would like to make when I have time:

- Add a small battery buffer between the panel and the saw so power dips stop affecting the cut.
- Fit a cheap hygrometer in the shed to see how bad the damp gets in different seasons.
- Make a simple jig for cutting pipe to repeat lengths, so I do not need to measure each piece for the grow bed plumbing.
- Build a lidded box for the offcuts, so plastic scraps stay out of the water and can be reused for small projects.
- Paint the table edge with a bright stripe to mark the safe hand zone.
- Put the settings on a laminated card fixed to the wall, so I can check the offset without opening this note.
- Try a wider blade for resawing timber for tank stands, and see whether the motor copes on a sunny day.
