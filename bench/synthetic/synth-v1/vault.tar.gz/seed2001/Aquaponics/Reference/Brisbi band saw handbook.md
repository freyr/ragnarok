---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Brisbi band saw."
---

# Brisbi band saw handbook

## References

This section lists the notes I check when I work on the Brisbi band saw. The saw is a yellow band saw, installed in 2024 in the barn, and it runs on solar energy. It belongs to the aquaponics setup, so most of the related notes are about water, power and fish rather than about wood.

**Power**
- [[Kubupur solar charger]]: the charger that feeds the saw's battery bank. The saw's energy source is solar, and nothing else is wired to it. If the saw stalls or slows, I check the charger notes first, because a weak charge looks like a motor fault.
- [[Methreth Bentroputh notes]]: my notes on the wiring and the fuse layout between the charger and the barn. I read them before I touch any cable near the saw.

**Water side of the system**
- [[Lardu circulation pump notes]]: the pump runs from the same solar supply on sunny days. When both the pump and the saw draw power at once, the supply gets tight. I keep the pump notes next to this handbook for that reason.
- [[Pesperk pond 2024]]: the log of the pond build in the same year the saw was installed. Most of the timber I cut with the saw went into the pond frames and the grow-bed supports.
- [[Faerkpioth level sensor log]]: readings from the level sensor. I use it to see whether a cutting session fell on a day when the water level was already drifting.
- [[Larnaerk valve actuator study]]: a study of the valve actuators. Several brackets for them were cut on the saw, and the study explains why I kept the cuts so square.

**People and places**
- [[Baefir Liosstis notes]]: notes from the person who helped me set up the blade guides. Their advice about tracking is still the most useful thing I have on the subject.
- [[Kokoth workshop]]: the other workshop I use. Heavy work that does not fit the barn goes there, and I carry finished pieces back and forth.

**How I use these links**

I do not read all of them each time. For a quick job I open the charger note and the wiring note. For a long cutting session I add the pump notes. When something odd happens, I go through the list from top to bottom, because power problems are the most common cause.

The properties of the saw, for quick reference:
- Kind: band saw
- Color: yellow
- Energy source: solar
- Year installed: 2024
- Location: barn
- Area: aquaponics (also in the frontmatter)

## History

**Why I wanted a band saw**

Before 2024 I cut everything with a hand saw and a borrowed jigsaw. The aquaponics build needed many curved and angled pieces: brackets, small frames, clamps for tubing and supports for the grow beds. Straight cuts were fine by hand, but the curves were slow and rough. I wanted a band saw that could sit in the barn and run without a mains connection, since the barn already had panels on the roof and I did not want to pay for a new line.

**Choosing and placing it**

The saw is yellow. That was not a choice I made for style. It was the one available, and the color turned out to be useful, because it is easy to see in a dim barn and I stopped tripping over it. I placed it near the big door so long boards can pass through, and away from the pond tools so sawdust does not drift toward the water gear. The location is still the barn, and it has not moved since the install.

**Installation in 2024**

I installed the saw in 2024, early in the season, before the pond work started. The main task was the power. The saw runs on solar energy, so I connected it through the [[Kubupur solar charger]] and the barn battery bank. I wrote down the fuse layout and cable runs in [[Methreth Bentroputh notes]] so I would not have to guess later. The first days were mostly about alignment: the table was slightly out of square, and the blade wandered until I fixed the guides.

[[Baefir Liosstis notes]] came from this period. They showed me how to set the guides close to the blade without pinching it, and how to listen for the sound of a blade that is tracking properly. I still follow those steps whenever I change a blade.

**First uses**

The first real jobs were pieces for the pond. [[Pesperk pond 2024]] describes the build, and many of the support blocks and edge pieces in it came from this saw. Later I cut brackets for the actuators described in [[Larnaerk valve actuator study]]. Those needed clean, repeatable cuts, and the saw handled them once the guides were right.

I also cut a few test pieces to see how long the saw could run on a cloudy day. The answer was not very long. A single session on a gray afternoon drained the battery bank further than I liked, and that led me to schedule the work for the brightest part of the day.

**Sharing the power**

The circulation pump draws from the same solar supply. In the early weeks I ran the saw while the pump was working hard and noticed the saw slow down. I recorded what happened in [[Lardu circulation pump notes]]. Since then I try not to cut during the pump's heaviest hours, and I check the sensor trace in [[Faerkpioth level sensor log]] if I suspect the two overlapped.

**Moving work between sites**

Large pieces do not fit the barn well, so I sometimes take them to the [[Kokoth workshop]] for the final shaping. The band saw stays in the barn and does the rough cutting, and the other workshop handles the finish. This split has worked well and I have kept it since the first season.

**Changes since the install**

Nothing major has changed. I have replaced blades, adjusted the table, and cleaned the dust from the housing many times. I moved a lamp closer to the cutting area. I added a small shelf for spare blades. I did not change the energy source, the color or the location. The saw is still the yellow solar band saw in the barn, installed in 2024.

**Lessons so far**
- Check the charger before blaming the motor.
- Set the guides every time the blade is changed.
- Cut in good light and in good sun.
- Keep the saw away from the pond tools.
- Write down every wiring change at once.

## Open questions

These are the things I still do not know about the Brisbi band saw. I list them so that I can answer them over time and cross them out.

**Power**
- How much cutting can the battery bank support on a poor day? I have a rough feeling, but no measured answer. The best place to record it would be next to the [[Kubupur solar charger]] notes.
- Does the saw need its own small battery instead of sharing the barn bank? Sharing has caused slowdowns when the pump is busy. I would like to compare the two arrangements in a proper test.
- Is the fuse I use the right size? [[Methreth Bentroputh notes]] says what is installed, but not whether it is the best choice. I want to check this with someone who knows more about solar wiring.

**Interaction with the water system**
- Does the pump's demand really cause the slowdown, or is it only a coincidence with cloud cover? The [[Lardu circulation pump notes]] and the [[Faerkpioth level sensor log]] might show a pattern if I line them up carefully.
- Would it help to add a simple switch that blocks the saw while the pump is at its highest draw? It would be easy to build, but I am not sure it is needed.

**Cutting and maintenance**
- Which blade type is best for the thin plastic and the hardwood I use for the actuator parts? The [[Larnaerk valve actuator study]] suggests that some cuts left a rough edge, and I do not know if the blade or my feed speed was the cause.
- How often should I replace the guides? I have not tracked wear. [[Baefir Liosstis notes]] gives a method for setting them, but not a schedule.
- Is the table still square? I check it by eye, and I should find a better way.

**Placement**
- Should the saw move closer to the [[Kokoth workshop]] work, or stay in the barn? Carrying pieces is a small cost, but it adds up in a busy season.
- Is the dust a risk for the aquaponics gear in the barn? I keep the saw away from the pond tools, but fine dust travels. I have not looked for dust near the pond area after a long session, and I should.

**Records**
- Where should I keep a running log of blade changes and cuts? At the moment the information is spread over several notes, including [[Pesperk pond 2024]]. A single place would be better, and it may be the next part of this handbook.
- Which facts are missing from this reference? I have the kind, the color, the energy source, the year installed, the location and the area, but I may have forgotten other facts worth writing down.

## Risks

The Brisbi band saw is a yellow band saw that sits in the barn. It was installed in 2024 and it runs on solar energy. It supports the aquaponics work, so most of what I cut with it is for the fish and plant systems: lumber for grow bed frames, plastic pipe, and the odd offcut of board for tank stands. The risks below are the ones I actually think about when I walk up to it.

### Blade risks

The blade is the obvious hazard. A band saw blade is a long loop of toothed steel running at speed, and only a small part of it is doing the cutting. The rest is exposed or half exposed behind the guides and the wheel covers.

- A blade can snap. When it does, it whips inside the housing and can throw pieces. I keep the wheel covers closed every time I run the saw.
- A dull blade makes me push harder. Pushing harder is how fingers end up near the teeth. If I have to lean on the wood, I stop and change the blade.
- A blade that is set too loose can wander and twist in the cut. One that is too tight is more likely to break.
- Cutting round stock, such as a length of pipe or a branch, without a support can let the piece roll and pull my hand in.

### Solar power risks

Because the saw runs on solar energy, its power depends on the weather and the time of day. That creates a few risks I would not have with a plain mains connection.

- Power can dip in the middle of a cut when a cloud passes. The motor slows, the blade can grab, and the wood can kick. I do not start a long cut when the sky is changing quickly.
- The saw can stop and then restart by itself when the power comes back. I always switch it off at the saw, not just rely on the supply dropping out.
- Wiring in a barn gets dusty, and the barn is damp from the aquaponics side. Damp and electricity together is a real danger, so I check cables and connections regularly.
- Late in the day the supply is weaker. I avoid heavy or thick cuts then.

### Water and damp risks

The barn holds the aquaponics gear, so water is never far away. Splashes, drips and humid air all reach the saw area.

- A wet floor near the saw is a slip risk, and slipping while holding wood against a blade is the worst case.
- Wet wood binds on the blade and cuts badly. I let it dry first when I can.
- Damp rusts the table and the blade. A rusty blade breaks sooner and cuts roughly.
- Water on or near the electrical parts is a shock risk. I keep buckets and hoses away from the saw.

### Dust and material risks

Sawing makes fine dust, and some of the materials I cut are not good to breathe.

- Wood dust irritates the lungs and eyes, and it builds up in a closed barn.
- Treated lumber is something I avoid cutting for anything that touches the fish or the water, because chemicals can leach into the system. I also avoid breathing its dust.
- Plastic cuts can leave shavings and a melted smell if the blade is dull or the feed is slow. I keep the barn doors open for air.
- Sawdust in a barn is a fire risk, especially near any electrical fault.

### Handling and fatigue risks

Most accidents happen when I am tired or hurrying. A long session of cutting frame parts makes me less careful, so I keep sessions short and take breaks. I also do not use the saw when I am distracted, for example when I am thinking about a pump problem in the tanks.

## Supplies

This section lists what I keep on hand so I do not have to improvise at the saw. I store most of it in a labeled box near the Brisbi band saw in the barn.

### Blades

I keep spare blades because a break in the middle of a project is annoying, and a dull blade is a safety issue. I keep a few types so the saw suits the job:

- A general purpose wood blade for most of my frame work.
- A finer toothed blade for thin boards and plastic pipe.
- A wider blade for straight cuts in thick lumber.

I store blades coiled and tied, hung on a dry hook, away from the damp. A light wipe of oil keeps rust off.

### Maintenance items

- A soft brush and a small vacuum for clearing dust from the table and the wheel area.
- A rag and a little machine oil for the table surface and the blade.
- Wax or dry lubricant for the table so wood slides easily.
- A small screwdriver set and a wrench for the guides and the table tilt.
- Spare fuses and a few spare connectors for the solar supply side.
- A cloth to wipe moisture off the saw after humid days.

### Workholding and guides

- Push sticks, at least two, kept on a hook beside the saw. I make new ones from scrap whenever the old ones get chewed up.
- A fence for straight cuts.
- A V block or a cradle for round stock so it cannot roll.
- Clamps for holding longer pieces steady.
- A miter gauge for angled cuts.

### Personal protection

- Safety glasses, which I keep in the same box so I cannot forget them.
- A dust mask or a respirator for fine dust and for cutting plastic.
- Hearing protection, because the saw gets loud in a closed barn.
- Close fitting gloves for handling blades when I change them, never for feeding wood past a running blade.
- Sturdy shoes with a good grip, since the floor can get damp.

### Cleaning and emergency items

- A broom and dustpan, kept dry.
- A small fire extinguisher mounted near the barn door.
- A first aid kit with plenty of plasters, gauze and tape.
- A phone or a charged handheld device so I can call for help if I am alone.

### Material notes

I try to buy untreated lumber for anything connected to the aquaponics system. For plastic, I choose food safe pipe where it will carry system water. I keep offcuts in a bin so they do not pile up on the floor around the saw.

## Safety

These are the rules I follow every time I use the yellow Brisbi band saw in the barn. I wrote them as short steps so I can read them quickly before starting.

### Before I switch it on

1. Look at the weather and the solar supply. If the sky is changing fast or the supply looks weak, I wait.
2. Check the floor around the saw. It should be dry, clear and well lit.
3. Check the blade for cracks, missing teeth or rust. If I see damage, I replace it.
4. Check the blade tension and tracking by turning the wheel by hand.
5. Set the upper guide just above the wood, so only the needed part of the blade is exposed.
6. Close and fasten the wheel covers.
7. Put on safety glasses, a mask and hearing protection.
8. Check cables and connections for damage or damp.

### While cutting

- Let the blade reach full speed before the wood touches it.
- Feed the wood slowly and let the blade do the work.
- Keep my hands out of the line of the blade and well away from the teeth. I use a push stick near the end of a cut.
- Never cut round stock without a cradle or V block.
- Do not back the wood out of a cut while the blade is running if it is binding. I switch the saw off and wait for the blade to stop.
- Do not reach behind the blade or clear scraps with my hands while it moves.
- If the power dips or the motor slows, I stop feeding, switch off, and wait.
- Keep my attention on the cut and do not talk or look away.

### After cutting

1. Switch off the saw at the saw itself.
2. Wait until the blade has fully stopped before I clear the table.
3. Brush and vacuum the dust, especially around the motor and wiring.
4. Wipe the table and blade dry, then add a thin film of oil.
5. Release some blade tension if the saw will sit idle for a long time.
6. Put push sticks, glasses and other gear back in the box.

### Electrical and solar safety

- Treat the saw as live whenever the solar supply is connected.
- Disconnect the supply before changing a blade, adjusting the guides or doing any cleaning inside the housing.
- Keep water, hoses and wet hands away from the saw and its cables.
- Do not run the saw if a cable is frayed, a connector is loose or something smells burnt.
- Check the supply side after storms, since wind and damp can loosen or damage parts.

### Fire and dust safety

- Sweep sawdust often, so it does not collect near the motor.
- Keep the extinguisher where I can reach it without crossing the saw.
- Open the barn doors when cutting a lot, so dust and fumes can clear.

### Working alone

I try not to use the saw when nobody knows I am in the barn. If I must, I keep my phone with me, tell someone what I am doing, and keep sessions short. If I feel tired, rushed or unwell, I leave the cut for another day.

### If something goes wrong

- If the blade breaks, switch off, wait for everything to stop, then check myself and the area before touching anything.
- If I cut myself, stop, press on the wound with clean cloth, and get help. For a serious cut I call for emergency help straight away.
- If there is a fire, I disconnect the supply if I can do so safely, use the extinguisher on a small fire, and leave if it grows.
- After any incident, I inspect the saw before using it again and write down what happened so I can avoid it next time.

## Lessons

The Brisbi band saw is a band saw, and it has been installed in the barn since 2024. It is yellow, which turned out to be more useful than I expected. In a barn full of grey tanks, grow beds and dusty timber, a yellow machine is hard to miss, and I have never walked into it in poor light. I keep it in the same corner so that the layout stays predictable.

The biggest lesson is about the energy source. The saw runs on solar power, so its behavior depends on the weather and the time of day. On bright days it cuts without complaint. On heavy overcast days the motor can sag under a thick load, and the blade slows down in the cut. I now plan the big jobs for the middle of a clear day and leave small trimming for the evenings. If the sky is dull, I do prep work instead: marking, measuring, sorting offcuts.

The second lesson concerns the area the saw serves. Its job is aquaponics, meaning it cuts the frames, bed supports, stand legs and plank edging that hold up the fish and plant systems. Damp is the constant enemy. Wet timber binds the blade and leaves a rough edge, so I let stock dry for a few days before cutting. I also keep the saw away from the splash zone near the tanks, because water on the table and the blade guides invites rust.

Other things I learned the slow way:

- Blade tension matters more than blade sharpness. A slightly dull blade at the right tension still cuts straight; a sharp blade that is too loose wanders.
- Release the tension when the saw will sit for more than a few days. The barn gets cold at night, and a blade left tight all winter loses its life early.
- Cut treated timber only with the dust extraction attached, and wear a mask anyway.
- Never force a curve tighter than the blade width allows. The blade twists, and it can snap.
- Clean pitch and sap from the wheels. A small buildup makes the blade track badly and the whole saw vibrates.
- Mark the cut line with a bright pencil. Yellow paint on the saw body hides pencil marks nearby, so I mark on the workpiece only.

One mistake worth recording: in the first season I fed long planks without a support stand, and the end swung and pulled the cut off line. A simple roller stand fixed that. Another: I left the saw uncovered during hay season, and the table was coated with fine dust that scored the guides. A fitted cover now lives on a hook beside it.

## Costs

I am not writing exact prices here, because they change and I do not want stale figures in a reference note. What matters is the shape of the spending, and where the money went.

The largest cost was the initial purchase and setup in 2024. The saw itself was the major item, followed by the work needed to get power to it. Because the energy source is solar, the saw is tied to the barn's panel and battery setup, so I counted a share of that system as part of the saw's cost. If I had used mains power, the setup would have been simpler, but I would be paying for electricity every month. With solar, the running cost of the motor is close to nothing, which is the main reason I chose it.

Ongoing costs are small and fall into a few groups:

- **Blades.** These are the main consumable. Buying spares in a few widths saves trips and downtime. A narrow blade for curves and a wider one for straight resawing cover almost everything I do.
- **Guides and bearings.** These wear slowly, but wet timber and dust speed it up. I replace them when the cut starts to drift rather than on a schedule.
- **Lubricant and rust protection.** A can of dry lubricant and some wax for the table last a long time.
- **Dust control.** Filters and bags for the extraction need replacing now and then, and this cost rises when I cut a lot of treated or damp wood.
- **Cover and stands.** A one-off purchase, but worth listing, because skipping them cost me more in repairs.

Hidden costs deserve a line. Poor cuts waste timber, and in aquaponics a bad frame can mean a leaking bed or a wobbling tank stand, which risks fish and plants. Time lost to weather-dependent power is also a cost, although I reduce it by planning around the sun. If the battery is low, I would rather wait than push the motor.

If I were buying again, I would spend a little more on a stronger motor margin and a better blade guide set, and a little less on accessories I rarely use. I would also keep a small repair fund, because something always needs replacing in the second or third year.

## Checklist

Use this before and after each session with the Brisbi band saw in the barn.

**Before cutting**

- Check the sky and the battery level. Big jobs wait for a bright part of the day.
- Look over the yellow body and table for dust, water or sap.
- Check blade tension and make sure the blade sits centered on both wheels.
- Set the guides close to the blade without pinching it.
- Confirm the timber is dry enough to cut cleanly.
- Attach dust extraction, and put on a mask and eye protection.
- Set up a roller stand for long stock.
- Mark the cut line on the workpiece in pencil.
- Clear the floor around the saw of offcuts and cords.

**During cutting**

- Let the blade reach full speed before feeding the wood.
- Feed at a steady pace and let the blade do the work.
- Do not force tight curves; make relief cuts instead.
- If the motor slows because the sun fades, stop, back out, and wait.
- Keep fingers well clear of the blade path and use a push stick for narrow pieces.

**After cutting**

- Switch off and wait for the blade to stop completely.
- Brush off dust, and clean sap from the wheels and guides.
- Wipe the table dry and apply a thin coat of wax.
- Release blade tension if the saw will sit unused for several days.
- Empty or check the dust bag.
- Put the cover back on and return spare blades to their hook.

**Monthly**

- Inspect the blade for cracks and missing teeth.
- Check the bearings and guides for wear.
- Check the solar connection and cables for damage or loose fittings.
- Review the supply of spare blades and filters.

## Tools

The Brisbi band saw is a yellow band saw that sits in the barn, and it has run on solar power since I installed it in 2024. Most of what I do with it supports the aquaponics system, so the tools around it are chosen for that work: cutting lumber for grow beds, trimming pipe supports, and shaping stands for the fish tanks.

**Tools I keep next to the saw**

- A steel rule and a pencil. I mark every cut with both, because a pencil line alone disappears under sawdust.
- A combination square. I use it to check that the fence sits square to the blade before any long cut.
- A push stick. It lives on a hook at the left side of the saw and I never cut small pieces without it.
- A soft brush and a small vacuum for the table. Resin and dust build up fast, and a dirty table makes the wood drag.
- A blade tension gauge. It is a simple spring type that I clip on when I change a blade.
- A tin of dry lubricant stick for the blade guides.
- Spare blades in a labeled tube: one coarse for green timber, one fine for thin boards and plastic.
- Ear protection and safety glasses, hung on the same hook as the push stick.

**Tools for the solar side**

Because the saw runs on solar, I treat power as a tool too. I keep a small voltmeter on the barn wall near the battery bank. Before a long session I look at it. If the battery is low, I do the cutting in the afternoon, when the panels have been working for several hours. I also keep a notebook page by the saw with the rough cutting time I can expect on a sunny day and on a cloudy one.

**Cleaning and care tools**

- A wire brush for the wheels' rubber tires. I use it lightly, only when something is stuck to them.
- A rag with a little oil for the table surface, wiped dry afterward so it does not stain the wood.
- A flashlight, because the barn is dim near the back wall and the blade path is hard to see.
- A small mirror on a stick, used to look at the lower guide without kneeling.

**Workshop habits tied to the tools**

I put every tool back in the same place after each job. The saw is bright yellow, so it is easy to see, but the small tools are not, and I lost a square twice in the wood pile. Now each one has a painted outline on the board behind the saw.

For aquaponics work I also keep a separate pair of gloves that never touch fish water. Wet gloves and a running blade do not mix, so I dry my hands and put on dry gloves before I start the saw. Actually, I take them off for fine cuts, because loose fabric near a moving blade is a risk, and I rely on the push stick instead.

## Ideas

These are things I want to try or improve. None are done yet unless I say so.

**A dust catcher**

The barn is open on one side, but dust still settles on the battery bank and the wiring. I want a simple catcher under the table: a sheet metal funnel leading to a bucket. The aim is to keep sawdust out of the electronics and to reuse it as bedding in the compost corner. I would keep it away from the fish area, because fine wood dust can foul water and change how the beds behave.

**A fixed cutting jig for grow bed frames**

I keep cutting the same lengths of board for frames. A stop block clamped to the fence, with a tidy scale beside it, would save time and reduce waste. I could make a second jig for cutting angled braces so that tank stands come out the same each time.

**A shade over the panels**

On very hot afternoons the panels get hot and the output drops slightly. I have thought about a light airflow gap behind them, with better spacing from the roof. It is not a shade as such, more a way to let air move. It might help the saw run more steadily in summer.

**Switch labeling and a clear start routine**

I want a laminated card by the power switch with a short list: check the blade, check the guides, check the battery level, clear the table, put on glasses, start. Since I use the saw only now and then, a card is more reliable than my memory.

**A lower work light**

A yellow saw in a dim barn still needs good light. A small lamp on a flexible arm, powered from the same solar system, would show the cut line better. I would have to make sure it does not drain the battery on days when there is little sun, so it should be a low-draw type.

**A cutting plan for the season**

Each spring I rebuild some of the aquaponics frames because damp wood does not last. I would like to plan the lumber in one list, cut it in a few sunny days, and store the pieces dry in the barn. That would use the saw when solar power is strongest and avoid rushed cuts in autumn.

**Plastic and pipe cutting setup**

I sometimes cut pipe for the plumbing. The fine blade works, but pipe rolls. I want a V-shaped cradle on the table, clamped down, so the pipe stays still and the cut stays square.

**Tracking maintenance**

A simple log pinned in the barn: date of blade change, date of guide cleaning, anything odd I noticed. At the moment I rely on memory and I forget what I did last.

## Problems

This section records the issues I have had with the saw, what I think caused them, and what I did.

**Blade wandering in thick boards**

Sometimes the cut drifts to one side in thick timber. The cause was usually a dull blade or too much feed pressure. The fix is to slow down, let the blade do the work, and change to a sharper blade sooner than I think I need to. I also check that the guides are set close to the wood but not tight.

**Blade slipping or coming off**

Twice the blade came off a wheel. Once the tension was too low after a blade change, and once the wheel tracking had shifted. Now I check tension with the gauge, turn the wheel by hand a few times, and watch where the blade sits on the tire before I close the cover.

**Power drops on cloudy days**

Because the saw runs on solar, a run of gray days can leave the battery too low for good cutting. The motor then slows under load and the cut gets rough. I now avoid heavy cutting on dull days and do the thick pieces when the battery reads full. If I must cut, I make shallow, short passes and rest the motor.

**Resin and damp wood build-up**

Wood for aquaponics is often damp, because it sits near water. Wet sawdust sticks to the wheels and the table. That makes the blade vibrate and the cut look rough. I clean the wheels more often than the manual suggests, and I let boards dry in the barn before cutting if I can.

**Rust on the table**

Humidity from the nearby tanks leaves a light film of rust on the table. I wipe it with an oiled rag, then wipe it dry. I also keep a cover over the saw when I am not using it. A small fan in the barn helps air move, but I have not found a perfect answer.

**Dust on the electronics**

Fine dust gets onto the solar controller and the battery terminals. I clean it with a dry brush before I forget. The dust catcher idea above is meant to deal with this properly.

**Poor visibility at the back of the barn**

The saw is in a dim spot, and I once misjudged a line. A better lamp is on my list. For now I use a flashlight and mark lines darker than I think necessary.

**Pipe and thin stock chatter**

Thin boards and plastic pipe vibrate and tear on the coarse blade. Switching to the fine blade solves most of it. For pipe, a cradle is still missing, so I clamp a scrap block behind it, which works but is clumsy.

**Forgetting maintenance**

The biggest problem is me. I skip guide cleaning, I forget when the blade was changed, and I put off checking the tension. A written log and a start card should fix this, so those two ideas are the ones I should do first.

## Schedule

This is the routine I keep for the Brisbi band saw, the yellow band saw that has stood in the barn since 2024. It runs on solar power, so the schedule follows the sun as much as the calendar. I plan cutting for bright hours and do maintenance on dull days when the panels give little anyway.

### Before each session

- Look at the sky and the battery display. If the charge is low and it is cloudy, I move the cutting to another day.
- Walk around the saw and look for sawdust or fish-tank spray on the table. The barn is near the aquaponics beds, and damp air gets everywhere.
- Check that the yellow guard is in place and moves freely.
- Spin the wheels by hand once, with the power off, to see that the blade tracks in the middle of the tire.
- Clear the floor around the saw. A tripped hose is the most likely accident in this barn.

### After each session

- Switch off the power and wait until the blade has fully stopped.
- Brush the dust out of the lower housing. Wet dust packs hard if left overnight.
- Wipe the table with a dry cloth, then a very thin film of oil to keep rust off.
- Release a little blade tension if I will not use the saw for several days.
- Note in the logbook what I cut, how long I ran the saw, and anything that sounded wrong.

### Weekly

- Check the blade for cracks near the teeth and for missing teeth.
- Look at the guide blocks and the thrust bearing for wear.
- Vacuum the motor vents.
- Check the solar cable run from the roof to the saw for chafing, loose clips or signs of rodents.

### Monthly

- Clean both tires and look for grooves or glazing.
- Check that the table is still square to the blade.
- Inspect the wiring box for damp, because condensation from the aquaponics side is a real problem.
- Test the emergency stop and the guard.
- Wash the panel surface if dust or pollen has built up.

### Seasonal

- At the start of the bright season, I do a full alignment and replace the blade whether it needs it or not.
- Before the dark season, I clean everything, oil the moving parts, and cover the saw with a sheet.
- Once a year, I check the solar battery connections and tighten them.

## Setup

### Where it stands

The saw is in the barn, along the wall away from the water. I chose that spot for three reasons: the wall is dry, the cable to the roof panels is short, and there is enough free floor to feed long boards through without hitting anything. The saw is yellow, which helps because the barn is dim and I can see it from across the room.

The floor is concrete and fairly level. I put a rubber mat under the base to cut vibration and keep the feet from creeping. Light comes from a window to the left of the saw, and I added a work lamp on a bracket for winter.

### Power

The Brisbi band saw uses solar as its energy source. A panel array on the barn roof feeds a battery bank, and the saw draws from that bank through a controller. I do not connect it to the mains. The motor starts hard, so I leave the battery well charged before I begin, and I never start the saw when the display shows a low level.

Some practical notes on power:

- The first start of the day takes the most current. I let the saw reach full speed before touching any wood.
- If the lights in the barn dim when the saw starts, the battery is too low and I stop.
- Long cuts in thick timber use much more energy than thin cuts, so I plan big jobs for the middle of a sunny day.
- I keep the controller display visible from the saw, so I can check the charge without walking away.

### Blade installation

1. Switch off the power and make sure the saw cannot start.
2. Open the wheel covers and release the tension fully.
3. Slide the old blade out of the guides and off the wheels, with gloves on.
4. Fit the new blade with the teeth pointing down toward the table at the front of the cut.
5. Seat the blade on the wheels and add tension slowly.
6. Turn the wheel by hand and adjust the tracking until the blade sits in the middle of the tire.
7. Set the guide blocks just clear of the blade, and set the thrust bearing a hair behind it.
8. Close the covers, raise the guard to the right height, and run the saw for a short test with no wood.

### Guide height and fence

I keep the upper guide only a little above the wood, since a low guide gives a safer and straighter cut. For straight work I clamp a wooden fence to the table and check it against the blade with a square. For curves, I take the fence off and cut by eye with a pencil line.

### Safety gear

- Eye protection, always.
- Hearing protection, since the barn echoes.
- Close-fitting sleeves and no loose cords or jewelry.
- A push stick within reach.
- A first aid kit on the wall beside the door.

I keep the floor dry. The aquaponics area is close, and water near a powered machine is not something I take lightly, so I wipe up any splash before I start.

## Overview

The Brisbi band saw is a band saw used in the aquaponics area of my small holding. It is yellow, runs on solar energy, was installed in 2024, and lives in the barn. I use it for the wood and plastic parts that the aquaponics system needs: frames for grow beds, supports for pipes, boards for covers, and the odd repair to a fish tank stand.

### Quick facts

- Kind: band saw
- Area: aquaponics
- Color: yellow
- Energy source: solar
- Year installed: 2024
- Location: barn

### What I use it for

The saw handles most of the shaping work around the system. Typical jobs include:

- Cutting timber to length for bed frames and legs.
- Ripping boards narrower for shelves and trays.
- Cutting curves in plywood for plant net supports.
- Trimming plastic sheet and thick pipe, with a fine blade and slow feed.
- Making small blocks and wedges for leveling tanks.

I do not cut metal on it, and I do not cut wet or green wood unless I have to, because the sap gums up the blade and the tires.

### How it behaves

The saw is steady once it is at speed. The yellow frame is heavy enough that it does not walk across the floor. The tracking holds well after a proper setup, but it drifts if the blade tension is too low. The main weaknesses are the dust that collects in the lower housing and the humidity in the barn, which is why my schedule has so much cleaning and oiling in it.

Because it runs on solar power, the saw is only as good as the weather. On a run of cloudy days I get less cutting done, and I have learned to batch jobs and prepare lumber ahead. That limit has turned out to be useful, since it forces me to plan each project before I start cutting.

### Common problems and fixes

- **Blade wanders in the cut:** the blade is dull, the tension is low, or the guides are too far back. Replace or retension and reset the guides.
- **Blade slips off the wheel:** tracking is off. Adjust it with the saw unplugged and turn the wheel by hand.
- **Saw slows or stops under load:** the battery is low or the feed is too fast. Wait for charge and push more gently.
- **Rust on the table:** damp barn air. Clean and oil it more often.
- **Burn marks on the wood:** dull blade or too slow a feed.
- **Strange rattle:** check the guard, the covers and the table bolts first.

### Notes to myself

- Keep a spare blade on the shelf next to the saw, so a broken one never ends a job.
- Keep the logbook up to date; it shows me when wear starts.
- If I move the saw, I must recheck the cable run to the panels and the level of the table.
- If the barn gets a leak, protect the saw first, then the rest.

## Background

The Brisbi band saw is a band saw that I keep in the barn. It was installed in 2024, and it has been part of the aquaponics work ever since. It is painted yellow, which makes it easy to spot in the dim corner where it stands, and I have never lost it under a pile of offcuts. It runs on solar power. That fact shapes almost every decision about when and how I use it.

I wrote this handbook for myself. The saw is not complicated, but I use it in bursts, sometimes with weeks between jobs, and I forget the small habits that keep it working well. Having it all in one place saves me from relearning things.

### Why a band saw in an aquaponics barn

An aquaponics system is mostly plumbing, frames and grow beds. A lot of the work is cutting: wooden frames for the grow beds, support rails for the pipes, plastic sheet for lids and dividers, and the odd piece of thick pipe that has to be trimmed to length. A band saw is gentler on plastic than a circular saw. It does not throw the material around or melt it as readily, and the cut is quieter. It also handles curves, which I need when I fit a bed around a post or a tank.

The barn is a good place for it. It is dry, it has space to feed long boards through, and it sits close to the fish tanks and the grow beds, so I do not carry heavy lumber far. The one drawback is humidity near the tanks. Moisture in the air is hard on bare steel, so I wipe the table and the blade after each session.

### Power and the solar setup

The energy source is solar. The saw does not draw directly from the roof panels at full strength on a dull day, so I plan cutting around the weather. My habit is simple:

- I cut in the middle of the day, when the sun is strongest.
- I avoid starting the saw when the battery is low or when the pumps for the fish tanks need the same supply.
- I never run the saw while another large load is switching on, because the start-up surge can trip the system.
- I do the long cuts in one go instead of stopping and starting, because each restart pulls a surge of current.

The fish and the plants always come first. If the system is under strain, the saw waits. A cloudy afternoon is a good time to sharpen, tidy or plan cuts instead of making them.

### Layout and what sits around it

The saw stands against the long wall of the barn, with clear floor space in front and behind it. I keep a few things within reach:

1. A push stick, hanging on a hook at the side.
2. A small brush for clearing dust from the table.
3. A tin of spare blades, wrapped so the teeth do not catch.
4. A cloth and a little light oil for the table and the guides.
5. A pair of safety glasses and ear protection.

The yellow paint is not only about looks. Because it stands out, I notice if something has been left leaning against it or if a cable has been run across the floor near it. I treat that as a prompt to tidy before cutting.

### Safe habits I follow

I keep these rules in mind every time:

- Unplug or switch off the supply before changing a blade or opening the guards.
- Set the upper guide just above the material, so only the needed length of blade is exposed.
- Hold the work flat on the table and feed it slowly. I never force it.
- Use the push stick near the blade, and keep fingers well away from the line of the cut.
- Do not cut round stock without a support, because it can roll and grab.
- Wait until the blade has stopped completely before reaching in to clear scraps.

### Blade care

A dull blade wanders, burns wood and makes the motor work harder, which matters when the power is solar. I check the blade for cracks and for missing or bent teeth before each job. Tension is set so that the blade does not flutter but is not tight enough to strain the frame. I release the tension when the saw will sit unused for a long time, which helps the blade and the tyres last longer.

For plastic, I choose a finer tooth and a slower feed so the cut does not melt and fuse behind the blade. For wood, a coarser tooth clears chips better. I keep notes on which blade is fitted so that I do not cut plastic with a coarse wood blade by accident.

### Cleaning and storage

After each session I brush down the table, empty the dust, and wipe the blade and guides with a lightly oiled cloth. Sawdust holds moisture, so I do not let it sit in the base. I keep the cover over the saw when it is not in use, because the barn collects dust and the occasional splash from nearby work.

## Measurements

This section collects the figures that describe the saw and its place in the system. I keep it short on purpose. Anything I have not measured myself I leave out instead of guessing.

### Summary of properties

| Property | Value |
| --- | --- |
| Kind | band saw |
| Area | aquaponics |
| Color | yellow |
| Energy source | solar |
| Year installed | 2024 |
| Location | barn |
| Flow rate | 363.93 l/h |

### Flow rate

The flow rate of the Brisbi band saw is 363.93 l/h. I record it here because the saw has a small water feed that I use to keep the blade cool and to keep dust down when I cut thick or resinous material. That feed is what the figure describes. It is not a measure of cutting speed or power.

In practice, the rate is low enough that it does not flood the table or drain the supply tank quickly. It is also gentle enough that the water does not splash toward the electrical parts. When I cut plastic, I keep the feed on so the cut stays clean. When I cut dry timber for frames, I usually turn it off, since wet wood swells and the sawdust turns into a paste that clogs the guides.

### How I check the flow

I check the flow from time to time because the figure can drift. Small particles collect in the line and slow it down. My routine is:

1. Place a marked container under the outlet.
2. Run the feed for a fixed, timed period.
3. Compare the amount collected with what I expect from the rate above.
4. If it is clearly low, clean the filter and the line, then repeat the test.

If the flow is far from the recorded rate after cleaning, I look for a kinked hose, a partly closed valve or air in the line. I do not adjust the valve to compensate before I have found the cause.

### Notes on use of the measurements

The properties in the table are fixed facts about the saw. The saw has been yellow since it was set up, it has stood in the barn since 2024, and it takes its energy from the sun. The only value that I expect to change over time is the flow rate, because of clogging or wear, and I will update the figure only after a proper test.

When I plan a job, I think in this order. First, I check the weather and the solar supply, since the energy source limits when I can work. Second, I confirm that the cutting area is clear. Third, I decide whether the water feed is needed, which depends on the material. Finally, I choose the blade. This sequence keeps me from starting a cut I cannot finish.

### What the figures mean for the aquaponics work

Because the saw belongs to the aquaponics area, its water use should never compete with the fish and plants. The feed rate is small next to the circulation of the system itself, so it does not matter much. Still, I try not to run the feed when the supply tank is low, and I never take water from the grow system for cooling. The saw uses its own separate supply, and I keep it that way to avoid carrying sawdust or oil into the fish water.

I also keep the saw well away from the tanks themselves. Fine dust and oil in the water can harm fish and clog the filters, so all cutting happens at the saw, and I sweep the floor around it before I leave.
