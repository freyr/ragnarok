---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Vustior valve actuator."
---

# Vustior valve actuator

## Tools

The Vustior valve actuator is a blue, solar-powered valve actuator that I installed in 2022. It sits in the shed and belongs to the aquaponics setup. Most jobs on it need only a few basic tools, and I keep them together on the shelf near the shed door.

- A small flat screwdriver for the terminal block and the cover latch.
- A medium Phillips screwdriver for the mounting plate.
- An adjustable spanner for the coupling between the actuator and the valve stem.
- A multimeter for checking the voltage from the solar side.
- A soft brush and a dry cloth for dust and spider webs.
- A torch, because the shed is dim even in daytime.
- A marker pen to mark the valve position before I take anything apart.

I do not use a power drill on this unit. The housing is thin plastic and the screws strip easily. Hand tools are enough, and they make me slow down, which helps.

## References

These are the notes I check when I work on the Vustior valve actuator or need to remember why something was done.

- [[Gandbrae workshop notes]] has my early notes on mounting the actuator and the first wiring layout in the shed.
- [[Trarkti workshop notes]] has the later changes, including how I rerouted the cable along the wall.
- [[Faerkpioth level sensor log]] shows the water level readings that decide when the valve should move. I compare the log with the actuator behaviour when something looks wrong.
- [[Nizi workshop plan 2018]] is the old plan for the shed. It explains why the shed has the layout it has and why the actuator ended up on the south wall.
- [[Kuglend solar charger plan]] describes the solar charging side that feeds the actuator.
- [[Pesperk pond 2024]] covers the pond work two years ago, when the valve was used more than usual.
- [[Kalglon Dithsel]] is the person I ask when I need a second opinion on valves and fittings.

## Parts

The part number of the Vustior valve actuator is KM-7208-W. I write it here because the label on the housing has faded and is hard to read now.

Main parts of the unit as I know them:

- The blue plastic housing, which holds the motor and the gears.
- The motor and gearbox, which turn the valve stem.
- The coupling, which joins the output shaft to the valve stem.
- The terminal block under the cover, where the supply and control wires connect.
- The mounting plate, fixed to the shed wall with four screws.
- The solar supply: a small panel on the shed roof, a charge controller and a battery. The setup is described in [[Kuglend solar charger plan]].

If I ever order a replacement, I will quote the part number above and say that the unit is blue and solar powered. I do not keep spare parts at the moment, apart from a few screws and a spare length of cable.

## Background

The Vustior valve actuator is a device in my aquaponics area. Its job is to open and close a water valve so that water moves between the fish tank and the grow beds without me standing there. The energy source is solar, so it keeps working without a mains socket in the shed. I installed it in 2022, and it has been in the same place in the shed ever since.

The reason for choosing solar was simple. The shed had no spare mains circuit, and running a new cable seemed like too much work for one small motor. The solar plan in [[Kuglend solar charger plan]] was the answer. The panel is small, but the actuator uses very little energy because it only runs for a short time when the valve changes position.

The actuator reacts to decisions based on the water level. I keep the readings in [[Faerkpioth level sensor log]]. The shed position was chosen with the older layout from [[Nizi workshop plan 2018]] in mind, and the first installation steps are in [[Gandbrae workshop notes]]. Later tweaks are in [[Trarkti workshop notes]].

During the pond work in [[Pesperk pond 2024]] I used manual override more often than before. That showed me how much I rely on this unit and how little I had written down about it, which is one reason this note exists.

## Safety

Even though the voltage is low, I follow a few rules each time.

- Close the manual supply valve upstream before removing the actuator, so water does not run out while the stem is free.
- Disconnect the battery side before touching the terminal block. A solar system can still deliver power in bright light, so I also cover the panel with a cloth if the sun is strong.
- Never work on the unit with wet hands. The shed floor gets damp, so I stand on a dry board.
- Keep the cable away from the water line. A loose cable near the pipes is the most likely cause of trouble.
- Mark the valve position first, so I do not force the stem the wrong way when I refit the actuator.
- Tell someone, such as [[Kalglon Dithsel]], when I will be in the shed alone for a longer job.
- Keep fingers out of the coupling while the unit is connected. The motor can start without warning if the controller gets a signal.

After finishing, I test the valve slowly by hand and then let it run one full cycle while I watch.

## Problems

These are the problems I have seen with the Vustior valve actuator, and what I did about each.

**Slow or weak movement.** This usually happens after several dull days, when the battery is low. I check the voltage with the multimeter and wait for sunny weather. If the problem repeats, I look again at [[Kuglend solar charger plan]] to see whether the panel is too small or shaded.

**Valve does not fully close.** The coupling can slip a little on the stem. I tighten it with the spanner after checking my pen mark for the correct position. Sometimes there is also algae or grit in the valve, and cleaning it helps.

**No movement at all.** First I check the battery, then the terminal block for loose wires. Damp in the shed has corroded a terminal once, and a wipe with a dry cloth and a firm re-seat of the wire fixed it.

**Wrong timing.** If the valve moves at odd moments, I compare what happened with [[Faerkpioth level sensor log]]. Usually the sensor reading was wrong, not the actuator.

**Faded label.** The label on the blue housing has faded, so I wrote the part number in the Parts section above. I should replace the label with a waterproof one.

**Things to do.** Add a small cover over the cable entry, keep a spare coupling, and write down the results of the next check in [[Trarkti workshop notes]].
