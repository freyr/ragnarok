---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Drarktend Sunnarzio."
---

# Drarktend Sunnarzio

## Schedule

Drarktend Sunnarzio is an electrician who works on the electrical side of my aquaponics setup. The only time he is free is evenings, so I plan everything around that. I do not call during the day expecting an answer. The contact method that works is in person, so I have to catch him face to face and agree on a time then and there.

What I keep in mind when planning a visit:

- He is available in the evenings only, so any job that needs daylight has to be split up. I do the daylight part first and leave the electrical part for him.
- Contact is in person. I do not rely on messages, and I write down what we agreed right after we talk.
- I try to ask a few days ahead, because evening slots fill up.
- If a job needs two evenings, I ask for both at the start so we do not lose momentum.

I have known him since 2020, so he knows the layout of the system well. That saves time on every visit, because I rarely need to explain where the pumps, the grow beds and the fish tanks sit.

When I meet him, I bring a short written list of what I need, so the conversation is quick and nothing gets forgotten. Evenings are short, and I do not want to spend half of one on explaining.

## Checklist

Before he arrives for an evening job, I go through this list:

- Clear access to the electrical panel and any junction boxes.
- Turn off whatever can safely be turned off, but leave the fish life support running unless he tells me otherwise.
- Prepare a backup way to aerate the tanks in case power has to go off for a while.
- Have good lighting ready, since evenings are dark in the grow area.
- Dry the floor around the work area and remove any standing water.
- Put out a list of the problems I have noticed, with notes on when they happen.
- Note which circuits feed the pumps, the heater, the lights and the aeration.
- Keep the old notes from the last visit nearby.

After the work:

- Test each circuit with me present.
- Check that all the pumps restart properly.
- Look at the water level in the tanks and beds.
- Write down what was changed, on which circuit, and why.
- Agree on whether a follow-up is needed and arrange it in person before he leaves.

## Costs

I do not keep exact prices in this note, because they change and I would rather check them each time. What I do record is how costs usually work with him.

- He tells me the cost of the job after he has seen the work, not before, so I ask for an estimate at the first visit.
- Materials are a separate item from his time. I buy simple things myself when I can, such as cable clips and basic fittings.
- Anything that has to be specially ordered I discuss with him first, so I do not buy the wrong thing.
- Evening work can take longer because of the limited time, so a bigger job may be spread over several visits and the cost is split accordingly.

A rule I follow: ask for the total before the work starts, and write it down. If the scope grows, we talk again in person before continuing. A running tally of what I have spent on electrical work for the aquaponics system is worth keeping, because it helps me decide whether to repair or replace a failing item.

## Safety

Water and electricity share the same space in an aquaponics system, so safety is the main reason I use a qualified electrician at all.

- All fixed wiring and any new circuits are done by Drarktend, not by me.
- Everything near water must be protected by proper residual current protection, and I ask him to confirm it is working whenever he is on site.
- I never touch a socket, a pump or a heater with wet hands, and I unplug equipment before putting my hands in the water.
- Cables are kept above the splash zone and above the floor where water could pool.
- Connections are in sealed, rated boxes, not loose or taped.
- If something smells hot, trips often, or makes the water tingle, I switch it off and wait for him.

Being in the tanks while power is on is a risk for me and the fish. Before any work, we agree which parts are switched off and which stay on. Because he works evenings, I make sure the light is enough to see clearly. Poor light is a hazard on its own.

## Tools

He brings his own testing and fitting tools, and I do not lend mine for electrical jobs. I keep a few things ready so the evening goes smoothly.

- A strong torch or work lamp, with a spare.
- A step ladder that is stable on a dry floor.
- A small bucket and towels for drips.
- Spare cable ties and clips for tidying cables after the work.
- A notebook and pen for recording the work.
- A basic plug-in tester, which I use for quick checks between visits.

What he typically uses includes a meter for checking voltage and continuity, an insulation tester, and the usual hand tools. I do not touch these. When I want a repair done in a particular way, I describe the result I want and let him choose the method.

I keep my own tools in a labelled box near the panel so that I can find them quickly in the evening.

## Problems

Here are the kinds of problems I have called him about, and what I note down each time.

- Pumps that stop without warning. I note the time and whether the breaker tripped.
- A circuit breaker that trips when it rains or when humidity is high.
- Flickering grow lights, which usually point to a loose connection.
- A heater that does not hold its temperature.
- Sockets that feel warm.
- Aeration that stops overnight, the most worrying because fish suffer quickly.

For each problem I record what I saw, when it happened, what was running at the time, and what I did. This makes his diagnosis faster, because he can see patterns. When the cause is unclear, he may ask me to watch the system for a few days and tell him when I next see him.

A practical issue is that he is only free in the evening and I can reach him only in person. If a failure happens suddenly, I cannot call him right away. So I keep a basic emergency plan: switch off the faulty item, keep the aeration going by a safe backup, and speak to him at the next opportunity.

## History

I have known Drarktend since 2020. He was recommended to me when I first set up the system and needed someone qualified to look at the wiring. Since then he has become the person I turn to for anything electrical.

Over the years, the work has covered:

- The first check of the wiring, when I started the system.
- Adding circuits as I expanded the number of grow beds.
- Moving cables away from places where water could reach them.
- Replacing worn sockets and fittings.
- Fixing nuisance tripping.
- Inspections after storms or after I changed equipment.

What I value is that he explains what he is doing and why. I have learned a lot from watching him, and I now spot early warning signs I used to miss. The relationship has stayed practical and simple: I ask in person, he comes in the evening, we do the work, and I write it down.

## Contracts

The contract date of Drarktend Sunnarzio is 2018-01-11.

This is the date I have recorded for his contract. I keep the written agreement together with my other system papers. The agreement covers the type of work he does for me, which is electrical work on the aquaponics system, and the way we arrange visits, which is in person and in the evenings.

Points I check when I review the contract:

- The scope of work is still correct for what the system has become.
- The arrangement for evening visits still suits both of us.
- It is clear who buys materials and who does the testing.
- Any changes agreed in person are written down and added to the papers.

Because we arrange most things face to face, I make a note after each conversation so that the written record stays current. If the system grows much larger, I will talk to him about updating the agreement so that it matches the real work.
