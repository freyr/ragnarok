---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Dunpirbae workshop."
---

# Dunpirbae workshop

## Schedule

The Dunpirbae workshop is a medium-sized workshop built for aquaponics work. It sits below ground and faces west, so the low afternoon light comes in only through the high windows at the top of the west wall. I plan my visits around that, because the room gets dim early in the day.

My usual weekly rhythm:

- Monday morning: walk the whole room, read the tank gauges, and write down anything odd before touching anything.
- Wednesday: water testing. I check ammonia, nitrite, nitrate, pH and temperature in the fish tanks and in the grow beds.
- Friday: feeding review, filter rinse, and a look at the plant roots for slime or browning.
- Saturday, every second week: deeper cleaning of the sump and the floor drains.

Seasonal tasks:

- Early spring: start seedlings on the shelf nearest the west wall, where it is warmest in the evening.
- Midsummer: watch the room temperature, since the below-ground position keeps it cool but humidity climbs.
- Late autumn: check the heaters and insulate the exposed pipe runs.
- Midwinter: reduce feeding and keep the pumps running without a break.

I try not to schedule more than two hours in the room at a stretch. The air gets heavy, and I make more mistakes when I am tired.

## Checklist

Before I leave the workshop, I go through this list every time:

1. Pumps are running and I can hear the water return to the tanks.
2. Water level in the sump is above the marked line.
3. Air stones are bubbling in every fish tank.
4. Heater switches are in the right position for the season.
5. Lids are back on the feed bins.
6. Floor is dry near the electrical boards.
7. Test kit is closed and put back on its shelf.
8. Notebook is updated with the readings.
9. Door is shut and the light is off.

Quick start-up check after a power cut:

- Reset the pump breaker first.
- Wait a minute, then restart the grow bed siphons.
- Check that the fish are not gasping at the surface.
- Test the water the next day, not straight away.

## Problems

Known issues in this room, with what I do about each one.

**Damp walls.** Because the workshop is below ground, the lower part of the walls stays damp. I keep shelving away from the wall by a hand's width and wipe down mould spots with a weak vinegar mix.

**Humidity in summer.** The grow beds add moisture. A dehumidifier helps, but I have to empty it often. A small fan across the beds also helps.

**Drain smell.** If the floor drains smell sour, I flush them with clean water and check whether the trap has dried out.

**Pump noise.** The main pump hums when the intake is partly blocked. I clean the intake screen first, then check the impeller.

**Algae on the west side.** The window light on the west side feeds algae in the nearest grow bed. I hang a dark cloth over the glass in summer.

**Power sockets.** Some sockets are old. I do not plug more than one heavy load into any one of them.

A typical log extract from the day I tracked a pump fault:

```
Mon  pump A hum louder than usual, flow looks normal
Tue  intake screen cleaned, hum reduced
Wed  nitrate fine, pH slightly low, added buffer
Thu  hum back after lunch, impeller checked, small snail shell found
Fri  shell removed, pump quiet, flow normal
```

## Admin

The workshop is held under a lease, and the lease reference is LR-885412. I keep the paper copy in the blue folder in the office drawer and a scan in my documents.

Other admin points:

- Renewal conversations should start well before the end of the lease term, so I put a reminder in my calendar a few months ahead.
- Any change to the plumbing or wiring needs a written note to the landlord first.
- Insurance covers the equipment but not livestock losses, so I keep that in mind when stocking tanks.
- Visitors sign the sheet by the door. This matters because the room is below ground and I want to know who is inside.
- Water and electricity bills come together. I compare them with my own notes every quarter to spot leaks or pumps drawing too much.

Contacts are kept in my address book under the workshop name, not in this note.

## Supplies

What I keep stocked in the room and where it lives.

**Water care**
- Test kit reagents for ammonia, nitrite, nitrate and pH, on the top shelf by the door.
- pH buffer and a small bottle of dechlorinator.
- Spare tubing in two diameters.

**Fish**
- Pellet feed in sealed bins under the bench.
- A small net, a bucket with a lid, and a spare air pump.

**Plants**
- Clay pebbles for the grow beds, stored in sacks on the pallet.
- Seed trays and labels.
- Mesh pots in a stack beside the west shelves.

**Maintenance**
- Spare O-rings and fittings in a tin.
- Cable ties, tape and a roll of dark cloth.
- Gloves, a scrubbing brush, and a towel for drying hands before touching the electrics.

I reorder when a bin is down to a quarter. Feed and reagents are the two things I never want to run out of.

## History

The workshop was built in 2001. It began as a plain below-ground room used for storage, and the aquaponics use came later, once the idea of running fish and plants in a closed loop seemed workable in a space with steady temperatures.

Over the years the main changes were:

- The first tanks were small and sat directly on the floor. They were later raised onto frames to make cleaning easier.
- The grow beds were added along the west side to use the little natural light available.
- The wiring was redone in part after an early scare with a wet socket.
- The drains were improved after a flood caused by a blocked outlet.
- A dedicated sump was added so that water volume stayed steady when the beds drained.

I still remember the first winter, when the room stayed cool enough that the fish barely ate. That taught me how much the below-ground position helps with temperature, and how much it hurts with damp.

## Setup

Summary of the room as it stands.

- **Kind:** workshop
- **Area:** aquaponics
- **Orientation:** west
- **Size:** medium
- **Year built:** 2001
- **Floor:** below ground

Layout, from the door inward:

1. Bench and storage on the right, with the test kit and notebook.
2. Fish tanks in the middle on raised frames.
3. Sump under the tank frames, with the main pump beside it.
4. Grow beds along the west wall, under the high windows.
5. Seedling shelf at the far end.

Water flows from the fish tanks to the sump, through the filter, then up to the grow beds, and drains back by gravity. The pumps and heaters are on separate breakers so I can isolate one without stopping the other.

Lighting is a mix of the west windows and a few grow lights over the seedlings. The grow lights are on a timer, which I check each Monday. Ventilation is a single extractor fan near the door, and I leave the door slightly open on the days I work inside.

When something changes in this setup, I update this section first, then adjust the checklist and schedule to match.
