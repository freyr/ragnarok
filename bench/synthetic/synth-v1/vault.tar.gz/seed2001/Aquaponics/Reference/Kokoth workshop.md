---
type: reference
status: active
project: reference
area: aquaponics
---

# Kokoth workshop

## Risks

The Kokoth workshop is a small workshop on the ground level, built in 1999, with its main face toward the east. It serves the aquaponics area. Because it sits at ground level, most of its risks come from water and from the way the building is used.

- Water on the floor is the biggest everyday hazard. Fish tanks, grow beds and plumbing all sit close to the work benches, and a leak can spread fast on a ground-level slab.
- Electrical equipment shares space with wet work. Pumps, heaters and air blowers all need power, and the sockets are not far from the splash zone.
- Because the workshop is small, there is little room to step around a problem. A spill, a dropped tool or an open crate can block the only clear path.
- The building dates from 1999, so I should assume some fittings, seals and wiring are old and may fail without much warning.
- The east orientation means the morning sun comes straight in. On warm days the room heats up early, which stresses the water and anything stored near the windows.
- Chemicals for water testing and cleaning are kept in the same room as the equipment. Mixing or spilling them near the tanks could harm the fish.

I treat a power cut as a risk too. If the pumps stop, the water stops moving, and I need to notice quickly. A small workshop has no spare room for a backup setup, so any fix has to be compact.

## Lessons

Years of using a small ground-level workshop have taught me a few plain things.

- Keep everything off the floor where possible. Shelves and hooks save tools and parts from the water that always ends up down there.
- Put a drip tray under anything that holds water, even if it has never leaked.
- Do one task at a time. In a small room, starting three jobs at once leads to a mess and to mistakes.
- Label every container. Unmarked bottles in an aquaponics area are a bad idea.
- Check the pumps first when something looks wrong. Most problems with the system trace back to flow.
- Shade the east side before the warm season, not after the first hot morning.

I also learned that the age of the building matters. A workshop built in 1999 has had a long time for small problems to build up, so a quick walk around once a week catches more than a big inspection once a year.

Another lesson is about tidying. Because the space is small, ten minutes of putting things back at the end of a session saves far more than that the next time I come in.

## Admin

The paperwork for the Kokoth workshop is short, but I want it in one place.

- Name: Kokoth workshop
- Kind: workshop
- Area: aquaponics
- Orientation: east
- Size: small
- Year built: 1999
- Floor: ground level
- Lease reference: LR-208872

The lease reference is the number to quote whenever I contact anyone about the lease, the premises or a repair that falls under the owner. I keep it with the other papers and copy it exactly when I write it down.

Things to keep up on the admin side:

- Keep a copy of the lease where I can find it quickly.
- Note any repair I do myself, and whether it was agreed with the owner first.
- Keep receipts for equipment that stays in the workshop.
- Write down who to call for water, power and building problems.

I should also record any change to the layout that might touch the lease terms, such as new pipework or a new electrical line. It is easier to ask first than to explain later.

## Ideas

A few improvements I would like to try, roughly in order of how useful they seem.

- Add a simple water sensor on the floor near the tanks, so a leak makes a noise before it becomes a puddle.
- Fit a light shade or film on the east windows to cut the early heat without losing daylight.
- Build a wall rack for hoses, nets and small tools, to free the bench and the floor.
- Mount a small battery-backed air pump as a stopgap during power cuts.
- Put a tray or raised grate by the door, so wet boots do not carry water across the room.
- Paint a clear walkway line on the floor to remind me to keep the path open.
- Set up a small folder, paper or digital, with a one-page checklist for the weekly walk-around.

Some of these cost very little and could be done in an afternoon. The shade and the rack come first, because they help with two of the problems I mention in the risks section: heat and clutter. The sensor is more valuable than it sounds, since a ground-level room hides leaks until they are large.

I would also like to think about whether the workshop layout could be turned around so the benches face away from the east light. That may not be practical in such a small room, but it is worth a sketch.

## Observations

The Kokoth workshop is small, and that shapes almost everything about how I use it. Two people can work in it, but not comfortably. Being on the ground level makes carrying heavy items easy, which is a real advantage for an aquaponics area where buckets of water, bags of media and crates of plants move in and out all the time.

The east orientation gives a bright start to the day. The light is good for checking the water and the plants early on, and the room feels pleasant in the morning. By midday the strongest sun has moved on, so the heat is mostly an early problem.

The building from 1999 shows its age in small ways: worn seals, marks on the floor and a few fittings that no longer sit quite right. None of this stops the work, but it is a reminder to keep an eye on the basics.

Things I tend to notice on a normal visit:

- The sound of the pumps, which tells me quickly if something has changed.
- Damp patches near the tank legs and along the pipe runs.
- How full the bins and shelves are, which shows when the room is getting crowded.
- The temperature near the east wall compared with the far side.

Overall, the workshop does its job well for an aquaponics area. Its limits are mostly size and age, and both can be handled with regular checks, tidy habits and a few small upgrades.
