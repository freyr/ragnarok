---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Kalglon Dithsel."
---

# Kalglon Dithsel

## Ideas

Kalglon Dithsel is my neighbor, and the area we work on together is aquaponics. I have known him since 2016. This note is a reference for how I deal with him and what we have talked about. It is not a project plan.

Ideas that have come up in our conversations over the years:

- Share the cost of a spare pump so neither of us is stuck when one fails. The pump details are in [[Lardu circulation pump notes]].
- Compare notes on water level sensing. He prefers simple float switches. I lean toward the setup described in [[Zaethlu level sensor handbook]]. We could each run the other's choice for a season and see which holds up.
- Try a joint bulk order of grow media and fish feed, since both of us run out at the same awkward times.
- Use the waste heat from his small workshop to take the chill off the fish tank in winter. This needs thought about the exchanger, see [[Kriosnal heat exchanger]].
- Swap seedlings. He grows leafy greens well, and I do better with herbs.
- Set up a shared notebook, paper or digital, of water test readings so we can spot seasonal patterns across both systems.

None of these is committed. I keep them here so I can raise one when we next talk, without having to remember who suggested what.

## Schedule

Kalglon's availability is weekdays. I treat that as the rule and do not try weekends, even though he is next door. He has said more than once that weekends are for his family, and I respect that.

His preferred contact method is email. He answers email reliably within a working day or so. A knock on the door is fine for something small, but only on a weekday, and not during the middle of the day when he is usually busy with his tanks.

How I plan around this:

- If I need advice about something that will go wrong quickly, such as a pump stopping or a tank temperature drifting, I email early in the week so there is time for a reply and a visit before the weekend.
- For anything that needs hands-on help, I propose a weekday and let him choose the hour.
- Routine exchanges like seedlings, borrowed tools, or returning containers happen on weekdays too.
- I avoid asking for favors the day before I leave on a trip. If I need someone to look at my system while I am away, I ask well ahead.

Because of the weekday limit, anything urgent over a weekend has to be handled by me alone. I keep a printed checklist near the system for that reason.

## Safety

Most safety issues around aquaponics are about water, electricity, and handling fish and plants hygienically. Kalglon is careful about all three, and I have picked up some habits from him.

- Keep every mains connection above the likely water line and use a drip loop on cables. He was strict about this the first time he looked at my setup.
- Use a residual current device on the circuit that feeds pumps and heaters. He will not work on a system that does not have one.
- Dry hands before touching a plug. It sounds obvious, but wet hands near a tank are how mistakes happen.
- Wash hands after working in the water, and keep tank tools separate from kitchen tools.
- Do not mix cleaning chemicals near the system. Anything that gets into the water can harm the fish and the bacteria that make the whole thing work.
- When we work together, one person handles power and the other handles water. We switch off and unplug before anyone puts a hand in.

If I am helping at his place, I follow his rules, not mine. If he is helping at mine, he does the same. That has avoided any argument.

## Tools

We lend each other tools, and I keep a mental ledger, but it is better to write it down. Items that have moved between our houses:

- A hand-held water test kit. His is more complete than mine, and I borrow it when something looks wrong.
- A small submersible pump for emptying tanks and moving water during cleaning.
- Plumbing fittings, tubing cutters, and a deburring tool for pipe ends.
- A basic thermometer pair, one for air and one for water, which we compared once against each other to see how far apart they read.
- A net and a bucket set for moving fish when a tank needs cleaning.

Rules we follow: return tools clean and dry, say so if something broke, and never lend a borrowed item onward. I log my own equipment in other notes, such as [[Zindzalon solar charger log]] for the power side and [[Zaethlu level sensor handbook]] for sensing. His tools are not in those notes because they are his, but I note here what I have borrowed so I remember to bring it back.

When I buy a tool that I will use rarely, I first ask whether Kalglon already has one. Often he does.

## Risks

The main risks I see in this relationship and in the shared hobby are practical rather than personal.

- Single points of failure. If both of us rely on the same supplier for feed or media, a supply problem hits both at once. We have talked about keeping a small reserve.
- Disease spreading between systems. If we swap plants, water, or fish, we could carry pathogens or pests from one tank to another. We agreed to quarantine anything that moves between our setups.
- Over-reliance on his advice. He is knowledgeable, but his system is not mine. What works in his conditions may not suit mine, so I test before copying.
- Availability. Because he is only reachable on weekdays, a weekend emergency is mine to solve. I should not plan around him being there.
- Borrowed equipment failing while in my care. I try to use borrowed gear only when I am present and watching it.
- Misunderstandings by email. Short messages can be read the wrong way, so I write clearly and confirm times back to him.
- Power cuts. A long outage stops the pumps and can harm the fish quickly. I plan for it separately, using what I learned in [[Zindzalon solar charger log]].

## Lessons

Things I have learned from knowing Kalglon Dithsel since 2016, mostly about aquaponics but also about being a good neighbor.

- Slow changes are better than fast ones. When I wanted to rebuild my whole system in a weekend, he suggested changing one thing at a time and watching for a few weeks.
- Measure before adjusting. His habit of writing down readings has made me do the same.
- Ask early. Many of my worst problems got worse because I waited to ask for help.
- Keep the plumbing simple. Every extra valve and joint is another place for a leak.
- Take notes on pumps. Flow drops gradually, and without records it is easy to miss. My own observations are collected in [[Lardu circulation pump notes]].
- Be a reliable borrower. Returning things promptly and in better shape than I received them has kept the arrangement easy for years.
- Respect time. His weekday availability is not an inconvenience, just a fact of his life, and working with it has kept things friendly.
- Share results, including failures. He once told me about a whole batch of seedlings he lost, and it was more useful than any success story.

## Observations

Here are things I have noticed about how Kalglon works and how his setup behaves, as a neighbor looking over the fence and sometimes through the door.

He is methodical. His tanks are labeled, his tubing is tidy, and his records are on paper in a binder. He checks the system at the same time each day. I have rarely seen him rushed.

His system seems to be stable in a way mine is not. He keeps stocking levels modest, so the water chemistry does not swing much. I tend to overstock and then chase problems.

He is slow to adopt new gadgets. Sensors, controllers, and apps get tested for a long time before they replace something manual. I find this frustrating sometimes, but his failures are rarer than mine.

He answers email in complete, short sentences. If a question needs a visit, he says so directly and suggests a weekday.

Plants in his grow beds respond well to the warmth he gets from his workshop side of the house. That is what started my interest in using heat more deliberately, which connects to [[Kriosnal heat exchanger]].

He is generous with advice but does not push it. If I ignore a suggestion and it fails, he does not say anything about it.

## Supplies

Supplies that Kalglon and I either share, swap, or compare notes about:

- Fish feed. He tries different brands in small amounts and tells me which fish seem to prefer them. I ask before changing anything.
- Grow media such as clay pebbles. We have discussed buying together to reduce delivery effort.
- Water conditioners and test reagents. Reagents expire, so splitting a larger set sometimes makes sense, as long as we label what we pour off.
- Seeds and seedlings. These are the most frequent exchange, and always informal.
- Spare tubing, clamps, and connectors. He keeps a drawer full of them.
- Replacement parts for pumps and sensors. We do not share these as freely because the fit matters, but we compare what we use. See [[Lardu circulation pump notes]] and [[Zaethlu level sensor handbook]].
- Power-related items such as batteries and cabling, which I mostly track in [[Zindzalon solar charger log]].

I keep my own stock list elsewhere. This section only records what passes between us, so I know what I owe or am owed. Nothing is formally charged. If something is large, we simply agree out loud who pays what.

## Maintenance

Maintenance is where Kalglon has taught me the most. His routine is regular and boring, which is exactly why it works.

Daily: look at the fish, check the water is moving, listen to the pumps. Anything unusual gets noted.

Weekly: test water, clean pre-filters, check for leaks, trim plants. He wipes down surfaces where algae builds up.

Seasonal: a deeper clean of tubing and tanks, inspection of seals and fittings, and a check of electrical connections for corrosion. He also reviews whether pumps are still delivering the flow he expects.

What we do jointly:

- Compare water test readings when something seems off. If both systems show the same trend, the cause is likely outside, such as the local water supply or weather. If only one does, the cause is local.
- Help each other with big cleanouts, which are easier with two people. Those happen on weekdays by arrangement.
- Check on each other's systems during short absences, though only after a clear handover of instructions.

My own equipment maintenance notes are in other pages, including [[Lardu circulation pump notes]] and [[Zaethlu level sensor handbook]]. For heating, I refer to [[Kriosnal heat exchanger]].

## Background

Kalglon Dithsel is my neighbor. I have known him since 2016, which is when I first moved close enough to see his greenhouse and fish tanks from my own yard. We started with a polite wave and a few remarks about the weather, and the first real conversation was about why my plants were turning yellow. He guessed a nutrient problem related to the water, and he was right.

His area is aquaponics, and that has been the common thread ever since. He had been running his system for some time before we met, and he has gone through several changes of design. He started with a simple single-tank layout and gradually added more beds and better filtration.

Over the years our relationship has been practical and friendly rather than close. We are not in each other's houses often, and we do not socialize much outside the hobby. But we trust each other with tools, advice, and the occasional favor.

Contact is by email, and he is available on weekdays. I keep these facts at the top of my mind because they shape how and when I ask for anything. Summary of the key properties:

- Role: neighbor
- Area: aquaponics
- Contact: email
- Availability: weekdays
- Known since: 2016

## Contracts

There is one formal item between Kalglon Dithsel and me. The contract date of Kalglon Dithsel is 2021-02-19. That is the day we wrote down our arrangement about sharing certain equipment and costs, after several years of handling it by word of mouth.

The contract is short and plain. It covers:

- Which items are jointly owned and which stay with their original owner.
- How we split the cost of shared purchases such as a spare pump or a bulk order of feed.
- What happens if something breaks while one of us is using it.
- How either of us can step out of the arrangement without hard feelings.
- That communication for anything important goes by email, so there is a written record.
- That requests for help are made for weekdays, matching his availability.

We wrote it mainly to avoid forgetting and to avoid awkward conversations. It was never intended to be strict. If something unusual comes up, we talk about it and adjust.

I keep the signed copy with my other household papers. If I ever need to review the terms, I should check there rather than rely on memory. Any change in the arrangement should be agreed by email and noted here with the reason.

## References

Notes that connect to this one:

- [[Lardu circulation pump notes]]: my records on pump behavior, flow changes, and spares, which Kalglon has helped me interpret.
- [[Zindzalon solar charger log]]: the power side of my setup, relevant to outage planning and backup.
- [[Zaethlu level sensor handbook]]: how I measure water level, and the point where our approaches differ from his float-switch preference.
- [[Kriosnal heat exchanger]]: the heating idea we have discussed using waste warmth from his workshop.

Other sources of information are mostly people and habits rather than documents:

- Kalglon's own paper binder of readings, which he has occasionally let me look at.
- Email threads with him, which I keep so I can find earlier advice. I search by topic when I need to remember what he said.
- Local supplier catalogs and instructions that came with equipment, which I store with each equipment note rather than here.

If I add new notes about shared projects, I should link them here so this page stays a useful starting point.

## Problems

Problems that have come up, or that I expect to come up, in dealing with Kalglon and in the shared hobby.

- Timing mismatches. Because he is available on weekdays only, I have sometimes had to wait for answers while something was going wrong. The fix is to ask earlier and to be able to cope alone.
- Unclear ownership. Before our written arrangement, it was sometimes uncertain who owned a tool or part. That is mostly solved, but small items still drift.
- Email delays. Rarely, a message goes unanswered. I have learned to follow up once, politely, rather than assume he saw it.
- Differences in approach. He prefers proven simple methods and I like to experiment. This occasionally leads to polite disagreement about whether a change is worth making.
- Pump trouble. Flow loss and noise in my system have been repeating issues, tracked in [[Lardu circulation pump notes]].
- Sensor drift and false readings, which led me to read [[Zaethlu level sensor handbook]] more carefully.
- Winter temperature swings, which started the heating discussion and the notes in [[Kriosnal heat exchanger]].
- Power interruptions affecting both of us, with backup ideas in [[Zindzalon solar charger log]].

None of these has damaged the relationship. They are logistics.

## Open questions

Things I still want to settle or find out.

- Should we revisit the contract from 2021-02-19 and update it to reflect what we actually share now? Some items have changed hands, and some purchases are not covered.
- Would he be willing to try one of my sensors alongside his floats for a season, so we have a real comparison?
- Is the workshop heat idea realistic? I need to know how much warmth is available and at what times, and whether the exchanger approach would work without upsetting his own use of the space.
- Can we agree on a regular weekday check-in by email, perhaps once a month, instead of only writing when something is wrong?
- What is his plan if he reduces or stops his system? I would like to know whether any shared equipment would come back to me.
- Would a joint reserve of spare parts make sense, and who would hold it?
- How should we handle a long outage affecting both of us? A shared plan might be better than two separate ones.
- Is there anything I could offer him in return for all the advice? So far I have mostly taken, and I would like to balance that.
