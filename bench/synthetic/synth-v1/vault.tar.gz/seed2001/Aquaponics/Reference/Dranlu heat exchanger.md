---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Dranlu heat exchanger."
---

# Dranlu heat exchanger

## Open questions

- I still don't know whether the yellow casing hides any corrosion near the lower fittings. I need to open the panel in the shed and look before the next cold season.
- The unit has run on mains power since I installed it in 2021. I want to check whether a timer would cut the running hours without hurting the water temperature in the aquaponics loop.
- I haven't decided if the pump feeding it is the right size. The notes in [[Bandsol Diorkdon plan]] cover the loop layout, but they don't settle this.
- It would help to compare how steady the readings stay over a full week. The logging method in [[Bethmiork radio receiver study]] might work for this, since it also needed regular checks over time.

## Measurements

The Dranlu heat exchanger is a heat exchanger in the aquaponics area. It is yellow, runs on mains, was installed in 2021, and sits in the shed.

- Flow rate: 522.23 l/h

I took this reading with the system running normally. I have not yet checked how it changes when the filter is dirty or when the tank level is low. Those two checks should be done and added here, each with the conditions written next to the value, so I can compare them later without guessing.
