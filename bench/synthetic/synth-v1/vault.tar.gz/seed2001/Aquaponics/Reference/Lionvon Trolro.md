---
type: reference
status: active
project: reference
area: aquaponics
description: "Reference about Lionvon Trolro."
---

# Lionvon Trolro

## Ideas

Lionvon Trolro is my neighbor, and the main thing we talk about is aquaponics. I know him in person only. I do not have a phone number or a message thread for him, so every idea below has to be raised face to face. He is usually around on weekdays, so that is when I try to catch him. I have known him since 2022.

Quick facts, so I do not have to search for them later:

| Property | Value |
|---|---|
| Role | neighbor |
| Area | aquaponics |
| Contact | in person |
| Availability | weekdays |
| Known since | 2022 |

Ideas I want to try or talk over with him:

- Ask him how he sizes the grow bed against the fish tank. My own guess is still rough, and I would like to hear what he does in practice.
- Compare how we each handle the pump schedule. Mine runs on a simple timer, and I suspect his is more careful.
- Borrow his way of checking water before and after a feeding, then write it down in my own notes instead of relying on memory.
- Look at running the pump from a small solar setup. My earlier work on this is in [[Firkglor solar charger tests]], and the unit I keep coming back to is the [[Kubupur solar charger]].
- Ask whether he would swap spare seedlings for some of my surplus herbs.
- Go through the older material in [[Methreth Bentroputh notes]] with him, since he may recognize some of the methods.

When I do get a chance to talk, I should bring a pen and write down what he says right away. Casual chats over the fence are easy to forget.

## Open questions

These are things I still do not know. I want to ask him in person, on a weekday, and then move the answers somewhere more permanent.

- Which fish does he keep, and why did he choose them over the alternatives?
- How often does he clean the filter, and does he do it on a fixed schedule or by looking at the water?
- What does he do in cold weather? I do not know whether he heats the tank, insulates it, or just lets the system slow down.
- Does he buy feed or make his own?
- Has he ever lost a whole tank, and what did he learn from it?
- Would he be willing to look at my setup and tell me what is wrong with it? I do not want to ask too much of a neighbor, so I should offer something back.
- Is the shed arrangement he uses something I could copy? I should compare it with what I wrote in [[Lorzera shed log 2023]].

One practical problem: because I can only reach him in person, a missed weekday means waiting for the next one. I should keep a short list in my pocket so I can ask several things at once when I see him.

## Contracts

There is nothing formal between us in the legal sense, but there is one agreement I want on record. The contract date of Lionvon Trolro is 2022-10-08. That is the day we agreed on how we would share the work and the supplies for the aquaponics project.

What the agreement covered, as I understand it:

- We would each keep our own tank and our own equipment.
- Shared consumables would be split roughly evenly, and whoever buys first gets paid back later.
- Advice goes both ways, with no charge.
- If either of us stops, the other keeps whatever is on their own side of the fence.

Because it was only spoken, I should write down any changes right away. If we ever change the terms, I will add a line here with the new arrangement. For now this is the only agreement and nothing else is in force.

## History

I have known Lionvon since 2022. He lives next to me, and we met over the fence while I was struggling with an early version of my own aquaponics setup. He looked at it, said a few plain things about the water flow, and offered to come back and see how it was going. That was the start of the regular weekday conversations we still have.

A rough timeline, as far as I remember it:

- **2022:** First meeting as neighbors. A few weeks later we made the agreement described under Contracts. I started taking notes after each talk.
- **2023:** Most of the practical work happened this year. I kept track of the shed and the equipment in [[Lorzera shed log 2023]], and some of his advice shows up there. This was also when I began testing solar power for the pump.
- **Later years:** The talks became less frequent but more focused. Instead of general questions, I now ask about specific problems, and he usually answers in a few sentences.

What I have learned from him over time is mostly practical. Keep the system simple. Check the water often. Do not change several things at once, because then you cannot tell which one helped. I try to follow all three, and my notes are better for it.

I should keep adding to this section after every meaningful conversation, even if it is only a line or two. The goal is a record I can actually use later, not a polished story.
