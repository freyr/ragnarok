---
type: plan
status: active
project: brinddesze-rebuild
area: forge
description: "Plan about Piorstaer air compressor."
---

# Piorstaer air compressor plan

## Observations

The Piorstaer air compressor is a grey air compressor that belongs to the forge area, although it sits in the greenhouse. It runs on mains power. I installed it in 2018, so it has been working for a good number of years now.

The greenhouse is not an obvious place for a forge tool. I put it there because the forge itself gets too much dust and heat, and the compressor does better in a cooler, calmer spot. The air line runs from the greenhouse to the forge bench. The line is long, and I notice a small pressure drop when I use the grinder for a long stretch.

Things I have noticed so far:

- The motor starts harder on cold mornings, mostly in winter.
- Damp air in the greenhouse makes the tank collect water faster than I expected.
- The noise carries further than I planned, so I avoid running it early.
- The grey paint is chipping near the base where the condensation sits.

Ganzin Birksta looked at the setup once and said the mains socket was fine, but that I should keep the cable off the wet floor. I have done that since. See [[Ganzin Birksta]] for the longer conversation about the wiring.

## Lessons

The main lesson is that location matters as much as the machine. The greenhouse protects the compressor from forge dust, but it brings humidity. I should have planned for water from the start.

What I plan to do next:

1. Drain the tank after every working session, not once a week.
2. Fit a better water trap near the forge end of the line, where the air is used.
3. Lift the compressor onto a small stand so the base stays dry and the paint stops chipping.
4. Shorten the air line where I can, or use a wider hose to cut the pressure loss.
5. Check the cable route every season, especially after heavy rain.

I also learned not to wait for a problem before doing maintenance. After seven or eight years, small jobs like checking the fittings, cleaning the intake filter and listening for leaks take only a few minutes. Skipping them costs far more time later. I will keep a short log of each check so I can see how the machine changes over time.

A second lesson is about the forge work. Some tools need steady pressure, and the grinder is the worst for this. If the drop gets worse, I may switch to doing that job closer to the compressor, or use a small buffer tank near the bench.

## Parts

The part number I need when I order anything for the Piorstaer air compressor is QQ-6648-K. I should write it on the supplier order every time, because the shop does not always find the right item by name alone.

Parts I expect to need over the next while:

- Intake filter, to be replaced after cleaning no longer helps.
- Drain valve, since the current one is stiff and slow to seal.
- Water trap for the forge end of the air line.
- A wider hose and new couplings.
- Rubber feet or a stand for the base.

I will keep the old parts for a while after replacing them, in case the new ones do not fit and I need to compare.
