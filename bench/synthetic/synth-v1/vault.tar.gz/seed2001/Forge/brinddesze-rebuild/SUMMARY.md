---
type: summary
status: active
project: brinddesze-rebuild
area: forge
description: "Summary about Brinddesze rebuild."
---

# Summary of Brinddesze rebuild

## Supplies

The Brinddesze rebuild is a project with the goal of rebuild, in the forge area. It started in the summer of 2019, and the carpenter leads it. Right now it sits in the middle stage: the planning is finished, the buying is mostly finished, and the actual building is going in slow steps.

What I have on hand so far:

- Seasoned oak beams for the main frame, stacked under the lean-to and covered with a tarp.
- Cut stone for the hearth base, delivered and checked for cracks.
- Fire brick for the inner lining, enough for the first pass with some spare.
- Iron strapping and hand-forged nails for the roof joints.
- Clay and sand for mortar, stored dry in the shed.

What is still missing:

- Roof slate. I have only a partial stack, and the rest needs to be ordered.
- A new bellows leather. The old one is too cracked to reuse.
- A second set of tongs for the carpenter to use during fitting work.

The carpenter has asked that all timber stay off the ground until the frame goes up. I agree with that and have moved the beams onto stone blocks.

## Decisions

The go decision for the rebuild was made on 2021-10-17. Before that date the project was only a sketch and a list of wishes. After it, I committed to buying materials and to keeping the carpenter as lead.

Other decisions so far:

- Keep the original footprint of the forge. Widening it would mean moving the water barrel and the quench trough, and that is not worth the trouble.
- Use oak for the frame instead of pine. It costs more in effort to cut, but it will survive the heat and sparks better.
- Rebuild the hearth first, then the frame, then the roof. Doing the roof early would only trap smoke while I test the fire.
- Reuse the old anvil stand after a check for rot. It passed.

Open points:

- Whether to add a small side window for light. The carpenter is for it, I am undecided.
- Where to put the new tool rack so it stays out of the spark path.
- How to vent the smoke: a plain hood or a longer flue. I need to look at how the neighbors did theirs.

## Next action

The next action is NX-1238. It covers placing the order for the remaining roof slate and confirming the delivery with the supplier, so the roof stage does not stall once the frame is up.

After that is done, I will go through the open points with the carpenter in one sitting and settle the window and the vent. I want those closed before any wall is raised, because changing them afterward means cutting into finished work.
