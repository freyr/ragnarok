---
type: note
status: active
project: brinddesze-rebuild
area: forge
description: "Note about Trithluth Torkkind."
---

# Trithluth Torkkind notes

## Setup

This note collects everything I know about Trithluth Torkkind, the plumber I call when something in the house or workshop leaks, clogs, or refuses to heat. I keep it as a plain working file. When I need him, I want the practical facts in one place instead of scattered across texts and half-remembered conversations.

The basic facts:

- Name: Trithluth Torkkind
- Role: plumber
- Area: forge
- Contact: phone
- Availability: weekdays
- Known since: 2023

He works out of the forge district and does not do video calls or email. If I want him, I phone. I have learned not to send long text messages, because he answers them by calling back anyway. Weekdays are the only time he takes jobs, so anything that goes wrong on a weekend has to be contained until Monday. I have written down some containment steps further down.

I link this note from the house maintenance pages. The main links are [[Restiothve Lorkbran plan]], which covers the bigger renovation sequence, and [[Vithrel Biste]], who is the person I coordinate with when a job touches the shared wall. I also mention the [[Fiothzi dehumidifier]] and the [[Zeltrelzur solar charger]] below, because both ended up being part of plumbing conversations.

## Background

I met Trithluth in 2023, when a pipe under the workshop floor started weeping. Two other people had looked at it and both suggested ripping up a large section of floor. A neighbour who works near the forge told me to call him instead. He arrived on a weekday morning, listened for a while, tapped along the pipe with the handle of a screwdriver, and found the actual problem in a joint behind a wall. That fix was small and the floor stayed intact. That first visit is why I trust him.

Since then he has done a mix of jobs for me: replacing a tap, rerouting a drain, checking the water heater, and advising on how to deal with damp. He explains what he is doing while he works. He does not hurry, and he tells me plainly when something is not worth fixing. That honesty is the main reason I keep his number at the top of my contacts.

His style is quiet. He wears the same canvas apron every visit, brings a single metal toolbox, and asks to see the problem before discussing anything else. He prefers to look first and talk second. If I describe a problem over the phone, he usually says he will come and see it rather than guess.

I have never seen him use a screen or a catalogue. Everything is in his head or on a small paper pad. This is part of why I keep my own notes: his records are not something I can look up later.

## Overview

Here is the short version of how working with him goes.

1. I phone on a weekday, early if possible.
2. I describe the symptom, not my theory of the cause.
3. He either comes the same week or tells me how to hold things until he can.
4. He looks, explains, and gives a rough idea of the work.
5. We agree on the work out loud, and I write it down afterward.

He is reliable about turning up on the day he says. He is less reliable about the time of day, so I treat his arrival as a window. I do not plan anything else during that stretch.

What he is good at: finding hidden leaks, old pipework, drains that run slowly, and anything involving the way water behaves in a cold building. What he does not do: electrical work, anything structural, and anything involving gas. For those he tells me to find someone else, and he has never been wrong about where his limits are.

He knows the older buildings around the forge well, including how they were piped and where earlier repairs were hidden. That local knowledge is worth more than any tool he carries. When I asked about the layout of the pipes behind the workshop wall, he sketched it from memory and he was right.

## Problems

These are the recurring problems I have called him about, written so I can recognise them sooner.

**The weeping joint.** The original reason I called him. Symptoms were a damp patch on the floor, a faint smell of wet stone, and a slow loss of pressure. The cause was a worn joint in a wall cavity. If it happens again, I should shut off the water before anything else.

**The slow drain.** The kitchen drain gets sluggish every autumn. Trithluth says it is grease and fine debris, not a collapsed pipe. I should not pour anything harsh down it. He recommends hot water, a plunger, and patience, and he will come if that fails.

**Cold pipes in the workshop.** On the coldest days the supply line near the outer wall gets close to freezing. The fix was insulation and leaving a small trickle running overnight when the weather turns. He insists the trickle is cheaper than a burst pipe.

**Damp air.** Not strictly plumbing, but he was the one who pointed out that some of the damp was condensation and not a leak. That is why the [[Fiothzi dehumidifier]] now runs in the lower room. Before I bought it, I had been blaming the pipes for moisture that was just humid air meeting cold walls.

**Weekend failures.** Because he only works weekdays, I need my own plan. Shut the main valve, move belongings away from the wet area, and call on Monday morning. For something truly urgent, I do not rely on him at all.

## References

Places in my notes where this person or this topic comes up:

- [[Restiothve Lorkbran plan]]: the renovation sequence. Plumbing steps in it are marked as needing Trithluth, and he should be consulted before any wall is closed up.
- [[Vithrel Biste]]: the contact for the shared wall. When a pipe runs through or along that wall, Vithrel needs to know before work begins.
- [[Fiothzi dehumidifier]]: the device I run in the lower room. It came out of a conversation with Trithluth about condensation.
- [[Zeltrelzur solar charger]]: I use it to power small tools and a work lamp during jobs when the mains supply is switched off for safety. It is not part of his kit, but it has been useful on his visits.

Outside of my own notes, there is nothing written down about him. He has no website that I know of, no listing, and no business card beyond the one I was given. Everything I know comes from direct dealings. If he ever stops answering the phone, I do not have a second route to him, so I should ask the neighbour near the forge who first recommended him.

## Ideas

A few things I want to try or raise with him the next time he visits.

- Ask him to label the main shut-off valves with something durable. Right now I rely on memory, and in an emergency that is not good enough.
- Ask for a rough hand-drawn map of the pipe routes, which I can photograph and file next to this note. He drew one from memory once and I did not keep it.
- Discuss whether the outer-wall supply line should be rerouted during the next stage of the [[Restiothve Lorkbran plan]], so the cold-weather trickle is no longer needed.
- Consider a small drip tray and leak alarm under the sink and under the water heater. He thinks alarms are fine as long as I do not rely on them instead of looking.
- Keep a short list of questions in the phone notes so I do not forget something while he is in the building. He does not like returning for a single small question.
- Ask whether he would be willing to look at the plumbing before I buy any larger appliance, to avoid surprises.

## Schedule

He works weekdays only. Over time I have noticed a few patterns, though none of them are promises.

Early in the week he tends to be easier to reach. Late in the week his days fill up and he is more likely to say "next week". If I phone on a Monday with a problem that started over the weekend, he usually comes within a day or two. If I phone on a Friday, I should expect to wait.

For planned work, I try to book a few weeks ahead and confirm by phone the evening before. He does not mind the confirmation call. I also try to keep the area clear and accessible, which saves time and keeps the visit short.

When the work needs the water off, I plan the visit for a morning, so water is back on well before evening. I tell anyone else in the building in advance. For jobs touching the shared wall, I tell Vithrel Biste a few days beforehand, as noted in [[Vithrel Biste]].

Seasonal rhythm: autumn is busy for him with drains and heating, and the first cold snap brings a rush of frozen-pipe calls. I try to ask for pre-winter checks before the weather turns, not after.

## Safety

Plumbing safety is mostly about water, cold, and electricity in the wrong place. These are the rules I keep.

- Know where the main shut-off is, and make sure everyone in the building does too.
- Never work on a pipe that might still be under pressure. Close the valve, then open a tap to relieve it.
- Keep electrical equipment away from wet floors. If water has reached a socket or an extension lead, switch off at the board first, and only if the board itself is dry.
- Do not use heat near old pipes or wooden structure without asking him first. He has warned me about this more than once.
- Wear gloves and eye protection for anything involving old joints or chemicals.
- Do not mix cleaning products in a drain.

Trithluth does not handle gas, so I treat any smell of gas as a different emergency entirely: leave, ventilate, call the proper service.

For the work lamp and small tools, I use the [[Zeltrelzur solar charger]] when the mains is switched off, so I am never tempted to run a lead from another room across wet ground.

## Supplies

I keep a small stock so minor jobs do not wait for him. None of this replaces a visit, but it helps with containment.

- Thread tape and a spare set of washers for the kitchen tap
- A basic pipe clamp and repair sleeve for emergencies
- A bucket, towels, and a roll of heavy plastic sheeting
- A plunger and a drain snake
- A torch and the work lamp, charged
- Pipe insulation sleeves for the outer-wall line
- A marker and masking tape for labelling valves

He brings his own fittings and does not like me buying parts in advance, because I usually get the wrong size. If he needs something he does not have, he tells me what it is and either collects it himself or describes exactly what to buy. I write the description down at the time and attach it to the job note.

The [[Fiothzi dehumidifier]] needs its tank emptied regularly, so a spare container sits next to it. It is not strictly a plumbing supply, but it belongs in the same cupboard.

## Lessons

What I have learned from working with him:

- Describe symptoms, not conclusions. He finds the cause faster when I tell him what I see, hear, and smell.
- Small leaks are cheap to fix and large ones are not. I should call earlier than feels necessary.
- Not every damp problem is a plumbing problem. Condensation fooled me for a long time.
- A confirmed appointment is worth the extra phone call.
- Clear access saves time. Moving boxes before he arrives is part of the job.
- He is happy to explain, but not while I interrupt. I ask my questions after he has finished looking.
- Write things down right after the visit, while I still remember the details. He does not keep records for me.
- Respect his limits. When he says something is outside his work, he means it, and he is right.

I also learned that the cheapest advice is often the best. Insulation, a trickle of water on a cold night, and a regular look under the sink have saved me more than any repair.

## Tools

He travels light. One metal toolbox, a few wrenches, a small torch, a pipe cutter, and a hand pump. He uses a listening tool, simply a long screwdriver held to the ear, to trace leaks. It looks old-fashioned, but it works better than anything I have seen anyone else use.

For his visits, I provide:

- Good light in the work area
- Access to the main valve
- A bucket and towels within reach
- Clear floor space
- A way to charge or power a lamp, sometimes the [[Zeltrelzur solar charger]] when the mains is off

My own tools stay modest. A pair of adjustable wrenches, a pipe clamp, a plunger, a drain snake, and a set of screwdrivers are enough for small jobs. I do not touch soldered joints or anything inside a wall.

I keep a small log of his visits in my phone, so I can refer back to what was done. This is the format I use:

```
visit log
person: Trithluth Torkkind
role: plumber
area: forge
contact: phone
availability: weekdays
symptom: slow drain in kitchen
finding: grease and fine debris, pipe sound
action: cleared by hand, advised hot water
follow-up: check again before winter
```

It is not fancy, but it lets me search later and see patterns across visits.

## Contracts

I do not have a formal contract in the usual sense. He works on agreement, not paperwork, and I note what was agreed after each visit. Still, there is one dated record that I keep for reference.

The contract date of Trithluth Torkkind is 2020-07-04. That date appears on the paper I was given, and I keep a copy in the house folder. It predates the time I actually met him in 2023, so the paper was clearly drawn up for an earlier arrangement and I inherited it with the building. I have not tried to untangle the history, because it has never mattered in practice.

What the arrangement amounts to in daily use:

- Work is agreed verbally before it starts.
- He tells me roughly what is involved and whether it is a small or larger job.
- Anything that changes the plan is discussed on the spot.
- I note the agreement in my own words the same day.

For larger work connected to the [[Restiothve Lorkbran plan]], I would want something written down properly, with a clear description of what is included. So far nothing has needed it. If the renovation reaches the stage where walls are opened, I will raise it with him first. He has never objected to putting things in writing, but he does not offer it unprompted.

## Observations

Small things I have noticed over the years.

He always checks the main valve first, before looking at the actual problem. He says it is habit, and it has saved a mess more than once.

He listens more than he talks at the start of a visit. If I begin explaining a theory, he nods and then goes and looks for himself. He is rarely swayed by what I think the cause is, and he is rarely wrong.

He is careful about leaving a clean workspace. Towels, offcuts, and old washers are always gone when he leaves. I have never had to sweep up after him.

He does not speak badly of other tradespeople, even when their earlier repairs were clearly poor. He just says "that was done in a hurry" and moves on.

He is consistent in how he treats everyone in the building. When Vithrel Biste had a question about the shared wall, he answered it the same way he would have answered me. That fairness matters when work affects more than one household.

He seems to prefer older buildings and the quirks that come with them. Newer installations bore him slightly, and he says so.

His phone habits are predictable: he answers in the morning, calls back in the early afternoon, and rarely picks up late. If I have not heard back by the end of a weekday, I try again the next morning instead of leaving repeated messages.

## Costs

I am not recording any figures here. The point of this section is how his charges behave, because that is what helps me plan.

He quotes by describing the work in plain terms, then gives a rough idea of the total. The final amount has always been close to what he said at the start. When a job turned out to be bigger, he told me while he was still on site, not afterward, and let me decide whether to continue.

What drives cost, in my experience:

- How hard the problem is to reach. Anything behind a wall costs more than anything under a sink.
- Whether parts are needed and whether he has them with him.
- Whether the visit is planned or an urgent call.
- How long the job takes, which depends heavily on how clear the area is when he arrives.

Ways I keep costs down: call early, keep access clear, describe the symptom accurately, and group several small jobs into a single visit. The [[Fiothzi dehumidifier]] is a good example of a cheap fix that replaced a much more expensive assumption. I was ready to pay for a pipe investigation, and what I actually needed was drier air.

I pay him in person at the end of the visit and note the payment in my own records. For larger work tied to the [[Restiothve Lorkbran plan]], I will set aside a separate budget line and ask him to confirm the scope before any work starts.
