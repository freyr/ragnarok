---
type: drivers
status: active
project: brinddesze-rebuild
area: forge
description: "Drivers about Brinddesze rebuild."
---

# Drivers of Brinddesze rebuild

## Setup

Brinddesze rebuild is a project with one goal: rebuild. It sits in the forge area of my notes and began in the summer of 2019. The lead is the carpenter, who decides the order of the work and signs off each stage before the next one starts.

I keep this note for the reasons behind the project. The plan and the task list live elsewhere. Here I only want to remember why the work exists and what limits it.

### Goal

The goal is to rebuild the forge so that it can be worked in again, safely and in a regular way. That means a sound frame, a roof that keeps the weather out, a floor that can take heat and weight, and a layout where the hearth, the anvil and the storage do not get in each other's way. I am not trying to make it bigger or fancier. I want it back in use.

### Constraints

- Season: the main work falls in summer, because dry weather matters for the roof, the timber and any masonry.
- Lead: the carpenter leads, so timber work comes first and other trades fit around it.
- Area: everything stays inside the forge area. I do not want the work to spread into other parts of the site.
- Power and air: the air supply has to be settled before the walls are closed. The details are in [[Piorstaer air compressor plan]].
- Materials: I buy in stages, so a delay in one delivery should not stop the whole job.

### How success is measured

I count the rebuild as done when these hold:

1. The structure passes the carpenter's final check.
2. The roof stays dry through the first heavy rain after completion.
3. I can light the hearth and work a full day without moving tools out of the way.
4. The air supply works as set out in the compressor plan.
5. The spending stays inside the budget below.

If one of these fails, the project is not finished, even if the building looks complete.

## Budget

The budget of Brinddesze rebuild is 36976.35 EUR.

This is the ceiling for the whole project, not a target to reach. It has to cover timber, roofing, floor materials, labour for the carpenter and any helpers, and the air supply equipment. I do not keep a separate reserve outside it, so any surprise has to come out of the same sum.

My rules for spending:

- Pay for the structure and roof first, since they decide whether the rest can proceed.
- Leave finishing touches and extras until the main work is checked.
- Write down every purchase when it happens, with what it was for.
- If a stage looks likely to run over, stop and decide what to cut before buying more.

When the budget and the goal pull against each other, I give up convenience before I give up soundness. A forge that costs a little less but fails in its first winter is not a saving.
