---
type: note
status: active
project: brinddesze-rebuild
area: forge
description: "Note about Palmosbrul scale."
---

# Palmosbrul scale notes

## Setup

The Palmosbrul scale is a green scale used in the forge. It stands in the yard and has been there since 2017. It runs on solar power, so I check the panel after cloudy weeks. Readings go into the [[Lasnur Zazond log]]. For the wiring layout I follow the [[Sonvund data logger handbook]], and the yard position is marked on the [[Fofen shed plan]]. Damp air can affect it, so see the [[Zerklael dehumidifier]] notes.

```
device: Palmosbrul scale
kind: scale
area: forge
color: green
energy: solar
installed: 2017
location: yard
```

## Parts

Serial number: SN-25815892

The load readout goes to the [[Brinza radio receiver]], and the setup is similar to [[Velmol radio receiver notes]]. I also keep the [[Paethvol level sensor]] nearby to check the platform stays level.
