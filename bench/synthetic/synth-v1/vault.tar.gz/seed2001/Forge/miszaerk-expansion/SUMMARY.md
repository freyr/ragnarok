---
type: summary
status: active
project: miszaerk-expansion
area: forge
description: "Summary about Miszaerk expansion."
---

# Summary of Miszaerk expansion

This is the summary note for Miszaerk expansion, a project in the forge area. The goal is expansion. The lead is my neighbor. The project started in spring 2025. It is past the planning stage and in the building phase, so the notes below describe work in progress rather than a finished job.

## Maintenance

The expansion adds floor space and a second working zone to the forge, so the old part has to keep working while the new part is built. I keep the maintenance routine short and written down so it does not get skipped when the building work gets busy.

- Clean the flue and check the chimney draw at the start of each season.
- Oil the hinges on the big doors and the sliding bolt on the side entrance.
- Sweep scale and ash from the old floor before anyone moves heavy material across it.
- Check the anvil stand for loose fixings and tighten them.
- Wipe down the tongs rack and the hammer wall, and put back anything that wandered into the new area.

The neighbor, who leads the project, looks after the shared wall and the roof joint where the new section meets the old one. I look after the tools and the inside of the old forge. We agreed on this split early and it has held up well. Each of us reports to the other when something changes, usually over the fence or by a short message.

Dust is the main maintenance issue during the build. Brick and mortar dust settles on everything, including the quench tank and the bellows. I keep the tank covered with a board and a sheet while masonry is going on, and I rinse the tank lid before I remove it. The bellows leather gets wiped with a dry cloth, never a wet one, and then lightly dressed with grease once a month.

## Decisions

The go decision for Miszaerk expansion was made on 2023-11-22. After that the project waited for the right season and for the neighbor to be free to lead it, which is why work only began in spring 2025.

Main decisions so far:

- The neighbor leads. I do not override site choices on the day, and I raise concerns afterwards, not during a pour or a lift.
- The expansion goes along the sunny side of the old forge, not behind it, so there is room for a delivery door.
- The new section uses the same wall height as the old one, so the roof can run in one line and shed rain in one direction.
- The floor in the new zone is packed earth topped with a hard-wearing layer, not full concrete. It is easier to repair and kinder to dropped hot steel.
- The old forge keeps working during the build. We do not shut it for the whole season.
- No new fuel store goes inside. Fuel stays in the existing outbuilding.

I wrote these down because I tend to forget why a choice was made. When a question comes up again, I check this list first and only reopen a decision if something real has changed, such as a cost that moved or a supply that dried up.

## Problems

The problems so far have been small but irritating. None of them has stopped the project.

The first is drainage. After heavy rain, water gathers at the low corner where the new section meets the old one. The ground there slopes toward the wall. We dug a shallow channel as a stopgap, but it needs a proper fix before the floor layer goes in.

The second is the roof joint. The old roof sits slightly lower than planned for the new one, so the join needs a flashing detail that neither of us has done before. The neighbor has seen it done and thinks it is manageable. I am less sure and want a second opinion before we close it in.

The third is timing. Dry days are short in spring, and masonry needs several in a row. We lost a good stretch to rain and had to cover the work and wait.

The fourth is clutter. With two zones, tools migrate. I found the same pair of tongs in three different places in one week. A simple rule helps: tools go back to the rack on the old side unless they are tagged for the new side.

## Ideas

These are things I may or may not do. None of them is a decision.

- A small raised hearth in the new zone, used for teaching or for light work, separate from the main fire.
- A rolling cart for the heaviest stock so it moves between zones without lifting.
- A lean-to over the delivery door so materials stay dry while being unloaded.
- A wall-mounted board with outlines of the tools, so a missing tool is obvious at a glance.
- A roof vent along the ridge of the new section to help hot air leave.
- A simple sign above the delivery door with the name of the forge.

The cart is the idea I like most, because it solves a real daily annoyance. The roof vent is the one I want to think about carefully, since a badly placed opening could pull smoke the wrong way or let rain in.

## Costs

I am not tracking exact prices here, because the numbers live in my separate ledger. This section is about the shape of the costs and where they have surprised me.

The largest cost is masonry material, followed by roof timber and sheeting. Labor is mostly free, since it is the neighbor and me, with occasional help. The neighbor covers some items directly and I cover others, and we settle the difference at the end of each month.

The surprises so far:

- Drainage was not budgeted. The stopgap channel was cheap, but a proper fix will not be.
- Flashing and sealing for the roof joint cost more than I assumed.
- Fuel for the old forge went up a little because we ran it during the build.
- Replacement blades and bits wore out faster than expected when cutting brick.

I keep a rule of thumb: whatever I think a job will cost, I add a cushion for the things I have not thought of. So far the cushion has been used.

## Supplies

Supplies are the part most likely to slow the project, so I check them before each work session.

Needed and on hand: bricks for the lower courses, sand, mortar mix, timber for the main roof frame, and basic fixings.

Needed and still to get: sheeting for the roof, flashing material for the joint, gravel for the drainage fix, the hard-wearing floor layer, and a door for the delivery opening.

I try to order in one batch where I can, because delivery to the forge is awkward and the lane is narrow. The neighbor knows a supplier who will hold material for a few days, which helps when the weather turns. Anything that must stay dry, such as mortar mix, is stored in the old forge under a tarp and off the floor on pallets.

A short working checklist I paste into my notes before each session:

```
session check - Miszaerk expansion
area: forge
lead: neighbor
[ ] weather ok for masonry
[ ] mortar mix dry and sealed
[ ] tools returned to old-side rack
[ ] covers on quench tank and bellows
[ ] extinguisher and water bucket in place
[ ] site swept at end of day
```

## Observations

A few things I have noticed while watching the work go up.

The new section is brighter than the old one. The old forge is dark, which suits judging heat by color, but the new zone has more daylight and will be better for finishing, filing and inspection. I should not put a fire there unless I shade it.

The neighbor works in a steady, unhurried way, and the work comes out straighter than when I rush. I have stopped hurrying them.

The ground on this side is softer than I thought. The first footing trench filled with water more than once, and we waited for it to drain before going further. That is probably the root of the drainage problem.

Sound carries differently now. With the wall opened up, hammering in the old forge is louder in the lane. I should mention it to the other neighbors before the work resumes in earnest.

Stage summary: planning is done, the footings and lower walls are in, the roof frame is next, and the floor, drainage and doors come last. Done: decision, site layout, footings, and the first wall courses. Open: drainage, the roof joint detail, roof sheeting, floor layer, and the delivery door.

## Next action

The next action is NX-8041. Everything else waits on it, so I should not start new side tasks until it is finished. After that I will go back through the open points above, starting with the drainage and the roof joint, and update this summary once they are closed.

## Safety

The forge is a working site and a building site at once, which makes it riskier than either alone. I keep these rules visible and I follow them even when I am in a hurry.

- Never carry hot work across the building zone. Quench or set it down first.
- Keep a clear path from the fire to the door at all times, and do not stack material in it.
- Wear eye protection when cutting brick or striking masonry, and a dust mask during mixing and sweeping.
- Keep the extinguisher and a bucket of water near the old forge entrance, not buried behind supplies.
- Check ladders and scaffolding boards before each use, and never work on the roof alone.
- Cover open trenches at night and mark them so no one steps in by mistake.
- Keep fuel only in the outbuilding, away from the new timber.
- Stop work in wind or heavy rain when roof sheets could lift or the footing could slip.

If something feels wrong, I stop and ask the neighbor to look. A delay of an hour costs less than an injury.
