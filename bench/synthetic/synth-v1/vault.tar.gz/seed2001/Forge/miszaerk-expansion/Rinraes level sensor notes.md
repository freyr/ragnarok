---
type: note
status: active
project: miszaerk-expansion
area: forge
description: "Note about Rinraes level sensor."
---

# Rinraes level sensor notes

## Background

The Rinraes level sensor is a level sensor that belongs to the forge area. It was installed in 2014 and sits in the cellar, where it watches the level of the quench water that collects there. The housing is grey, which makes it easy to spot against the damp stone wall.

It runs on solar energy. A small panel is fixed near the cellar window and feeds the unit through a short cable. On dull winter weeks the readings sometimes lag, so I check the panel for dust and cobwebs before I suspect the sensor itself.

I keep these notes so I do not have to rediscover the routine every time something drifts.

## Adjustment

When the readings start to disagree with the dipstick, I adjust the sensor rather than replace it. The calibration offset of Rinraes level sensor is 2.811 mm. I enter that value after any reset or after the panel has been disconnected for a long time.

My routine is simple. First I empty the cellar tray and let the sensor settle. Then I enter the offset and compare the reading with the dipstick at two or three levels. If the gap is small and steady, I leave it alone. If it wanders, I clean the panel and test again.
