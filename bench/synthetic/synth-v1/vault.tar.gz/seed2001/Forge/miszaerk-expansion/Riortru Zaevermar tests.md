---
type: research
status: active
project: miszaerk-expansion
area: forge
description: "Research about Riortru Zaevermar."
---

# Riortru Zaevermar tests

## Schedule

Riortru Zaevermar is a plumber I have known since 2025. He works in the forge area. The best way to reach him is by phone, and he is only available in the evenings, so I call after work and do not expect an answer during the day.

| Property | Value |
|---|---|
| Role | plumber |
| Area | forge |
| Contact | phone |
| Availability | evenings |
| Known since | 2025 |

When I plan a job, I check [[Bethtes Panvil plan]] first and then [[Piorstaer air compressor plan]], because both need water or air lines. Notes on the sensor side are in [[Linvetro data logger notes]].

## Contracts

The contract date of Riortru Zaevermar is 2022-03-21. That is earlier than when I met him, so it comes from the paperwork he showed me, not from my own records.

For the solar charger job I wrote down what he covers in [[Zeltrelzur solar charger]]. Related people and past work are in [[Rerdriork Brafaen notes]], [[Treda Kaeson notes]] and [[Siolo scale study]].
