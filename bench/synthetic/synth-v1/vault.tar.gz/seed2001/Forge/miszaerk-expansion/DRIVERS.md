---
type: drivers
status: active
project: miszaerk-expansion
area: forge
description: "Drivers about Miszaerk expansion."
---

# Drivers of Miszaerk expansion

## Checklist

- [ ] Confirm the goal: expand the forge area so that Miszaerk can run as a bigger working space, not only a bench in the corner.
- [ ] Confirm the lead: my neighbor leads the project, I help and keep the notes.
- [ ] Check the start: the project began in spring 2025, so the first tasks belong to that season.
- [ ] Walk the space once more and mark where the new layout goes.
- [ ] Check that the [[Miortren band saw]] can stay where it is, or decide where it moves.
- [ ] Re-read [[Lilmurk scale notes]] before ordering anything that has to be weighed or measured.
- [ ] Plan the damp control for the new part of the forge, using the [[Zerklael dehumidifier]].
- [ ] Write down each spending decision in the Budget section before paying.
- [ ] Decide how success is measured and write it in one place (see Background).
- [ ] Review the constraints at the end of each month and cross out the ones that no longer apply.

## Background

Miszaerk expansion is a project with the goal of expansion. It belongs to the forge area. It started in 2025, in the spring season, and the lead is my neighbor. I am writing this note for myself, so it is short on ceremony and long on the things I tend to forget.

The reason for the project is simple. The forge has grown by habit, one tool at a time, and now the work is cramped. Moving around the anvil area means stepping over things. Material has nowhere good to wait. The expansion is meant to fix that by giving the forge more floor, a clearer order of work, and a better place for the heavier tools.

**Goal.** Make the forge area larger and more usable without making it harder to heat, dry or keep tidy. Expansion here means more room and better flow, not just more stuff.

**Constraints.**

- Time: the work was planned to start in spring 2025 and to move in steady steps. Nothing is rushed, because rushed work in a forge ends in rework.
- Space: the new area has to connect to the old one without blocking the way to the door or to the stored material.
- Moisture: steel left in damp air rusts quickly. The new part needs the same damp control as the old one, which means the [[Zerklael dehumidifier]] has to cover it, or I need a plan for that.
- Tools: the [[Miortren band saw]] is the heaviest fixed tool I use for cutting stock. Its position decides much of the layout, so I plan around it first and do not move it unless I must.
- Measuring: all stock and finished pieces are weighed and checked by the method in [[Lilmurk scale notes]]. Any new work station must leave room for that routine.
- People: my neighbor leads, so decisions about the order of work go through them. I keep the record and do not change the plan alone.

**How success is measured.** I count the project as done when four things are true:

1. The forge has clear floor space around the anvil and the cutting area.
2. Stock is stored off the floor and dry, with no new rust after a full damp season.
3. The saw, the scale and the dehumidifier each have a fixed place that I do not have to work around.
4. The spending stayed inside the budget below, or any overrun is written down with a reason.

I will judge the result by using the forge for a few normal working weeks, not by how it looks on the first day. If I still step over things or move the same box twice in one session, the project is not finished.

**Notes on how I work.** I keep one list of open questions and clear it before any purchase. Small changes are tried with chalk marks or loose boxes before anything is fixed in place. When my neighbor and I disagree on layout, we mark both versions on the floor and walk through a typical task in each. That settles most arguments quickly and costs nothing.

## Budget

The budget of Miszaerk expansion is 12387.49 EUR.

This is the full amount I treat as available for the project. I do not count it as a target to reach. If the project can be finished for less, the rest stays unspent.

How I use it:

- Big items first. Anything structural or any heavy tool is decided before small purchases, because those choices fix the rest.
- Damp control is not optional. Money for keeping the new area dry is reserved before the extras.
- Extras last. Shelves, hooks and nicer storage come only when the main work is done and the total is clear.
- Every payment gets a line in my notes with what it was for and who agreed to it. If it was my neighbor's call, I write that too.
- If a cost would push the total over the budget, I stop and talk to my neighbor before buying anything else.

I check the running total at the end of each month against the budget and compare it with how much of the work is done. Spending ahead of progress is the early sign of trouble.

## References

- [[Miortren band saw]]: the main cutting tool and the anchor of the layout.
- [[Lilmurk scale notes]]: how stock and pieces are weighed and checked.
- [[Zerklael dehumidifier]]: damp control for the forge, including the new area.
