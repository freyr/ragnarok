---
type: note
status: active
project: miszaerk-expansion
area: forge
---

# Linvetro data logger notes

## Setup

The Linvetro data logger is a blue data logger that belongs to the forge area. I installed it in 2025 in the loft, up under the roof where the heat from the forge collects. It runs on solar energy, so there is no mains cable to the loft at all. A small panel sits on the south-facing slope of the roof and feeds the unit directly.

I picked the loft because it gives a steady reading of the warm air that rises from the working floor. It also keeps the logger away from sparks, water and the soot that settles near the hearth. The blue case is easy to spot when I climb up, which helps when I only want a quick look at the status light.

Notes on how I set it up:

- Mount the logger on the rafter, not on the boards, so it does not pick up vibration from the floor below.
- Point the panel away from the chimney shadow. In winter the shadow reaches further than I expected.
- Leave a loop of slack in the sensor cable so rain or condensation cannot run along it into the case.
- Check the status light after any cloudy week. If it blinks slowly, the battery is low and the logging interval should be lengthened.

The logger writes a reading at a fixed interval and keeps the data on its own memory until I collect it. I do not rely on any wireless link, because the loft walls are thick and the signal is poor.

## Tools

What I bring up the ladder when I visit the logger:

- A small screwdriver for the case screws.
- A soft cloth to wipe dust off the solar panel. Dust from the forge builds up faster than I expect, and a dirty panel is the usual reason for a flat battery.
- A laptop with a cable for pulling the data off.
- A head torch, since the loft has no light.
- Thin gloves, because the rafters are rough and the case can be hot in summer.

When I connect the laptop, I check the status first and then copy the files. This is the sort of log extract I expect to see after a normal collection:

```
status: ok
power: solar
battery: charging
sensor: connected
memory: readings stored
action: copy files, then clear memory
```

After copying, I open a couple of the files to make sure they are not empty before clearing the memory. Once I cleared it too early and lost a whole week of readings, so now I always check first.

I also keep a paper note taped near the ladder with the order of steps, so I do not have to remember them while balancing in the loft. The steps are: wipe the panel, check the light, connect, copy, verify, clear, close the case.

## Parts

The main unit is the Linvetro data logger itself, a blue case that holds the electronics and the battery. Its serial number is SN-36615089. I wrote it on the inside of the toolbox lid as well, in case the label on the case fades from the heat.

Other parts that belong to the setup:

- The solar panel on the roof, which is the only energy source for the logger.
- The panel cable, which runs through a gap under the eave into the loft.
- The sensor cable with its probe, which hangs in the warm air near the rafter.
- The internal battery, which stores the solar energy for nights and cloudy days.
- Two mounting brackets and the screws that hold the case to the rafter.
- A rubber seal around the case lid, which I inspect once a year for cracks.

Spare items I keep in the toolbox: a few extra screws, a length of spare sensor cable, and a little tube of sealant for the cable entry. The seal and the cable entry are the two places where moisture is most likely to get in, so those get the most attention.

If the logger ever needs repair or replacement, the serial number is what I will quote first, together with the fact that it was installed in the loft of the forge in 2025.
