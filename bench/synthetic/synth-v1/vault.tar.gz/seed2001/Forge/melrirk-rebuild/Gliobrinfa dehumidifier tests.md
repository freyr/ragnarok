---
type: research
status: active
project: melrirk-rebuild
area: forge
description: "Research about Gliobrinfa dehumidifier."
---

# Gliobrinfa dehumidifier tests

## Risks

The Gliobrinfa dehumidifier is a yellow, battery-powered dehumidifier that sits in the forge area, down at the pond. Most of the risks come from that combination: a damp place, a battery, and a machine that I want to run without watching it all the time.

- Water and the battery are the main worry. The unit is at the pond, and a splash or a flood could reach the battery compartment. I keep the unit raised off the ground for this reason.
- A flat battery stops the unit without warning. Humidity then climbs back up quickly, and the tools in the forge start to show surface rust within a few days.
- Heat from the forge can push the battery too hard if the unit is placed too near the working area. I have not seen a failure, but I treat it as a real risk.
- The yellow casing is easy to see, which is good, but it also means the unit gets bumped by people walking past. A knock could loosen the battery connection.
- If the collection tank overflows, the water can run back toward the base. I check the tank often for this reason.

None of these risks has caused real damage so far. I still list them because the tests in this note were all about finding out where the limits are.

## Observations

The Gliobrinfa dehumidifier was installed in 2025. It is a dehumidifier in the forge area, its location is the pond, its color is yellow, and its energy source is battery. I keep those facts at the top of my mind because every test result depends on them.

What I saw over the testing period:

- On a dry day the unit pulls very little water. The tank fills slowly and the battery lasts a long time.
- On a damp morning near the pond the tank fills much faster. The battery drains faster too, because the unit works harder.
- The air closest to the unit feels drier first. The far corners of the forge take much longer to change.
- The fan noise is steady and low. I can hear it when the forge is quiet, but it does not bother me while I work.
- Fog over the pond in the early hours makes the readings jump. After the fog lifts, things settle in an hour or two.
- The yellow casing does not seem to fade, even though the unit sits in bright light for part of the day.
- Condensation sometimes forms on the outside of the casing in the cold hours. It dries off by midday.

I keep a short daily line in the [[Kraendnio Viodith log]] with the tank level and the state of the battery. Those lines are the raw material for most of what I write here. When I want to check a pattern, I go back to that log first.

A few patterns stood out after reading those entries together:

- The tank is fullest after nights with fog.
- The battery is lowest after two damp days in a row.
- Tool rust appeared only in the weeks when the unit was off for a long stretch.

## History

I installed the Gliobrinfa dehumidifier in 2025. Before that, the forge area had no humidity control at all. I relied on opening the doors and on wrapping tools in oiled cloth, which worked only partly.

The early period went roughly like this:

1. I chose a dehumidifier that runs on a battery, because there is no easy mains power at the pond.
2. I placed it first inside the forge area, close to the anvil. That turned out to be too warm and too dusty.
3. I moved it to a spot nearer the pond side of the forge, where the damp is worst and the dust is lighter.
4. I started the daily notes in the [[Kraendnio Viodith log]] once the unit was in its final place.
5. After a few weeks I began to run deliberate tests instead of just watching.

The first season showed me that the unit does the job, but that the battery is the weak point. Every change I made after that was aimed at using the battery better or protecting it.

In the second season I had a clearer routine. I checked the tank each morning, swapped the battery on a schedule, and kept the notes tidy. That routine is what the Maintenance section below describes.

## Lessons

These are the things I learned from the tests, written as plain rules for myself.

- Place the unit where the damp is, not where it is convenient. Near the pond side works much better than near the anvil.
- Keep the unit off the ground. Even a small stand makes me feel safer about the battery.
- Do not wait for the tank to be full. Emptying it early keeps the unit running steadily and avoids overflow.
- A battery that is fully charged at the start of a damp week gets through much more than one topped up halfway.
- Closing the forge doors during the damp hours helps more than anything else I tried. The unit cannot beat an open door.
- Write the tank level down every day. The pattern is clearer on paper than in memory.
- Do not trust a single day. Fog, wind and rain change the result too much, so I compare several days.

The biggest lesson is that the dehumidifier is only one part of the answer. Doors, placement and tool care all matter just as much.

## Ideas

Some things I want to try next. None of them is done yet.

- Add a small hose from the tank to a bucket, so the unit does not need emptying so often.
- Build a simple shelf with a lip around it, to hold the unit and catch any spill.
- Try a second battery on a rotating schedule, so one is always charged.
- Make a cover for the top of the unit that keeps rain off when the doors are open, but still lets air through.
- Mark the floor near the unit, so people know not to knock it.
- Test a cloth curtain across the pond-side opening, to see whether it cuts the damp air coming in.
- Compare the tool rust on a rack near the unit against a rack far away, to get a clearer picture of the range.
- Write a one-page checklist and pin it next to the unit, so the daily check takes less thought.

If I only do one of these, I would pick the hose, because emptying the tank is the chore I like least.

## Software

The unit has a small controller, and it reports a firmware version. The firmware version of the Gliobrinfa dehumidifier is v1.25.401.

What I know about the software side:

- The controller handles the target humidity setting, the fan speed and the low battery warning.
- I have not updated the firmware since I installed the unit, and I have no plan to unless something breaks.
- When the battery gets low, the controller shuts the unit down on its own instead of running until it dies. That is helpful, because it protects the battery.
- Settings survive a battery swap, as long as the swap is quick. If I leave the battery out for a long time, I recheck the target setting afterwards.

I write the firmware version in the [[Kraendnio Viodith log]] whenever I check the settings, so I can tell later if anything changed.

## Supplies

What I keep on hand for the dehumidifier:

- A spare battery, charged and stored indoors.
- A charger that I keep dry, away from the pond.
- A clean cloth for wiping condensation off the yellow casing.
- A small bucket for emptying the tank.
- Oiled cloth for wrapping tools when the unit is off.
- A roll of tape for marking the floor and labeling the spare battery.
- A notebook page or a note ready for the daily entry.

I do not stock many extras. The unit is simple, and most problems are solved with the spare battery and a dry cloth. If I notice that I am running low on any of these, I add it to my next trip list.

## Maintenance

My routine is short and I try to keep it the same every time.

1. Each morning, check the tank and empty it if it is more than about half full.
2. Look at the battery state and note it down.
3. Wipe the casing if there is condensation on it.
4. Check that the unit is still upright and off the ground.
5. Once a week, clean the air intake with a dry cloth, so dust does not build up.
6. Once a week, look at the battery connection for any sign of damp or loosening.
7. Swap the battery when it is low, and put the used one on the charger indoors.

Every few weeks I take a closer look at the whole unit. I check the tank for stains, the fan for dust and the casing for cracks. So far everything has been in good condition.

If the unit will be off for a long time, I empty the tank fully, dry it out and store the battery indoors. Then I wrap the nearby tools in oiled cloth, since the forge will not have any protection while the unit is off.

## Tools

The tools I use for the tests and the upkeep are simple:

- A hygrometer, to read the humidity near the unit and in the far corner of the forge.
- A notebook or the [[Kraendnio Viodith log]], for daily entries.
- A small screwdriver, for opening the battery compartment.
- A dry cloth and a soft brush, for cleaning the intake.
- A bucket, for the tank water.
- A small stand or block, to keep the unit raised.
- A watch or timer, to time how long a full tank takes on damp days.

I keep the hygrometer next to the unit and a second one on the far wall. Comparing the two readings tells me how far the effect reaches. Without the second reading, I would think the unit was doing better than it really is.

## Background

The forge is an area where damp does real harm. Iron and steel rust quickly, and the pond makes the air heavier than it would be elsewhere. I wanted something that works without mains power, so a battery-powered dehumidifier was the logical choice.

The Gliobrinfa dehumidifier is a dehumidifier in the forge area. It is yellow and runs on a battery. It was installed in 2025, and its location is the pond. These are the basic properties, and I repeat them here because every other note about the unit depends on them.

The reason for the tests was simple. I wanted to know whether the unit makes a real difference, how long the battery lasts under different conditions, and where the unit should sit for the best effect. I also wanted to have my own record, instead of relying on a vague feeling that things were drier.

The tests were not formal. I used what I had: a hygrometer, a notebook, and a few weeks of patience. Even so, the daily entries added up to a useful picture over time.

## Problems

These are the problems I ran into during the testing.

- The battery ran flat once during a damp week, because I forgot to swap it. Rust spots appeared on two tools before I noticed.
- The first placement, near the anvil, collected dust and got too warm. I moved the unit after a short time.
- The tank overflowed once after a foggy night. A little water reached the floor, and I had to dry the area.
- A person walking past knocked the unit once. The battery stayed in place, but it showed me that the unit needs a safer spot.
- Condensation on the casing made the unit slippery when I picked it up. Now I wipe it before moving it.
- The readings were hard to compare on days with changing weather. I now use several days together instead of one.

None of these problems was serious, and each one led to a small change in my routine. The overflow and the flat battery were the two that taught me the most.

## Setup

The unit is set up at the pond side of the forge. This is the current arrangement.

- The Gliobrinfa dehumidifier, a yellow battery-powered unit, stands on a small raised block, off the ground.
- It sits near the pond-facing wall, where the damp air comes in.
- The area around it is kept clear, so air can reach the intake and nobody trips over it.
- The spare battery and the charger are kept indoors, away from the pond.
- One hygrometer sits beside the unit and another is on the far wall of the forge.
- The target humidity is set once and left alone, apart from a check after each battery swap.
- The doors are closed during the damp hours, which gives the unit a fair chance.

To restart after a pause, I put in a charged battery, check the target setting, empty the tank, and write the first line in the [[Kraendnio Viodith log]]. After that the unit runs by itself, and I only follow the daily routine.
