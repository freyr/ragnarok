---
type: summary
status: active
project: melrirk-rebuild
area: forge
description: "Summary about Melrirk rebuild."
---

# Summary of Melrirk rebuild

## Safety

Melrirk rebuild is a project with the goal of rebuild, in the forge area. It started in summer 2021 and the lead is my neighbor. The project is in the build stage, with the main work done and a few open points left.

- Keep the forge floor clear while the rebuild is going on, and keep water away from hot work.
- Check the [[Paethvol level sensor]] before any firing, since a wrong reading is a risk.
- Wear gloves and eye protection near the hearth.
- Store spare fuel in the [[Vindseth loft]] only when the loft is dry.

## Next action

The next action is NX-8705. Before I start it, I will reread the [[Mersos level sensor notes]] and compare them with the [[Pikios level sensor plan]]. Then I will ask the neighbor to confirm the order of work.

## Decisions

The go decision date is 2022-12-19. After that date we followed the [[Restiothve Lorkbran plan]] for the layout.

- Use [[Vithrel Biste]] as the contact for materials.
- Weigh loads with the method in the [[Lilmurk scale notes]].
- Keep the neighbor as lead until the rebuild is finished.
