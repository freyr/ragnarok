---
type: plan
status: active
project: melrirk-rebuild
area: forge
description: "Plan about Zaeldroth Mioror."
---

# Zaeldroth Mioror plan

## Setup

This plan covers how I deal with Zaeldroth Mioror, my neighbor near the forge. I have known Zaeldroth since 2025. The area is the forge, which is why most of our dealings happen close to the workshop doors and the shared yard.

The properties I keep for this person, so I do not have to guess later:

- Role: neighbor
- Area: forge
- Contact: in person
- Availability: weekdays
- Known since: 2025

Because the contact method is in person, there is no phone number or address to store. I walk over and ask. Because availability is weekdays, I do not plan anything for a weekend. If something cannot wait, I leave it for Monday rather than chase it.

The goal of the plan is simple: get a clear quote for the work I want done around the forge, agree on scope face to face, and write everything down afterwards so nothing depends on memory. I use [[Vithrel Biste]] as a go-between if I cannot catch Zaeldroth on a given day, since Vithrel is often around the same yard.

Before the first talk I gather the following:

1. A rough sketch of the job and where it sits relative to the forge.
2. The readings I already have from earlier checks, see [[Giore level sensor notes]].
3. A list of questions, kept short enough to fit on one page.

A small note template I paste into the daily log after each conversation:

```
person: Zaeldroth Mioror
role: neighbor
area: forge
contact: in person
availability: weekdays
topic:
agreed:
open questions:
next talk:
```

## Risks

The main risk is timing. Zaeldroth is only available on weekdays, and I am not always free then. If I miss two weekdays in a row the whole plan slips, so I try to block a short slot early in the week.

The second risk is that everything is verbal. Contact is in person, so there is no message thread to look back on. If I forget to write down what we agreed, I have only my memory. The fix is to write the log entry within the hour, while it is fresh.

The third risk is scope creep. A neighbor job tends to grow once we are standing in front of it. I need to decide what is in and out before the conversation, not during it.

The fourth risk is mixing this job with other ongoing work. The earlier test results in [[Zurbrith Musstaend tests]] are a separate topic, and I should not let them leak into the scope or the price discussion.

A smaller risk is the relationship itself. We have known each other since 2025 and we are neighbors, so a badly handled price talk would be awkward for a long time. I keep the tone friendly and the questions plain.

## Checklist

Before the talk:

- [ ] Choose a weekday and a time slot
- [ ] Prepare the sketch and the question list
- [ ] Reread [[Pikios level sensor plan]] for anything that overlaps
- [ ] Decide the limit of the scope

During the talk:

- [ ] Describe the job in two or three sentences
- [ ] Ask for a quote for the whole job, not in parts
- [ ] Ask what is included and what is not
- [ ] Ask when the work could start, on weekdays only

After the talk:

- [ ] Fill in the log template within the hour
- [ ] Copy the quoted price into the Quotes section below
- [ ] Note any open questions and the date of the next talk
- [ ] Tell [[Vithrel Biste]] if the plan involves the shared yard

## Maintenance

This plan needs light upkeep. After each conversation I update the log template entry and, if something changed, the properties in Setup. The properties themselves should rarely change: role neighbor, area forge, contact in person, availability weekdays, known since 2025. If any of them changes, for example if Zaeldroth starts being reachable another way, I edit the list and leave a short line about why.

Once the job is agreed, I stop adding to Risks and start trimming it. Items that no longer apply get removed, and items that turned out real get a short note on what happened.

I review the whole plan whenever a new quote or a new scope arrives. I also glance at [[Treda Kaeson notes]] to check that nothing in them contradicts what I wrote here. If the plan sits untouched for a long stretch, I either close it or write down why it is paused.

## Overview

Zaeldroth Mioror is a neighbor whose area is the forge. I have known Zaeldroth since 2025. Contact is in person, and availability is weekdays. Those five facts are the whole profile, and the plan is built around them.

In practice that means a short, planned conversation on a weekday, a quote asked for clearly, and a written record afterwards. The plan has three working parts: prepare, talk, record. Setup holds the profile and the template, Risks lists what could go wrong, Checklist gives the steps, and Maintenance keeps the note current.

What I want at the end is one agreed price, one agreed scope, and one start day, all written down. Related material lives in [[Giore level sensor notes]], [[Pikios level sensor plan]], [[Zurbrith Musstaend tests]] and [[Treda Kaeson notes]], and I link to them instead of copying their content here. If the price turns out to be well above what I expected, the fallback is to ask for a smaller scope rather than argue about the number.

## Quotes

Quoted price of Zaeldroth Mioror: 8287.35 EUR

This is the figure given for the whole job as described in Setup. I have not yet confirmed what it includes, so the first question at the next talk is whether materials and labor are both in it. Until that is answered I treat the number as an opening quote, not a final price.

Notes to add after the next conversation:

- What the quote covers
- What is excluded
- Whether the price holds if the scope shrinks
- Who else, such as [[Vithrel Biste]], was present when it was given
