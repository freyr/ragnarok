---
type: drivers
status: active
project: melrirk-rebuild
area: forge
description: "Drivers about Melrirk rebuild."
---

# Drivers of Melrirk rebuild

## Problems

The Melrirk rebuild is a project with the goal of rebuild, in the forge area. It started in the summer of 2021, and the lead is the neighbor. The main problem is that the old forge setup was worn out and no longer safe to work in, so the rebuild has to fix the basics first and leave extras for later.

Constraints I keep running into:

- The work has to fit around the neighbor's schedule, since the neighbor leads and I help. Summer is the only season that suits the heavy work, because the doors stay open and the ground is dry.
- Space is tight. Any new tool has to fit without blocking the walkways. My earlier cutting notes in [[Ziongind band saw notes]] show how much room a saw needs.
- Heat and ventilation are weak points. The airflow findings in [[Relnath greenhouse tests]] were useful for judging how air moves in a closed building.
- Measuring is still rough. For checking fuel and water levels I lean on [[Mersos level sensor notes]].
- Power is limited, and the wiring plan has to stay simple. Some of the earlier trials are in [[Zurbrith Musstaend tests]].
- Communication on site is poor when the machines run. I wrote down ideas with the [[Brinza radio receiver]] in mind.

How I judge success: the forge is safe to light, the layout lets two people work at once, and nothing needs to be redone after the first season of use. The earlier material in [[Trithluth Torkkind notes]] covers the old failures I want to avoid repeating.

## Budget

The budget of Melrirk rebuild is 15899.46 EUR. That figure has to cover materials, tools and any hired help. I do not plan to go over it, so anything optional waits until the essentials are done.

Order of spending:

1. Structure and safety first: floor, walls, roof repair, and ventilation.
2. Fire and heat handling next.
3. Tools and fittings after that.
4. Comforts and extras last.

For advice on suppliers and who to ask, I go back to [[Ganzin Birksta]]. Longer-term follow-up work sits in the [[Brirkbur Biodio plan]], and I will keep it separate from this budget so the rebuild cost stays easy to read.

Success on the money side means finishing at or below the budget with no unpaid leftovers. If a cost grows, I cut something optional rather than ask for more money.
