---
type: note
status: active
project: melrirk-rebuild
area: forge
---

# Velmol radio receiver notes

## Observations

The Velmol radio receiver is a grey radio receiver that sits in the yard. It was installed in 2020 and belongs to the forge area. It runs on battery, so there is no mains cable to trip over, and that was the main reason I picked this spot in the first place.

The case is plain grey and shows dirt quickly. After a dry week it is covered in fine forge dust, and after a wet week it gets streaks of rust-coloured water down the front. A wipe with a damp cloth fixes both, but I have to remember to do it.

Reception in the yard is decent most days. The signal is clearest in the morning, before the forge is lit. Once the furnace and the grinder are running, I hear a steady crackle underneath the voices. It is not bad enough to stop me listening, but I notice it. When the grinder is on, I mostly give up on quiet programmes and stick to music or loud talk.

I have noticed a few patterns over the years:

- The battery drains faster in cold weather.
- Volume has to be turned up when the forge is working, which also costs power.
- Damp air makes the dial feel sticky and the sound a bit muffled.
- The receiver holds its tuning well and rarely drifts once set.

It is a sturdy unit. It has taken knocks, a few splashes and one fall from the bench without any lasting harm.

## References

These are the notes and plans I look at when I work on the receiver or its surroundings:

- [[Fofen shed plan]] covers the layout of the yard buildings, including where the receiver could be mounted if I ever give it a proper shelter.
- [[Trithluth Torkkind notes]] has general notes about radio listening conditions and interference, which helped me understand the crackle.
- [[Fiothzi dehumidifier]] is about the moisture control I use in the workshop. The same ideas apply to keeping the receiver dry.
- [[Purnimiork Relsol log]] is the running log where I record battery changes and other small jobs.
- [[Restiothve Lorkbran plan]] is the longer maintenance plan for the forge area, and the receiver is listed in it.
- [[Ganzin Birksta]] is the person I ask when I get stuck with anything electrical or radio related.

## Setup

The receiver stands in the yard on a flat shelf by the forge wall. It has been there since 2020, and I have not moved it far since. The shelf is under a short overhang, so it is shielded from direct rain but not from blown spray or damp air.

Power comes from batteries only. I keep a spare set in a tin in the forge, away from the heat. Changing them takes a minute: open the back cover, swap the cells, check the contacts, close the cover.

The aerial is the one that came with the unit. I extended it fully and angled it slightly away from the wall. Pointing it away from the grinder cabinet gave a small but real improvement.

My routine when setting up for a work session:

1. Wipe dust off the front and dial.
2. Check the battery level by listening for a weak or distorted sound.
3. Tune the station and set the volume low.
4. Raise the volume only when the forge noise starts.

I try not to leave the receiver outside overnight in bad weather. If frost or heavy rain is forecast, I bring it into the forge and put it on the high shelf.

## Problems

The main problem is interference. The crackle that comes with the grinder and the furnace blower is constant and there is no simple cure. Moving the receiver a short distance along the wall helps a little, but not enough to remove it.

The second problem is moisture. The yard is damp for much of the year, and the back cover does not seal perfectly. Twice I found a little condensation inside the battery compartment. After that, I started leaving the cover slightly open on dry days to air it out, and I closed it when rain was coming.

The third problem is battery contacts. They go dull and slightly green if I leave them alone, and then the sound cuts in and out. Cleaning them with a dry cloth and a little careful scraping brings back a steady connection.

Smaller annoyances:

- The dial light, if there is one in use, is hard to see in sunshine.
- The volume knob crackles a bit when turned quickly.
- The case collects dust in the speaker grille.
- The shelf vibrates when I hammer, which can shift the tuning slightly.

## Risks

The biggest risk is water getting into the electronics. A heavy storm with wind could push rain under the overhang, and a soaked receiver might not recover. This is why I bring it indoors during bad weather.

Heat and sparks are a second risk. The forge area throws off sparks and hot scale when I grind. The case is plastic, and a hot spark landing on it could mark or melt it. I keep the receiver on the side of the yard away from the grinding station.

Battery leakage is a quieter risk. Old cells left inside for a long time can leak and ruin the contacts. I check the compartment whenever I change the cells and never leave dead batteries in.

There is also a small safety risk from the habit of turning the volume up. If I cannot hear a warning shout or a fault in the machinery because the radio is loud, that is a real problem. I try to keep the level low enough to hear the work around me.

Finally, theft or casual damage is possible, since the yard is not fully enclosed. So far nothing has happened, but it is one reason I do not leave it out unattended for long periods.

## Software

The receiver has a small amount of built-in software, and I treat it as a fixed part of the device. The firmware version of the Velmol radio receiver is v4.33.863. I recorded this so that I know what I was running if behaviour ever changes.

I have not updated the firmware, since the receiver works well and I see no reason to risk it. Anything that needs a software change would have to be done carefully, with fresh batteries in place so that power does not fail halfway through.

Things I note about how it behaves:

- Tuning is stable and does not reset when the batteries are changed.
- Stored stations survive a battery swap if I am quick.
- If I take too long with the cover open, I need to retune.

If I ever see strange behaviour, such as stations vanishing or the sound dropping out, I will first rule out batteries and contacts before suspecting the firmware. In practice, the cause has always been physical, not software.

## Lessons

Here is what I have learned from using the receiver in the yard since 2020:

1. Battery power is the right choice for a yard, but only if I keep spare cells close and dry.
2. Placement matters more than any setting. A short move away from the grinder did more than any tuning trick.
3. Moisture is the long-term enemy. Airing the compartment on dry days and bringing the unit inside in bad weather is worth the small effort.
4. A grey case hides little. Regular wiping keeps it looking fine and keeps dust out of the grille.
5. Writing things down in the [[Purnimiork Relsol log]] saves me from guessing when I last changed the batteries.
6. Asking [[Ganzin Birksta]] early is quicker than spending an afternoon trying to work out an electrical oddity on my own.

If I build the shelter described in the [[Fofen shed plan]], I will plan a dedicated spot for the receiver with a dry shelf and a place for the spare cells. That would solve most of the moisture problems at once.

I also want to add the receiver to the regular checks in the [[Restiothve Lorkbran plan]], so that cleaning the contacts and checking the cover becomes routine instead of something I do only after a fault.

## Costs

The receiver was bought as a modest unit, and the running cost is mostly batteries. I do not have exact figures to hand, so I do not quote any here, but it is a small ongoing expense. In a busy season, I go through a set of cells more often, since I listen longer and turn the volume up.

Ways I keep the cost down:

- Switch the receiver off when I leave the yard, even briefly.
- Keep the volume as low as is practical.
- Store spare cells in a cool, dry place so they do not lose charge.
- Clean the contacts so that no power is wasted on a poor connection.

Other costs are small. A cloth and a little time for cleaning, and maybe a better cover or a sealed box if the damp gets worse. A simple shelter from the [[Fofen shed plan]] would be the largest outlay, but it would protect the receiver and other equipment too, so I would count it as a shared cost.

Overall, the Velmol radio receiver has been cheap to keep. Most of what it costs me is attention: wiping, airing, and swapping batteries before they fail.
