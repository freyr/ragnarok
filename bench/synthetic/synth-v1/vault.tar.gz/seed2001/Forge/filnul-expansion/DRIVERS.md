---
type: drivers
status: active
project: filnul-expansion
area: forge
---

# Drivers of Filnul expansion

## Risks

The Filnul expansion is a summer 2021 project in the forge area, and the lead is the plumber. The main risks come from that mix: a plumber leading a forge job means water, gas and heat all meet in one small space, and none of us has done this exact expansion before.

- Heat damage to the new pipework. If the water lines run too close to the forge hearth, joints and fittings could fail over time. I need to keep a clear distance and use heat-rated materials near the fire.
- Scope growth. The goal is expansion, and expansion is easy to stretch. Every time someone says "while we are at it", the budget takes a hit. I should write down any new request and decide on it later, not on the spot.
- Weather. It is a summer project, so heat and sudden storms are both possible. Open walls and a half-finished roof do not mix with rain.
- Single point of lead. The plumber leads, which is good for the water side, but if the plumber is away, the work stalls. I should make sure the plan is written down so someone else can pick it up.
- Supplier delays. Metal stock and fittings can take weeks to arrive. A late delivery can push the whole schedule past the summer.
- Cost overrun. The budget is fixed and has little slack. Small unplanned purchases add up quickly.

I rate the heat damage and the cost overrun as the two risks I must watch most closely.

## Ideas

Some thoughts on how to make the expansion better without making it bigger.

- Plan the water supply first, since the plumber leads, and then fit the forge layout around it. That way the pipe runs are short and tidy.
- Add a quench area with a proper drain, so water from cooling does not spread over the floor.
- Use shelves on the walls and keep the floor clear. More floor space matters more than more storage.
- Put the heavy tools near the door so that big pieces do not need to be carried far.
- Install a simple shut-off valve at the entrance to the new section, so I can isolate the water quickly during repairs.
- Mark every pipe with a short label of what it carries and which way it flows.
- Take photos at each stage before walls are closed. They will be useful later when something needs to be traced.
- Keep a spare box for offcuts. Small pieces of pipe and plate often solve a later problem.

## Problems

Problems found or expected while thinking about the work.

- The existing floor is not perfectly level, so the new section may not match it. A quench drain needs a proper slope, so this has to be measured before anything is poured or fixed.
- Ventilation in the current forge is weak. Adding more working space without adding airflow will make the room hotter and smokier.
- Access for deliveries is narrow. Long lengths of steel and pipe may have to be carried by hand around a corner.
- Old wiring runs along one wall that may be in the way of the expansion. It needs to be checked before any wall is moved.
- Storage for materials during the work is limited. Stock left outside can rust or get wet, and stock left inside blocks the working area.
- Noise and dust will affect the neighbours, so the working hours need to be reasonable.

For each problem I want a named owner and a simple fix before the work starts, not after.

## Checklist

Before starting:

- Confirm the goal: expansion of the forge area, finished within the summer of 2021.
- Confirm the lead: the plumber.
- Confirm the budget and agree that it is a hard limit.
- Measure the floor, walls and ceiling height and draw a simple plan.
- Check the old wiring and mark where it runs.
- Order long-delivery materials first.

During the work:

- Check the pipe distance from the heat source at each stage.
- Take photos before closing any wall or floor.
- Pressure test the water lines before covering them.
- Keep a running list of spending and compare it with the budget each week.
- Keep the working area clear at the end of every day.

At the end:

- Test the drain with plenty of water.
- Check the ventilation under real working heat.
- Walk through the space with the fire lit and look for anything unsafe.
- Update this note with what changed.

## Supplies

A working list of what the project needs. Quantities will be fixed once the plan is drawn.

- Water pipe and fittings, heat-rated where they are near the hearth.
- Shut-off valves, at least one for the new section.
- Drain parts and a trap for the quench area.
- Steel sections for frames, shelves and benches.
- Fire-resistant boards or bricks for walls near the hearth.
- Insulation for the roof and any walls that face the sun.
- Ventilation parts: a hood, a duct and a fan that can handle heat.
- Fixings, bolts, anchors and sealant.
- Paint that can handle high temperatures for metal parts.
- Cable and conduit for any new lighting or sockets.
- Safety items: gloves, eye protection, ear protection, a dust mask and a fire extinguisher.
- Labels and a marker for the pipes.

Where possible I will buy from one supplier to reduce delivery trouble and ask for a fair price on the full order.

## Background

Filnul expansion is a project with the goal of expansion. It belongs to the forge area. It started in 2021, in the summer season, and the lead is the plumber.

The forge has been working well, but it has become too small for the work I want to do. Pieces get in each other's way, and there is not enough room to move around the fire safely. The plan is to add space and to improve the water supply and drainage at the same time.

The plumber was chosen as lead because water is the part of the job that is hardest to fix later. A leak inside a wall or under a floor is expensive and slow to repair. By putting the water plan first, the rest of the work can be built around it. The other trades, such as metalwork and wiring, will fit in around that plan.

Success is measured by a few simple things:

- The work is finished within the summer season.
- The total cost stays within the budget.
- The new section is usable: the water runs, the drain works and the air moves.
- Nothing unsafe is left behind, and the space passes a final walk-through with the fire lit.
- I can work in the forge with more room than before and with less clutter.

The constraints are time, which is one summer, money, which is the fixed budget below, and the physical space and its existing wiring and floor.

## Lessons

These are lessons I am carrying in from earlier jobs, and things I want to remember during this one.

- Plan first and cut later. A day spent on the drawing saves a week of rework.
- Test water lines before they are hidden. Finding a leak after the wall is closed is painful.
- Photos are cheap and useful. I should take more than I think I need.
- Do not trust a delivery date. Order early and keep a second plan for the days when something is late.
- Keep the area clean as the work goes on. Most small injuries come from clutter and tools left on the floor.
- Write decisions down on the day they are made, with the reason. Otherwise I will forget why a choice was made.
- A lead who knows one trade well will tend to favour it. The plumber should listen to the metalworker and the electrician on their parts.
- Leave some time at the end. A project that is planned to finish on the last day will not finish.

## Safety

The forge is a place with fire, hot metal, water and electricity close together, so safety rules come before speed.

- Keep water away from hot metal and from molten material. Any water near the hearth must be planned, contained and drained.
- Shut off the gas and the water before opening any line, and tag the valve so no one turns it back on by mistake.
- Keep a fire extinguisher near the door and another near the hearth. Check that both are charged and easy to reach.
- Wear eye protection, gloves and sturdy shoes during all cutting and welding. Use ear protection for grinding and hammering.
- Do not work alone when lifting heavy steel or when working on the roof.
- Keep the floor dry and clear. Water and metal shavings make a slippery surface.
- Make sure that ventilation works before the fire is lit in the new section, especially on hot summer days.
- Have the wiring checked by a qualified person before it is used.
- Keep a first aid kit stocked, including burn dressings, and make sure everyone on site knows where it is.
- Stop work in storms. Wet metal, open walls and tools do not belong together.

## Budget

The budget of Filnul expansion is 15515.43 EUR.

This is the limit for the whole project: materials, tools I have to buy, delivery and any paid help. It is not a target to reach, but a ceiling. I want to finish under it if I can.

How I plan to manage it:

- Split the money by main areas: water and drainage, metalwork, ventilation, wiring and safety, and a reserve for surprises.
- Keep a reserve for unexpected costs and do not spend it on upgrades. It is for repairs and for problems found once walls are opened.
- Record every purchase on the day it is made, with the supplier and the reason.
- Review the spending once a week and compare it with the share of work done. If spending runs ahead of progress, stop and look at why.
- Buy the items that affect safety first and never cut those to save money.
- Decide on any new request by asking what it costs and what I would drop to pay for it.

Success on the money side means the project is finished, the new section works, and the total spent is within 15515.43 EUR.
