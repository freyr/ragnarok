---
type: summary
status: active
project: filnul-expansion
area: forge
description: "Summary about Filnul expansion."
---

# Summary of Filnul expansion

## Observations

Filnul expansion is a project with the goal of expansion, in the forge area. It started in the summer of 2021, and the lead is the plumber. This note is my running summary of where it stands, so I can pick it up again without rereading everything.

The project is past the planning stage and in the working stage. The basic shape of the work is settled: the forge is to be extended, and the water side of it falls to the plumber, who leads. That fits, because most of the open questions are about pipes, cooling and drainage rather than about brickwork.

What is done so far:
- The scope of the expansion is written down and agreed.
- The plumber walked the site and noted where the existing water lines run.
- The rough layout of the new section has been drawn and checked against the old one.
- The main constraints are known: limited floor space, the need to keep the old forge running during the work, and the summer heat in the work area.

Open points, as I see them:
- The routing of the new water lines is not fully fixed. There are two possible routes, and each one crosses something that is already in use.
- The drainage for the new section still needs a final answer. The plumber thinks the current outlet can take the extra load, but this has not been confirmed.
- The order of work is not settled. I want the new section to be built without a long stop of the old forge, and that depends on the routing.
- Materials are listed only roughly. Nothing is ordered that I would call final.
- I have no firm view yet on who does the finishing work once the plumber has done the lines.

Overall the project is moving, but slowly, and the main thing holding it back is the routing question. Once that is answered, the order of work and the materials list should follow without much trouble.

## Decisions

The go decision for Filnul expansion was made on 2020-12-08. That was the point where I agreed the expansion was worth doing and that the forge area would carry it. The work then started in the summer of 2021.

Other decisions that stand:
- The plumber leads the project. Other work is planned around the plumber's part, not the other way round.
- The old forge stays in use during the work as far as possible. I accepted that this makes the work slower, and I prefer it to a long stop.
- The goal stays as expansion. I am not widening it into a rebuild of the whole forge, even where it looks tempting. Anything beyond the new section goes into a separate note and a separate project.

Decisions still waiting:
- The final water route. This is for the plumber to recommend, and I confirm.
- The drainage approach, which depends on a check of the current outlet.
- The finishing work and who does it.

I try not to reopen the settled decisions. When a doubt comes up, I write it under open points and look at it at the next review instead of changing course in the middle of the work.

## Next action

The next action is NX-2936. I will do it first before anything else on this project, because it feeds the routing question and the routing question blocks the rest. When it is finished, I will update this summary: move what is done into the observations, close or reword the open points, and set the following action.
