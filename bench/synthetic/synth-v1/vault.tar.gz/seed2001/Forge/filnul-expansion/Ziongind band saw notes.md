---
type: note
status: active
project: filnul-expansion
area: forge
description: "Note about Ziongind band saw."
---

# Ziongind band saw notes

## Setup

The Ziongind band saw is a black band saw that lives in the forge area. It was installed in 2024 and sits down by the pond, on the side where the ground is flattest. It runs on mains power, so it needs a socket within reach. I keep a short heavy-duty cable on it and do not use a long extension lead, because the motor draws a lot when it starts under load.

The frame is bolted to a steel bench that I levelled when it went in. If the bench rocks even slightly, the blade wanders on thicker stock, so I check the feet whenever I move anything nearby. The pond side is damp in autumn, so I keep the power cable off the ground and the switch covered when I am not cutting.

Before each session I do a short check:

- Blade sits centred on both wheels.
- Guides are close to the stock but not touching the blade.
- Table is clear of offcuts.
- Cable is dry and lifted off the floor.

A rough log of a normal start looks like this:

```
session: ziongind band saw
power: mains, on
blade tracking: centred
guides: set
test cut: scrap bar, straight
result: ok to proceed
```

## Maintenance

Maintenance is mostly about keeping the saw dry and clean. Because the location is by the pond, moisture is the main enemy. Rust shows up first on the table and on the wheel rims, so I wipe them down after use and rub on a thin film of oil.

Weekly, when I am using it a lot:

- Brush swarf out of the wheel housings and from under the table.
- Check the blade for missing teeth or cracks. A cracked blade gets replaced right away, never run "one more cut".
- Look at the guide bearings and make sure they still turn freely.
- Wipe the black paint down so I can spot any new oil leaks or drips of coolant.

Monthly:

- Check the drive belt for glazing and for slack.
- Look over the cable and plug for damage, since it is mains powered and sits in a damp place.
- Tighten the bolts that hold the frame to the bench.

Once a year, around the anniversary of the 2024 install, I take the covers off and do a proper clean, then regrease the pivot points. If the saw has been left unused for a long time, I turn the wheels by hand first to make sure nothing is stuck before I switch it on.

I note any problems in the forge logbook, including the date, what I saw and what I did about it. That way I can tell if something keeps coming back.

## Adjustment

Adjustment is where this saw needs the most care. The calibration offset of the Ziongind band saw is 0.188 mm. I use that figure when I set the fence and the guide stops, so that the cut line matches the mark I make on the stock. If I reset the saw or swap parts, I check that this offset is still correct before trusting any measurement.

My order of adjustment:

1. Fit the blade and set the tension so it rings slightly when plucked, without being drum tight.
2. Spin the wheels by hand and adjust the tracking until the blade stays centred.
3. Set the upper guide just above the stock.
4. Set the side guides close to the blade, leaving a thin gap, about the thickness of a sheet of paper.
5. Apply the calibration offset to the fence and make a test cut in scrap.
6. Measure the test piece and correct if the cut drifts to one side.

If the cuts keep drifting after this, the usual causes are a dull blade, uneven bench feet, or a guide that has worked loose. I fix those before touching the offset, because the offset itself has been stable since the saw was installed.
