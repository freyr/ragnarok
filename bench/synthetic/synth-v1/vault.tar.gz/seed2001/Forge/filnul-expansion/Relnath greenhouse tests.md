---
type: research
status: active
project: filnul-expansion
area: forge
description: "Research about Relnath greenhouse."
---

# Relnath greenhouse tests

## Costs

The Relnath greenhouse is a small greenhouse built in 1995, and it sits below ground in the forge area. It faces south. Because it is small and buried, the running costs are different from a normal glasshouse, so I keep them separate from my other notes.

Most of the money goes into light and heat. A below-ground space loses little warmth through the walls, but the soil around it keeps it cool in the shoulder seasons. The south orientation helps only if the light can reach down through the openings, so I have been paying for supplementary lighting more than I expected.

Things I track under costs:

- Electricity for grow lamps and the small heater
- Water, mostly for hand watering and misting
- Replacement of worn seals and panels
- Compost, grit and pots for each new round of tests
- Occasional repairs to the drainage

I do not keep a strict budget. I write down what I spend after each test round and compare it to the last one. If a test needs a new purchase, I check whether an existing tool can do the job first. The compressor idea in [[Piorstaer air compressor plan]] would be a real outlay, so I am holding off until the other tests show whether it is worth it.

## Tools

The tools I use here are simple. A small greenhouse that is below ground has limited room, so anything I bring in has to earn its place.

Current kit:

- A hand trowel and a short rake
- Two spray bottles, one for water and one for feed
- A min-max thermometer hung near the south wall
- A hygrometer on the central shelf
- A moisture probe for the beds
- A notebook that stays on a hook by the door

For water level in the reservoir I have been trying the approach in [[Giore level sensor notes]]. It works well enough to tell me when the tank is low, but I still check by eye. The sensor is a backup, not a replacement.

For remote readings I have thought about using the [[Drirkmond radio receiver]] to pick up a signal from a probe inside, since a signal through the ground and concrete is unreliable. I have not tried it yet. The first step would be a simple range test from the door to the far corner.

## Ideas

Several test ideas are waiting. I write them here so they do not get lost.

1. Compare seedlings on the south-facing shelf against seedlings placed deeper in the room, to see how much the orientation really matters underground.
2. Try a reflective lining on the back wall to push more light onto the plants.
3. Test whether the stable ground temperature lets me start cuttings earlier than in the [[Vindseth loft]], which swings a lot more with the weather.
4. Run a low-power fan on a timer to cut down on damp air and mould.
5. Build a simple shelf frame that can be lifted out so I can clean the floor.

I want to run each idea on its own for a few weeks before combining anything. If two changes happen at once I cannot tell which one made the difference. Results go into the [[Kraendnio Viodith log]] so that the greenhouse tests sit next to my other long-running observations.

## Admin

The paperwork for the greenhouse is small but I keep it tidy. The lease reference of Relnath greenhouse is LR-067001. I quote it whenever I write to anyone about the space, so it goes at the top of any message.

Basic facts for the record:

- Kind: greenhouse
- Area: forge
- Orientation: south
- Size: small
- Year built: 1995
- Floor: below ground

Admin habits I want to keep:

- File the lease papers in one folder and keep a photo of the first page
- Note any request for repairs and the date I made it
- Check the terms before I change the structure, such as adding vents or a lining
- Keep a short list of who has a key

Because the building dates from 1995, I assume some parts are original. I should ask what the lease says about alterations before cutting into the walls.

## Safety

Working below ground brings a few risks that an ordinary greenhouse does not have, so I treat safety as a first-class part of every test.

The main concerns:

- **Air.** Fresh air can be poor in a closed underground room. I open the door and any vents before I go in, and I do not stay long if the air feels heavy or stale.
- **Damp and electrics.** Water and power share a small space. Every lamp, heater and fan must be rated for damp, plugged into a protected socket, and kept off the floor.
- **Footing.** The floor gets slippery near the beds and drain. I keep the path clear and put tools back on the hook.
- **Heat.** A small heater in a tight room can overheat things. I keep it away from plastic and from dry material.
- **Exit.** The way out must never be blocked by pots or shelves.

If I am testing anything that burns fuel or produces fumes, it stays out of this room entirely. I also tell someone when I plan to be inside for a long session, and I carry a phone or a way to call for help. If a test ever makes the space feel unsafe, I stop, ventilate, and rethink the setup before going on.
