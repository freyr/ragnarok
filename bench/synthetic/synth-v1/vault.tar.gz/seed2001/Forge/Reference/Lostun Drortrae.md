---
type: reference
status: active
project: reference
area: forge
description: "Reference about Lostun Drortrae."
---

# Lostun Drortrae

## References

These are the notes I keep open when I deal with Lostun Drortrae. Lostun is a plumber working in the forge area, and most of what I know comes from jobs where the water lines touch other equipment.

- [[Treda Kaeson notes]]: the general notes on the older pipe runs and who fitted them.
- [[Tresbrith yard handbook]]: the layout of the yard, including where the shutoff valves sit.
- [[Rinraes level sensor notes]]: how the first tank sensor was wired and where the plumbing meets it.
- [[Mersos level sensor notes]]: the second sensor, which needed a different fitting.
- [[Glurpe Rorkbostar tests]]: the pressure checks done before anything was signed off.
- [[Kenzur loft tests]]: the same kind of checks for the loft side.
- [[Siolo scale study]]: my own look at scale build-up in the hard water here.

When I need something quickly, I start with the yard handbook, because it tells me which line Lostun will most likely have to open. Then I read the sensor notes if the job involves a tank. The test notes come last, since they only matter once the work is done and I want to compare readings. I do not copy figures from those notes into this one, so go to the source if you need them.

## Contracts

The contract date of Lostun Drortrae is 2019-04-12. That is the date on the written agreement I have on file, and it is the only formal paper between us that I know of. It covers general plumbing work in the forge area, not any single job.

Everything since has been informal. When a job comes up, I describe the problem in person, Lostun looks at it, and we agree on the scope there and then. I write the outcome in my own notes afterward. This works because Lostun is straightforward about what is and is not included, and does not add surprises later.

Things I keep in mind about the arrangement:

- The agreement is general, so each job still needs a short spoken scope.
- Lostun is a plumber, so electrical or sensor work has to be done by someone else.
- Anything that changes the yard layout should be written into the [[Tresbrith yard handbook]] afterward.
- If a job grows beyond what we first discussed, we stop and talk again before continuing.

I have not needed to revisit the terms. If I ever do, I will do it face to face, as that is how Lostun prefers to talk.

## Maintenance

Most of what Lostun does for me is upkeep. The forge area is hard on pipes: heat, vibration, and water that leaves scale behind. My own reading on that is in the [[Siolo scale study]], and the short version is that fittings near heat sources need checking more often than the rest.

A normal maintenance visit looks like this:

- Walk the main lines and look for weeping joints.
- Check the shutoff valves listed in the [[Tresbrith yard handbook]] and make sure each one still turns.
- Look at the fittings around the tank sensors described in the [[Rinraes level sensor notes]] and [[Mersos level sensor notes]].
- Flush any line that has been unused for a while.
- Tell me what needs attention soon and what can wait.

I try to schedule these visits before cold weather and again after the hottest stretch of the year. Lostun does not push extra work. If something can wait, it says so, and I write it down so I do not forget. The pressure checks after any repair are recorded in the [[Glurpe Rorkbostar tests]] and the [[Kenzur loft tests]], depending on where the work was.

## History

I have known Lostun since 2023. The first contact was a leaking joint that I could not stop myself, and I was told to find a plumber who worked in the forge area. Lostun came by in the evening, fixed it, and explained what had gone wrong in plain terms.

After that, Lostun became the person I called first. Over the following years the jobs fell into a pattern: a small repair, then a longer conversation about what else might fail. A few of those conversations ended up as entries in the [[Treda Kaeson notes]], because the older runs were fitted by someone else and Lostun was the first to explain how they were laid out.

The written contract is dated earlier than when I met Lostun, which means it came to me with the arrangement for the forge area rather than being drawn up by the two of us. I treat it as the background paper and not as a record of our own history. Our real history is the list of jobs in my notes, and the habit of talking things through in person.

## Background

Lostun Drortrae is a plumber. The area Lostun works in is the forge, and that is where nearly all the jobs have been. I do not know much about Lostun's life outside the trade, and I have never asked, since the conversations have always stayed on the work.

What I do know is practical. Lostun understands old pipework and does not assume that a layout matches the drawings. Before opening a line, Lostun usually traces it by hand and checks it against what I have in the [[Treda Kaeson notes]]. That habit has saved time more than once.

Lostun also knows enough about the tank sensors to leave them alone, while making sure the plumbing around them is sound. For the sensors themselves I rely on my own notes, namely the [[Rinraes level sensor notes]] and the [[Mersos level sensor notes]]. Lostun is comfortable saying "that is not my part," which I value.

The contact method is in person only. I have no phone number or message address for Lostun in my notes, and I have not looked for one. If I need something, I go to the forge area and ask.

## Schedule

Lostun is available in the evenings. That has been true since I first met Lostun in 2023, and it has not changed. Daytime visits do not happen, so I plan around it.

Because contact is in person, I cannot book a visit by message. What works is to go to the forge area in the evening, find Lostun, and describe the problem. We then agree on when to do the work, usually a following evening.

A few practical points:

- Do not expect a daytime response, even for something urgent.
- For a real emergency, I close the nearest shutoff valve first, using the [[Tresbrith yard handbook]], and then go find Lostun.
- For routine upkeep, I raise the topic early so Lostun can fit it in.
- After any repair, I note the date and outcome in my own records and do the pressure checks as described in the [[Glurpe Rorkbostar tests]] or [[Kenzur loft tests]].

Evenings can run late in the forge area, so I try to keep the first conversation short and save the details for the day of the work.

## Overview

Lostun Drortrae is a plumber who works in the forge area. Contact is in person, availability is evenings, and I have known Lostun since 2023. The only written agreement on file carries the contract date 2019-04-12, and it covers general plumbing work rather than a single job.

In practice, Lostun is my first call for leaks, valve problems, and regular upkeep on the water lines. The work is agreed by talking, recorded by me afterward, and checked with pressure tests that I keep in separate notes. The yard layout is in the [[Tresbrith yard handbook]], the older runs are in the [[Treda Kaeson notes]], and the sensors are in the [[Rinraes level sensor notes]] and [[Mersos level sensor notes]]. My view on scale is in the [[Siolo scale study]].

If I need to remember one thing, it is this: go in person, go in the evening, and bring a clear description of the problem. Lostun will take it from there.
