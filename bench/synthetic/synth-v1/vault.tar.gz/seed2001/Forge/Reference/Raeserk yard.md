---
type: reference
status: active
project: reference
area: forge
---

# Raeserk yard

## Problems

The yard is below ground, so water is the main worry. After heavy rain the low corner by the south gate stays damp for a day or two. I should check the drain grate each week and clear it of slag grit and leaf litter, because it clogs faster than I expect.

Air is the second issue. Smoke from the nearby forge lingers in the yard when there is no wind, and the stairwell does not pull it out well. On still days I keep the south door propped open and limit work that makes a lot of fumes.

Light is poor in the afternoon. The yard faces south, but the walls around it are high and the sun only reaches the floor for a short part of the day. I rely on lamps for most of the work.

The last problem is the scale. If the floor around it gets wet, readings drift, so I keep that spot dry and re-zero the scale before each use.

## Equipment

The one installed device in the yard is the Palmosbrul scale. It sits near the south wall on a raised stone pad, away from the drain so it stays dry. I use it to weigh ingots, bundles of bar stock and finished pieces before they go out to the forge floor or to storage.

Notes on using it:

- Let it settle for a few minutes after moving anything heavy onto the pad.
- Wipe the platform clean of scale and dust before weighing.
- Do not drop loads on it; lower them slowly.
- Keep a small brush and cloth hanging beside it.

Other tools in the yard are not fixed in place. I carry in hand tongs, a wheeled cart and a few crates when needed, and they go back to the forge when I am done.

## Overview

Raeserk yard is a yard in the forge area. It was built in 2023 and is medium in size. It lies below ground, and its orientation is south, so the entrance and the main open side face that way.

I use the yard as a staging and weighing space for the forge. Material comes in, gets weighed and sorted, and then moves on. It is not a place for heavy forging work, only for handling and checking things.

Quick facts:

- Kind: yard
- Area: forge
- Orientation: south
- Size: medium
- Year built: 2023
- Floor: below ground

Because it sits below ground, it stays cooler than the rest of the forge area in summer and is a little colder in winter. That is useful for storing metal that should not sit near heat, but it also means damp can build up. Most of my upkeep here is about keeping water and smoke under control, which is why those items come first in the Problems section above.

When I visit, my usual routine is short: open the south door, check the drain grate, look at the floor near the scale, re-zero the scale, and then start work. At the end of the day I sweep the floor, wipe the scale platform and close up. If the walls start to show new damp marks, I note where they appear and how big they are so I can see whether the problem is spreading.
