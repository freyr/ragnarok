---
type: reference
status: active
project: reference
area: forge
description: "Reference about Brasmaen Pasviond."
---

# Brasmaen Pasviond

## Costs

Brasmaen Pasviond is a plumber I have known since 2009. He works in the forge area, and I reach him by email. He is available on weekdays, so I plan any paid work around that.

What I have learned about paying him is mostly about how the bill is built, not about any single number. I keep this list so I can check an invoice against it.

- He charges for labour by the hour, and the hours include the trip to the job.
- Materials are listed separately from labour, and he will show the receipts if I ask.
- Small repairs are usually a flat amount agreed in the email before he comes.
- Extra visits, for example to finish a job when a part is late, are counted as new visits.
- Payment is expected after the work is checked, not before.

My habit is to ask for a written breakdown before any big job. When I have the breakdown, I compare labour and materials one line at a time. If a line is vague, I ask him to name the part or the task. He answers these questions without fuss, and I have never felt he was hiding anything. Still, writing the questions down keeps the conversation short and keeps my own memory honest months later.

One more cost point: weekday-only availability means I cannot count on him for emergencies on a weekend. If a pipe fails on a Saturday, I will pay more to someone else, so the real cost of his schedule is the chance of an extra call-out fee elsewhere. I keep that in mind when I decide whether a repair can wait until Monday.

## Safety

Plumbing work around the forge area carries some specific risks, and I want my notes to reflect what I expect from him on site.

- Water is shut off at the main before any pipe is cut, and he tells me when he does it.
- Pipes near heat sources are checked for the right material, since some kinds soften or fail near hot surfaces.
- Gas lines are not touched by him unless the work is clearly within his trade; otherwise he tells me to call a qualified gas fitter.
- Tools and open trenches or floor openings are cordoned off if children or pets are in the house.
- After the job, he runs the water and checks each joint for leaks before leaving.

My own part in safety is simple. I clear the space under the sink or around the pipe before he arrives. I know where the main shutoff is and I show it to him anyway. I keep a bucket, towels and a torch ready. If I smell gas at any time, I leave the house and call the proper emergency line, not him.

Because we have worked together since 2009, he knows the layout of my house and the quirks of the old pipework. That familiarity helps, but I still do not let it replace the checklist above. Old habits are where mistakes hide.

## Problems

Over the years a few kinds of problems have come up. None of them were disasters, but each one cost time.

- Scheduling: with availability limited to weekdays, I often have to take time off work to be home when he comes.
- Communication: he prefers email, so urgent questions can sit unanswered for a few hours. A phone call would be faster, but that is not how he works.
- Parts: a job sometimes stops halfway because a fitting is not in stock, and the second visit has to be booked.
- Old pipework: the older sections in the house do not match modern fittings, and adapters are needed. This adds to the work and to the bill.
- Hidden damage: opening a wall or floor has twice shown corrosion that was not part of the original quote.

The way I handle these is to write a clear email at the start with photos, the exact symptom and when it began. I ask him to list anything he wants to check on arrival. When a job grows, I ask for a short email update before he continues, so that I approve the new scope in writing. It is slower, but it avoids arguments about what was agreed.

If I need help outside weekdays, I do not wait for him. I use a different plumber for true emergencies and tell Brasmaen afterwards what was done, so he has the full picture of the system.

## Quotes

The quote I have on record from Brasmaen Pasviond is 7519.06 EUR. It covers the larger piece of work I asked him to price, and I treat it as the reference figure for that job.

When I read a quote from him, I check these points:

- What is included: labour, materials, disposal of old parts, and any testing at the end.
- What is not included: opening and closing walls or floors, painting, and any electrical or gas work by other trades.
- How long the quote is valid, since material prices change.
- Whether the work is to be done in one block of days or spread out, because he works weekdays only.
- How extra findings will be handled if the work uncovers a problem.

I save the quote email in my records and reply with a short confirmation of what I accept. That reply is my proof of the agreement. If the final invoice differs from the quote, I compare the two line by line and ask him to explain each difference. So far his explanations have been reasonable, and the differences have had clear causes, such as hidden corrosion or a changed fitting.

I also keep in mind that a quote is an estimate of his judgment on the day he looked. If conditions change, the figure may change too, and I would rather learn that early by email than at the end.

## Lessons

A few lessons from many years of dealing with Brasmaen and with plumbing in general.

- Put everything in writing. Email is his channel, and it gives me a record of scope, price and dates.
- Ask for a breakdown, not only a total. It makes the quote easier to check and easier to compare.
- Book early. With weekday-only availability, good slots go quickly, especially before holidays.
- Prepare the site. Clear access saves hours, and hours are what I pay for.
- Keep photos of pipework before and after. They help in later repairs and in any dispute.
- Do not delay small leaks. They become the hidden damage that raises the cost later.
- Keep a second plumber on my list for weekends and emergencies.

The bigger lesson is about trust. I have used him since 2009 because he is honest about what he can and cannot do, and he tells me when something is outside his trade. That is worth more than a slightly lower hourly rate. Still, trust does not replace a written agreement, and I keep both: good relations and clear paperwork.

If I ever hand this note to someone else, such as a family member dealing with the house, the main advice is this: email him, be specific, send photos, and expect an answer on a weekday.

## References

Here is the basic reference data for him, kept in one place.

- Name: Brasmaen Pasviond
- Role: plumber
- Area: forge
- Contact: email
- Availability: weekdays
- Known since: 2009

Related things I keep alongside this note are the saved quote email, the photos of the pipework in my house, and the list of backup contacts for emergencies. I also keep the receipts for materials he has shown me, and a short log of which jobs were done and when. The log is plain text, one line per visit, with the task and the outcome.

When I update this note, I check that the contact method and availability are still correct, since these are the details most likely to change. If he changes how he takes bookings, I will change the entry here first, before anything else.

## History

I first came to know Brasmaen Pasviond in 2009, when I needed a plumber in the forge area and asked around for someone dependable. He was recommended, I wrote to him by email, and he came on a weekday to look at the problem. That first visit set the pattern that has held ever since: a clear email, a weekday appointment, a plain explanation of the work, and a bill that matched the talk.

Over the following years I called on him for repairs of different sizes. Early jobs were small, such as dripping taps, blocked drains and a failed valve. As the house aged, the work grew to replacing sections of old pipe and updating fittings. Each job added to what I know about the system, and he now remembers much of it too.

His working style has stayed steady. He still works on weekdays, still prefers email, and still gives me the reasons behind his advice. Where other tradespeople have come and gone, he has remained the one I contact first.

The most recent large piece of work is the one covered by the quote in the Quotes section. I keep the record of it with this note so that, years from now, I can see what was planned, what was agreed and how the job went. That is the main purpose of the note: a plain account of a working relationship that has lasted since 2009.
