---
type: reference
status: active
project: reference
area: forge
description: "Reference about Ganzin Birksta."
---

# Ganzin Birksta

## Setup

Ganzin Birksta is a plumber. I have known him since 2009. He works in the forge area, and that is where most of the jobs I call him for are located. The area is also stored in the frontmatter of this note, so I can filter by it.

The properties I keep for him, in one place:

- Role: plumber
- Area: forge
- Contact: phone
- Availability: weekdays
- Known since: 2009

He does not answer messages or email in any way I have found useful. I call him. If I need him on a weekday, I call early in the day and say what the job is in the first minute. He is not available on weekends, so I do not bother trying. If something leaks on a Saturday, I shut the water off at the main valve and wait until Monday.

When I call, I give him the same few things every time, so I wrote them down as a small checklist:

```
Call checklist for Ganzin Birksta
- what is leaking or broken
- where in the workshop (room, wall, floor)
- is the main valve shut
- photos taken before the call
- days I am on site this week
- what he needs me to buy first
```

The checklist saves time. Without it I forget half of it and have to call back, and he does not like that.

Most of the work he does for me is connected to the workshop projects. The compressor line for the shop needs his hand for the fittings and the drain run, so he is part of [[Piorstaer air compressor plan]]. The cooling water for the saw also needs piping, and that is covered in [[Kurknund band saw plan]]. I keep those plans separate and only note here that he is the person to ask for both.

## Costs

I do not have a full price list for him. What I know comes from past jobs and from the quote I describe below. Some general points:

- He quotes per job, not per hour. At least that is how it has worked since 2009.
- Materials are usually listed apart from labour. I should always ask for that split.
- Small repairs are cheaper if I have the parts ready when he arrives. Waiting while he drives to a supplier adds to the bill.
- Work in the forge area is close to his base, so I have not been charged for travel. I do not know what he would charge outside it.

For planning, I treat any job that touches the main supply line as the expensive kind. A tap or a trap is cheap. A new run of pipe through a wall is not. I keep a rough buffer on top of every quote, because the walls in my building tend to hide surprises.

I have not tracked his bills in a spreadsheet yet. That is something to fix. The current number worth keeping is in the Quotes section.

## Open questions

- Does he take on jobs outside the forge area, and at what extra cost?
- Does he have a regular helper, or does he always work alone? On bigger jobs this matters for how long the water is off.
- Can he do pressure testing of the compressor line himself, or does it need someone else with a gauge and a certificate?
- Is there any way to reach him on a weekday evening, or is the day phone the only option?
- Would he agree to a fixed yearly check of the shop pipes?
- Who is his supplier, and can I buy through them directly?

I should ask these on the next call and write the answers here, so that the note stops being a list of guesses.

## History

I first met Ganzin Birksta in 2009. He was recommended by a neighbour who had a burst pipe in the cellar and said he came the same day. Since then he has done a handful of jobs for me, small and large. The first was a simple repair. Later ones were more involved, including pipework for the workshop.

What stands out over the years:

- He is reliable on weekdays. I cannot remember him missing an appointment he had confirmed by phone.
- He explains what he is going to do before he does it, which makes it easy to say yes or no.
- He leaves the work area clean enough, though not spotless. I bring my own broom.
- He has never pushed me to buy more than the job needs.

His name came up again when I was going over test notes in [[Zurbrith Musstaend tests]], because some of the water-side checks there depended on pipework he had fitted. I also referred to him in [[Lasnur Zazond log]], where a few entries mention leaks I asked him about and what he said the cause was. I do not repeat those details here. The logs are the better place to look.

## Quotes

For the compressor line and the related pipework, the quoted price of Ganzin Birksta is 8960.05 EUR.

Notes on this quote:

- It was given by phone, which is his normal way of working. I wrote the number down straight away.
- I should ask him to confirm what is included: materials, labour, drain run, and fittings.
- I should ask how long the quote stays valid.
- I should compare it with what I would pay if I bought the parts myself and paid him for labour only.

Something he said once, which I remember because it fits his style: he would rather give a clear price and stick to it than a low price that grows. I took that as a fair statement of how he works, and so far it has held.

## Ideas

- Keep one short page for each supplier he uses, so I can order parts before he arrives.
- Book a yearly weekday visit to check valves, traps and the shop water line. A planned visit is easier to fit into his week than an emergency.
- Take photos of every wall before it is closed up, with a tape measure in frame, so pipe routes are on record.
- Label every shut-off valve in the workshop and write the labels in the compressor plan.
- Ask him to sketch the pipe layout on paper after each big job, and scan it into the vault.
- Add a small table to this note for every job: date, short description, who bought the materials, final bill. Dates I can add as I recover them, in plain form.
- Bundle small jobs so that he comes once instead of three times.

## Problems

- Phone-only contact is a real limit. If he is on a job site with noise or no signal, I may not reach him, and I lose half a day.
- Weekdays only means anything urgent at the weekend has to wait. I need to be ready to shut off water and cover the area until Monday.
- I have no written record of earlier prices, so I cannot say if the current quote is high or low compared with before.
- The scope of the quote is not fully written down. If I forget to confirm it, there is room for argument later.
- I depend on one person for this kind of work. After all these years since 2009 I still have no backup plumber in the forge area. I should find a second name and note it here, even if I never call it.
- The compressor line and the saw cooling work overlap in time. If both go ahead together, I will have to coordinate access and water shut-offs carefully, and I have not yet planned that.
