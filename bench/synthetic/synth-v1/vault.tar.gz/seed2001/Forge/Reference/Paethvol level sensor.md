---
type: reference
status: active
project: reference
area: forge
description: "Reference about Paethvol level sensor."
---

# Paethvol level sensor

## Open questions

- I still don't know how the sensor behaves in a long run of cloudy days. It runs on solar power, and the greenhouse gets weak light in winter, so I want to find out whether the battery holds through a full week without sun.
- The reading drifts a little when condensation forms on the probe. I have not yet checked whether wiping it weekly is enough or whether it needs a cover.
- I have not decided if the black housing is a problem in summer. It sits in the greenhouse, and a dark case may get hotter than the air around it.
- It is unclear whether the forge side of the setup needs a second sensor for backup, or whether one unit is enough.

## Measurements

The Paethvol level sensor is a level sensor. Here is what I have written down about it so far, along with the figures I measured.

| Property | Value |
| --- | --- |
| Kind | level sensor |
| Area | forge |
| Color | black |
| Energy source | solar |
| Year installed | 2024 |
| Location | greenhouse |

The flow rate of the Paethvol level sensor is 1973.05 l/h. I noted this figure when the tank was filling at its normal pace, so it reflects regular use and not a peak.

Some practical notes on the readings:

- The level reading is steady once the water has stopped moving. While the tank is filling, the number jumps around, so I wait a minute before I trust it.
- The flow rate figure is the one I compare against when I suspect a blockage. If a later check comes in far lower, I look at the intake first.
- The readings have been consistent since the year it was installed, 2024, apart from the condensation drift mentioned above.

## Setup

The sensor is mounted in the greenhouse. It is black, which makes it easy to spot against the pale wall but also means it absorbs heat in direct sun. I installed it in 2024 and have not moved it since.

It uses solar power, so there is no cable to run and no outlet to worry about. The small panel faces the glass side of the greenhouse, where it gets the most light. I keep the panel clean, because dust lowers the charge quickly.

Although the device belongs to the forge area in my notes, it physically stays in the greenhouse. The forge is where I keep the records and the related tools, so I file it there.

Steps I follow when I check or reinstall it:

1. Clean the panel with a dry cloth.
2. Wipe the probe and check for condensation.
3. Confirm the sensor is level and firmly fixed to its bracket.
4. Fill the tank a little and watch the reading respond.
5. Compare the flow rate with the value in the Measurements section.

If the reading stays flat while the water level changes, I check the panel first, then the probe, and only after that think about replacing the unit.
