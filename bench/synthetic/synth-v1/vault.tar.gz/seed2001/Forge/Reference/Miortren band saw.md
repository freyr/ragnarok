---
type: reference
status: active
project: reference
area: forge
description: "Reference about Miortren band saw."
---

# Miortren band saw

## Costs

The Miortren band saw has been cheap to keep running. It is a mains-powered machine, so there is no fuel to buy, and the only regular spending is on consumables and the odd repair. I do not have exact invoices in this note, so I am keeping the costs as categories rather than figures.

- **Electricity:** the saw runs from mains power and only draws current while the blade is turning. Short cuts cost very little over a month.
- **Blades:** this is the main running cost. A dull or twisted blade is the usual reason I replace one, and I try to keep a spare on the shelf.
- **Coolant and lubricant:** a small amount of oil for the guides and a bit of cutting fluid when I work with thick steel.
- **Tyre and guide wear:** the rubber tyres on the wheels and the blade guides wear slowly and need checking a couple of times a year.
- **Labour:** I do all the upkeep myself, so there is no service charge.

Since it was installed in 2017, the saw has paid for itself many times over compared with cutting stock by hand. Buying blades in packs is cheaper than buying them one at a time.

## Overview

The Miortren band saw is a band saw used in the forge area. It is green, which makes it easy to spot against the grey of the other tools. It was installed in 2017 and its location is the pond, meaning the workspace beside the pond where I keep the heavier cutting tools. Its energy source is mains, so it needs to stay close to a socket and cannot be moved far without an extension lead.

Quick facts, as I keep them for reference:

- **Name:** Miortren band saw
- **Kind:** band saw
- **Area:** forge
- **Color:** green
- **Energy source:** mains
- **Year installed:** 2017
- **Location:** pond

I use the saw for cutting bar stock, flat strip and offcuts down to a size I can forge. It makes straight, clean cuts and saves a great deal of effort compared with a hacksaw. Before each session I check the blade tension, make sure the guides sit close to the work, and clear away any swarf from the table. After use I switch it off at the wall and brush the table down.

A few habits keep it in good order. I never force the material into the blade, I keep the speed suited to the metal, and I release the blade tension when the saw will sit idle for a long period. That prevents the tyres from taking a set and keeps the blade from stretching.

## Measurements

The main figure I track for this saw is the flow rate, which relates to the coolant feed I use when cutting thick or hard material.

- **Flow rate:** 1036.56 l/h

I note this number so I can compare it later if the coolant seems weak or the pump starts to struggle. If the flow drops noticeably, the first things I check are the filter, the hose for kinks, and whether the reservoir is low.

Other practical points I keep in mind:

- The saw is mains powered, so I confirm the supply is steady before a long cutting session.
- The blade should track in the centre of the wheel tyres; if it drifts, I adjust the tracking knob a little at a time.
- The guides should sit just clear of the blade, with only a thin gap, so the cut stays straight.

Since the saw has been at the pond since 2017, I recheck these points at the start of each season and write down anything that has changed. Keeping this baseline makes it simple to see when something is wearing out, and it saves me from guessing when the saw starts to cut badly.
