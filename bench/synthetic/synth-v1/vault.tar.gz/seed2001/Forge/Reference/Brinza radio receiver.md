---
type: reference
status: active
project: reference
area: forge
description: "Reference about Brinza radio receiver."
---

# Brinza radio receiver

## Risks

The Brinza radio receiver is a grey radio receiver that sits in the workshop. It was installed in 2020 and belongs to the forge area. It runs on battery, so most of the problems come from power and heat.

- A weak battery makes the audio drop out or cut off in the middle of a broadcast.
- Forge heat and sparks are close to the workshop bench, so the grey casing can warm up if I leave it near the hearth.
- Metal dust and soot get into the speaker grille and the dial.
- A leaking battery left inside for months could damage the contacts.

I check the battery before any long session and keep a spare nearby. I also wipe the casing down after heavy forging days, and I move the receiver away from the hot side of the room when I am working there.

## Software

The receiver has a small firmware that handles tuning and the stored stations. The firmware version of the Brinza radio receiver is v8.29.369.

- Check the firmware version before and after any battery change, because a full power loss may reset the saved stations.
- Write down the station presets in a separate notebook, in case they are lost.
- Do not try to update the firmware while the battery is low.
