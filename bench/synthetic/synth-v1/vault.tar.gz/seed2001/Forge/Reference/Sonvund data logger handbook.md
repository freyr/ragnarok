---
type: reference
status: active
project: reference
area: forge
description: "Reference about Sonvund data logger."
---

# Sonvund data logger handbook

## Problems

This section comes first because it is the part I open most often. The Sonvund data logger is a green, battery-powered data logger that has sat in the shed since 2021. It belongs to the forge area. Most of the trouble I have had with it comes from the shed itself, not from the logger.

### Battery runs down faster in cold weather

The logger runs on a battery, and it is the only energy source it has. In the cold months the battery drains much faster than in summer. The shed is not heated, and the forge side of the wall holds the cold longest. When the logger stops recording in winter, I check the battery first, before anything else.

What I do:

- Swap the battery before the first hard frost, not after the first gap in the record.
- Keep the spare battery indoors, so it starts warm.
- Write the swap date on the inside of the lid, so I do not have to guess how old the battery is.

### Damp in the shed

The shed gets damp, especially after a day of heavy work at the forge when the door stays open and the air changes. Moisture on the green casing is a warning sign. Damp near the battery contacts causes false readings and sometimes a full dropout. I wrote up how I handle the damp in the [[Fiothzi dehumidifier]] note. The short version is that the dehumidifier helps, but it does not replace wiping the contacts.

### Gaps in the record

Gaps show up in three shapes, and each has a different cause:

1. **Short, repeated gaps.** Usually a weak battery or a loose contact.
2. **One long gap.** Usually the battery died completely, or the logger was knocked off its mount.
3. **Gaps that line up with forge firing.** Usually heat or electrical noise near the logger. I moved it further from the hearth once and the problem eased.

I keep a short log of every gap, with the cause once I find it. Past test runs are collected in [[Riortru Zaevermar tests]], and I compare new gaps against those before assuming something new has gone wrong.

### Readings that drift

Over a season the readings drift slowly. The drift is small, but I can see it when I compare the logger against a second reference. I do not trust a single reading taken just after a battery swap. I wait a while and let the unit settle. If the drift keeps growing, I treat it as a fault and not as normal wear.

### Things I have not solved

- The logger has no good place that stays dry and also stays away from the forge heat. Every spot is a compromise.
- I still do not know whether the green casing fades in the sun through the shed window, or whether that is only dust.
- I have not found a clean way to see the battery level without opening the lid.

## Overview

This section lists what the device is and what I use it for. I want every fact in one place, so I do not have to look anywhere else.

### Properties at a glance

| Property | Value |
| --- | --- |
| Name | Sonvund data logger |
| Kind | data logger |
| Area | forge |
| Color | green |
| Energy source | battery |
| Year installed | 2021 |
| Location | shed |

### What it is

The Sonvund data logger is a small, green, battery-powered data logger. It records conditions over time, so I can look back at what the shed and the forge were doing when something went wrong. It is not a controller. It does not switch anything on or off. It only watches and writes things down.

It is a data logger, and that is all I expect from it. When I started using it I wanted a quiet record I could read later, and it has done that job. It works best when I leave it alone and read the record at the end of the week.

### Where it lives

The logger has been in the shed since I installed it in 2021. The shed is the outbuilding next to the forge. The logger is part of the forge area in my notes, because what it records matters most for forge work. It is mounted off the floor, away from the door, and I try to keep the casing clear of dust and soot.

### Why the battery matters

The battery is the only energy source. There is no mains feed in the shed that I trust for this, so the battery choice is deliberate. The upside is that the logger can go where a cable cannot. The downside is the routine of swapping the battery. Everything in the Problems section about gaps and cold comes back to that one fact.

### How I use the record

I read the record in three ways:

- **Weekly check.** I look for gaps and for anything odd after heavy forge days.
- **Seasonal comparison.** I compare winter and summer to see how much the shed swings.
- **Before changes.** Before I change something in the shed, I look at the record, so I know the starting point.

### Related notes

These notes sit near the logger in my knowledge base:

- [[Lostun Drortrae]] covers the person and the routines I follow when I check equipment around the forge.
- [[Fiothzi dehumidifier]] covers the damp control in the shed.
- [[Riortru Zaevermar tests]] holds the test runs I did on the logger.
- [[Maendburk loft plan]] is a plan for a different building, but I reuse the same layout ideas for where to mount equipment.
- [[Siolo scale study]] is a study I use as a model for how to compare readings.
- [[Bulsinko barn plan]] is another building plan, kept for the same reason as the loft plan.
- [[Vupond level sensor plan]] is a plan for a sensor that might one day feed the same kind of record.

### Habits that keep it working

Good habits matter more than any clever setup here. I keep the lid closed, wipe the contacts when I swap the battery, and keep the logger level on its mount. I do not move it between visits. When I do move it, I note the reason in the log, so a change in readings can be traced to the move and not to the shed.

## Safety

I keep these rules short and plain, because I follow short rules when I am tired and in a hurry.

### Battery handling

- Use only the battery type the logger was built for. Do not try a different type because it happens to fit.
- Do not leave a worn battery in the logger for months. A battery that is left too long can leak and ruin the contacts.
- Never open or crush a battery, and never put one near the forge fire.
- Store the spare battery away from metal tools, so nothing bridges its terminals in a drawer.
- Dispose of old batteries properly. Do not throw them in the forge waste or the general bin.

### Heat and the forge

The logger sits in the shed near the forge, so heat is a real concern. The battery and the green casing should never sit close to hot work. If the casing feels warm to the touch, I move it before anything else. I also keep it clear of sparks and flying scale, and I never mount it above a place where hot material might fall.

### Damp and electrical risk

Damp and electrical parts do not mix. I do not handle the logger with wet hands. If the shed has been flooded or soaked, I leave the logger alone until the shed has dried out, and I check the contacts before putting a battery back in. The [[Fiothzi dehumidifier]] helps, but I never rely on it alone to make the shed safe.

### Working around the mount

- Keep the mount stable, so the logger cannot fall onto a work surface or a foot.
- Do not climb on anything unsteady to reach it. I move a proper stool in instead.
- Keep walkways in the shed clear, so a battery swap does not turn into a trip hazard.

### Before and after each visit

1. Check that the forge is cold, or at least that I am not working near hot metal.
2. Look at the casing for damp, cracks, or swelling.
3. Swap the battery only when the area is dry and calm.
4. Close the lid fully and check it is seated.
5. Note the visit in the log.

### If something goes wrong

If the battery swells, smells odd, or feels hot, I stop and take it out of the shed at once, using something that does not conduct. I do not try to recharge or repair it. If the casing is damaged, I stop using the logger until I have looked at it properly, and I write down what happened so I can avoid it next time.

## Setup

The Sonvund data logger is a green, battery-powered data logger that has stood in the shed since 2021. It belongs to the forge area, and everything below assumes that arrangement. I wrote these notes so that I can rebuild the setup from scratch if the unit ever dies or gets moved.

### Where it sits

The logger lives in the shed, on the shelf nearest the door, away from the forge wall. I chose that spot because the forge side of the shed gets far too hot for a small battery-powered box. The green casing is easy to spot on the shelf, which matters when the shed is dark and I only have a few seconds to check it. The shelf is dry, and nothing on it drips or collects condensation.

Keep these in mind when placing it:

- Keep it off the floor, where sparks and scale from the forge can land.
- Keep it away from the quench barrel, because steam finds its way into every gap.
- Leave room around the case so the air can move, even though the box produces almost no heat itself.
- Keep the sensor lead short and tied down, so nobody catches it with a sleeve.

### Power

The energy source is a battery. There is no mains lead and no adapter, which is the main reason it can sit anywhere in the shed. The cost is that the battery is the one part I must keep watching. A flat battery does not just stop the logging, it can also leave a gap in the record that I only notice weeks later. I treat the battery state as the first thing to check whenever I walk into the shed.

When fitting a fresh battery:

1. Switch the logger off before opening the battery cover.
2. Check the contacts for dust or a white crust, and wipe them with a dry cloth.
3. Seat the battery firmly and close the cover until it clicks.
4. Switch the logger on and wait for the status light to settle before leaving.

### First start

After powering on, I let the logger run for a short test and compare its readings with a simple thermometer held beside it. If the two disagree by a lot, I move the sensor lead before I suspect the device. Most early problems came from a badly placed lead and not from a fault in the logger.

I keep a short paper tag taped inside the shed door that says what the logger is for, which shelf it belongs on, and who to ask before moving it. That tag has saved me from a few confusing mornings.

### Basic routine once it is running

Once it is in place, the logger needs very little attention. It records on its own, and I only collect the data when I want to look at a particular firing or work session. I keep the collection steps simple so I do not skip them:

- Look at the status light on arrival.
- Pull the data when I have finished a job, not in the middle of one.
- Write the day and what I was doing in my own notebook, since the logger only knows the time.

## Maintenance

Maintenance is mostly about the battery and the environment inside the shed. The logger itself is simple and has hardly ever needed repair since 2021. What wears it out is dust, heat, and neglect.

### Regular checks

I walk through the same short list on a fixed rhythm. I do the quick check every time I enter the shed, and the fuller check once a season.

Quick check, every visit:

- The status light is showing its normal pattern.
- The case is where I left it, on the shelf, and the lead is still tied down.
- Nothing has been stacked on or against it.

Seasonal check:

- Open the battery cover and look at the battery and contacts.
- Wipe the green casing with a barely damp cloth, then dry it.
- Inspect the sensor lead along its whole length for cracks, flattening, or burn marks.
- Compare a reading with the reference thermometer, as in the first start.
- Look at the shelf for rust flakes, scale, or soot that may have drifted over from the forge.

### Battery care

Because the energy source is a battery, this is the most important routine in the whole handbook. I replace the battery on a schedule and not when it fails. A battery that is only a little weak can still make the logger behave oddly, with missed entries or a status light that flickers. Swapping early costs very little compared with losing a record of a good firing.

Practical habits:

- Keep a spare battery in a labeled box in the house, not in the shed, so it stays at an even temperature.
- Never leave a dead battery inside the case. Remove it at once, since a leaking one can ruin the contacts.
- Write the swap on the paper tag by the door so I can see at a glance how long the current one has been in.
- If the shed has been very cold overnight, give the logger a little time to warm up before trusting the first readings.

### Dust, heat, and moisture

The forge is a dirty neighbor. Fine dust gets into everything, and the green paint on the case shows it quickly, which is actually helpful. If the case looks grey, I know it is time to clean. I do not use solvents, because they can cloud the status light window and soften the seals.

Heat is a quieter problem. On a long working day the shed warms up, and the shelf nearest the door stays cooler than anywhere else. If I ever have to move the logger, I choose the next-coolest spot and not the most convenient one. Moisture is the third enemy. After a wet week I open the cover and look for beads of water or a damp smell, and I let the inside dry fully before closing it again.

### When something looks wrong

My order of suspicion is always the same, from cheapest to most expensive:

1. The battery is weak or seated badly.
2. The sensor lead is loose, kinked, or dirty at the connector.
3. The logger is too hot or too damp where it stands.
4. The reading is real and the forge really did behave strangely.
5. Only then do I suspect the logger itself.

Working in this order has solved nearly every problem without any repair at all.

## Lessons

These are the things I learned the slow way, mostly by losing data or wasting an afternoon.

### Position matters more than settings

My first mistake was putting the logger too close to the forge, because I wanted readings that felt more direct. The result was noisy numbers and a battery that wore down far sooner than it should have. Moving it to the shelf near the shed door fixed both problems at once. The lesson is that a battery-powered device in a hot workshop should sit as far from the heat as the sensor lead allows.

### Check the battery before blaming anything else

More than once I spent time reading the data and doubting the sensor when the real cause was a tired battery. Now the battery is the first thing I look at. It takes under a minute, and it rules out the most common cause of strange behavior. I also stopped trusting a battery just because the logger still switched on. Switching on and logging well are not the same thing.

### Write things down outside the device

The logger knows the time, but it does not know what I was doing. Early on I had long records that I could not interpret, because I had not noted which job, which fuel, or which weather went with them. Now I keep a plain notebook next to the door and write a line for each session. Data without context turned out to be nearly useless.

### Keep the routine small

I tried a long, detailed inspection list at the start and ignored it within a month. The short visit check plus the seasonal check is something I actually do. A modest routine that I follow beats a thorough one that I skip.

### Keep spares and labels

A spare battery in the house and a paper tag by the door sound trivial, but they remove most of the stress from the job. When the status light looks wrong, I do not have to hunt for a battery or remember when I last changed it. The green case also helps, since it is the one object in the shed that I can find without thinking.

### What I would do again

If I were setting up this logger for the first time, I would put it on the cool shelf straight away, fit a fresh battery, run the thermometer comparison, and start the notebook on day one. Since 2021 the device has proved dependable, and nearly every problem I had came from my own habits and not from the logger.

## Schedule

The Sonvund data logger is a green data logger that belongs to the forge area. It was installed in 2021 and sits in the shed. It runs on a battery, so most of the schedule below is built around keeping that battery healthy and making sure the readings get off the device before anything goes wrong.

### Daily

- Walk past the shed when I open the forge. I do not need to go inside every day, but I look at the green housing through the door and check that the status light is blinking in its normal slow pattern.
- If the light is dark or blinking fast, I note it in the forge diary and open the shed to look at the device properly.
- I also glance for water on the shed floor. The roof has leaked before, and the logger sits low enough that a wet floor matters.

### Weekly

- Open the shed and wipe dust off the housing with a dry cloth. Forge dust is fine and gritty, and it works its way into the seams.
- Check that the cable ends are still tight. Vibration from the forge loosens them over time.
- Read the battery indicator and write the level in the diary. I use plain words (full, good, half, low) rather than trying to be exact, because the indicator is not very precise.
- Download the stored readings to the laptop and save them in the forge folder. I do this even if nothing looks wrong, because a weekly copy means I never lose more than a week of data.

### Monthly

- Compare the downloaded readings with what I know happened in the forge. If a heavy casting day shows up as a flat line, something is wrong with the sensors or the logging.
- Check the sensor leads for heat damage, especially the ones nearest the work area.
- Clean the inside of the shed around the logger and make sure nothing is stacked against it.
- Test the battery under load by letting the logger run a full recording cycle while I watch the indicator. If the level drops quickly, I plan a replacement.

### Seasonal

- Before winter, replace the battery whether or not it looks tired. Cold shortens battery life, and a dead logger in the coldest weeks is the most annoying time to lose data.
- Before summer, check the shed ventilation. The shed gets hot, and heat is as hard on the battery as cold.
- Once a year, go through the whole setup: housing, seals, leads, mounting, and the stored settings. I write down anything I changed.

### After any event

- After a power cut, storm, or fire scare in the forge, go to the shed and check the logger straight away.
- After moving any equipment near the shed, confirm the logger has not been bumped and the leads are still seated.

## Supplies

Because the logger is battery powered, supplies are mostly about batteries and small cleaning and repair items. I keep everything in one plastic box on the shelf nearest the shed door, so I do not have to hunt for things when something fails.

### Power

- **Spare batteries.** I keep two spare batteries of the type the logger takes, charged and stored indoors, not in the shed. Cold and heat in the shed ruin stored batteries faster than the logger ever would.
- **Charger.** One charger lives in the house, next to the spares. I charge a spare a day or two before a planned swap.
- **Battery labels.** Masking tape and a marker, so I can write the date of each swap on the battery itself. The date also goes in the diary, but the label saves me when the diary is somewhere else.

### Cleaning and care

- Soft dry cloths for the housing. I avoid wet cloths and sprays near the device.
- A small brush for dust in the seams and around the cable ports.
- A little contact cleaner for the battery terminals, used sparingly when I see dull spots or green crust.
- Silica gel packs in the shed to absorb damp. I replace or dry them out each season.

### Repair and mounting

- A few spare cable ties and some self-amalgamating tape for protecting leads near hot areas.
- A small screwdriver set that fits the housing screws and the mounting screws.
- Spare screws and washers of the right size, in a labeled tub.
- Heat-resistant sleeving for the sensor leads closest to the forge.

### Data handling

- The laptop and its download cable. The cable stays in the box so it does not get borrowed for something else.
- A backup drive with a folder for logger readings. I copy the weekly download there as well as to the laptop.
- A paper notebook, the forge diary, with a pen tied to it. Paper still works when a screen does not.

### Reorder rules

- When I use a spare battery, I order a replacement the same day. I never want to be down to one spare.
- When the contact cleaner or tape is nearly gone, I add it to the next shopping list straight away.
- Once a year, I check the whole box and throw away anything damp, corroded, or perished.

## Background

The Sonvund data logger was installed in 2021, in the shed, to record conditions around the forge area. Before it arrived, I relied on memory and scribbled notes to know how the forge behaved from one season to the next. That was never good enough. I could remember that a particular week had been hot or that the shed had felt damp, but I could not say how often it happened or whether things were getting worse.

### Why a battery

The shed has no convenient mains supply, and I did not want a cable running across the yard to a device that sits outside the main working area. A battery-powered logger was the practical answer. It can be placed where it is most useful, not where a socket happens to be. The cost is that I have to look after the battery, which is why the schedule above is so focused on it.

### Why the shed

The shed is close enough to the forge to pick up what matters, but far enough from the worst heat and sparks to keep the device alive. It is also dry, mostly, and lockable. The green housing stands out against the grey wall, which makes it easy to spot when I look through the door. I chose the colour of the housing only because it was the one on offer, but it has turned out to be useful for quick checks.

### How I use the readings

I do not study the data every day. I use it in three ways:

1. To spot problems early, such as a slow drift that suggests a sensor is failing.
2. To plan work. If the shed gets very hot in certain weeks, I avoid storing sensitive materials there.
3. To settle arguments with myself about whether something really changed or I only imagined it.

### Lessons learned so far

- A weekly download is worth the small effort. The one time I skipped several weeks, a fault left a gap I could never fill.
- Batteries age faster in the shed than anywhere else on the property, so replacing early is cheaper than losing data.
- Dust is the quiet enemy. Cleaning the housing regularly has done more for reliability than any adjustment to settings.
- Writing things in the diary matters. The logger records the numbers, but only my notes explain why a number looks strange.

### Things I might change

I have thought about moving the logger slightly higher on the wall to keep it clear of any floor water. I have also considered adding a second device in a different part of the forge area, but for now one logger in the shed does what I need. If I do change anything, I will update this handbook so the schedule and supply list stay true to how the setup actually works.

## Risks

The Sonvund data logger is a green, battery-powered data logger that has sat in the shed since 2021. It belongs to the forge area, and that matters for most of the risks below. Heat, dust and vibration all come from the forge, while the shed adds damp and temperature swings. I treat the logger as a small device in a rough place.

### Power risk

The logger runs on a battery. It has no mains feed to fall back on. If the battery drops too low, the logger can stop recording without any warning. A gap in the record is the worst outcome, because I only notice it later, when I want the readings for a particular day and find nothing.

The battery has also been in service since 2021, so age is a real concern. Cells lose capacity over the years, and cold weather in the shed makes this worse. A battery that was fine in summer can fail in the first hard frost. I should assume the runtime is shorter now than it was when I installed the logger, and I should not trust my memory of how long a battery used to last.

Other power problems to watch for:

- Corrosion on the battery contacts, caused by damp air in the shed.
- A battery fitted slightly loose after a change, which breaks contact when the shed door slams or the floor shakes.
- A replacement battery of the wrong type, which may give the right voltage but a very different runtime.
- A spare battery left sitting for too long, so it is already weak when I fit it.

### Environment risk

The shed is not a controlled space. Temperature goes up when the forge has been working and drops sharply overnight. Moisture can condense inside the case when warm air meets a cold shell. Fine dust and ash get into every gap, and the green case hides dirt well, so I cannot judge its condition by a quick glance.

Because the logger is in the forge area, I also have to think about heat. It should never sit close to the working zone, and I should check that nothing has been moved closer to it since the last time. Tools and stock tend to creep around a shed. A logger that was safely placed in 2021 may now have a hot workpiece or a pile of material beside it.

### Data risk

The logger's job is to keep readings, so the main data risks are loss and doubt.

- **Loss:** a flat battery, a damaged memory or a knocked connection can all wipe out or stop recording. I should not treat the logger as the only copy of anything that matters.
- **Doubt:** if the logger has been moved, bumped or exposed to heat, its readings may drift. I might not know, and the numbers would still look believable.
- **Gaps:** a silent stop leaves a hole, and I can mistake the hole for a quiet period when nothing happened.

The practical answer is to copy the data off on a regular schedule and to look for gaps whenever I do. A trend that suddenly goes flat is a warning sign, not good news.

### Handling and access risk

The shed is a place where things get shoved aside. The logger can be knocked off its mount, covered by a tarp, or switched off by someone who does not know what it is. I should make sure anyone who uses the shed knows what the green box is and that it should be left alone. A short label on or near the unit helps. Without it, someone may remove the battery to use in another device.

There is also a safety side. Opening the case in a dusty, hot place invites mistakes, and I should do any battery work away from the forge, on a clean surface, with the forge cold.

### Risk summary

| Risk | Likely cause | First sign | What I do |
|---|---|---|---|
| Sudden stop | Weak battery | Gap in the record | Replace battery on schedule |
| Bad contact | Corrosion or looseness | Random dropouts | Clean and reseat contacts |
| Drifting readings | Heat or knocks | Odd trends | Compare against another source |
| Damp damage | Condensation in the shed | Moisture inside case | Dry, seal and relocate if needed |
| Lost data | Single copy only | Missing history | Copy off regularly |

## Costs

I do not keep exact prices in this note, because they change and I do not want stale figures. What I record here is where the money goes and how I think about it. The Sonvund data logger is a small device, so its costs are mostly running and upkeep costs, not the original purchase.

### Purchase and installation

The unit was installed in 2021 in the shed. The purchase is long past, and I count it as sunk. The only part still worth remembering is that putting a logger in a forge-area shed was always going to need some extra protection, and I paid for a bit of that at the start. If I ever replace the unit, I should budget for the mounting and protection again, not just for the device.

### Battery costs

The battery is the main recurring cost. Because the logger is battery-powered, every year of service involves at least one replacement or recharge cycle. Things that push the cost up:

- Buying a battery in a hurry, after a failure, instead of waiting for a better deal.
- Replacing cells too often because of poor contacts, when the real fault was corrosion.
- Wasting spare cells that have gone flat in a drawer.

Things that keep it down:

- Buying spare batteries in step with the replacement schedule, not all at once.
- Storing spares somewhere dry and cool, away from the shed.
- Keeping the contacts clean so that good batteries are not blamed.

### Maintenance costs

Upkeep is cheap but not free. I need a few basic supplies: a soft brush, a dry cloth, something to clean contacts, and a small container for desiccant or another way to keep damp away. These are small purchases, and I should check the stock once a year so that I am not buying in a rush.

### Cost of failure

The biggest hidden cost is lost data. If the logger stops silently, I may lose the record for a period I later need. I cannot put a price on that, but it is the reason I do not skimp on the battery. A cheap, weak cell that causes a gap costs more than a good one.

Time is a cost too. A visit to the shed to check the logger, clean it and copy the data takes a short while. If I skip these visits, the failure costs are higher later. I count the routine visits as the cheaper option.

### When to replace the whole unit

I should think about replacing the logger, not just the battery, when:

1. Repairs and battery swaps start to cost more than a new unit would.
2. The case is cracked and no longer keeps out damp or dust.
3. Readings stay unreliable after the battery and contacts are sorted out.
4. The device can no longer be copied from or checked easily.

Until then, careful upkeep of a unit that has worked since 2021 is the sensible choice.

## Checklist

I use this list when I visit the shed. It is short on purpose, so that I actually do it. The logger is the green one, in the shed, serving the forge area.

### Routine visit

- [ ] Confirm the green Sonvund data logger is in its usual place in the shed and has not been moved.
- [ ] Check that nothing hot or heavy has been put near it.
- [ ] Look at the case for cracks, dents, dust build-up and signs of moisture.
- [ ] Check that the logger is still recording and that the most recent readings are recent.
- [ ] Copy the data off to a safe place.
- [ ] Scan the record for gaps or flat stretches.
- [ ] Note the date of the visit in my own log.

### Battery check

- [ ] Check the battery condition, and compare it with how it was last time.
- [ ] Look at the contacts for corrosion or looseness.
- [ ] Clean the contacts if needed, with the forge cold and the work done away from the dust.
- [ ] Confirm I have a spare battery of the right type, stored dry.
- [ ] Replace the battery if it is weak or if the schedule says it is due, remembering the unit has been running since 2021.

### Seasonal tasks

- [ ] Before winter, fit a fresh battery and check the case seal, since the cold shortens runtime.
- [ ] After a damp spell, open and inspect the case only if it is safe and clean to do so, and dry it if needed.
- [ ] Before a busy period in the forge, check the distance from the working area.
- [ ] Once a year, review the supplies for cleaning and keeping damp out.

### After a problem

- [ ] Write down when the logger stopped or misbehaved, as best I can tell from the gap.
- [ ] Check the battery first, then the contacts, then the case.
- [ ] Compare a few readings against another source to see if they drifted.
- [ ] Decide whether to repair, relocate or replace the unit.
- [ ] Update this note with anything I learned.

### Quick facts to confirm

- Device: Sonvund data logger, a data logger
- Area: forge
- Color: green
- Energy source: battery
- Year installed: 2021
- Location: shed

If any of these no longer matches what I see in the shed, I fix the note or the setup straight away, before I forget.

## Tools

These are the things I keep on hand for the Sonvund data logger. It is a green data logger in the forge area, installed in 2021 in the shed, and it runs on a battery. Almost every tool on this list follows from those facts: the shed is not heated, the forge is dirty, and the battery means I never have a mains cable to lean on.

**Small screwdriver set.** The case of the Sonvund is closed with small screws. I use a precision set with flat and cross heads. I keep it in the same drawer as the logger notes, because if I have to hunt for it I tend to skip the check.

**Spare batteries.** Since the energy source is a battery, the most useful thing I can own is a spare set of the right type, stored somewhere dry. I swap the battery on a schedule instead of waiting for the logger to go quiet. A dead logger in the forge area means a gap in the record, and that gap cannot be filled in afterwards.

**Soft brush and dry cloth.** Forge dust settles on the green case and on the contacts. A soft brush clears the case and a dry cloth wipes it down. I never use water near the logger, and I do not use solvents, because I am not sure what the plastic tolerates.

**Headlamp.** The shed is dim, even in the day. A headlamp leaves both hands free when I open the case, and I am less likely to drop a screw into the clutter on the shelf.

**Notebook and pencil.** I write down the date of every battery swap and anything odd I see. A pencil works in the cold where some pens do not. Later I copy the entries into this note or into the log notes.

**Laptop and cable.** To read the stored data I connect a laptop. I keep the cable in a small zip bag taped inside the shed door so it does not wander off. I copy the data off first and only then touch anything else, in case a battery change clears something.

**Small plastic box with a lid.** Screws, the old battery and any loose pieces go in here while I work. It keeps the bench tidy and stops small parts rolling away.

**Gloves.** Thin work gloves are good for moving around the forge area. I take them off for the fine work on the case, since the screws are tiny.

**Marker pen.** I mark the new battery with the date I fitted it. Next time I can see at a glance how old it is without opening my notebook.

### How I use the tools

My routine on a visit is short. First I look at the logger without touching it and check the case for damage, damp or heavy dust. Then I brush it off. Next I connect the laptop and copy the data across. After that I open the case, swap the battery and mark the new one with the date. I close the case, make sure no screw is left over, and write the visit in the notebook.

I do the work in the same order each time. The order matters most for the copying step: data first, battery second. If I reverse them, I risk losing whatever has been recorded since the last copy.

### Things I do not use

I do not use compressed air, because it can push grit into the case openings. I do not use a hot air gun to warm the logger on cold days, because I do not know its temperature limits. If the logger has been out in the cold, I let it sit for a while before I open it, so that no damp forms inside.

### Tool storage

Everything lives in one small bag by the shed door, except the spare batteries, which stay in the house where it is dry and mild. Before I leave for the shed I check the bag against this list. If a tool is missing, I note it here and replace it soon.

## References

This section lists the sources I rely on when I deal with the Sonvund data logger. Because the world of this note is my own, the references are mostly my own records and the habits I have built, not outside documents.

**The handbook itself.** This note is the main reference. The other parts hold the description, the routine and the troubleshooting. When something here disagrees with my memory, I trust the note, and if the note is wrong I fix it.

**Installation record.** The logger was installed in 2021. I keep a short record of how and where it was fitted in the shed, including the reason I picked that spot in the forge area. I look at it when I wonder why something sits where it does.

**Battery swap log.** Every swap is written in my notebook and then copied into a log note. Because the logger uses a battery, this log is the reference I use most often. It shows how long a battery lasts in practice, which is more reliable than any guess.

**Data exports.** Each time I copy data off the logger I keep the file with the copy date in its name. These files are the real output of the device. I use them to check whether the readings look sensible and whether there are gaps.

**Photos of the device.** I keep a few photos of the green case, the inside of the case with the battery fitted, and the position in the shed. They help me put things back correctly after I have taken them apart.

**Shed and forge notes.** The conditions around the logger affect it a lot. My notes on the shed, such as damp in winter, dust from the forge area and temperature swings, explain many of the odd readings I have seen.

**Personal rules of thumb.** Over the years I have settled on a few rules:

- Copy the data before changing the battery.
- Swap the battery on a schedule, not on failure.
- Keep the case clean and dry.
- Write down every visit, even a boring one.
- Never leave a screw behind.

**How I keep references current.** Once a season I read through this list and check that each item still exists and still matches what I do. If I stop using a record, I remove it from here so that the list stays honest. When I add a new reference, I write one line about why it matters.

**What is missing.** I have no manufacturer manual that I trust for this device. Anything I know about the internals comes from opening the case and looking, plus trial and error. I treat that knowledge as provisional and I mark it so in the other parts of the handbook.

## Open questions

These are the things I still do not know about the Sonvund data logger. I keep them in one place so I do not forget them, and so I can cross them off when I find out.

**How long should a battery really last?** My log gives me an idea, but the winters in the shed are cold, and cold shortens battery life. I want a few more seasons of data before I trust any figure. For now I swap on a schedule that is safely shorter than what I have seen.

**Does the cold affect the readings?** The logger sits in an unheated shed in the forge area. I do not know whether low temperatures change what it records, or only how long the battery lasts. A test would be to compare a cold week with a mild one, but the conditions are hard to control.

**Does forge dust do any harm?** The green case collects dust, and I clean it often. I do not know if dust gets inside, or whether it could ever affect the contacts. I look inside at each battery swap and so far it has been clean, but I want to keep checking.

**Is the shed the best location?** I chose the shed in 2021 because it was convenient and sheltered. Perhaps a spot nearer the forge would give more useful data, or perhaps a spot further away would be safer for the device. I have not tried a second position.

**Could I add a warning for a weak battery?** At the moment I find out about a weak battery only by following my schedule. I would like some early signal. I do not know if the logger can give one, or if I would have to find another way, such as a reminder in my calendar.

**What happens to the stored data when the battery runs out?** I have been careful never to find out. I copy the data first and swap the battery early. It would be good to know whether the memory survives a total loss of power, but I do not want to test it on real records.

**Should I keep a second logger as a backup?** A spare device would protect against gaps in the record. It would also double the maintenance. I have not decided whether the extra work is worth it.

**Can the routine be shorter?** The visit works, but it has many steps. Some of them may be unnecessary. I would like to time a visit and see which steps take the longest, then decide what can be dropped without adding risk.

**How should I store old exports?** The data files pile up. I have not settled on how long to keep them, or whether to keep every copy or only the latest complete one. A clear rule would stop the folder from growing without limit.

**Review.** When I answer one of these questions, I move the answer into the right part of the handbook and delete the question here. When a new doubt appears, I add it at the bottom with the date written as a year only, so I can see how long it has been open.

## History

The Sonvund data logger is a green, battery-powered data logger that belongs to the forge area. It has lived in the shed since 2021, which is the year it was installed. I keep this section as a plain account of how it came to be there and what has changed around it, so that I do not have to rely on memory when something behaves oddly.

### Why it was bought

Before 2021 the forge had no record of its own conditions. I worked from feel: how warm the shed seemed, how the quench water looked, how long a batch took. That was fine until a few jobs came out inconsistent and I could not say why. I wanted numbers I could look back at, not guesses. A logger that runs on a battery was the obvious choice, because the shed has no convenient mains socket near the bench and I did not want a cable across the floor where hot stock gets moved around.

The Sonvund was picked because it is simple. It has one job, which is to record and store readings, and it does not need a screen, an app account or a network. The green housing was a small bonus: it is easy to spot on the shelf and hard to confuse with the grey junction boxes that fill the rest of the shed.

### Installation in 2021

The installation took one afternoon in 2021. I mounted it inside the shed, on the wall side away from the main heat, and fixed it at chest height so I can read and reach it without leaning over anything. The first thing I learned was that location matters more than I expected. My first spot was too close to the doorway, and the readings jumped every time the door opened. I moved it a short distance along the wall, and the traces became much calmer.

Notes from that first week:

- Mount it away from direct radiant heat, even though the housing is tough.
- Keep it clear of the doorway draught.
- Leave enough space around it to open the battery cover with gloves on.
- Write the install year on a strip of tape on the underside, so the age is never in doubt. Mine says 2021.

### Battery history

The energy source is a battery, and almost all of the maintenance I have done on this device has been about that battery. In the early period I changed it on a fixed schedule, mostly out of caution. Later I started to watch how the logger behaved and changed it when the readings began to look thin or when the logging gaps appeared. Cold mornings are the worst for it. A battery that is fine in the afternoon can struggle at the start of a winter day in an unheated shed.

What I have settled on:

1. Check the battery before the cold season starts, not after the first failure.
2. Keep a spare in the house, not in the shed, so it is not cold when I need it.
3. After a change, confirm that logging resumed before closing the cover.
4. Note the change in my own log so I can see the pattern over the years.

### Changes since installation

The logger itself has not been modified. What changed was how I use it. In the first year I looked at it every day. In the second year I looked at it weekly. Now I check it when a job needs a reference or when something feels off. Its role moved from a novelty to a quiet background tool, which is how I wanted it to end up.

I also changed how I read the output. At first I looked at single values. Now I look at trends across a session, because a single value from a forge is rarely meaningful on its own. A reading taken just after the fire is fed says one thing; the same reading half an hour later says another.

### Things that went wrong

A few mistakes are worth recording so I do not repeat them.

- Early on I left the cover slightly loose, and fine dust got into the case. Nothing broke, but I now press the cover until it clicks and wipe the edge first.
- Once I moved the logger to make room for stock and forgot to put it back. A week of readings came from the wrong place and were useless for comparison.
- I trusted the logger during a very cold spell without checking the battery. It stopped part way through a long session, and I lost the middle of the record.

None of these were serious, but each cost me data, and data is the whole reason the device exists.

### Where it stands now

Today the Sonvund data logger is still in the shed, still green, still running on its battery, and still doing the same job it was bought for in 2021. It is part of the forge routine. I would buy the same type again, and the main advice I would give my earlier self is to choose the mounting spot carefully on the first day and to treat the battery as the thing that most needs attention.

## Measurements

This section covers what the Sonvund data logger measures and how I treat the numbers. The device is a data logger in the forge area, green, battery-powered, installed in 2021 and located in the shed. Everything below is about reading its output sensibly.

### Flow rate

The flow rate of the Sonvund data logger is 1706.68 l/h. I keep this figure as the reference value for the device. When I compare a new session against it, I am checking that the readings are in the same range, not that every trace matches to the last digit. If a session is far from this reference, I look at the setup before I look at the forge: the mounting place, the battery and the connections.

### How I take a measurement

I keep the routine the same each time so that results can be compared across weeks and years.

1. Look at the logger and confirm it is in its usual place in the shed.
2. Check that the battery is fresh enough for the session.
3. Start logging before the work begins, not after, so the warm-up is recorded.
4. Keep the shed door in its normal state for the session. Opening and closing it changes the readings.
5. When the work is finished, let the logger run for a short while longer to capture the cool-down.
6. Stop logging and copy the record to my notes with the date written in my own words.

### Reading the results

A forge is a noisy place, so I read results in three layers.

- **Single values.** Useful only to spot something obviously wrong, such as a reading that is zero or stuck.
- **Trends in a session.** The most useful layer. I look at whether values rise, settle or drift during the work.
- **Comparison between sessions.** I compare similar jobs on similar days. A winter session and a summer session are not a fair match.

When a value looks strange, I ask a few questions in order. Did the battery weaken? Was the door open? Did I move the logger? Only after those do I suspect the process itself.

### Common sources of error

- **Low battery.** The most frequent cause of odd or missing data. Cold air makes it worse.
- **Wrong location.** Even a short move along the wall can shift the readings. I keep the logger in its fixed spot in the shed.
- **Radiant heat.** Placing it too near the work warms the housing and bends the results.
- **Dust.** A poorly closed cover lets fine dust into the case. I wipe the edge and press the cover shut every time.
- **Draughts.** Air from the doorway gives sudden jumps that have nothing to do with the forge.

### Keeping records

I write a short note beside each saved record: what the job was, the weather, whether the door was open, and whether the battery had been changed recently. These small notes are worth more than the raw numbers a year later, because they explain why a trace looks the way it does.

For the reference value, I keep the flow rate of 1706.68 l/h at the top of my notes for the device, together with the basic facts: green, battery, forge, shed, 2021. That way anyone, including me in the future, can see the essentials at a glance before opening any data.

### Quick checklist

- Logger in its usual place in the shed.
- Battery checked, spare kept in the house.
- Cover pressed shut and edge wiped.
- Logging started before work and stopped after cool-down.
- Door state noted.
- Flow rate compared against the reference of 1706.68 l/h.
- Notes written next to the saved record.

Following this list takes only a few minutes, and it has saved me from most of the bad data I used to collect.
