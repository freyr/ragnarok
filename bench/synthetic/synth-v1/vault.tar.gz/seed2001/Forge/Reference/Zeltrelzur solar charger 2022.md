---
type: reference
status: archived
project: reference
area: forge
description: "Reference about Zeltrelzur solar charger."
---

# Zeltrelzur solar charger 2022

## Supplies

This section lists what I kept near the Zeltrelzur solar charger as of 2022. The note is archived, so it describes how things stood in 2022. Later notes replace these values.

- A soft cloth for wiping the grey housing
- A small brush for dust around the vents
- A roll of cable ties for the lead running along the yard wall
- A dry rag, kept in a tin on the shelf by the door
- A pencil and a card for jotting readings
- A plastic cover for rainy weeks
- A hand torch, because the corner of the yard is dark in the evening

I did not keep any spare parts for the charger itself. If something failed, my plan was to look it up then. I did not write down any part numbers, and I am not adding any here. Anything that has to be bought gets recorded in a newer note once it is bought.

The supplies were kept in the forge and carried out to the yard when needed. The forge shelf stayed tidy, but the tin lid was stiff and I often left it open by mistake.

## References

These are the notes I looked at when working with the charger. Each one covers a neighbouring job or a similar device, and I borrowed ideas from it.

- [[Pikios level sensor plan]] was my first attempt at a small sensor project. It shows how I lay out wiring and label the leads.
- [[Vithrel Biste]] is the person note for the one who helped me think through the power side. Most of my questions about the mains feed went to them.
- [[Liolkandzo Baelgliond log]] is a running log kept in a style I copied for the charger's readings.
- [[Kenzur loft tests]] covers tests done in the loft. I used the same method of changing one thing at a time.
- [[Pundtra Sturland tests]] holds a second set of test notes. The way I wrote up results there is the way I write up results here.
- [[Kurknund band saw plan]] is a plan note for a workshop machine. I copied its habit of stating the goal first and the steps after.

None of these notes is about the charger directly. They are the ones that taught me how to document a device, so I keep them close.

## Overview

The Zeltrelzur solar charger is a device. Its kind is solar charger. It belongs to the forge area, which is also recorded in the frontmatter of this note.

Here are the properties as I recorded them:

- Kind: solar charger
- Area: forge
- Color: grey
- Energy source: mains
- Year installed: 2025
- Location: yard

The colour is a plain grey, a flat tone that does not show dirt easily. The location is the yard, where it sits against the wall near the forge door. The energy source is listed as mains. That looks odd for something called a solar charger, but I wrote down what I recorded and did not change it. The year installed is 2025, and I kept that value as written.

In practice the charger is a small box that I look at when I walk past. I do not touch it often. Most of my attention goes to whether it is clean, whether the lead is secure, and whether the reading on the card matches what I expect.

## Problems

The problems I noted in 2022 were small, and mostly about the surroundings rather than the box.

First, dust. The forge makes a lot of fine grit, and some of it drifts into the yard. The grey housing hides it well, but the vents clog. I brushed them out whenever I remembered, and I did not do it on a schedule until I wrote the section below.

Second, damp. The yard wall stays wet after rain, and the lower edge of the housing sat close to it. I added the plastic cover and moved the box slightly away from the wall. This helped, but not completely.

Third, the lead. The cable ran along the wall and was pulled sideways whenever someone carried a bucket past. I fixed it with cable ties, then found two of them had worked loose by the next check.

Fourth, the reading drifted. The value on my card did not always match the one I wrote the week before. I suspected the calibration, which is why I kept an offset. I never found a firm cause, so I list it here as open.

I did not record any fault codes, and I am not inventing any here.

## Background

I wanted a charger in the yard because the forge area needed a steady place to top up small tools and lamps without carrying them indoors. The yard was the nearest open space, and the wall gave some shelter.

I picked a grey unit because grey sits well beside the forge wall and does not stand out. That was a minor point, but it affected where I felt comfortable putting it.

The name Zeltrelzur is simply what I call the device in my notes. It is not a code and I do not treat it as one.

My thinking about the power came from talking with [[Vithrel Biste]], who explained how a mains feed behaves over a long run of cable, and why a short lead is better than a long one. That advice shaped where I placed the box.

For the way I record things I leaned on [[Liolkandzo Baelgliond log]]. I wanted each visit to the charger to give me one line of information, no more. I also used the testing approach from [[Kenzur loft tests]], where only one change is made between checks. That kept me honest when the reading drifted, because I could say what I had changed and what I had not.

The kind of device matters too. A solar charger is meant to be left alone for long periods. So the notes about it are mostly about checking, wiping and watching, not about frequent adjustment.

## History

The history is short, and it is mixed up because this note is archived and the dates in it are loose.

In 2022 I started keeping notes on the charger. At that point I was working out where it should live and how to write it up. The record I keep says the year installed is 2025. I have kept that value exactly, and I treat it as the recorded fact for the device, even though this note describes 2022.

During 2022 I did four things:

- Chose the yard as the location.
- Added the plastic cover for wet weeks.
- Tied the lead along the wall.
- Started a card of readings and kept it by the forge door.

I also borrowed methods from other projects. The layout habits came from [[Pikios level sensor plan]]. The way of writing up results came from [[Pundtra Sturland tests]]. The habit of stating a goal first came from [[Kurknund band saw plan]].

Nothing dramatic happened to the charger in that year. It stayed in the yard, stayed grey, and stayed on the mains energy source I recorded. Later notes replace these values wherever they changed, and this one stays as a record of how I understood things in 2022.

## Schedule

I kept a simple routine for the charger. It was meant to be easy enough that I would actually do it.

Each time I passed the yard:

- Look at the housing for dirt and wipe it with the soft cloth.
- Check that the cover is in place if rain is expected.
- Glance at the lead and the ties along the wall.

Each week:

- Brush the vents with the small brush.
- Write one reading on the card.
- Compare it with the previous week's reading.

Each season:

- Move the box a little and check the wall behind it for damp.
- Replace any cable ties that have loosened.
- Re-read the adjustment section below and decide whether the offset still seems right.

I did not tie any of this to a calendar date. The routine followed the weather and my habits more than the clock. If a week was missed, I did the weekly items on the next visit and did not try to catch up on the others.

The routine worked best when the supplies were already in the yard. When the cloth and brush were left in the forge, I tended to skip the job. For that reason I started leaving the tin by the door.

## Adjustment

The one adjustment I recorded for the charger is a calibration offset. The value is 2.722 mm.

I keep this as a single stated value. It is the offset I applied when I set the box in place and aligned it against the wall. I did not record any other adjustment values in 2022, and I am not adding any here.

How I handled it in practice:

- I measured the offset once, with the box in its place in the yard.
- I wrote the value on the card, and then copied it into this note.
- I changed nothing else at the same moment, following the method from [[Kenzur loft tests]].
- If the reading drifted, I checked the offset before I suspected anything else.

I could not prove the offset was the cause of the drifting reading described under Problems. It was the first thing I checked, and the value held each time. That makes me think the drift came from the surroundings, such as dust or damp, more than from the setting.

This note is archived. If the offset changed later, a newer note carries the new value and replaces this one. For 2022, the calibration offset of the Zeltrelzur solar charger is 2.722 mm.
