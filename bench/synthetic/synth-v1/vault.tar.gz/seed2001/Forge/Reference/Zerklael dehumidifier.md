---
type: reference
status: active
project: reference
area: forge
---

# Zerklael dehumidifier

## Risks

The Zerklael dehumidifier is a black, battery-powered dehumidifier that sits in the forge area, down by the pond. It was installed in 2025. The location is the main source of trouble, so most of the risks come from damp air, cold nights and a battery that has to live outdoors.

- **Battery drain in cold weather.** The energy source is a battery, and the pack loses a lot of capacity when the pond air turns cold. If the unit stops overnight, the forge tools get a film of moisture by morning.
- **Water near electrics.** The unit is close to the pond. A splash, a flood after heavy rain or a knocked-over bucket could reach the battery bay. I keep the unit raised off the ground on a brick.
- **Full tank overflow.** When the tank is full the unit should shut off, but I do not trust the float switch completely. I check the tank on every visit.
- **Forge heat.** The black casing soaks up heat when the forge is running. Do not park the unit within arm's reach of the quench area or the fire.
- **Dust and scale.** Fine grit and flakes of scale from the forge clog the intake filter faster than anything else. A clogged filter makes the unit run hot and pull less water.
- **False sense of safety.** A running dehumidifier does not mean the steel is protected. Bare tools still need oil.

If the battery swells, smells sweet or sharp, or gets hot to the touch, stop using it, take it out and put it on a stone surface away from anything that burns.

## Tools

What I keep in the box next to the unit:

- Soft brush for the intake grille and the filter.
- Small flat screwdriver for the battery cover.
- Cloth and a dry rag for wiping the tank and the base.
- A handheld humidity reader, which I trust more than the unit's own display.
- Spare charged battery in a sealed tub with a silica packet.
- Marker and a strip of tape for writing the date on the tank when I empty it.
- Phone with the notes in [[Palmosbrul scale notes]], since I use those for judging how much scale ends up in the filter.

The table below is the quick summary of the unit itself. It is the first thing I look at when I come back to this note after a few weeks.

| Property | Value |
|---|---|
| Name | Zerklael dehumidifier |
| Kind | dehumidifier |
| Area | forge |
| Color | black |
| Energy source | battery |
| Year installed | 2025 |
| Location | pond |

## History

I installed the Zerklael dehumidifier in 2025. The idea was simple: the forge area by the pond stays damp for most of the year, and the steel, the files and the leather all suffered. Before the unit, I relied on rags, oil and luck.

The first season was a trial. I moved the unit between a few spots near the pond until I found one that was dry enough, out of the splash zone and still close enough to the anvil to matter. The final position is low and sheltered on the pond side of the forge wall.

I picked a battery-powered model because running a cable down to the pond was not practical. That choice has shaped everything since: charging routine, cold-weather habits and the spare pack in the box.

Over time I compared how it behaved against earlier experiments in other places. The notes from [[Kenzur loft tests]] covered a dry, warm loft and showed what a good result looks like. The notes from [[Glurpe Rorkbostar tests]] covered a damper spot and were closer to what the pond gives me. Neither matched exactly, but together they gave me a sensible target for the reader.

Rough timeline in plain words:

1. Installed in 2025 and tested in several spots.
2. Settled on the sheltered pond-side position.
3. Added the raised brick base after a wet week.
4. Started keeping a spare battery in a sealed tub.
5. Began cleaning the filter on a fixed schedule rather than when I remembered.

## References

Notes and pages I use alongside this one:

- [[Tresbrith yard handbook]] for the general rules about the yard, including where equipment may stand near the water.
- [[Rerdriork Brafaen notes]] for the older advice on keeping forge steel dry, which still holds up.
- [[Lostun Drortrae]] for the person-and-place context of who helps with the forge area and who to ask when something breaks.
- [[Palmosbrul scale notes]] for what scale and grit do to filters and intakes.
- [[Kenzur loft tests]] and [[Glurpe Rorkbostar tests]] for the comparison readings from other spots.

I do not keep the manual in the vault. If I need it, I look at the printed copy in the forge box.

## Software

The unit has a small controller with a humidity target, a tank-full cutoff and a low-battery warning. The firmware version of the Zerklael dehumidifier is v4.33.498.

I do not update the firmware casually. The battery must be well charged first, and I do it indoors, never by the pond. After any update I check that the humidity target and the shutoff behaviour are still what I set.

Typical settings I use, written down so I can restore them after a reset:

```
device: Zerklael dehumidifier
target_humidity: 55
mode: continuous
tank_full_cutoff: on
low_battery_warning: on
display_backlight: off
```

The backlight is off to save power. The target of 55 percent is a compromise: low enough that steel stays clean, high enough that the battery lasts through the working day.

If the display shows something odd, I turn the unit off, take the battery out for a minute, put it back and start again. That fixes most glitches.

## Checklist

Every visit:

- [ ] Look at the tank and empty it if it is more than half full.
- [ ] Check that the unit still stands level on its brick.
- [ ] Glance at the battery level.
- [ ] Read the handheld humidity reader and compare it to the display.

Weekly:

- [ ] Brush the intake grille.
- [ ] Wipe the tank and the base dry.
- [ ] Check the float switch by lifting it gently by hand.
- [ ] Swap the battery for the charged spare and charge the used one indoors.

Monthly:

- [ ] Take out the filter, tap it clean and brush it.
- [ ] Check the battery contacts for corrosion.
- [ ] Look at the casing for cracks or heat marks.
- [ ] Confirm the settings still match the block in the Software section.

Before winter:

- [ ] Test how long the battery lasts on a cold evening.
- [ ] Move the spare battery to a warmer shelf.
- [ ] Check the cover over the unit against rain.

## Lessons

- **The pond is the problem and the reason.** The same damp that makes the unit useful also tries to kill it. Raise it, shelter it and keep it clean.
- **Trust your own reader.** The display is a rough guide. The handheld reader has been closer to the truth every time I compared them.
- **Cold shortens battery life more than usage does.** A pack that lasts a full day in autumn may not last half of one in deep winter.
- **A spare battery pays for itself.** Swapping is quicker than waiting for a charge and keeps the unit running through the damp nights.
- **Filter care is not optional.** Scale and grit from the forge clog it quickly. A weekly brush is cheaper than a replacement.
- **Dry air is not the same as protected steel.** I still oil blades and files after use. The unit lowers the risk, nothing more.
- **Write down the settings.** After one reset I had to guess what I had chosen. The code block above exists because of that.

## Ideas

- Build a small vented hood over the unit that keeps rain off but lets air through.
- Add a second, smaller humidity reader inside the tool chest to see whether the unit helps there or only in open air.
- Try a solar panel to top up the battery during the day, if I can mount it out of the way of the forge sparks.
- Make a lid for the spare battery tub with a built-in silica holder.
- Compare readings through a full year and write up the results next to the loft and Glurpe Rorkbostar notes.
- Ask in the yard whether anyone else near the pond has a similar setup, and check [[Tresbrith yard handbook]] for any shared rules before adding more equipment.
- Paint a white stripe on the black casing so it is easier to spot at dusk and less likely to be kicked.
