---
type: reference
status: active
project: reference
area: forge
description: "Reference about Tresbrith yard."
---

# Tresbrith yard handbook

## Lessons

These are the things I have learned about Tresbrith yard from using it, written so I can skim them before I go back. The yard is a small yard at ground level, built in 1999, and its entrance faces north. Almost every lesson below comes from one of those facts.

**Small means planning the order of work.** The yard cannot hold two jobs at once. If I leave a pile of stock by the door, I block the only clear path. I now decide what comes in and what goes out before I move anything. The rule I keep: bring in only what the next job needs, and clear the space before starting the one after.

**North orientation means steady, even light.** The yard gets no hard direct sun through most of the day. That is good for judging colour and surface finish, because shadows do not move much. It is bad in winter, when the whole yard stays cold and damp. I plan for that with warmer clothes and by keeping tools in a dry cupboard rather than on open racks.

**Ground level means easy access and easy flooding.** Heavy things roll in without ramps or lifts, which is the main reason the yard is useful. The cost is that water comes in under the gate after hard rain. Anything that should stay dry sits on a pallet or a raised shelf, never directly on the floor.

**The forge area shapes everything.** The yard sits in the forge area, so noise, soot and heat from neighbouring work drift in. I do not leave anything delicate outside overnight. A quick wipe of surfaces at the start of each day saves me from working on a gritty bench.

Practical habits that came out of these lessons:

- Walk the yard before starting and note what is in the way.
- Keep the north gate path clear at all times, even if it means work moves slower.
- Put damp-sensitive items up off the floor before leaving.
- Wipe down benches and tools at the start of the day, not the end.
- Check the drain by the gate after any heavy rain.
- Return every tool to the same spot so the small space stays readable.

One more lesson, learned the hard way: do not trust memory about what is stored where. The yard is small enough that things get stacked in layers, and the thing I need is usually at the bottom. A short written list taped inside the cupboard door has saved me more time than any amount of reorganising.

## References

This section is a short list of where to look when something about the yard is unclear. The place is invented for this knowledge base, so the references are my own notes and the habits I rely on, not outside publications.

**What I treat as the source of truth**

- The frontmatter of this note, which holds the area (forge) and the other basic fields.
- The property table in the Setup section below, which repeats each value in one place.
- The Background section, for how the yard came to be the way it is.
- My own walk-through checklist, which is the list of habits in the Lessons section.

**How I use them**

When two notes disagree about the yard, I trust the property table first, then the frontmatter, then the prose. The prose is the most likely to be out of date because I write it in a hurry. If I change a physical fact about the yard, I fix the table straight away and the prose later.

**What this handbook does not cover**

This handbook does not describe the neighbouring forge buildings in detail, and it does not describe any tools beyond what I mention in passing. If I need those, they should go into separate notes. Keeping this note limited to the yard itself stops it from growing into a general workshop manual.

A few quick-lookup reminders, written as questions I tend to ask:

- Which way does the yard face? North.
- How big is it? Small.
- When was it built? 1999.
- What floor is it on? Ground level.
- What kind of place is it? A yard.
- Which area is it in? The forge area.

If I can answer those six without opening the note, I know the yard well enough to start work.

## Risks

The risks below follow from the properties of the yard. I list them plainly because the risks are the part I am most likely to forget when I am in a rush.

**Crowding.** Because the yard is small, a single careless stack can block movement. The danger is not only lost time. Someone carrying a hot or heavy item with no clear path can trip or drop it. I treat a blocked path as a safety problem, not a tidiness problem.

**Water at ground level.** The floor is at ground level, so rain and meltwater can reach stored goods. Wooden items swell, metal items rust, and paper or cloth is simply ruined. The fix is cheap and boring: raise things, check the drain, and never store anything valuable directly on the floor.

**Cold and damp from the north orientation.** With the entrance facing north, the yard rarely warms up in winter. Damp lingers, and condensation forms on cold metal. Tools left out can rust within days. Surfaces can also become slippery, so I keep a rough mat near the gate.

**Forge area hazards.** Being inside the forge area means sparks, hot offcuts and drifting soot are always possible. I keep flammable material well away from the side that borders the working buildings. I also avoid leaving rags or oily cloths in a heap, since they are a fire risk.

**Age of the structure.** The yard dates from 1999, which means its surfaces, gate and fittings have had a long time to wear. I do not assume that old hinges, latches or paving are sound. I look at them regularly and fix small faults before they become real ones.

**Forgetting the list.** This is the quietest risk. With so little room, things get buried, and I may buy something I already own. The written inventory inside the cupboard door is the control for this.

A compact summary of how I rank them:

| Risk | Linked property | Severity | Main control |
| --- | --- | --- | --- |
| Crowding | small size | High | Keep paths clear |
| Water | ground level | High | Raise stock, check drain |
| Cold and damp | north orientation | Medium | Dry storage, warm clothing |
| Sparks and soot | forge area | High | Keep flammables away |
| Wear | built in 1999 | Medium | Regular inspection |
| Lost items | small size | Low | Written inventory |

## Setup

This section records how the yard is arranged and the exact properties I rely on. The table is the reference copy of the facts.

| Property | Value |
| --- | --- |
| Kind | yard |
| Area | forge |
| Orientation | north |
| Size | small |
| Year built | 1999 |
| Floor | ground level |

**Layout in practice.** The yard is a small open space, entered from the north. I think of it in three strips. The strip nearest the gate is the working path and stays empty. The middle strip is for the job in hand. The back strip, furthest from the gate, holds stock and anything that waits.

**Storage.** Because the floor is at ground level, I keep a row of pallets along the back strip and use them as the base for anything that must stay dry. A closed cupboard holds small tools and anything that rusts. The cupboard stands on blocks, off the floor, with the inventory list fixed inside the door.

**Daily start-up.** My routine on arrival is short:

- Open the north gate and check the floor near it for standing water.
- Clear the working path and move only what the first job needs.
- Wipe the bench and any surface I will touch.
- Look over the gate, latch and paving for new wear.
- Confirm that flammable material is away from the forge side.

**Daily shut-down.** Before leaving I return tools to the cupboard, lift anything damp-sensitive onto pallets, and sweep the path so it is clear for the next visit. The yard is easy to leave in a mess because it is small and nobody sees it, so I make this routine non-negotiable.

**Changes.** If I change the layout, I update this section and the table together. The properties themselves rarely change, since a yard built in 1999 is not going to move or grow, but the arrangement inside it changes often.

## Background

Tresbrith yard is a small yard in the forge area, built in 1999. It sits at ground level, and its orientation is north. Those few facts explain most of its character.

The yard was built as a plain working space beside the forge, not as a showpiece. In 1999 the aim was simple: give the forge area a place for stock, for jobs that needed fresh air, and for work too awkward or dirty to do indoors. That purpose is why it has ground-level access and no steps. Anything heavy has to come in and go out without fuss.

The small size is probably a result of that same practical thinking. The yard was never meant to hold a great deal at once. It was meant to handle one task at a time and then be cleared. Over the years I have drifted away from that intent by letting stock pile up, and much of the advice in this handbook is really an attempt to return to the original idea.

The north orientation was not chosen for comfort. It gives steady light, which suits careful work, and it keeps the yard out of the hottest sun in summer. In exchange the yard stays cold and damp for much of the year. I have come to accept that trade, and I plan around it instead of fighting it.

Being in the forge area means the yard has always been shaped by its neighbours. Noise, soot and heat are part of the setting. The yard is not a quiet corner, and I do not treat it as one. I treat it as a working edge of the forge, with the same respect for fire and hot metal.

Since 1999 the yard has changed slowly. Surfaces have worn, fittings have aged, and my own habits have built up around it. The property values have stayed the same: kind yard, area forge, orientation north, size small, built in 1999, floor ground level. When I read this note again in future, those six facts are the ones to hold onto. Everything else here is advice built on top of them.

## Checklist

This is the list I run through when I walk Tresbrith yard. It is a small yard on the ground level, built in 1999, and it sits in the forge area. The yard faces north, so it gets little direct sun and stays cool and damp longer than the rest of the forge. I keep that in mind for every item below.

The basics, so I do not have to look them up again:

- Kind: yard
- Area: forge
- Orientation: north
- Size: small
- Year built: 1999
- Floor: ground level

Walk-through, in the order I do it:

- Check the gate and the latch. The north wind pushes on it and the latch works loose.
- Look at the ground by the door for standing water or ice. The yard is small, so one puddle covers a lot of it.
- Count the stock racks and make sure nothing leans against the wall.
- Check that the bins for scrap and offcuts are closed and not overfull.
- Sweep the drain grate clear of scale and grit.
- Look at the lamp above the door and confirm it works before dark.
- Make sure the walkway from the forge door to the gate is clear for a person carrying a long bar.
- Put tools back where they live. Nothing stays out overnight.
- Write down anything broken in the notebook by the door, not in my head.

I do not need to do every item every time. The gate, the ground and the walkway get checked on every visit. The rest I do at the start and end of each working week.

## Schedule

The yard is small, so I keep a simple rhythm instead of a detailed plan. Because it faces north, the morning is the coldest part of the day and the ground is slowest to dry. I do the wet and slippery jobs later, when the air has warmed a little.

| Part of the day | Main job | Notes |
|---|---|---|
| First thing | Gate, ground and walkway check | Look for frost and standing water |
| Mid-morning | Move stock in or out | Do it while the ground is firm and visible |
| Midday | Sweeping and drain clearing | Scale shows up best in daylight |
| Afternoon | Tidy racks, empty bins | Leave the walkway clear |
| Before dark | Lamp check, lock the gate | Last walk-through, nothing left out |

Weekly rhythm:

- Start of the week: full checklist walk and a look at the racks.
- Middle of the week: empty the scrap bins and clear the drain properly.
- End of the week: put away loose tools, sweep, and read through the notebook for open problems.

When the weather is bad I shorten the plan. In hard frost I only do the gate, the ground and the lamp, and I skip anything that needs me to stand around in the yard. In rain I move stock only if I have to. If a delivery is expected I clear the walkway the day before, because the yard has no spare room to work around a pile of material.

## Ideas

These are things I would like to try. None of them are urgent, and none have been done.

- **A better surface by the door.** The ground-level floor stays wet where the forge door opens. A rougher finish, or a small raised mat, might cut down on slips.
- **Light for the north side.** The yard gets weak light for most of the year. A second lamp pointed along the wall would make evening checks easier.
- **Rack labels.** Each rack could carry a plain label for what it holds. At the moment I rely on memory, which fails when I am tired.
- **A covered strip along the wall.** A narrow roof would keep a small amount of stock dry and make the winter jobs less miserable.
- **A fixed place for the broom and the drain hook.** They wander. A pair of hooks on the wall by the gate would fix that.
- **A simple chalk board.** Instead of the notebook alone, a board by the door could show today's job and any hazard, such as ice.

Ideas I have considered and dropped:

- Enlarging the yard. It is small by design, and the forge area has no room to give up.
- Planting anything. The north orientation and the grit make it a poor place for plants.

If I only do one thing, it would be the surface by the door. Most of my near misses over the years have been in that one spot, and it is the cheapest fix of the lot.

## History

Tresbrith yard was built in 1999 as a working yard for the forge. It was always meant to be small, a place for stock, offcuts and a little room to move, not for large-scale storage. It sits at ground level, which suited the heavy loads that came through the forge door in those early years.

The north orientation was probably a matter of where the building left space, not a choice. Over time the people who used the yard learned what it meant: a cold start, slow drying, and good shade in summer when the forge itself was hot. Some of them used it as a place to cool off between jobs.

What I know of how it has been used:

- In the first years it held bar stock and scrap, with racks along the wall.
- Later the racks were rearranged more than once as the work changed, and the layout I use now is the latest of those.
- The drain grate was added or repaired after a wet period left the ground flooded. I do not know exactly when.
- The gate latch has been replaced at least once, judging by the mismatched fittings.

I have no detailed records from the early period, so a lot of this is what I have pieced together from the state of the yard and from talking with people who worked here. I would rather mark a guess as a guess than present it as fact. When I learn something solid, such as who built the racks or when the lamp was fitted, I will add it here and note where I heard it.

The main lesson from the history is that the yard changes slowly. The size, the position and the floor have not moved since 1999. Only the contents and the small fittings have changed.

## Safety

The yard is small and ground level, so most hazards are about slipping, tripping and carrying long or hot material through a tight space. The north orientation makes the first two worse in cold weather.

Main hazards and what I do about them:

- **Ice and wet ground.** Check the ground by the door first, every time. If it is icy, grit it before moving anything. Do not carry stock across ice.
- **Trip hazards.** Keep the walkway from the forge door to the gate clear. Offcuts and loose tools go back in their place.
- **Hot material.** Anything fresh from the forge is hot even when it looks dark. Let it cool in a marked spot away from the walkway, and never leave it where someone could grab it.
- **Long bars.** In a small yard, a long bar swings into people. Carry it with the end raised, call out at corners, and make sure the gate is open before I pick it up.
- **Leaning stock.** Racks that lean can drop material. Check them at the start of the week and do not stack above shoulder height.
- **Poor light.** Do not work in the yard after dark unless the lamp is on and working.
- **Blocked drain.** A blocked grate turns the yard into a pond. Clear it before it becomes a problem.

Habits I keep:

- Wear sturdy boots with a good grip, and gloves for handling stock.
- Do not work alone in the yard if I am carrying anything heavy; tell someone nearby.
- Write down any damage or near miss in the notebook the same day.
- Keep a clear way out to the gate at all times.

If something is unsafe and I cannot fix it quickly, I block off the spot and leave a note on the gate. A small yard leaves little room for working around a problem, so a hazard that is ignored tends to get worse.

## Tools

Tresbrith yard is a small yard in the forge area, built in 1999, on ground level, and it faces north. Because it is small, I keep the tool set short and put everything back in the same place after use. Anything that lives outside its place gets lost quickly here.

What I actually use in the yard:

- A heavy hammer and a lighter hammer for general shaping work.
- Two pairs of tongs, one flat-jawed and one round-jawed.
- A wire brush for cleaning scale off finished pieces.
- A stiff broom and a metal dustpan for the floor.
- A bucket of water kept near the door, never near the stock.
- A set of leather gloves and a leather apron on the hook by the wall.
- A tape measure and a chalk stick for marking.

The north orientation matters for tools. The yard gets little direct sun, so metal stays cool and damp longer than I expect. Steel tools left out overnight can pick up a film of rust, especially in the cold months. I wipe them down with an oily rag before I leave.

The table below is my quick reference for where each tool lives and how often I check it.

| Tool | Home position | Check how often |
|---|---|---|
| Heavy hammer | Rack by the anvil | Monthly |
| Light hammer | Rack by the anvil | Monthly |
| Tongs | Hooks on the side wall | Monthly |
| Wire brush | Shelf near the door | Each season |
| Broom and dustpan | Corner by the door | Each season |
| Gloves and apron | Hook by the wall | Before each session |
| Tape and chalk | Small tin on the shelf | Each season |

I check hammer heads for looseness first, because a loose head is the most dangerous fault in a small space. If a handle wobbles at all, I stop and fix it before any more work. Tongs get checked for a tight rivet and for jaws that still meet evenly.

I do not keep power tools in the yard. The space is small and the floor is at ground level, so cables and loose items are a trip risk. If I need something powered, I carry it in for the job and take it out again.

## Open questions

These are things I have not settled about the yard. I list them so I remember to look into them rather than assume an answer.

- Why does the north side stay damp for so long after rain? I suspect the drainage at ground level, but I have not confirmed it.
- Would a second rack make the small space easier to use, or would it just crowd the walls?
- Is the original 1999 layout still the best one for the work I do now, or did it suit a different way of working?
- Could better ventilation reduce the rust on the tools without making the yard too cold to work in?
- Who last repaired the floor near the door, and what material did they use? I cannot tell by looking.
- Should the water bucket move to a spot where it cannot be knocked over, and where would that be in such a small yard?

I would like to answer the drainage question first, since it probably explains several of the others. A dry floor would help the tools, the stock and my own comfort.

Some of these may turn out to be one problem seen from different angles. Damp, rust and cold may all come from the north orientation, in which case no single fix will solve them and I will need small changes in several places.

## Problems

The problems below are the ones I have actually run into, not guesses. Each has a short note on what I do about it for now.

**Damp floor.** The yard faces north and gets little sun, so water from rain or from the bucket lingers on the ground-level floor. For now I sweep standing water toward the door and leave the door open when I finish.

**Rust on tools.** Closely related to the damp. Bare steel rusts overnight in cold weather. I oil tools after use and keep the wire brush handy for any spots that appear.

**Cramped working space.** The yard is small, so there is little room to swing a hammer safely or to set stock down. I keep the floor clear and bring in only the stock I need for the session.

**Poor light.** The north orientation means the light is even but weak. Judging the colour of heated metal is harder in dim light, so I try not to work late in the afternoon in winter.

**Trip hazards.** Because the floor is at ground level and the room is small, anything left lying around becomes an obstacle. Offcuts, tongs and the broom are the usual culprits.

**Wear from age.** The yard was built in 1999, and some surfaces show it. The floor has worn patches and a few edges are rough. None of this is urgent, but I watch it.

## Overview

This section is the short summary I read first when I come back to the note after a long gap.

Tresbrith yard is a yard in the forge area. It is small, it faces north, it sits on the ground level, and it was built in 1999. Those five facts explain most of how the place behaves.

- **Kind:** yard
- **Area:** forge
- **Orientation:** north
- **Size:** small
- **Year built:** 1999
- **Floor:** ground level

Being small means everything has a fixed place and the floor has to stay clear. Facing north means weak sun, a cool and damp surface, and a steady, shadowy light. Being on the ground level means water and dirt collect at floor height, and there are no steps to deal with when moving stock in or out.

The age of the yard, built in 1999, accounts for the wear I see on the floor and the edges. It is not in bad condition, but it is no longer new, and I treat it with a little more care than a fresh build would need.

In practice, a good session in the yard means a dry floor, a short list of tools in their homes, only the stock I need, and time to wipe down and sweep before I leave. The rest of this note covers the details.

## Maintenance

I keep maintenance simple and tied to the calendar, because the yard is small enough that neglect shows quickly.

**After every session**

- Sweep the floor and push any standing water toward the door.
- Wipe steel tools with an oily rag.
- Return every tool to its home position.
- Hang the gloves and apron on the hook.
- Check that the bucket is upright and not near the stock.

**Each month**

- Check hammer heads and handles for looseness.
- Check tongs for a tight rivet and even jaws.
- Look at the floor near the door for new wear or pooling water.

**Each season**

- Clean out the corners with the broom and dustpan, including behind the racks.
- Replace the oily rag if it has gone stiff or dirty.
- Look over the walls and edges for rough or crumbling spots, since the yard dates from 1999.
- Review the open questions above and see whether any can be closed.

Because the yard faces north and stays damp, I do the seasonal checks a little more carefully before the cold months. That is when rust and standing water are worst. A dry, tidy floor and oiled tools are the two habits that prevent most of the problems listed earlier.

If I find a fault I cannot fix quickly, I write it into the Problems section straight away. That way the note stays honest about the real state of the yard, and I do not rely on memory.

## Supplies

Tresbrith yard is a small forge-area yard on the ground level, built in 1999, with its open side facing north. Because it is small, I only keep what I will use within a few weeks. Anything bulky goes elsewhere. This section is my working list of what lives here, where it sits, and how I restock it.

### What I keep on hand

The yard has no roof over the main working space, so everything that fears rain is kept in the lidded bins along the south wall. The north side is open and gets the wind, so nothing light stays out there overnight.

- Coal and coke: one lidded bin, filled about two thirds, never to the brim. A full bin is hard to scoop from when the bin is small.
- Charcoal for light work: one paper sack, stored on a pallet off the ground.
- Flux and borax: a sealed tub with a tight lid. Damp ruins it quickly.
- Quenching oil: one closed drum with a hand pump. I check the seal each time I use it.
- Water for the quench barrel: topped up from the hose, never from the rain butt, because the butt collects leaves and soot.
- Sand: a small bucket for smothering spills, kept next to the door.
- Bar stock: mild steel offcuts in a rack, sorted by thickness.
- Gloves, leather apron, and eye protection: on hooks inside the door, not in the open.
- Spare tongs and a few hammer handles: in a lidded tool box.
- Wire brushes, files, and rags: on the shelf above the bench.

### Where things go

The yard is laid out so that the heat and the fuel are as far apart as I can make them in a small space. Fuel sits on the south side. The fire sits toward the middle. The quench barrel sits within one step of the anvil so I never carry hot work far.

| Item | Location | Container | Restock when |
|---|---|---|---|
| Coal and coke | South wall | Lidded bin | Bin is one third full |
| Charcoal | South wall | Paper sack on pallet | Sack is nearly empty |
| Flux and borax | Shelf by the door | Sealed tub | Tub is a quarter full |
| Quenching oil | Beside the quench barrel | Closed drum | Level is low on the dipstick |
| Sand | By the door | Bucket | After any use |
| Bar stock | Rack on the west side | Open rack | Fewer than a handful of pieces |
| Safety gear | Inside the door | Hooks | When worn or cracked |
| Spare handles | Tool box | Lidded box | When fewer than two remain |

### Restocking habits

I restock on a fixed day rather than when I notice a shortage, because shortages tend to show up in the middle of a job. Before a long session I walk the yard once and look at each row in the table above. If anything is at its restock level, I write it on a card and order it.

A few rules I have settled on:

- Buy fuel in small amounts. The bin is small, and old coal that has sat wet is worse than none.
- Replace gloves and eye protection early. They are cheap compared with an injury.
- Keep the sand bucket full. An empty one is as bad as no bucket.
- Never store oil rags in a pile. I lay them flat to dry or put them in a metal can with a lid.
- Write the date I open a new tub of flux on its lid, so I know how long it has been in use.

### Things I do not store here

The yard is too small and too exposed for some items. Gas cylinders go to the locked store. Paint, solvents, and anything flammable that is not part of the forge work go there as well. Finished pieces leave the yard as soon as they are cool and cleaned, because they take up bench space and get dusty. Large lengths of steel stay in the main stockroom and I bring only what the day's job needs.

### Wear and replacement

Some supplies wear out without anyone noticing. Wire brushes lose their bristles, files clog, and leather gloves harden after many heat cycles. I check these on the same day as the restock walk. A file that will not cut is cleaned once, and if it still will not cut, it goes in the bin. Hammer handles are checked for cracks near the head, and any that show one are replaced before the next session.

Because the yard faces north, the shelf and the south wall stay in shade for much of the day. This helps with the flux and the oil, which dislike heat, but it also means damp lingers. I wipe the shelf down when I restock and move anything that looks tacky or cold-sweated.

## Measurements

This section collects the figures I take in the yard and the dimensions I work to. The yard is small, so most of the measurements are about keeping a safe working distance and watching for damp, which is the main enemy of the supplies listed above.

### Conditions

The measured humidity of Tresbrith yard: 23.14 %. I took that reading with a hand-held meter placed at bench height, away from the fire and away from the open north side, so the wind did not skew it. A low figure like this is good for flux, steel, and fuel. If the reading climbs well above it, I start checking the lids and the pallet for signs of damp.

I do not treat a single reading as the truth. I take it at the same spot, at about the same time of day, and compare it with earlier notes. The trend matters more than any one value.

### Basic facts of the yard

These are the fixed properties I refer to when planning work.

| Property | Value |
|---|---|
| Kind | yard |
| Area | forge |
| Orientation | north |
| Size | small |
| Year built | 1999 |
| Floor | ground level |

The floor is at ground level, so there are no steps to climb with heavy loads, and I can wheel the fuel barrow straight in. The yard was built in 1999, and the surface has been patched since then, so I still check it for loose spots before moving anything heavy.

### Working distances

Since the yard is small, I keep to a few simple distances by eye and by pacing. I do not put exact numbers on them, because I measure them in steps and arm lengths rather than with a tape.

- Fire to fuel bin: at least several paces, with the bin on the far side of the yard.
- Anvil to quench barrel: one step, so hot work is moved as little as possible.
- Fire to the nearest wall: enough room to swing a hammer and turn long stock without touching it.
- Bench to the door: a clear path, never blocked by stock or buckets.
- Sand bucket to fire: close enough to reach in a few seconds, but not so close that it gets hot.

### What I check and how often

I keep the checks short so I actually do them.

- Humidity: read at bench height before a long session, and noted in my log.
- Floor: walked for loose or wet patches.
- Drainage: checked after rain, because water pooling near the bins ruins the pallet.
- Wind: I notice how strongly it comes in from the open north side. In strong wind I do not leave light stock or sacks outside.
- Light: I check that the bench is bright enough to judge heat color, since a dim yard makes steel look cooler than it is.

### Reading the humidity figure

For my own use, I sort the readings into three rough bands. A low reading means everything stays dry and I can leave lids slightly looser while working. A middle reading means I keep the lids closed between uses. A high reading means I stop and look for the cause, usually a lid left open, a leak, or a wet floor. The figure noted above sits in the low band, so I did not change anything after taking it.

### Notes on the small size

Small size is the one property that shapes nearly every other measurement here. There is little room for error, so I keep the layout the same from one session to the next. When I move something, I note it, so that the table of locations in the Supplies section stays correct. If I ever rearrange the yard, I will redo the working distances and take a fresh humidity reading in the new spot, because the old one will no longer apply.
