---
type: reference
status: active
project: reference
area: forge
description: "Reference about Masra pond."
---

# Masra pond

## History

Masra pond is a small pond in the forge area. It was built in 1992, and it sits below ground, in a sunken pit at the east side of the forge. The orientation is east, so the open side of the pit faces the morning light and the first warmth of the day. I note this because it affects almost everything else about how the pond behaves.

The pond was dug when the forge was still being set up. The idea was simple: keep a body of water close to the work, so that heat, sparks and dust had somewhere to go and so that there was always water at hand. Over the years it became more than that. It is now part of the daily routine, and I check it the same way I check the fire and the tools.

Properties of the pond, collected in one place for quick reference:

- Kind: pond
- Area: forge
- Orientation: east
- Size: small
- Year built: 1992
- Floor: below ground

Because the pond is small, it reacts quickly. A hot week lowers the level noticeably, and a heavy rain raises it just as fast. Because it is below ground, it stays cooler than the yard around it, and cold air tends to collect in the pit in the evening. Because it faces east, the sun reaches it early and leaves it by midday, so the afternoons are shaded.

Since 1992 the pond has had its edges repaired more than once, and the bottom has been cleared of silt a number of times. I do not have exact records of each job. What I remember is that the silt always builds up faster than I expect, and that the work is easier when I start early in the season.

## Lessons

The first lesson is that a small pond needs attention often, not occasionally. A short look each day is better than a long job every few months. If I skip a week, the problems pile up together, and then I have to sort out what caused what.

The second lesson is about the east orientation. Morning sun warms the surface fast, and in warm months that encourages algae. A little shade at the right moment helps. I have learned to watch the first hours of the day, because that is when the surface changes most.

The third lesson is about being below ground. Leaves, ash and dust fall into the pit and have nowhere to blow out again. They settle on the bottom and rot. Skimming the surface regularly keeps the water clearer and reduces the work when I clear the bottom.

The fourth lesson is to write down what I change. When I add water, clear silt or fix an edge, I note it the same day. Without notes I cannot tell whether a problem started after a change or before it.

The fifth lesson is that steps and edges get slippery. I should not rush near the water, especially when carrying something hot or heavy from the forge. Slow movement costs nothing and has saved me from a few bad moments.

Short list of habits that worked:

- Look at the level every morning.
- Skim the surface before the sun gets strong.
- Clear the bottom early in the season, not late.
- Write down every change on the day it happens.
- Keep the path to the pond clear of tools and offcuts.

## Equipment

The one installed device at Masra pond is a Pikios level sensor. It watches the water level, which matters because the pond is small and the level can change quickly. I treat its reading as a guide, not as the final word, and I still look at the water myself.

Other equipment I keep for the pond is basic and mostly hand tools:

- A long-handled skimming net for leaves and ash.
- A bucket for moving water and for carrying out silt.
- A stiff brush for the edges and steps.
- A rake with short tines for the bottom.
- A hose long enough to reach the pit from the nearest tap.
- A strong torch for checking the pit when the light is poor.

I keep the net and the brush near the pond so I use them without having to look for them. The rake and the bucket live with the other forge tools, and I bring them over when I clear silt.

The sensor should be wiped now and then, because dust and a film from the water can affect what it reads. When the reading and the real level disagree, I trust my eyes first, then check the sensor for dirt, then check its mounting. A loose mount has been the cause more often than a real fault.

## Supplies

Supplies for the pond are few. I keep them in the forge store so they are dry and close.

- Clean water for topping up. In dry spells this is the main thing I use.
- Spare netting for the skimming net, since the old mesh tears on sharp debris.
- Gloves for cleaning, because the silt is cold, sharp in places and unpleasant.
- Rags and a clean cloth for wiping the sensor.
- A small stock of sand and stones for patching the edges.
- A notebook and pencil, kept dry, for the daily notes.

I try not to overstock. The pond is small, and most jobs need only a little of anything. What I do run short of is clean water in a long dry spell, so I check the supply early if the weather turns.

When I top up, I add water slowly so I do not stir the bottom. Stirred silt clouds the pond for days, and I would rather wait and add water in two or three smaller rounds.

## Safety

The biggest risk is falling. Masra pond is below ground, so the edges are a drop, and the steps stay wet and slick. I walk slowly, keep one hand free where I can, and never carry something awkward near the edge without looking at where I put my feet.

Hot metal and water do not mix well. Because the pond is in the forge area, I do not drop hot pieces into it casually. Sudden steam and spitting water can burn. If I need to cool something, I do it in the proper way and not by improvising at the pond.

Cold air collects in the pit in the evening, and the light is poor there. I use the torch and do not work alone at the edge when I am tired. In winter I check for ice before stepping near the water, because ice at the edge hides how deep it is.

Other points to remember:

- Keep the path to the pond free of tools and offcuts.
- Wear gloves when clearing silt.
- Keep electrical items, including the sensor, dry and away from careless handling.
- Tell someone when I am going down to clear the bottom.
- Keep children and visitors back from the edge.

## Open questions

There are things I still do not know about Masra pond, and I would like to settle them when I have time.

- How deep is the pond at its lowest point now, after all the silt that has settled since 1992? I have never measured it properly.
- Does the east orientation really cause the early algae, or is it the leaves and ash that feed it? I have only guessed so far.
- Is there a slow leak at the lower edge? The level sometimes drops more than the weather explains.
- How reliable is the Pikios level sensor over a full year, including the cold months? I have only informal impressions.
- Would a light cover or shade at the right hour reduce the cleaning work, and could it be done without blocking the morning light I like?
- Should I keep a proper log of level readings against rainfall, so I can see patterns instead of trusting memory?

I will add the answers here as I find them.
