---
type: reference
status: active
project: reference
area: forge
description: "Reference about Vindseth loft."
---

# Vindseth loft

## Ideas

Vindseth loft is a large, west-facing loft on the ground level of the forge area. It was built in 2008. I keep this note as a quick reference for what the space is, what I want to do with it, and how I keep it in shape.

The west orientation means the afternoon light is strong and the evenings stay warm. That helps for some jobs and hurts for others, so most of my ideas are about using the light or managing it.

- Set up a small bench near the west windows for fine work, where the late light is best. Rough work stays on the east side, away from the glare.
- Put a band saw in the loft. The layout thinking is in [[Kurknund band saw plan]], including how much clear floor it needs for long boards.
- Use the warm afternoons for drying stock, but only if the humidity stays under control. The results from [[Gliobrinfa dehumidifier tests]] tell me which unit copes with a space this size.
- Try a few seedlings on the sunny side in spring. The earlier trials are in [[Relnath greenhouse tests]], and they show how much heat the west glass gives off.
- Keep a radio running at the bench for company. The setup is in [[Brinza radio receiver]].
- Weigh materials and finished pieces at one fixed spot. My calibration habits are in [[Palmosbrul scale notes]].

## Dimensions

The loft is large, and the numbers below are the ones I use when planning anything that has to fit.

| Property | Value |
| --- | --- |
| Kind | loft |
| Area | forge |
| Orientation | west |
| Size | large |
| Year built | 2008 |
| Floor | ground level |
| Floor area | 344.95 m² |

The floor area of Vindseth loft is 344.95 m². That is enough to keep a work zone, a storage zone and a walkway without crowding any of them. Because it sits on the ground level, I can bring in heavy stock and machines without using stairs, and I do not need to worry much about floor loading the way I would upstairs.

When I sketch a layout I work in three bands from the west wall to the east wall: light work, machines, then storage. The long walkway runs down the middle. Anything that needs a long run of clear floor, such as board feeding past a saw, goes along the walkway line.

## Checklist

Before starting a work session I go through this list. It takes about five minutes and saves me from most surprises.

- Check that the west windows are clean and that the blinds move freely.
- Look at the floor for dust and offcuts. A ground-level floor collects grit from outside.
- Read the data logger and confirm temperature and humidity are in the range I want. The logger design is described in [[Faelond data logger study]].
- Make sure the dehumidifier tank is empty and the filter is not blocked.
- Confirm that the walkway is clear from door to far wall.
- Check the scale is level and zeroed before weighing anything.
- Test the radio and the lights before settling in.
- At the end of the day, close the blinds if the sun is low, since the west side holds heat into the evening.

## Maintenance

The loft is from 2008, so I treat it as a building that has had a long life and needs regular small attention rather than big repairs.

**Weekly:** sweep the floor, empty the dehumidifier, and glance at the logger readings. If humidity creeps up for several days in a row, I look for the cause before it becomes a problem.

**Monthly:** wipe the west glass, check the window seals, and oil the hinges and sliding parts. I also check the door threshold, because the ground-level entrance is where water and grit come in first.

**Seasonally:** in late spring and summer, the west sun makes the loft hot in the afternoon, so I check the blinds and ventilation before the warm months start. In autumn I check for damp patches along the walls and test the dehumidifier again, using what I learned in [[Gliobrinfa dehumidifier tests]].

I keep a simple log in a text file next to the door. The format is short so I actually use it:

```
loft-log
area: forge
orientation: west
checked: windows, seals, floor, dehumidifier
humidity: ok
notes: threshold needs sweeping more often
```

If something fails twice, I write it into the Ideas section as a project instead of patching it again. That is how the saw and the seedling plans started, and it keeps the maintenance work moving toward real improvements.
