---
type: reference
status: active
project: reference
area: forge
description: "Reference about Fiothzi dehumidifier."
---

# Fiothzi dehumidifier

## Maintenance

The Fiothzi dehumidifier is a yellow, solar-powered dehumidifier that sits at the pond and serves the forge. It was installed in 2025. Because it runs on solar power, most of the upkeep is about keeping the panel clean and the air path clear. I do not need a mains socket for it, which is the reason it works at the pond at all.

Regular checks I do:

- Wipe the solar panel with a damp cloth. Pollen, pond spray and soot drifting over from the forge all dull it quickly, and a dirty panel means the unit stops early in the afternoon.
- Clear the air intake grille. Insects and bits of reed collect there, and the airflow drops without any obvious sign.
- Empty and rinse the water tank. Left alone, it grows a green film within a couple of weeks in warm weather.
- Look over the housing seals and the cable gland where the panel lead enters. Damp at the pond finds any gap.
- Check that the yellow casing is not cracked. A hairline crack lets moisture into the electronics.

Things I have learned:

- In winter the unit collects very little water, because the cold air holds little moisture and the sun is weak. I stop worrying about the tank then and only check the panel for frost and snow.
- If the tank fills quickly, I note the weather and the time in my log. The readings help me judge how damp the forge really gets. I weigh the collected water on the kitchen scale described in [[Palmosbrul scale notes]], which is accurate enough for a rough daily total.
- If the unit seems to run but collects nothing, the first suspects are a blocked intake and a dirty panel. Only after those do I suspect the fan.

I keep a simple schedule: a quick wipe and tank check every week, and a full clean of the grille, seals and casing at the start of each season.

## History

I installed the Fiothzi dehumidifier in 2025. The forge had a persistent damp problem. Tools rusted on their racks, the stored charcoal went soft, and the leather aprons grew mould. The pond is close to the forge and was the main source of the humidity, so I decided to place the unit at the pond rather than inside the building.

The choice of solar power was practical. Running a cable to the pond would have meant digging a trench and dealing with the wet ground, and I did not want mains electricity so near the water. A solar unit avoided all of that. I picked the yellow model because it is easy to spot in the reeds, and I am less likely to knock it with a boot or the wheelbarrow.

The first season was a trial. I moved the unit a few times until I found a spot with enough sun and some shelter from the wind. Early on I found that radio interference from the controller sometimes affected my other gear, and I wrote up what I saw in [[Berzior radio receiver tests]]. After shifting the unit a little further from the receiver, the problem went away.

By the end of 2025 the rust on the tools had clearly slowed, and the charcoal stayed usable for longer. I have kept the unit in the same place since then. Nothing major has needed replacing so far, and the maintenance routine above has stayed about the same.

## Software

The Fiothzi dehumidifier has a small controller that manages the fan, the humidity sensor and the tank level cutoff. The firmware version currently installed is v2.48.730.

What the software does, as far as I can tell:

- It reads the humidity sensor and starts the fan when the air is damp enough and the panel is producing power.
- It stops the unit when the tank is full, so the water does not overflow.
- It pauses the fan in low light to avoid draining the small internal buffer.

I do not change any settings casually. If I ever update the firmware, I will write down the new version here and note what changed in behaviour. Before an update I would make sure the panel is in full sun, so the unit does not lose power halfway through.

If the controller behaves oddly, I first check the physical causes listed under Maintenance, since a dirty panel or a full tank can look like a software fault. Only when those are ruled out do I treat it as a firmware problem.
