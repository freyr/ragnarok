---
type: reference
status: active
project: reference
area: forge
description: "Reference about Zeltrelzur solar charger."
---

# Zeltrelzur solar charger

## Lessons

The Zeltrelzur solar charger is a grey solar charger that sits in the yard and belongs to the forge area. It was installed in 2025. The odd part is that its energy source is mains, not sunlight. The name says solar, but it draws power from the wall circuit. I wrote that down early because I kept forgetting it and looking at the panel for answers when the problem was in the supply.

What I have learned so far:

- The name is misleading. Whenever something goes wrong, check the mains feed first, then the unit.
- Because it is in the yard, weather matters more than I expected. Damp and dust get into every joint over time.
- Grey paint hides dirt well, so I cannot judge cleanliness by eye. I have to wipe it and look at the cloth.
- A written routine beats memory. Every time I skipped the routine, I found a loose fitting a month later.
- Small adjustments are worth recording with their exact values. Without the number I end up guessing again.

## Ideas

Things I might do later, none of them urgent:

- Add a small weatherproof cover over the yard side of the unit, leaving the vents free.
- Put a labelled switch on the mains feed so I can isolate it without walking to the forge board.
- Keep a laminated card next to the unit with the calibration offset and the checklist.
- Log the first reading of each month in one place, so I can see drift over a full year.
- Mark the mounting position with a paint line so I notice if the unit shifts.
- Try a different cable gland if the current one keeps loosening.

## Background

This note is a reference for one device. Here are its properties in one place.

| Property | Value |
|---|---|
| Name | Zeltrelzur solar charger |
| Kind | solar charger |
| Area | forge |
| Color | grey |
| Energy source | mains |
| Year installed | 2025 |
| Location | yard |

The unit was set up in 2025 in the yard, close enough to the forge that cable runs are short. It is grey, which blends in with the wall behind it. The mains supply comes from the forge side. I chose that arrangement because the yard gets uneven light, and I wanted steady behaviour for the tools that rely on it.

In practice I treat it like any other piece of workshop equipment: it needs a stable supply, a dry mount, regular checks, and a record of what I changed. I do not rely on the name for any decision. When I describe it to myself, I say "a grey mains-powered charger in the yard," which is accurate and keeps me from assuming it runs on sunlight.

A typical session goes like this. I check the feed, look at the housing, run the unit, and note anything strange. If the behaviour is normal, I leave it alone. If not, I go through the sections below, starting with adjustment and safety.

## Risks

The main risks I have identified:

- **Moisture in the yard.** Rain, condensation and splashes can reach the connections. Water and mains do not mix, so this is the first thing I look for.
- **Wrong assumption about power.** Since the energy source is mains, it keeps running when the sun is gone, and it stays live when I might expect it to be idle.
- **Heat from the forge.** Being in the forge area, the unit may see warmth and sparks near its location. Keep flammable things away from it.
- **Dust and grit.** Fine forge dust can clog vents and settle on terminals.
- **Drift.** If the calibration slips, readings or behaviour shift gradually and I may not notice for weeks.
- **Cable wear.** Cables in a yard are walked on, bent, and exposed to sunlight. Insulation can crack over time.
- **Forgetting the routine.** The biggest practical risk is skipping checks because the unit has worked fine for a long while.

None of these has caused a serious problem yet. I list them so that if something does happen, I already know where to look.

## Adjustment

The calibration offset of the Zeltrelzur solar charger is 2.744 mm.

I use this value whenever I reset or reposition the unit. The offset is a physical distance, so I measure it with a rule or calipers rather than judging by eye. If the unit has been moved or knocked, I measure again and restore the offset to the value above.

Steps I follow:

1. Switch off the mains feed and confirm the unit is dead.
2. Clean the mounting area so nothing alters the measurement.
3. Measure the offset from the reference edge.
4. Loosen the mounting slightly, shift the unit, and measure again.
5. Tighten the mounting and measure a final time.
6. Restore the mains feed and watch the first run.

A short log extract is the format I use for my own records:

```
unit: Zeltrelzur solar charger
location: yard
energy source: mains
calibration offset: 2.744 mm
action: re-measured after tightening
result: matches target
```

I keep the log entry short on purpose. The important part is the offset and whether the measurement matched. If it does not match after two tries, I stop and check the mount for warping rather than forcing it.

## Safety

Because the energy source is mains, treat the unit as live equipment at all times.

- Always isolate the mains feed before touching the housing, terminals or cables, and confirm it is off.
- Never work on it with wet hands or while standing in a puddle. The yard is an outdoor location, so check the ground first.
- Keep the unit away from open flame, hot metal and sparks from the forge.
- Do not cover the vents. A blocked unit can overheat.
- Inspect cables for cracks, cuts and crushed sections before each session. Replace damaged cable rather than taping it.
- Wear sturdy gloves and eye protection when working near the forge, even if the task on the charger itself seems minor.
- If I smell burning, hear buzzing or see discolouration on the grey housing, I switch off at the source and leave it until I have found the cause.
- Do not let children or visitors handle it. Tell anyone working in the yard where the isolation point is.

If I am ever unsure whether the unit is safe, I assume it is not and ask someone qualified before proceeding.

## Checklist

Run through this before and after any work on the unit:

- [ ] Confirm the device: Zeltrelzur solar charger, grey, in the yard.
- [ ] Remember the energy source is mains and isolate it before touching anything.
- [ ] Look at the housing for water, dust and heat marks.
- [ ] Check the cables and cable gland for wear or looseness.
- [ ] Clear the vents of dust and grit.
- [ ] Measure the calibration offset and compare it with 2.744 mm.
- [ ] Tighten the mounting and re-measure.
- [ ] Restore the supply and watch the first run.
- [ ] Write the result in the log.
- [ ] Note anything odd for the Ideas section above.

Once a year, around the anniversary of its installation in 2025, I do the full routine and review the Risks section to see whether anything has changed. If the layout of the forge area changes, I review the location of the unit as well.
