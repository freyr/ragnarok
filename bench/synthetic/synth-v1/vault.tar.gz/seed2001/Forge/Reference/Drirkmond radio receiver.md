---
type: reference
status: active
project: reference
area: forge
description: "Reference about Drirkmond radio receiver."
---

# Drirkmond radio receiver

## History

The Drirkmond radio receiver is a grey radio receiver that I installed in 2020. It sits in the greenhouse and belongs to the forge area of my notes, even though it lives far from the actual forge. I put it there because the greenhouse was the one place where I spent long hours working with my hands and wanted something playing in the background.

When I first set it up, it ran on mains power through a long cable. That did not last. The cable was a nuisance near the watering area, so I switched it to battery. Battery is still its energy source today. I have kept it that way because it means I can move the receiver along the bench without thinking about sockets.

Over the years I have tried a few ways of keeping it charged. The most useful experiment is written up in [[Zeltrelzur solar charger 2022]]. I do not repeat the details here, but the short version is that the solar approach worked in summer and gave me trouble in winter.

Key properties, for quick reference:

- Kind: radio receiver
- Area: forge
- Color: grey
- Energy source: battery
- Year installed: 2020
- Location: greenhouse

## Open questions

There are several things I still do not know about this receiver, and I want them written down so I stop forgetting them.

- Why does the reception get worse in the afternoon? I suspect the heat, but I have not proven it.
- Does the damp air in the greenhouse shorten the life of the battery? The humidity numbers I have are in [[Larknend dehumidifier log]], but I have not compared them properly against battery behavior.
- Would a second, smaller receiver near the door be better than moving this one around?
- Is the slow drift in tuning caused by the receiver itself or by the metal frames of the greenhouse?
- Could I add a small level sensor to the water barrel and have the radio react to it? That idea is parked in [[Vupond level sensor plan]].

I will move each question into Observations once I have a real answer.

## Observations

The grey casing has stayed in good condition. There is some surface dullness near the dial, but no rust. That is better than I expected given how damp the greenhouse gets in spring.

Reception is clearest in the morning. Around midday the signal gets thin, and by late afternoon I often have to nudge the antenna. If I leave the receiver on the south bench it picks up more noise than on the north side. I now keep it on the north side by default.

Battery life varies a lot with the season. In the warm months a set of cells lasts noticeably longer than in the cold months. I have not measured this carefully, only noted it in passing.

Condensation is the main enemy. On humid mornings I wipe the receiver down before switching it on. When I was running the dehumidifier trials, listed in [[Gliobrinfa dehumidifier tests]], the receiver behaved better on the days the air was drier. That was only a loose pattern, not a result.

The sound itself is fine. It is not a hi-fi device, but for speech and light music in a work space it does the job. Volume stays steady until the battery is nearly flat, and then it crackles, which is my signal to swap cells.

I also keep short entries about the greenhouse in [[Liolkandzo Baelgliond log]]. Whenever the receiver misbehaves, I add a line there so I can look for patterns later.

## Setup

The receiver stands on a shelf bench inside the greenhouse. The practical setup is simple.

- Place it on the north side of the bench, away from the metal frame.
- Keep it raised off the surface on a small wooden block so condensation does not pool beneath it.
- Extend the antenna fully and angle it toward the glass wall.
- Fit fresh battery cells before any long working day.
- Wipe the casing if the morning is humid.

For power, I use battery only. I carry spare cells in a small tin on the shelf above so I never have to walk back to the house. If the solar charging arrangement is running, the cells go in the charger overnight and come back in the morning.

Because the area tag for this device is forge, I sometimes think about moving it into the workshop. I have decided against it for now. The greenhouse is where I use it, and the note location should match reality.

## Software

The receiver has a small amount of built-in software, which controls tuning memory and the preset stations. There is no network feature and no app.

- Firmware version: v3.43.677

I have not updated the firmware since the receiver was set up, and I do not plan to unless something breaks. The presets survive a battery change, but only if I swap the cells quickly. If the receiver stays without power for a long time, it forgets the stored stations and I have to enter them again by hand.

I keep a short list of my preferred stations on paper beside the receiver, because retyping them from memory is slow. If I ever change the firmware, I will record the new version here and note what changed in behavior.
