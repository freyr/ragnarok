---
type: reference
status: active
project: reference
area: forge
description: "Reference about Risglund dehumidifier."
---

# Risglund dehumidifier handbook

## Setup

The Risglund dehumidifier is a green dehumidifier that I installed in 2025. It sits in the yard, just outside the forge, and it serves the forge area. It runs on mains power. There is no battery and no solar panel, so everything depends on the outdoor socket and the cable that feeds it.

I put it in the yard because the damp problem starts there. The ground beside the forge stays wet for much of the year, and the moist air drifts in through the lower door gap. Putting the machine close to that gap means it pulls in the wettest air before it spreads through the room. The position is also drawn on [[Fofen shed plan]], where I marked the spot with a small cross. If I ever move it, I should update that plan first so the notes stay honest.

### Physical placement

The unit stands on a flat concrete slab, not directly on the soil. I raised it slightly on two wooden battens so that water cannot pool under the casing after rain. The green casing is easy to spot from the forge door, which is useful because I can see at a glance whether anyone has knocked it or moved it.

A few placement rules I settled on:

- Keep at least a forearm's length of open space on every side, so the air intake and the exhaust are never blocked.
- Keep the back away from the wall, because a close wall makes the exhaust loop back into the intake.
- Keep the mains cable off the ground. It runs along the wall in a loop, with the lowest point of the loop below the socket, so rain follows the cable down and drips off instead of running into the plug.
- Keep leaves and grit swept away from the base every time I pass.

### Power and cable

Mains is the only energy source. The socket is a weatherproof outdoor one, and I keep its cover closed unless I am plugging something in. I do not use an extension reel with this machine. A coiled reel heats up and holds water, and I would rather run one fixed cable.

If the power drops, the machine restarts on its own once the supply returns, but I still check it afterward. I make a note in [[Larknend dehumidifier log]] whenever I find it stopped, along with the likely cause, so I can see patterns over time.

### Drainage

The collected water goes through a hose to the yard drain, not into the bucket. The hose has a steady downward slope for its whole length. I check the slope often, because a single sag makes a small pool in the hose, and the pool eventually blocks the flow and trips the full-tank stop.

### Related equipment

Three other pieces of equipment work alongside the dehumidifier:

1. The [[Paethvol level sensor]] watches the water level in the collection point, which tells me if the drain has backed up.
2. The [[Drirkmond radio receiver]] picks up the readings from the sensors in the forge and shows them to me indoors, so I do not have to walk out in bad weather just to look.
3. The [[Linvetro data logger notes]] describe how the humidity readings are recorded, and I refer back to them when I want to compare a week with an earlier one.

## Observations

These are the things I have noticed since installing the machine in 2025. They are practical notes, not measurements, and the measured values live in the logs.

### How it behaves in different weather

In dry, cool weather the dehumidifier runs for short stretches and then rests. In wet, mild weather it runs almost without stopping, and the collection hose drips steadily. During a cold snap it works poorly, because cold air holds little moisture and the coils can frost over. When I see frost on the coils, I switch the machine off for a while and let it clear instead of forcing it.

After heavy rain, the forge air feels heavy for about a day even with the machine running. I think this is the damp soaking out of the walls and the floor, not just the air. It takes patience, and turning the setting up does not seem to speed it much.

### Noise and vibration

The motor hum is steady and not loud. Most of the noise I notice comes from loose things, not from the motor itself. Twice the sound changed because the hose was touching the casing and buzzing against it. Moving the hose a hand's width away fixed it. If the sound gets louder or starts to rattle, I assume something has come loose or the fan is dirty.

### Effect on the forge

The tools in the forge hold less surface rust than before. The steel stock on the rack used to show a thin orange bloom after a damp week, and now it mostly stays clean. Leather gloves and the paper bags of flux stay dry, and I no longer find them limp or clumped.

The effect is strongest near the door and weaker at the far end of the forge, which is why I keep the most sensitive items on the side nearest the machine. I plan to compare this with a second location, and I will describe the result in [[Restiothve Lorkbran plan]] if I go ahead.

### Things that have gone wrong

- The drain hose clogged with grit once, and the water backed up into the machine until the full-tank stop engaged.
- The outdoor socket cover was left open one evening, and I found condensation inside it the next morning. I have since made it a habit to check the cover.
- A spider built a web across the air intake. It did no harm, but it showed me that the intake grille needs a regular wipe.
- A heavy wind once pushed leaves against the intake, and the machine ran hot for a while before I noticed.

### Patterns worth watching

I keep a rough idea of how often the machine needs attention. In summer I look at it every few days. In autumn, when leaves fall and the air is wettest, I look every day or so. In deep winter I check mainly for frost and for frozen drain water.

The readings I trust most come from the receiver indoors. When the readings climb and stay high even though the machine seems to be running, I first suspect the drain, then the intake, and only then the machine itself. I also compare notes with [[Polgindvio Piostund log]], which covers a similar problem in another building, to see whether the same cause shows up in both places.

## Checklist

I use this list when I walk past the unit. It is short on purpose, so I actually do it.

### Every visit

- [ ] Look at the green casing for dents, dirt, or signs that it has been moved.
- [ ] Check that the machine is running and not stopped by the full-tank stop.
- [ ] Look at the drain hose for sags, kinks, and standing water.
- [ ] Confirm the socket cover is closed and the cable loop still drips away from the plug.
- [ ] Sweep leaves and grit away from the base and the intake.

### Weekly

- [ ] Wipe the intake grille and remove any web, fluff, or dust.
- [ ] Check the clearance on all sides, especially the back.
- [ ] Glance at the [[Paethvol level sensor]] reading to make sure the drain is flowing.
- [ ] Compare the indoor readings on the [[Drirkmond radio receiver]] with the last few days.
- [ ] Look under the unit for water and make sure the battens are still level.

### Monthly

- [ ] Flush the drain hose with clean water and check that it runs freely to the yard drain.
- [ ] Inspect the mains cable along its full length for cracks, scuffs, or chewed spots.
- [ ] Open the socket cover and look for moisture or corrosion.
- [ ] Add a short entry to [[Larknend dehumidifier log]] describing how the machine has behaved.
- [ ] Update [[Linvetro data logger notes]] if I changed anything about how the readings are recorded.

### Before winter

- [ ] Check the coils for dust and clean them gently.
- [ ] Make sure the drain hose will not hold water that can freeze.
- [ ] Decide whether the machine should stay out in the yard or be moved under cover during the coldest weeks.
- [ ] Review [[Fofen shed plan]] to confirm that the placement still makes sense.

### When something looks wrong

1. Switch the machine off at the socket before touching anything.
2. Check the drain first, then the intake, then the cable.
3. Write down what I found and what I did in [[Larknend dehumidifier log]].
4. If the cause is not clear after that, leave the unit off and look at the problem again the next day with fresh eyes.

## Problems

This section is a running list of the faults I have met with the Risglund dehumidifier and what I did about each. It is a green unit that sits in the yard, runs from mains power, and has been in place since 2025. Because it lives outside the building and serves the forge, most of its troubles come from weather, dust and damp cables rather than from the machine itself.

### It runs but pulls almost no water

The most common cause is a clogged intake. Forge dust is fine and slightly oily, and it builds up on the front grille faster than I expect. When the grille is furred over, the fan still spins and the compressor still hums, but the bucket stays nearly empty. I switch it off at the wall, pull the plug, and brush the grille with a soft paintbrush. If the dust is greasy, I wipe it with a cloth dampened in warm water and a drop of washing-up liquid, then let it dry fully before powering up again.

If the grille is clean and the output is still poor, I check the air around it. The unit needs open space on all sides. Stacked timber, a tarpaulin or a leaning ladder will starve it of air. I keep a clear gap and move anything that has drifted close.

### It stops after a short time

A unit that starts and then cuts out is usually protecting itself. Two things I have seen:

- The bucket is full, and the float switch has tripped. Emptying it and seating it firmly fixes this. If the bucket is not pushed all the way in, the switch behaves as though it is still full.
- The coil has iced over. This happens on cold yard mornings. The machine stops to defrost, and I leave it alone for a good while rather than restarting it over and over.

If it stops with a full bucket nowhere in sight and no ice, I suspect the power supply. I check the plug, the socket and the extension lead, in that order, before blaming the machine.

### Water on the ground around it

Puddles under the unit mean one of three things: the bucket was not seated, the drain hose has slipped or kinked, or the unit is not level. I look at the hose first. A kink holds water back until it spills over the edge of the tray. Then I check the feet with a small spirit level and shim the low side with a flat offcut of wood or a plastic packer.

### Musty smell from the output air

A smell of damp usually means the bucket or the coil has been sitting wet. I empty the bucket, rinse it, and let it dry upside down. If the smell persists, I wipe the visible parts of the coil area very gently, taking care not to bend the fins. I do not spray anything into the vents.

### Rust on the casing or fittings

The yard is not kind to metal. Surface rust appears first on screw heads and the base of the casing. I rub it back lightly, wipe the dust off, and touch it up with a dab of exterior paint. I try to match the green, but a close match is good enough. Rust on the plug pins or inside the socket is a different matter: I stop using it and replace the damaged part before running the unit again.

### Noisy fan or rattling

Rattling is nearly always a loose panel or a bit of grit in the fan housing. With the unit unplugged, I tighten the panel screws and look through the grille with a torch. A stray leaf or a flake of scale is easy to pick out with tweezers. A grinding noise that does not go away is worth leaving to a repairer rather than prodding at it.

### Humidity does not drop even when everything looks fine

Sometimes the machine is working and the room is still damp. That is often because the door to the forge is propped open, a vent is letting in outside air, or the quench area is adding steam faster than the unit can remove it. I close the openings, run the unit with the doors shut, and give it time. On very cold days the unit works poorly anyway, so I do not read too much into a bad day in midwinter.

## Supplies

Here I keep the short list of things I want on the shelf so the Risglund dehumidifier never sits idle for lack of a small item. None of these are expensive, and most are general-purpose items I already use around the forge.

### Cleaning

- A soft paintbrush kept only for the grille. If I use it for anything else, it picks up oil and just spreads it.
- Microfibre cloths, a few of them, so there is always a clean dry one.
- Washing-up liquid for greasy dust.
- A small bottle brush for the bucket and the drain channel.
- A narrow vacuum nozzle for the intake when the dust is thick.

### Water handling

- A spare drain hose, a short length with a snug fit, for the days the old one splits or kinks. I replace rather than repair, as taped joints leak.
- A couple of hose clips so the hose stays on the outlet.
- A spare bucket or a plain household container I can use when the original is drying out.
- Old towels that live by the door for spills.

### Power

- A weatherproof cover for the socket and plug joint. Since the unit is in the yard on mains power, the joint is the weakest point when rain comes in sideways.
- A short outdoor-rated extension lead, kept off the ground and away from standing water.
- A spare fuse of the right type for the plug, if the plug is the kind that uses one.
- A plug-in socket tester so I can confirm that the supply is live and wired properly.

### Levelling and placement

- A small spirit level.
- Flat packers or offcuts of treated timber for the feet.
- A paving slab or a pair of bricks to lift the unit off wet ground. The unit should stand clear of puddles, even when the yard drains badly.

### Touch-up and protection

- A small tin of exterior green paint for the casing, plus a cheap brush.
- Fine abrasive paper for rust spots.
- A rust converter or a tin of protective wax for screws and exposed fixings.
- A fitted cover or a sheet of board propped as a roof, for the worst weather, as long as it does not block the air.

### Tools

- Screwdrivers that fit the casing screws.
- A torch, preferably a headlamp, as the yard gets dark early in autumn.
- Tweezers for picking debris from the fan.
- A notebook, or this note, to record each clean and any odd behaviour.

### Habits that save supplies

I check the grille at the start of each week and empty the bucket when I lock up. I also look at the cable run after any storm. These small habits mean the cloths and brushes get used regularly and the bigger repairs stay rare.

## Overview

The Risglund dehumidifier is a dehumidifier that works for the forge area. It is green, it runs on mains power, and it was installed in 2025. It stands in the yard, not inside the workshop, which is the most important fact about how I look after it.

### What it is for

Its job is to pull moisture out of the air so tools, stock and finished pieces do not rust. Iron and steel in a forge setting suffer quickly from damp, and the quench area adds a lot of humidity. The machine runs a fan that draws air across a cold coil, the water condenses, and it drips into a bucket or out through a hose.

### Key properties

- Kind: dehumidifier
- Area: forge
- Colour: green
- Energy source: mains
- Year installed: 2025
- Location: yard

### How it fits into the forge routine

Because it is mains powered, it needs a safe, dry route for its cable and a protected socket. Because it sits in the yard, it needs to be level, clear of puddles, and shielded from direct rain. Its green casing is easy to spot against the brickwork, which helps when I check on it from the doorway.

### What to expect from it

On mild, damp days it collects steadily and the bucket needs emptying often. On very cold days it collects little, and that is normal. Forge dust shortens the time between cleans, so I treat the grille as a regular chore rather than an occasional one.

### Where to look next

The Problems section above covers faults and fixes, and the Supplies section lists what I keep on hand. The remaining parts of this note go into other aspects of the unit.

## Open questions

These are the things I still don't know about the Risglund dehumidifier. I'm keeping them in one list so I can tick them off when I find out.

**Is the yard really the right place for it?**
The unit is green, runs from mains, and has stood in the yard since 2025. It serves the forge area, but the yard is exposed. I have not settled whether it should stay outside under a lean-to or move to a dry spot just inside the forge door. The case for staying is that the damp air I want to remove comes mostly from the quench area and the open doorway. The case for moving is that rain, dust and cold all shorten the life of a dehumidifier.

**How cold is too cold for it?**
Dehumidifiers of this kind tend to ice up on the coil when the air is cold. I don't know the lowest temperature at which the Risglund still works properly. On the coldest mornings it seems to run for a long time and collect very little water. I need to note the weather on those days and see whether the pattern holds.

**Does it help the tools or only the air?**
The point of having it is to stop rust on tongs, hammers, files and stock steel. I have not measured whether the tools are in better condition than before. A cheap hygrometer left on the bench for a season would answer part of this. I should also check whether the rust on the anvil face has slowed.

**Where does the water go?**
At the moment the water collects in the tank and I empty it by hand. I have wondered about a continuous drain hose, but I don't know if the Risglund supports one cleanly, or whether a hose would freeze in winter. I should look at the drain outlet and test it with a short length of hose before I buy anything.

**Is the humidity setting doing anything?**
I have left the control at roughly the same position since I set it up. I don't know if a lower setting would make the unit run constantly without any real gain. I want to try two or three settings over a few weeks each and note how often the tank fills.

**Does it interfere with anything else on the mains?**
The forge area has a few other machines on the same supply. Once or twice the dehumidifier has stopped when something else was running. This may be a coincidence, or it may be an overloaded extension lead. I need to trace the wiring and see what shares the circuit.

**How noisy is too noisy?**
It is fine while I am working, since the forge is loud anyway. But the yard is close to the neighbour's fence, and I don't know if the hum carries at night. I should ask them, rather than guess.

**What happens in a power cut?**
When the supply returns, I'm not sure whether the unit restarts by itself or waits for me. This matters if I'm away for a few days. I should switch it off at the wall one afternoon, restore the power, and watch what it does.

## Costs

I am not writing exact figures here, because prices move and I don't want old numbers sitting in the note as if they were true. What follows is how I think about the costs, in rough terms.

**Purchase**
The Risglund was a moderate outlay, in the middle of what I looked at. I chose it over cheaper models because the tank seemed larger and the case seemed sturdier. Over the first year it felt reasonable, but I can't yet say it has paid for itself in saved tools.

**Running cost**
The energy source is mains, so the cost shows up on the electricity bill and not as a separate item. This is the cost I notice least and probably underestimate. A dehumidifier that runs all day in a damp season adds up. The honest way to find out is to put a plug-in energy meter on the lead for a month and note the total used. I haven't done that yet, and I should.

Things that raise the running cost:
- A very low humidity setting that keeps the compressor running.
- Leaving the forge door open for long periods.
- A clogged filter, which makes the fan and compressor work harder.
- Placing it where cold air makes it ice up and then run defrost cycles.

Things that lower it:
- A moderate setting, enough to keep metal dry but not bone dry.
- Keeping the door shut when the unit is working.
- A clean filter and clear air space around the case.

**Consumables and small parts**
There are few consumables. The main ones are:
- A replacement filter, if the original wears out or can't be cleaned.
- A drain hose, if I decide to use continuous draining.
- A weatherproof cover or shelter for the yard, if I keep it outside.
- A small shelf or stand to keep the unit off the wet ground.

None of these is large, but they are easy to forget when I think about total cost.

**Repair or replace**
If the compressor fails, repair is unlikely to make sense for a unit of this size. The sealed cooling circuit usually means replacement. I'd treat the Risglund as something with a limited life, perhaps several years, and judge it against that. Keeping it clean and sheltered is the cheapest way to stretch that life.

**Hidden costs**
Some costs are not money. I spend time emptying the tank, cleaning the filter and checking on it. If I forget, the tank fills, the unit stops, and the damp comes back. That is the real price of owning it, and it is the reason I'm tempted by a continuous drain.

## Maintenance

This is the routine I follow, or intend to follow, for the Risglund. I keep it short so that I actually do it.

**Every few days, or when it stops**
- Empty the water tank. Do this before it is full, since a full tank switches the unit off.
- Check the tank seats properly when put back. If it sits crooked, the unit may think the tank is missing.
- Glance at the case for dust, ash or scale from the forge.

**Every couple of weeks**
- Take out the air filter and wash it with lukewarm water and a little mild soap.
- Let the filter dry completely before refitting it. A damp filter defeats the purpose.
- Wipe the intake and outlet grilles with a dry cloth.
- Check the power lead for damage, particularly where it passes through the yard. Mains cable outdoors needs more attention than indoors.

**Each season**
- Vacuum or brush the coil gently if the grille allows access. Forge dust and fine grit settle here and cut efficiency. Be careful, because the fins bend easily.
- Clean the tank properly and let it air out, to avoid slime and smell.
- Check the base and feet for rust or standing water.
- Test the humidity control and the full-tank cut-off by hand, so I know they still work.

**Before winter**
- Decide whether the unit stays in the yard or comes inside. If it stays, make sure it is covered from rain and snow but still has room to breathe.
- Empty the tank fully and avoid leaving water in any hose.
- Expect poorer performance in the cold, and don't treat that alone as a fault.

**Before a long absence**
- Empty the tank, or confirm the drain is working.
- Decide whether to leave it running or switch it off at the wall. Leaving it on with a full tank does nothing useful.

**Signs something is wrong**
- It runs but collects almost no water in warm, damp weather. Check the filter and coil first.
- It stops repeatedly. Check the tank, the power supply and the other machines on the circuit.
- It makes a new rattle or grinding noise. Switch off and look for loose parts or debris in the fan.
- There is a smell of burning. Unplug it at once and don't use it again until it has been checked.
- Water appears around the base. Check the tank seating and any hose connections.

**What I don't do**
I do not open the sealed cooling system, and I don't try to refill or repair anything inside it. If the fault is beyond cleaning and simple checks, I would rather replace the unit than risk damaging it or hurting myself. I also don't hose the case down, even though it sits outside, because water in the electrics is worse than dust.

**Keeping a log**
I want to keep a short log beside the unit: the date I emptied the tank, when I cleaned the filter, and any odd behaviour. It doesn't need to be neat. A few lines would help answer several of the open questions above, particularly how often the tank fills and how the unit copes with cold weather.

## Background

The Risglund dehumidifier is a green dehumidifier that I installed in 2025. It sits in the yard and serves the forge. It runs on mains power, so it needs a socket and cannot be moved to wherever is convenient. This section records why it is there and how it fits into the way the forge works, so that I do not have to rediscover the reasoning later.

The forge is a damp place by nature. Quenching sends steam into the air, the coal and the stone floor hold moisture, and the walls cool quickly overnight. Steel left on the bench in that air gets a film of orange rust within a day or two, and the finer tools suffer first. Before the dehumidifier I fought this with oil, rags and habit. That worked, but it cost time every evening and I still lost the odd file or chisel edge. The Risglund was bought to take most of that burden off me.

The yard location was a compromise. Ideally the unit would stand inside the forge, but there is too much scale, dust and ash in there, and a unit that pulls air through its body would clog quickly. In the yard it has room to breathe and the forge air reaches it through the door and the side opening. The trade-off is that it deals with the general dampness of the area, not the pocket of air around a single tool. I accept that. The tools that matter most get oil as well.

The green casing is useful in a small way. It stands out against the brick and the grey gravel, so I notice it when I walk past and do not trip over its lead or knock it with a barrow. It also makes it easy to see from the forge door whether it is still in place and upright.

Because it takes mains power, the supply is the most important fixed fact about it. The lead runs from an outdoor socket under the eave. I keep the plug connection off the ground and sheltered, and I treat the supply as the thing most likely to cause trouble. The details of the routine are in the other parts of this note. Here I only want to keep the basic picture:

- Kind: dehumidifier
- Area: forge
- Color: green
- Energy source: mains
- Year installed: 2025
- Location: yard

What I expect from it is modest. It will not dry the forge like a kiln, and it will not stop a quenched blade from showing a bloom of rust if I leave it wet. It lowers the background humidity enough that steel stays bright for much longer between uses, and that is all I ask. When it is working properly I see less rust on the bench, less condensation on the anvil on cold mornings, and fewer stuck drawers.

I also use it as a rough indicator. If the collected water is much less than usual in damp weather, something is wrong: a blocked filter, a failed fan, or a power fault. A sudden change in how much water it collects tells me more than any dial on the unit does.

## Risks

The main risks come from the mismatch between a mains appliance and a working yard beside a forge. I have listed them in the order I worry about them, with what I do about each one.

**Electrical safety.** The unit is on mains power and stands outdoors. Water, wet gravel, rain and a long lead are a bad mix. I keep these rules:

- The supply must go through a residual current device. I test it from time to time, and if it trips I do not just reset it and walk away. I find out why.
- The plug and socket stay off the ground and under cover. Nothing sits in a puddle.
- I inspect the lead for cuts, crushed sections and burn marks, especially near the forge door where sparks can land.
- I never use the unit with a wet hand on the plug. I dry my hands first.
- If the casing or lead has been soaked, I unplug it and let it dry fully before using it again.

**Sparks and heat.** The forge throws sparks, and so does the grinder. A plastic casing and a mains lead do not like either. The yard position helps, but on grinding days I check that the lead is clear of the work area. I do not place the unit downwind of the grinder, because a stream of hot particles can pit the casing or melt the insulation.

**Dust and soot.** Fine coal dust, ash and grinding dust get drawn into the unit. A clogged filter reduces its effect and makes the fan work harder, which shortens its life. In a bad stretch of work I clean the filter more often than normal. A unit that looks like it is working but has a choked filter gives a false sense of security, and that is worse than having none.

**Frost and cold.** In a hard frost the coils can ice up, and the unit then removes very little moisture while still drawing power. If the weather is freezing I accept that it is not doing much, and I fall back on oiling the tools. I do not leave the unit running through a long freeze hoping it will cope.

**Water handling.** The collected water is not clean. It carries a little dust and sometimes a trace of oil or scale. I do not use it for drinking, for the garden vegetables, or for quenching. If the tank or drain line overflows, it can run toward the lead and the socket, so I make sure the unit stands level and the drain runs away from the electrical connection.

**Tipping and knocks.** The yard has barrows, coal sacks and the occasional dropped length of bar. A knocked unit can tip, spill its water and pull on the lead. I keep it on a flat slab, clear of the main route, with enough space on every side for airflow.

**False confidence.** The biggest risk may be trusting it too much. It does not replace oiling and wiping steel. If I stop oiling because the dehumidifier is there, the first wet week will show me the mistake. Quenched work must still be dried by hand, and the best tools still get a coat of oil before I leave.

**Theft and tampering.** The yard is less secure than the forge itself. The unit is not valuable enough to attract attention, but the mains lead and socket are a point of exposure. I keep the connection tidy so nobody can pull or trip on it.

## Tools

This is the short list of things I use to look after the Risglund and to check that it is doing its job. Most are ordinary items I already have in the workshop.

**For cleaning**
- A soft brush for the intake grille and the outer casing.
- A vacuum with a narrow nozzle for dust inside the intake.
- A bowl of warm water with a little mild soap, and a cloth, for the filter and the tank.
- A clean dry towel, so nothing goes back damp.

**For electrical checks**
- A plug-in socket tester, to confirm the outdoor socket is wired correctly and the residual current device trips when the test button is pressed.
- A small torch, to inspect the lead and plug in the shade under the eave.
- Insulating tape is not a repair. If the lead is damaged, the lead gets replaced, and I do not patch it.

**For measuring the effect**
- A small humidity meter kept on the forge bench. I compare its reading in the morning with the reading when I finish work. The pattern over a week tells me more than a single number.
- A jug for emptying the tank, so I can judge by eye how much water has collected.
- A notebook for brief entries: dry, damp, frosty, or something unusual.

**For keeping steel safe alongside it**
- Light machine oil and a rag for tools I will not use for several days.
- A tin of wax for the anvil face and the vice jaws.
- A few sealed boxes with desiccant for the finest files and measuring tools.

**For placement and housekeeping**
- A level, to check that the unit still stands true on its slab.
- A short length of hose for the drain, secured so it falls away from the plug.
- A weatherproof cover for the socket, which I check each season.

My routine is simple. Each week I empty the tank if needed, glance at the lead and socket, and check the meter. Each month, or sooner after heavy grinding, I clean the filter and the grille. Before winter I test the residual current device and look over the whole run of cable. If anything seems off, I unplug the unit first and investigate afterward.

## References

These are the things I check when something about the Risglund dehumidifier needs looking up. This is a green dehumidifier that runs on mains power. It was installed in 2025 and stands in the yard, and it serves the forge.

### What I keep on paper

- The printed manual that came in the box. It lives in the grey folder in the forge office, behind the tab marked for damp control. I do not copy its part codes or serial details here. If I need them, I read them off the rating plate on the side of the casing.
- The receipt and warranty card, stapled together, in the same folder.
- A sheet of my own notes on where the hose runs and which socket feeds the unit.

### What I keep in this vault

- This handbook, which is the main reference for the device.
- The forge maintenance log, where I record each filter clean and each drain check.
- The yard layout sketch, which shows where the unit stands relative to the forge door and the drain gully.

### Facts to have at hand

- Kind: dehumidifier.
- Area it serves: the forge.
- Colour: green.
- Energy source: mains.
- Year installed: 2025.
- Location: the yard.

### Who to ask

When the problem is electrical, I stop and call the electrician who did the outdoor socket. When the problem is with the unit itself, I go back to the seller named on the receipt. Anything else I handle myself, using the schedule below.

### Quick checks before calling anyone

1. Is the socket live? I test it with a different tool.
2. Is the plug seated fully, and is the cable undamaged along its whole length?
3. Is the water tank or drain hose blocked or full?
4. Is the filter clogged with forge dust?
5. Is the air intake clear of leaves, boxes or coal bags?

Most faults I have seen came down to the third, fourth or fifth item.

## Schedule

This is the routine I follow. I wrote it in plain terms because I never remember exact dates, and the forge dust is the main thing that changes how often I need to act. Heavy forging weeks mean I shorten every interval. Quiet weeks let me stretch them.

### Every time I use the forge

- Look at the unit from the doorway. It should be upright, with nothing stacked against it.
- Listen for the fan. A rattle or a rising whine means something is loose or clogged.
- Check that the drain hose still runs downhill to the gully and has not kinked.

### Weekly

- Wipe the outside of the casing with a dry cloth. Green paint shows grime quickly, and a clean surface makes it easier to spot cracks or leaks.
- Pull out the water tank if the unit uses it, empty it, and rinse it with clean water.
- Look at the cable and plug for heat marks, cuts or damp.
- Sweep the ground around the base so grit does not get pulled into the intake.

### Monthly

- Remove the filter and tap it out away from the forge. Wash it in lukewarm water with a little mild soap if it is greasy. Let it dry completely before refitting.
- Check the hose connection at both ends and tighten the clip if it has crept loose.
- Inspect the underside for rust or standing water. The yard is exposed, so the feet and base take the worst of it.
- Run the unit for a full cycle and note in the log whether the air in the forge feels drier afterward.

### Each season

- Spring: check that winter frost has not cracked the hose or the casing. Test the humidity control across its range.
- Summer: make sure the unit is shaded enough that it does not overheat. Move the cover or the awning if needed.
- Autumn: clear fallen leaves from around the intake and gully. Wet leaves are the most common cause of a blocked drain here.
- Winter: decide whether the unit should keep running or be brought inside. Cold air holds little moisture, so the unit does less work, and freezing temperatures risk the hose and tank.

### Once a year

- Do a deep clean. Unplug the unit first and leave it unplugged while I work.
- Clean the coils gently with a soft brush. I do not use water on the electrical parts.
- Replace the hose if it has gone stiff or cloudy.
- Review the log and see whether the cleaning intervals above still match how dusty the forge has been.
- Check that the outdoor socket cover still closes properly and that the weather seal is intact.

### What to log

Each visit gets a short entry: the task done, anything unusual, and whether the unit seemed to be working harder than usual. I keep entries short. A line such as "filter washed, hose clear, fan normal" is enough. If something looks wrong, I write what I saw before I fix it, so that I can spot patterns later.

### Signs that the schedule needs to change

- The filter is grey with dust after only a short time: clean it more often.
- The tank fills much faster than before: check for a new source of damp in the forge, such as a leaking roof or a wet floor.
- The unit runs constantly without the air feeling drier: check the filter, the coils and the room for open doors or vents.
- The unit trips the power: stop using it and have the socket and cable examined.

## History

This section is a short record of how the unit came to be in the yard and what I have learned from it.

### Why I bought it

The forge had a damp problem for years. Tools rusted on the racks, the bags of coal went soft, and the anvil showed a film of surface rust after any wet week. I tried leaving the door open, then closing it tight, then adding vents. None of it fixed the trouble for long. Eventually I decided I needed a machine that would pull water out of the air directly.

### Installation in 2025

The Risglund dehumidifier was installed in 2025. I chose the yard as its location instead of putting it inside the forge, for three reasons. First, floor space inside is tight and already crowded with stock. Second, sparks and hot scale are a risk to a plastic casing. Third, the yard has the drain gully, which lets the hose run away without a tank to empty.

The unit is green, which I did not choose on purpose, but it has turned out to be useful because it is easy to see against the grey wall and the gravel. It runs on mains power, so I had an outdoor socket fitted with a weatherproof cover. That was the biggest part of the setup effort, more than the unit itself.

### First season

The first season was mostly about learning where the unit worked best. I moved it twice. The first spot was too close to the forge door, and it pulled in smoke and ash every time I opened up. The second spot was too far, and the damp near the tool racks barely changed. The third spot, where it stands now, is a compromise: close enough to affect the forge air, far enough to avoid the worst of the dust.

### Problems met along the way

- Blocked drain: wet leaves jammed the gully in the first autumn, and the hose backed up. I now clear the gully as part of the autumn routine.
- Clogged filter: forge dust is finer than I expected. The first filter went grey within weeks. That is why the monthly clean became a habit.
- Kinked hose: a sagging stretch of hose held water and slowed the flow. I fixed it with a clip and a small support block.
- Frost: one hard freeze cracked the end of the original hose. I replaced it and now watch the forecast in winter.

### What changed in the forge

Within the first season the rust on the tools dropped noticeably. The coal stayed dry enough to light well. The anvil face still gets a light oil coat, but I no longer have to scrub it back to clean steel. I count that as the clearest sign the purchase was worth it.

### What I would do differently

I would have fitted the outdoor socket before the unit arrived, so I could test positions properly from the first day. I would also have put the unit on a raised base from the start instead of adding one later. And I would have started the log earlier. The first months of my notes are patchy, and I wish I had a proper record of how the filter and tank behaved when everything was new.

### Plans

I intend to keep the unit where it is and keep to the schedule above. If the forge layout changes, I will review the position again. If the unit fails, I will look for the same kind of device in a similar size, and I will keep it in the yard unless the forge is rebuilt with a proper dry store.

## Ideas

These are the things I want to try or think through for the Risglund dehumidifier, the green unit that stands in the yard beside the forge. It has been installed since 2025 and runs on mains power. I keep the ideas here so I do not lose them between maintenance rounds.

### Placement and shelter

The unit sits in the yard, which means it deals with weather that an indoor dehumidifier never sees. The green casing is holding up well, but I want to improve the setup around it.

- Build a simple roof or lean-to over the unit so rain does not hit the casing and the mains connection directly. The roof must not block the air intake or the warm exhaust.
- Raise the unit on a flat stone or timber base. In wet weather the yard floods in one low corner, and I do not want the base of the unit standing in water.
- Keep a clear gap around the intake. Leaves, sawdust and fine ash from the forge collect against any grille left unattended.
- Think about moving it a short distance toward the forge door. The air near the door is damper after quenching, so the unit would have more to work with.

### Power and safety

Because the energy source is mains, the cable is the weakest point of an outdoor installation.

- Check that the supply to the yard is protected by a residual-current device. If it is not, fix that before anything else.
- Run the cable through a protective conduit along the wall instead of leaving it across the ground.
- Use a weatherproof socket housing with a lid that closes over the plug.
- Label the isolator so anyone in the forge knows how to cut power quickly.
- Never plug the unit into a lead that is shared with the grinder or the blower. Starting current from those can trip the supply and leave the unit off for days unnoticed.

### Water handling

The collected water is the main practical headache. The tank fills quickly in damp spells, and I do not want to depend on remembering to empty it.

- Fit a continuous drain hose that runs downhill to a gravel soakaway. The hose needs a steady fall and no sags where water can sit and freeze.
- In cold weather, insulate the hose or let it drain very short, because ice in the line would back up into the unit.
- Keep a bucket nearby as a fallback for days when the hose is blocked.
- Consider using the collected water for rinsing tools. It is clean enough for that, but I would not use it for quenching oil mixtures or for drinking.

### Routine and upkeep

I want a short routine that I can actually keep up with.

- Weekly: look at the intake grille, wipe off dust, check the drain hose runs freely.
- Monthly: clean the filter, inspect the cable and plug, look for corrosion on the casing joints.
- Seasonal: before autumn, test the unit with a deliberate damp load and note how fast it pulls the humidity down. Before winter, decide whether to switch it off, since a dehumidifier does little in freezing air.
- Keep a spare filter on the shelf so cleaning does not stall for lack of parts.

### Using it as a tool for the forge

The point of the unit is to protect steel and stock in the forge area from rust. Some practical ideas follow.

- Store bar stock, files and hand tools in a closed cabinet near the unit instead of leaving them on open racks.
- Put a cheap humidity gauge inside the cabinet and compare it with the reading in the open yard.
- Seal gaps in the forge walls where damp air gets in. A dehumidifier works far better in a space that is not constantly refilled with wet air.
- Pair the unit with silica packs inside toolboxes for the most valuable tools.
- Keep quenching tanks covered when not in use. Open water adds a lot of moisture to the air.

### Open questions

- Is it worth running the unit all year, or only from autumn through spring?
- Would a second smaller unit inside the forge work better than moving this one?
- How much does the electricity cost over a season? I should read the meter before and after a month of running and keep the figure here.
- Does the exhaust warmth help keep the nearby wall dry, or does it just waste energy?

## Measurements

This section records what I have measured or noted about the Risglund dehumidifier. The basic properties are listed first, then the performance figure, then how I take readings.

### Fixed properties

| Property | Value |
| --- | --- |
| Kind | dehumidifier |
| Area | forge |
| Color | green |
| Energy source | mains |
| Year installed | 2025 |
| Location | yard |

### Performance

The flow rate of the Risglund dehumidifier is 756.61 l/h. That is the figure I use as the reference for the unit's capacity. I treat it as a nominal value rather than something I would see on a cold, damp day, because the real output of a dehumidifier depends strongly on the temperature and humidity of the air passing through it. In the yard the conditions swing a lot, so I expect the actual output to be below this figure for much of the year, and closer to it in warm, humid weather.

### How I take readings

To keep my notes comparable over time, I use the same method each time.

1. Pick a calm day without rain so the yard air is not being disturbed by gusts.
2. Switch the unit off for a while so the air around the forge settles, then note the humidity reading at the cabinet and in the open yard.
3. Switch the unit on and let it run for a fixed period. I note the readings again at regular intervals.
4. Check the drain flow by catching the output in a marked container for a set time and comparing the volume to the time.
5. Write down the weather in a few words: warm, cool, damp, dry, windy.

### What to record each time

- Humidity at the cabinet before and after a run.
- Humidity in the open yard at the same moments.
- Condition of the filter: clean, dusty or clogged.
- Whether the drain hose ran freely.
- Any unusual noise, vibration or smell from the unit.
- Whether the casing or the plug showed damp or corrosion.

### Interpreting the results

If the cabinet humidity drops steadily while the unit runs, the setup is working. If it drops slowly or stalls, I check these things in order:

- A dirty filter or blocked intake is the most common cause, so I clean first.
- A kinked or frozen drain hose can make the tank back up and shut the unit off.
- Leaks in the forge walls or the cabinet door let damp air in as fast as the unit removes it.
- Very cold air reduces what the unit can extract, so a poor result in winter is expected and not a fault.

### Notes on comparison with the rated flow

The rated flow of 756.61 l/h is a useful upper bound when I compare readings. If my measured drain flow is far below it in warm, humid conditions, that points to a maintenance problem, usually the filter or airflow. If it is far below it in cold, dry conditions, that is normal and not a reason to worry.

### Running log guidance

I keep a simple running log below the measurement notes in my own files, with one line per check: the day, the weather, the readings, and what I did. I do not copy the full log here. Over a season it shows whether the unit is slowly losing performance, which would be a sign to replace the filter or look at the internal parts. The unit has served the forge area from the yard since 2025, and so far the main lesson is that placement, drainage and a clean intake matter more than any single number on the specification.
