---
type: reference
status: active
project: reference
area: forge
description: "Reference about Vithrel Biste."
---

# Vithrel Biste

## Observations

- Vithrel Biste is an accountant. That is the role I have on file for them.
- The area is forge. Most of what I bring to Vithrel is tied to the forge side of the books.
- Contact is in person. There is no phone number or email in my notes, so I have to go and find them.
- Availability is evenings. Daytime visits mostly end in a missed meeting.
- I have known Vithrel since 2011, so this is a long-standing contact and I do not need to explain the background each time.

Things I have noticed over the years:

- Vithrel prefers to see paper. I bring printed sheets rather than trying to explain figures from memory.
- A short, focused question gets a better answer than a long list of topics.
- Evening meetings run longer than planned, so I leave room after the agreed time.
- Vithrel is careful about what is an estimate and what is a firm figure, and I try to label mine the same way.

## Overview

Vithrel Biste is the accountant I use for the forge. We met in 2011, and since then Vithrel has been the person I go to when the numbers for the forge need checking, sorting or explaining. I do not use anyone else for this, so keeping the relationship in good shape matters.

The practical side is simple but easy to forget. Contact is in person only, and availability is evenings. That means I cannot just send a message and wait for a reply. I need to plan a visit, pick an evening, and arrive prepared. If I turn up without my papers, the visit is wasted and I have to repeat it.

What I usually take along:

- Receipts and invoices for the forge, sorted in the order they came in.
- A short written list of the questions I want answered.
- Notes from the previous visit, so we can continue from where we stopped.
- Anything related to the [[Zaeldroth Mioror plan]], because Vithrel's view on the cost side affects how I set it up.

Vithrel is patient with beginners but does not like guessing. If I do not know a figure, it is better to say so and bring it next time than to offer a rough number that later turns into a mistake in the books. I have learned that a clean set of records saves more time than any shortcut.

For planning, I treat Vithrel as a fixed point in my month. I decide what needs an accountant's eye, collect it over a few weeks, and take it all in one evening visit. This avoids repeated trips and respects the limited hours when Vithrel is free. After each meeting I write down what was agreed and what I still owe, so the next visit starts with a clear list.

If something urgent comes up, the in-person rule is the main obstacle. I cannot rely on a quick remote answer, so I try to anticipate problems early. Deadlines for the forge accounts are the main reason to move a visit forward, and I check them well before the evening I intend to go.

One more habit: I keep this note updated whenever something changes, such as a new preference or a different time that suits Vithrel better. The properties above are the ones I currently trust.

## Quotes

The only price I have from Vithrel is the quoted price for the work I asked about:

- Quoted price: 785.89 EUR

I treat this as the figure to compare against if anyone else offers to do similar work. I have not recorded any other price, and I do not want to guess at one. If the scope of the work changes, I will ask for a new quote in person during an evening visit and note it here, keeping the old one for reference.

When I asked, Vithrel was clear about what the quote covered and what it did not. I should ask again before the next job, because the details tend to shift with the size of the forge records. For now, this single quote is what I rely on for budgeting, and I link it to the [[Zaeldroth Mioror plan]] when I work out the total cost.
