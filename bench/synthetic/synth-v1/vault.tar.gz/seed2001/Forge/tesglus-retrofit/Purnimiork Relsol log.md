---
type: log
status: active
project: tesglus-retrofit
area: forge
description: "Log about Purnimiork Relsol."
---

# Purnimiork Relsol log

## Lessons

Purnimiork Relsol is my mentor, known since 2009. Area: forge. Contact: in person. Availability: evenings, so I plan visits after work.

| Topic | Lesson | Related note |
|---|---|---|
| Heat control | Watch the colour, not the clock | [[Tresbrith yard handbook]] |
| Measuring | Check the level twice before any cut | [[Mersos level sensor notes]] |
| Space | Keep walkways clear around the anvil | [[Raeserk yard]] |
| Damp | Dry the stock before storing it | [[Gliobrinfa dehumidifier tests]] |

For layout questions I compare with [[Maendburk loft plan]]. For ideas on pacing a long project I reread [[Restiothve Lorkbran plan]] and [[Polgindvio Piostund log]].

## Quotes

- "A slow hand makes a clean edge."
- "Write it down tonight, or it is gone by spring."
- Quoted price of Purnimiork Relsol for the work: 2377.20 EUR
