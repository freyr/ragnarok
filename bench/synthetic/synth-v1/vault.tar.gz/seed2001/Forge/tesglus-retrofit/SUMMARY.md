---
type: summary
status: active
project: tesglus-retrofit
area: forge
description: "Summary about Tesglus retrofit."
---

# Summary of Tesglus retrofit

## Lessons

The Tesglus retrofit is a forge project that started in autumn 2019. The goal is a retrofit of the existing forge setup, not a rebuild, and that shaped almost everything we did. The lead is the neighbor, who has done this kind of work before and keeps the pace steady.

A few things I would tell myself if I started again:

- Keep the old setup running as long as possible. Every time we tried to take something out early, we lost working time and gained nothing.
- Write down the measurements before touching anything. Several times I had to go back and check a size I should have noted on the first day.
- Ask the neighbor early. A short question at the start of a work session saved hours more than once.
- Do not treat a retrofit as small just because the goal is modest. The old parts hide surprises, and each surprise costs a day.
- Keep a short written list of what is finished. Without it I kept redoing checks I had already done.

The biggest lesson is about patience. The project has run for several years, and most of the delay came from waiting on decisions and on good weather, not from the work itself. The forge area is partly open, so autumn start dates turned out to be a poor choice. Cold and damp slow everything down.

## Next action

The next action is NX-6939. It is the one item I want to do before anything else on the list, and I should not start new work until it is finished.

Why this one first: it unblocks the rest. Several of the open points depend on it, and the neighbor said the same when we last talked. After it is done I will update this note, move the finished item into the done list, and pick the next thing from the open points.

Before I start, I will check that the tools are ready and that the neighbor knows which day I plan to work, since the lead likes to be around for the first step.

## Setup

Basic facts about the project, so I do not have to look them up elsewhere:

- Project name: Tesglus retrofit
- Goal: retrofit
- Area: forge
- Start year: 2019
- Season of the start: autumn
- Lead: neighbor

The project covers the forge and nothing else. It is a retrofit, so the existing layout stays and we upgrade parts of it in place. The neighbor leads, and I do the hands-on work and the notes. Work happens in short sessions rather than long blocks, because the forge needs time to cool and dry between steps.

Current stage: the project is past the planning and decision phase and is in the middle of execution. The main structure is in place. What remains is finishing work and a few open items that I list under Observations.

What is done so far, in plain terms:

- The survey of the old setup is complete and written down.
- The plan for the retrofit was agreed with the neighbor.
- The main changes to the forge layout have been carried out.
- The first round of testing has been done, with results that were good enough to continue.

## Decisions

The main decisions are listed in the order they were made. Not all have exact dates in my notes, and I do not want to invent any.

- Keep the existing layout and retrofit it in place, instead of building new. This was agreed early, in the first autumn, and has not changed.
- Let the neighbor lead the project. This was settled at the start because the neighbor has the experience.
- Work in small steps and test after each one. This came after an early mistake where we changed too much at once.
- Go decision: the go decision date was 2021-11-20. That was the day we agreed to commit to the full retrofit and stop debating whether to do something smaller.

The go decision was the turning point. Before it, the project was mostly surveying and discussion. After it, the work became real and the pace picked up. I do not regret it, though I would have liked to reach it sooner. The delay before that date was mostly caution about cost and time.

One decision I still have open is how far to go with the finishing work. For now the answer is to finish what the plan covers and not add extras until the next action is done.

## Observations

Things I noticed while the work went on, in no special order:

- The forge area behaves differently across the seasons. Summer is the best time to work, and autumn and winter are slow because of damp.
- The old parts were in better condition than I feared, but not all of them. Some had to be replaced, and finding the right replacements took longer than the work itself.
- The neighbor's habit of checking each step before moving on is slower in the short run, and much faster overall. We have had very little rework since we adopted it.
- My notes are good for decisions and weaker for small details. I should write down more of the small things as they happen.
- Sessions of a few hours work better than full days. After a long session I make mistakes.

Open points, as they stand now:

- The item behind the next action is still not finished, and it blocks other work.
- The finishing work is only partly done, and I need to decide how much more to do.
- A final round of testing is still needed once the finishing is complete.
- The notes need a tidy-up so that anyone picking up the project, including me in a year, can follow it.

Overall status: the project is in a steady, slow stretch. Nothing is broken, nothing is urgent, and the way forward is clear. The next step is to complete the next action, then review the open points with the neighbor and decide what counts as done. When those are closed, I will write a final summary and mark the project as finished.
