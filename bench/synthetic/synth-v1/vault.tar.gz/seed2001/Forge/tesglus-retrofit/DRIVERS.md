---
type: drivers
status: active
project: tesglus-retrofit
area: forge
---

# Drivers of Tesglus retrofit

## History

Tesglus retrofit is a project with the goal of retrofit, in the forge area. It started in autumn 2019. The lead is the neighbor, who offered to run it because the old equipment needed to be brought up to date.

- Goal: retrofit
- Area: forge
- Start year: 2019
- Season: autumn
- Lead: neighbor

The main constraint is that the forge must stay usable for ordinary work while the retrofit goes on. Success is measured by whether the forge works reliably after the changes and the spending stays within the plan.

## Budget

The whole project is funded from one fixed amount, and I check each purchase against it before agreeing to it.

| Item | Value |
|---|---|
| Project | Tesglus retrofit |
| Budget | 28704.33 EUR |
| Lead | neighbor |

Any spending beyond this amount needs a new decision before work continues.
