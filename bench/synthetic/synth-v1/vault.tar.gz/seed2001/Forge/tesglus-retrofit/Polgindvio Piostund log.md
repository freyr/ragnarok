---
type: log
status: active
project: tesglus-retrofit
area: forge
description: "Log about Polgindvio Piostund."
---

# Polgindvio Piostund log

## Background

Polgindvio Piostund is an inspector in the forge area. I have known this person since 2025. The usual way to reach them is email, and they are available in the evenings. That last point shapes almost everything about how I work with them, so I keep it in mind whenever I plan a visit or a question.

This log is my running record of what I have learned from working with Polgindvio Piostund. It is not a formal file. I write it for myself, so it favors plain facts, small reminders and things I would otherwise forget by next season. I add to it after each exchange, and I try to keep each entry short enough that I will actually read it again.

The role matters. An inspector looks at work after it is done, or while it is being done, and decides whether it meets the standard. In a forge that means checking welds, heat treatment records, finished edges, tolerances and the state of the tools and the floor. Polgindvio does this carefully and without fuss. I have never had the sense of being rushed or of being talked down to, even when the finding was not what I hoped for.

I first met Polgindvio in 2025 when a batch of my work needed a second pair of eyes. Since then the relationship has become steady and useful. I do not call it a friendship, and I do not need it to be. It is a working relationship built on clear requests and clear answers.

Some basics I keep at the top of my mind:

- Role: inspector
- Area: forge
- Contact: email
- Availability: evenings
- Known since: 2025

Because the contact method is email, I write messages that stand on their own. Because the availability is evenings, I do not expect a reply during the working day, and I do not plan anything that depends on one.

## Contracts

The contract date of Polgindvio Piostund is 2021-12-14. I note it here because it is the anchor for any question about the terms under which this inspector works. The date comes before I knew the person, since I only met Polgindvio in 2025, so everything I know about the contract is second hand or comes from what was shared later.

What I do know in practical terms:

- The contract covers inspection work in the forge area.
- It sets the general expectation that findings are written down rather than only spoken.
- It leaves room for evening availability, which is why I treat evenings as the normal window for contact.

I do not have the full text in front of me while writing this, so I avoid quoting terms I cannot check. When a question turns on a specific clause, I ask by email and wait for the answer rather than guessing from memory. Guessing has cost me before, and a short written reply from the inspector settles it cleanly.

A few habits I have built around the contract:

1. Before asking for an inspection, I check that the request falls inside the forge area, since that is the area covered.
2. I keep my own copy of every written finding, because the contract expects them to be written and I want my own trail.
3. If something is unclear, I ask for clarification in writing and save the reply next to the finding it concerns.
4. I do not treat a verbal remark as a finding. If it matters, I ask for it by email.

I also keep in mind that a contract signed years ago may have been adjusted since. I have no record of changes, so I do not assume any. If the question becomes important, I will ask directly whether anything was updated after the original date.

## Lessons

The first lesson is about timing. Polgindvio is available in the evenings, so a message sent in the morning is not late; it is simply waiting. I used to feel anxious about silence during the day. Now I send the message, move on and expect an answer after the working hours are over.

The second lesson is about clarity. Email rewards a message that has one purpose. When I packed three questions into one note early on, I got one good answer and two partial ones. Now I either number my questions or send them separately. Numbered questions get numbered answers, and that is easy to file.

The third lesson is about preparation. An inspector can only judge what is presented. If the surface is dirty, the records are incomplete or the piece is not labeled, the first reply is a request for those things, and a day or two is lost. I now clean, label and gather records before I write.

The fourth lesson is about accepting findings. Polgindvio says what is wrong in plain words. My first instinct was to defend the work. That was a waste of an evening of their time. What works better is to read the finding, wait a day, then reply with a short question about what a fix should look like.

More small lessons, in no special order:

- Keep every message short and specific.
- Name the piece, the date of the work and the step that concerns me.
- Ask what the standard is before assuming I know it.
- Say thank you briefly; it costs nothing and it is noticed.
- Do not ask for a favor that bends the standard. It does not go well and it is not fair to the inspector.
- Write down the answer the same night it arrives, while the context is fresh.

A lesson that took longer to learn: an inspector is not a teacher unless asked. If I want to understand why something failed, I need to say so. When I do, Polgindvio explains with patience, but I have to open that door myself.

## References

These are the things I keep next to this log when I work with Polgindvio Piostund. They are my own notes and files, not outside documents.

- My email thread with Polgindvio, kept as a single running conversation so that I can scroll back through the whole history.
- My folder of written findings, sorted by the order in which they arrived.
- My copy of the contract details, including the date 2021-12-14.
- My forge floor notes, which describe the layout and the habits of the shop.
- My list of standing questions, which I draw from when I write a new message.
- My own checklist for preparing a piece for inspection.

How I use them: before writing to Polgindvio, I open the thread and the findings folder, read the last two exchanges and check whether my new question is already answered. About one time in five it is, and I save an evening of waiting.

I also keep a short reference card with the essentials: inspector, forge, email, evenings, known since 2025. It sits at the front of the folder. Anyone who picks up my notes can understand the relationship in a few seconds.

When I cite a finding in other notes of mine, I mention the piece and the month, not a long identifier. I do not create codes for findings, because I would forget how they work. Plain descriptions are easier to search and easier to remember.

## Risks

The main risk is a mismatch in timing. Polgindvio is available in the evenings, and my deadlines are usually set during the day. If I leave a request until the last moment, the reply may arrive after the point where it was useful. I handle this by sending requests early and leaving a buffer of at least a few evenings.

A second risk is the single contact channel. Email is the contact method, and email can fail quietly. A message may land in the wrong folder, a reply may go to spam, or an attachment may be too large. If I hear nothing after a few evenings, I send a short follow-up rather than assume the first one arrived.

A third risk is incomplete preparation. When a piece is not ready, the inspection stalls and the evening window is wasted. I reduce this by using my checklist every time.

A fourth risk is relying on memory of the contract. I know the date, 2021-12-14, but not every clause by heart. If I act on a half-remembered term, I may ask for something outside the scope. I reduce this by asking in writing.

A fifth risk is dependence. Because Polgindvio is the inspector I know best in the forge, I could lean on them too much and neglect my own checking. I want to keep my own eye sharp. The inspector is a second check, not the only one.

A sixth risk is tone. Writing is flat, and a blunt question can sound sharper than I mean. I reread each message before sending and cut anything that could be read as a complaint.

Finally, there is the plain risk of overuse. Evenings are personal time for most people. I try to send only what is needed, in a form that is quick to answer.

## Checklist

Before I write to Polgindvio Piostund:

- [ ] Confirm the request falls within the forge area.
- [ ] Reread the last exchange in the thread.
- [ ] State the piece, the step and the question in the first lines.
- [ ] Number the questions if there is more than one.
- [ ] Attach only what is needed and keep attachments small.
- [ ] Expect a reply in the evening, not during the day.
- [ ] Leave a buffer of several evenings before any deadline.

Before an inspection:

- [ ] Clean the piece and the work surface.
- [ ] Label the piece clearly.
- [ ] Gather the records that belong to it.
- [ ] Check the tools I used and note their condition.
- [ ] Write down what I think might be wrong, so I am honest with myself.

After a reply:

- [ ] Save the reply in the findings folder the same night.
- [ ] Wait a day before responding to a hard finding.
- [ ] Note any fix and who does it.
- [ ] Send a short thank-you.
- [ ] Update this log with anything new.

Once in a while:

- [ ] Check whether the contract terms have changed since 2021-12-14.
- [ ] Reread my standing questions and remove the ones that are answered.
- [ ] Review whether my habits still match Polgindvio's evening availability.

## Costs

I do not have figures for what the inspector charges, and I will not invent them. What I can describe are the kinds of cost that come with this working relationship.

Time is the largest cost. Waiting for an evening reply means a piece may sit idle for a day or more. When the forge schedule is tight, idle time matters more than any fee. I plan for it rather than fight it.

Preparation is the second cost. Cleaning, labeling and gathering records take real effort, often an hour or two for a single piece. That effort is not wasted, since it also improves my own work, but it is still time I have to find.

Rework is the third cost. When a finding says something must be fixed, I pay with materials, heat and labor. The earlier a problem is caught, the cheaper the fix. That is the strongest argument for inviting an inspection early instead of at the end.

Attention is the fourth cost. Every exchange needs careful reading and a careful reply. I try not to let that pile up by handling each message the same evening.

There is also a quiet cost in not asking. If I skip an inspection to save time, I may pay later when a flaw shows up in use. I have learned to count that as the most expensive option.

Because I keep no price figures here, any question about fees goes by email to Polgindvio, and I record the answer in my own notes when it arrives, using whatever form it was given.

## Overview

Polgindvio Piostund is an inspector working in the forge area. I have known them since 2025. Contact is by email, and they are available in the evenings. The contract date is 2021-12-14.

In short, this is a reliable and plainspoken inspector. The working pattern is simple: I prepare carefully, write a clear message, wait for the evening and read the answer calmly. Findings arrive in writing, and I keep them.

What I value most:

- Honest findings, stated without drama.
- Consistent availability in the evenings.
- Willingness to explain when I ask.
- Respect for the standard, even when it is inconvenient.

What I try to give in return:

- Prepared pieces and complete records.
- Short, specific messages.
- Patience with the evening schedule.
- Prompt thanks and no pressure to bend the standard.

If someone else had to take over my dealings with Polgindvio, the three things I would tell them are these: use email, do not expect daytime replies, and arrive prepared. Everything else follows from those.

## Tools

The tools I use around this relationship are modest.

- Email: the only contact channel, so I keep the thread tidy and searchable.
- A notes app: this log lives here, along with the findings folder and my checklist.
- A calendar: I mark the evenings when I send messages and the evenings when I expect replies, so I do not lose track.
- A camera: photographs of the piece before inspection help me describe a problem and let me compare before and after a fix.
- A labeling kit: tags and a marker, so every piece is identified at a glance.
- A plain notebook at the forge: for quick observations that I later copy into the log.

For the forge itself, I keep my measuring tools clean and checked, since an inspector will compare my claims to the real state of the work. I also keep a clean cloth and good light at the inspection spot, because poor light hides defects and creates arguments that do not need to happen.

I avoid adding tools for their own sake. The email thread and the findings folder do most of the work. Anything that does not clearly save time or reduce mistakes stays out.

One small tool worth naming: a template for my first message. It has the piece, the step, the question and the deadline in that order. Using it keeps my messages short and keeps replies fast.

## Open questions

- Has anything in the contract changed since 2021-12-14? I have no record of changes and should ask.
- Does Polgindvio prefer photos in the first message or only on request?
- Is there a preferred length or format for written findings that would make them easier for both of us?
- Are there evenings that are better than others, or is the availability even across the week?
- What is the best way to flag something urgent when the only channel is email and the only window is evening?
- Does the inspector's scope include tool condition and floor state, or only the finished work?
- How long does Polgindvio usually keep records on their side, in case mine are lost?
- Would a short standing agenda for each exchange help, or would it feel too formal?

I will gather answers one at a time, by email, and move each answered question out of this list and into the right section above. I do not want to send all of them at once, since that would break my own rule about one purpose per message.

## History

2021: The contract date is 2021-12-14. This is the earliest point in the record and comes before my own involvement.

2025: I came to know Polgindvio Piostund. The first contact came when a batch of my work needed another look. The initial exchange was by email and the reply arrived in the evening, which set the pattern that has held ever since.

Early on, I learned that the evening window was real and not a polite figure of speech. I also learned that a clear, short message gets a clear, short answer.

Over the months that followed, I built the habits described in this log: preparing pieces properly, numbering questions, saving every finding and waiting a day before answering a hard one. The relationship became steady, and the inspections became more useful because I came to them better prepared.

More recently, I began keeping this log as a single place for what I have learned. The aim is to avoid repeating old mistakes and to make it easy for someone else to pick up the thread.

Going forward, I expect the pattern to stay the same. The inspector is still in the forge area, email is still the channel, and evenings are still the time. I will update this history when something meaningful changes, and I will keep each entry brief and factual.
