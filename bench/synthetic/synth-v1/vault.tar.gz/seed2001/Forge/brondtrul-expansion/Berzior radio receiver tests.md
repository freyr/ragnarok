---
type: research
status: active
project: brondtrul-expansion
area: forge
description: "Research about Berzior radio receiver."
---

# Berzior radio receiver tests

## Lessons

The Berzior radio receiver is a black radio receiver that sits in the greenhouse. It belongs to the forge area in my notes, even though it lives far from the forge itself. It was installed in 2020, and it runs on a battery. Those facts shape almost everything I have learned from testing it, so I list them here first and keep coming back to them.

The first lesson is that the greenhouse is a hard place for a radio. The air is damp in the morning and hot by afternoon. The black case soaks up sun and gets warm to the touch on bright days. Early on I blamed weak reception for crackling and drop-outs. Later I saw that the worst moments matched the hottest hours, and that moving the unit a short distance into shade made the sound steadier. So heat is a bigger factor than signal strength here.

The second lesson is that battery power changes how I must test. With mains power I could leave a receiver running for days and not think about it. With the Berzior I have to track how long a charge lasts, because a tired battery causes odd symptoms: quiet output, stations that drift, and sudden silence. I now treat any strange behavior as a battery question first. Only when a fresh battery gives the same fault do I look elsewhere.

The third lesson is about patience. A receiver installed in 2020 has been through several seasons of greenhouse life. Some faults I saw at first were wear, not defects. A scratchy volume control, a loose antenna connector, and a slightly sticky tuning knob were all signs of age and moisture. None of them meant the design was bad. They meant the unit needed regular care.

The fourth lesson is that a written log beats memory. In the first weeks I trusted myself to remember when a fault happened. I did not. Now every test gets a short entry: what I did, what the weather was like, how the battery felt, and what I heard. After a month the log showed patterns I could never have seen otherwise, such as faults that cluster after watering days, when the humidity peaks.

The fifth lesson is to change one thing at a time. Early tests mixed a new antenna position with a new battery and a different station. When the sound improved I could not say why. Now I change a single variable, listen for a while, and write down the result before touching anything else. It is slower, but the conclusions hold up.

## Maintenance

Maintenance on this receiver is mostly about moisture, heat and the battery. I keep the routine simple so I actually follow it.

Each week I wipe the black case with a dry cloth and check for condensation near the speaker grille and the tuning knob. If I see droplets, I leave the unit in a dry room for a day before testing again. I never wipe it with a wet cloth.

I check the battery contacts every two weeks. Greenhouse air makes metal contacts dull and sometimes leaves a faint film. I clean them gently with a dry swab and look for any green or white residue. If I find residue, I remove the battery, clean the area, and let it dry fully before putting a battery back.

I inspect the antenna connection monthly. A loose connector was my most common fault in the first year of testing. I press it in, check that it sits firmly, and run a short listening test to confirm the sound did not change.

Every season I do a longer check. I open the battery compartment, look for corrosion, confirm that the case still closes properly, and look at the cable and mounting. I also test the controls by turning each one through its full range and listening for scratches. Any scratch gets noted in the log, because a fault that appears once and then repeats is worth acting on.

Between uses I take out the battery if I will not touch the receiver for more than a few weeks. A battery left in a hot greenhouse for a long time ages fast and might leak. I store spare batteries in the house, not in the greenhouse.

## Software

The receiver has firmware, and the version I have recorded is v1.38.617. I wrote this down after the last check and I compare it each time I test, so I notice if anything changes without my knowing.

I do not update firmware casually. My rule is to test the receiver for a full week on the current version before and after any change, so I can tell whether a difference comes from software or from the greenhouse conditions. Because the unit runs on a battery, I only attempt any software task with a freshly charged or new battery. A power loss in the middle of a change would be a real risk.

Settings I keep an eye on include the stored station presets, the volume level at start-up, and any power-saving behavior. I have noticed that the power-saving behavior affects how long a battery lasts, so I record it in the log together with the battery results. When a preset drifts or vanishes, I write down the date, the weather, and the battery state, then restore the preset by hand.

I keep a plain text file beside my notes with the firmware version, the presets and the settings as I last left them. If I ever need to reset the unit, I can rebuild everything from that file in a few minutes. Keeping that record has saved me more than once.

## Tools

The tools I use for these tests are ordinary and cheap. I like it that way, since I want to repeat the tests without any special setup.

- A dry soft cloth and a dry cotton swab for the case and the battery contacts.
- A small screwdriver set for the battery compartment and the mounting, used only when the battery is out.
- A basic multimeter to check battery voltage before and after a test session. It tells me whether a fault is really about power.
- A notebook and pencil kept in the greenhouse for quick entries, which I copy into my notes later.
- A simple thermometer and humidity gauge placed next to the receiver, so I can link faults to conditions.
- A timer, so I know exactly how long the unit has played on one battery.
- A shade cloth and a small stand to test different positions without moving the receiver far.
- A second, simple radio for comparison. If both radios struggle with a station, the cause is outside the Berzior.

I keep the tools in one box so I do not hunt for them. The multimeter and the gauge give me the most useful information for the least effort.

## Open questions

Several things are still unclear after all these tests.

- How much of the crackle comes from heat and how much from humidity? The two often rise together, so I cannot separate them yet. I would like a test day that is hot but dry, or damp but cool.
- Does the black case make the heat problem noticeably worse? A different color might stay cooler, but I do not want to change the unit. I may try a shade cover instead and compare.
- How long should one battery really last in the greenhouse? My results vary with temperature, and I do not have enough logged sessions to give a firm figure.
- Is the sticky tuning knob a cleaning problem or a sign of wear inside? So far cleaning helps only for a short time.
- Would a different antenna position solve the drift for good, or does the drift come from the receiver itself?
- Does the forge area have any real link to the receiver's performance, or is that only a label in my notes? I assigned the area by habit and have never tested whether the forge matters.

## Schedule

I follow a regular rhythm so the tests stay comparable over time.

- Daily when I am in the greenhouse: a quick listen, a glance at the case for moisture, and a short log entry if anything sounds wrong.
- Weekly: wipe the case, check the log for patterns, and note the battery condition.
- Every two weeks: clean and inspect the battery contacts and measure voltage.
- Monthly: check the antenna connection and run a longer listening test of at least an hour on one station.
- Each season: full inspection, control test, and a review of the firmware record against the version I wrote down, v1.38.617.
- Once a year: a bigger review of the whole log, with a decision on whether the receiver should stay where it is. The unit was installed in 2020, so each yearly review also asks how the greenhouse has treated it over the years.

If I miss a slot, I write that down too. Gaps in the log are information, and I do not want to guess later.

## Problems

These are the faults I have met so far, with what I did about each one.

Crackling and drop-outs in the afternoon. The cause seems to be heat. Moving the receiver into shade reduced the problem. I have not found a permanent fix.

Quiet output and drifting stations. Usually a weak battery. A fresh battery fixed it each time. I now measure voltage before blaming anything else.

Scratchy volume control. This appeared after damp weeks. Turning the control through its range several times helped for a while, but the scratch returns.

Loose antenna connector. It caused sudden loss of signal. Pressing the connector firmly and checking it each month keeps this under control.

Sticky tuning knob. Moisture is the likely cause. Wiping and drying helps briefly. I will watch whether it gets worse.

Condensation on the case. This happens on cool mornings after a warm night. I leave the unit to dry before using it, and I do not run it while it is wet.

Lost presets. This happened once or twice. I restored them by hand from my settings file.

## Risks

The main risk is battery damage. A battery in a hot greenhouse can swell or leak, and a leak could ruin the contacts or the inside of the receiver. I reduce this by removing the battery during long breaks and by inspecting the compartment often.

Moisture is the second risk. Water getting inside the black case could cause corrosion and permanent faults. I keep the unit away from watering spray and out of direct drips.

Heat is the third. Direct sun on the black case could shorten the life of the parts. Shade and good placement are my main defenses.

There is a risk in software work. A failed change to the firmware, currently v1.38.617, could leave the unit unusable, and I would have no easy way to repair it. That is why I only touch software with a good battery and after writing down the settings.

Finally, there is the risk of my own habits. If I skip the log or the checks for a few weeks, small faults can grow unnoticed. The unit is already several years old, and I should expect age to catch up with it eventually.

## Safety

Safety here is simple but worth stating clearly.

Take out the battery before opening the battery compartment or doing any cleaning inside. Do not work on the receiver with wet hands, and do not use it if the case is wet.

Handle batteries with care. If a battery looks swollen, feels hot, or smells strange, stop using it, move it away from plants and anything that burns, and dispose of it properly. Do not leave it in the greenhouse.

Wear gloves if I find leaked residue, and wash my hands afterward. Keep leaked material away from the soil and the plants.

Do not place the receiver where it could be knocked into water or where a cable could trip someone. The greenhouse floor is often wet and uneven.

Keep the black case out of long direct sun. It can get hot enough to be uncomfortable to touch, and a hot case is a sign that the battery inside is under stress too.

If something smells of burning or the case becomes very hot, remove the battery at once if it is safe to do so, and leave the unit outside the greenhouse to cool.
