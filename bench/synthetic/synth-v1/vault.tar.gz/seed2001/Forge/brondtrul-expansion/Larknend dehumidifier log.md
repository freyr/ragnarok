---
type: log
status: active
project: brondtrul-expansion
area: forge
description: "Log about Larknend dehumidifier."
---

# Larknend dehumidifier log

## References

This log covers the Larknend dehumidifier, a yellow dehumidifier that runs on battery power. It was installed in 2025 and sits in the loft, which belongs to the forge area. I keep all entries about it in this one note so I can find them quickly.

Related notes I check when something changes:

- [[Gliobrinfa dehumidifier tests]] has my earlier comparison runs on another unit. I use it to judge whether the Larknend is pulling a sensible amount of water out of the air.
- [[Rerdriork Brafaen notes]] holds general notes on damp problems in the forge buildings. The loft section is the useful part.
- [[Glurpe Rorkbostar tests]] lists the humidity readings I took before the Larknend went in. They are my baseline.
- [[Vithrel Biste]] is the person who helped me carry the unit up the loft ladder. They also know which rafters stay wet longest.
- [[Kraendnio Viodith log]] is the log for the other device in the same area. I compare the two when I plan battery swaps.

## Software

The Larknend dehumidifier has a small controller with a basic menu. It lets me set a target humidity, switch the fan speed, and turn on a low-power mode. I do not update it often, because the loft is cold and I would rather not risk a failed update halfway through.

- Firmware version: v9.41.582
- Update method: done by hand, with the unit on a full battery and brought down from the loft to the bench.
- Settings I use: target humidity set to a middle value, fan on low, low-power mode on.

Notes on behavior:

- With low-power mode on, the unit cycles off for long stretches. This saves the battery but lets the damp creep back on wet days.
- After a full discharge the unit forgets the target humidity and goes back to its default. I now check the setting every time I swap the battery.
- The display is dim in daylight. I read it with my hand shading the screen.

If the firmware ever changes, I will write the new version here and keep the old one in a line below it, so I can tell which behavior belongs to which release.

## Checklist

Because the unit runs on battery, most of the work is about power and water. I go through this list on each visit to the loft.

1. Check the battery level and swap it if it is low. If the sun has been good, I top up from the [[Zeltrelzur solar charger]].
2. Empty the water tank. It fills faster than I expect in wet weeks.
3. Confirm the target humidity is still what I set, since a drained battery resets it.
4. Wipe the yellow casing and clear dust from the air intake.
5. Look at the rafters and the floor near the unit for fresh damp spots or mold.
6. Write the readings and the tank level in a new entry below.
7. Ask [[Ganzin Birksta]] about the roof leak repair if the damp patches have grown since the last visit.

Things to remember:

- Do not leave the unit on the bare floor. Keep it on the small wooden block so the base stays dry.
- Keep the tank outlet clear of the ladder hatch, so nobody kicks it.
- If the tank is full and the battery is low at the same time, deal with the tank first. A full tank shuts the unit off anyway.

Log entries go under this list, newest on top, each with a short line on the weather, the tank level and the battery state.
