---
type: summary
status: active
project: brondtrul-expansion
area: forge
description: "Summary about Brondtrul expansion."
---

# Summary of Brondtrul expansion

Brondtrul expansion is a project with the goal of expansion, in the forge area. It started in autumn 2020, and the lead is the neighbor. This note is the running summary: where the project stands, what is finished, what is still open, and what comes next.

## Checklist

The project is past the planning stage and into the build stage. The idea has been agreed, the lead is settled, and the work is now about getting the forge side ready. Most of the groundwork is done. The open items are mostly things that depend on other people or on the weather.

Current state of the main items:

| Item | Status | Owner | Notes |
|---|---|---|---|
| Agree on the goal | Done | Me | Goal is expansion, nothing more ambitious |
| Confirm the lead | Done | Neighbor | Neighbor leads, I support |
| Clear the working space | Done | Me | Old stock moved out of the way |
| Sketch the new layout | Done | Neighbor | Rough drawing, good enough to start |
| Source the main materials | In progress | Neighbor | Waiting on a supplier reply |
| Prepare the floor and base | In progress | Me | Needs a dry spell to finish |
| Check airflow and ventilation | Open | Both | Not started yet |
| Final walkthrough | Open | Both | Only after everything above |

What is done, in plain words:

- The goal and the lead are fixed, so there is no more debate about who decides.
- The space is cleared and the first layout sketch exists.
- The go decision was made, so the work is officially running.

What is still open:

- Materials are not all in hand.
- The base work is half finished.
- Ventilation has not been looked at properly.
- Nothing has been written down about how the finished forge should be used day to day.

A small status extract I keep next to the project, so I can see the shape of it at a glance:

```yaml
project: Brondtrul expansion
goal: expansion
area: forge
start_year: 2020
season: autumn
lead: neighbor
stage: build
done:
  - goal agreed
  - lead confirmed
  - space cleared
  - layout sketched
open:
  - materials
  - floor and base
  - ventilation
  - final walkthrough
```

## Risks

The main risks are practical and small. None of them is a reason to stop, but each one can slow things down if I ignore it.

**Supplier delay.** The materials depend on one supplier who answers slowly. If the reply drags on, the base work and everything after it will sit waiting. A fallback would be to ask around locally for a second source, but I have not done that yet.

**Weather.** The floor and base work needs dry conditions. Autumn is the wrong time to count on that. A wet stretch could push the work back by a good while, and rushing it would give a poor base that I would have to redo.

**Ventilation left too late.** Airflow is the item most likely to be forgotten because it is not visible progress. If it is checked only at the end, a problem there could force changes to work that is already finished. I want it looked at before the final structure is closed in.

**Relying on one person.** The neighbor leads, which works well, but it also means the project slows down whenever the neighbor is busy. I should keep my own tasks moving so that waiting on the lead is never the only thing holding us up.

**Scope creep.** The goal is expansion and nothing else. It is easy to start adding extras once the space opens up. Any extra idea should be written down for later rather than added to this project.

How I handle these:

- Keep the supplier question at the top of the list until it is answered.
- Do the base work in the first dry window, not on a fixed date.
- Move the ventilation check earlier, ahead of the final walkthrough.
- Park every new idea in a separate list.

## Next action

The next action is NX-9672.

Everything else on the open list either waits for it or can be done alongside it. Once it is finished, I will update the checklist table, then look again at the supplier and the base work. If the next action gets blocked, I will record why in this note instead of silently moving on to something else, so the stage stays honest.

After that is done, the order I plan to follow is: finish the materials, finish the base in a dry window, check the ventilation, and only then do the final walkthrough with the neighbor.

## Decisions

The go decision date is 2020-09-10. That is the day the project was approved to start, and it is the reference point for the whole timeline. Before that date the idea was only talk. After it, the work was real, and the autumn season was chosen as the start.

Decisions made so far:

- **Go.** The project goes ahead, decided on 2020-09-10.
- **Goal stays at expansion.** No extra features are added to this project. Anything else becomes a separate idea.
- **Lead is the neighbor.** The neighbor makes the final call when we disagree. My role is to support, keep notes, and handle my own tasks.
- **Area is the forge.** All the work is limited to the forge area, and the rest of the property is left alone.
- **Layout is good enough.** The rough sketch is accepted as the working plan. I will not redraw it unless the ventilation check forces a change.

Decisions still to make:

- Whether to find a second supplier if the first one stays quiet.
- How long to wait for a dry spell before choosing another way to do the base.
- When to call the project finished and move it out of the active list.

I will add each new decision here as soon as it is made, with a short reason, so I can see later why things were done the way they were.
