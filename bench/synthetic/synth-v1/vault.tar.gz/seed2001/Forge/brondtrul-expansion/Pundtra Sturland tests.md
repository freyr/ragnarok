---
type: research
status: active
project: brondtrul-expansion
area: forge
description: "Research about Pundtra Sturland."
---

# Pundtra Sturland tests

## References

Pundtra Sturland is my neighbor, and I know them from the forge area. I have known them since 2025. The best way to reach them is in person, and they are usually available in the evenings, so I stop by after work instead of trying to call.

These notes cover the tests I asked them about. I keep this page as a short record of what was agreed and what still needs checking. Before I commit to anything, I want to confirm the scope of the work in person and write down any changes here.

- Role: neighbor
- Area: forge
- Contact: in person
- Availability: evenings
- Known since: 2025

## Quotes

The quoted price of Pundtra Sturland is 6232.29 EUR.

I should ask what this price covers and whether it changes if the tests take longer than planned. I will write the answer here after our next evening talk.
