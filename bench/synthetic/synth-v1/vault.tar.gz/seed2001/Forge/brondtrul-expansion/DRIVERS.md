---
type: drivers
status: active
project: brondtrul-expansion
area: forge
description: "Drivers about Brondtrul expansion."
---

# Drivers of Brondtrul expansion

## Overview

Brondtrul expansion is a project in the forge area. Its goal is expansion. It started in autumn 2020, and the lead is the neighbor. This note collects the drivers: why the project exists, what limits it, how much money is set aside, and how I will know it worked.

The forge has outgrown its current layout. Work piles up on the same few benches, and anything large has to be moved out of the way before something else can start. The expansion is meant to give the forge more working room without changing how I work in it day to day. I do not want a bigger forge for its own sake. I want fewer interruptions, less shuffling of material, and a safer path between the fire, the anvil and the quench.

### Goal

The goal is expansion of the working space in the forge. In practice that means three things:

- a separate zone for heavy work, so the main floor stays clear
- a dry, ordered place for stock and finished pieces
- room to add a second work position later, without rebuilding again

### Constraints

- The neighbor leads the project, so decisions about the shared boundary and access go through them first. I should not start anything that touches that side without agreement.
- The work has to fit around the working season. Autumn was the original start, and I still prefer to avoid cold-weather jobs that need long curing or open walls.
- The existing fire and chimney stay where they are. Any new layout has to work around them.
- Ventilation must not get worse. If anything, it has to improve.
- Materials should be things I can get locally, so a delay at one supplier does not stop everything.

### How success is measured

I will call the project a success if these hold after a few months of regular use:

- Heavy pieces can be worked without moving other jobs aside.
- Stock is stored off the floor and I can find any item without digging.
- Walking from the fire to the anvil to the quench never crosses a storage area.
- The total spend stays inside the budget below.
- The neighbor and I both consider the shared boundary settled.

The earlier trials in [[Kenzur loft tests]] informed some of these points, especially the ones about storage height and airflow. I treat those results as a starting point, not as final proof.

## Budget

The budget of Brondtrul expansion is 25778.20 EUR.

This is the ceiling for the whole project, not a target to reach. I want to keep it as one figure and not split it too early, because the split depends on decisions that are still open. Roughly, I expect the money to go into these groups:

- structure and shelter: the largest group, since it covers the new heavy-work zone
- storage fittings: racks, shelves and anything that gets stock off the floor
- ventilation: improvements that I consider non-negotiable
- tools and fixtures for the new position
- a reserve for surprises, which I want to protect as much as possible

Rules I set for myself on spending:

- Nothing is bought before the neighbor has agreed to the part of the plan it affects.
- Ventilation is paid for before any extras.
- If the reserve is used up, the project pauses and I review the plan, rather than borrowing from other forge funds.
- Every purchase gets written down with a short reason, so the final review is easy.

## References

- [[Kenzur loft tests]]: notes from earlier trials that fed into the storage and airflow thinking.
- The forge area notes, for the current layout and the position of the fire and chimney.
- Any sketches of the boundary, kept with the neighbor's comments.
- Supplier lists I use for local materials.

I want to keep this list short. If a reference does not change a decision, it does not belong here.

## Ideas

- Build the heavy-work zone first and leave the second work position for later, so the early spending goes where the daily pain is.
- Use movable racks on wheels so the floor can be cleared quickly when a big job comes in.
- Add a simple roof overhang on the quench side to keep rain out and to give a little shade in summer.
- Mark the floor with paint lines for the walking route between fire, anvil and quench, so storage never creeps into it.
- Ask the neighbor whether any materials can be shared or bought together to lower costs.
- Take photos before each stage, so I can compare how the space is used afterward.
- Plan a quiet trial week before the work is final, where I use cardboard or temporary markers to test the layout.

## Open questions

- What exactly does the neighbor need from the shared boundary, and what are they willing to change?
- Which season is best for the structural work, given that the original start was autumn and the weather turns quickly?
- Is the budget enough if ventilation turns out to need a bigger change than I expect?
- Can the chimney and fire stay untouched in every version of the layout?
- Should the second work position be designed now, even if it is built later?
- How long should I observe daily use before I judge the project a success?
- Who handles the final decision if the neighbor and I disagree on a detail?
