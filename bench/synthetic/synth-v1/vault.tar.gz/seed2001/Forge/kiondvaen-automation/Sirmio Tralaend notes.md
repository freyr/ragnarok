---
type: note
status: active
project: kiondvaen-automation
area: forge
description: "Note about Sirmio Tralaend."
---

# Sirmio Tralaend notes

## Schedule

Sirmio Tralaend is my mentor in the forge area. I have known him since 2009. He is available on weekends only, so I plan everything around Saturdays and Sundays. The contact is in person. He does not answer messages in any useful way, so I do not try to sort things out by phone or by writing. If I need him, I go to the forge on a weekend.

How I plan a visit:

- Decide the week before what I want to ask or show him.
- Bring the work piece, the notes and the tools I need, so no time is lost.
- Arrive early on the day. He likes to start while the fire is still fresh.
- Keep the visit to a morning or an afternoon. A full weekend day is too much for both of us.
- Write down what he said the same evening, before I forget the details.

If a weekend is missed, I do not try to squeeze in a weekday. I wait for the next one and use the time to practice what he showed me last. That has worked better than rushing.

Things I want to cover with him over the coming weekends:

- The next step in the [[Restiothve Lorkbran plan]].
- A review of how I handle heat and timing on longer jobs.
- Questions that came up while working through the [[Rinraes level sensor notes]].

## Costs

Sirmio does not charge me a fee for mentoring. That has been the arrangement since the early years, and I want to keep it fair. What I do pay for is the practical side of the visits.

Typical costs to keep in mind:

- Materials I use during a session. I buy these myself and do not expect him to supply them.
- Fuel and consumables for the forge on days when I use his equipment. I try to bring some or pay him back in kind.
- Travel to get there. Because contact is in person, travel is the main recurring cost.
- A small thank-you now and then, such as food or a tool he has mentioned wanting.

Rules I set for myself:

1. Never ask him to buy anything on my behalf.
2. Always offer to cover what I use up.
3. Keep a short list of what I spent per visit, so I see the pattern over a season.
4. If he recommends a larger purchase, wait a week before deciding.

When something bigger is needed, he gives a price, and I record it in the Quotes section below. I do not commit before comparing it against what I can do myself. For small parts, I check whether the work from the [[Berzior radio receiver tests]] already gave me something reusable.

## History

I met Sirmio Tralaend in 2009. At the time I was just starting out and had more enthusiasm than skill. He was patient with me, and that has not changed.

How the relationship developed:

- **Early years:** He taught me the basics of the forge: how to read the fire, how to hold the work and how not to hurry. Most of what I did then was repetition.
- **Middle years:** He started giving me small problems to solve myself. He would watch and say very little, then point out one thing at the end.
- **Recent years:** We talk more like colleagues. I bring him projects and he tells me where the weak points are.

Some lessons that stayed with me:

- Slow work is usually faster in the end.
- Clean the workspace before starting, not after.
- Test on scrap before touching the real piece.
- Write down what went wrong, because the same mistake comes back otherwise.

I have also learned that he prefers a direct question to a long explanation. If I show up with a clear problem, we get further in an hour than in a whole day of vague discussion.

Links to my own related work: the [[Restiothve Lorkbran plan]] came out of one of his suggestions, and the [[Rinraes level sensor notes]] contain the follow-up to a problem we talked through at the forge. The [[Berzior radio receiver tests]] are a side project, but he asked to see the results anyway.

## Quotes

Here I keep what Sirmio has quoted me for work or materials, and some of the things he says that I want to remember.

Price:

- Quoted price of Sirmio Tralaend: 5552.26 EUR

I treat this figure as the quoted amount and not as a final commitment. Before accepting, I check what it covers, how long the work takes and what I would need to supply myself. I also ask what happens if the job grows.

Things he says that I try to keep in mind:

- "Look at the fire, not at the clock."
- "If you are unsure, stop and ask."
- "A good tool is a tool you know how to fix."
- "Do it slowly once, then do it well a hundred times."

I write down the quote and the date of the conversation in my own log, and I check it again at the next weekend visit. That way there is no confusion about what was agreed.

## Safety

The forge is a place where small mistakes become injuries. Sirmio is strict about this, and I follow his rules even when I think I know better.

Basic rules:

- Wear eye protection, gloves and closed leather footwear at all times.
- Tie back long hair and avoid loose sleeves or hanging cords.
- Keep the floor clear. Trips near a hot fire are the worst kind.
- Know where the water, the extinguisher and the first aid kit are before starting.
- Never work tired. If I am rushed or distracted, I skip the session.
- Let hot pieces cool in the marked area and never leave them where someone might pick them up.

Ventilation matters too. Fumes can build up quickly in a closed room, so doors and vents stay open during work. If I feel dizzy or get a headache, I stop and go outside.

For electrical or sensor work done alongside the forge, such as what I describe in the [[Rinraes level sensor notes]], I keep it away from heat, sparks and water. Electronics testing, like the [[Berzior radio receiver tests]], is done at a separate bench and never next to the fire.

If someone gets hurt, the first step is to stop work and make the area safe. Then deal with the injury, and tell Sirmio afterwards so we can review what happened.

## References

- [[Restiothve Lorkbran plan]]: the project plan that grew out of my work with Sirmio.
- [[Berzior radio receiver tests]]: test notes from a side project he took an interest in.
- [[Rinraes level sensor notes]]: notes on a sensor problem we discussed at the forge.

Summary of the person:

- Name: Sirmio Tralaend
- Role: mentor
- Area: forge
- Contact: in person
- Availability: weekends
- Known since: 2009
