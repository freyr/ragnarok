---
type: summary
status: active
project: kiondvaen-automation
area: forge
description: "Summary about Kiondvaen automation."
---

# Summary of Kiondvaen automation

## Supplies

Kiondvaen automation is a project with the goal of automation, in the area of forge. It started in spring 2022, and the lead is mentor. This note is the running summary: where the project stands, what is done, what is still open, and what comes next.

The project is at the build-out stage. The idea has been proven, and the work now is mostly gathering what is needed to make the automation run without me standing at the forge all day.

What I have on hand or have settled:

- The basic layout of the automated line, worked out on paper and then walked through in the space itself.
- The tools and fixtures that the early trials showed I could not do without.
- Notes from [[Kenzur loft tests]], which taught me how the setup behaves when the room is dry and warm, and what to avoid when it is not.
- Notes from [[Ristisbras pond study]], which gave me a good picture of how water use and cooling should be planned.
- A cleared working spot at [[Raeserk yard]], where the main equipment will sit once it is assembled.

What is still missing or open:

- A final choice on how the cooling loop will be routed so it stays clear of the working area.
- A tidy way to store the spare fittings so they do not wander off between sessions.
- A written routine for shutting everything down safely at the end of a day.
- Agreement with the mentor on how much of the process should stay manual for now.

## Next action

The next action is NX-4950. I want to do it before anything else, because the open points about cooling and shutdown depend on what it shows me. Once it is finished I will write up the result here in a few lines and then decide which open point to take on next.

Until then I am keeping the rest of the work small: sorting the fittings, tidying the notes from the earlier tests, and making a short list of questions for the mentor. None of this should change the plan, but it should make the next working session easier to start.

## Decisions

The go decision for Kiondvaen automation was made on 2023-10-22. That was the point where I stopped treating the project as an experiment and committed to building it properly. The reasons were simple: the tests in the loft were encouraging, the pond study showed that the water side could be handled, and the yard offered enough room to work.

Other decisions so far:

- Keep the mentor as lead. Their experience with the forge saves me from repeating mistakes, and they have the final say on safety questions.
- Build in small steps, testing each part before adding the next, rather than assembling everything at once.
- Keep a manual fallback for every automated step, at least until the shutdown routine is written and tried.
- Record every change in this project's notes, so that later me can see why something was done the way it was.

Decisions still waiting: the cooling route, the storage method for fittings, and how far to push automation in the first full version. I will log each one here when it is settled.
