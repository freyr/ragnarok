---
type: note
status: active
project: kiondvaen-automation
area: forge
---

# Giore level sensor notes

## Observations

The Giore level sensor is a black level sensor that has been in the greenhouse since 2024. It runs on mains power, so it has no battery to worry about, and it has been on almost without a break since I installed it. The forge area is where I file it in my notes, even though the unit itself sits in the greenhouse. That is a quirk of how I sort things, and I keep it that way so all the gear I care about for the forge lives in one place.

What I notice most is how steady it is. The reading does not jump around when I walk past or open the door. Compared with the older sensors I have tried, it settles quickly after a change and then stays put. The black housing absorbs a lot of sun on bright afternoons, and the case gets warm to the touch. So far that has not changed the readings in any way I can see, but I keep watching for it.

Things I have seen over time:

- The reading drifts slightly when the greenhouse gets very humid in the morning.
- Condensation forms on the lower edge of the case after cold nights.
- The mains lead stays dry as long as I keep the drip loop I made.
- Dust gathers on the top face faster than I expected.
- After a power cut it comes back on its own without any button presses.

I compare it in my head with the [[Paethvol level sensor]], which was louder in its behaviour and needed more attention. The Giore is calmer, and that is why I keep trusting it. When I want a second opinion on a reading, I look at what I wrote in [[Rinraes level sensor notes]], because that sensor covers a similar job and the two rarely disagree by much.

## Measurements

The only hard figure I keep for this device is its flow rate: 1347.07 l/h. I noted it once while the system was running normally and have not seen a reason to change it. It is a working figure, not a lab result, so I treat it as a sensible baseline and not a guarantee.

Other things I record are less exact but still useful:

- Kind: level sensor.
- Colour: black.
- Energy source: mains.
- Year installed: 2024.
- Location: greenhouse.

When I check the sensor, I do it in the same order each time. First I look at the reading with nothing disturbed. Then I compare it against a quick manual check of the level. If the two agree closely, I leave everything alone. If they disagree, I wipe the face of the sensor, wait a while, and look again before I touch any settings.

I do not keep a long table of numbers, because it never helped me. What helps is the habit of comparing the sensor with my own eyes. The flow rate stays as the one reference figure, and anything that seems far from it makes me look for a blocked line or a dirty face before I blame the electronics.

For weighing small amounts of additives I use the notes in [[Lilmurk scale notes]], which keep that work separate from the sensor readings. I do not mix the two, so a mistake in one does not hide a mistake in the other.

## Schedule

I run the sensor on a loose routine, not a strict calendar. Because it is on mains power, there is no battery date to remember, and that removes the biggest source of forgotten chores.

My routine looks like this:

- Every few days: a quick look at the reading and a glance at the case for condensation.
- Weekly: wipe the face and check that the mains lead has not shifted.
- Monthly: compare the reading against a manual check and note any gap.
- Each season: look over the mounting and the cable route, and clean thoroughly.

In summer I check more often, because heat and humidity are both higher in the greenhouse and the case sees more stress. In winter the checks are lighter, but I watch for condensation after cold nights. I do not write down exact dates for these checks. If I notice that a check was skipped, I do it at the next convenient moment and carry on.

The schedule is tied to my other routines. When I look in on the [[Zerklael dehumidifier]], I also glance at the sensor, since the two share the same space and a change in one often shows up in the other. That habit alone catches most problems early, and it costs me almost no extra effort.

## Background

I installed the Giore level sensor in 2024. I wanted something that did not depend on batteries, since the greenhouse is a place where I tend to forget small chores. Mains power looked like the practical answer, and the greenhouse already had a socket close to where the sensor needed to go.

The sensor is black, which I chose partly by accident and partly because it blends into the corner where it sits. It is a level sensor by kind, and it belongs to the forge area in my filing, because the forge notes are where I collect equipment that supports my bigger projects. That filing choice is not about physical location. The device really lives in the greenhouse.

Before this one I used the [[Paethvol level sensor]], and I wrote down what I learned from that in other notes. The main lesson was that a sensor which needs frequent fiddling stops being useful, because I stop checking it. The Giore replaced it because it asked less of me.

For a sense of how I think about equipment in general, some older notes live in [[Treda Kaeson notes]], which cover the way I keep records and decide what is worth writing down. [[Brasmaen Pasviond]] is the name I use for the wider set of notes this belongs to, and I go back to it when I want context on why I set things up the way I did. None of that is essential to running the sensor, but it explains the habits behind the setup.

## Risks

The main risks are modest, but I list them so I do not forget them.

- Moisture: the greenhouse is damp, and mains equipment does not mix well with water. The drip loop in the lead and the position of the plug matter a great deal.
- Heat: the black case warms in direct sun. If it ever gets too hot to hold comfortably, I will move it or shade it.
- Power loss: a cut means no readings for the duration. The sensor recovers by itself, but I would not know the level during that time.
- Dust and residue: a dirty face may give a slightly wrong reading, and it builds up slowly enough that I could miss it.
- Cable damage: a mains lead in a greenhouse can be nicked by tools or chewed by pests, so I check it by eye.

None of these has caused a real problem so far. The one I take most seriously is moisture, because it combines mains power with a humid space. I keep the plug off the floor and away from anywhere water could pool, and I do not run the lead where I walk.

A second-order risk is trust. Because the sensor is so steady, I could stop checking it against reality. The manual comparison on my monthly routine is there to prevent that. If the sensor ever drifts quietly, that comparison is the only thing that would catch it.

## Open questions

There are a few things I have not settled.

- Does the warmth of the black case ever shift the reading on the hottest days? I have not seen it, but I have also not tested it carefully.
- Would a lighter-coloured cover reduce heat without hurting the signal?
- Is the flow rate of 1347.07 l/h really constant, or does it move a little with the season? I have only noted it once.
- Should I add a simple backup reading for the times when the power fails?
- Is the humid-morning drift real, or am I imagining a pattern?

I would like to answer the flow rate question first, because it is the one number I rely on. To do that I would have to take several readings under different conditions and compare them, and I have not yet found the patience for it. For now I treat the figure as a baseline and move on.

Another open point is whether to move the device closer to the [[Zerklael dehumidifier]] for easier checking, or keep it where it is. Moving it would save steps but might put it in a damper spot, and that cancels out the benefit.

## Tools

I do not need much to look after this sensor. The tools I use are plain and cheap.

- A soft dry cloth for wiping the face and case.
- A small brush for dust in the seams.
- A torch for checking the lead and the underside in poor light.
- A notebook, or this note, for writing down what I see.
- A basic mains tester for the socket, used only when something seems off.

For the manual check of the level I use whatever is at hand in the greenhouse, and I keep the method the same every time so that the comparison means something. When I need to weigh something small, I turn to the setup described in [[Lilmurk scale notes]], and I keep that gear apart from the sensor tools.

I avoid solvents and harsh cleaners on the black case, since I do not know how it would react and the finish is easy to dull. Water on a cloth, wrung out well, is enough. I never spray anything near the plug or the lead. If the socket needs checking, I switch it off first and only then handle anything.

## Setup

The sensor sits in the greenhouse, mounted so that its face is clear and the case is out of direct splashes. It is a black level sensor on mains power, installed in 2024. The mains lead runs to a nearby socket, and I made a drip loop so that water running down the cable drips off before it reaches the plug.

I chose the position with a few things in mind. It had to be near the socket so the lead stays short. It had to be reachable without bending awkwardly, since I check it often. And it had to be away from the spots where I water, so that spray does not land on it.

The steps I followed were simple:

- Pick a spot close to the socket and out of the main spray zone.
- Fix the mounting firmly so the sensor does not shift.
- Route the lead along a wall, away from foot traffic.
- Form the drip loop before the plug.
- Switch on, wait for the reading to settle, and compare against a manual check.

After the first day I checked the reading again, and then again a few days later. It matched the manual check well enough that I left it. The notes in [[Rinraes level sensor notes]] helped me decide what a good match looks like, since that sensor does a similar job.

## Maintenance

Maintenance is light, which is the whole point of this unit. It has no battery to swap, so the work is mostly cleaning and looking.

Each time I wipe the face I also look at the case for cracks, the lead for nicks, and the plug for any sign of moisture. If anything looks wrong, I switch the socket off before touching it. A dirty face is the most common cause of a slightly odd reading, so cleaning comes first when something seems off, and only after that do I consider anything more involved.

My usual maintenance list:

- Wipe the face and case with a damp, well-wrung cloth.
- Brush dust out of seams and from around the mount.
- Check the drip loop is still in place and the lead is dry.
- Look at the mount for any loosening.
- Compare the reading against a manual check and note the result.

I keep a short log of what I find, nothing elaborate. A line or two is enough to show whether a problem is new or has been creeping along. If the readings start disagreeing with the manual check more than once in a row, I treat that as a sign to look deeper, and I reread the sections above on risks and open questions to remind myself what might be going on.

For the bigger picture of how I record upkeep for all my gear, I look at [[Treda Kaeson notes]]. Keeping the same simple habits across devices is what lets me maintain them all without much effort.
