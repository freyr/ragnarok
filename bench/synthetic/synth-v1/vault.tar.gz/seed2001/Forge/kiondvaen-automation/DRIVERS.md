---
type: drivers
status: active
project: kiondvaen-automation
area: forge
description: "Drivers about Kiondvaen automation."
---

# Drivers of Kiondvaen automation

## Costs

Kiondvaen automation is a project in the forge area, started in spring 2022, with the goal of automation. The lead is the mentor. This note collects the drivers: what pushes the project, what limits it, what it costs and how I decide it worked.

The costs fall into three groups. The first is parts and materials: sensors, relays, wiring, enclosures, and small fittings. The second is tooling I had to buy or borrow so I could build and test the pieces. The third is my own time, which I do not price in euros but do count in hours, because it was the real limit in most weeks.

Costs I track:

- Sensors and switches for the forge floor, which take the most abuse and get replaced most often.
- Wiring, connectors and heat-resistant sleeving. Cheap sleeving failed early, so I stopped trying to save there.
- Enclosures that keep dust and scale out of the electronics.
- Replacement stock for anything that sits near the fire.

The hidden cost is rework. Twice I built something that worked on the bench and failed in the forge, and both times the lesson was to test in the real heat before committing to a final layout.

## Budget

The budget of Kiondvaen automation is 3249.12 EUR. That figure covers parts, enclosures, wiring and the tools bought specifically for this project. It does not cover the building itself or anything I already owned.

I split the money loosely into thirds: about a third for sensing, a third for control and wiring, and a third held back for failures and changes. The held-back portion has been used more than I expected, and I treat it as a normal part of the plan instead of an emergency fund.

Rules I follow on spending:

- Nothing over a small threshold gets bought without writing down what problem it solves.
- If a part is likely to be destroyed by heat, I buy a spare at the same time.
- Prefer parts I can get again easily over parts that are slightly better but hard to find.
- Review the running total at the end of every working session.

## Problems

The main problems so far are heat, dust and trust. Heat kills cheap electronics and warps plastic. Dust and scale get into every gap and cause intermittent faults that are hard to reproduce. Trust is the human side: the mentor, who leads this work, will not rely on an automatic system that sometimes does the wrong thing silently, so every automatic action needs a visible sign and a manual override.

Specific trouble spots:

- Level sensing in the quench and fuel areas gave false readings until I reconsidered the approach. The notes are in [[Pikios level sensor plan]].
- Cutting stock to length is slow and inconsistent by hand. The idea of automating it is in [[Kurknund band saw plan]], but the vibration is a concern for any sensor mounted nearby.
- Power supply noise from the large motors caused random resets in the controller until I separated the supplies.
- Cable routing across the floor is a trip hazard and a fire risk, so every run has to be planned.

## Ideas

Several ideas are waiting for time or money.

- A small controller that logs temperatures in the work area and warns when the air gets too hot for the electronics.
- A stop-and-start sequence for the blower, so the fire is easier to hold steady without constant attention.
- A simple counter on the saw to repeat cuts at the same length, following [[Kurknund band saw plan]].
- Reusing the layout from [[Bethtes Panvil plan]] for the anvil-side station, so the same mounts and cable paths work in both places.
- Moving part of the storage and spare-parts shelf into the [[Vindseth loft]] so that the forge floor stays clear and cooler.

I rank ideas by how much risk they remove, not by how clever they are. A feature that prevents a burn or a fire goes above one that saves a few minutes.

## Maintenance

Automation that is not maintained becomes a hazard. My routine is short enough that I actually do it.

- Weekly: wipe dust from enclosures, check connectors for looseness and look at sleeving for scorching.
- Monthly: test every override and every stop, by hand, with the system live.
- After any repair: run the full sequence once with nobody near the fire.
- Each season: replace the parts nearest to the heat, whether or not they look worn.

I keep a short log file for the controller. A typical extract looks like this:

```
session: spring check
blower relay: ok
quench level input: ok
saw stop input: ok
override switch: ok
note: sleeving near flue scorched, replace
```

The log is only useful if the notes are honest, so I write down failures even when they are embarrassing.

## Lessons

What I would tell myself at the start of 2022:

- Test in the real environment as early as possible. Bench results mean little near a fire.
- Spend on sleeving, connectors and enclosures first. They are dull, but they decide whether anything lasts.
- Keep the system simple enough that the mentor can understand it by looking at it. That matters more than features.
- Always provide a manual override and make it easy to reach.
- Hold back money for failures. The reserve is not waste, it is the plan being realistic.
- Write down why a decision was made. Months later I forget, and the reasons are more useful than the choices.

I also learned to ask [[Vithrel Biste]] for a second opinion before any change that affects safety. A fresh pair of eyes caught a wiring path that I had stopped seeing.

## Overview

Kiondvaen automation is a project with the goal of automation, in the forge area, which began in spring 2022. The mentor leads it. The point is to take over repetitive or risky tasks around the forge so that the work is safer and steadier, without removing the human judgment that makes the craft work.

Goal: automate the dull and dangerous parts, leave the decisions to the person at the fire.

Constraints:

- A fixed budget of 3249.12 EUR.
- Heat, dust and vibration in the working area.
- Limited time, since the project competes with actual forge work.
- A requirement from the lead that everything can be overridden by hand.

How I measure success, in practice:

- Fewer manual repeats of the same task in a normal session.
- No unexplained stops or resets over a full season.
- No safety incident that the system caused or failed to prevent.
- Spending that stays inside the budget without raiding the reserve more than once a year.
- The mentor is willing to leave a system running while working nearby.

If those hold, the project has done its job. If only the spending holds, it has not.

## Tools

The tools I use are modest.

- A basic multimeter for checking continuity and supply levels.
- A soldering iron and crimping tool for wiring and connectors.
- A small programmable controller board, with a laptop to load and test code.
- Heat-resistant sleeving, ties and mounting brackets.
- A notebook next to the forge for quick observations before they go into the log.

For planning, the related notes are [[Pikios level sensor plan]], [[Kurknund band saw plan]] and [[Bethtes Panvil plan]]. For storage of spare parts and drawings I use the [[Vindseth loft]]. For safety review and second opinions I go to [[Vithrel Biste]]. I prefer fewer tools that I know well over a large kit I only half understand.
