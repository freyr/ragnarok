---
type: plan
status: active
project: kiondvaen-automation
area: forge
description: "Plan about Restiothve Lorkbran."
---

# Restiothve Lorkbran plan

## Background

Restiothve Lorkbran is an inspector who works in the forge area. I have known Restiothve since 2025. The best way to reach Restiothve is email, and Restiothve is available on weekdays, so I plan my requests around the working week and do not expect answers at weekends.

The reason I keep this plan is simple: inspections at the forge decide whether a batch of work goes out or comes back for more work. If I do not know who is checking it, when that person can be reached and how to ask, I lose days. This note collects what I know so that I can prepare before I write.

What I want from Restiothve, in order of importance:

- A clear yes or no on each piece of finished work, with the reason written down.
- Notice before an inspection happens, so the work is ready and the area is clear.
- A short written list of anything that needs to be fixed, so I do not have to guess.

Earlier inspection notes are in [[Lasnur Zazond log]]. I read that log before I write to Restiothve, because it shows which questions have already been answered and which are still open. It saves me asking twice.

## Contracts

The contract date of Restiothve Lorkbran is 2019-02-22. That is the date on the agreement that covers the inspection work, and it is older than my own contact with Restiothve, which only began in 2025. So the terms were set well before I arrived, and I am working inside them rather than shaping them.

What I need to keep in mind about the contract:

- The inspection role belongs to Restiothve. I should not ask for a favour that changes a result.
- Requests go through email, so there is always a written record of what was asked and what was answered.
- Because availability is weekdays only, any deadline that falls on a weekend should be moved to the Friday before it.

My plan is to reread the contract terms before each new batch goes to inspection. I want to confirm that the scope still matches the work I am sending, and to note any change in writing. If the scope has drifted, I would rather raise it early by email than discover it at the moment of rejection.

I also want to keep a short running list of what the contract covers and what it does not, so I can answer quickly when someone asks whether a piece of work falls under inspection. For now that list lives in my head, which is not good enough, so moving it into this note is a task for the next review.

## Problems

The main problem is timing. Restiothve is only available on weekdays, so anything I finish late in the week can sit untouched until the following Monday. That has already cost me time more than once, and the delay is hard to recover once it starts.

A second problem is that email alone can be slow when something is urgent. A short question can take a full day to settle, and a longer one can turn into a thread that nobody wants to follow. I should write shorter messages with one question each and put the deadline in the first line.

A third problem is that my records of past inspections are incomplete. [[Lasnur Zazond log]] covers some of them, but not all, and I sometimes cannot tell whether an issue was closed or only dropped. That makes it risky to assume anything is settled.

Things I plan to do about these problems:

1. Send finished work early in the week, never on a Friday afternoon.
2. Keep each email to a single question, with the deadline stated at the top.
3. After every inspection, add a line to the log saying what was found and whether it is closed.
4. Review this plan once a month and remove anything that no longer applies.

If a problem keeps coming back after these changes, I will write down exactly what happened each time instead of working from memory. A clear record is the only thing that will let me ask Restiothve for a change in process without it sounding like a complaint.
