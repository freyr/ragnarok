---
type: plan
status: active
project: bothnuzuth-rebuild
area: forge
description: "Plan about Pikios level sensor."
---

# Pikios level sensor plan

## Overview

This note is my plan for looking after the Pikios level sensor. It is a level sensor that belongs to the forge area. The case is yellow, which makes it easy to spot against the dark water and the stones around the pond. It runs on a battery, so there is no cable to trace and no mains socket to worry about. It was installed in 2018 and its location is the pond.

The sensor tells me how high the water stands in the pond. The forge draws on that water for cooling and quenching, so a wrong reading has real consequences. If the reading is too high, I might think there is plenty of water when the pond is nearly dry. If it is too low, I might stop work for no reason. The plan below is meant to keep the readings honest with as little effort as possible.

Summary of the subject:

- Name: Pikios level sensor
- Kind: level sensor
- Area: forge
- Color: yellow
- Energy source: battery
- Year installed: 2018
- Location: pond

The goal of this plan is simple. I want to check the sensor on a regular rhythm, correct it when it drifts, and write down what I did so that I do not have to remember it later.

## History

I installed the sensor in 2018. At that time the pond was the only dependable source of water near the forge, and I wanted a way to know its level without walking down to look. The yellow body was a practical choice too, because I once lost a grey sensor in the reeds for most of an afternoon.

In the first years the sensor needed almost nothing. The battery lasted a long time and the readings matched the marks I had scratched on the old post by the bank. Over time the readings began to wander a little. Some of this came from algae and silt on the sensing end. Some came from the post settling in the soft ground. A few times the reading jumped after a storm, and I was never fully sure whether the water had really risen that much or whether the sensor had been knocked.

I replaced the battery more than once over the years, and each time I forgot to write down exactly when. That is one reason this plan exists. I would like a record that is short, dated by season, and kept in one place.

Things I remember about the past:

- The first reading after each battery change was usually a little off.
- Cold mornings made the display slow to respond.
- Algae grew fastest in late summer.
- The post by the bank moved after heavy rain.

## Lessons

The main lesson is that the sensor is only as good as its last check against something I can see. A number on a display feels authoritative, but it is just a guess until I compare it with the marks on the post. I now treat the sensor as a helper, not as the final word.

The second lesson is that cleaning matters more than I expected. A thin film on the sensing end changes the reading slowly, so I never notice it day to day. Wiping it clean at the start of each season removes most of the drift without any other work.

The third lesson is about the battery. A weak battery does not always switch the sensor off. Sometimes it just makes the readings erratic. If the numbers start to look strange, I should change the battery before I touch any settings. Otherwise I end up correcting for a fault that a fresh battery would have fixed.

The fourth lesson is to write things down at once. When I do a check, I note the date, the visible mark on the post, and what the sensor said. Three lines are enough. Without them, I cannot tell a slow drift from a sudden shift.

Short list of habits I want to keep:

- Compare the sensor with the post marks before trusting it.
- Clean the sensing end every season.
- Change the battery first when readings look odd.
- Write the check down the same day.

## Adjustment

This section covers how I correct the sensor when it no longer agrees with the post. The correction is a fixed offset, not a new scale. The calibration offset of the Pikios level sensor is 2.992 mm. I apply it so that the sensor's reading lines up with the true water height at the post mark.

The steps I follow:

- Pick a calm day with little wind, so the water surface is flat.
- Read the mark on the post at the waterline and write it down.
- Clean the sensing end and let the sensor settle for a few minutes.
- Read the sensor and write that down next to the post reading.
- Apply the calibration offset of 2.992 mm and compare again.
- If the two readings now agree, stop. If they do not, check the battery and the position of the post before changing anything else.

I do not change the offset casually. If the gap between the sensor and the post grows, I first look for a physical cause: silt, a loose mount, a leaning post, or a tired battery. Only when all of those are ruled out do I think about whether the offset itself needs to change. If I ever do change it, I will write the old value and the new value in this note with the reason.

After the adjustment I leave the sensor alone for a day and look at it again the next morning. A good adjustment holds steady overnight. A bad one drifts, and that tells me the cause is somewhere else.

## Open questions

There are several things I do not know yet, and I would like to settle them over the next year.

- How long does the battery really last? I never recorded the dates of the changes, so I only have a loose impression. I want to start a proper log.
- Does the cold affect the readings or only the speed of the display? I have seen slow responses on winter mornings, but I have not compared the numbers against the post in the same conditions.
- Is the post moving, or is the sensor? The ground by the bank is soft. A fixed reference nearer to solid ground would make my checks more trustworthy.
- Should the sensor be moved to a calmer corner of the pond? Ripples near the current location may add noise to the readings.
- Is yellow still the right color choice? It is easy to see, but sun may fade it, and a faded case is harder to find in the reeds.

I will come back to this list after the next full season of checks and strike out whatever I have answered.

## Risks

The biggest risk is trusting a wrong reading at a moment when the forge needs water. If the sensor says the pond is fuller than it is, I could start a long session and run short. To reduce this, I keep the habit of looking at the post whenever the weather has been dry for a while.

A second risk is battery failure. Because the sensor runs on a battery, it can stop with no warning, and the last number on the display may stay there and look normal. I should not assume a steady number means a healthy sensor. A reading that never changes for days is itself a warning sign.

A third risk is physical damage. The pond location exposes the sensor to storms, floating debris, frost and animals. Any of these can shift the mount or crack the case. After bad weather I should go and look at it, not just read the display.

A fourth risk is that I forget the routine. The plan only works if the checks actually happen. Putting a reminder at the start of each season, and keeping the notes short, is the best defense I have found against my own forgetfulness.

Finally, there is the risk of over-adjusting. Every time I change a setting without a clear reason, I make the history harder to read. I will adjust only after a proper comparison with the post, and I will record every change.
