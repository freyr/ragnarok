---
type: plan
status: active
project: bothnuzuth-rebuild
area: forge
description: "Plan about Brirkbur Biodio."
---

# Brirkbur Biodio plan

## Safety

Brirkbur Biodio is a plumber I have known since 2023. He works in the forge area, and the way to reach him is by phone. He is available in the evenings, so I should not expect a call back during the working day.

Before anyone starts work on the pipes, I want these basics settled:

- Shut off the main water supply and check that the taps are really dry before any joint is opened.
- Switch off the water heater and let it cool. Hot water stored in the tank can scald.
- Keep a bucket, old towels and a torch near the work area, in case the water does not drain as expected.
- If any work involves a flame or a heat gun near wooden beams, keep a fire blanket close and check the area again afterwards.
- Do not touch the gas supply myself. If a smell of gas appears, I leave the house and call for help from outside.

Because Brirkbur is only free in the evenings, work often happens in poor light. I will set up a lamp in advance so he is not working in shadow around old pipes. I also want the house to be quiet and the children out of the room while he works, since evening jobs tend to run longer than planned.

## Observations

What I have noticed about working with Brirkbur so far:

- He picks up the phone in the evening and usually answers within a day if I leave a message. Texting works less well than a direct call.
- He explains the problem before he starts, and he shows me the old part once it is removed.
- He is tidy. He lays down a cloth under the work and leaves the floor dry.
- He does not like to guess. If he cannot see the cause of a leak, he says so and asks to come back in daylight.
- He prefers to be told exactly where the trouble is, so I should write down the symptoms beforehand: which tap, how long the drip has lasted, and what the pressure feels like.

The forge area is not far, so travel is rarely a problem. The main limit is his time. Evenings fill up quickly in the cold months, when many people have frozen pipes, so I should ask early rather than wait for a small fault to grow.

## Background

I first met Brirkbur in 2023, when a neighbour recommended him after a slow leak under my kitchen sink. He came one evening, found a worn seal in a few minutes, and fixed it without fuss. Since then he has become the person I call first for anything to do with water.

His trade is plumbing, and his base is the forge area. He works mostly alone, and I have never seen him bring an assistant. Phone is the contact method that works, and evenings are his available time. I have not tried to arrange daytime visits and do not expect them to work.

Over the years I have kept rough notes on what he has done for me: the sink seal, a dripping outdoor tap, and a check of the radiator valves before winter. None of these were large jobs, but each one went as he described beforehand. That consistency is the main reason I trust him with a bigger task now.

The plan in this note is meant to gather what I know about how to work with him, so that the next job runs smoothly and I do not forget the small things that make a visit easier.

## Lessons

Some lessons from earlier visits:

- Ask for a call in the evening rather than hoping for a quick reply during the day.
- Clear the space under sinks and around the boiler before he arrives. Time spent moving boxes is time he cannot spend fixing.
- Keep the old parts he removes until I am sure the repair has held. Twice a part helped explain a problem later.
- Agree on the scope of the job before he starts. A short spoken summary at the door avoids confusion about what is included.
- Ask what to watch for after he leaves, such as a damp patch or a change in pressure, and check it the next morning.
- Do not leave winter preparation until the first frost. A call in autumn is easier for both of us.

One thing I would do differently: I should write the agreed plan down immediately after the call. Twice I remembered the details slightly wrong, and a written line would have prevented that.

## Contracts

I want a clear arrangement with Brirkbur for the larger work, not just a handshake over the phone. The contract date of Brirkbur Biodio is 2026-06-20. That is the date the arrangement was set, and I should refer back to it if there is any question about what was agreed.

What the arrangement should cover, as I understand it:

- The work to be done, described in plain words, including which rooms and which fittings are involved.
- The evenings on which he can come, since that is his availability, and a fallback if a visit has to be moved.
- How I will reach him: by phone, in the evening.
- What happens if he finds a problem beyond the agreed scope, so that neither of us is surprised.
- How and when I pay, once I have agreed the amount with him directly.

I will keep a copy of the arrangement with my household papers and a short summary here in the vault. Before each visit I will reread the summary and check the safety list above. If something changes, I will note it next to the contract date so the history stays in one place.
