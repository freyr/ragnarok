---
type: drivers
status: active
project: bothnuzuth-rebuild
area: forge
---

# Drivers of Bothnuzuth rebuild

## Schedule

The Bothnuzuth rebuild is a project in the forge area. Its goal is a rebuild, and the lead is the mentor. The project started in 2026, in the summer season. These are the drivers I keep coming back to when I decide what to do next, so I write them down here and check them before I change the plan.

The main driver of the schedule is the season. Summer gives me long daylight, dry air and open doors, which matters for a forge because the heat inside is already heavy. Work done in the cooler part of the day goes faster and with fewer mistakes. I plan the heavy jobs for the early morning and keep the afternoon for lighter tasks such as measuring, sorting and cleaning.

The second driver is the mentor. Since the mentor leads the project, the order of work follows the mentor's availability. Steps that need a second pair of experienced eyes are grouped into a few visits instead of being spread thin. Between visits I do the jobs that I can do alone and that are easy to undo if the mentor disagrees.

The third driver is the order of the rebuild itself. Demolition and clearing come first, then the structural parts, then the working surfaces, then the finishing. I do not start a later stage until the earlier one is checked, because a rebuild punishes shortcuts: a crooked base shows up in everything built on top of it.

Constraints on time:

- The project belongs to the summer season of 2026, so slipping past it means working in colder, wetter conditions.
- Mentor visits are the bottleneck, so I prepare questions in advance.
- Nothing is lit until the mentor has seen the finished layout.

## Budget

The budget of Bothnuzuth rebuild is 22082.54 EUR. This is the ceiling I hold myself to, not a target to reach.

I think about the money in a few groups. Structure and masonry take the biggest share, since a rebuild of a forge depends on solid foundations and heat-resistant materials. Equipment and fittings come second. Consumables, small materials and the things I forget take the rest, and I keep some of that as a reserve because surprises always turn up once old work is opened.

Rules I follow for spending:

- Buy the parts that affect safety first, and do not economise on them.
- Compare at least two sources before any larger purchase.
- Prefer used equipment when the condition is easy to judge, and new when it is not.
- Write every purchase down on the day it happens, with what it was for.
- If a single decision would use a large part of the reserve, talk to the mentor before paying.

The budget is also a driver of scope. When money gets tight, I cut finishing touches before I cut anything structural, and I move optional upgrades to a later project.

## Lessons

Past forge work has taught me a few things that shape this rebuild.

- Measure twice and write the numbers down. Memory of a measurement is unreliable after a long day.
- Old structures hide problems. Expect cracks, rot or weak spots behind anything that looks fine, and leave room in both time and money for them.
- Heat changes everything. Materials that look right when cold may behave differently under use, so I test in small steps.
- The mentor's advice is cheaper than a mistake. Asking early has saved me more than any tool.
- Tidy work areas make fewer accidents. Clearing as I go is part of the job, not a break from it.
- Do not rush curing or drying. Waiting is a task, and I plan for it instead of fighting it.

I add new lessons here as the work moves along, mostly in plain sentences, right after something goes wrong or unexpectedly well.

## Checklist

How success is measured is simple and practical. I look at these points at the end of each stage and again at the end of the project.

- The rebuild goal is met: the forge is rebuilt and works as the mentor expects.
- The project finished within the summer season of 2026, or I can explain clearly why not.
- Total spending stayed within the budget.
- The mentor reviewed and approved the layout, the structure and the first lighting.
- All safety points were checked: ventilation, clearances, fire protection and exits.
- The work area is clean, and tools and materials are put away.
- My notes are complete enough that I could repeat or repair the work later.

Before each stage begins:

- The previous stage is checked and signed off.
- The materials for the stage are on site.
- The next mentor visit is planned, with questions ready.
- The weather for the planned days is acceptable.

## Tools

The tools are a driver too, because the rebuild is limited by what I can use safely and properly. I split them into groups.

Measuring and marking: tape, level, square, chalk line and a notebook. These come first, since every later step depends on them.

Demolition and clearing: hammers, chisels, bars, shovels, barrows and strong containers for rubble. I also keep dust masks, eye protection, gloves and hearing protection within reach.

Building: trowels, mixing tubs, buckets, straight edges and clamps. Heat-resistant materials need the right mixing and handling, so I keep clean tubs for them only.

Forge work: tongs, anvil, hand hammers and a small set of test pieces to try the finished forge in gentle steps.

Rules for tools:

- Check each tool before use, especially handles and edges.
- Borrow from the mentor rather than buying something I will use once.
- Clean and store tools at the end of the day.
- Keep a short list of what is lent out and to whom.

## Maintenance

A rebuilt forge only stays good if it is looked after, so maintenance is part of the plan from the start and not an afterthought.

After the project, I check the structure at regular intervals. I look for cracks, loose parts and signs of uneven heating. Small cracks are normal in heat-resistant work, but I watch whether they grow. I keep the area around the fire free of clutter and check ventilation each time before lighting.

Seasonal habits:

- At the end of summer, review how the forge performed and note anything that needs attention.
- Before the cold months, protect exposed parts from damp and frost.
- Once a year, ask the mentor to look at the whole thing with fresh eyes.

I keep a simple log of repairs and changes, with what was done and why. If something starts to fail, I fix it early and write down the cause. The aim is that the work done in 2026 lasts, and that the notes in this file make the next repair easier than the first build.
