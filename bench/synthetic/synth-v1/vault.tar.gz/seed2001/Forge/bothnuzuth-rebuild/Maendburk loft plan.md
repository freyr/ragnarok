---
type: plan
status: active
project: bothnuzuth-rebuild
area: forge
description: "Plan about Maendburk loft."
---

# Maendburk loft plan

## Lessons

The main lesson from planning this loft is that a large raised space with a west orientation behaves differently from what I first assumed. Maendburk loft is a large loft in the forge area, built in 1998, with a raised floor and west-facing windows. Each of those properties changes how I plan the work, and I keep them in mind whenever I decide something.

First, the raised floor. I assumed it would only matter for stairs and carrying things. In practice it affects almost everything: how heavy items get in, how sound travels down, where cables can run, and how I think about fire exits. Anything heavy has to be carried up, so I now plan the order of deliveries before I plan the layout.

Second, the west orientation. Mornings are cool and dim, and afternoons are bright and hot. I had planned my main working bench near the big windows, and that was a mistake. By late afternoon the glare makes close work unpleasant. I now keep the bench at a right angle to the windows and use the window side for storage and general work.

Third, the size. A large space tempts me to spread out and leave things for later. The loft is easy to fill with half-finished projects. The lesson is to define zones early and give each one a purpose, rather than letting the space decide.

Fourth, the age. A building from 1998 is not ancient, but it is old enough that I should not trust the wiring or the insulation without checking. I treat every system as unknown until I have looked at it myself.

Fifth, the forge area. The neighborhood has a working character: noise, dust and the occasional smell from nearby workshops. I should not expect a quiet, clean setting. I plan for filtering, closed windows when needed, and a tolerance for background noise.

Some smaller lessons:

- Write down measurements once and reuse them. I wasted time re-measuring the same wall.
- Do the dirty jobs first, before anything delicate is moved in.
- Keep a short list of what is urgent and a longer list of what can wait.
- Photograph every wall before closing it up or covering it.
- Do not buy furniture before the layout is settled on paper.

## Ideas

These are options I want to keep in view. None is decided yet.

**Zoned layout.** Divide the loft into four zones: a work zone, a storage zone, a rest zone and an entry zone. The work zone sits away from direct afternoon sun. The storage zone takes the west wall, where it can also act as a buffer against heat. The rest zone goes at the far end, away from the stairs. The entry zone is kept clear, so the way in is never blocked.

**West window treatment.** Because the loft faces west, I want a way to control the afternoon light. Options I have considered:

- Light-colored blinds that can be drawn halfway.
- A sheer curtain layer plus a heavier one for summer.
- Window film that cuts glare without making the room dark.
- A fixed shade or awning outside, if the building rules allow it.

I lean toward blinds plus a sheer curtain, because they are cheap and reversible.

**Raised-floor cable routing.** Since the floor is raised, there may be a void I can use for cables. I want to check whether panels lift out. If they do, I can run power and network lines underneath and keep the surface clean. If not, I will use surface trunking along the walls.

**Sound control.** A large raised space can be loud for whoever is below. Rugs, felt pads under furniture and soft panels on a few walls would help. I also want to avoid dropping heavy things, so tool storage should be at a low height.

**Shared worktable.** One large central table, sized to the space, could serve for projects, meals and meetings. A big loft can take it, and it would give the room a clear center.

**Plants.** West light is strong, so plants that tolerate sun and dry air would suit the windows. I will pick tough ones and not fuss over them.

**Lighting plan.** Layered lighting: general ceiling light, task lamps at the bench, and a warm lamp in the rest zone. Evenings in the forge area can be dark, so I want good light that does not depend on the sun.

## Dimensions

The loft is large. The numbers I rely on are below, and I keep them in one place so I do not measure twice.

The floor area of Maendburk loft is 180.03 m². This is the figure I use for every calculation involving paint, flooring, lighting and ventilation.

The other properties that describe the space:

| Property | Value |
|---|---|
| Name | Maendburk loft |
| Kind | loft |
| Area | forge |
| Orientation | west |
| Size | large |
| Year built | 1998 |
| Floor | raised |

Notes on how these affect measuring and planning:

- The size is large, so I split the floor into zones on paper and measure each zone separately. Measuring the whole room in one go leads to mistakes.
- The raised floor means I must check the height of the floor above the base level at the entrance and at the edges. Door clearances and furniture heights depend on it.
- Because the loft faces west, I record where the sun reaches at different times of day, and I note the position of each window relative to the work zone.
- A building from 1998 may not have perfectly square corners. I check diagonals before ordering anything cut to size.

For anything I buy by area, I add a margin for waste. For paint, I count the walls and not the floor. For flooring, I use the floor area and add extra for cuts. For lighting, I think in terms of zones, not the whole area.

I also want a simple sketch with all fixed features marked: windows, doors, columns, stairs, sockets, and any vents. The sketch is the base for every layout idea I try.

## Checklist

A working checklist, to be ticked off as I go.

**Before starting**

- [ ] Walk the whole loft and note every defect.
- [ ] Photograph each wall, ceiling corner and window.
- [ ] Check that the floor panels are sound and note any loose ones.
- [ ] Test every socket and light switch.
- [ ] Find the main power board and label each circuit.
- [ ] Check the windows open, close and lock properly.
- [ ] Look for damp marks on walls and under windows.
- [ ] Confirm the route for carrying heavy items to the raised floor.

**Layout**

- [ ] Draw a base sketch with all fixed features.
- [ ] Mark the four zones.
- [ ] Decide where the bench goes, away from afternoon glare.
- [ ] Decide where storage goes along the west wall.
- [ ] Keep a clear path from the entrance to each zone.

**Comfort**

- [ ] Choose window coverings for the west light.
- [ ] Plan layered lighting.
- [ ] Add rugs or felt pads for sound.
- [ ] Check ventilation on hot afternoons.

**Finish**

- [ ] Clean the whole space.
- [ ] Put tools in their places and label shelves.
- [ ] Do a last walk-through with the sketch.
- [ ] Write down what changed, and what I would do differently.

## Setup

The setup is the physical order of work. I want to avoid moving things twice.

**Step one: clear and inspect.** Empty the loft as much as possible. An empty large space is the only way to see its real condition. I inspect the floor, walls, ceiling and windows, and I record the findings in my notes.

**Step two: repairs.** Fix anything that is broken before bringing in new items. This includes loose floor panels, damaged window seals, and any electrical issues. For anything involving wiring that I am not sure about, I get a qualified person to look at it.

**Step three: surfaces.** Clean and paint the walls. A light color helps in the morning, when the west-facing room is dim, and it also reflects afternoon light softly. I paint before any furniture goes in.

**Step four: services.** Set up power, network and lighting. If the raised floor allows it, I run cables below the surface. Otherwise I use trunking. Light fittings go in according to the zones, not evenly across the ceiling.

**Step five: heavy items.** Bring in the largest and heaviest pieces first, because they must be carried up to the raised floor. This includes the central table, shelving and the bench. I place them according to the sketch.

**Step six: storage.** Install shelves along the west wall. Fill them gradually, keeping the most used items at a reachable height.

**Step seven: soft items.** Rugs, curtains, cushions and plants go in last. They are easy to move and they finish the room.

**Step eight: review.** Live with the layout for a week. Adjust what does not work. Small changes are cheap at this point.

Some practical rules I follow during setup:

- Keep one clear path at all times.
- Do not stack boxes in front of windows.
- Keep a bin and cleaning supplies near the entrance.
- Finish one zone before beginning the next.

## Schedule

I plan the work in phases, without exact dates, because the timing depends on deliveries and on my free time. Each phase has an expected length in weeks.

| Phase | Work | Expected length |
|---|---|---|
| One | Clear, inspect, record | One week |
| Two | Repairs and electrical checks | Two weeks |
| Three | Cleaning and painting | One week |
| Four | Services and lighting | One week |
| Five | Heavy items and storage | One week |
| Six | Soft items and adjustments | Two weeks |

That gives about eight weeks in total. I expect delays, so I treat it as a target, not a promise.

Some scheduling thoughts:

- Painting should be done on a cooler day. In a west-facing loft, afternoon heat dries paint too fast and can leave marks.
- Deliveries of heavy items should be booked early, since the raised floor makes carrying slower.
- I avoid working in the loft during the hottest part of the afternoon in summer. Mornings are better.
- Loud work is best done on weekdays, when the forge area is already noisy and neighbors are less likely to mind.
- I keep one flexible week at the end. There is always something that was missed.

If the schedule slips, the order of priority is: safety and repairs first, then the work zone, then storage, then comfort items. Decoration can wait indefinitely.

## References

These are the sources I use for this plan, all of them my own notes or general practice, and nothing external with a number.

- My own inspection notes from the first walk-through of the loft.
- The base sketch of the floor, with fixed features marked.
- Notes from earlier projects in other spaces, especially about paint, lighting and cable routing.
- The building's own rules about changes to windows, walls and the exterior. I should check these before fitting anything outside.
- Manufacturer instructions for any equipment I install. I keep these with the items themselves.
- Advice from tradespeople I have spoken with about electrical work and floor repairs.

Related topics I may write up separately:

- Heat control in west-facing rooms.
- Cable routing under raised floors.
- Sound control in large open spaces.
- Layered lighting for workspaces.

I keep the references short on purpose. The plan only works if I actually use it, so I avoid piling up reading material.

## Observations

These are things I noticed while spending time in the loft.

**Light.** The west orientation means the morning is gentle and the afternoon is strong. The shift is quite sudden, usually when the sun drops below the nearby rooftops and shines straight in. Late afternoon is the hardest time for screens and detailed work.

**Temperature.** The loft warms up in the afternoon and holds the heat into the evening. The size of the space helps a little, because the air volume is large, but it does not fully solve the problem. Mornings are cooler.

**Sound.** The raised floor carries footsteps. I can hear my own steps clearly, and I assume anyone below can too. The forge area adds distant sounds from nearby workshops, mostly on weekdays.

**Air.** There is some dust that I assume comes from the area. Surfaces collect it faster than I expected, so I plan for easy-to-clean finishes.

**Space.** The size is the loft's biggest strength. Even with furniture, it feels open. The risk is that it feels empty, so I use zones, rugs and lighting to give it structure.

**Building.** For a place built in 1998, it is in reasonable condition, but I see small signs of age: worn paint near the entrance, a few stiff window catches, and floor panels that are not perfectly level.

**Movement.** The path from the entrance to the far end is long. I walk it often, so I want the most used things close to the entrance or close to the work zone.

## Background

Maendburk loft is a large loft in the forge area. It was built in 1998, has a raised floor, and faces west. The floor area is recorded in the dimensions section, and I will not repeat it here.

I took on the loft as a space for projects and for general living and working. I wanted something big enough to spread out in, and the raised floor and west light were part of what made it interesting. I also liked that the forge area has a practical, working feel, which suits what I do.

At the start I had only a vague plan. I knew I wanted a work zone, some storage and a place to rest. I did not have a clear idea of how the orientation, size and floor would shape those choices. This note is the result of working through that.

The forge area matters for the plan. It is a place of workshops and craft, with the noise and dust that come with it. That is part of the appeal, but it also means I should plan for filtering, sound control and cleaning. A quiet residential street would call for different choices.

The year of construction matters too. A building from 1998 was made with the standards and materials of that time. It is not a historic building, so I do not have to treat it as precious, but I also cannot assume everything is up to current practice. I treat inspection as the first real job.

The raised floor is probably the most unusual property. It gives the loft a particular character and a particular set of constraints. It can hide cables and services, but it also makes carrying and sound more of an issue. I think of it as a feature to work with, not a problem to fix.

My overall aim is a loft that is practical, comfortable and not over-designed. It should be easy to keep tidy and easy to adjust as my needs change.

## Risks

Here are the risks I can see, with what I plan to do about each.

**Heat in the afternoon.** The west orientation brings strong sun and heat. Mitigation: window coverings, a work zone away from the glare, and good ventilation. If the heat is still a problem, I will look at window film or an external shade.

**Hidden problems under the raised floor.** I do not yet know what is in the void. There could be old cables, damp or pests. Mitigation: lift a few panels early and look. Photograph what I find.

**Old wiring.** A building from 1998 may have wiring that is fine, but I should not assume it. Mitigation: have the electrics checked by a qualified person before adding load, particularly if I plan equipment that draws a lot of power.

**Carrying heavy items.** The raised floor makes delivery harder and increases the chance of injury or damage. Mitigation: plan the route, get help, and use proper lifting equipment where needed.

**Sound for neighbors.** Footsteps and dropped items carry through a raised floor. Mitigation: rugs, felt pads and sensible habits. I avoid loud work at unsociable hours.

**Dust and fumes.** The forge area is likely to have both. Mitigation: closed windows when needed, filters, easy-clean surfaces, and storing delicate items in closed cabinets.

**Overspending.** A large space invites large purchases. Mitigation: buy in order of priority, and do not purchase furniture before the layout is settled.

**Clutter.** A big loft can swallow things. Mitigation: zones, labelled storage and a regular tidy-up.

**Schedule slip.** Deliveries and repairs can run late. Mitigation: a flexible week at the end and a clear order of priority.

## Tools

A list of tools and supplies I expect to need, grouped by job.

**Measuring and marking**

- Long tape measure
- Spirit level
- Laser distance measurer, if I can borrow one
- Pencil, marker and masking tape for marking zones on the floor
- Graph paper for the sketch

**Inspection**

- Torch with a strong beam
- Mirror on a handle for looking into tight spaces
- Panel lifter, or a suitable flat tool, for raised floor panels
- Camera, for photographs of everything
- Basic socket tester

**Repair and fitting**

- Screwdrivers, both flat and cross-head
- Drill and a set of bits
- Hammer and a small pry bar
- Adjustable spanner
- Filler and a scraper
- Sealant gun and sealant for windows

**Painting**

- Rollers, brushes and trays
- Dust sheets
- Masking tape
- Cleaning cloths and sugar soap or similar cleaner

**Moving**

- Sack trolley
- Lifting straps
- Furniture sliders
- Strong gloves

**Cleaning**

- Vacuum cleaner with a good filter
- Mop and bucket
- Dust cloths
- Bin bags

**Services**

- Cable trunking
- Cable ties
- Power strips with surge protection
- Light fittings and bulbs suited to each zone

I borrow the tools I will use only once, and I buy the ones I will use often. I keep everything in one marked box near the entrance during the work.

## History

This section is a record of what has happened so far, kept in plain terms.

The loft was built in 1998. Since then, I assume it has been used in several ways, though I do not have a full record. Signs of earlier use include worn paint near the entrance, marks on the floor in places where heavy items stood, and some old fixings on the walls.

My own history with the space is short. I first visited and walked through it, taking in the size, the raised floor and the west light. I made a few rough notes and measurements. Later I spent more time there at different hours to see how the light and temperature changed through the day.

Then I started this plan. The early version was just a list of wishes. After a few visits it became clearer that the orientation and floor would shape the work, and I rewrote it into the phases and zones in this note.

Some decisions so far:

- The loft will be divided into four zones.
- The bench will not go near the west windows.
- The raised floor will be checked before any cables are run.
- Heavy items will be moved in before soft items.
- Wiring will be checked by a qualified person.

Decisions still open:

- The exact type of window covering.
- Whether to use the floor void for cables or use trunking.
- The final position of the central table.
- How much to spend on lighting.

I update this section whenever something is decided or something changes, so that I can look back and see why I did what I did.

## Safety

Safety comes first in this plan, and I treat these rules as fixed.

**Electrical.** I do not work on wiring that I am not confident about. Any new circuit or change to the main board is done by a qualified person. I switch off the relevant circuit before touching any fitting. I do not overload sockets, and I use surge-protected strips only where suitable.

**Raised floor.** I check that panels are secure before walking on them with heavy loads. I mark any loose panel clearly until it is fixed. I do not leave panels open where someone could step into the gap.

**Lifting.** Heavy items are carried by two or more people or moved with proper equipment. I bend my knees, keep the load close and avoid twisting. I wear gloves and sturdy shoes.

**Heat.** In the afternoon, the loft can get hot. I drink water, take breaks and avoid heavy work during the hottest hours. I keep windows operable so I can ventilate.

**Dust and fumes.** When painting, sanding or using chemicals, I open windows and wear a mask suited to the job. I follow the instructions on every product.

**Fire.** I keep clear access to the exit at all times. I keep a fire extinguisher and a smoke alarm in working order, and I check them as part of the setup. I do not store flammable items near heat sources or the west windows, where strong sun can warm them.

**Tools.** I use tools only for their intended purpose, keep blades sharp and put everything away after use. I wear eye protection when drilling or cutting.

**Working alone.** If I am doing risky work, I tell someone where I am and when I expect to finish. I keep a phone within reach.

**Tidiness.** A clear floor prevents most accidents. I tidy as I go and do not leave cables across walkways.

## Overview

This plan covers how I will prepare and organize Maendburk loft. It is a large loft in the forge area, built in 1998, with a raised floor and a west orientation. The floor area is 180.03 m², which gives plenty of room for the zones I want.

The core idea is simple: let the properties of the place guide the layout. The west orientation means strong afternoon light, so the work zone stays away from the glare and the windows get proper coverings. The raised floor means careful carrying, sound control and possibly cable routing below the surface. The size means that I need clear zones and a clear path so the space does not feel empty or messy. The year of construction means I check the electrics and fabric before relying on them. The forge area means I accept some noise and dust and plan for it.

The work follows a fixed order: clear and inspect, repair, paint, install services, bring in heavy items, set up storage, then add soft items and adjust. The schedule is roughly eight weeks, with a flexible week at the end.

The main risks are afternoon heat, hidden problems in the floor void, old wiring, difficult carrying and clutter. Each has a planned response, and safety rules take priority over speed or cost.

The key lessons so far are to measure once and record it, to put dirty work before delicate work, to settle the layout on paper before buying furniture, and to treat every system as unknown until I have checked it.

I will keep this note updated as decisions are made. When the work is finished, I will add a short review of what went well, what did not, and what I would change next time.
