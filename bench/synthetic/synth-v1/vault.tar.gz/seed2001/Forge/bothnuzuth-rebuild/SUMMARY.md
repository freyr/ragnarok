---
type: summary
status: active
project: bothnuzuth-rebuild
area: forge
description: "Summary about Bothnuzuth rebuild."
---

# Summary of Bothnuzuth rebuild

## Tools

The Bothnuzuth rebuild is a project in the forge area. Its goal is rebuild, it started in the summer of 2026, and the lead is the mentor. This note summarizes where it stands.

Tools in use at the bench:

- coal forge with a hand-cranked blower
- heavy anvil on the oak stump
- tongs, hammers and a quench barrel
- a plain text work log kept next to the forge

A typical log extract looks like this:

```text
project: Bothnuzuth rebuild
goal: rebuild
area: forge
start: 2026 summer
lead: mentor
stage: in progress
```

## Decisions

The go decision was made on 2022-05-09. Since then the plan has stayed the same: rebuild the existing structure instead of starting from scratch, and keep the original layout where it still works.

Done so far:

- old parts cleared and sorted
- work area swept and made safe
- first rough shaping finished

Open points:

- choose the final finish for the surfaces
- check whether the quench barrel needs replacing
- agree with the mentor on the order of the remaining steps

The mentor leads the work, so any change to the plan goes through them first.

## Next action

The next action is NX-9609. Before starting it, I will read the latest log entries, set out the tools, and confirm with the mentor that the plan has not changed. When it is finished I will update the stage line in the log and review the open points again.
