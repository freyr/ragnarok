---
type: note
status: active
project: nirtond-survey
area: forge
---

# Treda Kaeson notes

## Observations

Treda Kaeson is my neighbor. I have known her since 2008, so this is a long acquaintance and not a new one. The area tied to her in my notes is the forge, and almost everything I write here relates to that. She works with metal, and her workspace sits close enough to my place that I hear it before I see it.

I keep this note for my own use. It is a plain record of what I have seen, what I have agreed with her, and what I should remember before I knock on her door.

- Role: neighbor
- Area: forge
- Contact: in person
- Availability: weekdays
- Known since: 2008

The contact method matters most. She does not answer messages quickly, and I have never had a reliable exchange with her outside of standing in front of her. If I need something, I walk over. I do not plan on sending a note and waiting for a reply. This has been true for as long as I have known her, and I do not expect it to change.

Her availability is weekdays. On weekends the forge is usually quiet and she is often away or busy with her own errands. I have tried weekend visits a few times and found nobody. So I save my questions and bring them on a weekday, when the fire is lit and she is at the bench.

Some general things I have noticed over the years:

- She prefers a short, clear question to a long story.
- She answers better when I have already looked at the problem myself.
- She keeps her work area tidy around the fire and less tidy elsewhere.
- She remembers favors and expects me to remember them too.
- She will say plainly when she cannot do something, which I appreciate.

When I arrive, I wait at the edge of the yard until she looks up. Walking in while she is hammering is a mistake I made once and will not repeat. She does not mind waiting a minute, but she does mind surprises near hot metal.

## Safety

The forge is the main reason I keep a safety section at all. Hot metal, open flame, sparks and heavy tools are all within a few steps of where I stand when we talk. I treat every visit as a visit to a working hazard area, even when the fire looks low.

Rules I follow when I go there:

- Stay at the edge of the work area until she signals that I can come closer.
- Wear closed shoes. Sandals are not acceptable near the forge floor.
- Keep sleeves short or tight, and keep loose cloth away from the fire.
- Do not touch any piece of metal, even if it looks cold. Dark steel can still burn.
- Keep children and the dog at home.
- Do not stand in the line of the anvil when she is striking.
- Know where the water bucket and the sand are before I need them.

Hot metal does not glow when it is dangerous enough to hurt. That is the lesson she taught me the first year. A bar can look black and still be hot enough to leave a mark. Since then I treat everything on her bench as hot until she tells me otherwise.

Sparks travel further than I expect. Dry leaves, sawdust and old rags near the forge door are a fire risk, and I have offered to help clear them more than once. She usually says she will do it herself, and mostly she does.

Ventilation is another point. The forge gets smoky when the wind turns, and the air can be heavy with fumes if she is working with coated or painted metal. If I notice a sharp smell, I step back and tell her. I do not stand in the smoke to finish a conversation.

If anything goes wrong while I am there, I stay calm, move away from the fire, and call for help only after making sure nobody is in contact with hot material. I keep her phone number in my head, but in truth I would simply shout, because we live close enough that she would hear me.

## Schedule

Her availability is weekdays, and that sets my whole routine around her. I do not try to fit her into my weekend. Instead I plan small visits on weekday afternoons, when I know the fire is usually lit and she has finished her first tasks of the day.

My working pattern for visits:

- Early morning: avoid. She is setting up the forge and does not like interruptions.
- Midday: acceptable for short questions, but she may be eating.
- Afternoon: best time. She is at the bench and usually willing to talk.
- Evening: avoid. She is cleaning up and closing the forge.
- Weekends: do not go. She is rarely there.

Because contact is in person, I cannot book a time ahead in any formal way. What works is mentioning, during one visit, that I will come by again on a certain weekday. She nods, and that is usually enough. If she is busy when I arrive, I leave and try again the next day without any complaint.

Longer jobs need more planning. If I want her to make or repair something, I raise it at least a couple of weeks before I need it. Her workload goes up and down, and she cannot always start straight away. A rushed request has never gone well.

I also keep in mind the seasons. In cold months she works more at the forge and is easier to find. In warm months she sometimes takes a few weeks away from the fire, and I should not expect anything from her then. I note any such break when she mentions it so I do not walk over for nothing.

When I owe her something, such as returning a tool or paying for work, I do it on the first weekday I can. Delaying a return is the quickest way to make her less willing to help the next time.

## Risks

The risks around Treda Kaeson are mostly practical and not personal. We get on well, and the history since 2008 gives me a lot of trust. Still, I keep a list so I do not drift into careless habits.

- Physical risk from the forge, covered in the safety section.
- Fire risk to the shared fence line if sparks carry or if her stock of fuel is stored badly.
- Noise risk: hammering can start early and carry into my house.
- Dependency risk: she is the only person nearby I would ask for metalwork, so if she is away I have no easy substitute.
- Communication risk: because contact is only in person, a missed visit can delay a job by days.
- Relationship risk: asking for too many favors without returning any.

The dependency point is worth thinking about. I could find another smith in a bigger place, but it would mean travel, cost and starting a new relationship from nothing. It is better to keep this one healthy. I try to give her work when I can, speak well of her, and lend help when she needs a second pair of hands.

On the communication risk, I have started to write down the thing I want to ask before I walk over. That way, if she is busy and I come back later, I do not forget half of it. It sounds trivial, but it has saved me a few wasted visits.

Another small risk is assuming she remembers every detail of an earlier agreement. She is sharp, but she works with many people. I now repeat the key points at the start of a conversation, such as the size, the finish and the date I need the piece.

## Problems

Not many problems have come up, but a few repeat often enough to be worth noting.

The first is timing. Because she is only reliably available on weekdays, I have sometimes missed her entirely when my own week was full. I once went three weeks without managing a proper conversation, and a small repair waited all that time.

The second is noise. The forge can start early, and on still mornings the sound of the hammer reaches my bedroom. I have not complained, because it is her trade and she was there first. I mention it here only so I remember to be patient, and to ask if she could avoid the earliest hours when I have visitors.

The third is smoke. When the wind pushes it toward my yard, my washing smells of coal. I now check the wind before hanging anything outside.

The fourth is misunderstanding about measurements. Twice I gave her a rough size and the result did not fit. Since then I bring the actual part, or a drawing with the measurements marked, and I confirm them aloud while she looks.

The fifth is payment. She prefers to settle things directly and soon after the work is done. I once delayed, not out of bad intent, and I could feel a small cooling in her manner. Now I pay on collection.

None of these is serious. They are the normal friction of living next to a working forge, and they are easy to manage with a little thought and some consistency.

## Tools

I do not own her tools, but I know what she uses and what I have borrowed. This list helps me speak clearly when I ask for something.

What I have seen at the forge:

- A coal or coke forge with a hand-cranked or foot-driven blower
- A heavy anvil on a wooden stump
- Hammers of several weights, from light to very heavy
- Tongs of different shapes for holding hot stock
- A vise bolted to the main bench
- A grinder and a drill for finishing
- Quenching tubs, one for water and one for oil
- Files, chisels and punches on a rack near the door

What I have borrowed from her over the years:

- A pair of long tongs, returned the next weekday
- A small hand grinder, returned cleaned
- A pry bar for a stuck gate

I always return borrowed items in the same condition, or cleaner. If something gets damaged, I tell her at once and offer to replace it.

For my own side, I keep a few items ready when I go to talk about a job: a tape measure, a pencil, a small notebook, and the part itself if there is one. Having these in hand shows I have prepared, and it makes her more willing to start straight away.

I have also learned the names of her main tools, so I can follow her explanations. She appreciates it when I use the correct word for a thing, and she is more patient with questions from someone who has made the effort.

## References

These are the things I rely on when I want to recall how the relationship works or what has been agreed in the past. They are all personal and informal.

- My own memory of visits since 2008, which is the main source.
- Notes I keep in this knowledge base about repairs and jobs she has done for me.
- The sketches and measurements I have drawn on paper and kept in a folder in my workshop.
- Items she has made for me that I can look at to remember her style and quality, such as the gate hinges and a set of hooks.
- Conversations with other neighbors who have used her work and speak well of it.

There is no written contract between us and I do not expect one. Our arrangements are made in person and held on trust. The closest thing to a record is my own set of notes, so I try to write down the key points of each agreement soon after we speak.

When I need to remember what price or size we agreed on, I check my notes first and then confirm with her on the next weekday visit. I do not rely on only one of the two.

## Maintenance

Maintaining the relationship takes a small but steady effort. It is similar to maintaining a tool: a bit of regular attention prevents bigger trouble later.

What I do to keep things in good order:

- Visit now and then even when I need nothing, just to say hello on a weekday.
- Return borrowed items quickly and clean.
- Pay promptly and without argument.
- Offer help when I see her moving heavy stock or loading a cart.
- Give her a small gift at the end of the year, usually something practical like a good pair of work gloves or a bag of coal.
- Keep my own yard clear of anything that could catch a spark.
- Be patient with the noise and smoke.

I also maintain my own records. After each visit I add a line to my notes about what was said, what was agreed and what I need to bring next time. It does not take long and it keeps the details straight.

Maintenance of the boundary matters as well. The fence between our places needs checking each spring, especially the side nearest the forge. I look for scorch marks, loose posts and dry growth. If I find a problem, I mention it to her calmly and offer to fix it together.

Over the years, this routine has kept things comfortable. We have never had a real dispute, and I would like to keep it that way.

## Quotes

This section holds the prices she has given me. I write them down exactly as she said them, because memory is not reliable about money.

- Quoted price of Treda Kaeson: 1134.29 EUR

This figure was given in person, which is how she gives all her quotes. She does not write them down unless I ask. I wrote this one in my notebook as she said it and checked it back to her before I left, so we both agreed on the amount.

Points I keep in mind about her quotes:

- A quote covers the work as described at the time. If I change the size or finish, the price may change too.
- She usually says what is included, such as materials and finishing, and I should ask if she does not.
- She expects payment on collection, not before and not long after.
- If the job grows, she tells me early, and I prefer that to a surprise at the end.
- I should not haggle in a pushy way. A polite question about the price is fine, but she respects people who accept a fair figure.

Whenever I get a new quote, I add it here with a short description of the job it belongs to. That way I can compare later and see if her prices have moved over time.

## Supplies

Supplies matter in two ways: what she needs for the forge, and what I bring or keep for dealing with her.

What the forge consumes, as far as I can tell:

- Coal or coke for the fire
- Steel bar and flat stock in several sizes
- Flux and a little borax for welding
- Oil for quenching and for protecting finished pieces
- Grinding discs, files and drill bits
- Leather for aprons and gloves
- Wood for handles and for the stump

Sometimes she is short of an item and mentions it in passing. If I am heading to town on a weekday, I offer to pick it up. She pays me back right away, and the favor is remembered.

What I keep at home for the sake of our arrangement:

- A small bucket of sand near the fence in case of stray sparks
- A garden hose within reach of the forge side
- A spare pair of safety glasses for visits
- Gloves for handling any piece she hands me
- The notebook and pencil I use to record measurements

When I bring a job to her, I try to supply the raw material myself if I can, such as an old part to copy or a piece of stock. It speeds the work and sometimes lowers the cost. She has said that she likes it when people arrive prepared with what they need.

## Overview

Treda Kaeson is my neighbor, and I have known her since 2008. Her area is the forge. I reach her in person, and she is available on weekdays. Those facts shape nearly everything else in this note.

In practice, the relationship is simple and steady. I walk over on a weekday afternoon, wait at the edge of the yard until she sees me, and ask a short, clear question. If I need work done, I bring measurements and the part itself, agree the price aloud, and pay when I collect. The quoted price I have on record is 1134.29 EUR, and I keep that figure in the quotes section so I can check it later.

The main cautions are the heat and sparks at the forge, the noise and smoke that sometimes reach my place, and the fact that she cannot be reached except face to face. I manage those by staying alert, being patient, and planning my visits around her weekday schedule.

What I value most is that she is direct and fair. She says what she can and cannot do, she tells me early if a job is growing, and she remembers a kindness. In return I try to be prompt, tidy and honest. After all these years, that balance has served us both well.

If I only remember a few things, they are these: go on a weekday, go in person, respect the fire, write down what we agree, and pay promptly. Everything else in this note is detail around those simple points.
