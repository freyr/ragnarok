---
type: summary
status: active
project: nirtond-survey
area: forge
description: "Summary about Nirtond survey."
---

# Summary of Nirtond survey

## Costs

The Nirtond survey is a project in the forge area. Its goal is survey, it started in spring 2019, and the lead is the plumber. I never kept a proper ledger for this project, so the costs here are described in kinds rather than amounts, and I am not going to invent figures.

The costs fall into four groups:

- **Time.** This is the biggest cost by far. The plumber lead has spent many evenings and several weekends on field visits and write-ups. Most of the effort went into the first few seasons, when the scope was still fuzzy.
- **Materials.** Notebooks, marker flags, tape, a few cheap measuring tools and some printing. All of it is small and was bought as needed.
- **Travel.** Fuel and a bit of wear on the vehicle. Because the forge area is close to home, this stayed low.
- **Replacement of lost gear.** Two measuring items were lost early on and replaced. I count this as a lesson more than a cost.

The cost picture is stable. Nothing in the project forces a large purchase, and the only real pressure is the lead's time. If the survey grows beyond its current scope, the time cost will grow with it, so I should watch scope before I watch money.

## Decisions

The main decision record for the Nirtond survey is the go decision. The go decision date is 2025-10-15. Before that date the project was in a long "maybe" state, and the survey was run in a loose way. After it, the project had a clear mandate to finish the work rather than keep exploring.

What the go decision covered:

- The goal stays survey. I will not turn the project into a build or a repair job, even if the survey shows things that could be fixed.
- The area stays forge. Neighbouring areas are out of scope, even when they look tempting.
- The plumber stays as lead. There is no plan to hand it over.
- The work is judged by whether the survey is complete and readable, not by how much detail it holds.

Smaller decisions that followed:

- Keep the notes in plain form, with one entry per visit.
- Use a fixed template for each entry so that entries can be compared later.
- Do not chase perfect measurements. A reading that is good enough to compare against the next one is enough.
- Park every side idea in the Ideas section instead of acting on it right away.

I made these decisions to protect the project from drifting. The project began in spring 2019, and since then it has drifted more than once. Writing the decisions down makes it easy to say no to myself later.

## Open questions

Several questions are still open. None of them blocks progress today, but each one affects how I finish.

1. How complete does the survey need to be before I call it done? I have a feeling for it, but I have never written a clear finish line.
2. Should the survey results be kept as one long document or as separate short reports per part of the forge area? Right now they are a mix.
3. Is it worth repeating the earliest visits? Those entries were made before the template existed, and they are harder to compare with the newer ones.
4. Who, besides me, should read the final summary? If nobody, I can keep it terse. If someone else will, I need to explain more.
5. Do I need a second pair of eyes for the trickiest part of the site? The lead is a plumber, and some of the questions drift outside that trade.
6. What happens to the raw notes after the survey is finished: archive, keep in place, or trim?

I will try to answer the first question first, because the answer shapes the others. A written finish line would also make the next action easier to judge.

## Observations

These are the things I have noticed while running the Nirtond survey, in no strict order.

- The plumber lead's habits shape the survey. Attention goes first to anything involving flow, joints, pipes and fittings, and it is thinner on other topics. That is a strength and a bias at the same time.
- Entries made soon after a visit are much better than entries made days later. Memory fades quickly, and small details like the direction of a fitting or the state of a seal disappear.
- The forge area has a rhythm. Some parts are busy and some are quiet, and visits go best when I plan around that rhythm and not around my own calendar.
- Spring was the right season to start. The weather made access easy, and the ground and surfaces were clear enough to read. The project keeps its spring character: most of my best work happened in that season.
- Photographs help only when each one has a short caption. Without a caption I cannot tell later what I was looking at.
- Repeated visits to the same spot show change that a single visit would miss. This is the main reason the survey has value at all.

I want to keep observations separate from conclusions. An observation here is only what I saw. Any reading of it belongs in the Lessons or Ideas sections.

## History

The Nirtond survey began in spring 2019. The goal was survey from day one, and the area was forge from day one. The lead has always been the plumber.

A rough timeline, by year:

- **2019.** The project started with a few exploratory visits. There was no template and no clear scope. Most notes from this year are short and uneven.
- **2020 and 2021.** Progress slowed. Other work took priority, and the survey was done in short bursts. I lost some gear in this period.
- **2022 and 2023.** I rebuilt the habit of regular visits and began to write the entries in a consistent form. This is when the template appeared.
- **2024.** Comparison between visits became possible for the first time. The survey started to show real patterns.
- **2025.** The go decision was made on 2025-10-15, and the project moved from open-ended exploring into a finishing phase.
- **2026.** The work has been about closing gaps, tidying the notes and preparing the final summary. This note is part of that.

Looking back, the slow middle years were not wasted, but they cost momentum. The lesson is to keep a small, steady rhythm, even when the project is not the top priority.

## Schedule

The schedule is loose on purpose. The project has no external deadline, and a fixed calendar would only create pressure that I would then ignore.

The working plan is:

- **Now.** Finish the summary and settle the open questions about the finish line.
- **Next stretch.** Fill gaps in the survey, starting with the parts of the forge area that have the fewest entries.
- **After that.** Review the early entries, decide whether to repeat them, and tidy the notes into their final form.
- **At the end.** Write a closing note, archive the raw material and mark the project as done.

The project began in spring, and I would like to close it in a spring too. That gives the whole thing a tidy shape, and it is the season when the area is easiest to read. If that slips, the next best moment is whenever access is easy and the days are long.

Each stage should be small enough to finish in a few visits. If a stage grows beyond that, I will split it in two instead of letting it stretch.

## Overview

The Nirtond survey is a project with these properties:

- **Goal:** survey
- **Area:** forge
- **Start year:** 2019
- **Season:** spring
- **Lead:** plumber

In plain words, this is a long-running survey of a site in the forge area, led by the plumber, started in spring 2019. The purpose is to record what is there, how it changes and what condition it is in, so that later decisions rest on notes and not on memory.

**Stage.** The project is in its finishing phase. The go decision of 2025-10-15 moved it out of open exploration. The bulk of the field work is done, the template is stable and the notes are mostly comparable.

**What is done.**

- Regular visits over several years.
- A consistent entry template.
- Enough repeated visits to show change over time.
- A written scope with clear limits.

**What is left.**

- A written finish line.
- Gap-filling visits in the thin parts of the area.
- A decision about the earliest entries.
- A closing summary and an archive.

The project is healthy but not finished. The risk is not that it fails but that it fades, so the next action is deliberately small and concrete.

## Lessons

Some things I would do differently, and some I would keep.

**Keep.**

- Write the entry the same day. It is the single biggest quality boost.
- Use a template from the start. The later entries are far more useful than the earlier free-form ones.
- Limit the scope in writing. The go decision did more for progress than any amount of extra effort.
- Park side ideas instead of chasing them.

**Change.**

- Define the finish line at the beginning. Without one, a survey can run forever.
- Caption every photograph at the time it is taken.
- Keep a short checklist of gear before each visit. Losing items early was avoidable.
- Plan visits around the rhythm of the site, not around spare time.

**A general note.** A survey is only as good as its comparability. Detail matters less than being able to put two visits next to each other and see what changed. If I started again, I would trade some detail for consistency right away.

Another lesson is about the lead. Having the plumber as lead gives strong depth in one trade, but I should ask for an outside view on topics that fall beyond it.

## Maintenance

Maintenance here means keeping the survey notes usable, not keeping the site itself in repair.

Routine tasks:

- Review the newest entries after each visit and fix unclear wording.
- Keep the template in one place and do not alter it without a note explaining why.
- Check that every photograph has a caption and every entry has a date in its title.
- Keep a short log of what was changed in the notes themselves.
- Back up the raw notes regularly, so a lost device does not wipe years of work.

A small checklist I use before closing each working session:

```text
session-close checklist
- entry written for today's visit: yes/no
- photographs captioned: yes/no
- gear counted and returned: yes/no
- open points copied to the summary: yes/no
- backup done: yes/no
```

When the project is finished, maintenance shrinks to nearly nothing: keep the archive readable, and do not edit the final summary except to fix errors. If I later reopen the survey, I will start a new note and link it by name in text rather than rewrite this one.

## References

I keep references simple, since this is a personal knowledge base and not a formal report.

- **The survey entries.** One per visit, written with the fixed template. These are the primary source for everything in this summary.
- **The photograph set.** Captioned images from the visits. Useful for checking details that the written entries skip.
- **The scope statement.** The short written scope that came out of the go decision on 2025-10-15.
- **Earlier free-form notes.** The first entries from 2019, before the template existed. Treat them with care, since they are less consistent.
- **Gear checklist.** The short list used before each visit.
- **Other notes in this knowledge base** about the forge area. I mention them by topic only, and the details live in those notes.

If I ever need to defend a statement in this summary, the survey entries come first, then the photographs, then my memory, in that order. Memory is last because it is the least reliable of the three.

## Next action

The next action of the Nirtond survey is NX-7172.

This is the single item I should do next, and it should be done before anything else on the project. I keep it as one item on purpose. A project in its finishing phase does best with one clear step in front of it, not a long list.

When I finish it, I will update this section with the next single step, and move any leftover items into Open questions or Problems. If the action turns out to be bigger than expected, I will split it and keep only the first part here.

A reminder to myself: do not start the gap-filling visits or the review of early entries until this action is closed. Doing several things at once is how the middle years of the project slipped away.

## Problems

Current problems, as honestly as I can state them:

- **No finish line.** Without a written definition of done, I cannot say how close I am. This is the most important problem, and it feeds the open questions above.
- **Uneven early notes.** The oldest entries do not match the template. Comparing them with newer ones takes extra effort and some guesswork.
- **Thin coverage in some parts.** A few parts of the forge area have far fewer entries than others, which weakens the patterns I can claim.
- **Lead bias.** The survey leans toward the trade of the lead. Other aspects of the site are under-recorded.
- **Time.** The project competes with other work, and it loses when I do not schedule it.
- **Uncaptioned photographs.** A handful of images cannot be identified with confidence anymore.

None of these is severe, and each one has a known fix. The trouble is that they are boring fixes, which is exactly the kind of work that gets postponed.

## Risks

The main risks to the project, with a short note on each:

- **Fading.** The biggest risk. A long-running project with no deadline can quietly stop. The answer is a small, concrete next action and a written finish line.
- **Scope creep.** The survey shows things that could be fixed or built. If I follow them, the goal stops being survey. The go decision exists to prevent this.
- **Loss of data.** Raw notes and photographs exist in few copies. Regular backups reduce this risk to a small one.
- **Bias in the record.** If the lead only records what the trade cares about, later readers will get a skewed picture. An outside check on the trickiest part would help.
- **Memory decay.** Entries written late lose detail. Same-day writing is the remedy.
- **Season slip.** If the work misses its good season, the project may wait a whole year. I should plan for the next spring early.

I rate none of these as high, but fading is the one I would bet on if the project ever fails.

## Ideas

Ideas parked here are not commitments. They are for later, and acting on any of them needs a fresh decision.

- Make a one-page map of the forge area with the visited spots marked, so that coverage gaps are visible at a glance.
- Write a short "how to read this survey" note for any future reader, explaining the template and its limits.
- Invite one outside person to review the trickiest part of the site and add a different point of view to the record.
- Build a simple comparison table for repeated visits to the same spot, to make change easier to see.
- Turn the gear checklist into a printed card that stays with the notebook.
- Once the survey is done, write a short retrospective on how the project drifted and recovered, as a guide for future projects of this kind.
- Consider a lighter yearly follow-up visit after the project closes, only to confirm that nothing major has changed.

If any of these looks worth doing, I will first ask whether it serves the goal of survey. If the answer is no, it stays here.
