---
type: plan
status: active
project: nirtond-survey
area: forge
description: "Plan about Vupond level sensor."
---

# Vupond level sensor plan

## Checklist

This is the working plan for the Vupond level sensor, the black level sensor that sits in the greenhouse. It belongs to the forge area in my notes, even though it lives among the plants. I installed it in 2020 and it runs on solar energy. The list below is what I go through at each visit.

- Confirm the Vupond level sensor is still in the greenhouse, in the spot where I mounted it in 2020.
- Wipe dust and condensation off the black housing so the readings are not affected.
- Check the small solar panel for shade, leaves, or film. Greenhouse glass gets dirty quickly.
- Look at the cable entry and the seals for cracks or moisture.
- Compare the reading with a manual check of the water level using a ruler.
- Write the result in the Observations section before leaving.
- Check whether the [[Zeltrelzur solar charger]] is delivering steady power on a cloudy day.
- Compare the behaviour with the [[Paethvol level sensor]] if both are being read on the same day.

## Lessons

A few things I have learned since 2020, written down so I do not repeat them.

1. Solar power works well in the greenhouse during the growing season, but the winter weeks are tight. The sensor needs a clean panel and a good angle, or it drops out.
2. Black housing absorbs heat. On sunny afternoons the case gets warm, and I have seen readings drift a little when it is hot. Shade helps.
3. Condensation is the main enemy. Moisture collects on the sensor face and the readings become noisy. A regular wipe fixes most problems.
4. A manual check is always worth the two minutes. If I trust the sensor blindly, I find problems late.
5. Notes need to be written on the spot. If I wait until I am back at the desk, I forget which tank or bed I was looking at.
6. Work on the forge side of things is a separate job. The sensor is filed under forge because of how I organise my tools, not because it sits near the fire. I should not mix the notes.

I also keep ideas from other plans in mind. The [[Brirkbur Biodio plan]] has a section on regular cleaning that I borrowed, and the [[Glurpe Rorkbostar tests]] showed me how to record a test run in a simple table.

## Schedule

I want a routine that is short enough to actually happen.

- **Weekly:** quick look at the housing and the panel. Wipe if needed. Glance at the reading and compare with the display.
- **Monthly:** full checklist, including the manual level check and the seals.
- **Seasonally:** a longer session. Remove the sensor if it is practical, clean the sensing face properly, check the mounting, and retighten anything loose.
- **Once a year:** review the notes, decide whether the sensor stays where it is, and write down any change in plan. The anniversary of the 2020 installation is a convenient reminder.

Extra checks after any storm, a long cloudy spell, or when the greenhouse has been heated or ventilated in an unusual way. In those cases I check the sensor the same day if I can.

If a visit is missed, I do not try to catch up with two visits in a row. I just do the next one properly and note the gap.

## Measurements

The main numbers I track for the sensor are listed here. I record the same things each time so I can compare them over the months.

- Flow rate of Vupond level sensor: 435.26 l/h
- Level reading from the sensor, noted as a rough fraction of full.
- Level measured by ruler, noted in the same way.
- Panel condition: clean, dusty, or shaded.
- Weather on the day: sunny, cloudy, or wet.
- Temperature feel inside the greenhouse: cool, mild, or hot.

I keep the method simple. The flow rate figure is the reference I use when I think about how fast the water moves through the system, and I compare any new impression against it. If the sensor reading and the ruler disagree by more than a small margin, I flag it. Small differences are normal, especially when the surface of the water is moving.

I do not trust a single reading. I take two, a few minutes apart, and write both. If they disagree, I wait and take a third.

## Observations

This section is a running log. New entries go at the top of the list, in plain words.

- The sensor has been steady for most of its time in the greenhouse. The black case has faded a little but is sound.
- Readings tend to be most stable in the morning, before the greenhouse warms up.
- After humid nights, the sensing face is often wet and the first reading is unreliable. I wipe it and read again.
- The solar supply copes well in summer. In winter I watch it more closely, and I sometimes pair the checks with a look at the [[Zeltrelzur solar charger]].
- Compared with the [[Paethvol level sensor]], the Vupond unit seems a bit slower to settle but less jumpy overall. This is only an impression, not a test result.
- The mounting is still firm. No rust, though the screws should be checked each season.
- Insects and small spiders like the housing. I clear them during the weekly look.

Open questions for later:

1. Would a small shade over the case reduce the afternoon drift?
2. Is the panel angle still the best one after several years?
3. Should I add a second manual check point in the greenhouse?

## Supplies

What I need on hand so a visit does not turn into a trip to the shop.

- Soft cloth and a small brush for the housing and the panel.
- Mild soapy water in a small bottle. No harsh cleaners near the sensing face.
- A ruler or a marked stick for manual level checks.
- Notebook or the phone with this note open.
- Spare seals and a little silicone grease for the cable entry.
- Cable ties and a few spare screws for the mount.
- A small screwdriver set.
- A piece of shade cloth, in case I try the idea of covering the case in the afternoon.
- Gloves, since the greenhouse can be damp and dirty.

Related notes to keep nearby: [[Brirkbur Biodio plan]] for cleaning routines and [[Glurpe Rorkbostar tests]] for how I log test runs. If I change the plan, I will update the Schedule and Checklist first, and then add a short line to Observations so the reason is not lost.
