---
type: drivers
status: active
project: nirtond-survey
area: forge
description: "Drivers about Nirtond survey."
---

# Drivers of Nirtond survey

## Lessons

The Nirtond survey is a project with the goal "survey", it belongs to the forge area, it started in spring 2019, and the plumber leads it. These notes are about the drivers of the work: why it exists, what limits it, what it costs and how I decide whether it worked.

What I learned early is that a survey with a vague goal drifts. In the first season we collected measurements without agreeing on what they were for, and half of them were never used. Since then, every measurement we take has to answer a question written down before the work starts.

Other lessons that have held up:

- The goal comes first. If a task does not help the survey goal, it waits.
- The lead owns the decisions. Having the plumber as lead kept the scope small, because the plumber thinks in terms of what can actually be reached and checked on site.
- Write down the constraints at the start. Constraints discovered halfway through cost far more than constraints accepted on day one.
- Success has to be measurable in plain terms. "A good survey" means nothing. "Every pipe run in the forge area is recorded and checked once" can be tested.
- Spring is a good season to start. The forge is less crowded with orders, and the weather lets us open up the outer walls and yard without trouble.

## Ideas

Several ideas have come up for making the survey better. None is committed yet, but they are worth keeping.

- Use one shared sketch of the forge area as the base for all records, so that every note points to the same layout.
- Mark each surveyed point physically with a tag, so that a later visit can find it without reading the notes.
- Split the area into small zones and finish one zone fully before moving to the next. This gives visible progress and makes it easier to stop at any time with something useful.
- Take a short photo series of each zone before and after, kept in a folder named after the zone.
- Ask the lead for a short review at the end of each zone rather than a large review at the end of the project.
- Keep a single list of "things that surprised us". Surprises are the best signal of where the original assumptions were wrong.

An idea I am less sure about is repeating the whole survey after a few years to see what changed. It would be useful, but it only makes sense if the first survey is recorded in a format that can be compared later.

## Budget

The budget of Nirtond survey is 38100.05 EUR.

This is the total I treat as the ceiling for the project. It covers the main costs: tools and consumables for measuring, access work where walls or floors have to be opened, time for the people involved, and a reserve for things we did not foresee.

How I handle the money in practice:

- Costs are grouped by zone, so that I can see which part of the forge area is expensive.
- Anything that would push a zone over its share needs a short discussion with the lead before it is bought.
- The reserve is not spent on things that were simply forgotten in the plan. It is for real surprises only.
- I check the running total at the end of each zone, not only at the end of the project.

The budget is one of the three main constraints, together with the season window and the availability of the lead. If one of them tightens, the scope has to shrink, not the quality of the records.

## Supplies

The survey does not need much exotic equipment. Most of what we use is ordinary and easy to replace.

- Measuring tools: tapes, a level, a basic distance meter and a notebook with waterproof pages.
- Marking material: tags, paint markers and tape in a few colours, one colour per type of line.
- Access tools: simple hand tools for opening panels and covers, plus a work lamp and spare batteries.
- Safety items: gloves, eye protection and sturdy footwear, because the forge area has hot surfaces, sharp offcuts and uneven floors.
- Recording items: a camera or phone, a folder structure for photos, and printed copies of the shared sketch.

Supplies are stored in one box near the entrance of the forge area. After each session the box is checked and anything used up is written on a short list. The plumber usually knows which items run out first, mostly tags and batteries, so I buy those in larger amounts.

## History

The project began in spring 2019. The idea came from a repeated problem: whenever something needed repair in the forge area, nobody had a reliable picture of what was behind the walls or under the floor, so every repair began with guessing.

The early work was loose. We walked the area, took many notes and measured things without a plan. That produced a lot of material but little that could be trusted. After the first season the plumber, as lead, set a clearer structure: zones, one question per measurement, and a standard way of recording.

Since then the work has moved in stages. Each stage covered a few zones, ended with a review, and left behind a set of records that could be used on their own. Some stages were slowed by access problems and by the busy periods of the forge, but the overall direction did not change. The goal has stayed "survey" throughout, and I have resisted turning it into a renovation project, even though the survey often reveals things that should be fixed.

## Problems

The problems so far are mostly practical.

- Access: some parts of the forge area are hard to reach. Pipes behind fixed panels or under heavy equipment cannot be checked without moving things, and moving things costs time and sometimes money.
- Conflicts with work: the forge has its own rhythm. When orders are heavy, survey sessions get cancelled or shortened.
- Inconsistent records: early notes use different names for the same place. Cleaning this up takes more effort than expected.
- Heat and dirt: they damage paper, tags and sometimes tools. Waterproof pages helped, but not for everything.
- Scope pressure: people who see the survey tend to ask for extra checks. Each request is reasonable, but together they would double the work.

The way I deal with these is to log each problem with its zone and the date it appeared, decide whether it blocks the survey goal, and either solve it or move it to the open questions. Problems that do not block the goal are not allowed to take over the schedule.

## Risks

The main risks are things that could stop the project from reaching its goal or push it beyond its limits.

- Budget overrun: the budget is fixed, and hidden conditions behind walls could make access work more expensive than planned. The reserve is the first protection, and reducing the number of zones is the second.
- Loss of the lead: the plumber leads the project and holds much of the practical knowledge. If the plumber becomes unavailable, decisions slow down and some knowledge may be lost. To reduce this, important points are written down, not kept in memory.
- Safety: working around hot and heavy equipment is a real danger. Sessions are planned with the forge work in mind, and nobody opens a panel near active equipment.
- Poor record quality: if records are not clear, the survey fails even when the measurements are right. Standard names and the shared sketch are the defence.
- Season window: the project depends on good conditions for outside work. Missing the window moves tasks to a worse time of year.
- Survey turning into repair: finding defects creates pressure to fix them at once, which would eat the budget.

## Maintenance

A survey is only useful while it matches reality, so its records need care after the main work is done.

- After any repair or change in the forge area, the matching zone record is updated the same week.
- The shared sketch is kept as the master copy, and printed copies are replaced when it changes.
- Tags are checked once a year, usually in spring, when the project originally started. Missing or unreadable ones are replaced.
- Photo folders are kept in the same structure, and old photos are not deleted, because the comparison is often the most useful part.
- The list of supplies is reviewed after each session so that the box does not run empty.
- Once a year I read through the drivers again: the goal, constraints, budget and success measure. If something has changed, I write it down here instead of keeping it in my head.

Success is measured simply. Each zone counts as done when every item in it is recorded, marked, photographed and checked once by the lead. The project counts as done when all zones are done within the budget.

## Open questions

Some things are still undecided.

- Should the survey be repeated after a few years, and if so, in what format so that it can be compared with the first one?
- How much of the budget should be kept as reserve for the later zones, now that the earlier ones have shown how large the surprises can be?
- Who takes over the lead's practical knowledge if the plumber is not available?
- Where is the line between a survey and a repair? At the moment I stop at recording the defect, but some defects are urgent.
- Is one colour per type of line enough, or do we need a better marking system for crowded areas?
- Should the records be shared outside the project, for example with whoever maintains the forge building, and who would keep them up to date?
- Is spring still the best season to continue, or would another time of year fit the forge's order cycle better?
