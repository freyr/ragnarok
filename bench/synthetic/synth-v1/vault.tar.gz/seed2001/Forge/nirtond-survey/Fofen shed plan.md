---
type: plan
status: active
project: nirtond-survey
area: forge
---

# Fofen shed plan

## Safety

This plan covers the Fofen shed, a shed in the forge area. It is a medium shed, built in 2003, on ground level, and the main door faces north. I keep the safety rules at the top of the note because I read them before anything else when I come back after a long gap.

- Check the floor for loose offcuts and cold metal before lighting or powering anything. On a ground-level floor, a dropped piece rolls a long way.
- Keep the north door propped open whenever the forge side is in use. The shed is medium sized, but smoke and fumes collect fast with the door shut.
- Never leave the dehumidifier cable across the walkway. Route it along the wall.
- Keep the fire bucket and the sand bin by the door, not at the back.
- Wear eye protection for anything involving grinding, cutting or hammering scale off hot work.
- Do not work alone on the band saw. If I must, I tell someone in the house first.

The north orientation means the shed gets little direct sun, so it is dim in the morning. I use the work lamp even when it feels bright enough outside. Poor light caused more near-misses here than any tool did.

## History

The Fofen shed was built in 2003. I did not build it myself. It came with the plot, and the earlier owner used it as a general store for garden gear. When I took it over, the first job was clearing it out and deciding whether it could be a working space for the forge area.

The shed is a ground-level building with a solid floor, which is the main reason I chose it for heavy work. A raised floor would have been a problem for the anvil stand and for moving stock around. The year of construction shows in the wall boards, which have gone grey on the outside but are still sound on the inside.

Over the years since, the use of the shed has changed in stages. First it was storage only. Then I added a bench and started small repairs. After that, I moved the forge-related tools in and gave the shed a proper plan, which is this note. I wrote down what I did at each stage so I do not repeat mistakes, and the later sections draw on those notes.

I also talked the layout over with [[Brasmaen Pasviond]], who has more experience with forge buildings than I do. The advice about keeping the quench area near the door came from that conversation, and I have kept to it.

## Measurements

The shed is medium in size. I do not need exact wall lengths in this plan, because the layout is built around zones rather than millimetres. What matters is that the medium size gives enough room for a bench, a stock rack, a saw station and a clear walkway, but not enough for a second large machine.

The main properties, written down in one place:

- Kind: shed
- Area: forge
- Orientation: north
- Size: medium
- Year built: 2003
- Floor: ground level

The measured humidity of Fofen shed: 23.88 %. I took that reading with the logger after the shed had been closed for a while, so it reflects the resting state and not a day of active work. It is a comfortable figure for tools and stock. Steel rusts quickly when the air stays damp, so I treat this as the target and watch for drift upward.

For weighing stock and checking material, I follow [[Palmosbrul scale notes]], which explains how I zero and check the scale before use. For ongoing readings, the setup in [[Sonvund data logger handbook]] describes how the logger is placed and read. I keep the logger at bench height, away from the door, so that a draught from the north side does not skew the result.

## Setup

The shed is laid out in zones along the walls, with the middle kept clear.

The north wall holds the door, so I keep that side free. The fire bucket, the sand bin and the quench tub sit close to it. The reasoning is simple: if something goes wrong, the way out and the way to the water are the same way.

The east wall carries the bench. It is a sturdy bench with a vice at one end. Hand tools hang on a board above it, in the order I use them. I outline each tool on the board so a missing one is obvious at a glance.

The west wall holds the stock rack. Long steel sits lowest and flat bar sits above. I keep a dry rag in each bay and a small tin of oil on the shelf to wipe the ends of anything that has been out in the open.

The back of the shed is the saw station. The plan for it is in [[Kurknund band saw plan]], which covers the stand, the table height and the clearance behind the blade. I stuck to that plan so the offcuts fall where I can sweep them up easily.

The dehumidifier, described in [[Zerklael dehumidifier]], sits on the floor near the stock rack, since that is where damp does the most harm. The data logger sits on the bench wall. The [[Paethvol level sensor]] is used when I check the water level in the quench tub and the dehumidifier tank, so I keep it in a labelled box on the bench shelf.

## Problems

These are the problems I have run into, written plainly so I can recognise them again.

**Damp in the corners.** The north side stays cool and shaded, so the corners behind the stock rack hold moisture longer than the rest of the shed. Rust spots first appear on the ends of bars stored there. Moving the rack a hand's width off the wall helped, and the dehumidifier did the rest.

**Dim morning light.** Because the door faces north, direct sun rarely reaches the bench. I added a lamp above the bench and another over the saw station. Before that, I misjudged cuts more than once.

**Cluttered walkway.** A medium shed fills up fast. Every time I let offcuts pile up near the door, the walkway narrowed. I now sweep at the end of every session, not at the end of the week.

**Tank overflow.** Twice the dehumidifier tank filled up and stopped without my noticing. The [[Paethvol level sensor]] is the fix for that, since it gives an early warning before the tank is full.

**Cold floor.** The ground-level floor stays cold in the shoulder seasons. A rubber mat at the bench is enough for my feet, but cold metal left on the floor stays cold much longer than metal on the bench. That matters when I am checking whether something is still hot.

## Schedule

I keep a routine that matches how the shed is used. Nothing here depends on a calendar date, only on the rhythm of use.

- **Every session:** open the north door, check the floor, check the lamp, look at the logger reading, empty the dust tray at the saw station, sweep before leaving.
- **Weekly:** check the dehumidifier tank, wipe the stock ends with oil, check the fire bucket and the sand bin, and put tools back on their outlines.
- **Monthly:** move the stock rack and check behind it, check the door seal, check the cable runs along the wall, and review the logger history.
- **Seasonal:** go through the whole stock and discard anything rusted past use. Check the roof boards from inside for light leaks. Check the saw blade and the stand bolts.
- **Yearly:** take everything out, clean the floor completely, repaint the outline board if needed, and rewrite any part of this plan that no longer matches the shed.

I do not try to do everything at once. The schedule is a rhythm, and the worst thing I can do is to turn it into a chore I skip. If I miss a week, I do the weekly list next time and carry on.

## Background

The Fofen shed sits in the forge area, which is the part of the plot set aside for hot work and metalwork. The area has its own habits: noise, smoke and heavy material all belong here, and I keep the other parts of the plot free of them on purpose.

I wanted a building that could take these habits without constant fuss. A shed on ground level, with a solid floor, suits heavy anvils and stock. The north orientation is a mixed blessing. It keeps the inside cooler in summer, which is pleasant when the forge is running, but it also keeps the inside damp and dim.

My earlier attempts at a workshop were in a lean-to with a dirt floor. Everything rusted, and I could not keep the saw level. That is why the damp numbers matter so much to me now. The measured humidity of 23.88 % mentioned earlier is the reason I feel the current approach works. It shows that the dehumidifier and the routines together are doing their job.

I also lean on written references more than I used to. The notes for the scale, the logger and the saw exist because I used to rely on memory and got caught out. A short note that says how to set something up is worth more than a confident guess.

## Tools

The shed holds a modest set of tools, chosen for the forge area.

- **Bench vice:** fixed at the east end of the bench, used for filing, bending and holding small work.
- **Band saw:** at the back of the shed, built following [[Kurknund band saw plan]].
- **Scale:** used for weighing stock and finished pieces, checked as in [[Palmosbrul scale notes]].
- **Dehumidifier:** the unit from [[Zerklael dehumidifier]], on the floor near the stock rack.
- **Data logger:** set up as in [[Sonvund data logger handbook]], recording humidity and temperature at bench height.
- **Level sensor:** the [[Paethvol level sensor]], for the quench tub and the dehumidifier tank.
- **Hand tools:** hammers, tongs, files, chisels and punches, each with its outline on the board.
- **Safety kit:** eye protection, gloves, fire bucket, sand bin and a basic first aid box.

I keep the list short on purpose. A medium shed does not reward owning more than I can store properly. When I think about buying a new tool, I first ask where it will live and what I will remove to make room. Often that question alone settles it.

## Maintenance

Maintenance keeps the shed useful for another stretch of years. The building dates from 2003, so I treat it as an older structure that still has life in it but needs regular attention.

**Structure.** I check the wall boards, the roof boards and the door frame from inside. Light leaks show up as bright lines in the morning. Any soft board gets replaced rather than patched, because soft wood on the north side means water is getting in.

**Door.** The north door is the one I use most. I oil the hinges and check that it still props open firmly. A door that swings shut on its own is a safety issue in a forge shed.

**Floor.** The ground-level floor gets swept every session and scrubbed when oil spots build up. I never leave oily rags on it.

**Dehumidifier.** I empty and rinse the tank as part of the weekly routine, and I clean the filter when the logger shows humidity creeping up despite the unit running. The manual-style notes are in [[Zerklael dehumidifier]].

**Logger and sensor.** I check that the logger is still recording and that the [[Paethvol level sensor]] still responds. A silent instrument is worse than none, because I start trusting it.

**Saw.** The blade, the guides and the stand bolts are checked in the seasonal round, following the notes in [[Kurknund band saw plan]].

## Lessons

A few things have become clear after working in this shed for a while.

First, humidity is the quiet enemy. Nothing dramatic happens, but stock, tools and even the wooden handles suffer slowly. Having a real number, 23.88 %, gives me something to compare against, which is better than guessing from the smell of the air.

Second, the layout matters more than the tools. A medium shed with a clear walkway and tools in fixed places is safer and quicker than a bigger shed with things piled in it. Every time I broke that rule, something was dropped or lost.

Third, light is a safety feature. The north-facing door looks fine on paper, but the shed is dim for much of the day. Good lamps cost little and prevent a lot of mistakes.

Fourth, write the setup down. The notes on the scale, the saw and the logger all started as quick reminders and turned into the most useful part of my records. When I forget how I calibrated something, the note answers, and I do not have to start over.

Fifth, ask for advice. Talking with [[Brasmaen Pasviond]] saved me from placing the quench tub in the wrong corner, which would have meant carrying hot work across the whole shed.

## Observations

These are things I have noticed that do not fit neatly elsewhere.

The shed feels different depending on the season, even though it is the same building. In cooler months the north side holds the cold, and the humidity reading drifts up unless the dehumidifier runs more often. In warmer months the shed stays pleasant while the forge is burning, but the stock needs more attention because condensation forms when warm air meets cold steel.

The logger readings tell a clear story when I look at them over a few days. Humidity rises after I close the shed following a long session, then settles. The resting figure of 23.88 % is lower than I expected for a shaded north-facing shed, and I credit the dehumidifier and the habit of wiping the stock.

The sound in the shed is also worth noting. The band saw is loud in a medium space, and ear protection is not optional. The sound carries out through the north door, so I try to avoid long sawing sessions at times that would disturb anyone nearby.

Finally, tidy habits spread. When the bench is clear, I tend to keep the floor clear, and when the floor is clear I tend to put the tools back. It works the other way too. One untidy corner invites more of the same.

## Risks

The risks below are the ones I think about when I plan work in the Fofen shed. I list them so I can decide in advance what I will do, instead of deciding in the middle of a problem.

- **Fire:** a forge area with wooden walls built in 2003 is a real fire risk. The fire bucket and the sand bin stay by the north door, and I do not store solvents or loose paper near the hot work.
- **Fumes:** a closed shed fills with smoke and gas. The door stays open during hot work, and I stop if the air feels heavy.
- **Damp and rust:** if the dehumidifier fails or the tank fills, humidity climbs and the stock suffers. The logger and the [[Paethvol level sensor]] are my early warnings.
- **Saw injury:** the band saw is the most dangerous tool in the shed. I follow [[Kurknund band saw plan]] for the guards and clearances, and I do not use the saw when tired.
- **Trips and falls:** a medium shed with a ground-level floor has little spare room. Cables, offcuts and tools on the floor are the main cause.
- **Structural wear:** the age of the building means roof or wall boards may weaken. The seasonal check from inside is how I catch it.
- **Poor light:** the north orientation leaves the shed dim, so lamp failure is a safety issue, not just an annoyance. I keep a spare bulb on the shelf.

If several of these risks show up at once, I stop work, make the shed safe, and go back to the Safety section before starting again.
