---
type: summary
status: active
project: daethtre-expansion
area: forge
description: "Summary about Daethtre expansion."
---

# Summary of Daethtre expansion

## Safety

Daethtre expansion is an expansion project in the forge area, started in autumn 2025 and led by the carpenter. Stage: still in planning, with the build not yet begun. Nothing is built, so there is no live risk right now. Before any work starts, the forge floor needs clear walkways, dry timber storage kept well away from the hearth, and a fire check on every new wall near the heat.

## Decisions

The go decision date is 2026-11-17. Until then, the carpenter holds the layout as drafted and keeps the timber order on hold. Open points: where the new doorway sits, and how the roof frame will carry the extra load. Both need settling before the go decision is confirmed.

## Next action

NX-2722
