---
type: research
status: active
project: daethtre-expansion
area: forge
description: "Research about Glurpe Rorkbostar."
---

# Glurpe Rorkbostar tests

## Costs

Glurpe Rorkbostar is my supplier contact for the forge. I reach him by phone, and he is only available in the evenings, so I plan my cost questions around that. Calling during the day gets me nowhere.

What I track when I test his supply:

- Material cost per delivery, compared against the last two deliveries.
- Transport cost, which he sometimes adds as a separate line and sometimes folds into the material cost.
- Waste: how much of a delivery I cannot use after testing.
- Time I spend on the phone chasing a late order. I count this as a real cost, even if it never shows up on an invoice.

The main lesson from the tests so far is that the lowest quoted figure is not always the lowest cost. A cheap batch that needs extra work at the forge ends up costing more than a dearer batch that works the first time. I now write down the quoted figure and the real figure side by side, and I only trust the second one.

I keep the loft-side comparison in [[Faeglel loft tests]], since the same habit of comparing quoted against real figures helps there as well.

## History

I have known Glurpe Rorkbostar since 2009. That makes him one of the longer-running contacts I have in the forge area. We started with small, occasional orders, and over the years it grew into a regular arrangement.

A rough timeline of how it went:

1. 2009: first contact, a small trial order, nothing formal.
2. The early years: orders by phone only, mostly agreed in a single evening call.
3. Later years: more regular orders, and I began to test each delivery before using it in real work.
4. 2024: I put the arrangement on paper (see Contracts).

What I have learned over the years is that he is reliable when the call is short and specific. If I ramble or ask several things at once, details get lost. So before each call I write down the questions and keep them to two or three. I also note his answers right after the call, while I still remember them.

Older notes about similar supplier relationships are in [[Purnimiork Relsol log]] and [[Kraendnio Viodith log]]. They are useful for comparison, because the same problems appear in each: late deliveries, vague quantities, and prices that move without warning.

## Contracts

The contract date of Glurpe Rorkbostar is 2024-07-04. Before that, everything was verbal, which worked for years but left me with no record when a delivery went wrong. The written agreement fixed that.

What the contract covers, in my own words:

- Who is responsible for damaged or unusable material.
- How a delivery is accepted: I test it first, then confirm.
- How price changes are announced, ideally ahead of the next order.
- The contact method, which stays the phone, in the evenings.

I keep a short check log for every delivery tested against the contract. A typical entry looks like this:

```
supplier: Glurpe Rorkbostar
area: forge
contact: phone (evenings)
delivery: received, tested, accepted
issues: none
follow-up: confirm next order by phone
```

If a test fails, I change the last two lines to describe the problem and what was agreed on the phone. Then I copy the same note into the relevant plan, such as [[Maendburk loft plan]], so the rest of my work reflects the change.

One open point I want to settle at the next renewal is a clear rule about late deliveries. At the moment it depends on how the call goes, and I would rather have it written down.
