---
type: research
status: active
project: daethtre-expansion
area: forge
description: "Research about Faeglel loft."
---

# Faeglel loft tests

## History

Faeglel loft is a loft in the forge area. It was built in 2008, and it has stood on its raised floor since then. I keep this note as a running record of the tests I have done there, so the history here is mostly the history of how the space has been used and what I learned about it.

The loft is large and faces west. In the first years it was used as a general store above the working part of the forge. Over time it became a place for slow jobs: sorting, drying, and testing small setups before they went downstairs. The raised floor was a deliberate choice by the original builders, who wanted air to move underneath and wanted the loft kept clear of dust from the forge floor.

My own tests started when I wanted to know whether the loft was good enough to hold instruments and materials that dislike heat and damp. The earlier plans I compared it with are [[Maendburk loft plan]] and [[Zaeldroth Mioror plan]]. Both helped me decide which questions to ask. The loft never had a proper survey, so everything here comes from my own measurements and notes.

## Risks

The main risks I have found while testing are listed below. None are dramatic, but each one has caused a wasted test day at some point.

- **Afternoon heat.** The loft faces west, so low sun heats it in the late part of the day. Any test that needs steady temperature gets spoiled if it runs into the evening.
- **Forge dust and smoke.** The raised floor helps, but fine dust still gets up through gaps near the stair. Open samples collect it fast.
- **Floor loading.** The loft is large, and it is easy to put too much weight in one corner. I keep heavy items near the walls and away from the middle of the span.
- **Vibration.** When work is going on below, the floor carries it. Scale readings in particular jump around.
- **Damp in cold spells.** Cold nights followed by a warm day cause condensation on metal near the western wall.
- **Stair and edge.** Because the floor is raised, the edge by the stair is a real fall hazard when I carry loads.

I treat the first four as test-quality risks and the last two as safety risks. The Safety section covers the second group in more detail.

## Supplies

What I bring up to the loft for a normal test session is fairly stable. I keep a small kit there so I do not carry everything up each time.

- A data logger for temperature and humidity, set up following [[Linvetro data logger notes 2019]].
- A small radio receiver for checking interference, described in [[Velmol radio receiver notes]].
- A bench scale and a set of check weights, with the handling rules in [[Palmosbrul scale notes]].
- Clean cloths, tape, and sealed containers for samples.
- A notebook and pencil, because screens are hard to read in the western glare.
- Shade cloth to hang over the west window during afternoon runs.
- A torch, since the lighting is poor near the back wall.

The table below shows where each item lives and what it is for. I keep it so I can tell quickly if something has gone missing.

| Item | Kept where | Used for |
|---|---|---|
| Data logger | Shelf by the stair | Temperature and humidity runs |
| Radio receiver | Cabinet, north wall | Interference checks |
| Bench scale | Bench, centre-south | Weight and vibration tests |
| Check weights | Lidded box under bench | Scale calibration |
| Shade cloth | Hook by west window | Reducing afternoon heat |
| Sample containers | Low shelf, east side | Dust and damp tests |

## Costs

I do not track exact prices in this note. What matters for planning is where the money and effort go, so I describe the costs in relative terms.

The largest ongoing cost is time. A proper temperature and humidity run needs the loft left undisturbed for several days, which means I cannot use it for anything else. The second cost is the effort of carrying equipment up and down the stair, which is why I keep the kit in the loft.

The equipment itself was already owned, so the tests cost little new. The only things I buy regularly are cloths, tape, and sealed containers, and these are cheap. If I ever decide to improve the loft, the big items would be shading for the west window, a better seal around the stair opening, and some form of floor reinforcement. I have not priced these, and I would rather finish the testing before deciding whether they are worth it.

One hidden cost is repeat testing. When a result looks odd, I have to redo the run, and with a large loft that means waiting for the conditions to settle again. I now budget extra days for that.

## Overview

Here are the properties of the place, stated plainly so I do not have to look them up again.

- Name: Faeglel loft
- Kind: loft
- Area: forge
- Orientation: west
- Size: large
- Year built: 2008
- Floor: raised

The loft sits above the working part of the forge, and its west orientation gives it strong evening light and heat. Its large size means conditions are not uniform. The area near the western wall behaves differently from the area near the stair, and the middle of the floor behaves differently again. Because the floor is raised, there is airflow below, which keeps the boards drier than I expected, though it also lets vibration through.

The tests I run fall into a few groups: temperature and humidity, dust, floor behaviour under load and vibration, and radio interference. This note collects what I did, what I saw, and what I still want to find out. It is a working document, not a finished study.

## Checklist

Before each test session I go through this list. It saves me from the mistakes I have made before.

- Check the weather for the afternoon and decide whether shade cloth is needed.
- Confirm the logger is charged and its clock is right.
- Clear the test area and sweep the floor near the stair.
- Place the bench scale away from the middle of the span.
- Check that the forge below is quiet, or note that it is not.
- Hang the shade cloth if the run will pass into the afternoon.
- Put check weights on the scale and confirm the reading before starting.
- Write the start conditions in the notebook.

After the session:

- Stop the logger and save the data straight away.
- Return all weights and containers to their places.
- Close the window and secure the stair opening.
- Write a short summary of anything odd.

The checklist is short on purpose. When it gets long I stop following it.

## Background

The reason for testing the loft at all is practical. I wanted a place that could hold sensitive items without a lot of fuss, and the loft was the largest quiet space available. Before committing, I wanted evidence about how it behaves through a day and across weather changes.

I compared it with other places I have notes on. The [[Maendburk loft plan]] describes a loft with a different orientation, and the comparison made the effect of the west-facing wall obvious. The [[Zaeldroth Mioror plan]] gave me a layout idea for dividing the space into zones. For the pond-side conditions that I sometimes use as a damp reference, I look at [[Masra pond]], where humidity is naturally high.

I also talked through the early results with [[Ganzin Birksta]], who has more experience with building behaviour than I do. His main advice was to test in all kinds of weather and not to trust a single good week. That advice shaped how I plan the schedule.

For the record of larger-scale activity in the area, which affects vibration and dust, I rely on [[Purnimiork Relsol log]].

## Observations

These are the main things I have seen so far. They are patterns, not precise findings, and I have tried to say how sure I am of each one.

**Heat.** The west wall warms up from the middle of the afternoon and the warmth lingers well into the evening. The effect is strongest near the window and weaker toward the stair. Shade cloth helps noticeably, though it does not remove the effect. I am fairly sure of this one.

**Humidity.** Humidity is steadier than I expected thanks to the raised floor. It rises on cold mornings and drops in the afternoon. The worst condensation shows up on metal near the west wall after a cold night followed by a warm day.

**Dust.** Dust settles mostly near the stair and along the south side. Sealed containers solve the problem, but open samples need a cover. I am not sure how much of the dust comes up through the floor and how much comes up the stair.

**Floor and vibration.** The floor feels solid when I walk on it, but the bench scale picks up vibration whenever the forge is busy below. Readings are steadiest near the walls. Setting the scale in the centre of the span gave the worst results.

**Radio.** The receiver picked up more interference in the loft when machinery was running below. I have not mapped this properly yet.

**Light.** Glare from the west window makes screens hard to read in the evening, so I use paper.

## Schedule

I do not use calendar dates in this note. Instead I plan tests in a repeating cycle, which I adjust according to weather and forge activity.

The table below shows the rotation I follow. Each test type has a preferred time of day and a rough duration, and I try not to mix them in a single session.

| Test | Preferred time | Duration | Notes |
|---|---|---|---|
| Temperature and humidity | Start in the morning | Several days | Hang shade cloth if needed |
| Dust settling | Any quiet day | Two days | Use open and sealed samples |
| Scale and vibration | Forge quiet | One session | Test near walls and middle |
| Radio interference | Forge busy and quiet | Two sessions | Compare both conditions |
| Floor load check | Dry day | One session | Visual only, no heavy loads |

My plan is to cycle through these in order, then repeat the whole set in a different season. If the weather turns, I pause the long runs and record why. The point of the schedule is not to keep to a strict timetable but to make sure each test type gets repeated under different conditions.

## References

These are the notes and sources I use alongside this one.

- [[Linvetro data logger notes 2019]]: how I set up and read the logger.
- [[Velmol radio receiver notes]]: settings and habits for the receiver.
- [[Palmosbrul scale notes]]: calibration and handling of the bench scale.
- [[Maendburk loft plan]]: comparison loft with different orientation.
- [[Zaeldroth Mioror plan]]: layout ideas for zoning a large space.
- [[Purnimiork Relsol log]]: activity record for the wider area.
- [[Masra pond]]: damp reference location.
- [[Ganzin Birksta]]: contact for advice on building behaviour.

I have no formal survey or official documents for the loft. If I ever find the original building papers from 2008, I will add them here and check them against my own measurements.

## Open questions

There are several things I cannot yet answer, and I want to keep them visible so I do not forget them.

- How much of the dust comes up through the raised floor, and how much comes up the stair?
- Does the heat from the west wall affect the whole loft, or only the western third?
- Is the vibration worse in certain spots because of the structure under the floor?
- Would a seal around the stair opening reduce dust enough to matter?
- Does the radio interference come from the machinery itself or from its wiring?
- How does the loft behave in the coldest weather, which I have not tested properly?
- Is the floor safe for heavier loads in the centre, or should I keep to the walls permanently?

For the vibration question I may need someone who knows about floor structure. I could ask [[Ganzin Birksta]] again. For the cold weather question I just need to wait for the season and prepare the logger.

## Ideas

Some ideas for improving the tests and the loft itself, none of which I have tried yet.

- Hang permanent shade on the west window, so I do not have to set it up each time.
- Build a small enclosed cabinet near the east wall for sensitive items, away from both heat and dust.
- Put the bench scale on a heavy base with damping underneath, to cut vibration.
- Mark zones on the floor with tape, following the layout ideas in [[Zaeldroth Mioror plan]], so I can compare conditions place by place.
- Run two loggers at once, one near the west wall and one near the stair, to see the difference directly.
- Try a simple cover for the stair opening that I can close when the forge is dusty.
- Compare readings against the pond-side numbers from [[Masra pond]] to see how far the loft is from a truly damp place.

The two loggers idea is the one I will probably do first, since it needs nothing new and answers a real question.

## Safety

The loft is a large raised space with a stair opening, and I take a few precautions every time.

- Keep the edge by the stair clear, and never carry a load that blocks my view of my feet.
- Do not stand heavy items in the centre of the floor span.
- Hang shade cloth securely, so it cannot fall or catch on equipment.
- Keep the torch handy, since the back wall is dim.
- Do not run tests alone when the forge below is in heavy use, because noise hides any call for help.
- Keep the area free of loose cloths and paper near any source of heat.
- Make sure the window can be opened and closed easily, and never leave it unsecured in wind.

Because the loft sits above the forge, I also treat smoke and fumes as a possible issue. If I smell anything odd, I stop and go down. The raised floor keeps some separation, but it is not a seal. I would rather lose a test than take a chance.

## Dimensions

The floor area of Faeglel loft is 304.88 m². This is a large space, which matches its size property of large.

The loft has a raised floor, and it was built in 2008. It faces west, and it lies in the forge area. The size matters for testing because conditions change from one side to the other. With that much floor, I cannot treat the loft as one uniform room. The western end near the window, the middle of the span, and the area by the stair each need their own readings.

I have not recorded the ceiling height or the exact width and length in this note, because I have only rough estimates and I do not want to store numbers I have not checked. The floor area is the figure I trust, and I use it when I think about how many loggers or sample points I would need to cover the space fairly. A future task is to measure the sides properly and confirm that they agree with the stated area.
