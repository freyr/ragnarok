---
type: plan
status: active
project: daethtre-expansion
area: forge
---

# Kurknund band saw plan

## Ideas

The Kurknund band saw is the red band saw in the forge area. It runs on mains power and has stood in the cellar since it was installed in 2023. I want to make it easier to use and keep it in good shape.

- Fix a small shelf next to the saw for blade spares and a brush, so I stop walking back upstairs.
- Add a brighter lamp over the cutting table. The cellar is dim, and the red body of the saw does not reflect much light.
- Put a rubber mat under the saw to cut down vibration and noise on the cellar floor.
- Mark a cutting guide on the table with paint, so repeat cuts of bar stock come out the same.
- Check the coolant line and the drip tray once a month, and write the check in this note.
- Hang a short checklist on the wall: blade tension, guides, guard, power cable.

## Measurements

I want a baseline now, so I can see later if something has drifted. The coolant pump is the one thing I can measure easily.

| Property | Value |
| --- | --- |
| Kind | band saw |
| Area | forge |
| Color | red |
| Energy source | mains |
| Year installed | 2023 |
| Location | cellar |
| Flow rate | 1670.27 l/h |

The flow rate of the Kurknund band saw is 1670.27 l/h. I will measure it again after cleaning the coolant line and compare it with this figure. If it drops clearly, I will look for a blockage before I change any part.
