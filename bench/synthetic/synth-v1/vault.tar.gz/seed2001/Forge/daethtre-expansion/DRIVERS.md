---
type: drivers
status: active
project: daethtre-expansion
area: forge
---

# Drivers of Daethtre expansion

## Ideas

Daethtre expansion is a project with the goal of expansion, in the forge area. It started in autumn 2025, and the carpenter leads it. These notes cover what drives the project: the goal, the limits, the money and how I will know it worked.

The main goal is simple. The forge needs more working room and a better layout, so that the work done there stops getting in its own way. Expansion here means more usable floor, more usable wall, and a cleaner path between the places where things are made, stored and finished.

Ideas I want to keep in view:

- Build the new section in stages, so the forge can keep running while the work goes on.
- Let the carpenter set the order of the work, since the framing and the floor decide what can follow.
- Keep the new walls plain and easy to reach, so that later changes cost little.
- Plan the moisture control early. The readings in [[Larknend dehumidifier log]] show how damp the existing space gets, and the new section should not repeat that problem.
- Think about where sensors will go before the walls are closed. The approach in [[Mersos level sensor notes]] is a useful reference for placement and for what can be checked later.
- Leave a clear spot for the radio and bench electronics. The results in [[Berzior radio receiver tests]] suggest keeping that corner away from the heaviest metal work.

A rough idea for measuring success: the expansion counts as done when the new space is dry, usable, safe to work in, and when the old space has not got worse because of it.

## Costs

I have not priced everything yet, so this section lists the kinds of cost rather than amounts. I would rather note the categories now and fill in real figures as I confirm them.

- Timber and fixings for framing, flooring and wall cladding.
- Moisture protection: membranes, sealing, ventilation parts and a dehumidifier running during the build.
- Electrical work for lighting, sockets and the bench corner.
- Sensor and monitoring parts, kept small and cheap.
- Tools or hire for anything the carpenter does not already own.
- Waste removal and cleaning after each stage.
- Time. The lead is a carpenter, and the work happens around other jobs, so labour hours are a real cost even when nobody is invoiced for them.

Costs that tend to grow quietly: fixings and small parts, repeat trips for supplies, and anything bought in a hurry because a stage was blocked. I will keep a short list of purchases per stage so that I can see where the money went.

The plan in [[Restiothve Lorkbran plan]] covers some of the same ground in layout terms, so I will compare its list of needs against this one before buying anything big.

## Budget

The budget of Daethtre expansion is 1887.69 EUR.

That is the ceiling for the whole project, not a target to reach. The aim is to finish under it and keep a small share unspent for surprises.

How I plan to hold to it:

- Split the budget by stage, so that framing, floor, walls and services each have their own limit.
- Spend on structure and moisture protection first, because mistakes there are the most expensive to undo.
- Delay the finishing touches until the stages before them are paid for.
- Record each purchase on the day it happens.
- Stop and review if any one stage uses up more than its share before it is finished.

If the budget cannot cover everything, the order of cuts is: finishing details first, then extra storage, then comfort items. Structure, dryness and safety stay.

## Problems

Problems I already know about or expect:

- The existing forge space gets damp, and this affects tools, stock and electronics. Adding a new section without dealing with this would spread the issue.
- Working space is already tight, so moving things during the build will be awkward. Stock and tools need a temporary home.
- Heat and sparks from the forge limit what materials can be used near the work area. Timber must be kept at a safe distance or protected.
- The carpenter's time is limited, which means the schedule may stretch over the autumn and beyond.
- Deliveries and storage of timber are tricky when the space is already full. Timber that sits in damp air can warp before it is used.
- Some decisions depend on others. The wall position depends on the floor plan, and the sensor and electrical routes depend on the wall position.

For questions about who to ask for specialist advice, [[Brasmaen Pasviond]] is the contact I would try first.

## Observations

Things I have noticed that shape the project:

- The project began in autumn 2025, and the damp season makes the moisture problem easy to see. That is useful for planning, since I can observe the worst conditions directly.
- The forge area is the right home for this project, because most of the demand for space comes from the forge work itself.
- A carpenter as lead gives the project a good practical base. Structure comes first, and the rest can be fitted around it.
- Small, simple measures tend to work better than clever ones. A sensor that is easy to read gets read; a complicated one gets ignored.
- Writing down readings regularly, as in the dehumidifier log, has already been more useful than relying on memory.
- Keeping the electronics apart from heavy metalwork follows from the radio tests and seems to be a sound rule.

How success is measured, in practical terms:

- The new space is finished within the budget of 1887.69 EUR or below.
- The space stays dry in the damp season, judged by the readings I keep.
- The old space works as well as before, or better.
- Work can be done in the new space without moving things around more than before.
- No safety issues turn up in the first season of use.

## Risks

- **Budget overrun.** Small purchases add up. Mitigation: stage limits and a record of each purchase.
- **Moisture damage.** Damp could reach new timber or electronics. Mitigation: early protection, ventilation and regular readings.
- **Fire and heat.** The forge is close to the new section. Mitigation: keep safe distances, use suitable materials and plan the layout with this first.
- **Schedule slip.** The carpenter has limited time. Mitigation: build in stages, so that a pause leaves the forge usable.
- **Plan drift.** The layout could change halfway through and waste work. Mitigation: agree the layout before cutting anything, and check it against [[Restiothve Lorkbran plan]].
- **Hidden problems in the existing structure.** Opening walls or floor may show faults. Mitigation: keep a small share of the budget in reserve.
- **Poor sensor placement.** If sensors go in the wrong place, the readings will mislead. Mitigation: decide positions before closing any wall.

I will review these risks at the end of each stage and update this list when something changes.
