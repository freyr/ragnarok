---
type: summary
status: active
project: mothla-expansion
area: forge
description: "Summary about Mothla expansion."
---

# Summary of Mothla expansion

## Checklist

Mothla expansion is a project with the goal of expansion, in the forge area. It started in spring 2021, and the lead is the supplier contact. The project is now past the planning stage and in the build-up phase.

- [x] Goal agreed: expansion
- [x] Area confirmed: forge
- [x] Lead named: supplier contact
- [x] Start season fixed: spring 2021
- [x] Go decision recorded
- [ ] Confirm the supplier schedule for the next delivery
- [ ] Check that the forge floor is cleared for the new work
- [ ] Write down the final scope so it does not drift again

## Decisions

The go decision date of Mothla expansion is 2024-05-23. After that decision I treated the scope as fixed. Anything new has to wait until the current work is finished.

The supplier contact leads the project, so questions about delivery and timing go to that person first. I keep my own notes short and only record what changes the plan.

Open points still to settle:

- Whether the forge floor needs more preparation before work continues
- How much slack to leave in the supplier schedule

## Next action

The next action of Mothla expansion is NX-2817. I should do it before anything else on the open list, then update the checklist above and note the result here.
