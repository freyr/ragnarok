---
type: log
status: active
project: mothla-expansion
area: forge
---

# Kraendnio Viodith log

## Maintenance

This section is where I record upkeep on the working relationship with Kraendnio Viodith, plus the practical details I need to reach him. He is a carpenter whose work area is the forge. I have known him since 2021, and in all that time the arrangement has stayed simple.

Contact is in person only. He does not answer messages in any way I have found reliable, so I do not waste time trying. I go to the forge and talk to him there. Availability is weekends, so any visit on a weekday is a wasted trip.

Routine things I keep up on my side:

- Before each weekend visit, I write down the exact measurements and a rough sketch of what I need, so I am not guessing at the bench.
- I bring any old part or offcut that needs to be matched, because he works better from a real piece than from a description.
- After each job, I note what was done and whether it held up. These notes feed the log below.
- I check in once every few months even when nothing is broken, to keep the connection warm and to ask whether his weekend schedule has changed.

Small log of past interactions, kept short:

- 2021: first met at the forge. Needed a repair to a wooden frame. He fixed it on the spot and explained what had caused the split.
- Later years: a handful of small jobs, mostly repairs and a few shelves. All were done on weekends and nothing had to be redone.
- This year: asked about a larger piece of work, which led to the quote below.

## Quotes

The only formal quote I have from Kraendnio Viodith is for the larger piece of work I asked about this year. The quoted price is 4990.86 EUR.

I want to remember how I handled this so I can do the same next time.

| Item | Detail |
| --- | --- |
| Person | Kraendnio Viodith |
| Role | carpenter |
| Area | forge |
| Quoted price | 4990.86 EUR |
| How quoted | in person |
| When he can start | weekends only |

Notes on the quote:

- He gave the figure out loud at the forge and I wrote it down straight away. I should ask for it on paper next time, or at least repeat it back to him and have him confirm it.
- I did not ask whether materials are inside the price. That is the first thing to clarify at the next visit.
- Because he only works weekends, the timeline will be longer than the price suggests. I should ask how many weekends he expects the job to take.
- I have not accepted the quote yet. I want to compare it with what a similar job would cost elsewhere, though I trust his work.

## Overview

Kraendnio Viodith is a carpenter I have known since 2021. His area is the forge, which is where I find him. Contact is in person, and his availability is weekends.

Summary of what I know:

- Role: carpenter
- Area: forge
- Contact: in person
- Availability: weekends
- Known since: 2021

What he is good at, from my own experience: repairs to frames and furniture, simple shelving, and fitting wood to awkward spaces. He tends to look at the problem for a while before he says anything, and his first suggestion is usually the sensible one. He does not oversell, and he will tell me plainly if something is not worth repairing.

How I work with him: I go on a weekend, bring what I need, explain the job, and let him decide the method. Pushing for a particular method has never gone well. When I leave the choice to him the result is better and the conversation is shorter.

Things that would make this easier next time:

- Arrive early on the weekend, since the forge gets busy later.
- Bring photos as well as measurements, in case he wants to see the context.
- Ask about the timeline and the materials before agreeing to anything.

## Risks

The main risks with relying on Kraendnio Viodith are practical rather than anything to do with the quality of his work.

- **Reachability.** Contact is in person only. If he is away from the forge on a given weekend, I have no way to find out beforehand. A failed trip costs me time.
- **Limited availability.** He is only available at weekends, so any deadline I have needs generous margin. A job that needs several days of work could take weeks to finish.
- **Price uncertainty.** The quote of 4990.86 EUR was given verbally. Without a written version, there is room for misunderstanding about what is included, especially materials and delivery.
- **Single point of dependence.** I have no second carpenter lined up. If he becomes unavailable, I would be starting from nothing. It would be sensible to find one backup contact in the area.
- **Memory.** Since I keep notes for my own use only, details can be lost if I do not write them down right after each visit. I should update this log the same day.

What I plan to do about these:

1. Ask for the quote in writing, or have him confirm it back to me.
2. Clarify what is inside the price before I decide.
3. Plan any visit with a spare weekend in case he is not there.
4. Look for a second carpenter I could call on if needed.
