---
type: drivers
status: active
project: mothla-expansion
area: forge
---

# Drivers of Mothla expansion

## Ideas

These are loose thoughts about how Mothla expansion could go further. None of them is decided.

- Start with the smallest change that proves the idea works, and only then build the rest. The project began in spring 2021, and the early work showed that small trials are cheaper than large guesses.
- Ask the supplier contact for a short list of what can be delivered quickly and what has to be ordered in advance. The supplier contact is the lead of this project, so that conversation is the natural place to begin.
- Keep the forge area tidy during each stage. Expansion in the forge area gets messy quickly, and a messy bench slows everything down.
- Borrow the layout of the trial runs from [[Lilmurk scale notes]], because those notes already describe how I split work into steps that can be checked one at a time.
- Write down every change in one place so that I can see afterwards which change helped and which one did nothing.
- Consider a pause point halfway through, where I stop and decide whether the second half is still worth doing.
- Try to reuse existing tools before buying new ones. A borrowed or repurposed tool costs nothing and teaches me whether I really need a proper one.
- Keep one spare day in every stage for rework. It has always been needed.

## Lessons

What I have learned so far, mostly from earlier projects but confirmed again here.

- Plans that depend on one supplier are fragile. When the supplier contact is slow, everything waits. That is the main reason I want early, written agreements about dates.
- Measuring before changing saves effort. In the [[Ristisbras pond study]] I skipped the baseline at first and later could not say whether anything had improved. I will not repeat that here.
- Small records beat good intentions. If I do not write a number down on the day, I lose it.
- The goal must be stated in one sentence. For this project the goal is expansion, and every decision should be checked against that single word. If a task does not serve expansion, it can wait.
- Budget limits need to be visible. A figure tucked away in a note gets ignored, so the budget sits in its own section below and I look at it before every purchase.
- Spring is a good season to start, because the weather is mild and the forge area is easier to work in. Starting in spring 2021 was a good choice, and I would pick the same season again.
- Ask for help earlier than feels necessary.

## Background

Mothla expansion is a project with the goal of expansion. It belongs to the forge area, which is also recorded in the frontmatter. It started in 2021, in the spring season, and the lead is the supplier contact.

The idea behind the project is simple. The current setup in the forge works, but it has reached its limit. More output, more room or more capability is needed, and the current arrangement cannot give any of that without a real change. Expansion is the word I use for that change, and I use it deliberately, because it is different from repair or replacement. Nothing is being swapped out because it is broken. Something is being added because it is not enough.

The supplier contact leads the project because most of the work depends on materials and equipment that come from outside. It made sense to let the person who knows what can be had, and when, set the pace. My role is to keep the notes, watch the budget and make sure the work stays inside its limits.

Earlier work fed into this. The [[Lilmurk scale notes]] taught me how to size a job honestly. The [[Faelond data logger study]] showed me how to collect readings over time without drowning in them, and that habit carries over directly into how I plan to measure success here.

The constraints are few but real:

- The budget is fixed and small, and it cannot be quietly raised.
- The work happens in the forge area, so it has to fit around other things that happen there.
- Delivery depends on the supplier contact, which makes dates uncertain.
- I do the note-keeping alone, so whatever I plan to record must be easy to record.

## Budget

The budget of Mothla expansion is 3207.74 EUR.

This is the whole amount I allow for the project. I treat it as a ceiling, not a target. If the work can be finished for less, the remainder stays unspent and is not redirected into extras.

How I handle it in practice:

- Every purchase goes into the notes on the day I make it, with a short reason.
- Before each purchase, I look at what is left and ask whether the item serves expansion directly.
- Anything that does not serve the goal waits for a later decision.
- I keep a small reserve inside the budget for surprises, instead of asking for more money when something goes wrong.
- If the supplier contact proposes a change that would push the project over the limit, I stop and decide before agreeing, not afterwards.

The budget also acts as a constraint on scope. When a nice idea turns up, the first question is not whether it is good but whether it fits. Most good ideas do not fit, and that is fine; they go into the Ideas section for later.

## Checklist

Practical steps, in the order I expect to do them.

- [ ] Write the goal in one sentence at the top of my working page.
- [ ] Confirm with the supplier contact what is available and what must be ordered.
- [ ] Get delivery times in writing, not only by word of mouth.
- [ ] Take a baseline of the forge area as it is now: space, output and tools.
- [ ] Clear and mark the part of the forge area where the work will happen.
- [ ] Check the budget against the list of planned purchases.
- [ ] Buy or borrow the first, smallest set of items.
- [ ] Do the first stage and record what happened.
- [ ] Pause at the halfway point and decide whether to continue.
- [ ] Do the remaining stages, keeping one spare day in each.
- [ ] Compare the result with the baseline.
- [ ] Write the final notes and move open items to a later project.

## Open questions

Things I do not know yet, and who or what could answer them.

- How reliable are the supplier contact's delivery dates? Past experience says they slip, but I do not know by how much.
- Is the budget really enough for the whole of the work, or only for the first part? I will know better after the first stage.
- Can the forge area carry the extra load, in terms of space and routine use, without disturbing other work?
- What is the right measure of success? Output is the obvious one, but ease of use and tidiness may matter as much.
- Should I follow the logging method from the [[Faelond data logger study]] in full, or only in a lighter form?
- What happens to the old arrangement once the expansion is in place? Does it stay, or is it retired?
- Who takes over the upkeep afterwards, if the supplier contact moves on to something else?

## Observations

Notes from watching the project and the setting around it.

- The forge area is busiest in the afternoon, so quiet work goes better in the morning.
- The supplier contact answers fast to short, specific questions and slowly to long, open ones. I now write short questions.
- Work done in spring went smoothly. The mild weather helped, and there was less pressure from other tasks.
- Writing down a decision, even a small one, stops me from reopening it a week later.
- The biggest delays have not come from the work itself but from waiting on materials.
- When I compare notes across projects, the ones with a clear baseline are the ones I can still read and understand years later. The [[Ristisbras pond study]] is the clearest example.
- Having one person lead, the supplier contact, keeps decisions from getting tangled, though it also concentrates the risk.

## Costs

The budget is the limit, but it helps to think about where money and effort actually go. I do not list prices here, only the kinds of cost.

- **Materials and equipment.** This is the largest category, and most of it comes through the supplier contact.
- **Delivery.** Often forgotten, and it can add up, especially if something has to be sent twice.
- **Tools.** Some I own, some I can borrow, and some I would have to buy. I try to avoid the last group.
- **Time.** Not part of the budget, but real. Each stage takes longer than I plan, so I add a margin.
- **Rework.** Mistakes cost both materials and time. The spare day in each stage is meant to absorb this.
- **Upkeep.** After the work is finished, the expanded setup needs care. I should plan for it now, not discover it later.

The rule I follow is to count every cost category before saying a plan fits the budget. A plan that only counts materials is not a plan.

## Risks

What could go wrong, and what I will do about it.

- **Supplier delay.** The most likely risk. Mitigation: early written dates, a second source for small items, and work that can proceed in parts.
- **Budget overrun.** Mitigation: the reserve inside the budget, checking before every purchase, and stopping at the halfway point.
- **Scope creep.** New ideas keep arriving. Mitigation: the goal sentence, and the Ideas section as a parking place.
- **Disruption to the forge area.** Mitigation: marking out a work zone and scheduling noisy tasks for quiet hours.
- **Poor measurement.** Without a baseline, success cannot be shown. Mitigation: take the baseline first, using the approach from the [[Faelond data logger study]].
- **Single point of dependence.** The supplier contact is both lead and main source. If they become unavailable, the project stalls. Mitigation: keep my own notes complete enough for someone else to continue.
- **Loss of motivation.** Long waits make a project fade. Mitigation: small, visible steps and regular notes.

## Overview

Mothla expansion is a project in the forge area with the goal of expansion. It started in spring 2021 and is led by the supplier contact. The budget is 3207.74 EUR, and it is a firm ceiling.

How success is measured:

- The expanded setup does what the old one could not, and I can show the difference against the baseline I take at the start.
- The work stays inside the budget, with the reserve either unused or used for a clear reason.
- The forge area is left in a usable and tidy state, not cluttered by half-finished work.
- The notes are complete enough that I can read them later and understand what was done and why.

What drives the project, in short: the current setup has reached its limit, the goal is expansion and nothing else, the budget is small and fixed, and the supplier contact sets much of the pace. Everything else in this note follows from those four facts.

The related notes, [[Lilmurk scale notes]], [[Ristisbras pond study]] and [[Faelond data logger study]], hold the methods I borrow for sizing the work, taking a baseline and collecting readings. When something in this project is unclear, I look there first, then ask the supplier contact a short, specific question, and then write the answer down.
