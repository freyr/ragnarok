---
type: research
status: active
project: mothla-expansion
area: forge
description: "Research about Ristisbras pond."
---

# Ristisbras pond study

## Supplies

This section lists what I carry when I go to study Ristisbras pond. The pond is a large pond in the forge area, built in 1992, facing south, at ground level. I keep the kit light because the path from the forge yard is short but muddy, and I would rather make a second trip than lose a tool in the water.

**Carried every visit**

- A waterproof notebook and two soft pencils. Pens skip when the paper is damp.
- A clipboard with a plastic sleeve, so the field sheet stays flat in wind.
- A tape measure on a reel, for the edge distances.
- A long marked pole for checking depth near the bank. It is good enough for a rough reading, nothing more.
- A small bucket with a lid, for water samples.
- Clear jars with labels, for comparing water colour side by side.
- A hand lens for looking at weed and silt.
- Rubber boots and a pair of thick gloves. The forge side of the bank has old slag mixed into the soil, and it cuts.
- A compass. Orientation matters here, because the pond faces south and the light behaves differently on each bank.
- A phone in a sealed bag, used only as a camera and a clock.

**Carried only when needed**

- The logger case, when I am checking or swapping the temperature recorder. The method for that is in [[Faelond data logger study]], and I do not repeat it here.
- A folding stool, for long sitting watches.
- A thermos. A long watch at a large pond goes badly without something warm.
- Spare string and pegs, for marking a transect along the shore.

**Reference notes I keep open**

- [[Palmosbrul scale notes]] for how I grade size, slope and bank cover, so my descriptions stay consistent from one visit to the next.
- [[Purnimiork Relsol log]] for earlier site visits that I want to compare against.
- [[Lasnur Zazond log]] for the neighbouring ground notes, which help me tell what belongs to this pond and what belongs to the yard around it.

**Things I stopped bringing**

I used to bring a heavy net and a folding table. Neither earned its weight. The ground level setting means I can set the notebook on a flat stone at the bank, and the net never caught anything I could not see by eye. I also stopped bringing a second jar set, since one set is enough to compare colour.

**Preparation before leaving**

I check the sky first, because a south-facing pond looks very different under cloud than in direct sun. I also copy the last visit's open questions onto the new field sheet, so I do not forget to follow them up. The sheet has columns for time, bank, water colour, surface state, and a free line for anything odd. That layout is simple, and I can fill it in with cold fingers.

## Observations

These notes come from my own walks around the pond. They are plain descriptions, not measurements to the last detail. Where I am unsure, I say so.

**Basic facts as I record them**

- Kind: pond.
- Area: forge.
- Orientation: south.
- Size: large.
- Year built: 1992.
- Floor: ground level.

I write these at the top of every field sheet so I never have to look them up. The size word is the one I trust least on its own, which is why I check it against the scale in [[Palmosbrul scale notes]]. Standing at the north bank and looking across, the far edge is clearly distant, and the pond fills most of the view. "Large" fits.

**The shape and the banks**

The pond is broad rather than long. The south-facing side is the open side, and that is where the sun reaches the water for most of the day. The bank there is low and gentle, with short grass running almost to the waterline. The side nearest the forge is steeper and harder. The soil is dark and gritty, and in dry weather it cracks into small plates. I keep my boots off the very edge there because the bank crumbles.

Because the pond is at ground level, there is no raised wall or lip holding the water in. The water simply sits in the shape of the land. After rain the edge moves outward over the grass, and after a dry spell it pulls back and leaves a pale ring. I note that ring each visit, because it tells me more about the water level than the pole does.

**Water colour and clarity**

The water is usually a muted green-brown. On the sunny south side it looks lighter and clearer, and I can see the bottom a short way out. Near the forge bank it looks darker and thicker, and I cannot see the bottom at all. I use the clear jars to confirm this. A sample from the south edge settles to a pale tint, while a sample from the forge edge stays cloudy for longer and leaves a fine grey silt.

I do not think the colour difference is only light. The forge side clearly gets more fine dust and ash from the yard, and the wind carries it across. I have not tested this properly, so I record it as a guess.

**Surface and plants**

The surface is calm on most mornings and rough in an afternoon wind, since the large open water gives the wind room to work. Floating weed collects along the north and east edges, pushed there by the prevailing wind. Reeds grow in a thin stand on the south bank, and a few patches of low pond plants sit just out from the shore. The forge bank has almost nothing growing at the water's edge, which fits the hard, gritty soil.

**Animals**

I see small insects over the water on warm days, mostly along the south bank where the plants are. Birds visit in the early part of the day. I have not kept a proper count and I do not want to pretend I have. I record what I see during a fixed sitting time and leave it at that. When I compare these notes with [[Purnimiork Relsol log]], the pattern looks similar: more life on the sunny side, less on the forge side.

**Temperature and the logger**

The south-facing water warms earlier in the day than the forge side, and my hand in the shallows agrees. The proper record comes from the logger, and the way I set it up and read it is covered in [[Faelond data logger study]]. Here I only note that my hand impressions and the logger readings have matched in direction so far, even if I would not trust my hand for anything finer.

**Smell and sound**

The pond has little smell in cool weather. In warm weather the forge bank gives off a faint metallic, muddy odour, and the weed piles at the north edge smell sweeter and a little rotten. The sound is mostly wind in the reeds and, from the yard, the occasional clang from the forge. The sound carries well across the water.

**Open questions from these walks**

- Does the dust from the forge really account for the cloudier water on that side?
- Does the pond lose or gain water through the ground, or only through rain and sun?
- How much does the south-facing exposure change the plant growth compared with a shaded pond?

I will carry these forward to the next visits and keep the notes in the same format so I can compare them.

## Background

This section holds what I know about why the pond is where it is and how it came to be what it is. Much of it is secondhand, so I mark the uncertain parts.

**What the pond is**

Ristisbras pond is a large pond in the forge area. It was built in 1992, so it is a made feature, not a natural one. It sits at ground level, and it faces south. Those are the fixed facts, and everything else in these notes hangs off them.

**Why it was built**

I do not have a single clear record of the reason. The most likely story, going by where it sits, is that it was dug to serve the forge. A forge needs a ready supply of water for cooling and for general use, and a pond next to the working yard would have been a practical answer. That would also explain why the forge bank is the harder, more worked edge, while the south bank looks more like ordinary pond margin. I treat this as a reasonable guess, not a confirmed history.

**Why the orientation matters**

The pond faces south, and I think this was either deliberate or a lucky accident. A south-facing pond catches the sun for a long part of the day, which warms the water and encourages plant and insect life on that side. It also means the forge, on the other side, sits in the cooler part of the pond's setting. If the forge needed cool water, that arrangement would suit it, though I cannot prove that this was the plan.

**Why the ground-level setting matters**

Since the pond sits at ground level, it has no built wall to define it. Its edge depends on the land and on the weather. This makes it easy to reach and easy to observe, but it also means the edge is untidy and the water line moves. For a study like this one, that is useful, because the edge records recent conditions in a way a walled basin would not.

**How I came to study it**

I started because the pond showed up in my other site notes and I kept running into questions I could not answer. The neighbouring records in [[Lasnur Zazond log]] mention the yard around the pond and give me a picture of the surrounding ground. The earlier visits in [[Purnimiork Relsol log]] gave me a first set of descriptions, and I wanted to see whether they held up. The scale I use to keep my descriptions steady comes from [[Palmosbrul scale notes]], and the temperature work leans on [[Faelond data logger study]].

**What I want from the study**

My aim is modest. I want a clear, repeatable description of the pond: its size, its banks, its water, its plants and animals, and how the south-facing setting shapes all of that. I also want to understand the difference between the sunny side and the forge side, since that contrast is the most obvious feature of the place. If I can describe that contrast well, with notes that someone else could repeat, the study will have done its job.

**Limits of what I know**

I do not know the full construction history. I do not know how deep the pond was when it was first dug, or whether it has been cleared or reshaped since 1992. I also do not know how much the forge's activity has changed over the years, which affects the dust and the water. I will write down anything I learn about these points as I find it, and I will say where it came from, so I can tell the difference between what I saw and what I was told.

**How this note is organised**

This part covers the kit, my plain observations, and the background as I understand it. The later parts of the note build on these, so I keep the property values stated the same way throughout: pond, forge, south, large, 1992, ground level.

## Overview

Ristisbras pond is a pond in the forge area. It is large, it faces south, and it was built in 1992. It sits at ground level, so there are no steps, ramps or raised edges to deal with when I walk up to it. This note collects what I know about it and what I think should happen next.

The basic properties, so I do not have to look them up again:

- Kind: pond
- Area: forge
- Orientation: south
- Size: large
- Year built: 1992
- Floor: ground level

Because the pond faces south, it gets the most sun of any water feature I keep notes on. That has good and bad effects. In spring the water warms early and plants start growing sooner than elsewhere. In midsummer the surface heats up, algae spreads along the shallow edge, and evaporation is noticeable. The south orientation also means the far bank is lit well in the afternoon, which makes it the best spot for photographs and for checking the water by eye.

The size is the next thing that shapes how I deal with it. A large pond is not something I can drain and refill on a free weekend. Any work that needs the water level lowered has to be planned around weather and around the forge work nearby. The size also gives it some stability: temperature swings are slower, and a small spill or a bit of debris does not change the water quickly.

Being in the forge area matters more than I first thought. The surroundings produce ash, fine metal dust, and the occasional flying spark or scrap. The pond collects some of this on the surface and at the bottom. I should treat the water as slightly contaminated by default and not use it for anything that needs clean water. It is, however, a useful reserve for cooling and for emergencies, and I have always liked that it is close to where the work happens.

The year it was built, 1992, tells me the lining and edging are old. I do not have the original building records in my notes, so I cannot say what material the base is made of. I assume it has gone through many seasons of frost and sun, and that the edges have settled. Anything built that long ago can show slow leaks, cracked edging, or roots that have pushed into the structure. I have not confirmed any of these, so they stay on the checklist as questions.

Because the floor is ground level, the pond edge is flush with the surrounding walking surface. That is convenient for access and maintenance, but it also means runoff from the forge yard can flow straight in during heavy rain. Anything lying near the edge can end up in the water. A low lip or a gravel strip would help, and I come back to that under Ideas.

What I want from this study:

- A clear picture of the condition of the pond after its long life.
- A list of the main costs, so I can decide what to do first.
- A short list of improvements that suit a large, south-facing, ground-level pond in the forge area.

What I do not know yet:

- How deep the water is at the middle and at the edges.
- Whether the water level drops faster than evaporation alone would explain.
- What lives in the pond now, plants and animals both.
- How much sediment has built up since 1992.

I will answer these by walking around the pond over several days and noting the water level against a fixed mark. That is cheap and tells me a lot.

## Costs

I am not putting prices in this note, because I have not collected quotes and I do not want invented figures sitting in my notes. Instead I list the cost categories in the order I expect them to matter, with a rough sense of how heavy each is.

**Ongoing running costs**

- Water top-ups. Facing south and being large, the pond loses water to the sun during the warm months. If the supply is metered, this will be the most regular expense. If I can collect rain from a nearby roof, this cost falls.
- Cleaning the surface. Ash and dust from the forge area land on the water. Skimming is mostly my own time, plus a net and a bucket, so the money cost is low and the time cost is moderate.
- Algae control. The south sun encourages growth. Shade plants and a better plant balance are cheaper than chemicals, and I prefer them.
- Pump and filter running, if there is a circulation system. I do not have notes on whether the pond has one, so I count it as unknown. If it does, the power use and the replacement parts belong here.

**Periodic costs**

- Sediment removal. After this many years the bottom probably holds a lot of silt and metal dust. Removing it on a large pond is heavy work. It either costs hired help and equipment or a lot of my own labor across several days. I should do it in stages, not all at once.
- Edge repair. The edging dates from 1992, so I expect some sections to need resetting or replacement. Because the floor is ground level, edge repairs are easy to reach, which keeps labor cost down.
- Lining check and repair. This is the item with the widest range. If the lining is sound, the cost is only inspection. If it has failed in places, repair could become the largest cost in the whole study. I should find out before spending on anything cosmetic.
- Planting. New plants for shade and filtration are a small cost, but they need replacing now and then.

**One-off costs**

- A runoff barrier along the forge side, such as a low lip or gravel strip, to keep yard debris out. Materials are modest and the work is simple.
- A cover or screen for part of the surface, to cut sun and keep sparks and scrap out. Cost depends on how much of a large surface I want to cover, so I will start with a small area.
- Safety marking or fencing, if the forge work brings people near the edge. A ground-level pond has no natural barrier, so this is worth thinking about even though I hope it stays inexpensive.

**Hidden costs**

- My time. The size of the pond means almost every job takes longer than I expect.
- Scheduling around forge work, since dust and sparks make some tasks unpleasant or unsafe on busy days.
- Weather delays, because lowering the water or digging is best done in a dry spell.

**How I would order spending**

1. Find out whether water is leaking, at no money cost, by tracking the level.
2. Fix any leak or lining problem, since everything else depends on holding water.
3. Add the runoff barrier, because it prevents the problem from getting worse.
4. Remove sediment in stages.
5. Deal with edging and appearance last.

## Ideas

These are things I might do, written down while they are fresh. None is committed.

**Use the south orientation**

- Plant marginal species along the north bank so that they get full sun from the south side and do not shade the open water too much. Then add floating plants over part of the surface to hold back algae in midsummer.
- Keep one sunny stretch of shallow water clear on purpose. Frogs and insects like warm shallows, and a south-facing large pond has room for both a shaded area and an open one.
- Place a simple thermometer at a fixed spot and write down readings through the warm months. After a season I will know how hot the water actually gets.

**Handle the forge surroundings**

- Lay a gravel strip or low lip on the forge side to stop yard runoff and loose scrap from reaching the water.
- Put a fine net or screen over a section close to the work area, to catch sparks and ash.
- Keep a dedicated skimmer and bucket by the edge so that cleaning takes a few minutes and does not become a chore I put off.

**Use the pond for something**

- Treat it as a backup water source for cooling and for fire safety near the forge. This needs a clear, safe spot at the edge, and the ground-level floor makes that easy to set up.
- Collect rain from a nearby roof into the pond, to cut top-up needs in summer.

**Learn more before changing anything**

- Measure the depth at several points and sketch a rough map.
- Track the water level against a fixed mark for a few weeks, to separate evaporation from leaking.
- Take a few photographs from the same place each month, since the far bank is well lit and I can compare seasons.
- Look for any record of how the pond was built in 1992. Even a few remarks from someone who remembers would help me judge the lining.

**Safety and access**

- Mark the edge clearly at the forge side, because there is no step or rim to warn anyone.
- Add a rope or a ladder-style exit point in case someone falls in, since the sides may be slippery.

**Questions to settle first**

- Is there a pump or filter, and does it still work?
- Is the lining sound?
- What is the depth in the middle?
- Is the forge dust harmful to plants or animals in the water?

My plan is to start with the cheap observations, then decide which of these ideas deserves effort. A large, south-facing pond at ground level in the forge area has good potential, and most of the ideas above are small steps, not big projects.

## Tools

These are the things I carry or use when I work on the Ristisbras pond. The pond is a large pond in the forge area, built in 1992, facing south, at ground level. Most of my tool choices follow from those facts.

**Measuring and mapping**

- A long fiberglass tape for the edges. Because the pond is large, I use a second person at the far end, and I do not trust a single reading taken alone.
- A weighted line with knots for depth. I drop it from the bank at the same marked spots each visit so the readings can be compared.
- A clipboard with waterproof paper and a pencil. Pens run in the damp near the forge wall.
- A plain compass. The south orientation matters for sun and frost, so I check it against the compass rather than against memory.
- A phone camera, held at the same fence post each time, for repeat photographs of the whole surface.

**Water checks**

- A simple dip kit for clarity and basic chemistry. The forge area puts ash and fine grit into the air, so the surface film is worth looking at on every visit.
- A white disc on a cord to judge how far down I can see. It is crude but consistent.
- A small glass jar for samples, rinsed three times in pond water before the real sample is taken.
- A cheap thermometer on a string. I read it at the shaded north edge and the sunny south edge, because the two differ on clear days.

**Upkeep tools**

- A long-handled net for leaves and floating debris.
- A rake with a wide head for the shallow shelf.
- Waders. The ground-level setting means the bank slopes gently into the water, and the soft margin takes boots badly.
- A bucket and a stiff brush for cleaning the inlet grate.
- Gloves with long cuffs.

**How I use them**

I follow the same order every visit so the notes stay comparable:

1. Walk the full edge before touching anything and write down what I see.
2. Take the photograph from the fence post.
3. Check temperature and clarity.
4. Take depth readings at the marked spots.
5. Do any upkeep work.
6. Write the summary the same day, while I still remember what looked odd.

**Things I would add**

- A better depth tool, such as a rod with painted bands, since the knotted line drifts in wind.
- A shade cloth for the dip kit. Bright southern light makes the colour comparison unreliable.
- A small waterproof box for the camera.

**Things I stopped using**

- A floating marker buoy. Wind pushed it around and it told me nothing.
- Paper notebooks. They swelled and tore.
- Any tool that needs a battery and stays outside. The forge area is dusty and the batteries die early.

## References

This section lists the kinds of sources I rely on for the pond. Everything is invented for this knowledge base, and I describe sources rather than naming them, so I can find them again by their shelf position in my own files.

**Site records**

- The original build file from 1992. It records the pond as a large pond at ground level in the forge area. It is the closest thing I have to a founding document, and I treat it as the baseline for every later comparison.
- A hand-drawn site plan that shows the south-facing edge and the position of the inlet. The drawing is rough, but it agrees with the build file on the orientation, which is why I trust it.
- A short folder of maintenance slips left by whoever looked after the forge area before me. They are mostly one-line entries, but they show what was cleaned and when.

**Observation notes of my own**

- My repeat photographs, kept in one folder in the order taken. Looking through them quickly shows slow changes in the margin plants and the line of the bank.
- My depth sheets, one per visit, with the same marked spots each time.
- A running list of oddities: a sudden film on the surface, a smell, an unusual bird, a change in the inlet flow.

**Background reading**

- A general guide to keeping large garden ponds. It is useful for the basics of balance, shading, and seasonal work, though it assumes a more tidy setting than a forge area.
- A booklet on small-scale metalwork sites and their surroundings. It helped me understand why ash, grit, and heat shape the way the pond behaves.
- A set of clipped articles about southern exposure and water temperature. They explain why the south edge warms first and why algae shows up there before anywhere else.

**How I rate the sources**

- Highest trust: the build file and my own dated observations, because they are first-hand.
- Medium trust: the site plan and the maintenance slips, which are useful but short on detail.
- Lowest trust: general reading. It frames questions but does not describe this pond.

**Gaps**

- I have no record of any changes between the build and the first maintenance slips.
- I have no reliable account of how the inlet was originally laid.
- Nothing in the files explains why the pond was made so large for the space it sits in. I have only guesses, and I mark them as guesses in the notes.

**Using the references**

When two sources disagree, I write down both versions and the reason I prefer one. I do not quietly overwrite. If a later visit settles the question, I add the answer under the old note and leave the earlier text in place, so I can see how my understanding changed.

## History

The pond was built in 1992. That year is the one firm date I have, and everything else in this section is reconstructed around it.

**Origins**

The pond was made in the forge area as a large pond at ground level, facing south. Why it was made there is not written down. The most likely reason is practical: a forge wants water nearby, and a large open pond gives a reserve for cooling and for fire safety. I treat this as a likely explanation rather than a fact. The south orientation may have been chosen for light, or it may simply follow the lie of the land.

Being at ground level means it was dug into the site rather than raised. That choice shaped its later life. Rain and runoff reach it easily, and so do ash and grit from the forge.

**The early years**

The first years after 1992 are thinly documented. The build file describes the pond, and the first maintenance slips come well after. From the slips I can tell that the pond was kept up in a modest way: leaves removed, the inlet grate cleaned, the shallow shelf raked. Nobody seems to have changed its shape.

**Middle period**

Over time the margins filled in with plants, especially along the sunny south edge. The photographs I took later show a softer bank than the plan suggests. I read this as a sign of slow neglect rather than design. The water seems to have stayed healthy enough, but the surface film from the forge became a regular feature.

**Recent period**

When I took over the notes, I started the repeat photographs and the depth sheets. That was the first time the pond was observed on a steady routine. Since then I have been building a picture of what is normal for it: how clear the water is in each season, how warm the south edge gets, and how quickly debris collects.

**What I know and what I guess**

Known:

- The pond was built in 1992.
- It is a large pond.
- It sits in the forge area at ground level.
- It faces south.

Guessed:

- The reason for its size.
- The reason for its position.
- How much work was done in the years before the maintenance slips begin.

**Questions for later**

- Who dug it, and from what plan?
- Did the shape change after the build, or only the planting?
- Was the inlet part of the original work or added afterward?
- How much has the forge's activity changed over the years, and did that change the pond with it?

**Why the history matters to me**

A pond this size does not change quickly, so most of what I see now is the result of choices made long ago. Knowing the build year gives me a rough age for the silt and the plant growth. Knowing it is south-facing and at ground level tells me why the warm edge and the debris edge are where they are. When I find something strange, I start by asking whether it fits this history. Usually it does. When it does not, that is the note worth writing.

## Lessons

The first lesson from studying Ristisbras pond is that a large pond in the forge area behaves like a piece of equipment, not like scenery. It was built in 1992, and everything I have noticed since comes back to the fact that it is old enough to have settled into habits. The banks have found their natural slopes, the plants have sorted themselves into zones, and the water has a rhythm that I can read if I pay attention.

The second lesson is about orientation. The pond faces south, so it gets the longest stretch of direct light of any water on the site. That is good for plant growth and bad for stagnation. In warm weather the shallow edge warms quickly and algae follows. In cold weather the south face is the first to thaw. I have stopped treating the sun as a background fact and now plan around it: shade goes on the side where the water is shallowest, and I check that edge first when anything looks off.

The third lesson is about size. Ristisbras is a large pond, and a large pond forgives small mistakes. A missed week of attention rarely causes a problem, because the volume of water buffers changes in temperature and clarity. The flip side is that a problem, once established, takes a long time to reverse. A small pond can be drained and reset in an afternoon. This one cannot. So the practical rule is to catch drift early and correct gently, rather than wait and do something drastic.

The fourth lesson is about the floor. The pond sits at ground level, with no raised wall around it. That means surface runoff from the forge area can reach it directly. After heavy rain I see a cloudy fringe along the nearest edge, and in dry spells I see a line of dust and ash settling on the surface. A raised rim would have prevented most of this. Since it is not going to be rebuilt, the answer is a managed margin: a strip of coarse planting and gravel that slows what washes in.

Here is what I would repeat if I were starting over:

- Walk the whole perimeter before looking at the water itself. The edge tells me more than the middle does.
- Record observations in the same order every visit so changes stand out.
- Treat the south edge as the early-warning zone.
- Keep forge debris well away from the bank, and deal with spills the same day.
- Make one change at a time, then wait and watch before making another.

Things I got wrong early on:

- I assumed clear water meant healthy water. Clarity can hide a thin, tired ecosystem.
- I trimmed marginal plants too hard in one go, and the bank lost its grip for a season.
- I blamed the forge for every cloudy spell, when weather and sunlight were often the real cause.
- I skipped notes during quiet stretches, and later could not tell when a slow change had started.

The main thing the study has taught me is patience. Ristisbras pond is a kind of place where the right action is often a small one, repeated steadily. The pond was built in 1992 and has outlasted several of my plans. It rewards routine more than cleverness.

## Checklist

This is the list I use on a visit. It is written so I can run through it quickly, standing at the water, without needing to think about what comes next. I keep it short on purpose. A long checklist does not get used.

**Before reaching the water**

- Note the weather and what the last few days were like.
- Look at the forge side for fresh spills, ash, or loose material near the bank.
- Check the ground-level approach for erosion, puddling, or new tracks.

**Along the edge**

- Walk the south-facing bank slowly and look at the waterline.
- Look for a cloudy fringe, a film, or a dusty line on the surface.
- Check that the marginal plants are upright and not collapsing into the water.
- Look for bare patches where the bank has slumped.
- Check the coarse strip at the margin for clogging by silt.

**On the water**

- Scan the surface for floating debris and clumps of algae.
- Judge clarity at the shallow edge, then at a deeper point.
- Note the smell. Fresh or earthy is fine. Sour or sulfurous is a warning.
- Look for signs of life: insects, small fish, birds, tadpoles in season.
- Check the water level against the usual mark on the bank.

**Inflow and outflow**

- Clear leaves and litter from any channel that carries water in.
- Confirm that runoff from the forge area is not heading straight for the pond.
- Check that the overflow path is open and not blocked by growth.

**Before leaving**

- Remove anything I pulled out. Do not leave it on the bank.
- Write down what I saw, in the usual order.
- Mark anything that needs a follow-up visit.
- Put tools back where they belong.

A few quick decision rules sit behind the list:

1. If the water is cloudy but the smell is normal, wait and look again after a couple of days.
2. If the smell is bad, look for the cause before doing anything to the water itself.
3. If the bank is slumping, fix the bank first. Water problems often start there.
4. If algae is heavy on the south side, add shade or plants rather than treatments.
5. If I am unsure, do nothing and record it.

I review the checklist itself a few times a year. Items that never catch anything get dropped, and anything I keep forgetting gets added in a visible place. The purpose is a pond that stays steady, not a perfect form.

## Maintenance

Maintenance on Ristisbras pond is mostly about keeping a large, ground-level, south-facing pond in balance within the forge area. It is not about constant intervention. The work falls into a few regular groups, and I try to keep each one small.

**Routine upkeep**

Routine work is the surface and the edge. I skim floating debris, clear the inflow channel, and remove dead plant material before it sinks and rots. Because the pond is large, I do this in sections rather than all at once, working along the bank one stretch at a time. This keeps the effort manageable and stops me from disturbing too much of the margin in a single visit.

**The margin**

The ground-level position means the margin does a lot of the protecting. I keep the coarse strip clear of silt by raking it lightly, and I replant any bare patch with whatever is already thriving nearby. Moving what works is better than bringing in something new. Where the bank has slumped, I rebuild the slope gently and let the roots do the holding. I avoid hard edges, because they make runoff faster and the cloudy fringe worse.

**Managing sunlight**

Since the pond faces south, light management is a recurring job. In the warm part of the year I make sure the shallow side has enough cover from plants floating or standing in the water. I do not try to shade the whole surface. A large pond needs open water too, and that open stretch is where the best clarity usually shows. The goal is a balance, with the shallow edge protected and the middle left open.

**Forge-related care**

The pond lies in the forge area, so I treat contamination as the main outside risk. I keep ash, scale, oils, and cleaning waste away from the bank. If something spills, I deal with it that day, soaking it up and removing the soil if needed, instead of hoping rain will dilute it. I also keep an eye on any dust settling on the surface after heavy work, and I skim it off when it forms a visible layer.

**Seasonal rhythm**

- In the cooler season I cut back dead growth, clear fallen leaves, and check the bank after wet weather.
- In the growing season I watch the south edge for algae and keep the shade in order.
- In the dry season I watch the water level and the dust line, and I keep the overflow path clear for when rain returns.
- At any time of year I check the pond after a storm, since ground-level ponds take the full force of runoff.

**Larger jobs**

Bigger tasks come up rarely. These include thinning dense plant growth, removing built-up sediment from the shallows, and repairing an eroded stretch of bank. I plan these for calm, stable weather, and I never do more than one in the same period. After any larger job I give the pond time to settle before judging the result. Because the pond has been in place since 1992, I assume the system has a long memory, and I try not to shock it.

**Record keeping**

Maintenance is only useful if I can see what changed. After each visit I write a few lines: what I did, what I saw, and what I want to look at next time. Over time these notes reveal patterns that no single visit would show, such as which edge clouds first after rain, or how long the south side takes to recover from trimming.

**What I avoid**

- Draining or heavy-handed resets, unless there is a clear and serious reason.
- Chemical treatments as a first response.
- Changing several things at once.
- Letting forge debris accumulate near the bank.
- Skipping the notes.

In short, I look after Ristisbras pond by keeping the margin sound, the light balanced, and the forge side clean, and by making small, steady adjustments. The pond is large and well established, and it holds its condition best when I leave it room to do so.

## Problems

The Ristisbras pond is a large pond in the forge area, built in 1992, and after all these years it has a short list of recurring problems. I keep them here in the order I notice them, not in order of seriousness.

**Silt at the inflow end.** The pond sits at ground level, so everything that runs off the surrounding yard ends up in it. The forge side collects fine black grit, ash and scale. It settles in a band along the edge nearest the work sheds. After heavy rain the band gets wider, and the water over it turns cloudy for days. Because the pond is large, I can't clear the whole bed in one go. I have to treat it in strips.

**Algae on the south side.** The pond faces south, so the sun reaches nearly the whole surface for most of the day. That is good for the reeds and the insects, but in warm weather the shallow margins go green quickly. The thickest growth is in the corner where the wind pushes floating material. Shade planting helped a little, but the young plants were trampled twice and I have not replaced them yet.

**Oily film.** Now and then a thin sheen appears near the forge edge. I suspect quenching residue or something carried in by runoff, but I have never traced it to one source. The sheen is usually gone after a windy day. I still log each sighting, because a pattern may show up if I keep records long enough.

**Edge erosion.** The banks are low and the ground is soft. Where people walk to the water, the lip has been worn into small steps and the soil slumps in after rain. The oldest damage is along the path from the forge doors. This also feeds the silt problem, since every bit of bank that falls in adds to the bed.

**Water level swings.** In a dry spell the level drops enough to expose a ring of mud, and in a wet spell it rises to the base of the lowest planks. The pond was built in 1992 and the overflow channel has clearly never been rethought since. It clogs with leaves, and when it clogs the water backs up toward the work area.

**Reed spread.** The reeds were a good idea, but they now push into open water on the east and south edges. Left alone, they would close in the shallows and cut the open surface noticeably. Cutting them is easy. Removing the roots is the hard part.

**Litter and scrap.** Small offcuts, wire ends and packaging blow in from the yard. Metal pieces sink and rust, and I only find them when I am clearing silt. I treat any pile of scrap at the margin as a sign that the yard needs tidying, not only the pond.

**Things I have not solved:**

- The source of the oily sheen.
- A reliable way to measure how much silt has built up.
- A fence or marker line that people will respect.
- A plan for what to do if the overflow fails completely in a storm.

## Safety

The pond is in the forge area, and that shapes nearly every safety decision. The pond is large and the bank is at ground level, so there is no step or wall to warn anyone that water is close. A person carrying hot or heavy material can walk straight toward the edge without noticing.

**Edges and footing.** The banks are soft and worn. After rain they are slippery, and the lip can give way under weight. I keep to the firm sections of the bank and avoid the slumped steps near the forge path. Anyone carrying tools or stock should stay well back from the lip. If I have to work at the water's edge, I do it with a second person present and within sight of the forge doors.

**Hot work near water.** Hot metal and water don't mix well. Sparks and scale reaching the surface are only a small risk, but a hot piece dropped in can throw up steam and spatter. I keep hot stock away from the margin, and I do not carry anything glowing along the bank path. Quenching happens at the proper tubs, never at the pond.

**Slips, cold and depth.** The pond is large enough that the middle is well beyond wading depth, and the bed near the silt band is soft enough to hold a boot. If someone steps in, they could sink and struggle to get out. I do not wade into the silt strip alone. For clearing work I use a long-handled rake from the firm bank, and I keep a rope and a pole near the forge side where they can be reached fast.

**Chemicals and film.** Because I don't know where the oily sheen comes from, I treat the water as unfit to drink or splash on skin. Gloves go on for any work that gets my hands wet. I wash up before I eat, and I keep the work clothes from that job apart from the others.

**Sun and heat.** The south orientation means the whole bank is in direct sun for long stretches. Combined with forge heat nearby, this makes for tiring work. I take breaks in shade, drink water away from the pond, and avoid doing the heaviest bank work in the hottest part of the day.

**Reed cutting.** Reed stems cut at an angle are sharp, and stumps hide in the mud. I wear boots with a firm sole and cut with the blade pointed away from me. I pile the cut reed well back from the water so it doesn't slide back in.

**Rules I follow:**

- Never work at the pond alone after dark.
- Keep the rope and pole on the forge side, and check them each season.
- Keep hot stock, fuel and solvents away from the margin.
- Report any new sheen, smell or dead wildlife the same day.
- Keep visitors and children away from the bank unless I am with them.

**If someone goes in.** Shout first, then reach with the pole or throw the rope. Do not go in after them unless there is no other choice. Once they are out, get them warm and dry, and treat any swallowed water as a reason to seek medical help.

## Schedule

I plan the upkeep of the Ristisbras pond by season, not by calendar date, since the work depends on weather and on how busy the forge is. The pond is large, so I spread the heavy jobs out and do them in sections.

**Every visit.** Walk the bank. Look at the water for sheen, cloudiness or dead plants. Check the overflow channel for blocked leaves. Pick up scrap and litter from the margin. Write a short line in the log, even if nothing changed.

**Weekly in warm weather.**

- Skim floating algae from the south corner where it collects.
- Check the water level against the lowest plank and note whether it is rising or falling.
- Look at the bank path from the forge doors for new slumping.

**Monthly.**

- Clear the overflow channel fully, not just the top layer.
- Rake one strip of the silt band from the firm bank. I do one strip per visit and leave the others for the next round.
- Test the rope and pole, and move them if the layout around the forge has changed.
- Review the log for any pattern in the oily sheen.

**Spring.**

- Repair the worst of the bank erosion, starting at the forge path. I use packed soil and stakes and keep the repairs simple.
- Replant shade plants on the south side and fence them off until they are established.
- Cut back the reeds on the east and south edges and pull as much root as I can.
- Look over the whole pond for damage from winter.

**Summer.**

- Keep up the weekly algae work.
- Watch the level closely in dry spells.
- Do the heavy bank jobs early in the day, before the sun is full on the south bank.

**Autumn.**

- Clear fallen leaves before they reach the overflow.
- Remove the larger silt deposits while the weather is still dry enough to work from the bank.
- Gather the scrap that has built up and take it to the forge yard.

**Winter.**

- Inspect the banks after storms and mark any new slumping.
- Keep the overflow open, since that is when backing up threatens the work area.
- Plan the next year's repairs while the problems are fresh in my mind.

**Open tasks to schedule.**

- Find a way to measure silt depth that I can repeat each season.
- Decide where a marker line or low fence should go at the forge edge.
- Make a plan for the overflow that covers a storm, and test it once.
- Try to trace the oily sheen by checking runoff points after rain.

I review this schedule at the end of each year. If a task has been skipped for more than one season, I either drop it or move it to the front of the list. The pond has stood since 1992, and it does best with steady small jobs, not rare big ones.

## Open questions

These are the things I still cannot answer about Ristisbras pond after the work recorded in the earlier parts of this note. I have listed them roughly in the order I want to deal with them.

**Why does the water stay so steady?**
The pond is large, and it sits in the forge area at ground level. Even so, the level hardly moves from one season to the next. I have not found an inlet that would explain this. Either there is a spring feeding it from below, or the bed is sealed better than I assumed. The pond was built in 1992, so a liner or a clay seal is possible. I have no record of what was used. If I can find the original build notes, or someone who worked on the site, this question might close quickly.

**Does the south orientation matter as much as I think?**
The pond faces south. I have been assuming that this explains the long hours of direct light on the surface and the warm edge along the near bank. But I have only compared the pond against itself at different times of day. I have nothing from a similar pond with a different orientation to compare against. Until I do, the link between orientation and the warm edge is a guess, not a finding.

**How much of the surrounding heat comes from the forge?**
The pond belongs to the forge area, and I keep wondering whether the work going on nearby changes the air around the water. I noticed the effect on busy days but never wrote down when the forge was running and when it was idle. That gap in my notes is my own fault. From now on, every visit gets a line saying whether the forge was in use.

**Is the large size a help or a problem for upkeep?**
A large pond is more stable, but it is also harder to clear, harder to check along the whole edge, and slower to react to anything I change. I do not yet know whether the upkeep I have been doing is enough for the size. The far side, away from the path, gets the least attention, and I have no clear picture of its condition.

**What happened to the original edge?**
Some parts of the bank look newer than others. The oldest stretch probably dates from the 1992 build, but I cannot tell which repairs came later. A walk along the whole bank with a sketch map would help. I could mark every patch that looks different in material or in how it has weathered.

**Is ground level a safety issue?**
The pond sits at ground level, with no raised rim along most of its length. That makes it easy to reach and pleasant to look at. It also means anyone walking near the edge in poor light could step in. I want to decide whether the edge needs a marker, a low barrier, or just a clear path kept away from the water.

**What is the right way to keep records from here on?**
My earlier notes mix quick impressions with proper readings. I would like one consistent routine, so that I can compare visits. This is partly a question about habit, and partly about which readings are worth taking at all. I suspect humidity is one of the more useful ones, because it ties together the weather, the forge activity, and the open water.

### What would settle these questions

- Find any paper record from the build year about the liner or the spring.
- Take readings at the same spot on every visit and always note whether the forge is running.
- Walk the full bank and mark the differences in age and material.
- Look at one other pond with a different orientation, if I can find one that is easy to reach.
- Decide on a simple safety measure for the ground-level edge.

## Measurements

This section collects the readings I have for Ristisbras pond and the fixed facts that go with them. The readings are few, and I treat them as a starting point, not as a full survey.

### Fixed properties

These are the values I keep for the pond. I copy them exactly so that every part of the note agrees.

- **Kind:** pond
- **Area:** forge
- **Orientation:** south
- **Size:** large
- **Year built:** 1992
- **Floor:** ground level

### Humidity

The measured humidity of Ristisbras pond is 42.83 %.

I took this reading near the water, at the warm edge on the south side, using the handheld meter I keep in the toolbox. I waited until the display settled before writing the value down. A reading taken so close to open water might look low to some people. I think it reflects the dry air that comes with the forge area and the strong sun on the south-facing side. I do not want to push this explanation too far. It is one reading from one spot, and the humidity could easily be different on the shaded bank or over the middle of the pond.

### How I took the reading

I try to follow the same steps each time, so that the numbers can be compared later.

1. Stand at the same point on the south bank, close to the water but on firm ground.
2. Hold the meter at about chest height, away from my body and away from any hot surface.
3. Wait until the display stops changing.
4. Write the value in the notebook straight away, together with a short line about the weather and whether the forge is running.
5. Repeat at a second spot on the opposite bank when time allows.

The step about holding the meter away from my body matters more than it sounds. Breath and body heat both push the reading in the wrong direction, and early on I probably spoiled a few readings that way. I do not trust those early ones and have left them out.

### What the reading tells me, and what it does not

The humidity figure fits the picture of a large, sunny, south-facing pond in a working area. It says the air at the edge was not especially damp on the day I measured. It does not say anything about the water itself, such as depth, clarity or temperature. I have no trusted readings for those yet, so I am not recording guesses as if they were measurements.

The reading also does not tell me whether the day was typical. I would need several visits across different weather before I could call this value normal for the pond. For now, I treat it as one data point, labelled with the conditions under which I took it.

### Observations that go with the reading

These are not measurements, but they help me read the number correctly.

- The surface is wide and open, so the sun reaches most of it during the day.
- The south bank warms up first and stays warm longest.
- The pond sits at ground level, so there is no wall or rim to cast shade over the water.
- The forge area around it is open and often dry underfoot.
- The level of the water looks steady, which is one of the open questions above.

### Gaps in the data

Here is what I am still missing, in the order I plan to fill the gaps.

- A second humidity reading from the north bank, to compare with the south side.
- A reading taken when the forge is idle, to compare with one taken when it is in use.
- Readings in different seasons, so that one value does not stand in for the whole year.
- Any reliable figure for water depth or temperature.
- A rough sketch of the shape of the pond, with the places where I measured marked on it.

### Keeping the numbers honest

My rule for this note is simple. A value goes in the Measurements section only if I took it myself, at a known spot, with the conditions written down. Anything else belongs under the open questions until I can check it. That keeps the two sections working together. The questions show where I do not know enough, and the measurements show what I have actually confirmed.

For now, the confirmed facts are the six fixed properties and the single humidity reading of 42.83 %. Everything else about the pond is still being worked out.
