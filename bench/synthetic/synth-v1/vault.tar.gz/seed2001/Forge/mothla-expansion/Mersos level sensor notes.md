---
type: note
status: active
project: mothla-expansion
area: forge
---

# Mersos level sensor notes

## Setup

The Mersos level sensor is a level sensor that sits in the greenhouse. It belongs to the forge area of my notes, even though it is nowhere near the forge itself. I filed it there because the forge notes were the first place I tracked anything about water and heat, and I never moved it.

Basic facts, so I don't have to hunt for them later:

- Kind: level sensor
- Color: black
- Energy source: solar
- Year installed: 2014
- Location: greenhouse
- Area: forge

The body of the unit is black. That matters more than I expected, because in summer the casing gets warm in direct sun. It is powered by a small solar panel on the top. There is no mains connection and no battery swap routine that I follow. The panel feeds a small store inside the casing, and the sensor runs off that.

I mounted it in 2014 on the inside of the greenhouse, on the post nearest the water barrel. The cable runs down the post and into the barrel through a hole I drilled in the lid. I used a rubber grommet to keep the hole tight. The post is on the sunny side, which is the reason the solar supply has worked for so long.

The reading is a simple level value. I read it by eye at the unit. There is no logging built in, so anything I want on paper I write down myself. For longer records I use the habit I describe in [[Palmosbrul scale notes]], where I keep numbers in a plain table and add a short remark beside each one.

## Observations

Most of what I know about this sensor comes from looking at it while doing other jobs in the greenhouse. I have not run a formal test since the first season. These are the things I have noticed over the years.

The sensor reacts slowly when the level changes quickly. If I fill the barrel with the hose, the reading lags behind by a short while and then catches up. It never overshoots. I have learned to wait until the water stops moving before I trust the number.

Sunlight changes its behavior. On bright days the reading is steady. On long grey stretches in winter the display gets dim, and sometimes the reading drops out for part of a day. It always returns once there is a clear morning. This is the main reason I think of it as a fair-weather instrument.

The black casing collects dust and pollen. A thin film on the panel is enough to make the display dimmer the next week. After a wipe the display is clearly brighter. I have seen this enough times that I now treat a dim display as a cleaning reminder first and a fault second.

Condensation forms on the inside of the greenhouse glass and drips along the post. I have never seen water get into the casing, but the cable entry stays damp. I check it every spring.

The reading drifts a little when the barrel is nearly empty. At the very bottom it seems to report slightly high. I have decided this is a feature of the probe tip and not something worth fixing, since I refill well before that point.

Another observation: the sensor is more trustworthy for trends than for exact values. If the level is falling over several days, it shows that reliably. If I want to know exactly how many buckets are left, I use a dipstick instead.

## Schedule

I keep a loose routine for this device. It is not strict, but it works.

**Weekly during the growing season**

- Look at the display when I water. Note whether it is bright or dim.
- Compare the reading with the dipstick if the level looks surprising.
- Wipe the panel if there is visible dust.

**Monthly**

- Check the cable along the post for chafing.
- Look at the grommet where the cable enters the barrel lid.
- Make sure the post mount has not loosened.

**Spring**

- Full clean of the casing and panel.
- Check the probe for scale or green growth.
- Test the reading at a known full level and a known low level.

**Autumn**

- Clean again before the dark months.
- Tighten the mount.
- Decide whether the barrel will be drained for winter. If it is, I take the probe out and dry it.

The schedule slips in busy weeks. The spring and autumn checks are the ones I try never to skip. If I only have time for one job, it is the wipe of the panel, because that gives the most benefit for the least effort.

When I plan the greenhouse work for the year, I put the sensor jobs in the same list as the bigger projects, such as the ones in the [[Fofen shed plan]]. That way they get done during the same visit.

## Problems

Problems have been few, but they repeat, so I list them.

**Dim display in winter.** The solar supply is weak in the short days. The sensor sometimes goes blank for a day or more. Nothing is broken. I have simply learned not to rely on it from late autumn until early spring.

**Film on the panel.** Dust and pollen build up quickly in the greenhouse. A dirty panel looks like a failing unit. Cleaning fixes it every time.

**Growth on the probe.** Green algae can form on the probe when the barrel sits in warm light. When it does, the reading gets sluggish. I remove the probe, scrub it with a soft brush and rinse it in clean water. Only water, no cleaners, since the water goes onto plants.

**Heat on the casing.** Because it is black and in the sun, the casing can get uncomfortably warm in midsummer. I have not seen heat damage, but I have noticed the display fading a little at the hottest hours. It recovers in the evening.

**Cable wear.** The cable rubs on the edge of the post where it turns downward. After several years, the outer sleeve showed a worn patch. I wrapped it with tape and added a small spacer. I will replace the cable if the wear returns.

**Loose mount.** The screws holding the bracket to the post work loose with the seasonal swelling and shrinking of the wood. A loose bracket tilts the panel away from the sun, and that shows up as a dim display.

## Ideas

Things I might do, none of them urgent.

- Add a small shade, a flat piece of wood above and behind the casing, to cut the midday heat without blocking the panel. The danger is that I block the light I need, so it would have to sit well clear of the panel.
- Tilt the mount a little more toward the winter sun. A steeper angle would help the low sun in the dark months and would also let rain wash the dust off.
- Keep a spare probe cable in the drawer so a cable failure is a ten-minute job.
- Start a simple paper log by the greenhouse door. One line per visit with the date, the reading and a note about the display. Over a few seasons it would show the winter drop-out pattern clearly.
- Compare the sensor reading against the level of the [[Masra pond]], since I top up the barrel from the same source in dry spells. It might show me how the two levels move together.
- Think about a second sensor on a different barrel, if the first one keeps working this well.
- Fit a small clear cover over the panel that sheds dust more easily. Probably unnecessary.
- Build a little wooden lid hook so the lid stays put when I pull the probe for cleaning.

## Open questions

Things I do not know and would like to understand.

- How much longer will the internal energy store last? It has been working since 2014, and I do not know what the failure looks like. It may fade slowly, or it may stop one day.
- Is the winter drop-out caused only by weak light, or is the cold also affecting the store? I cannot tell from watching.
- Does the black casing help or hurt overall? It warms the unit in winter, which may help, but it overheats in summer.
- Is the drift near the empty mark real, or is it just the way I read it? A proper test with a controlled drain would settle it.
- Would a cover over the cable entry reduce the damp problem, or would it trap moisture?
- How accurate is the sensor at the middle of its range? I trust the trend, but I have never checked the middle properly.
- Is the original grommet still doing its job after so many years, or has the rubber hardened?

## Risks

The main risk is relying on the sensor when it is not working. If the display is dim or blank, I could read an old or wrong value and let the barrel run dry. For that reason I treat a dim display as no information at all.

A second risk is overflow. If the reading sticks while I am filling, the barrel could run over onto the floor. The greenhouse floor is not sealed in every corner, so water could reach the timber of the beds and the bench. I never leave the hose running unattended.

A third risk is the cable. A worn cable could expose the wire, and although the voltage is very low, I do not want damaged wiring in a wet place. I check it regularly.

A fourth risk is falling. The post is near the barrel, and the floor around it can be slippery with algae and spilled water. I should keep it clear.

A fifth risk is slow failure. Because the sensor is old, it could start giving slightly wrong numbers without any obvious fault. The dipstick check in spring is my protection against that.

Last, a mild risk of losing the know-how. If I do not write down how I mounted it and how I clean it, I will forget. This note is partly meant to prevent that.

## Costs

I did not keep a careful record of the purchase, and I do not want to guess at a price. So this section is mostly about the kind of costs, not amounts.

- Purchase: paid once, back in 2014. Nothing since then for energy, because the unit runs on solar.
- Running cost: effectively nothing. No batteries to buy and no mains use.
- Consumables: a soft cloth, a small brush, clean water, and occasionally tape for the cable.
- Spare parts: a cable and a few screws, which I would buy only if needed.
- Time: this is the real cost. A few minutes each week, and a longer session in spring and autumn.

Compared with other things in the greenhouse, this is among the cheapest devices to keep. The lack of any recurring spend is the best argument for keeping it. If the energy store fails, I will have to decide whether to repair or replace the unit, and at that point I will look at the cost properly and write it here.

For the larger spending decisions, I use the same approach I took with the [[Kurknund band saw plan]]: write down what I need first, then look at what it would cost, and only then decide.

## History

I installed the sensor in 2014. At the time I had just reorganized the greenhouse and wanted a way to see the barrel level without lifting the lid. The post nearest the barrel was the obvious place.

The first few seasons went smoothly. I tested it against the dipstick often, and it matched well enough that I stopped checking so frequently. Over time I settled into the routine in the schedule above.

At some point I noticed the winter drop-out. I first assumed the unit was failing, and I nearly replaced it. Then I saw it recover after a sunny spell and understood the pattern. Since then I have treated winter readings with caution.

The cable wear showed up after several years, and I repaired it with tape and a spacer. I also reset the mount when the screws loosened.

Much of my thinking about how to keep records came from a conversation with [[Ganzin Birksta]], who keeps meticulous notes on everything in his workshop. His advice was to write down the boring facts early, such as what, where, when and what color, because those are the facts you lose first. That is why this note starts with a plain list.

I also share the water source with a few other projects. When I was planning the work in the [[Bethtes Panvil plan]], I had to think about how much water the greenhouse could spare, and that was the first time I really leaned on the sensor for a decision.

## Maintenance

This is the practical how-to, written so I can follow it without thinking.

**Cleaning the panel**

1. Use a soft, slightly damp cloth.
2. Wipe gently from the top edge down.
3. Dry with a second cloth to avoid streaks.
4. Do not use any strong cleaner or anything rough.

**Cleaning the probe**

1. Lift the lid and slowly pull the probe out.
2. Rinse with clean water.
3. Use a soft brush on any green growth.
4. Rinse again and let it dry for a short while in the shade.
5. Put it back in the same position, so the readings stay consistent.

**Checking the cable**

- Run a hand along the length and feel for rough or flat spots.
- Look closely at the bend near the top of the post.
- Re-tape if the sleeve is worn through.

**Checking the mount**

- Test the bracket by hand.
- Tighten the screws if they turn easily.
- Adjust the angle so the panel faces the strongest light.

**Checking the reading**

- Use the dipstick to compare against the display.
- Do it at a full level and a low level.
- Write down any difference in the paper log.

If the display is blank, I clean the panel first, wait for a bright day, then check again before assuming a fault.

## Lessons

A few things I have learned from keeping this unit going.

- A dim display is usually a dirty panel. Clean first and worry later.
- Trust trends over single numbers. The sensor is good at showing direction.
- Keep a manual check. A dipstick costs almost nothing and it never fails.
- In winter, assume the sensor is unreliable. Plan for that rather than being surprised.
- Small mount problems cause larger symptoms. A tilted panel looks like a dying unit.
- Write the details down while they are fresh. I regret not noting the purchase details in 2014.
- Solar is a good choice for a place like this. No wiring and no batteries to change has saved a lot of effort.
- A black casing is fine for a sunny spot but needs thought about heat.
- Do the same job the same way each time. Putting the probe back in the same spot keeps readings comparable.

The idea of keeping the lessons separate from the problems is borrowed from how I handled the [[Brinza radio receiver]] notes. There, the list of faults was long and dull, and the real value came from the short list of what I would do differently.

## Supplies

What I keep on hand for this sensor.

- Two soft cloths, one damp and one dry
- A small soft brush
- A roll of weatherproof tape
- A few spare screws that fit the bracket
- A small screwdriver
- A spare rubber grommet in case the old one hardens
- A dipstick marked in clear steps
- A notebook and pencil, or this note open on my phone
- A bucket of clean water for rinsing the probe

I keep most of this in a small box on the shelf next to the barrel. It lives in the greenhouse so I do not need to fetch anything. The box is lidded because humidity rusts the screws if left open.

Not needed, but might be worth having: a spare cable, a small piece of wood for a sun shade, and a tube of grease for the screw threads.

## Background

The idea behind the sensor is simple. I use a barrel in the greenhouse as a buffer for watering, and I want to know how full it is without opening it each time. A level sensor does that job. The Mersos is a level sensor with a solar supply, which suits a spot with no mains power.

I picked a solar unit because running a cable from the house to the greenhouse was not practical in 2014. The post location gets good sun, so solar was a natural choice. The black casing was simply what the unit came in. I did not choose the color.

The greenhouse is where the sensor does its work, and it has its own microclimate. Warm and humid for much of the year, with dew on the glass. That puts some strain on any electronics, and it explains the damp cable entry and the algae on the probe.

The water in the barrel comes partly from rain and partly from topping up. In dry spells I sometimes bring water from the [[Masra pond]], which is why I keep an eye on the level in the first place. A low barrel means a trip to the pond.

The sensor sits in the forge area of my notes for historical reasons. I started tracking water and heat together in those notes, and the sensor stayed filed there.

## Measurements

These are the measured and recorded values for the sensor.

- Flow rate of Mersos level sensor: 1241.44 l/h

That is the only measured number I hold for this device, and I treat it as a reference point rather than a guarantee. I would not read it as a precise figure for every condition, since the reading depends on how the barrel is being filled and how still the water is.

Other recorded properties, repeated here so the section is complete:

- Kind: level sensor
- Color: black
- Energy source: solar
- Year installed: 2014
- Location: greenhouse

When I take new measurements, I record the conditions beside them: whether it was sunny, whether the display was bright, and whether the water had settled. Without those notes the numbers are hard to interpret later. I follow the same layout as in [[Palmosbrul scale notes]], with the value in one column and a short remark in the next.

If I ever repeat the flow measurement, I will do it on a bright day, after cleaning the panel and probe, with the barrel at a similar starting level. That keeps the comparison fair. Until then, the figure above stands as the one on record.
