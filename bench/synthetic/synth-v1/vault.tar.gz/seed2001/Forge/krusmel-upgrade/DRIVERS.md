---
type: drivers
status: active
project: krusmel-upgrade
area: forge
description: "Drivers about Krusmel upgrade."
---

# Drivers of Krusmel upgrade

## Tools

For the Krusmel upgrade I keep a small set of tools close to the forge bench. Most of the work is measuring, so the list is short and boring on purpose.

- A notebook with a hard cover, used only for this project. Every reading, every change and every phone call with the supplier goes in it.
- A tape and a set of calipers for checking the fit of any part before it goes near the fire.
- The level gauge from the old setup, kept as a reference so I can compare it with whatever replaces it.
- A handheld thermometer for checking the shell of the unit during a long run.
- The logger described in [[Faelond data logger study]], which I use for anything that has to be watched overnight.
- A camera, mainly to photograph the wiring and the pipe runs before I touch them, so I can put them back the same way.

The supplier contact leads this project, so I also keep a shared list of questions. I add to it during the week and send it in one batch. That saves both of us time and avoids a dozen small messages.

## Background

Krusmel upgrade is a project in the forge area. Its goal is an upgrade of the existing setup, and it started in the autumn of 2023. The lead is the supplier contact, which is unusual for me, because most of my projects I run alone. Here the supplier knows the equipment better than I do, so it made sense to let them steer and for me to act as the person on site.

The reason for the upgrade is simple. The old arrangement worked, but it needed too much attention. I had to check levels by eye, and I had to guess when something was running low. More than once I found out too late. The upgrade is meant to remove that guessing and to make the forge calmer to work in.

Earlier notes feed into this one. I wrote down what I learned about sensors in [[Rinraes level sensor notes]], and I picked one candidate in [[Paethvol level sensor]]. The layout questions, such as where things can physically sit, come from [[Fofen shed plan]]. Storage of spare parts and the less used material goes to [[Vindseth loft]], which keeps the bench area clear.

What I want out of the project, in one sentence: a forge setup that tells me what it is doing without me standing next to it.

## Safety

Safety is the first constraint, before cost and before schedule. Anything that sits near heat, fuel or electrical supply gets handled with extra care.

- Power is switched off and locked out before any wiring is touched. I do not trust a switch alone, so I also pull the plug where that is possible.
- Nothing is changed while the forge is warm. I wait until the whole area has cooled and I check it by hand-held thermometer, not by feel.
- Sensors and cables near heat must be rated for it. If the supplier cannot confirm the rating, the part does not go in.
- A fire extinguisher stays within reach of the bench during all work, and I check its gauge at the start of each session.
- I work with ventilation open. Fumes from old fittings and cleaning fluids are not something to ignore.
- Eye protection and gloves are mandatory, even for small jobs. Small jobs are where I get careless.

If anything looks wrong during a step, I stop, make the area safe and write down what I saw before deciding what to do. I do not push through to finish a step.

## Maintenance

An upgrade that is hard to maintain is not an upgrade. I want the new setup to be something I can look after on my own, with simple checks.

- Every sensor must be reachable without dismantling the whole unit.
- Connections should be labelled at both ends, so I can trace a cable without guessing.
- I want a short routine, done once a month: look over the cables, clean the sensing parts, compare the reading with the reference gauge, and note the result.
- Spare parts for the parts most likely to fail should be on hand. The supplier contact will advise which ones, and the spares go in [[Vindseth loft]] in a labelled box.
- Any change to the setup is written in the notebook the same day, with a photograph.

I also want the supplier to give me a plain description of how to calibrate and reset the main parts. If that description is only available through a call, I will write it down myself and keep it with this project.

## Observations

These are things I noticed before the upgrade began, and they shape what I am asking for.

- The old way of checking levels took me several minutes each time, and I tended to skip it when busy. Skipped checks were the main cause of trouble.
- Readings by eye differ depending on the light. In the evening I read the same level lower than in the morning.
- The shell of the unit gets warm in a long run, and I have no record of how warm. That is why I now measure it.
- Overnight events are invisible to me. I only see the result in the morning. This is the reason I looked at logging in [[Faelond data logger study]].
- The sensor notes in [[Rinraes level sensor notes]] showed that cheap sensors often drift. I want something that holds its reading, or at least lets me recalibrate easily.

None of these are dramatic. Together they say the same thing: the problem is not the equipment's strength, it is my lack of information.

## Schedule

The project began in the autumn of 2023, and I plan it in stages rather than by exact dates, because the supplier's delivery times are not in my control.

1. Decide the scope and confirm it with the supplier contact. This is mostly talking and writing down the goal.
2. Check the layout against [[Fofen shed plan]], so I know where each new part will physically go.
3. Order the parts, starting with the ones that take longest to arrive.
4. Prepare the area: clear the bench, move stored material to [[Vindseth loft]], and photograph the existing wiring.
5. Install in small steps, testing after each one, never several changes at once.
6. Run the new and old setups side by side for a while and compare the readings.
7. Remove the old parts only after the comparison looks good, and write up the result.

Because the supplier leads, I treat their advice on ordering and sequence as the default, and I only push back when it conflicts with the safety rules above.

## Costs

The costs of this project fall into a few groups. I list them here in words, and the total limit is in the budget section.

- Parts: the sensor and its fittings, cables, connectors and mounting pieces. This is the largest group. The candidate sensor is described in [[Paethvol level sensor]].
- Supplier time: some of the work is advice and checking, and the supplier may charge for it. I need to ask this early, not at the end.
- Logging: if I add overnight recording, there is a cost for the logger and its storage, based on the findings in [[Faelond data logger study]].
- Consumables: cleaning materials, labels, tape and protective items that wear out.
- Spares: a few of the parts most likely to fail, bought at the same time to save on delivery.
- Surprises: fittings that do not match, or a part that arrives damaged. I always set a margin for these, because they happen.

I record every purchase in the notebook with the date, the item and what it was for. That makes it easy to see where the money went if I end up near the limit.

## Setup

The planned setup has three layers, and I want each one to work on its own before connecting it to the others.

**Sensing.** A level sensor sits in the place chosen from the layout work. The reading is taken at a fixed point, so that it is always comparable. The reference gauge stays in place during the trial period.

**Display.** A simple readout near the bench, where I can see it without moving. It should be readable in poor light, since my eye readings suffered from that.

**Recording.** A logger keeps the readings during the night and when I am away. I look at the record in the morning and compare it with what I expected.

The physical arrangement follows [[Fofen shed plan]]. Cables run along existing supports, away from heat, and are labelled. Spare material and unused old parts go to [[Vindseth loft]] once the trial is finished.

Success is measured in a few plain ways:

- I no longer need to check levels by eye during normal work.
- The recorded readings agree with the reference gauge during the trial.
- I notice a problem from the record before I notice it at the bench.
- The monthly maintenance routine takes me a short time and I actually do it.
- The project stays within the budget below.

## Risks

- **Delivery delay.** The supplier may be slow, and the forge would then sit half-changed. Mitigation: do not start dismantling until all main parts have arrived.
- **Sensor drift.** The notes in [[Rinraes level sensor notes]] warn about this. Mitigation: keep the reference gauge during the trial and check the sensor against it regularly.
- **Heat damage.** A part placed too close to the fire could fail. Mitigation: confirm ratings and measure the shell temperature before fixing anything.
- **Wrong fit.** Parts that do not match the existing fittings. Mitigation: measure with calipers and send the supplier photographs before ordering.
- **Lead depends on someone else.** The supplier contact leads, so decisions may wait on their replies. Mitigation: send questions in one batch and agree on reply times at the start.
- **Scope creep.** It is tempting to add logging features that I do not need. Mitigation: any addition has to answer the goal of an upgrade that tells me what it is doing, otherwise it waits.
- **Safety slip.** Rushing a step near heat or power. Mitigation: the rules in the safety section, with no exceptions.

## Budget

The budget of Krusmel upgrade is 39178.24 EUR.

This is the upper limit for the whole project: parts, supplier time, logging, consumables, spares and the margin for surprises. I treat it as a ceiling and not a target. If a purchase would push me near the limit, I stop and discuss it with the supplier contact before ordering.

I check the running total after every order and write it in the notebook. If the margin for surprises is used up before the installation is finished, I pause, review what remains, and cut anything that does not serve the goal. The comparison with the reference gauge and the safety work are the last things I would cut, so they are protected first.
