---
type: log
status: active
project: krusmel-upgrade
area: forge
description: "Log about Lasnur Zazond."
---

# Lasnur Zazond log

## Maintenance

This log is about Lasnur Zazond, my mentor in the forge. I have known him since 2018. We meet in person, and he is only available on weekends. Because of that, the main upkeep of this relationship is planning. I keep the notes tidy, I write down what I want to ask before a weekend, and I write down what I learned afterwards.

Things I do to keep the mentoring useful:

- Before each weekend visit I write a short list of questions about the work I am stuck on.
- I bring the piece I am working on, even if it looks bad. He learns more from a failed piece than from my description of it.
- After the visit I rewrite my notes the same evening, while I still remember his wording.
- I return borrowed tools clean and in the state I received them.
- I send no messages during the week. He prefers that we talk in person, so I save my questions for the weekend.

The one thing that breaks the routine is a missed weekend. If I cannot go, I tell him at the forge the weekend before, not on the day. I have learned that a missed visit costs more than one Saturday, because the thread of what we were working on goes cold.

## Observations

Over the years I have noticed several habits that Lasnur Zazond repeats. I list them here because they help me prepare.

- He looks at the fire and the metal before he looks at the person. If he is silent for a minute, he is reading the heat, not ignoring me.
- He asks what I expected to happen before he tells me what did happen. This irritated me early on. Now I understand it as the actual lesson.
- He rarely corrects the final shape first. He corrects the order of steps, and the shape usually fixes itself.
- He will not let me rush a heat. If I reach for the hammer too early, he simply waits until I put it down.
- He keeps his bench almost bare. Tools that are not in use go back on the wall.
- He is more generous with time late in the day. The best conversations have always happened after the main work was done and the forge was cooling.

I also notice things about myself when I am with him. I talk too much when I am nervous. I get better results when I say less and watch his hands. I tend to over-grind a piece when I am unsure of the shape, and he points it out every time.

## Overview

Lasnur Zazond is a person in my life with the role of mentor. His area is the forge, which is the part of my life where I work with fire, iron, and hand tools. Our contact is in person. His availability is weekends. I have known him since 2018.

That is the short version, and it is worth writing out in full because it explains how everything else in this note works. A mentor who is only reachable in person on weekends is not someone I can call when something goes wrong at a weekday evening session. So I have to build my own habits around that limit. I learn to solve small problems alone, keep a list of the larger ones, and bring them to him when we meet.

What he gives me is not mainly technique, though I have learned a great deal of technique from him. He gives me judgment. He teaches me how to decide when a piece is finished, when it should be scrapped, and when a mistake is worth keeping as a lesson. This is difficult to get from books.

I am also aware that he introduced me to others in the same circle. One of them is [[Brasmaen Pasviond]], who I mention below where it fits. Knowing both of them has widened what I can ask and where I can go for another opinion.

## History

I met Lasnur Zazond in 2018. At the time I had a small setup and almost no knowledge of how to use it safely. I had read enough to be dangerous and not enough to be good. He saw that quickly.

The first year was mostly watching. He let me hold tongs and move stock, and for a long time he did not let me strike anything important. I was impatient about that. Looking back, it was the right decision, because I learned the rhythm of the shop before I learned to make anything.

In the following years the work changed gradually. I began to make simple pieces under his eye: hooks, small blades, a set of handles. He would let me finish a piece and then show me exactly where it had gone wrong. He never took the tool out of my hand to fix it himself. I think that mattered more than any single technique.

Somewhere along the way the relationship became less formal. We started talking about things other than the work, such as how to organise a week, when to stop, and how to deal with a project that has gone sour. The weekend schedule stayed the same throughout. It has been the same arrangement since the beginning, and I have never tried to change it.

Through him I came to know [[Brasmaen Pasviond]], who works nearby and sometimes joins on weekends. Having a second person to compare opinions with has been useful, especially when Lasnur is being deliberately vague to make me think.

## Risks

Some of the risks in this relationship are about the forge, and some are about the arrangement itself.

The practical risks first. Work with fire and hot metal can injure me, and being a beginner makes this worse, not better. The biggest danger is overconfidence after a good session. I have had weekends where everything worked, and the next time I tried the same thing alone it went wrong because I skipped a step that he had been quietly doing for me.

The arrangement carries its own risks:

- Dependence. If I save every question for the weekend, I may stop thinking about problems myself. I try to attempt a solution first and bring both the attempt and the question.
- Single point of failure. He is available only on weekends, and only in person. If he is ill or away, I have nobody else at that level, apart from asking [[Brasmaen Pasviond]] for a second view.
- Misreading silence. When he does not answer, it can mean approval, doubt, or that he wants me to find the problem. I need to ask directly instead of guessing.
- Taking too much of his time. He gives his weekends freely. I should not treat that as unlimited, and I should offer help with his own jobs when I can.
- Copying without understanding. If I only imitate what I see, I will not be able to adapt when the material behaves differently.

## Safety

The forge is where I need to be most careful, and he has drilled these rules into me over the years. I write them as he says them, as closely as I can remember.

- Wear eye protection every time, including when I am only standing nearby.
- Wear leather and natural fibres. Synthetic clothing can melt onto skin.
- Keep the floor clear. Stock, offcuts, and tools on the ground are a trip hazard next to a hot fire.
- Know where the water and the fire extinguisher are before I light anything.
- Never assume that metal is cold. Dark iron can still burn. He tells me to hold my hand near it first, and never to touch it to test it.
- Do not work when tired or distracted. A short session done well is better than a long one done badly.
- Keep the ventilation working. Fumes build up faster than I notice.
- Tell someone when I am working alone. Because he is only around on weekends, this is a rule I must follow on other days by myself.

He also insists on one habit above the rest: stop and think before every strike and every move of hot stock. If I cannot say what I am about to do and why, I am not ready to do it.

## Checklist

Before a weekend with Lasnur Zazond:

- Confirm that I can attend, and tell him early if I cannot.
- Write down the questions I want to ask, in order of importance.
- Bring the unfinished piece, along with any failed attempts.
- Pack gloves, eye protection, and leather apron.
- Bring something to write with, and a notebook that can survive a dirty bench.
- Check which supplies I need to buy or bring, and see the Supplies section.
- Decide what I want to be able to do better by the end of the weekend.

At the forge:

- Say hello, look at the fire, and wait to be told where to start.
- Say less, watch more.
- Ask what he would do before explaining what I did.
- Clean up before leaving, including the floor and the tools.

After the visit:

- Rewrite notes the same evening.
- Mark what I should practise alone and what I should leave until the next weekend.
- Add anything worth keeping to the Lessons section.

## Schedule

The schedule is simple because his availability is simple: weekends. That is the only time he can meet, and the contact is always in person.

I arrange my week around that fact. Early in the week I review my notes from the last visit and decide what to practise. Midweek I do my own work in the forge and try to solve problems alone. Toward the end of the week I make my question list and gather the supplies I need. Then I go on the weekend.

A typical weekend visit looks like this:

- Arrive, greet him, and help with whatever he is already doing.
- Show him my piece and tell him what I expected from it.
- Work on one specific skill for most of the session.
- Spend the last part of the day cleaning up and talking.
- Go home and write up the notes.

I try to keep to one main topic per visit. When I attempt three things at once, I remember none of them. When [[Brasmaen Pasviond]] is there too, the visit tends to be looser and more conversational, and I plan for that by keeping my own list short.

If a weekend is missed, I do not try to double up the next one. I just continue from where my notes left off.

## Quotes

Quoted price of Lasnur Zazond: 5077.52 EUR

This is the price he quoted for a larger piece of work, and I have written it down so that I do not misremember it later. It is not something I have agreed to, and I have not paid it. I treat it as a reference point for what a serious job of this kind costs when it is done by someone with his skill.

Things he has said that I want to keep, written from memory:

- "Watch the metal, not the clock."
- "If you cannot explain the next step, you are not ready for it."
- "A good fire is quiet."
- "Fix the order and the shape follows."
- "You do not learn from the piece that worked."

I wrote these down because they sound simple and they are not. Each of them has saved me from a mistake more than once.

## Supplies

I do not rely on him to supply my materials. Over time I have worked out what I should bring and what I can use from his forge.

What I bring myself:

- Eye protection and gloves.
- Leather apron and sturdy boots.
- Notebook and pencil.
- A rag or two for cleaning.
- Any stock I want to work on, if it is part of my own project.

What I use from the forge, with his permission:

- Anvil, hammers, and tongs.
- The fire and its fuel. I offer to cover the fuel for the day when I use a lot.
- Quenching water and general shop tools.

I try to replace what I use. If I take the last of something, I tell him and buy more. I also try to offer a small thanks, such as food, a favour, or an hour of help with cleaning. He never asks for anything, which is exactly why I make a point of offering.

If I ever need to order something larger, I ask him first which kind to buy, because he knows what is worth the money and what is not.

## Background

Lasnur Zazond is a mentor whose area is the forge. I have known him since 2018, and our contact has always been in person on weekends. That is the context for everything in this log.

He does not talk much about his own past, and I have never pushed. What I know is what I have seen: he has a deep, practical familiarity with fire and metal, and he treats the craft with patience and respect. He is not interested in showing off. When he works, he does it in plain steps, and he expects the same of me.

I have no interest in turning him into a legend. He is a person who is good at something and willing to pass it on, within the limits of his time. That is already a lot.

Part of why the arrangement works is that we are both clear on the boundaries. He gives his weekends. I give my attention and effort. Neither of us pretends it is anything bigger than that. The circle around him, including [[Brasmaen Pasviond]], is small and informal, and it works because nobody tries to organise it too much.

When I write about him here I try to stay factual and avoid guessing at his motives. It keeps the log useful rather than sentimental.

## Lessons

These are the main things I have taken from my years with Lasnur Zazond.

- Order matters more than force. If the steps are right, the result tends to follow.
- Slow down before the hard part. Rushing a heat or a strike nearly always costs more time than it saves.
- Say what I expect before I act. Comparing expectation and result is where most learning happens.
- A failed piece is worth more than a lucky one, as long as I look at it honestly.
- Keep the workspace clean. A clear bench makes clear thinking easier.
- Do not confuse a good day with skill. Repeating the result alone on a normal day is the real test.
- Respect the limits of a mentor's time. Weekends only means I should arrive prepared and leave with something written down.
- Have more than one source of advice. Asking [[Brasmaen Pasviond]] as well has helped me see which of Lasnur's lessons are rules and which are just his way of working.
- Write it down the same day. Memory fades fast, and the small remarks are often the most useful ones.

If I had to put it into one sentence, it would be this: pay attention, be patient, and come back the next weekend ready to do it again.
