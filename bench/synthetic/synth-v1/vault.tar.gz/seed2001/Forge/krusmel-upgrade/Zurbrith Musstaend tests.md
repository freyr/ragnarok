---
type: research
status: active
project: krusmel-upgrade
area: forge
---

# Zurbrith Musstaend tests

## Overview

Zurbrith Musstaend is an accountant whose work is tied to the forge. I have known this person since 2011, so this is a long-running contact and I treat the notes here as a working record, not a first impression.

Properties as I keep them:

- Role: accountant
- Area: forge
- Contact: in person
- Availability: weekdays
- Known since: 2011

The practical meaning is simple. Zurbrith does not answer well to messages sent into the void, so I plan to speak face to face. Since availability is weekdays, I do not bother trying on weekends. If I need something checked before a weekend, I ask early in the week.

The reason for this note is to collect what I have learned from testing how reliable the figures and answers are. The word "tests" in the title means small checks I ran against Zurbrith's numbers, not a formal audit. I compared what was said in person with what I could verify from my own records. Most of it matched. Where it did not, the gap was usually a matter of timing, not a mistake.

A related piece of background is in [[Faelond data logger study]]. That study used the same habit of writing down a claim, then checking it later. I am applying the same method here: note the claim, note the source, and note whether it held up.

What I want from this work:

- A clear picture of how Zurbrith prices and explains things.
- A short list of questions I should always ask in person.
- A reminder of what to bring to each meeting.

## Quotes

The only price I have on record is the quoted price of Zurbrith Musstaend: 2339.68 EUR.

Notes on how I handle this quote:

- The quote was given in person, as is usual for this contact, so I wrote it down right after the conversation.
- I should confirm what the quote covers before I rely on it. Bookkeeping for the forge can mean several things, and the scope matters more than the headline figure.
- If the scope changes, I ask for the quote to be restated and I write the new one beside the old one, not over it.
- I do not compare this quote with others until I know that each one covers the same work.

Things Zurbrith has said that I want to keep in mind, paraphrased from memory and not as exact words:

- Records are easier to handle when they come in regularly, not in one large batch.
- Questions are better asked early in the week, when there is time to answer them properly.
- A figure without a source is only a guess, so bring the paper.

I should add real quotes here only when I have written them down at the time. Until then these stay as paraphrases.

## Checklist

Use this before each meeting with Zurbrith.

- [ ] Pick a weekday. Do not plan anything for the weekend.
- [ ] Arrange to meet in person, since that is the contact method that works.
- [ ] Bring the paperwork for the forge: receipts, invoices and any earlier notes.
- [ ] Re-read the quote of 2339.68 EUR and check that the scope is still the same.
- [ ] Write down the questions in advance, and put the most important one first.
- [ ] Note each claim made during the meeting, and who or what it came from.
- [ ] Mark which claims I can check myself and which I have to take on trust.
- [ ] Write a short summary the same day, while it is still fresh.
- [ ] Look back at [[Faelond data logger study]] if I need a reminder of how I record and verify claims.
- [ ] Set a date for the next check so the tests keep going.

After the meeting, I update this note with anything that changed. If a claim failed a check, I record what the difference was and what Zurbrith said about it when I asked.
