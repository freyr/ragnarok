---
type: log
status: active
project: krusmel-upgrade
area: forge
---

# Liolkandzo Baelgliond log

## Overview

This is my running log for Liolkandzo Baelgliond. Liolkandzo is an inspector who works in the forge area. I keep this note so I can see at a glance what has happened between us, what I learned from it, and how to reach them without guessing.

The basic facts, so I don't have to search for them:

- Role: inspector
- Area: forge
- Contact: email
- Availability: weekends
- Known since: 2025

Email is the only channel that has worked reliably. Liolkandzo does not answer quickly during the week, and I have stopped expecting it. Messages sent on a Friday evening tend to get an answer on Saturday or Sunday, which fits the weekend availability. If I need something for a Monday, I write by the Thursday before at the latest.

I first came across Liolkandzo in 2025, and most of what is written below comes from that year and the time since. I try to keep entries short and factual. Opinions go in the Observations section, so the rest of the note stays usable as a reference.

## History

I met Liolkandzo in 2025 while sorting out how inspections were done at the forge. At that point I only knew the name and the role. The first exchange was a short email asking when an inspection could be arranged. The reply came on a Sunday, which set the pattern for everything after.

The early period was mostly about learning how the inspector works. Liolkandzo likes written questions that are specific. A vague request such as "can you look at the batch" gets a question back, while a request that names the item, the place and the reason gets a direct answer. I wasted a couple of weeks at the start by being vague.

Over the following months the relationship became routine. I send a list of items, Liolkandzo picks a weekend, and the findings come back by email in plain text. There were no phone calls. I tried once to arrange a call and it simply did not happen, so I went back to email and the problem went away.

Some of the background on how I judge results comes from my other notes. The comparisons I made while reading the findings are in [[Pundtra Sturland tests]], and the earlier thinking about what counts as a pass is in [[Trithluth Torkkind notes]]. I go back to both when a finding seems odd and I need to decide whether the problem is the item or my expectations.

## Lessons

These are the practical things I have learned, in rough order of how much time they saved me.

1. Write to Liolkandzo by email and nothing else. Other channels waste time.
2. Plan around weekends. Do not set a deadline that falls on a weekday and expect an answer before it.
3. Be specific. Name the item, the place and the reason for the request in the first message.
4. Send one topic per email. When I combined two topics, only one of them got answered and the other was lost.
5. Keep my own copy of every finding. The emails are clear, but I do not want to depend on searching an inbox later.
6. Ask for the reasoning, not only the verdict. A short explanation from the inspector helps me far more than a bare pass or fail.

One more lesson is about patience. A slow reply is not a refusal. Liolkandzo works the forge area during the week and answers when time is free. Once I stopped chasing, the answers became more complete, and I think that is not a coincidence.

When I am unsure whether something is worth raising, I check how a similar case went in [[Polgindvio Piostund log]]. It often shows me whether the matter is normal or whether it deserves a message.

## Contracts

The contract date of Liolkandzo Baelgliond is 2022-05-06. I have this written down because it is the reference point whenever I need to check how long the arrangement has been in place, or when someone asks which terms apply.

Note that the contract date is earlier than the year I first met Liolkandzo, which is 2025. The contract existed before I had any contact. I only dealt with the inspector once I took over the relevant work, so the paperwork predates my own log. When reading older papers, I should not assume that I was involved in them.

What I do with the contract in practice:

- I look at it before I ask for anything unusual, to see whether the request is in scope.
- I keep it separate from the email findings, so that terms and results are never mixed up.
- I mention the date when I write to Liolkandzo about scope, so we both refer to the same document.

I have not seen any dispute about the terms. If one ever appears, this section is where I will record what was agreed and when, and the date above stays as the starting point.

## Observations

Liolkandzo is consistent. The pattern of email in, weekend answer out has held since 2025, and I can plan around it. That is worth more to me than speed.

The findings are brief and stick to what was seen. There is very little padding and no speculation. When something is unclear, the inspector says so and does not guess. I prefer that, even though it sometimes means a second round of questions.

A few things I want to keep watching:

- Whether the weekend availability changes. So far it has not, but any change would force me to rework my schedule.
- Whether email stays enough. If the volume of items grows, a single weekly reply may become a bottleneck.
- Whether the level of detail in the findings stays the same. It has been steady, and I would notice a drop quickly.

On balance, Liolkandzo is a dependable inspector for the forge area, provided I respect the limits: email only, weekends only, specific questions. Working within those limits has cost me nothing and saved me a lot of back and forth.

Next time I add an entry, I will put the date of the exchange, the item, and the outcome in one line each, then move any lasting lesson up into the Lessons section.
