---
type: summary
status: active
project: krusmel-upgrade
area: forge
description: "Summary about Krusmel upgrade."
---

# Summary of Krusmel upgrade

This is the summary note for the Krusmel upgrade, a project in the forge area. The goal is an upgrade. The work started in autumn 2023, and the lead is the supplier contact. I keep this note as the single place to check where the project stands, what is finished, what is still open and what I do next.

Current stage: the project is in the middle of execution. The planning is finished and the go decision is made. Part of the physical work is done, and the rest waits on the supplier contact and on a few answers I still need. It is not blocked, but it moves only as fast as the supplier replies.

## Risks

The biggest risk is dependence on one person. The supplier contact leads the project, so if that person is away, slow or changes role, the work stops. I have no second contact on the supplier side. I should ask for a backup name and write it here once I have it.

The second risk is that the upgrade changes how the forge behaves. A forge is not a place where I can test lightly. If the new setup heats differently, holds heat differently or draws more from the supply, my usual working rhythm changes. I need to expect a short period of relearning before I trust the result.

The third risk is schedule drift. The project started in autumn 2023, and the work has been stretched by waiting. Long gaps make me forget small details, such as which parts were already checked and which were only assumed. I try to write every check down on the day I do it, and I keep this summary in line with those notes.

The fourth risk is mismatched parts. The upgrade uses components from the supplier, and my forge is older than the parts. A part can look right on paper and still not fit in the real space. Before any part is fixed in place, I do a dry fit and compare it to the old piece. If it does not match, I stop and ask, instead of forcing it.

The fifth risk is lost working time. While the forge is being changed, I cannot do the jobs that need it. I plan those jobs for other places or move them to later, and I do not promise anything to anyone that depends on the forge being ready by a certain day.

The last risk is a quiet one: scope creep. Each time I open something up, I see another thing worth improving. The goal is an upgrade, and I want to keep it to that. Extra ideas go into a separate list and wait until this project is closed.

## Tools

The tools for this project are mostly ordinary ones, and I keep them together so I do not hunt for them in the middle of a step.

- Hand tools for taking apart and fitting: spanners, a socket set, pliers, and a set of screwdrivers. I keep them in a single box near the forge.
- Measuring tools: a steel rule, a tape, and calipers. I measure the old piece first and the new piece second, and I write both down.
- A marker and masking tape for labeling. Everything I take off gets a label showing where it came from and which way it faced.
- A wire brush and rags for cleaning surfaces before anything is joined again.
- A torch and a small mirror for looking into tight spaces.
- A notebook, plus this note, for recording what I did.
- Heat-resistant gloves and tongs, kept separate from the general tools so they stay clean and in good shape.

I do not plan to buy any new tools for this project. If a step needs a tool I do not own, I would first ask whether the supplier contact can lend it or tell me a cheaper way. I count that as a change to the plan, and it goes under Decisions before it goes anywhere else.

One habit I keep: I return each tool to the box at the end of a session, even if I will use it again the next day. It saves more time than it costs.

## Decisions

The go decision for the Krusmel upgrade was made on 2019-06-27. That is the date I use as the formal start of the commitment, even though active work in this project began later, in autumn 2023. The gap between the two is long, and I should remember that when I read old notes: the early ones come from the preparation period, not from the work itself.

Other decisions, in plain terms:

- The supplier contact leads the project. I keep the decisions about timing and sequence with that person, and I keep the decisions about my own space and safety with me.
- The goal stays as an upgrade of the existing forge. I am not replacing the whole forge and I am not moving it.
- I will do the physical work in small stages, and I will check each stage before the next one. I prefer a slow finish to a fast restart.
- I will keep the old parts until the new setup has proven itself over a good stretch of normal use. Nothing old is thrown away early.
- New ideas wait. Anything that is not part of the upgrade goes into a separate list.
- I keep the notes in my own words and I record the reason for each decision, because I tend to forget the reason sooner than the decision.

If I ever reverse one of these, I will write the new decision here and leave the old one visible with a short remark, not erase it.

## Next action

The next action is NX-0283.

I do not want to retype what that item contains, so I keep its details in my task list. In practice, it is the next concrete step I take to move the project forward, and it comes before anything else on my list for this project. When it is done, I will update this section to the following step, add a line to History, and check whether any open question has been answered by the result.

Before I begin, I will prepare in a few simple ways: clear the work area, lay out the tools from the box, read the relevant earlier notes once, and confirm that the forge is cold and isolated. If the supplier contact has sent anything new, I read it first, since it could change the order of work.

## History

A short timeline in words, since the exact dates of the small steps are in my working notes and not needed here.

- Early on, the idea of upgrading the forge came up, and I collected information from the supplier. This period ended with the go decision on 2019-06-27.
- After the decision, the project stayed quiet for a long time. Other work took priority, and the supplier side was not ready.
- In autumn 2023 the project truly started. The supplier contact took the lead, and we agreed on the general approach and the order of work.
- The first stage was preparation: measuring the existing setup, listing the parts that would be replaced, and clearing the space around the forge.
- The next stage was the removal and inspection of the older parts. I labeled them and kept them. Some looked worse than I expected, which confirmed that the upgrade was worth doing.
- Part of the new components arrived and were dry-fitted. Most fitted as planned. One needed a small adjustment, which I handled with the supplier contact.
- After that, progress slowed as I waited on replies and on the remaining items.
- Today the project is in execution, with the next step recorded in the Next action section.

What is done, summed up: the planning, the go decision, the measurements, the removal and inspection of the old parts, and the first dry fits. What is not done: the final fitting of the remaining components, the full check of the new setup, and the closing of the project with a clean record.

## Open questions

These are the things I still do not know. I keep them as questions so that I notice when an answer arrives.

- Who is the backup contact on the supplier side if the lead is unavailable?
- Will the remaining components arrive in one delivery or in parts, and does the order of arrival change the order of work?
- Does the upgraded forge need a different routine for the first heating, and does the supplier have written guidance for it?
- How long should I keep the old parts before I let them go?
- Is there a simple test that shows the upgrade works as intended, so that I can call the project finished without guessing?
- Do I need to change anything about how I store fuel, stock or tools near the forge once the upgrade is in place?
- Are there maintenance steps that become more frequent after the upgrade, and should I add them to my regular routine?
- Should I ask the supplier contact for a short written handover at the end, so that the knowledge does not stay only in that person's head?

When an answer comes, I move it into Decisions if it changes the plan, or into History if it is only a fact.

## Safety

The forge is a hot and unforgiving place, and a project that changes it has its own hazards on top of the normal ones. My rules for this project:

- Work only on a cold forge. I check by hand-distance and by waiting longer than I think I need, not by trusting that it has been long enough.
- Isolate the supply before opening anything. Whatever feeds the forge, whether fuel, air or power, is shut off first, and I confirm it is off.
- Wear proper protection: eye protection, gloves, sturdy shoes and clothing that does not hang loose. When cutting, grinding or cleaning, I add a mask.
- Keep the floor clear. Parts, tools and rags left on the ground are a trip risk, and tripping near a forge is serious.
- Lift heavy parts with care, and ask for a second pair of hands when a part is awkward, not only when it is heavy.
- Do not rely on memory for how the old setup was connected. I use the labels and the photographs I took.
- After the work, do a slow and careful first heating. I stay present the entire time, keep a way to shut everything off within reach, and keep a suitable extinguisher close.
- Never work alone on the riskiest steps. I make sure someone knows when I am working and when I expect to finish.
- Stop if something feels wrong. A strange smell, an unexpected sound or a part that will not seat is a reason to pause and ask, not to push on.

I treat the safety section as higher priority than the schedule. A delay costs time. An accident costs much more.

## Costs

I keep the costs here at a general level, because the exact figures live in my accounts and I do not want two versions of the truth.

The main cost is the set of components from the supplier. That was agreed at the time of the go decision and has stayed broadly in line with the original expectation. The supplier contact has been straightforward about what is included and what is not.

Smaller costs come on top: consumables such as cleaning materials, tape, and labels, and the occasional small fitting or fastener that turns out to be needed. I have kept these low by reusing what I can and by checking the old parts before ordering new ones.

There is also a cost in time. The forge is out of use for part of the project, and that time cannot be used for the work that needs it. I count this as a real cost, even though it does not show up as money. It is one more reason to avoid scope creep and to finish in clean stages.

There is a possible cost I have not yet closed: an unexpected extra part, if a dry fit shows that something does not match. I treat this as a risk to watch, not as a planned expense. If it happens, I will record it under Decisions together with the reason.

Last, there may be a small saving later, if the upgraded forge works more efficiently and needs less fuel or less repair. I do not count on it, and I will only write it down after I have seen it in use.
